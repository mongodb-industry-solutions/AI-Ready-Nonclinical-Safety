"""
Shared Pydantic models for Runner SDK components.

These models define the API contracts between:
- Orchestration Engine (OE)
- Agent Execution Runtime (AER)
- Tool Executor Pod
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from enum import Enum
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from magenta_sdk_core.models import (
    LLMInvocationOptions,
    LLMResponse,
    LLMTokenUsage,
    LLMToolCall,
    LLMToolSchema,
    Message,
    ToolCallChunk,
)
from pydantic import AliasChoices, BaseModel, Field, JsonValue, model_validator

if TYPE_CHECKING:
    from runner_shared.logging import ExecutionLog, NodeExecutionLog

# =============================================================================
# Execution Status
# =============================================================================


class ExecutionStatus(str, Enum):
    """Status of an agent execution."""

    PENDING = "pending"
    RUNNING = "running"
    SUSPENDED = "suspended"
    RESUMING = "resuming"
    COMPLETED = "completed"
    ERROR = "error"


# =============================================================================
# Suspend Payload (Agent → Platform)
# =============================================================================


class SuspendPayload(BaseModel):
    """Payload returned by an agent tool to trigger human-in-the-loop suspension.

    Agent tools signal a suspend by returning a JSON string containing these
    fields.  The ``__suspend__`` flag is stripped before the payload is passed
    to LangGraph's ``interrupt()``.

    Example usage in an agent tool::

        from runner_shared.models import SuspendPayload

        payload = SuspendPayload(
            suspend_reason="awaiting_human_review",
            suspend_context={"claim_id": "C-123", "task_id": "T-456"},
        )
        return payload.to_json()
    """

    suspend_reason: str = Field(
        ..., description="Why the agent is suspending (e.g. 'awaiting_human_review')"
    )
    suspend_context: Dict[str, Any] = Field(
        default_factory=dict,
        description="Arbitrary context the human reviewer needs to make a decision",
    )

    def to_json(self) -> str:
        """Serialize to the JSON wire format expected by _process_result."""
        data = self.model_dump()
        data["__suspend__"] = True
        return json.dumps(data)


# =============================================================================
# Streaming / Interrupt Results (AER internal)
# =============================================================================


class InterruptResult(BaseModel):
    """Result from agent execution when the agent is suspended.

    Contains the suspend payload directly (framework-agnostic) rather than
    wrapping LangGraph-specific Interrupt objects. Any framework-specific
    state needed to resume (LangGraph checkpoint id, ADK function-call
    correlation, etc.) is carried opaquely in ``metadata`` — the AER never
    inspects it; the framework adapter writes it on suspend and reads it back
    from ``RequestContext.metadata`` on resume.
    """

    suspend_payload: Dict[str, Any] = Field(
        description="Suspend payload from the agent's suspend event",
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Opaque framework-specific resume state, round-tripped to resume",
    )


class StreamingResult(BaseModel):
    """Result from agent execution for normal completion.

    Returned by _execute_via_agent_stream when the agent finishes without
    suspend. The caller uses content for the final response and messages
    for memory writing.
    """

    content: str = Field(
        default="",
        description="Sanitized final AI response (thinking stripped, trailing empties skipped)",
    )
    messages: list[Message] = Field(
        default_factory=list,
        description="All messages from agent execution (sdk-core Message objects), for memory writer",
    )


# =============================================================================
# Agent Start (Client → OE)
# =============================================================================


class InvokeRequest(BaseModel):
    """Request to invoke the agent (compatible with agent-runtime)."""

    message: str = Field(..., description="User message")
    session_id: Optional[str] = Field(default=None, description="Session ID for trace correlation")
    thread_id: Optional[str] = Field(
        default=None, description="Thread ID for conversation continuity"
    )
    # Multi-tenant context
    org_id: Optional[str] = Field(
        default=None, description="Organization ID for multi-tenant isolation"
    )
    user_id: Optional[str] = Field(default=None, description="User ID for personalization")
    workspace_id: Optional[str] = Field(
        default=None, description="Workspace identifier for cost tracking"
    )
    project_id: Optional[str] = Field(
        default=None, description="Project ID for project-level scoping"
    )
    # Per-agent AER routing
    aer_url: Optional[str] = Field(
        default=None, description="AER HTTP endpoint for this agent; overrides default AER_URL"
    )
    tool_url: Optional[str] = Field(
        default=None, description="Tool HTTP endpoint for this agent; overrides default TOOL_URL"
    )
    # Sync mode (default: wait for completion)
    wait: bool = Field(default=True, description="If true, wait for completion and return result")
    # Custom headers forwarded from caller (X-Mdb-Agentic-Platform-Custom-* HTTP headers, prefix-stripped and lowercased)
    custom_headers: Optional[Dict[str, str]] = Field(
        default=None, description="Caller-provided custom headers"
    )


class InvokeResponse(BaseModel):
    """Response from invoking the agent (compatible with agent-runtime)."""

    result: Any = Field(default=None, description="The agent's response")
    session_id: Optional[str] = Field(default=None, description="Session ID")
    thread_id: Optional[str] = Field(default=None, description="Thread ID used")
    user_id: Optional[str] = Field(default=None, description="User ID used")
    # Runner-specific fields (for async mode and tracking)
    execution_id: Optional[str] = Field(default=None, description="Unique execution identifier")
    status: Optional[str] = Field(default=None, description="Execution status")
    error: Optional[str] = Field(default=None, description="Error message if failed")


# =============================================================================
# Execute Request (OE → AER)
# =============================================================================


class ExecuteRequest(BaseModel):
    """Request to execute an agent in AER."""

    execution_id: str = Field(..., description="Unique execution identifier")
    message: str = Field(default="", description="User message")
    platform_api_url: str = Field(..., description="URL of the OE for callbacks")
    resume: bool = Field(default=False, description="Whether this is a resume after SUSPEND")
    resume_from_step: Optional[int] = Field(default=None, description="Step to resume from")
    resume_data: Optional[Dict[str, Any]] = Field(
        default=None, description="Data to inject on resume"
    )
    # Multi-tenant context
    org_id: Optional[str] = Field(
        default=None, description="Organization ID for multi-tenant isolation"
    )
    user_id: Optional[str] = Field(default=None, description="User ID for personalization")
    session_id: Optional[str] = Field(
        default=None, description="Session ID; the AER adapter uses this as the LangGraph thread_id"
    )
    thread_id: Optional[str] = Field(
        default=None,
        description="Deprecated — callers should use session_id. Removal tracked by AP-2194.",
    )
    workspace_id: Optional[str] = Field(
        default=None, description="Workspace identifier for cost tracking"
    )
    project_id: Optional[str] = Field(
        default=None, description="Project ID for project-level scoping"
    )
    root_session_id: Optional[str] = Field(
        default=None, description="Root user-facing session ID for cross-agent trace correlation"
    )
    root_execution_id: Optional[str] = Field(
        default=None, description="Root execution ID for cross-agent trace correlation"
    )
    # Custom headers forwarded from caller (X-Mdb-Agentic-Platform-Custom-* HTTP headers, prefix-stripped and lowercased)
    custom_headers: Optional[Dict[str, str]] = Field(
        default=None, description="Caller-provided custom headers"
    )
    payload: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Opaque caller-provided input forwarded unchanged on every dispatch; payload['message'] fills top-level message when empty",
    )
    metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Opaque executor-provided state from the last SUSPENDED callback, forwarded back on resume",
    )
    # `message` resolution (promote payload["message"] when the top level is
    # empty; reject when both are set) lives in the AER, the only component that
    # unpacks the opaque payload — see runner_shared.server.aer. Keeping it out
    # of a model validator means the conflict surfaces as a clean 400 instead of
    # a 422 that would echo the payload back to the caller and into logs.


# =============================================================================
# Tool Execution (AER → OE → AER/ToolPod)
# =============================================================================


class ToolExecuteRequest(BaseModel):
    """Request to execute a tool (AER → OE for approval)."""

    execution_id: str = Field(..., description="Execution identifier")
    tool_name: str = Field(..., description="Name of the tool to execute")
    arguments: Dict[str, Any] = Field(..., description="Tool arguments")
    step_number: int = Field(..., description="Step number in execution sequence")
    kind: Optional[str] = Field(default=None, description="Explicit observability kind")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Observability metadata")

    def to_start_log(
        self,
        execution: "Execution",
        policy: Optional[Any] = None,
    ) -> "ExecutionLog":
        """
        Convert this request to an ExecutionLog for tool start.

        Args:
            execution: The parent execution context
            policy: Optional ToolConfig for field redaction
        """
        from uuid import uuid4

        from runner_shared.logging import ExecutionLog, ExecutionStatus, redact_fields

        inputs = self.arguments
        if policy and hasattr(policy, "redact_fields") and policy.redact_fields:
            inputs = redact_fields(self.arguments, policy.redact_fields)

        return ExecutionLog(
            id=str(uuid4()),
            execution_id=self.execution_id,
            tool=self.tool_name,
            kind=self.kind,
            status=ExecutionStatus.STARTED,
            timestamp=datetime.now(timezone.utc),
            inputs=inputs,
            step_number=self.step_number,
            policy=policy,
            session_id=execution.session_id,
            user_id=execution.user_id,
            thread_id=execution.thread_id,
            org_id=execution.org_id,
            project_id=execution.project_id,
            workspace_id=execution.workspace_id,
            metadata=self.metadata,
        )

    def to_cached_log(
        self,
        execution: "Execution",
        cached_result: Any,
    ) -> "ExecutionLog":
        """
        Convert this request to an ExecutionLog for cached result.

        Args:
            execution: The parent execution context
            cached_result: The cached result being returned
        """
        from uuid import uuid4

        from runner_shared.logging import ExecutionLog, ExecutionStatus

        return ExecutionLog(
            id=str(uuid4()),
            execution_id=self.execution_id,
            tool=self.tool_name,
            kind=self.kind,
            status=ExecutionStatus.CACHED,
            timestamp=datetime.now(timezone.utc),
            output=cached_result,
            step_number=self.step_number,
            session_id=execution.session_id,
            user_id=execution.user_id,
            thread_id=execution.thread_id,
            org_id=execution.org_id,
            project_id=execution.project_id,
            workspace_id=execution.workspace_id,
            metadata={"replay": True, **self.metadata},
        )


class ElicitationInfo(BaseModel):
    """Authorization details returned when broker consent is required.

    Its presence in a ToolExecuteResponse signals that the user must authorize
    via the provided URL before the tool invocation can proceed.
    """

    elicitation_id: str = Field(..., description="Credential broker elicitation identifier")
    authorization_url: str = Field(
        ...,
        description="URL the user must visit to grant authorization",
    )
    message: str = Field(default="", description="Human-readable authorization guidance")
    created: bool = Field(
        default=False,
        description="Whether this response created a new elicitation",
    )


class GuardrailMeta(BaseModel):
    """Identity of the policy that caused a guardrail block or require_review halt."""

    guardrail_id: str = Field(..., description="ID of the policy that caused the halt")
    guardrail_category: str = Field(..., description="Category of the policy that caused the halt")


class ToolExecuteResponse(BaseModel):
    """Response from OE for tool execution request."""

    proceed: bool = Field(..., description="Whether to proceed with execution")
    cached_result: Optional[Any] = Field(default=None, description="Cached result if replaying")
    route_to: Optional[str] = Field(
        default=None, description="URL to route to (callback or OE-owned stream relay)"
    )
    reason: Optional[str] = Field(default=None, description="Reason if blocked")
    elicitation: Optional[ElicitationInfo] = Field(
        default=None,
        description="Authorization elicitation details when broker consent is required",
    )
    status: Optional[str] = Field(
        default=None,
        description="Final status when OE directly executes the intercepted tool",
    )
    result: Optional[Any] = Field(default=None, description="Final result from OE-owned execution")
    error: Optional[str] = Field(default=None, description="Execution error message")
    retryable: bool = Field(default=False, description="Whether retry is safe")
    latest_step_number: Optional[int] = Field(
        default=None,
        description="Highest step number observed during nested execution",
    )
    from_cache: bool = Field(default=False, description="Whether replay cache answered")
    duration_ms: Optional[float] = Field(default=None, description="Execution duration")
    pod_name: Optional[str] = Field(default=None, description="Execution pod name")
    guardrail_meta: Optional[GuardrailMeta] = Field(
        default=None, description="Policy identity when a guardrail halt fires"
    )

    @model_validator(mode="before")
    @classmethod
    def _assemble_guardrail_meta(cls, data: Any) -> Any:
        """Assemble guardrail_meta from the flat guardrail_id/guardrail_category fields
        that the OE wire format sends, so callers work with a single structured object."""
        if isinstance(data, dict):
            gid = data.get("guardrail_id")
            gcat = data.get("guardrail_category")
            if gid and gcat and data.get("guardrail_meta") is None:
                data["guardrail_meta"] = {"guardrail_id": gid, "guardrail_category": gcat}
        return data


class ToolResultRequest(BaseModel):
    """Report tool execution result (AER → OE)."""

    execution_id: str = Field(..., description="Execution identifier")
    step_number: int = Field(..., description="Step number")
    tool_name: str = Field(..., description="Tool name")
    status: str = Field(
        ..., description="Execution status: success, error, blocked, cached, suspend"
    )
    result: Optional[Any] = Field(default=None, description="Tool result if successful")
    error: Optional[str] = Field(default=None, description="Error message if failed")
    duration_ms: float = Field(..., description="Execution duration in milliseconds")
    pod_name: Optional[str] = Field(
        default=None, description="Hostname/pod name where tool was executed"
    )
    # Token usage fields (populated for invoke_llm calls)
    prompt_tokens: Optional[int] = Field(default=None, description="Prompt/input tokens used")
    completion_tokens: Optional[int] = Field(
        default=None, description="Completion/output tokens used"
    )
    total_tokens: Optional[int] = Field(default=None, description="Total tokens used")
    model: Optional[str] = Field(default=None, description="LLM model name")
    workspace_id: Optional[str] = Field(default=None, description="Workspace identifier")
    kind: Optional[str] = Field(default=None, description="Explicit observability kind")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Observability metadata")

    def to_log(self, execution: Optional["Execution"] = None) -> "ExecutionLog":
        """
        Convert this request to an ExecutionLog for tool result.

        Args:
            execution: The parent execution context (optional)
        """
        from uuid import uuid4

        from runner_shared.logging import ExecutionLog, ExecutionStatus

        exec_status = (
            ExecutionStatus.SUCCESS
            if self.status == "success"
            else ExecutionStatus.SUSPENDED
            if self.status == "suspend"
            else ExecutionStatus.ERROR
            if self.status == "error"
            else ExecutionStatus.BLOCKED
            if self.status == "blocked"
            else ExecutionStatus.CACHED
            if self.status == "cached"
            else ExecutionStatus.ERROR
        )

        return ExecutionLog(
            id=str(uuid4()),
            execution_id=self.execution_id,
            tool=self.tool_name,
            kind=self.kind,
            status=exec_status,
            timestamp=datetime.now(timezone.utc),
            output=self.result,
            error=self.error,
            duration_ms=self.duration_ms,
            step_number=self.step_number,
            session_id=execution.session_id if execution else None,
            user_id=execution.user_id if execution else None,
            thread_id=execution.thread_id if execution else None,
            org_id=execution.org_id if execution else None,
            project_id=execution.project_id if execution else None,
            pod_name=self.pod_name,
            prompt_tokens=self.prompt_tokens,
            completion_tokens=self.completion_tokens,
            total_tokens=self.total_tokens,
            model=self.model,
            workspace_id=self.workspace_id or (execution.workspace_id if execution else None),
            metadata=self.metadata,
        )


# =============================================================================
# Tool Pod Execution (OE → ToolPod)
# =============================================================================


class ToolAuthorization(BaseModel):
    """Delegated credential injected by OE for tool execution."""

    token: str = Field(..., repr=False, description="Bearer token for third-party API access")
    expires_at: Optional[int] = Field(
        default=None,
        description="Token expiry as Unix seconds",
        json_schema_extra={"format": "int64"},
    )


class ToolPodExecuteRequest(BaseModel):
    """Request to execute a tool in a Tool Pod."""

    execution_id: str = Field(..., description="Execution identifier")
    tool_name: str = Field(..., description="Name of the tool")
    arguments: Dict[str, Any] = Field(..., description="Tool arguments")
    tool_call_id: Optional[str] = Field(default=None, description="Tool call ID from LLM")
    session_id: str = Field(
        ...,
        min_length=1,
        description=(
            "Session ID for memory context. For LangGraph applications, this is the "
            "LangGraph thread ID."
        ),
    )
    user_id: Optional[str] = Field(default=None, description="User ID for context")
    oe_url: Optional[str] = Field(
        default=None, description="OE callback URL for memory and other operations"
    )
    authorization: Optional[ToolAuthorization] = Field(
        default=None, description="Delegated credential injected by OE via credential broker"
    )
    custom_headers: Optional[Dict[str, str]] = Field(
        default=None, description="Caller-provided custom headers"
    )
    payload: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Opaque caller-provided invocation payload, forwarded so tools can read it via get_current_payload()",
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Tool execution metadata forwarded by OE. Recognized keys: "
            "mcp_server (str), mcp_tool (str)."
        ),
        json_schema_extra={"default": {}},
    )


class ToolPodExecuteResponse(BaseModel):
    """Response from Tool Pod execution."""

    status: str = Field(..., description="Execution status: success, error")
    result: Optional[Any] = Field(default=None, description="Tool result")
    error: Optional[str] = Field(default=None, description="Error message if failed")
    pod_name: Optional[str] = Field(
        default=None, description="Hostname/pod name where tool was executed"
    )
    kind: Optional[str] = Field(default=None, description="Explicit observability kind")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Observability metadata")


# =============================================================================
# Guardrails Runtime Check (OE → ToolPod)
# =============================================================================


class GuardrailRuntimeStage(str, Enum):
    """Runtime stage where OE is asking the Tool Pod to evaluate guardrails."""

    LLM_INPUT = "llm_input"
    LLM_OUTPUT = "llm_output"
    TOOL_INPUT = "tool_input"
    TOOL_OUTPUT = "tool_output"


class GuardrailCheckDecision(str, Enum):
    """Decision returned by the Tool Pod guardrails evaluator."""

    ALLOW = "allow"
    BLOCK = "block"
    MODIFY = "modify"
    REQUIRE_REVIEW = "require_review"
    LOG_ONLY = "log_only"


class GuardrailRuntimePolicy(BaseModel):
    """OE-selected guardrail policy sent to the Tool Pod for evaluation."""

    id: str = Field(..., description="Guardrail policy identifier")
    type: str = Field(..., description="Guardrail policy type")
    status: str = Field(default="active", description="Guardrail policy status")
    action: str = Field(..., description="Action requested when the policy triggers")
    stage_filter: List[str] = Field(
        default_factory=list,
        description="Runtime stages this policy applies to; empty means all stages",
    )
    config: Dict[str, JsonValue] = Field(
        default_factory=dict,
        description="Evaluator-specific policy configuration",
    )

    def applies_to_stage(self, stage: GuardrailRuntimeStage) -> bool:
        if self.status.strip().lower() != "active":
            return False
        if not self.stage_filter:
            return True

        return any(value.strip().lower() == stage.value for value in self.stage_filter)

    def check_decision(self) -> GuardrailCheckDecision:
        action = self.action.strip().lower()
        if action in {"modify", "transform", "fix"}:
            return GuardrailCheckDecision.MODIFY
        if action in {"noop", "no_op", "warn", "log_only"}:
            return GuardrailCheckDecision.LOG_ONLY
        if action == "require_review":
            return GuardrailCheckDecision.REQUIRE_REVIEW
        if action in {"block", "exception"}:
            return GuardrailCheckDecision.BLOCK

        on_fail = self.config.get("on_fail")
        if isinstance(on_fail, str):
            normalized_on_fail = on_fail.strip().lower()
            if normalized_on_fail == "fix":
                return GuardrailCheckDecision.MODIFY
            if normalized_on_fail in {"noop", "warn", "log_only"}:
                return GuardrailCheckDecision.LOG_ONLY
            if normalized_on_fail in {"block", "exception"}:
                return GuardrailCheckDecision.BLOCK

        return GuardrailCheckDecision.ALLOW


class GuardrailCheckInput(BaseModel):
    """Runtime content and metadata to evaluate."""

    text: str = Field(..., description="Text content to evaluate")
    metadata: Dict[str, JsonValue] = Field(
        default_factory=dict,
        description="Runtime metadata such as model, tool name, or source",
    )


class GuardrailCheckContext(BaseModel):
    """Execution context for a guardrail check."""

    org_id: str = Field(..., description="Organization ID")
    project_id: str = Field(..., description="Project ID")
    workspace_id: Optional[str] = Field(default=None, description="Workspace ID")
    session_id: Optional[str] = Field(default=None, description="Session ID")
    user_id: Optional[str] = Field(default=None, description="User ID")


class GuardrailCheckRequest(BaseModel):
    """Request from OE to Tool Pod to evaluate selected guardrail policies."""

    execution_id: str = Field(..., description="Execution identifier")
    stage: GuardrailRuntimeStage = Field(..., description="Runtime stage being evaluated")
    input: GuardrailCheckInput = Field(..., description="Content to evaluate")
    context: GuardrailCheckContext = Field(..., description="Execution context")
    policies: List[GuardrailRuntimePolicy] = Field(
        default_factory=list,
        description="OE-selected policies to evaluate",
    )


class GuardrailCheckEvidence(BaseModel):
    """Evidence explaining why a guardrail policy triggered."""

    policy_id: str = Field(..., description="Triggered policy identifier")
    message: str = Field(default="", description="Human-readable evidence summary")
    metadata: Dict[str, JsonValue] = Field(
        default_factory=dict,
        description="Evaluator-specific evidence metadata",
    )


class GuardrailCheckResponse(BaseModel):
    """Decision returned by the Tool Pod guardrails evaluator."""

    decision: GuardrailCheckDecision = Field(..., description="Guardrails decision")
    allowed: bool = Field(..., description="Whether execution may continue")
    transformed_text: Optional[str] = Field(
        default=None,
        description="Modified text when decision is modify, or original text for allow/no-op",
    )
    triggered_policy_ids: List[str] = Field(
        default_factory=list,
        description="Policy IDs that triggered",
    )
    evidence: List[GuardrailCheckEvidence] = Field(
        default_factory=list,
        description="Policy trigger evidence",
    )
    reason: Optional[str] = Field(default=None, description="Decision reason")
    metadata: Dict[str, JsonValue] = Field(
        default_factory=dict,
        description="Evaluator-specific response metadata",
    )


# =============================================================================
# LLM Pod Execution (AER → ToolPod)
# =============================================================================


class InvokeLLMRequestArguments(BaseModel):
    """Typed invoke_llm arguments forwarded through OE and tool pods."""

    model: str = Field(..., description="Model name (e.g. 'gpt-4o-mini', 'gemini-2.5-flash')")
    messages: List[Message] = Field(..., description="Conversation in sdk-core Message wire format")
    llm_id: str = Field(
        default="__default__",
        description="Stable identifier for the LLM instance registered via app.llm(llm_id=...); "
        "the tool pod resolves this id against its named-LLM registry. "
        "Unnamed app.llm() calls register under the sentinel id '__default__'. "
        "Defaults to '__default__' for backward compatibility with callers that omit this field.",
    )
    stop_sequences: Optional[List[str]] = Field(
        default=None,
        validation_alias=AliasChoices("stop_sequences", "stop"),
        serialization_alias="stop",
        description="Stop sequences forwarded to the underlying LLM provider",
    )
    tools: Optional[List[LLMToolSchema]] = Field(
        default=None, description="Serialized tool schemas for bind_tools"
    )
    options: Optional[LLMInvocationOptions] = Field(
        default=None,
        description="Explicit provider/model invocation options (for example max_tokens)",
    )
    stream: bool = Field(
        default=False,
        description="Whether OE should approve and route a real streaming invoke_llm call",
    )

    @model_validator(mode="before")
    @classmethod
    def _normalize_options_alias(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value
        if "options" in value or "kwargs" not in value:
            return value
        payload = dict(value)
        payload["options"] = payload.pop("kwargs")
        return payload


class LLMPodInvokeRequest(BaseModel):
    """Request to invoke LLM on a tool executor pod."""

    execution_id: str = Field(..., description="Execution identifier")
    arguments: InvokeLLMRequestArguments = Field(..., description="Typed invoke_llm arguments")

    @model_validator(mode="before")
    @classmethod
    def _normalize_flat_payload(cls, value: Any) -> Any:
        if not isinstance(value, dict) or "arguments" in value:
            return value
        payload = dict(value)
        if "execution_id" not in payload:
            return value
        execution_id = payload.pop("execution_id")
        return {"execution_id": execution_id, "arguments": payload}


class LLMResult(BaseModel):
    """Normalized result from an LLM invocation.

    Provides a consistent Pydantic shape for LLM responses regardless of the
    underlying provider (OpenAI, Gemini, Anthropic, etc.).
    """

    content: str = Field(default="", description="Generated text content")
    tool_calls: List[LLMToolCall] = Field(
        default_factory=list, description="Tool calls requested by the model"
    )
    usage: Optional[LLMTokenUsage] = Field(
        default=None, description="Token usage (input_tokens, output_tokens, total_tokens)"
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict, description="Additional response metadata"
    )
    id: Optional[str] = Field(default=None, description="Provider response identifier")
    name: Optional[str] = Field(default=None, description="Provider response name")
    additional_kwargs: Optional[Dict[str, JsonValue]] = Field(
        default=None, description="LangChain additional message kwargs"
    )
    response_metadata: Optional[Dict[str, JsonValue]] = Field(
        default=None, description="LangChain response metadata"
    )

    @classmethod
    def from_response(cls, response: Any) -> "LLMResult":
        """Extract a normalized result from a LangChain LLM response.

        Handles AIMessage, BaseMessage, and arbitrary objects by falling back
        to str() for content extraction.
        """
        if isinstance(response, LLMResponse):
            return cls(
                content=response.content,
                tool_calls=response.tool_calls or [],
                usage=response.usage,
                metadata=dict(response.metadata),
                id=response.id,
                name=response.name,
                additional_kwargs=response.additional_kwargs,
                response_metadata=response.response_metadata,
            )

        content = response.content if hasattr(response, "content") else str(response)
        tool_calls = getattr(response, "tool_calls", [])
        usage = cls.extract_usage(response)
        metadata = getattr(response, "metadata", None)
        response_metadata = getattr(response, "response_metadata", None)
        additional_kwargs = getattr(response, "additional_kwargs", None)
        response_id = getattr(response, "id", None)
        response_name = getattr(response, "name", None)

        return cls(
            content=content,
            tool_calls=tool_calls,
            usage=usage,
            metadata=metadata if isinstance(metadata, dict) else {},
            id=response_id if isinstance(response_id, str) else None,
            name=response_name if isinstance(response_name, str) else None,
            additional_kwargs=(additional_kwargs if isinstance(additional_kwargs, dict) else None),
            response_metadata=(response_metadata if isinstance(response_metadata, dict) else None),
        )

    @staticmethod
    def extract_usage(response: Any) -> Optional[LLMTokenUsage]:
        """Extract token usage metadata from a LangChain response or chunk."""
        if isinstance(response, LLMResponse) and response.usage is not None:
            return response.usage

        usage_meta = getattr(response, "usage_metadata", None)
        if usage_meta and isinstance(usage_meta, dict):
            return LLMTokenUsage.model_validate(usage_meta)

        response_metadata = getattr(response, "response_metadata", None) or {}
        if isinstance(response_metadata, dict):
            for key in ("usage", "token_usage"):
                usage = response_metadata.get(key)
                if isinstance(usage, dict):
                    return LLMTokenUsage.model_validate(usage)

        metadata = getattr(response, "metadata", None)
        if isinstance(metadata, dict) and isinstance(metadata.get("usage"), dict):
            return LLMTokenUsage.model_validate(metadata["usage"])
        return None

    def to_response(self) -> LLMResponse:
        """Convert the normalized runner result to sdk-core's response shape."""
        metadata = dict(self.metadata)
        if self.usage is not None and not metadata:
            metadata = self.usage.model_dump(exclude_none=True)
        return LLMResponse(
            content=self.content,
            tool_calls=self.tool_calls or None,
            metadata=metadata,
            usage=self.usage,
            id=self.id,
            name=self.name,
            additional_kwargs=self.additional_kwargs,
            response_metadata=self.response_metadata,
        )


class LLMPodInvokeResponse(BaseModel):
    """Response from LLM invocation on a tool executor pod."""

    status: str = Field(..., description="Execution status: success, error")
    result: Optional[LLMResponse] = Field(
        default=None, description="LLM result with content, tool_calls, and usage"
    )
    error: Optional[str] = Field(default=None, description="Error message if failed")
    pod_name: str = Field(..., description="Hostname/pod name where LLM was executed")
    duration_ms: float = Field(..., description="Execution duration in milliseconds")
    usage: Optional[LLMTokenUsage] = Field(
        default=None, description="Token usage (input_tokens, output_tokens, total_tokens)"
    )

    @model_validator(mode="after")
    def _sync_usage_with_result(self) -> "LLMPodInvokeResponse":
        if self.result is not None and self.result.usage is None and self.usage is not None:
            self.result.usage = self.usage
        if self.usage is None and self.result is not None:
            self.usage = self.result.usage
        return self


class LLMPodStreamEvent(BaseModel):
    """SSE event emitted by a tool pod during invoke_llm streaming."""

    content: Optional[str] = Field(default=None, description="Generated text delta")
    tool_call_chunks: Optional[List[ToolCallChunk]] = Field(
        default=None, description="Partial tool-call deltas"
    )
    tool_calls: Optional[List[LLMToolCall]] = Field(
        default=None, description="Complete tool calls for compatibility with older stream senders"
    )
    id: Optional[str] = Field(default=None, description="Provider message identifier")
    name: Optional[str] = Field(default=None, description="Provider message name")
    additional_kwargs: Optional[Dict[str, JsonValue]] = Field(
        default=None, description="LangChain additional message kwargs"
    )
    response_metadata: Optional[Dict[str, JsonValue]] = Field(
        default=None, description="LangChain response metadata"
    )
    done: Optional[bool] = Field(default=None, description="Whether the stream is complete")
    error: Optional[str] = Field(default=None, description="Error message if streaming failed")
    pod_name: Optional[str] = Field(default=None, description="Hostname/pod name")
    duration_ms: Optional[float] = Field(default=None, description="Stream duration")
    usage: Optional[LLMTokenUsage] = Field(default=None, description="Final token usage")


# =============================================================================
# Executor Callback (AER → OE)
# =============================================================================


class ExecutorCallbackRequest(BaseModel):
    """Callback from AER to OE when execution completes or suspends."""

    execution_id: str = Field(..., description="Execution identifier")
    status: str = Field(..., description="Status: COMPLETED, SUSPENDED, ERROR")
    result: Optional[Any] = Field(default=None, description="Final result if completed")
    error: Optional[str] = Field(default=None, description="Error message if failed")
    suspend_reason: Optional[str] = Field(default=None, description="Reason for suspension")
    suspend_context: Optional[Dict[str, Any]] = Field(
        default=None, description="Context for resume"
    )
    state_snapshot: Optional[Dict[str, Any]] = Field(
        default=None, description="Serialized graph state"
    )
    metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Opaque executor-provided state; stored by OE on SUSPENDED, cleared on terminal status",
    )


# =============================================================================
# Resume (Client → OE)
# =============================================================================


class HumanReviewData(BaseModel):
    """Data provided by human reviewer when resuming a suspended execution."""

    decision: str = Field(
        ...,
        description="Review decision: 'approved', 'rejected', or custom value",
        examples=["approved", "rejected", "approved_with_conditions"],
    )
    reviewer_notes: Optional[str] = Field(
        default=None,
        description="Optional notes from the reviewer",
    )


class AgentResumeRequest(BaseModel):
    """Request to resume a suspended execution."""

    human_review: HumanReviewData = Field(
        ...,
        description="Human review decision data (for human-in-the-loop resume)",
    )
    custom_headers: Optional[Dict[str, str]] = Field(
        default=None, description="Caller-provided custom headers"
    )


class AgentResumeResponse(BaseModel):
    """Response from resuming an execution."""

    execution_id: str = Field(..., description="Execution identifier")
    status: str = Field(..., description="Execution status")


# =============================================================================
# Execution Status Query
# =============================================================================


class ExecutionStatusResponse(BaseModel):
    """Response for execution status query."""

    execution_id: str = Field(..., description="Execution identifier")
    status: ExecutionStatus = Field(..., description="Current status")
    result: Optional[Any] = Field(default=None, description="Result if completed")
    error: Optional[str] = Field(default=None, description="Error if failed")
    suspend_reason: Optional[str] = Field(default=None, description="Reason if suspended")
    suspend_context: Optional[Dict[str, Any]] = Field(
        default=None, description="Context if suspended"
    )
    created_at: datetime = Field(..., description="Creation timestamp")
    updated_at: datetime = Field(..., description="Last update timestamp")


# =============================================================================
# Database Models
# =============================================================================


class Execution(BaseModel):
    """Execution record stored in TenantDB."""

    id: str = Field(..., description="Unique execution identifier")
    status: ExecutionStatus = Field(..., description="Current status")
    message: str = Field(..., description="Original user message")
    result: Optional[Any] = Field(default=None, description="Final result")
    error: Optional[str] = Field(default=None, description="Error message")
    suspend_reason: Optional[str] = Field(default=None, description="Reason for suspension")
    suspend_context: Optional[Dict[str, Any]] = Field(
        default=None, description="Context for resume"
    )
    # Checkpoint tracking for proper resume
    checkpoint_id: Optional[str] = Field(default=None, description="LangGraph checkpoint ID")
    state_snapshot: Optional[Dict[str, Any]] = Field(default=None, description="Serialized state")
    # Multi-tenant context
    session_id: Optional[str] = Field(default=None, description="Session ID for trace correlation")
    org_id: Optional[str] = Field(
        default=None, description="Organization ID for multi-tenant isolation"
    )
    user_id: Optional[str] = Field(default=None, description="User ID for personalization")
    thread_id: Optional[str] = Field(
        default=None, description="Thread ID for conversation continuity"
    )
    workspace_id: Optional[str] = Field(
        default=None, description="Workspace identifier for cost tracking"
    )
    project_id: Optional[str] = Field(
        default=None, description="Project ID for project-level scoping"
    )
    # Per-agent AER routing
    aer_url: Optional[str] = Field(
        default=None, description="AER HTTP endpoint for this agent; overrides default AER_URL"
    )
    tool_url: Optional[str] = Field(
        default=None, description="Tool HTTP endpoint for this agent; overrides default TOOL_URL"
    )
    # Timestamps
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    def to_persistence_doc(self, updated_at: Optional[datetime] = None) -> Dict[str, Any]:
        """
        Convert to a document for MongoDB persistence.

        Args:
            updated_at: Optional timestamp override (defaults to now)

        Returns:
            Dict suitable for MongoDB upsert
        """
        return {
            "execution_id": self.id,
            "status": self.status.value,
            "message": self.message,
            "session_id": self.session_id,
            "user_id": self.user_id,
            "org_id": self.org_id,
            "workspace_id": self.workspace_id,
            "project_id": self.project_id,
            "result": self.result,
            "error": self.error,
            "suspend_reason": self.suspend_reason,
            "suspend_context": self.suspend_context,
            "checkpoint_id": self.checkpoint_id,
            "state_snapshot": self.state_snapshot,
            "updated_at": updated_at or datetime.now(timezone.utc),
        }

    @staticmethod
    def _ensure_utc(dt: Optional[datetime]) -> Optional[datetime]:
        """Normalize a datetime to UTC-aware.

        PyMongo returns naive datetimes by default. The OE uses
        ``datetime.now(timezone.utc)`` everywhere, so mixing aware and
        naive values causes ``TypeError`` on comparison.  This helper
        stamps naive datetimes as UTC (which is what MongoDB stores).
        """
        if dt is None:
            return None
        if dt.tzinfo is None:
            return dt.replace(tzinfo=timezone.utc)
        return dt

    @classmethod
    def from_persistence_doc(cls, doc: Dict[str, Any]) -> "Execution":
        """
        Rehydrate an Execution from a MongoDB document.

        Uses .get() with defaults for all Optional fields so documents
        created before new fields were added still deserialize safely.
        """
        now = datetime.now(timezone.utc)
        return cls(
            id=doc["execution_id"],
            status=ExecutionStatus(doc["status"]),
            message=doc.get("message", ""),
            result=doc.get("result"),
            error=doc.get("error"),
            suspend_reason=doc.get("suspend_reason"),
            suspend_context=doc.get("suspend_context"),
            checkpoint_id=doc.get("checkpoint_id"),
            state_snapshot=doc.get("state_snapshot"),
            session_id=doc.get("session_id"),
            org_id=doc.get("org_id"),
            user_id=doc.get("user_id"),
            thread_id=doc.get("thread_id"),
            workspace_id=doc.get("workspace_id"),
            project_id=doc.get("project_id"),
            created_at=cls._ensure_utc(doc.get("created_at"))
            or cls._ensure_utc(doc.get("updated_at"))
            or now,
            updated_at=cls._ensure_utc(doc.get("updated_at")) or now,
        )


class ExecutionStep(BaseModel):
    """Execution step record stored in TenantDB."""

    id: str = Field(..., description="Unique step identifier")
    execution_id: str = Field(..., description="Parent execution ID")
    step_number: int = Field(..., description="Step sequence number")
    tool_name: str = Field(..., description="Tool or operation name")
    arguments: Dict[str, Any] = Field(..., description="Arguments passed")
    status: str = Field(..., description="Step status: pending, success, error")
    result: Optional[Any] = Field(default=None, description="Step result")
    error: Optional[str] = Field(default=None, description="Error message")
    duration_ms: Optional[float] = Field(default=None, description="Execution duration")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @classmethod
    def from_log_doc(cls, doc: Dict[str, Any]) -> "ExecutionStep":
        """
        Reconstruct an ExecutionStep from an execution_logs MongoDB document.

        The execution_logs collection stores tool start/result events with
        fields: execution_id, step_number, tool, inputs, status, output,
        error, duration_ms, timestamp. This method maps those fields back
        to the ExecutionStep model for step cache rehydration after OE restart.
        """
        from uuid import uuid4

        return cls(
            id=doc.get("id", str(uuid4())),
            execution_id=doc["execution_id"],
            step_number=doc.get("step_number", 0),
            tool_name=doc.get("tool", ""),
            arguments=doc.get("inputs") or {},
            status=doc.get("status", "error"),
            result=doc.get("output"),
            error=doc.get("error"),
            duration_ms=doc.get("duration_ms"),
            timestamp=Execution._ensure_utc(doc.get("timestamp")) or datetime.now(timezone.utc),
        )


# =============================================================================
# Health Check
# =============================================================================


class HealthStatus(str, Enum):
    """Health status of a component."""

    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    DEGRADED = "degraded"


class HealthResponse(BaseModel):
    """Health check response."""

    status: HealthStatus = Field(..., description="Health status")
    component: str = Field(..., description="Component name")
    mode: str = Field(..., description="Runtime mode")
    version: str = Field(default="1.0.0", description="Component version")
    details: Dict[str, Any] = Field(default_factory=dict, description="Additional details")


# =============================================================================
# Tool Definition
# =============================================================================


class ToolDefinition(BaseModel):
    """Definition of a registered tool."""

    name: str = Field(..., description="Tool name")
    description: str = Field(default="", description="Tool description")
    is_local: bool = Field(default=True, description="Whether tool runs locally")
    parameters: Optional[Dict[str, Any]] = Field(
        default=None, description="JSON schema for parameters"
    )


# =============================================================================
# AER Route Response Models
# =============================================================================


class AERExecuteResponse(BaseModel):
    """Response from AER /execute endpoint.

    Returned on both normal completion and HITL suspension.
    """

    status: str = Field(
        ...,
        description="Execution outcome: 'completed' or 'suspended'",
        examples=["completed", "suspended"],
    )
    result: Optional[str] = Field(
        default=None,
        description="Final agent response text (present when status is 'completed')",
    )
    suspend_reason: Optional[str] = Field(
        default=None,
        description="Why the agent suspended (present when status is 'suspended')",
    )


class ToolsListResponse(BaseModel):
    """Response from /tools endpoint listing registered tools."""

    tools: List[Dict[str, Any]] = Field(
        ..., description="Registered tool definitions with name and metadata"
    )
    count: Optional[int] = Field(
        default=None, description="Number of registered tools (included by Tool Pod)"
    )


# =============================================================================
# Streaming
# =============================================================================


class StreamChunk(BaseModel):
    """
    A chunk of streaming response from the agent.

    Used for real-time streaming of agent responses via SSE or gRPC.
    """

    chunk_type: str = Field(
        ...,
        description=(
            "Chunk type string. AER-emitted values are defined in "
            "runner_shared.server.chunk_types ('text', 'subagent_start', "
            "'subagent_end', 'done', 'error'). OE may inject additional "
            "infrastructure types (e.g. 'metadata', 'tool_call', 'tool_result') "
            "before forwarding to clients."
        ),
    )
    content: str = Field(default="", description="Content of the chunk")
    metadata: Dict[str, JsonValue] = Field(default_factory=dict, description="Optional metadata")
    error: Optional[str] = Field(default=None, description="Error message if chunk_type is 'error'")

    # Tool-specific fields
    tool_name: Optional[str] = Field(
        default=None, description="Tool name for tool_call/tool_result chunks"
    )
    tool_call_id: Optional[str] = Field(default=None, description="Tool call ID")

    # Execution context
    execution_id: Optional[str] = Field(default=None, description="Execution ID")
    step_number: Optional[int] = Field(default=None, description="Step number in execution")


class AgentStartStreamRequest(BaseModel):
    """Request to start an agent execution with streaming response."""

    message: str = Field(..., description="User message")
    thread_id: Optional[str] = Field(
        default=None, description="Thread ID for conversation continuity"
    )
    org_id: Optional[str] = Field(
        default=None, description="Organization ID for multi-tenant isolation"
    )
    user_id: Optional[str] = Field(default=None, description="User ID for personalization")


# =============================================================================
# Node Execution (AER → OE)
# =============================================================================


# =============================================================================
# Query Response Models — Execution Logs & Node Executions (AP-589)
# =============================================================================


class ExecutionLogsQueryResponse(BaseModel):
    """Response for execution logs query (used by API Gateway proxy)."""

    logs: List[Dict[str, Any]] = Field(default_factory=list, description="Execution log documents")
    count: int = Field(0, description="Number of logs returned")


class NodeExecutionsQueryResponse(BaseModel):
    """Response for node executions query (used by API Gateway proxy)."""

    executions: List[Dict[str, Any]] = Field(
        default_factory=list, description="Node execution documents"
    )
    count: int = Field(0, description="Number of executions returned")


# Cost Dashboard Query Response Models (AP-641)
# =============================================================================


class CostSummary(BaseModel):
    """Aggregate cost metrics for the requested period."""

    total_cost_usd: float = 0.0
    total_tokens: int = 0
    total_prompt_tokens: int = 0
    total_completion_tokens: int = 0
    total_llm_calls: int = 0
    unpriced_llm_calls: int = 0


class CostByWorkspace(BaseModel):
    """Cost breakdown for a single workspace."""

    workspace_id: str
    total_cost_usd: float = 0.0
    total_tokens: int = 0
    call_count: int = 0
    percentage: float = 0.0


class CostByModel(BaseModel):
    """Cost breakdown for a single model."""

    model: str
    total_cost_usd: float = 0.0
    total_tokens: int = 0
    call_count: int = 0
    percentage: float = 0.0


class DailyCostEntry(BaseModel):
    """Cost data for a single day."""

    date: str
    total_cost_usd: float = 0.0
    total_tokens: int = 0
    call_count: int = 0


class CostDashboardResponse(BaseModel):
    """Response for cost dashboard aggregation (used by API Gateway proxy)."""

    summary: CostSummary = Field(default_factory=CostSummary)
    by_workspace: List[CostByWorkspace] = Field(default_factory=list)
    by_model: List[CostByModel] = Field(default_factory=list)
    daily_trend: List[DailyCostEntry] = Field(default_factory=list)


# =============================================================================
# Executions Query Response Models (AP-641)
# =============================================================================


class ExecutionDocument(BaseModel):
    """An execution document as stored in the platform database."""

    execution_id: str
    status: str = ""
    message: str = ""
    session_id: str = ""
    user_id: str = ""
    thread_id: str = ""
    org_id: str = ""
    project_id: Optional[str] = ""
    workspace_id: Optional[str] = ""
    result: Optional[Any] = None
    error: Optional[str] = None
    suspend_reason: Optional[str] = None
    suspend_context: Optional[Dict[str, Any]] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class ExecutionsListQueryResponse(BaseModel):
    """Response for executions list query (used by API Gateway proxy)."""

    success: bool = True
    executions: List[ExecutionDocument] = Field(default_factory=list)
    count: int = 0


class ExecutionDetailQueryResponse(BaseModel):
    """Response for single execution detail query (used by API Gateway proxy)."""

    success: bool = True
    execution: Optional[ExecutionDocument] = None
    error: Optional[str] = None


# =============================================================================
# Node Execution (AER → OE)
# =============================================================================


class NodeExecutionRequest(BaseModel):
    """Report node execution event (AER → OE for logging)."""

    execution_id: str = Field(..., description="Execution identifier")
    node_name: str = Field(..., description="Name of the LangGraph node")
    status: str = Field(..., description="Node status: started, success, error, suspend")
    timestamp: datetime = Field(..., description="Event timestamp")
    run_id: str = Field(..., description="LangChain run ID for this node execution")
    parent_run_id: Optional[str] = Field(default=None, description="Parent run ID if nested")
    session_id: Optional[str] = Field(default=None, description="Session ID for correlation")
    thread_id: Optional[str] = Field(
        default=None, description="Thread ID for conversation continuity"
    )
    user_id: Optional[str] = Field(default=None, description="User ID for personalization")
    inputs: Optional[Dict[str, Any]] = Field(
        default=None, description="Node inputs (for started status)"
    )
    outputs: Optional[Dict[str, Any]] = Field(
        default=None, description="Node outputs (for success status)"
    )
    error: Optional[str] = Field(default=None, description="Error message (for error status)")
    duration_ms: Optional[float] = Field(
        default=None, description="Execution duration in milliseconds"
    )
    org_id: Optional[str] = Field(default=None, description="Organization ID")
    project_id: Optional[str] = Field(default=None, description="Project ID")

    def to_log(self) -> "NodeExecutionLog":
        """Convert this request to a NodeExecutionLog for persistence."""
        from uuid import uuid4

        from runner_shared.logging import NodeExecutionLog, NodeExecutionStatus

        node_status = (
            NodeExecutionStatus.STARTED
            if self.status == "started"
            else NodeExecutionStatus.SUCCESS
            if self.status == "success"
            else NodeExecutionStatus.SUSPENDED
            if self.status == "suspend"
            else NodeExecutionStatus.ERROR
        )

        return NodeExecutionLog(
            id=str(uuid4()),
            execution_id=self.execution_id,
            node=self.node_name,
            status=node_status,
            timestamp=self.timestamp,
            run_id=self.run_id,
            parent_run_id=self.parent_run_id,
            inputs=self.inputs,
            outputs=self.outputs,
            error=self.error,
            duration_ms=self.duration_ms,
            session_id=self.session_id,
            user_id=self.user_id,
            thread_id=self.thread_id,
            org_id=self.org_id,
            project_id=self.project_id,
        )
