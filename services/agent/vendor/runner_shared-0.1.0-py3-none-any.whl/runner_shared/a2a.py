"""
Agent-to-Agent (A2A) client for the Magenta platform.

Provides methods for agent discovery and invocation through the
Orchestration Engine's REST API.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import httpx

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class AgentSkill:
    """A skill advertised by an agent."""

    name: str
    description: str
    example_input: Optional[str] = None
    example_output: Optional[str] = None


@dataclass(frozen=True)
class DiscoveredAgent:
    """An agent visible to the caller after policy filtering."""

    agent_id: str
    name: str
    description: str
    project_id: str
    skills: List[AgentSkill] = field(default_factory=list)
    capabilities: List[str] = field(default_factory=list)
    input_modes: List[str] = field(default_factory=list)
    output_modes: List[str] = field(default_factory=list)


@dataclass(frozen=True)
class AgentResponse:
    """Response from an A2A invoke_agent call."""

    status: str
    result: Optional[str] = None
    error: Optional[str] = None
    execution_id: str = ""


class AgentToAgent:
    """Client for agent-to-agent communication via the Orchestration Engine.

    All calls route through the OE's REST API, ensuring policy enforcement,
    logging, and HITL controls.

    Args:
        oe_url: The OE's HTTP base URL (e.g. "http://localhost:8000").
        auth_token: Bearer token for A2A authentication (the A2A JWT).
    """

    def __init__(self, oe_url: str, auth_token: str = "") -> None:
        self._oe_url = oe_url.rstrip("/")
        self._auth_token = auth_token
        self._client: Optional[httpx.Client] = None

    def _ensure_client(self) -> httpx.Client:
        if self._client is None:
            headers: Dict[str, str] = {}
            if self._auth_token:
                headers["Authorization"] = f"Bearer {self._auth_token}"
            self._client = httpx.Client(
                base_url=self._oe_url,
                headers=headers,
                timeout=310.0,
            )
        return self._client

    def discover_agents(
        self,
        project_id: str = "",
        skills: Optional[List[str]] = None,
        capabilities: Optional[List[str]] = None,
        input_modes: Optional[List[str]] = None,
        limit: int = 50,
    ) -> List[DiscoveredAgent]:
        """Discover agents available for A2A calls.

        All filters are ANDed. Results are restricted by OE policy.

        Args:
            project_id: Scope to a specific project. Empty = caller's project.
            skills: Filter to agents advertising any of these skill names.
            capabilities: Filter to agents with any of these capability tags.
            input_modes: Filter to agents accepting any of these MIME types.
            limit: Max results to return.

        Returns:
            List of discovered agents.
        """
        client = self._ensure_client()
        params: Dict[str, Any] = {"limit": limit}
        if project_id:
            params["project_id"] = project_id
        for skill in skills or []:
            params.setdefault("skills", [])
            params["skills"].append(skill)
        for cap in capabilities or []:
            params.setdefault("capabilities", [])
            params["capabilities"].append(cap)
        for mode in input_modes or []:
            params.setdefault("input_modes", [])
            params["input_modes"].append(mode)

        try:
            resp = client.get("/a2a/discover", params=params)
            resp.raise_for_status()
        except httpx.HTTPError as e:
            logger.error("A2A discover_agents failed: %s", e)
            raise

        data = resp.json()
        agents = []
        for a in data.get("agents", []):
            agent_skills = [
                AgentSkill(
                    name=sk.get("name", ""),
                    description=sk.get("description", ""),
                    example_input=sk.get("example_input") or None,
                    example_output=sk.get("example_output") or None,
                )
                for sk in a.get("skills", [])
            ]
            agents.append(
                DiscoveredAgent(
                    agent_id=a.get("agent_id", ""),
                    name=a.get("name", ""),
                    description=a.get("description", ""),
                    project_id=a.get("project_id", ""),
                    skills=agent_skills,
                    capabilities=a.get("capabilities", []),
                    input_modes=a.get("input_modes", []),
                    output_modes=a.get("output_modes", []),
                )
            )
        return agents

    def invoke_agent(
        self,
        agent_id: str,
        message: str,
        skill: str = "",
        timeout: Optional[float] = None,
        custom_headers: Optional[Dict[str, str]] = None,
    ) -> AgentResponse:
        """Invoke another agent via the Orchestration Engine.

        Args:
            agent_id: Target agent identifier (from discover_agents).
            message: The message to send to the agent.
            skill: Optional skill name hint for multi-skill agents.
            timeout: Optional timeout in seconds. None uses the OE default.
            custom_headers: Optional headers forwarded to the target agent's
                execution context. Keys must not use the reserved ``a2a-`` prefix.

        Returns:
            AgentResponse with status, result, and execution_id.
        """
        client = self._ensure_client()
        body: Dict[str, Any] = {
            "target_agent_id": agent_id,
            "message": message,
        }
        if skill:
            body["skill"] = skill
        if timeout is not None:
            body["timeout_seconds"] = timeout
        if custom_headers:
            body["custom_headers"] = custom_headers

        try:
            try:
                from runner_shared.tracing import get_tracer
            except Exception:
                resp = client.post("/a2a/invoke", json=body)
                resp.raise_for_status()
                data = resp.json()
            else:
                tracer = get_tracer("runner-shared.a2a")
                with tracer.start_as_current_span("a2a.invoke_agent") as span:
                    span.set_attribute("agentic.span.kind", "a2a")
                    span.set_attribute("a2a.target_agent_id", agent_id)
                    if skill:
                        span.set_attribute("a2a.skill", skill)
                    resp = client.post("/a2a/invoke", json=body)
                    resp.raise_for_status()
                    data = resp.json()
                    child_execution_id = data.get("execution_id", "")
                    if child_execution_id:
                        span.set_attribute("a2a.child_execution_id", child_execution_id)
        except httpx.HTTPError as e:
            logger.error("A2A invoke_agent failed: %s", e)
            raise

        return AgentResponse(
            status=data.get("status", "failed"),
            result=data.get("result") or None,
            error=data.get("error") or None,
            execution_id=data.get("execution_id", ""),
        )

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None
