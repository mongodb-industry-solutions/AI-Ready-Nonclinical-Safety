"""
SecureToolWrapper - Routes all tool/LLM calls through OE for logging and policy enforcement.

This module provides:
- SecureToolWrapper: Wraps tool calls to route through OE
- SecureWrappedLLM: Wraps LLM calls to route through OE

HITL is handled via LangGraph's native interrupt() / Command(resume=...) API.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any, Callable, Dict, Optional

import httpx

from runner_shared.models import (
    GuardrailMeta,
    SuspendPayload,
    ToolExecuteRequest,
    ToolExecuteResponse,
    ToolResultRequest,
)
from runner_shared.utils import (
    get_request_timeout,
    log_cached_result,
    log_policy_blocked,
    log_tool_request,
    log_tool_result,
)

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


def extract_usage(response: Any, fallback_model: Optional[str] = None) -> Dict[str, Any]:
    """
    Extract token usage from an LLM response's response_metadata.

    Handles provider-variant key names:
    - OpenAI: response_metadata.usage.{prompt_tokens, completion_tokens, total_tokens}
    - Anthropic: response_metadata.usage.{input_tokens, output_tokens}
    - Some providers: response_metadata.token_usage.{...}

    Returns dict with keys: prompt_tokens, completion_tokens, total_tokens, model.
    All values may be None if unavailable.
    """
    result: Dict[str, Any] = {
        "prompt_tokens": None,
        "completion_tokens": None,
        "total_tokens": None,
        "model": fallback_model,
    }

    rm = getattr(response, "response_metadata", None) or {}
    usage_data = rm.get("usage", rm.get("token_usage", {})) or {}

    # Fallback: LangChain's usage_metadata (used by some providers in streaming)
    if not usage_data:
        um = getattr(response, "usage_metadata", None)
        if um and isinstance(um, dict):
            usage_data = um

    prompt = usage_data.get("prompt_tokens")
    if prompt is None:
        prompt = usage_data.get("input_tokens")
    completion = usage_data.get("completion_tokens")
    if completion is None:
        completion = usage_data.get("output_tokens")
    total = usage_data.get("total_tokens")

    if prompt is not None:
        result["prompt_tokens"] = int(prompt)
    if completion is not None:
        result["completion_tokens"] = int(completion)
    if total is not None:
        result["total_tokens"] = int(total)
    elif result["prompt_tokens"] is not None and result["completion_tokens"] is not None:
        result["total_tokens"] = result["prompt_tokens"] + result["completion_tokens"]

    # Model name: prefer response_metadata, fall back to wrapper attribute
    model_name = rm.get("model_name") or rm.get("model") or fallback_model
    result["model"] = model_name

    return result


def _extract_pod_usage(
    usage: Optional[Dict[str, Any]], fallback_model: Optional[str] = None
) -> Dict[str, Any]:
    """Extract token usage from a tool-pod usage dict into report_oe_result kwargs.

    Uses ``is not None`` checks instead of ``or`` so that a valid 0 token count
    is not treated as missing.  Computes total_tokens when the provider omits it.
    """
    if not usage:
        return {
            "prompt_tokens": None,
            "completion_tokens": None,
            "total_tokens": None,
            "model": fallback_model,
        }

    prompt = usage.get("input_tokens")
    if prompt is None:
        prompt = usage.get("prompt_tokens")

    completion = usage.get("output_tokens")
    if completion is None:
        completion = usage.get("completion_tokens")

    total = usage.get("total_tokens")
    if total is None and prompt is not None and completion is not None:
        total = prompt + completion

    model = usage.get("model")
    if not model:
        model = fallback_model

    return {
        "prompt_tokens": prompt,
        "completion_tokens": completion,
        "total_tokens": total,
        "model": model,
    }


# =============================================================================
# Exceptions
# =============================================================================


class PolicyDeniedException(Exception):
    """Raised when OE policy engine denies execution."""

    def __init__(
        self,
        reason: str,
        guardrail_meta: Optional[GuardrailMeta] = None,
    ):
        self.reason = reason
        self.guardrail_meta = guardrail_meta
        super().__init__(f"Policy denied: {reason}")


class ToolExecutionError(Exception):
    """Raised when tool execution fails."""

    def __init__(self, error: str):
        self.error = error
        super().__init__(f"Tool execution error: {error}")


class LLMInvocationError(Exception):
    """Raised when LLM invocation fails (after OE approval)."""

    def __init__(self, error: str):
        self.error = error
        super().__init__(f"LLM invocation error: {error}")


# =============================================================================
# OE Communication Helpers
# =============================================================================


def request_oe_approval(
    oe_url: str,
    execution_id: str,
    tool_name: str,
    arguments: Dict[str, Any],
    step: int,
    kind: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    timeout: float | httpx.Timeout | None = None,
) -> ToolExecuteResponse:
    """
    Request approval from OE before executing a tool/LLM call.

    Returns:
        ToolExecuteResponse with proceed flag and optional cached_result

    Raises:
        PolicyDeniedException: If OE is unreachable
    """
    request = ToolExecuteRequest(
        execution_id=execution_id,
        tool_name=tool_name,
        arguments=arguments,
        step_number=step,
        kind=kind,
        metadata=metadata or {},
    )

    client_timeout = timeout if timeout is not None else get_request_timeout()
    with httpx.Client(timeout=client_timeout) as client:
        try:
            resp = client.post(f"{oe_url}/tool/execute", json=request.model_dump())
            resp.raise_for_status()
            return ToolExecuteResponse(**resp.json())
        except httpx.HTTPError as e:
            logger.error(f"Step {step}: Failed to request OE approval: {e}", exc_info=True)
            raise PolicyDeniedException("OE unreachable; blocking for safety") from e


def report_oe_result(
    oe_url: str,
    execution_id: str,
    tool_name: str,
    step: int,
    status: str,
    result: Any,
    error: Optional[str],
    duration_ms: float,
    pod_name: Optional[str] = None,
    prompt_tokens: Optional[int] = None,
    completion_tokens: Optional[int] = None,
    total_tokens: Optional[int] = None,
    model: Optional[str] = None,
    kind: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    """Report execution result to OE for logging."""
    request = ToolResultRequest(
        execution_id=execution_id,
        step_number=step,
        tool_name=tool_name,
        status=status,
        result=result,
        error=error,
        duration_ms=duration_ms,
        pod_name=pod_name,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        total_tokens=total_tokens,
        model=model,
        kind=kind,
        metadata=metadata or {},
    )

    with httpx.Client(timeout=get_request_timeout()) as client:
        try:
            client.post(f"{oe_url}/tool/result", json=request.model_dump())
        except httpx.HTTPError as e:
            logger.error(f"Step {step}: Failed to report result to OE: {e}", exc_info=True)


# =============================================================================
# SecureToolWrapper
# =============================================================================


class SecureToolWrapper:
    """
    Wrap tool calls so OE owns execution, replay, logging, and routing.

    Flow for each call:
    1. Send the intercepted tool call to OE (POST /tool/execute)
    2. OE returns the final outcome: success, suspend, or error
    3. The wrapper logs locally and converts suspend payloads back into framework interrupts

    This enables:
    - Audit logging of all operations
    - Policy enforcement (block if not allowed)
    - Deterministic replay scenarios (resume after SUSPEND)
    """

    def __init__(
        self, oe_url: str, execution_id: str, custom_headers: Optional[Dict[str, str]] = None
    ):
        """
        Initialize the wrapper.

        Args:
            oe_url: URL of the Orchestration Engine
            execution_id: Unique execution identifier
            custom_headers: Caller-provided custom headers forwarded from the invoke request
        """
        self.oe_url = oe_url.rstrip("/")
        self.execution_id = execution_id
        self.step_counter = 0
        self.custom_headers: Dict[str, str] = custom_headers or {}

    async def close(self) -> None:
        """Clean up resources. Currently a no-op but available for future cleanup needs."""
        pass

    def execute_tool(
        self,
        tool_name: str,
        arguments: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """
        Execute a tool call through OE.

        Args:
            tool_name: Name of the tool
            arguments: Arguments to pass to the tool
            metadata: Optional execution metadata to send to OE

        Returns:
            Result from execution or cached result

        Raises:
            PolicyDeniedException: If OE blocks the call
            ToolExecutionError: If execution fails
            langgraph.types.interrupt: If result contains __suspend__ signal,
                or if OE returns an elicitation requiring user authorization
                (triggers suspend with authorization_url in context)
        """
        self.step_counter += 1
        step = self.step_counter
        log_tool_request(tool_name, arguments, step, prefix="TOOL")

        # 1. Request approval from OE
        response = request_oe_approval(
            oe_url=self.oe_url,
            execution_id=self.execution_id,
            tool_name=tool_name,
            arguments=arguments,
            step=step,
            metadata=metadata,
        )

        if response.elicitation:
            from runner_shared.hooks import get_suspend_handler

            interrupt = get_suspend_handler()
            if interrupt is None:
                raise RuntimeError(
                    "No suspend handler registered. "
                    "Ensure the framework SDK calls register_suspend_handler() before run()."
                )

            interrupt(
                {
                    "suspend_reason": "authorization_required",
                    "suspend_context": {
                        "authorization_url": response.elicitation.authorization_url,
                        "elicitation_id": response.elicitation.elicitation_id,
                        "message": response.elicitation.message,
                        "created": response.elicitation.created,
                    },
                }
            )
            return  # interrupt() raises GraphInterrupt; defensive guard

        if not response.proceed:
            log_policy_blocked(tool_name, step, response.reason or "Policy denied", prefix="TOOL")
            raise PolicyDeniedException(
                response.reason or "Policy denied",
                guardrail_meta=response.guardrail_meta,
            )

        if response.latest_step_number is not None:
            self.step_counter = max(self.step_counter, response.latest_step_number)

        if response.from_cache:
            log_cached_result(tool_name, step, prefix="TOOL")

        status = response.status or "error"
        result = response.result
        error = response.error
        duration_ms = response.duration_ms or 0.0

        log_tool_result(
            tool_name,
            step,
            status,
            result=result,
            error=error,
            duration_ms=duration_ms,
            prefix="TOOL",
        )

        if status == "error":
            raise ToolExecutionError(error or "Unknown error")
        if status not in {"success", "suspend"}:
            raise ToolExecutionError(f"Unexpected OE tool status: {status}")

        return self._process_result(result)

    def _process_result(self, result: Any) -> Any:
        """Process result and check for SUSPEND signal.

        When ``__suspend__`` is detected, validates the payload against
        ``SuspendPayload`` and calls the registered suspend handler (e.g.
        LangGraph's ``interrupt()``).  On resume, the handler returns the
        human decision from ``Command(resume=...)``, which becomes the
        tool result.
        """
        parsed = result
        if isinstance(result, str):
            try:
                parsed = json.loads(result)
            except (json.JSONDecodeError, ValueError):
                pass

        if isinstance(parsed, dict) and parsed.get("__suspend__"):
            from runner_shared.hooks import get_suspend_handler

            interrupt = get_suspend_handler()
            if interrupt is None:
                raise RuntimeError(
                    "No suspend handler registered. "
                    "Ensure the framework SDK calls register_suspend_handler() before run()."
                )
            payload = SuspendPayload.model_validate(parsed)
            human_decision = interrupt(payload.model_dump())
            if not isinstance(human_decision, dict):
                raise TypeError(
                    f"Expected dict from HITL interrupt, got {type(human_decision).__name__}"
                )
            return json.dumps(human_decision)
        return result


# NOTE: SecureWrappedLLM has been moved to magenta-sdklanggraph.secure_llm
# as part of AP-217 to make runner-shared framework-agnostic.


# =============================================================================
# Context-Aware Tool Wrapper
# =============================================================================


def create_secure_tool_function(
    original_tool: Any,
    tool_name: str,
    allow_direct: bool = False,
    metadata: Optional[Dict[str, Any]] = None,
) -> Callable:
    """
    Create a wrapped tool function that routes through SecureToolWrapper.

    The wrapper is looked up from context at call time, allowing the tool
    to be built before execution context exists.

    Args:
        original_tool: The original LangChain tool
        tool_name: Name of the tool
        allow_direct: Whether to allow direct execution when wrapper is missing
        metadata: Optional execution metadata to send to OE

    Returns:
        Wrapped function that routes through OE via SecureToolWrapper
    """
    import functools

    from runner_shared.context import get_current_wrapper

    @functools.wraps(original_tool.func if hasattr(original_tool, "func") else original_tool)
    def wrapped_func(**kwargs):
        wrapper = get_current_wrapper()
        if wrapper is None:
            if not allow_direct:
                raise RuntimeError(
                    f"SecureToolWrapper missing for tool {tool_name}; "
                    "execution not allowed (RUNNER_ALLOW_DIRECT_TOOL_EXECUTION=false)"
                )
            logger.warning(f"No wrapper for tool {tool_name}, executing directly (UNSAFE)")
            return original_tool.invoke(kwargs)

        try:
            # Delegate to SecureToolWrapper which handles:
            # 1. Sends the intercepted tool call to OE
            # 2. Receives the final success/suspend/error outcome
            # 3. Converts suspend payloads back into the framework interrupt
            return wrapper.execute_tool(
                tool_name=tool_name,
                arguments=kwargs,
                metadata=metadata,
            )
        except ToolExecutionError as exc:
            logger.info(
                "Propagating tool execution error to graph for %s: %s",
                tool_name,
                exc.error,
            )
            raise

    return wrapped_func
