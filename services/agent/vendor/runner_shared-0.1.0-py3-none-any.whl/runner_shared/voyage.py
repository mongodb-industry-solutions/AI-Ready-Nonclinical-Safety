"""
Voyage AI integration for embeddings and reranking.

Credentials injected via K8s secrets -> environment variables.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import List, Optional

logger = logging.getLogger(__name__)

DEFAULT_VOYAGE_DIMENSION = 1024
DEFAULT_VOYAGE_MODEL = "voyage-4-large"
DEFAULT_VOYAGE_RERANK_MODEL = "rerank-2-lite"


@dataclass
class RerankResult:
    """Result from reranking operation."""

    index: int
    document: str
    relevance_score: float


class VoyageService:
    """
    Voyage AI embeddings and reranking.

    Env vars: VOYAGE_API_KEY (required), VOYAGE_URL, VOYAGE_MODEL, VOYAGE_DIMENSION, VOYAGE_RERANK_MODEL.
    VOYAGE_DIMENSION defaults to 1024 when unset.
    """

    def __init__(self):
        """Initialize Voyage service from environment variables."""
        api_key = os.environ.get("VOYAGE_API_KEY")
        if not api_key:
            raise ValueError("VOYAGE_API_KEY environment variable required")

        try:
            import voyageai
        except ImportError as e:
            raise ImportError("voyageai package required") from e

        self._model = os.environ.get("VOYAGE_MODEL", DEFAULT_VOYAGE_MODEL)
        self._rerank_model = os.environ.get("VOYAGE_RERANK_MODEL", DEFAULT_VOYAGE_RERANK_MODEL)

        dim_env = (os.environ.get("VOYAGE_DIMENSION") or "").strip()
        if not dim_env:
            self._dimension = DEFAULT_VOYAGE_DIMENSION
        else:
            try:
                self._dimension = int(dim_env)
            except ValueError as e:
                raise ValueError("VOYAGE_DIMENSION must be a positive integer") from e
            if self._dimension <= 0:
                raise ValueError("VOYAGE_DIMENSION must be a positive integer")

        base_url = (os.environ.get("VOYAGE_URL") or "").strip() or None
        client_kwargs = {"api_key": api_key}
        if base_url:
            client_kwargs["base_url"] = base_url

        self._client = voyageai.Client(**client_kwargs)  # type: ignore[attr-defined]  # voyageai public API
        self._async_client = voyageai.AsyncClient(**client_kwargs)  # type: ignore[attr-defined]  # voyageai public API

        logger.info(
            f"VoyageService initialized: model={self._model}, "
            f"dimension={self._dimension}, rerank={self._rerank_model}"
        )

    def _embed_kwargs(self, input_type: str) -> dict:
        """Build kwargs for embed calls."""
        kwargs: dict = {"model": self._model, "input_type": input_type}
        kwargs["output_dimension"] = self._dimension
        return kwargs

    def embed(self, text: str, input_type: str = "document") -> List[float]:
        """Generate embedding for a single text."""
        result = self._client.embed([text], **self._embed_kwargs(input_type))
        return result.embeddings[0]  # type: ignore[return-value]  # voyageai returns float embeddings

    def embed_batch(self, texts: List[str], input_type: str = "document") -> List[List[float]]:
        """Generate embeddings for multiple texts."""
        if not texts:
            return []
        result = self._client.embed(texts, **self._embed_kwargs(input_type))
        return result.embeddings  # type: ignore[return-value]  # voyageai returns float embeddings

    def embed_query(self, text: str) -> List[float]:
        """Generate query-optimized embedding for retrieval."""
        return self.embed(text, input_type="query")

    async def aembed(self, text: str, input_type: str = "document") -> List[float]:
        """Async: Generate embedding for a single text."""
        result = await self._async_client.embed([text], **self._embed_kwargs(input_type))
        return result.embeddings[0]  # type: ignore[return-value]  # voyageai returns float embeddings

    async def aembed_batch(
        self, texts: List[str], input_type: str = "document"
    ) -> List[List[float]]:
        """Async: Generate embeddings for multiple texts."""
        if not texts:
            return []
        result = await self._async_client.embed(texts, **self._embed_kwargs(input_type))
        return result.embeddings  # type: ignore[return-value]  # voyageai returns float embeddings

    async def aembed_query(self, text: str) -> List[float]:
        """Async: Generate query-optimized embedding for retrieval."""
        return await self.aembed(text, input_type="query")

    def rerank(
        self,
        query: str,
        documents: List[str],
        top_k: Optional[int] = None,
    ) -> List[RerankResult]:
        """Rerank documents by relevance to query."""
        if not documents:
            return []

        result = self._client.rerank(
            query=query,
            documents=documents,
            model=self._rerank_model,
            top_k=top_k or len(documents),
        )

        return [
            RerankResult(
                index=r.index,
                document=documents[r.index],
                relevance_score=r.relevance_score,
            )
            for r in result.results
        ]

    async def arerank(
        self,
        query: str,
        documents: List[str],
        top_k: Optional[int] = None,
    ) -> List[RerankResult]:
        """Async: Rerank documents by relevance to query."""
        if not documents:
            return []

        result = await self._async_client.rerank(
            query=query,
            documents=documents,
            model=self._rerank_model,
            top_k=top_k or len(documents),
        )

        return [
            RerankResult(
                index=r.index,
                document=documents[r.index],
                relevance_score=r.relevance_score,
            )
            for r in result.results
        ]

    @property
    def dimension(self) -> int:
        """Configured embedding dimension."""
        return self._dimension

    @property
    def model_id(self) -> str:
        """Embedding model identifier."""
        return self._model

    @property
    def rerank_model_id(self) -> str:
        """Reranking model identifier."""
        return self._rerank_model


def get_voyage_service() -> Optional[VoyageService]:
    """Get VoyageService if configured, None otherwise."""
    if not os.environ.get("VOYAGE_API_KEY"):
        logger.warning("VOYAGE_API_KEY not set, Voyage features disabled")
        return None

    try:
        return VoyageService()
    except Exception as e:
        logger.error(f"Failed to initialize VoyageService: {e}", exc_info=True)
        return None


__all__ = [
    "DEFAULT_VOYAGE_DIMENSION",
    "DEFAULT_VOYAGE_MODEL",
    "DEFAULT_VOYAGE_RERANK_MODEL",
    "VoyageService",
    "RerankResult",
    "get_voyage_service",
]
