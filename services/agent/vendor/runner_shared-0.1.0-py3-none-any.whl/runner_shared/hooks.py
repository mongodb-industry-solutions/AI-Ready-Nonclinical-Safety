"""
Framework hook registry for runner-shared.

Hooks are registered once at process startup by the framework SDK
(e.g. magenta_sdklanggraph) before the server starts. Consumers in
runner-shared call get_*() instead of importing framework-specific
modules directly.

Type aliases use sdk-core protocols where possible. The suspend handler
remains loosely typed because its signature is framework-specific
(e.g. langgraph's ``interrupt`` returns whatever the resume caller provides).
"""

from __future__ import annotations

from typing import Any, Callable

from magenta_sdk_core.interfaces import BaseLLM

# Accepts a serialized SuspendPayload dict, returns the human decision dict.
SuspendHandler = Callable[[dict[str, Any]], dict[str, Any]]

# Accepts (raw_llm, tools=...), returns a BaseLLM-compatible adapter.
LLMAdapterFactory = Callable[..., BaseLLM]

# Runs framework-specific OTel instrumentation (e.g. LangChainInstrumentor).
Instrumentor = Callable[[], None]

_suspend_handler: SuspendHandler | None = None
_llm_adapter_factory: LLMAdapterFactory | None = None
_instrumentor: Instrumentor | None = None
_llm_registry: dict[str, Any] = {}


def register_suspend_handler(handler: SuspendHandler) -> None:
    global _suspend_handler
    _suspend_handler = handler


def get_suspend_handler() -> SuspendHandler | None:
    return _suspend_handler


def register_llm_adapter_factory(factory: LLMAdapterFactory) -> None:
    global _llm_adapter_factory
    _llm_adapter_factory = factory


def get_llm_adapter_factory() -> LLMAdapterFactory:
    if _llm_adapter_factory is None:
        raise RuntimeError(
            "No LLM adapter factory registered. "
            "Ensure the framework SDK calls register_llm_adapter_factory() before run()."
        )
    return _llm_adapter_factory


def register_instrumentor(instrumentor: Instrumentor) -> None:
    global _instrumentor
    _instrumentor = instrumentor


def get_instrumentor() -> Instrumentor | None:
    return _instrumentor


def register_llm(llm_id: str, llm: Any) -> None:
    """Register an LLM by id. Raises ValueError on duplicate id.

    Framework SDKs call this from ``app.llm()`` for every LLM the agent
    uses. The unnamed-LLM convenience case is represented by registering
    under the sentinel id ``"__default__"``; a second unnamed call will
    therefore raise the same duplicate-id error as a second named call
    with the same id.
    """
    if llm_id in _llm_registry:
        raise ValueError(
            f"llm_id {llm_id!r} is already registered. "
            "Each LLM must have a unique llm_id; pass app.llm(llm, llm_id='...') for each."
        )
    _llm_registry[llm_id] = llm


def get_named_llm(llm_id: str) -> Any:
    if llm_id not in _llm_registry:
        raise KeyError(
            f"llm_id {llm_id!r} not registered. "
            "Call app.llm(llm, llm_id=...) for each LLM before run()."
        )
    return _llm_registry[llm_id]


def has_named_llms() -> bool:
    return bool(_llm_registry)


def reset_llm_registry() -> None:
    global _llm_registry
    _llm_registry = {}


def snapshot_llm_registry() -> dict[str, Any]:
    """Return a shallow copy of the current registry."""
    return dict(_llm_registry)


def reset_hooks() -> None:
    global _suspend_handler, _llm_adapter_factory, _instrumentor, _llm_registry
    _suspend_handler = None
    _llm_adapter_factory = None
    _instrumentor = None
    _llm_registry = {}
