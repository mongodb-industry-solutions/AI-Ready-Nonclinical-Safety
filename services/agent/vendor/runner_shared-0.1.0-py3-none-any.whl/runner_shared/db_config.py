"""Single source of truth for the consolidated data-plane database name.

All platform-owned stores (execution logs, checkpoints, memory, traces)
live in one database.  Override via the ``MDB_AGENTIC_STORE_DB`` environment
variable; the default is ``mdb_agentic_store``.
"""

from __future__ import annotations

import os

_DEFAULT_DB_NAME = "mdb_agentic_store"
_ENV_VAR = "MDB_AGENTIC_STORE_DB"


def get_store_db_name() -> str:
    """Return the consolidated data-plane database name.

    Reads ``MDB_AGENTIC_STORE_DB`` from the environment on every call so that
    late configuration (e.g. ``load_dotenv()`` after import) is respected.
    """
    value = os.environ.get(_ENV_VAR, "").strip()
    return value if value else _DEFAULT_DB_NAME
