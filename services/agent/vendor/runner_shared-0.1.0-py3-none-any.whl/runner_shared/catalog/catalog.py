"""
Catalog system for tool policies.

Provides reusable policy definitions loaded from YAML files or MongoDB.
"""

from __future__ import annotations

import logging
import os
import threading
from pathlib import Path
from typing import Dict, Optional, Protocol

import yaml

from .types import ToolConfig

logger = logging.getLogger(__name__)


class CatalogProvider(Protocol):
    """Protocol for catalog providers."""

    def get_policy(self, policy_id: str, tenant_id: Optional[str] = None) -> Optional[ToolConfig]:
        """Get a policy by ID."""
        ...


class YAMLCatalogProvider:
    """
    Loads tool policies from YAML files.

    Catalog files are loaded from:
    1. AGENTIC_CATALOG_DIR environment variable (if set)
    2. Package defaults directory

    Example catalog file (openai.yaml):
        policies:
          openai/chat:
            network:
              - api.openai.com
            timeout_seconds: 120
    """

    def __init__(self, catalog_dir: Optional[Path] = None) -> None:
        env_dir = os.getenv("AGENTIC_CATALOG_DIR")

        if catalog_dir is not None:
            self._base_dir = catalog_dir
        elif env_dir:
            self._base_dir = Path(env_dir)
        else:
            # Default to package catalog directory
            self._base_dir = Path(__file__).parent / "_defaults"

        self._lock = threading.Lock()
        self._loaded = False
        self._catalog_cache: Dict[str, ToolConfig] = {}

    def _load_catalog(self) -> None:
        """Load all YAML catalog files."""
        if self._loaded:
            return

        with self._lock:
            if self._loaded:
                return

            if not self._base_dir.exists():
                logger.debug(f"Catalog directory does not exist: {self._base_dir}")
                self._loaded = True
                return

            for yaml_file in self._base_dir.glob("*.yaml"):
                try:
                    with yaml_file.open("r", encoding="utf-8") as f:
                        data = yaml.safe_load(f) or {}

                    policies = data.get("policies", {}) or {}
                    for policy_id, policy_data in policies.items():
                        self._catalog_cache[policy_id] = ToolConfig(
                            name=policy_id,
                            **policy_data,
                        )
                    logger.debug(f"Loaded {len(policies)} policies from {yaml_file.name}")
                except Exception as e:
                    logger.warning(f"Failed to load catalog file {yaml_file}: {e}")

            logger.info(f"Loaded {len(self._catalog_cache)} policies from catalog")
            self._loaded = True

    def get_policy(self, policy_id: str, tenant_id: Optional[str] = None) -> Optional[ToolConfig]:
        """Get a policy by ID."""
        self._load_catalog()
        return self._catalog_cache.get(policy_id)

    def list_policies(self) -> Dict[str, ToolConfig]:
        """Get all loaded policies."""
        self._load_catalog()
        return dict(self._catalog_cache)

    def reload(self) -> None:
        """Force reload of catalog files."""
        with self._lock:
            self._loaded = False
            self._catalog_cache.clear()
        self._load_catalog()


# Global default provider
_default_provider: Optional[CatalogProvider] = None
_provider_lock = threading.Lock()


def get_catalog_provider() -> CatalogProvider:
    """Get the default catalog provider."""
    global _default_provider

    if _default_provider is None:
        with _provider_lock:
            if _default_provider is None:
                _default_provider = YAMLCatalogProvider()

    return _default_provider


def set_catalog_provider(provider: CatalogProvider) -> None:
    """Set a custom catalog provider."""
    global _default_provider
    with _provider_lock:
        _default_provider = provider


def load_policy(policy_id: str, tenant_id: Optional[str] = None) -> ToolConfig:
    """
    Load a policy from the catalog.

    Args:
        policy_id: Policy identifier (e.g., "openai/chat")
        tenant_id: Optional tenant ID for multi-tenant lookups

    Returns:
        ToolConfig for the policy

    Raises:
        ValueError: If policy not found
    """
    provider = get_catalog_provider()
    config = provider.get_policy(policy_id, tenant_id=tenant_id)

    if config is None:
        raise ValueError(f"Unknown catalog policy: {policy_id}")

    return config
