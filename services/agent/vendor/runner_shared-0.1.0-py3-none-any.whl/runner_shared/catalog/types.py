"""
Type definitions for the catalog system.

Includes policy configuration types for tool execution.
"""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field


class ToolConfig(BaseModel):
    """
    Configuration/policy for a tool.

    Defines security policies, timeout limits, and logging behavior.
    Can be defined in YAML catalogs or inline.
    """

    name: str
    catalog: Optional[str] = None

    # Network policy - allowed hosts for outbound requests
    network: List[str] = Field(default_factory=list)

    # Execution limits
    timeout_seconds: int = 30

    # Fields to redact from logs (e.g., passwords, API keys)
    redact_fields: List[str] = Field(default_factory=list)

    # Whether tool runs locally in AER (True) or in Tool Pod (False)
    is_local: bool = True

    # Tool description for LLM binding
    description: Optional[str] = None
