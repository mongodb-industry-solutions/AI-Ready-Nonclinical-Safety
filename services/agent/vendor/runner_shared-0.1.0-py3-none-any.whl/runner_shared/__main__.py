"""Generic platform entrypoint for the runner-shared image.

Dispatches via RUNNER_MODE (aer | tool | memory-server) through
TenantRuntime.register_and_run(). Memory-server and tool modes do not
need a graph builder; aer mode does, so user agents provide their own
__main__.py for that case (App.run() enforces the builder check there).
"""

from runner_shared.runtime import TenantRuntime

if __name__ == "__main__":
    TenantRuntime().register_and_run()
