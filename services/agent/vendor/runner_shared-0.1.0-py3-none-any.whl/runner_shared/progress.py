"""emit / emit_step — send a mid-execution chunk from within a tool function.

Tool functions running inside a Tool Pod call these to stream events to the
client while the tool is still executing. Both execution_id and oe_url are
injected into Python contextvars by the Tool Pod server before the tool runs.

The call is best-effort: network errors are logged and swallowed so a failed
chunk emit never aborts the tool.
"""

from __future__ import annotations

import atexit
import logging

import httpx

from runner_shared.context import current_execution_id, current_oe_url
from runner_shared.server.chunk_types import (
    DONE,
    ERROR,
    STEP,
    SUBAGENT_END,
    SUBAGENT_START,
    TEXT,
)

logger = logging.getLogger(__name__)

# Short timeout: chunk emits are best-effort fire-and-forget. A slow or
# unreachable OE must not delay the tool function itself.
_PROGRESS_TIMEOUT_SECS = 5.0

# Module-level client so the underlying TCP/TLS connection to the OE is pooled
# and reused across emit() calls. httpx.Client is thread-safe for the .post()
# method we use; atexit closes it deterministically on interpreter shutdown.
_client = httpx.Client(timeout=_PROGRESS_TIMEOUT_SECS)
atexit.register(_client.close)

# Chunk types reserved for infrastructure use. Tool code emitting these would
# either close the SSE stream prematurely (DONE/ERROR are terminal) or spoof
# infrastructure-only chunk types (TEXT/SUBAGENT_*).
_RESERVED_EVENTS = frozenset({DONE, ERROR, TEXT, SUBAGENT_START, SUBAGENT_END})


def emit(event: str, data: str) -> None:
    """Emit a chunk of the given event type to the client stream.

    General-purpose API. For the common textual-step case, prefer
    :func:`emit_step`.

    Args:
        event: Chunk type identifier (e.g. ``"step"``). Reserved infrastructure
            event types (``done``, ``error``, ``text``, ``subagent_start``,
            ``subagent_end``) raise ``ValueError`` to prevent tool code from
            prematurely closing or spoofing the stream.
        data: Payload string for the event.

    Raises:
        ValueError: if ``event`` is a reserved infrastructure event type.

    Transport failures are logged at DEBUG and swallowed — best-effort delivery
    must never abort the tool function. No-op outside an execution context.
    Synchronous; async tool functions must wrap in ``asyncio.to_thread``.
    """
    if event in _RESERVED_EVENTS:
        raise ValueError(
            f"emit: event {event!r} is reserved for infrastructure use; "
            f"choose a non-terminal event type such as 'step'"
        )

    execution_id = current_execution_id.get()
    oe_url = current_oe_url.get()

    if not execution_id or not oe_url:
        return

    try:
        response = _client.post(
            f"{oe_url.rstrip('/')}/stream/chunk",
            json={
                "execution_id": execution_id,
                "chunk_type": event,
                "content": data,
                "metadata": {},
            },
        )
        response.raise_for_status()
    except Exception as exc:
        # Best-effort: a failed chunk must never abort the tool function.
        # DEBUG so operators can diagnose OE connectivity without noise.
        # Catches httpx.InvalidURL too (it extends Exception, not HTTPError).
        logger.debug("emit: failed to send chunk: %s", exc)


def emit_step(message: str) -> None:
    """Emit a textual progress step from within a running tool function.

    Convenience wrapper around ``emit(event="step", data=message)``.

    Example::

        from runner_shared import emit_step

        @app.tool(is_local=False)
        def crawl_website(url: str) -> str:
            emit_step("Fetching page...")
            html = fetch(url)
            emit_step(f"Parsing links from {url}...")
            return parse(html)
    """
    emit(event=STEP, data=message)
