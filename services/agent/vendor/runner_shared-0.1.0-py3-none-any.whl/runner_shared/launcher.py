"""
Launcher module for pipeline-built agent containers.

Reads AGENT_ENTRYPOINT and starts the user's agent code. This module exists so
the generated Dockerfile can use a fixed CMD instruction for every agent image:

    CMD ["/app/.venv/bin/python3", "-m", "runner_shared.launcher"]

Environment variables:
    AGENT_ENTRYPOINT  Startup target in one of these forms:

                      1) ``module.path:function_name`` (e.g. ``my_agent.main:main``)
                         - The function is imported and invoked.
                      2) ``module.path:attribute_name`` (e.g. ``my_agent.agent:app``)
                         - If the attribute is not callable but has a callable
                           ``run()`` method, ``.run()`` is invoked.
                      3) ``module.path`` (e.g. ``my_agent.main``)
                         - Defaults to calling ``module.path:main``.

Security note:
    The AGENT_ENTRYPOINT value is baked into the Dockerfile ENV at build time
    by the CodeBuild pipeline (see buildspec.yml.tmpl). It is not user-supplied
    at container runtime. The importlib.import_module call here serves the same
    role as ``python -m <module>`` — bootstrapping a known, pre-installed module.
    This is an intentional exception to the sec-003 "no dynamic code execution"
    guideline; the user's agent code is already installed in the image and would
    be imported regardless of the mechanism used to start it.
"""

from __future__ import annotations

import importlib
import logging
import os
import sys

from runner_shared.mcp_oauth_secret import materialize_mcp_oauth_secret_cache

logger = logging.getLogger(__name__)


def _resolve_entrypoint() -> tuple[str, str]:
    """Parse AGENT_ENTRYPOINT into (module_path, target_name)."""
    raw = os.environ.get("AGENT_ENTRYPOINT", "")
    if not raw:
        print("AGENT_ENTRYPOINT is not set", file=sys.stderr)
        sys.exit(1)

    if ":" in raw:
        module_path, func_name = raw.rsplit(":", 1)
    else:
        module_path = raw
        func_name = "main"

    if not module_path or not func_name:
        print(
            f"Invalid AGENT_ENTRYPOINT '{raw}': both module path and function name must be non-empty",
            file=sys.stderr,
        )
        sys.exit(1)

    return module_path, func_name


def main() -> None:
    """Entry point invoked by ``python -m runner_shared.launcher``."""
    try:
        materialize_mcp_oauth_secret_cache()
    except (RuntimeError, OSError) as exc:
        print(f"Cannot materialize MCP OAuth credentials: {exc}", file=sys.stderr)
        sys.exit(1)

    module_path, target_name = _resolve_entrypoint()

    logger.info(f"Launcher: importing {module_path}:{target_name}")

    try:
        module = importlib.import_module(module_path)
    except ModuleNotFoundError as exc:
        print(f"Cannot import module '{module_path}': {exc}", file=sys.stderr)
        sys.exit(1)

    target = getattr(module, target_name, None)
    if target is None:
        print(
            f"Module '{module_path}' has no attribute '{target_name}'",
            file=sys.stderr,
        )
        sys.exit(1)

    # Preferred form: module:function (callable).
    if callable(target):
        target()
        return

    # Compatibility form: module:app_object where app_object has a run() method.
    run = getattr(target, "run", None)
    if callable(run):
        run()
        return

    print(
        f"'{module_path}:{target_name}' is not callable and has no callable 'run()' method",
        file=sys.stderr,
    )
    sys.exit(1)


if __name__ == "__main__":
    main()
