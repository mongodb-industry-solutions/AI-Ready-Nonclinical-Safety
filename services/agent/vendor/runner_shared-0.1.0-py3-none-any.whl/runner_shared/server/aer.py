"""
Agent Execution Runtime (AER) server - Framework-agnostic agent execution.

The AER is responsible for:
- Executing agents via the BaseAgent protocol (framework-neutral)
- Making LLM calls (with network access)
- Routing all calls through OE via SecureToolWrapper
- Handling HITL via StreamEvent suspend/resume pattern
- Reporting completion/suspension to OE
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import os
from typing import TYPE_CHECKING, Any, Dict, NamedTuple, Optional, TypedDict, Union, cast

import httpx
from fastapi import FastAPI, HTTPException, Query
from magenta_sdk_core import (
    AgentInput,
    RequestContext,
    collect_message_artifact_metadata,
)
from magenta_sdk_core.models import (
    SessionMessagesResponse,
    SessionsSummaryResponse,
)
from pydantic import JsonValue

from runner_shared.context import clear_execution_context, set_execution_context
from runner_shared.metrics import with_metrics
from runner_shared.models import (
    AERExecuteResponse,
    ExecuteRequest,
    ExecutorCallbackRequest,
    InterruptResult,
    StreamingResult,
    SuspendPayload,
    ToolsListResponse,
)
from runner_shared.node_logger import NodeExecutionLogger
from runner_shared.secure_wrapper import SecureToolWrapper
from runner_shared.server.base import BaseServer
from runner_shared.server.chunk_types import (
    DONE,
    ERROR,
    SUBAGENT_END,
    SUBAGENT_START,
    TEXT,
)
from runner_shared.utils import (
    filter_thinking_tokens,
    get_env_float,
    get_request_timeout,
    log_execution_callback,
    log_section,
    strip_thinking,
)

if TYPE_CHECKING:
    from runner_shared.runtime import TenantRuntime

logger = logging.getLogger(__name__)

# Configurable execution timeout (default 5 minutes)
EXECUTION_TIMEOUT = get_env_float("RUNNER_EXECUTION_TIMEOUT", 300.0)

# Bounded-retry policy for AER -> OE chunk POSTs. Transient HTTP errors
# (connection error, 5xx, read/write/protocol timeouts) are retried with
# exponential backoff (0.1s, 0.2s, 0.4s ...). 4xx responses are not retried.
MAX_CHUNK_POST_ATTEMPTS = 3
CHUNK_POST_BASE_DELAY_S = 0.1
# After the SDK emits a terminal result/suspend event, ask the iterator for one
# more item so async generators can run their natural cleanup path instead of
# being closed by GeneratorExit from an in-loop return.
AGENT_STREAM_TERMINAL_DRAIN_TIMEOUT_S = get_env_float("AGENT_STREAM_TERMINAL_DRAIN_TIMEOUT", 1.0)


async def _aclose_stream_iter(stream_iter: Any, execution_id: str) -> None:
    """Close an async iterator when it supports generator-style ``aclose``."""
    aclose = getattr(stream_iter, "aclose", None)
    if aclose is None:
        return
    try:
        result = aclose()
        if inspect.isawaitable(result):
            await result
    except Exception:
        logger.warning(
            "Failed to close agent stream iterator for execution %s",
            execution_id,
            exc_info=True,
        )


class _SubagentBoundaryData(TypedDict, total=False):
    """Expected fields on subagent_start / subagent_end SDK events."""

    source: str
    subagent_name: str
    tool_call_id: str
    description: str  # present on subagent_start; forwarded in metadata
    summary: str  # present on subagent_end; forwarded in metadata


def _artifact_metadata_from_messages(messages: list[Any]) -> dict[str, JsonValue]:
    """Collect generic message artifact metadata from the final assistant message."""
    for message in reversed(messages):
        if getattr(message, "role", None) != "assistant":
            continue

        metadata = collect_message_artifact_metadata(
            getattr(message, "additional_kwargs", None),
        )
        return metadata.to_message_metadata() if metadata else {}

    return {}


class _ResolvedParams(NamedTuple):
    thread_id: str
    message: str


def _resolve_invocation_params(request: ExecuteRequest) -> _ResolvedParams:
    """Resolve the continuation id and message for this execution.

    ``thread_id`` prefers ``session_id``, falling back to ``thread_id`` then
    ``execution_id`` for backward compatibility. The langgraph checkpoint id
    is *not* resolved here — it is opaque framework state that the adapter
    reads from ``metadata``.
    """
    req_payload = request.payload or {}

    thread_id = request.session_id or request.thread_id or request.execution_id

    _payload_message = req_payload.get("message")
    message = (_payload_message if isinstance(_payload_message, str) else None) or request.message

    return _ResolvedParams(
        thread_id=thread_id,
        message=message,
    )


def _reject_ambiguous_message(request: ExecuteRequest) -> None:
    """Reject a request that carries ``message`` both top-level and in ``payload``.

    The AER is the only component that unpacks the opaque payload, so the
    collision is caught here and raised as a clean 400. Doing it here (rather
    than in a model validator) keeps the payload out of the error body and the
    logs — a 422 from a validator would echo the entire request, payload
    included, back to the caller.
    """
    payload_msg = request.payload.get("message") if request.payload else None
    if request.message and isinstance(payload_msg, str) and payload_msg:
        raise HTTPException(
            status_code=400,
            detail=(
                "Ambiguous request: 'message' was provided both at the top level "
                "and inside 'payload'. Send the message in exactly one place."
            ),
        )


class AERServer(BaseServer):
    """
    Agent Execution Runtime server - framework-agnostic agent execution.

    Responsibilities:
    - Execute agents via the BaseAgent protocol (framework-neutral)
    - Use SecureToolWrapper for all tool/LLM calls
    - Report completion or suspension to OE
    """

    def __init__(self, runtime: "TenantRuntime"):
        super().__init__(runtime)
        self._client: Optional[httpx.AsyncClient] = None
        self._client_lock = asyncio.Lock()
        self._a2a_registered = False
        self._chunk_seq: Dict[str, int] = {}

    @property
    def mode_name(self) -> str:
        return "aer"

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client (thread-safe)."""
        if self._client is None:
            async with self._client_lock:
                if self._client is None:  # Double-check after acquiring lock
                    self._client = httpx.AsyncClient(timeout=get_request_timeout())
        return self._client

    async def on_startup(self) -> None:
        """Verify graph builder is ready and register A2A config."""
        if self.runtime._graph_builder is None:
            raise RuntimeError(
                "Agent graph builder not initialized. "
                "Did you pass a graph_builder to register_and_run()?"
            )

        logger.info("AER ready with graph builder")

        # Register A2A config at startup using env vars (set by the operator).
        oe_url = os.environ.get("OE_URL", "")
        workspace_id = os.environ.get("APP_ID", "")
        if oe_url and workspace_id and not self._a2a_registered:
            await self._register_a2a_config(oe_url, workspace_id)

    async def on_shutdown(self) -> None:
        """Clean up resources."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def _register_a2a_config(self, oe_url: str, workspace_id: str) -> None:
        """Push agent.yaml A2A config to the OE (one-shot, fail-open)."""
        a2a_cfg = self.runtime.agent_config.a2a
        try:
            client = await self._get_client()
            payload = {
                "workspace_id": workspace_id,
                "name": self.runtime.app_name,
                "description": "",
                "org_id": os.environ.get("ORG_ID", "") or (self.runtime.org_id or ""),
                "project_id": os.environ.get("PROJECT_ID", ""),
                "a2a_enabled": a2a_cfg.enabled,
                "skills": [
                    {
                        "name": sk.name,
                        "description": sk.description,
                        "example_input": sk.example_input or "",
                        "example_output": sk.example_output or "",
                    }
                    for sk in a2a_cfg.skills
                ],
                "input_modes": a2a_cfg.input_modes,
                "output_modes": a2a_cfg.output_modes,
                "allowed_callers": a2a_cfg.allowed_callers,
                "aer_http_endpoint": self._build_aer_endpoint(oe_url, workspace_id),
                "tool_http_endpoint": self._build_component_endpoint(oe_url, workspace_id, "tool"),
            }
            headers: dict[str, str] = {}
            a2a_secret = os.environ.get("A2A_JWT_SECRET", "")
            if a2a_secret:
                from runner_shared.a2a_auth import sign_registration_jwt

                platform_db = os.environ.get("MDB_AGENTIC_STORE_DB", "mdb_agentic_store")
                token = sign_registration_jwt(
                    a2a_secret,
                    workspace_id,
                    issuer=f"oe.{platform_db}",
                    org_id=os.environ.get("ORG_ID", "") or (self.runtime.org_id or ""),
                    project_id=os.environ.get("PROJECT_ID", ""),
                )
                headers["Authorization"] = f"Bearer {token}"

            resp = await client.post(
                f"{oe_url}/a2a/register", json=payload, headers=headers, timeout=10.0
            )
            if resp.status_code == 200:
                logger.info(
                    f"A2A config registered for workspace {workspace_id} (enabled={a2a_cfg.enabled})"
                )
                self._a2a_registered = True
            else:
                logger.warning(f"A2A registration returned {resp.status_code}: {resp.text}")
        except httpx.HTTPError as e:
            logger.warning(f"A2A registration failed (will retry on first /execute): {e}")
        except Exception as e:  # noqa: BLE001 — non-network error, will retry on first /execute
            logger.error(f"A2A registration failed unexpectedly: {e}")

    @staticmethod
    def _build_component_endpoint(oe_url: str, workspace_id: str, component: str) -> str:
        """Build an in-cluster service URL for a workspace component.

        Extracts the namespace from the OE URL and reads the component's port
        from the Kubernetes service-discovery env var that the kubelet injects
        for every Service in the namespace.

        Args:
            oe_url: The OE's in-cluster URL (contains the namespace).
            workspace_id: The workspace identifier.
            component: The component suffix ("aer" or "tool").
        """
        from urllib.parse import urlparse

        parsed = urlparse(oe_url)
        hostname = parsed.hostname or ""
        parts = hostname.split(".")
        namespace = parts[1] if len(parts) >= 2 else ""

        # Read the port from the Kubernetes service-discovery env var:
        # {WS_ID}_{COMPONENT}_SERVICE_PORT (uppercased, hyphens → underscores)
        svc_env_prefix = f"{workspace_id}_{component}".upper().replace("-", "_")
        port = os.environ.get(f"{svc_env_prefix}_SERVICE_PORT", "")
        if not port:
            port = os.environ.get("APP_PORT", "8001")

        svc_name = f"{workspace_id}-{component}"
        if namespace:
            return f"http://{svc_name}.{namespace}.svc.cluster.local:{port}"
        return f"http://{svc_name}:{port}"

    @staticmethod
    def _build_aer_endpoint(oe_url: str, workspace_id: str) -> str:
        """Derive the AER's in-cluster service URL from the OE URL."""
        return AERServer._build_component_endpoint(oe_url, workspace_id, "aer")

    def get_health_details(self) -> Dict[str, Any]:
        return {
            "graph_builder_ready": self.runtime._graph_builder is not None,
            "tools_registered": list(self.runtime._tools.keys()),
        }

    def register_routes(self, app: FastAPI) -> None:
        """Register AER-specific routes."""
        server = self

        @app.post("/execute", response_model=AERExecuteResponse)
        async def execute(request: ExecuteRequest) -> AERExecuteResponse:
            """Execute an agent workflow via the BaseAgent protocol.

            Accepts an execution request from the Orchestration Engine, runs the
            agent graph with SecureToolWrapper for tool/LLM routing, and reports
            completion or HITL suspension back to the OE via callback.
            """
            return await server._handle_execute(request)

        @app.get("/tools", response_model=ToolsListResponse)
        async def list_tools() -> ToolsListResponse:
            """List all tools registered with this AER instance.

            Returns the tool definitions that were registered via the Runner SDK
            ``app.tool()`` decorator during agent initialization.
            """
            return ToolsListResponse(
                tools=[
                    {"name": name, **defn}
                    for name, defn in server.runtime._tool_definitions.items()
                ],
            )

        @app.get("/query/sessions", response_model=SessionsSummaryResponse)
        async def query_session_summaries(
            # The platform's session-list page caps at 50; 200 leaves
            # headroom for batched enrichment without letting a single
            # request fan out into a 100k-element $in scan if the OE proxy
            # is ever bypassed (the trust model the AER documents).
            session_ids: list[str] = Query(default_factory=list, max_length=200),
        ) -> SessionsSummaryResponse:
            """Return framework-derived summary for the given session_ids.

            Used by the platform to enrich its workspace-scoped sessions list
            with framework-specific data (timestamps, message counts, message
            preview). The platform supplies the session_ids; this endpoint
            does no workspace scoping of its own.
            """
            if not session_ids:
                return SessionsSummaryResponse(sessions=[])
            plugin = server.runtime.get_query_plugin()
            if plugin is None:
                raise HTTPException(
                    status_code=501,
                    detail="session queries are not supported by this framework",
                )
            return await plugin.get_summaries_for_sessions(session_ids)

        @app.get(
            "/query/sessions/{session_id}/messages",
            response_model=SessionMessagesResponse,
        )
        async def query_messages_for_session(
            session_id: str,
        ) -> SessionMessagesResponse:
            """Return the decoded conversation history for ``session_id``.

            Returns an empty message list if the session has no persisted
            state.
            """
            plugin = server.runtime.get_query_plugin()
            if plugin is None:
                raise HTTPException(
                    status_code=501,
                    detail="session queries are not supported by this framework",
                )
            return await plugin.get_messages_for_session(session_id)

    @with_metrics("aer_execute")
    async def _handle_execute(self, request: ExecuteRequest) -> AERExecuteResponse:
        """
        Handle /execute request from OE.

        Executes the agent via BaseAgent.stream() with SecureToolWrapper.
        """
        log_section()
        logger.info("AER: Execute %s... (resume=%s)", request.execution_id[:8], request.resume)
        logger.info("AER: OE callback URL: %s", request.platform_api_url)
        logger.debug(
            "AER: Message: %s",
            request.message[:50] + "..." if len(request.message) > 50 else request.message,
        )

        # Fail fast on a message supplied both top-level and inside payload,
        # before any side effects (A2A registration, execution).
        _reject_ambiguous_message(request)

        # One-shot A2A registration: push agent.yaml a2a config to OE
        if not self._a2a_registered and request.workspace_id:
            await self._register_a2a_config(request.platform_api_url, request.workspace_id)

        resolved = _resolve_invocation_params(request)
        thread_id_for_checkpoint = resolved.thread_id
        message = resolved.message

        # Use contextvars for per-execution isolation
        wrapper = SecureToolWrapper(
            oe_url=request.platform_api_url,
            execution_id=request.execution_id,
            custom_headers=request.custom_headers,
        )
        # On resume, advance step counter past pre-suspend steps so OE
        # does not return stale cached results for new post-resume calls.
        if request.resume_from_step is not None:
            wrapper.step_counter = request.resume_from_step
        context_tokens = set_execution_context(
            execution_id=request.execution_id,
            wrapper=wrapper,
            oe_url=request.platform_api_url,
            user_id=request.user_id,
            session_id=thread_id_for_checkpoint,
            workspace_id=request.workspace_id,
            custom_headers=request.custom_headers,
            payload=request.payload,
        )
        ctx = RequestContext(
            execution_id=request.execution_id,
            session_id=thread_id_for_checkpoint,
            user_id=request.user_id,
            request_headers=request.custom_headers,
            resume=request.resume,
            resume_data=request.resume_data,
            metadata=request.metadata,
        )

        try:
            # AgentInput.payload is the opaque caller blob, with the resolved
            # message normalized in. Platform plumbing (identity, resume,
            # checkpoint) travels on ctx, not here.
            caller_payload: Dict[str, Any] = dict(request.payload or {})
            caller_payload["message"] = message
            agent_input = AgentInput(payload=caller_payload)

            if request.resume:
                logger.info("AER: Resume execution for %s", request.execution_id[:8])

            logger.info(
                "AER /execute: execution_id=%s, session_id=%s, thread_id=%s",
                request.execution_id[:8],
                request.session_id[:8] if request.session_id else "None",
                thread_id_for_checkpoint[:8],
            )

            # Create node execution logger callback (sends events to OE for logging)
            node_logger = NodeExecutionLogger(
                oe_url=request.platform_api_url,
                execution_id=request.execution_id,
                session_id=thread_id_for_checkpoint,
                thread_id=thread_id_for_checkpoint,
                user_id=request.user_id,
                org_id=request.org_id,
                project_id=request.project_id,
            )
            logger.debug("Created NodeExecutionLogger for thread %s", thread_id_for_checkpoint[:8])

            # Get BaseAgent instance (framework-neutral interface)
            agent = self.runtime.get_agent(callbacks=[node_logger])

            # Execute via BaseAgent.stream()
            try:
                execution_outcome = await asyncio.wait_for(
                    self._execute_via_agent_stream(
                        agent,
                        ctx,
                        agent_input,
                        request.platform_api_url,
                        request.execution_id,
                    ),
                    timeout=EXECUTION_TIMEOUT,
                )
            except asyncio.TimeoutError:
                error_msg = f"Execution timed out after {EXECUTION_TIMEOUT} seconds"
                try:
                    await self._send_stream_chunk(
                        request.platform_api_url,
                        request.execution_id,
                        chunk_type=ERROR,
                        error=error_msg,
                    )
                except Exception as chunk_err:
                    logger.error(
                        "Failed to deliver ERROR chunk for execution %s after retries: %s",
                        request.execution_id,
                        chunk_err,
                        exc_info=True,
                    )
                await self._report_callback(
                    request.platform_api_url,
                    request.execution_id,
                    status="ERROR",
                    error=error_msg,
                )
                raise HTTPException(status_code=504, detail=error_msg)

            # Check if the agent was suspended (HITL).
            # _execute_via_agent_stream returns InterruptResult for
            # suspensions and StreamingResult for normal completion.
            if isinstance(execution_outcome, InterruptResult):
                if not execution_outcome.suspend_payload:
                    error_msg = "Agent produced an empty suspend payload; cannot suspend."
                    log_execution_callback(
                        request.execution_id, "ERROR", error=error_msg, prefix="AER"
                    )
                    await self._report_callback(
                        request.platform_api_url,
                        request.execution_id,
                        status="ERROR",
                        error=error_msg,
                    )
                    raise HTTPException(status_code=500, detail=error_msg)
                payload = SuspendPayload.model_validate(execution_outcome.suspend_payload)

                log_execution_callback(
                    request.execution_id,
                    "SUSPENDED",
                    suspend_reason=payload.suspend_reason,
                    prefix="AER",
                )

                # The framework adapter owns resume semantics; its opaque
                # metadata is forwarded to the OE verbatim and round-tripped
                # back into RequestContext.metadata on resume.
                await self._report_callback(
                    request.platform_api_url,
                    request.execution_id,
                    status="SUSPENDED",
                    suspend_reason=payload.suspend_reason,
                    suspend_context=payload.suspend_context,
                    metadata=execution_outcome.metadata,
                )
                return AERExecuteResponse(
                    status="suspended",
                    suspend_reason=payload.suspend_reason,
                )

            # Normal completion — write conversation turn to memory (async, non-blocking)
            if self.runtime._memory_writer and execution_outcome.messages:
                try:
                    self.runtime.write_turn_async(
                        message=message,
                        result_messages=execution_outcome.messages,
                        user_id=request.user_id,
                        session_id=thread_id_for_checkpoint,
                    )
                    logger.info(f"Memory write queued for user {request.user_id}")
                except Exception as e:
                    logger.warning(f"Failed to queue memory write: {e}")

            try:
                done_metadata = {
                    "status": "completed",
                    **_artifact_metadata_from_messages(execution_outcome.messages),
                }
                await self._send_stream_chunk(
                    request.platform_api_url,
                    request.execution_id,
                    chunk_type=DONE,
                    content=execution_outcome.content,
                    metadata=done_metadata,
                )
            except Exception as chunk_err:
                logger.error(
                    "Failed to deliver DONE chunk for execution %s after retries: %s",
                    request.execution_id,
                    chunk_err,
                    exc_info=True,
                )

            await self._report_callback(
                request.platform_api_url,
                request.execution_id,
                status="COMPLETED",
                result=execution_outcome.content,
            )
            return AERExecuteResponse(status="completed", result=execution_outcome.content)

        except HTTPException:
            raise
        except Exception as e:
            log_execution_callback(request.execution_id, "ERROR", error=str(e), prefix="AER")
            await self._report_callback(
                request.platform_api_url,
                request.execution_id,
                status="ERROR",
                error=str(e),
            )
            raise HTTPException(status_code=500, detail=str(e))

        finally:
            # Clean up execution context
            self._chunk_seq.pop(request.execution_id, None)
            await wrapper.close()
            clear_execution_context(context_tokens)

    async def _post_chunk_with_retries(
        self,
        client: httpx.AsyncClient,
        url: str,
        payload: Dict[str, Any],
        *,
        max_attempts: int = MAX_CHUNK_POST_ATTEMPTS,
        base_delay: float = CHUNK_POST_BASE_DELAY_S,
    ) -> None:
        """POST ``payload`` to ``url`` with bounded exponential backoff.

        Retries on transient transport errors and 5xx responses. The
        retried exception set is:

        - ``httpx.ConnectError`` — TCP connection refused / reset.
        - ``httpx.TimeoutException`` — covers ``ConnectTimeout``,
          ``ReadTimeout``, ``WriteTimeout``, and ``PoolTimeout``.
        - ``httpx.RemoteProtocolError`` — server closed the connection
          mid-response.
        - 5xx ``httpx.HTTPStatusError`` responses.

        Does not retry on 4xx — those reflect a caller bug or stale
        endpoint, not a transient network condition. Raises the final
        exception on exhaustion.
        """
        last_exc: Optional[BaseException] = None
        for attempt in range(max_attempts):
            try:
                response = await client.post(url, json=payload)
                response.raise_for_status()
                return
            except httpx.HTTPStatusError as e:
                if e.response.status_code < 500:
                    raise
                last_exc = e
            except (
                httpx.ConnectError,
                httpx.TimeoutException,
                httpx.RemoteProtocolError,
            ) as e:
                last_exc = e
            if attempt < max_attempts - 1:
                await asyncio.sleep(base_delay * (2**attempt))
        if last_exc is None:
            raise RuntimeError(
                f"_post_chunk_with_retries exhausted {max_attempts} attempts but recorded no exception"
            )
        raise last_exc

    async def _send_stream_chunk(
        self,
        oe_url: str,
        execution_id: str,
        chunk_type: str,
        content: str = "",
        error: str = "",
        metadata: Optional[Dict[str, JsonValue]] = None,
    ) -> None:
        """Send a streaming chunk to OE's /stream/chunk endpoint.

        ``metadata`` is forwarded verbatim to OE. See
        ``runner_shared.server.chunk_types`` for the canonical chunk_type
        values and the per-type metadata keys each event carries.

        Transient HTTP failures are retried with bounded exponential backoff
        (see ``_post_chunk_with_retries``). Terminal chunks (``done`` /
        ``error``) re-raise on exhaustion so the caller can recover; the
        caller is responsible for falling through to ``_report_callback`` so
        OE's ``exec.Status`` fallback can still synthesize a terminal SSE
        chunk from ``exec.Result`` / ``exec.Error``. Non-terminal chunks
        (``text`` / ``subagent_start`` / ``subagent_end``) log at WARNING on
        exhaustion and return; the run continues, the chunk is dropped.
        """
        seq = self._chunk_seq.get(execution_id, 0) + 1
        self._chunk_seq[execution_id] = seq

        client = await self._get_client()
        chunk = {
            "execution_id": execution_id,
            "chunk_type": chunk_type,
            "content": content,
            "error": error,
            "metadata": metadata or {},
            "seq": seq,
        }
        terminal = chunk_type in (DONE, ERROR)
        try:
            await self._post_chunk_with_retries(client, f"{oe_url}/stream/chunk", chunk)
        except Exception as e:
            if terminal:
                self._chunk_seq.pop(execution_id, None)
                raise
            logger.warning(
                "Failed to deliver %s chunk (seq=%d) to OE after retries: %s",
                chunk_type,
                seq,
                e,
            )
            return

        if terminal:
            self._chunk_seq.pop(execution_id, None)

    async def _emit_subagent_boundary(
        self,
        oe_url: str,
        execution_id: str,
        chunk_type: str,
        content_key: str,
        event_data: _SubagentBoundaryData,
    ) -> None:
        """Forward a subagent_start/subagent_end event to OE as a stream chunk."""
        # description/summary go into metadata, not content, so text accumulators
        # (CLI, UI) that append chunk.content without inspecting chunk_type don't
        # pick up structural boundary text as part of the agent's response.
        meta: dict[str, JsonValue] = {
            "source": str(event_data.get("source", "") or ""),
            "subagent_name": str(event_data.get("subagent_name", "") or ""),
            "tool_call_id": str(event_data.get("tool_call_id", "") or ""),
            content_key: str(event_data.get(content_key, "") or ""),
        }
        await self._send_stream_chunk(
            oe_url,
            execution_id,
            chunk_type=chunk_type,
            content="",
            metadata=meta,
        )

    async def _execute_via_agent_stream(
        self,
        agent: Any,
        ctx: RequestContext,
        agent_input: AgentInput,
        oe_url: str,
        execution_id: str,
    ) -> Union[InterruptResult, StreamingResult]:
        """Execute via BaseAgent.stream() and handle StreamEvents.

        This method iterates over the agent's streaming events and:
        - Streams "token" events to OE (with thinking token filtering)
        - Returns InterruptResult for "suspend" events (HITL)
        - Returns StreamingResult for "result" events (completion)

        Thinking tokens (``<think>...</think>``) are suppressed during
        streaming and stripped from the final content.

        Args:
            agent: BaseAgent instance (e.g., LangGraphBaseAgent)
            agent_input: Framework-neutral agent input
            oe_url: OE callback URL for streaming chunks
            execution_id: Execution ID for logging

        Returns:
            ``StreamingResult`` for normal completion (with sanitized
            ``content`` and raw ``messages`` for memory), or
            ``InterruptResult`` when the agent is suspended.
        """
        # Per-stream <think> filter state keyed by (source, tool_call_id).
        # source alone is insufficient: two parallel dispatches of the same-named
        # subagent share a source string but have distinct tool_call_ids, so their
        # thinking buffers must be isolated to prevent token cross-contamination.
        thinking_state: dict[tuple[str, str], tuple[str, bool]] = {}

        if not isinstance(agent_input.payload, dict):
            raise TypeError(f"Expected dict payload, got {type(agent_input.payload)}")

        terminal_outcome: Union[InterruptResult, StreamingResult, None] = None
        stream_iter = agent.execute(ctx, agent_input).__aiter__()

        try:
            while True:
                # Once the SDK yields result/suspend, drive the iterator one more
                # step so async generators can finish post-yield cleanup naturally.
                # Only that drain pass is bounded here; pre-terminal execution is
                # still governed by the normal request/execution timeout.
                draining_after_terminal = terminal_outcome is not None
                timeout_s = (
                    AGENT_STREAM_TERMINAL_DRAIN_TIMEOUT_S if draining_after_terminal else None
                )
                try:
                    next_event = stream_iter.__anext__()
                    stream_event = (
                        await asyncio.wait_for(next_event, timeout=timeout_s)
                        if timeout_s is not None
                        else await next_event
                    )
                except StopAsyncIteration:
                    break
                except asyncio.TimeoutError:
                    if draining_after_terminal:
                        logger.warning(
                            "Timed out draining agent stream after terminal event "
                            "for execution %s after %.1fs",
                            execution_id,
                            AGENT_STREAM_TERMINAL_DRAIN_TIMEOUT_S,
                        )
                        break
                    raise
                except Exception:
                    if draining_after_terminal:
                        logger.warning(
                            "Unexpected exception during post-terminal drain "
                            "for execution %s, ignoring",
                            execution_id,
                            exc_info=True,
                        )
                        break
                    raise

                if draining_after_terminal:
                    logger.warning(
                        "Ignoring agent stream event %s after terminal event for execution %s",
                        getattr(stream_event, "event", type(stream_event).__name__),
                        execution_id,
                    )
                    break

                if not isinstance(stream_event.data, dict):
                    raise TypeError(f"Expected dict event data, got {type(stream_event.data)}")
                event_data: dict[str, Any] = stream_event.data

                if stream_event.event == "token":
                    token_content = event_data.get("content", "")
                    source = str(event_data.get("source", "") or "")
                    tool_call_id = str(event_data.get("tool_call_id", "") or "")
                    if token_content:
                        state_key = (source, tool_call_id)
                        buf, inside = thinking_state.get(state_key, ("", False))
                        streamable, buf, inside = filter_thinking_tokens(token_content, buf, inside)
                        thinking_state[state_key] = (buf, inside)
                        if streamable:
                            await self._send_stream_chunk(
                                oe_url,
                                execution_id,
                                chunk_type=TEXT,
                                content=streamable,
                                metadata={
                                    "source": source,
                                    "tool_call_id": tool_call_id,
                                },
                            )

                elif stream_event.event == "subagent_start":
                    await self._emit_subagent_boundary(
                        oe_url,
                        execution_id,
                        chunk_type=SUBAGENT_START,
                        content_key="description",
                        event_data=cast(_SubagentBoundaryData, event_data),
                    )

                elif stream_event.event == "subagent_end":
                    await self._emit_subagent_boundary(
                        oe_url,
                        execution_id,
                        chunk_type=SUBAGENT_END,
                        content_key="summary",
                        event_data=cast(_SubagentBoundaryData, event_data),
                    )
                    source = str(event_data.get("source", "") or "")
                    tool_call_id = str(event_data.get("tool_call_id", "") or "")
                    thinking_state.pop((source, tool_call_id), None)

                elif stream_event.event == "suspend":
                    # The framework adapter owns all resume semantics. It places
                    # whatever it needs to resume (checkpoint id, function-call
                    # correlation, etc.) into an opaque ``metadata`` dict that the
                    # AER round-trips to the OE without inspecting.
                    raw_metadata = event_data.get("metadata")
                    metadata = dict(raw_metadata) if isinstance(raw_metadata, dict) else {}
                    terminal_outcome = InterruptResult(
                        suspend_payload=event_data.get("suspend_payload", {}),
                        metadata=metadata,
                    )
                    continue

                elif stream_event.event == "result":
                    content = strip_thinking(event_data.get("response", "") or "")
                    terminal_outcome = StreamingResult(
                        content=content,
                        messages=event_data.get("messages", []),
                    )
                    continue
        finally:
            await _aclose_stream_iter(stream_iter, execution_id)

        if terminal_outcome is not None:
            return terminal_outcome

        # Should not reach here - stream should yield result or suspend
        raise RuntimeError(
            f"Agent stream ended without result or suspend (execution_id={execution_id})"
        )

    async def _report_callback(
        self,
        oe_url: str,
        execution_id: str,
        status: str,
        result: Any = None,
        error: Optional[str] = None,
        suspend_reason: Optional[str] = None,
        suspend_context: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Report execution status to OE."""
        client = await self._get_client()
        callback = ExecutorCallbackRequest(
            execution_id=execution_id,
            status=status,
            result=result,
            error=error,
            suspend_reason=suspend_reason,
            suspend_context=suspend_context,
            metadata=metadata,
        )
        try:
            response = await client.post(f"{oe_url}/executor/callback", json=callback.model_dump())
            response.raise_for_status()
        except Exception as e:
            logger.error(f"Failed to report callback to OE: {e}", exc_info=True)
