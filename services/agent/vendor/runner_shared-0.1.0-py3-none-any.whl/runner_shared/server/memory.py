"""
Memory Server - HTTP server for mongomem memory operations.

The Memory Server provides HTTP endpoints for:
- Short-term memory (conversation turns)
- Semantic memory (facts, knowledge)
- Episodic memory (past experiences)
- Procedural memory (workflows, procedures)
- Document ingestion
- Context building
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Dict, Optional

from fastapi import FastAPI

from runner_shared.server.base import BaseServer

if TYPE_CHECKING:
    from runner_shared.runtime import TenantRuntime

logger = logging.getLogger(__name__)


class MemoryServer(BaseServer):
    """
    Memory Server for mongomem HTTP API.

    Provides REST endpoints for memory operations including:
    - STM (short-term memory)
    - Semantic memory
    - Episodic memory
    - Procedural memory
    - Context building
    """

    def __init__(self, runtime: "TenantRuntime"):
        """Initialize memory server."""
        super().__init__(runtime)
        self._engine: Optional[Any] = None  # MemoryEngine instance
        self._worker: Optional[Any] = None  # MongoMemWorker instance

        # Initialize memory engine and worker during construction
        # (before register_routes is called)
        self._initialize_memory()

    @property
    def mode_name(self) -> str:
        """Return the mode name."""
        return "memory-server"

    @property
    def default_port(self) -> int:
        """Return the default port for memory server."""
        return 8081

    def _initialize_memory(self) -> None:
        """Initialize memory engine and worker."""
        try:
            from runner_shared.server.mongomem_impl.main import (
                _build_llm,
                _detect_llm_provider,
                create_engine,
                create_worker,
            )

            # Build LLM first so engine.llm is set — required for extraction handlers
            detected = _detect_llm_provider()
            llm = _build_llm(*detected) if detected else None

            logger.info("Creating MemoryEngine...")
            self._engine = create_engine(llm=llm)

            logger.info("Creating MongoMemWorker...")
            self._worker = create_worker(self._engine)
            if self._worker is None:
                logger.warning(
                    "MongoMemWorker not created (no embedder or LLM) — "
                    "/api/v1/worker/process will return 204"
                )

            logger.info("Memory engine initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize memory engine: {e}", exc_info=True)
            raise

    def register_routes(self, app: FastAPI) -> None:
        """Register memory server routes by including routers directly."""
        if self._engine is None:
            logger.warning("Memory engine not initialized, routes will not be available")
            return

        # Store engine in app state for route handlers
        app.state.engine = self._engine

        # Store worker in app state for /worker/process endpoint
        app.state.worker = self._worker

        # Import and register all route modules directly
        from runner_shared.server.mongomem_impl.routes.v1 import (
            context,
            episodic,
            health,
            ingestion,
            procedural,
            retrieval,
            semantic,
            stm,
            taxonomic,
            user_context,
        )
        from runner_shared.server.mongomem_impl.routes.v1 import (
            worker as worker_routes,
        )

        # Include all routers (they already have /api/v1 prefix in their definitions)
        app.include_router(health.router, prefix="/api/v1", tags=["health"])
        app.include_router(semantic.router, prefix="/api/v1", tags=["semantic"])
        app.include_router(episodic.router, prefix="/api/v1", tags=["episodic"])
        app.include_router(procedural.router, prefix="/api/v1", tags=["procedural"])
        app.include_router(stm.router, prefix="/api/v1", tags=["stm"])
        app.include_router(retrieval.router, prefix="/api/v1", tags=["retrieval"])
        app.include_router(context.router, prefix="/api/v1", tags=["context"])
        app.include_router(ingestion.router, prefix="/api/v1", tags=["ingestion"])
        app.include_router(user_context.router, prefix="/api/v1", tags=["user_context"])
        app.include_router(taxonomic.router, prefix="/api/v1", tags=["taxonomic"])
        app.include_router(worker_routes.router, prefix="/api/v1", tags=["worker"])

        logger.info("Registered all mongomem routes with /api/v1 prefix")

    async def on_startup(self) -> None:
        """Called when server starts."""
        logger.info("Memory server starting up...")
        if self._worker is not None:
            self._worker.initialize()
            logger.info("MongoMemWorker initialized")
        logger.info("Memory server ready")

    async def on_shutdown(self) -> None:
        """Called when server shuts down."""
        logger.info("Memory server shutting down...")

        if self._worker is not None:
            self._worker.shutdown()
            self._worker = None
            logger.info("MongoMemWorker stopped")

        if self._engine is not None:
            logger.info("Cleaning up MemoryEngine...")
            self._engine = None

        logger.info("Memory server shutdown complete")

    def get_health_details(self) -> Dict[str, Any]:
        """Return memory server health details."""
        mongodb_connected = False

        # Check if engine is initialized and connected
        if self._engine is not None:
            try:
                # Try to ping MongoDB through the engine
                self._engine._db.command("ping")
                mongodb_connected = True
            except Exception as e:
                logger.warning(f"MongoDB health check failed: {e}")
                mongodb_connected = False

        return {
            "mode": "memory-server",
            "mongodb_connected": mongodb_connected,
            "engine_initialized": self._engine is not None,
        }
