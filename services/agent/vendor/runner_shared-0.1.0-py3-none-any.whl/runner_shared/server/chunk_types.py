"""Wire-protocol constants for AER → OE stream chunks.

Centralized so a typo in one site can't silently desync the consumer.
Values are stable strings forwarded verbatim through OE to the API gateway
and on to the UI; do not rename without coordinating across all three
layers (and the Go-side ``StreamChunk`` model).
"""

from __future__ import annotations

__all__ = ["DONE", "ERROR", "STEP", "SUBAGENT_END", "SUBAGENT_START", "TEXT"]

# Token of agent output (post-``<think>`` filter, per-source state).
TEXT = "text"

# Subagent lifecycle markers — emitted only when guardrails are disabled.
SUBAGENT_START = "subagent_start"
SUBAGENT_END = "subagent_end"

# Mid-execution progress update emitted by tool functions via emit_step().
STEP = "step"

# Stream terminators.
DONE = "done"
ERROR = "error"
