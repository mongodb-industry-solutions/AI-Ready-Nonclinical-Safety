"""
Tool Executor server - Executes tool functions in isolated pods.

The Tool Executor is responsible for:
- Executing registered tool functions
- Running tools that need special permissions (network, secrets)
- Executing LLM calls routed from AER via SecureWrappedLLM
- Returning results to OE
"""

from __future__ import annotations

import logging
import time
from typing import Any, AsyncGenerator, Dict, List, Optional

from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from magenta_sdk_core.models import LLMStreamChunk, LLMToolSchema, Message, ToolCallChunk

from runner_shared.guardrails_evaluator import evaluate_guardrail_check
from runner_shared.hooks import (
    get_llm_adapter_factory,
    get_named_llm,
    has_named_llms,
    register_llm,
    reset_llm_registry,
    snapshot_llm_registry,
)
from runner_shared.metrics import with_metrics
from runner_shared.models import (
    GuardrailCheckRequest,
    GuardrailCheckResponse,
    LLMPodInvokeRequest,
    LLMPodInvokeResponse,
    LLMPodStreamEvent,
    ToolPodExecuteRequest,
    ToolPodExecuteResponse,
    ToolsListResponse,
)
from runner_shared.secure_llm_proxy import SecureLLMProxy
from runner_shared.server.base import BaseServer
from runner_shared.toolpod_handlers import BUILTIN_TOOL_NAMES
from runner_shared.utils import (
    LLM_BACKOFF_MULTIPLIER,
    LLM_INITIAL_BACKOFF,
    LLM_MAX_BACKOFF,
    LLM_MAX_RETRIES,
    is_retryable_error,
    log_tool_request,
    normalize_tool_call_args,
)

logger = logging.getLogger(__name__)


def _deserialize_messages(messages: list[Message]) -> list[Message]:
    """Return typed sdk-core Message objects validated by LLMPodInvokeRequest."""
    return list(messages)


def _coerce_stream_chunk(chunk: Any) -> LLMStreamChunk:
    """Normalize adapter or LangChain stream output into sdk-core's LLMStreamChunk."""
    if isinstance(chunk, LLMStreamChunk):
        return chunk

    if isinstance(chunk, dict):
        return LLMStreamChunk.model_validate(chunk)

    content = chunk.content if isinstance(getattr(chunk, "content", None), str) else None

    tool_calls: list[ToolCallChunk] = []
    for index, tool_call in enumerate(getattr(chunk, "tool_call_chunks", None) or []):
        if not isinstance(tool_call, dict):
            continue
        tool_calls.append(
            ToolCallChunk(
                id=tool_call.get("id"),
                name=tool_call.get("name"),
                args=normalize_tool_call_args(tool_call.get("args")),
                type=tool_call.get("type"),
                index=tool_call.get("index", index),
            )
        )

    if not tool_calls:
        for index, tool_call in enumerate(getattr(chunk, "tool_calls", None) or []):
            if not isinstance(tool_call, dict):
                continue
            tool_calls.append(
                ToolCallChunk(
                    id=tool_call.get("id"),
                    name=tool_call.get("name"),
                    args=normalize_tool_call_args(
                        tool_call.get("args", tool_call.get("arguments"))
                    ),
                    type=tool_call.get("type"),
                    index=tool_call.get("index", index),
                )
            )

    return LLMStreamChunk(
        content=content,
        tool_calls=tool_calls or None,
        usage=getattr(chunk, "usage", None),
        id=getattr(chunk, "id", None),
        name=getattr(chunk, "name", None),
        response_metadata=getattr(chunk, "response_metadata", None),
        additional_kwargs=getattr(chunk, "additional_kwargs", None),
    )


class ToolServer(BaseServer):
    """
    Tool Executor server - executes tool functions.

    Responsibilities:
    - Execute registered tool functions
    - Provide isolation for tools that need network/secrets
    - Return results to caller
    """

    @property
    def mode_name(self) -> str:
        return "tool"

    async def on_startup(self) -> None:
        """Register built-in tool handlers and populate the named-LLM registry from the user entrypoint."""
        from runner_shared import toolpod_handlers

        # ``features.deep_agent`` gates the built-in filesystem + shell
        # handlers. Tenants that don't opt in never get a file/shell attack
        # surface registered on their Tool-Pod — the platform stays
        # agent-type-agnostic and tenants pay only for what they use.
        deep_agent_enabled = self.runtime.agent_config.feature_enabled("deep_agent", default=False)
        if deep_agent_enabled:
            toolpod_handlers.register_builtin_tools(self.runtime)

            missing = BUILTIN_TOOL_NAMES - set(self.runtime._tools.keys())
            if missing:
                raise RuntimeError(
                    f"ToolServer startup: missing built-in tool handlers: "
                    f"{sorted(missing)}. Expected all of "
                    f"{sorted(BUILTIN_TOOL_NAMES)} to be registered by "
                    f"register_builtin_tools()."
                )
            logger.info(
                "Deep-agent built-in tools registered (features.deep_agent=true): %s",
                sorted(BUILTIN_TOOL_NAMES),
            )
        else:
            logger.info(
                "Deep-agent built-in tools NOT registered "
                "(features.deep_agent is off in agent.yaml)."
            )

        tools = list(self.runtime._tools.keys())
        logger.info(f"Registered tools: {tools}")

        # Always run the user's entrypoint to populate the named-LLM registry.
        # Reset first so import-time registrations don't collide if the entrypoint
        # re-registers them. If the entrypoint registers nothing, restore the
        # pre-reset snapshot (import-time-only agents must still work).
        graph_builder = self.runtime._graph_builder
        if graph_builder is not None:
            get_agent = getattr(graph_builder, "get_agent", None)
            if get_agent is not None:
                pre_snapshot = snapshot_llm_registry()
                reset_llm_registry()
                entrypoint_ok = False
                try:
                    get_agent()
                    entrypoint_ok = True
                except Exception:
                    logger.warning(
                        "Failed to run entrypoint for LLM registration; "
                        "/invoke_llm will fail if no LLM was registered",
                        exc_info=True,
                    )
                    if pre_snapshot:
                        for llm_id, llm in pre_snapshot.items():
                            register_llm(llm_id, llm)
                        logger.info(
                            "Entrypoint failed; restored %d import-time registration(s)",
                            len(pre_snapshot),
                        )

                if entrypoint_ok:
                    if has_named_llms():
                        logger.info("Named LLM registry populated from user entrypoint")
                    elif pre_snapshot:
                        for llm_id, llm in pre_snapshot.items():
                            register_llm(llm_id, llm)
                        logger.info(
                            "Entrypoint registered no LLMs; "
                            "restored %d import-time registration(s)",
                            len(pre_snapshot),
                        )
                    else:
                        logger.warning(
                            "Entrypoint ran but did not call app.llm(); "
                            "/invoke_llm will fail until an LLM is registered"
                        )

    def get_health_details(self) -> Dict[str, Any]:
        return {
            "tools": list(self.runtime._tools.keys()),
            "tool_count": len(self.runtime._tools),
        }

    def register_routes(self, app: FastAPI) -> None:
        """Register Tool-specific routes."""
        server = self

        @app.post("/execute", response_model=ToolPodExecuteResponse)
        async def execute_tool(request: ToolPodExecuteRequest) -> ToolPodExecuteResponse:
            """Execute a registered tool function in this isolated pod.

            Runs the named tool with the provided arguments. Tools are registered
            via the Runner SDK ``app.tool()`` decorator and execute with the pod's
            network and secret access.
            """
            return await server._handle_execute(request)

        @app.post("/invoke_llm", response_model=LLMPodInvokeResponse)
        async def invoke_llm(request: LLMPodInvokeRequest) -> LLMPodInvokeResponse:
            """Invoke an LLM and return the complete response.

            Collects the full streaming response from the configured LLM provider,
            including token usage. Used by SecureWrappedLLM when streaming is not
            needed by the caller.
            """
            return await server._handle_invoke_llm(request)

        @app.post("/invoke_llm/stream")
        async def invoke_llm_stream(request: LLMPodInvokeRequest) -> StreamingResponse:
            """Stream an LLM response from this tool pod via Server-Sent Events.

            Returns a streaming response of ``LLMPodStreamEvent`` JSON objects,
            one per SSE ``data:`` line. The final event has ``done=true`` and
            includes token usage and timing metadata.
            """
            return StreamingResponse(
                server._handle_invoke_llm_stream(request),
                media_type="text/event-stream",
                headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
            )

        @app.post("/guardrails/check", response_model=GuardrailCheckResponse)
        async def check_guardrails(request: GuardrailCheckRequest) -> GuardrailCheckResponse:
            """Evaluate selected guardrail policies for OE-controlled runtime content."""
            return await server._handle_guardrails_check(request)

        @app.get("/tools", response_model=ToolsListResponse)
        async def list_tools() -> ToolsListResponse:
            """List all tools registered with this Tool Pod instance.

            Returns the tool definitions that were registered via the Runner SDK
            ``app.tool()`` decorator during agent initialization.
            """
            return ToolsListResponse(
                tools=[
                    {"name": name, **defn}
                    for name, defn in server.runtime._tool_definitions.items()
                ],
                count=len(server.runtime._tool_definitions),
            )

    @with_metrics("tool_pod_guardrails_check", record_errors=False)
    async def _handle_guardrails_check(
        self, request: GuardrailCheckRequest
    ) -> GuardrailCheckResponse:
        return evaluate_guardrail_check(request)

    @with_metrics("tool_pod_execute", record_errors=False)
    async def _handle_execute(self, request: ToolPodExecuteRequest) -> ToolPodExecuteResponse:
        """Execute a tool function."""
        import asyncio
        import socket

        from runner_shared.context import (
            clear_execution_context,
            get_current_execution_metadata,
            set_execution_context,
        )

        log_tool_request(
            request.tool_name or "(empty)", request.arguments, step=0, prefix="TOOL_POD"
        )

        pod_name = socket.gethostname()

        if not request.tool_name:
            return ToolPodExecuteResponse(
                status="error", error="Tool name cannot be empty", pod_name=pod_name
            )

        func = self.runtime._tools.get(request.tool_name)
        if not func:
            from runner_shared.mcp_tools import MCPConfigError, is_configured_mcp_sdk_tool_name

            mcp_server_name = request.metadata.get("mcp_server")
            mcp_tool_name = request.metadata.get("mcp_tool")
            if (
                not isinstance(mcp_server_name, str)
                or mcp_server_name == ""
                or not isinstance(mcp_tool_name, str)
                or mcp_tool_name == ""
            ):
                if is_configured_mcp_sdk_tool_name(
                    self.runtime.agent_config.mcp,
                    request.tool_name,
                ):
                    return ToolPodExecuteResponse(
                        status="error",
                        error=(
                            f"mcp tool {request.tool_name!r} is missing discovered "
                            "MCP call metadata (mcp_server, mcp_tool). Ensure AER has "
                            "been upgraded to send MCP tool identity."
                        ),
                        pod_name=pod_name,
                    )
                return ToolPodExecuteResponse(
                    status="error", error=f"Unknown tool: {request.tool_name}", pod_name=pod_name
                )

            try:
                func = self._configured_mcp_tool(
                    request.tool_name,
                    mcp_server_name,
                    mcp_tool_name,
                )
            except MCPConfigError as exc:
                return ToolPodExecuteResponse(status="error", error=str(exc), pod_name=pod_name)
            except Exception as exc:
                logger.exception("Unexpected error resolving MCP tool %r", request.tool_name)
                return ToolPodExecuteResponse(status="error", error=str(exc), pod_name=pod_name)
            if not func:
                return ToolPodExecuteResponse(
                    status="error", error=f"Unknown tool: {request.tool_name}", pod_name=pod_name
                )

        context_tokens = set_execution_context(
            execution_id=request.execution_id,
            wrapper=None,
            oe_url=request.oe_url or "",
            user_id=request.user_id,
            session_id=request.session_id,
            authorization=request.authorization,
            custom_headers=request.custom_headers,
            payload=request.payload,
        )

        try:
            if asyncio.iscoroutinefunction(func):
                result = await func(**request.arguments)
            else:
                # Off-load sync handlers to the default thread-pool so a
                # single blocking tool (filesystem, shell) does not stall
                # the event loop and serialize concurrent specialist
                # fan-out in deep-agent workflows.
                result = await asyncio.to_thread(func, **request.arguments)
            metadata = get_current_execution_metadata()
            return ToolPodExecuteResponse(
                status="success",
                result=result,
                pod_name=pod_name,
                metadata=metadata,
            )

        except Exception as e:
            metadata = get_current_execution_metadata()
            return ToolPodExecuteResponse(
                status="error",
                error=str(e),
                pod_name=pod_name,
                metadata=metadata,
            )

        finally:
            clear_execution_context(context_tokens)

    def _configured_mcp_tool(
        self,
        sdk_tool_name: str,
        mcp_server_name: str,
        mcp_tool_name: str,
    ) -> Any | None:
        """Return a Tool Pod callable for an MCP tool configured in agent.yaml.

        Tool Pods intentionally skip remote ``tools/list`` discovery during startup.
        They only need to execute the server-prefixed tool name OE sends after AER
        has already discovered and bound the schema.
        """
        from runner_shared.mcp_tools import (
            make_mcp_tool_pod_callable,
            resolve_configured_mcp_tool_binding,
        )

        binding = resolve_configured_mcp_tool_binding(
            self.runtime.agent_config.mcp,
            sdk_tool_name,
            mcp_server_name,
            mcp_tool_name,
        )
        if binding is None:
            return None
        return make_mcp_tool_pod_callable(binding)

    def _create_llm_for_pod(
        self,
        llm_id: str,
        tools: Optional[List[LLMToolSchema]] = None,
    ) -> Any:
        """Create a BaseLLM-compatible instance for tool pod execution.

        Retrieves the named LLM from the registry (registered via
        ``app.llm(llm, llm_id=...)``) and wraps it through the registered
        adapter factory. No SecureWrappedLLM needed — OE approval already
        happened in AER.
        """
        llm = get_named_llm(llm_id)
        return get_llm_adapter_factory()(llm, tools=tools)

    @with_metrics("llm_pod_invoke", record_errors=False)
    async def _handle_invoke_llm(self, request: LLMPodInvokeRequest) -> LLMPodInvokeResponse:
        """Execute an LLM call by collecting the streaming execution path."""
        import socket

        pod_name = socket.gethostname()
        start_time = time.time()

        try:
            chunks = [chunk async for chunk in self._stream_llm_chunks(request)]
            llm_response = SecureLLMProxy.response_from_stream_chunks(chunks)
            duration_ms = (time.time() - start_time) * 1000
            return LLMPodInvokeResponse(
                status="success",
                result=llm_response,
                pod_name=pod_name,
                duration_ms=duration_ms,
                usage=llm_response.usage,
            )

        except Exception as e:
            duration_ms = (time.time() - start_time) * 1000
            return LLMPodInvokeResponse(
                status="error",
                error=str(e),
                pod_name=pod_name,
                duration_ms=duration_ms,
            )

    async def _stream_llm_chunks(
        self, request: LLMPodInvokeRequest
    ) -> AsyncGenerator[LLMStreamChunk, None]:
        """Yield typed LLM stream chunks with retry-before-first-delta semantics."""
        import asyncio

        invoke_args = request.arguments
        llm = self._create_llm_for_pod(invoke_args.llm_id, invoke_args.tools)
        messages = _deserialize_messages(invoke_args.messages)
        extra_kwargs = invoke_args.options.to_model_kwargs() if invoke_args.options else {}

        last_error: Exception | None = None
        stream_started = False
        usage = None

        for attempt in range(LLM_MAX_RETRIES):
            try:
                stream = llm.astream(
                    messages,
                    stop=invoke_args.stop_sequences,
                    **extra_kwargs,
                )

                async for chunk in stream:
                    stream_chunk = _coerce_stream_chunk(chunk)
                    stream_started = True
                    if (
                        stream_chunk.content
                        or stream_chunk.tool_calls
                        or stream_chunk.id is not None
                        or stream_chunk.name is not None
                        or stream_chunk.response_metadata is not None
                        or stream_chunk.additional_kwargs is not None
                    ):
                        yield stream_chunk
                    if stream_chunk.usage is not None:
                        usage = stream_chunk.usage

                if usage is not None:
                    yield LLMStreamChunk(usage=usage)
                return

            except Exception as e:
                last_error = e
                if not stream_started and is_retryable_error(e) and attempt < LLM_MAX_RETRIES - 1:
                    backoff = min(
                        LLM_INITIAL_BACKOFF * (LLM_BACKOFF_MULTIPLIER**attempt),
                        LLM_MAX_BACKOFF,
                    )
                    logger.warning(
                        f"LLM Pod Stream: Rate limited (attempt {attempt + 1}/{LLM_MAX_RETRIES}). "
                        f"Retrying in {backoff:.1f}s..."
                    )
                    await asyncio.sleep(backoff)
                    continue
                break

        if last_error is not None:
            raise last_error
        raise RuntimeError("Failed to create LLM stream")

    async def _handle_invoke_llm_stream(
        self, request: LLMPodInvokeRequest
    ) -> AsyncGenerator[str, None]:
        """Stream LLM response as SSE events."""
        import socket

        pod_name = socket.gethostname()
        start_time = time.time()

        try:
            usage = None
            async for stream_chunk in self._stream_llm_chunks(request):
                if stream_chunk.usage is not None:
                    usage = stream_chunk.usage
                if not (
                    stream_chunk.content
                    or stream_chunk.tool_calls
                    or stream_chunk.id is not None
                    or stream_chunk.name is not None
                    or stream_chunk.response_metadata is not None
                    or stream_chunk.additional_kwargs is not None
                ):
                    continue
                chunk_event = LLMPodStreamEvent(
                    content=stream_chunk.content,
                    tool_call_chunks=stream_chunk.tool_calls,
                    id=stream_chunk.id,
                    name=stream_chunk.name,
                    response_metadata=stream_chunk.response_metadata,
                    additional_kwargs=stream_chunk.additional_kwargs,
                )
                yield f"data: {chunk_event.model_dump_json(exclude_none=True)}\n\n"

            # Final summary event
            duration_ms = (time.time() - start_time) * 1000
            summary = LLMPodStreamEvent(
                done=True,
                pod_name=pod_name,
                duration_ms=duration_ms,
                usage=usage,
            )
            yield f"data: {summary.model_dump_json(exclude_none=True)}\n\n"

        except Exception as e:
            error_event = LLMPodStreamEvent(error=str(e))
            yield f"data: {error_event.model_dump_json(exclude_none=True)}\n\n"
