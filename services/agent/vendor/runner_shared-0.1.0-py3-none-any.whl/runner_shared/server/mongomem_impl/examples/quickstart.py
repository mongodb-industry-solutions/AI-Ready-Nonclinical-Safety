#!/usr/bin/env python3
"""
mongomem Quickstart - Get running in 5 minutes!

Prerequisites:
    1. MongoDB running locally (or set MONGOMEM_MONGO_URI)
    2. pip install mongomem

Run:
    python quickstart.py
"""

from mongomem_core import MemoryEngine

# ─────────────────────────────────────────────────────────────────────────────
# Step 1: Connect to MongoDB
# ─────────────────────────────────────────────────────────────────────────────

# Uses localhost:27017 by default, or set MONGOMEM_MONGO_URI env var
engine = MemoryEngine.from_env()

# Create collections and indexes (safe to run multiple times)
engine.bootstrap()

print("[OK] Connected to MongoDB")

# ─────────────────────────────────────────────────────────────────────────────
# Step 2: Store a conversation (Short-Term Memory)
# ─────────────────────────────────────────────────────────────────────────────

# Every call needs org_id and user_id for multi-tenancy
# For personal projects, just use "default" for both
ORG = "default"
USER = "me"

# User message
engine.write_turn(
    session_id="chat_001",
    role="user",
    content="What's the capital of France?",
    org_id=ORG,
    user_id=USER,
)

# Assistant response
engine.write_turn(
    session_id="chat_001",
    role="assistant",
    content="The capital of France is Paris.",
    org_id=ORG,
    user_id=USER,
)

print("[OK] Stored conversation in STM")

# ─────────────────────────────────────────────────────────────────────────────
# Step 3: Store a fact (Semantic Memory)
# ─────────────────────────────────────────────────────────────────────────────

result = engine.create_semantic(
    label="france-capital",
    text="Paris is the capital of France, with a population of 2.1 million.",
    org_id=ORG,
    user_id=USER,
    source="quickstart-demo",
)

print(f"[OK] Stored fact: {result.label}")

# ─────────────────────────────────────────────────────────────────────────────
# Step 4: Store user preferences (User Context)
# ─────────────────────────────────────────────────────────────────────────────

result = engine.create_user_context(
    tone="friendly",
    style="concise",
    language="en",
    preferred_format="bullet_points",
    source="user_input",
    org_id=ORG,
    user_id=USER,
)

print("[OK] Stored user preferences")

# ─────────────────────────────────────────────────────────────────────────────
# Step 5: Query your data
# ─────────────────────────────────────────────────────────────────────────────

# Get the fact back
fact = engine.get_semantic(org_id=ORG, label="france-capital")
print(f"\nRetrieved fact: {fact.text}")

# Get user preferences
prefs = engine.get_user_context(org_id=ORG, user_id=USER)
print(f"User prefers: {prefs.tone} tone, {prefs.style} style")

# List all semantic memories
facts = engine.list_semantic(org_id=ORG, limit=10)
print(f"\nYou have {len(facts)} facts stored")

# ─────────────────────────────────────────────────────────────────────────────
# Done!
# ─────────────────────────────────────────────────────────────────────────────

print("""
Quickstart complete!

Next steps:
  1. Check your MongoDB - you'll see collections like:
     - memory_short_term (conversations)
     - memory_semantic (facts)
     - memory_user_context (preferences)

  2. Add an embedder for vector search:
     See examples/with_embeddings.py

  3. Run the worker for background processing:
     See examples/with_worker.py

  4. Try conversation thread retrieval:
     See examples/thread_retrieval.py

Docs: https://github.com/mongodb/mongomem
""")
