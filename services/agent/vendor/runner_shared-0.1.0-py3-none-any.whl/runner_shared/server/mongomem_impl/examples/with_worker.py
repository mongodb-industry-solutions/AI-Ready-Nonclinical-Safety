#!/usr/bin/env python3
"""
mongomem with Worker - Background processing for production!

The worker handles:
- Batch embedding generation
- STM -> Snapshot promotion
- Learning extraction (with LLM)
- Maintenance tasks

For development, you can skip the worker and use sync embedding.
For production, the worker provides better throughput and reliability.
"""

import time
from typing import List

# ─────────────────────────────────────────────────────────────────────────────
# Setup: Create embedder (required for worker)
# ─────────────────────────────────────────────────────────────────────────────


class SimpleEmbedder:
    """Simple embedder for demo purposes."""

    def __init__(self):
        self._dimension = 384

    def embed(self, text: str) -> List[float]:
        # In production, use a real embedding model
        import hashlib

        h = hashlib.sha384(text.encode()).digest()
        return [b / 255.0 for b in h]

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        return [self.embed(t) for t in texts]

    @property
    def dimension(self) -> int:
        return self._dimension

    @property
    def model_id(self) -> str:
        return "simple-sha384"


# ─────────────────────────────────────────────────────────────────────────────
# Option 1: Engine-only (sync, simpler)
# ─────────────────────────────────────────────────────────────────────────────


def engine_only_example():
    """
    Use engine without worker - everything happens synchronously.
    Good for: Development, small scale, simple use cases.
    """
    from mongomem_core import MemoryEngine
    from mongomem_core.config import Settings

    embedder = SimpleEmbedder()
    settings = Settings(embedding_dimension=embedder.dimension)
    engine = MemoryEngine(settings, embedder=embedder)
    engine.bootstrap()

    # Embeddings generated immediately (sync)
    result = engine.write_turn(
        session_id="chat_1",
        role="user",
        content="Hello world!",
        org_id="default",
        user_id="me",
    )
    print(f"Sync mode: has_embedding={result.has_embedding}")  # True immediately

    return engine


# ─────────────────────────────────────────────────────────────────────────────
# Option 2: Engine + Worker (async, production)
# ─────────────────────────────────────────────────────────────────────────────


def engine_with_worker_example():
    """
    Use engine with worker - writes are fast, processing is async.
    Good for: Production, high throughput, batch processing.
    """
    from mongomem_core import MemoryEngine
    from mongomem_core.config import Settings
    from mongomem_worker import MongoMemWorker

    embedder = SimpleEmbedder()
    settings = Settings(embedding_dimension=embedder.dimension)
    engine = MemoryEngine(settings, embedder=embedder)
    engine.bootstrap()

    # ─────────────────────────────────────────────────────────────────────
    # Fast writes (skip sync embedding)
    # ─────────────────────────────────────────────────────────────────────

    # This is fast - doesn't wait for embedding
    result = engine.create_semantic(
        label="fast-fact",
        text="This will be embedded by the worker later.",
        org_id="default",
        user_id="me",
        skip_embedding=True,  # Key: skip sync embedding
    )
    print(f"Async mode: has_embedding={result.has_embedding}")  # False initially

    # ─────────────────────────────────────────────────────────────────────
    # Start worker to process queue
    # ─────────────────────────────────────────────────────────────────────

    worker = MongoMemWorker(engine=engine)

    # Option A: Run in foreground (blocking)
    # worker.run()

    # Option B: Run in background thread
    worker.start_background()
    print("Worker started in background")

    # ... your app continues running ...

    time.sleep(2)  # Wait for worker to process

    # Check if embedding was generated
    fact = engine.get_semantic(org_id="default", label="fast-fact")
    print(f"After worker: has_embedding={fact.has_embedding}")  # True now!

    # Stop worker gracefully
    worker.stop()
    print("Worker stopped")

    return engine


# ─────────────────────────────────────────────────────────────────────────────
# Option 3: Worker CLI (production deployment)
# ─────────────────────────────────────────────────────────────────────────────

"""
For production, run the worker as a separate process:

    # Terminal 1: Your application
    python your_app.py

    # Terminal 2: Worker process
    mongomem-worker --embedder myapp.embedders.VoyageEmbedder

Or with custom configuration:

    mongomem-worker \\
        --embedder myapp.embedders.VoyageEmbedder \\
        --scaling-mode distributed \\
        --poll-interval 1.0 \\
        --batch-size 50

See `mongomem-worker --help` for all options.
"""


# ─────────────────────────────────────────────────────────────────────────────
# Worker vs Engine: When to use what?
# ─────────────────────────────────────────────────────────────────────────────

"""
+-----------------------------------------------------------------------------+
|                        Engine vs Worker Decision Tree                        |
+-----------------------------------------------------------------------------+
|                                                                              |
|  Are you in development/prototyping?                                         |
|    YES -> Use engine only (simpler)                                          |
|    NO  |                                                                     |
|        v                                                                     |
|  Do you need fast writes (< 50ms)?                                           |
|    YES -> Use worker (skip_embedding=True)                                   |
|    NO  -> Engine only is fine                                                |
|                                                                              |
|  Do you have high throughput (100+ writes/sec)?                              |
|    YES -> Use worker with distributed mode                                   |
|    NO  -> Engine only or single worker                                       |
|                                                                              |
|  Do you need LLM-based extraction?                                           |
|    YES -> Must use worker (async LLM calls)                                  |
|    NO  -> Engine only is fine                                                |
|                                                                              |
+-----------------------------------------------------------------------------+

Summary:
- Development: Engine only
- Production with low latency requirements: Engine + Worker
- Production with high throughput: Multiple workers (distributed mode)
"""


if __name__ == "__main__":
    print("=" * 60)
    print("Example 1: Engine-only (sync)")
    print("=" * 60)
    engine_only_example()

    print("\n" + "=" * 60)
    print("Example 2: Engine + Worker (async)")
    print("=" * 60)
    engine_with_worker_example()

    print("\n[OK] Examples complete!")
