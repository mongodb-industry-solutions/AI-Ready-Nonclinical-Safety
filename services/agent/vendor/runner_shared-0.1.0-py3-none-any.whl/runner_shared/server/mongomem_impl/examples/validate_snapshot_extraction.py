#!/usr/bin/env python3
"""
mongomem Validation Example - Snapshots + Worker Extraction

This example validates that:
1. Snapshots work correctly (STM → Snapshot promotion)
2. The worker is extracting data (semantic, episodic, taxonomic)
3. Embeddings are generated correctly
4. Change streams work with auto-extraction (M30+ cluster required)

================================================================================
SETUP INSTRUCTIONS
================================================================================

1. Create .env file with your configuration:

    # MongoDB Atlas M30+ cluster
    MONGODB_URI=mongodb+srv://user:password@cluster.mongodb.net/
    DB_NAME=your_database_name

    # LLM API key
    OPENAI_API_KEY=sk-...

    # Optional: Voyage AI for embeddings
    VOYAGE_API_KEY=pa-...

2. Run the validation:

    python examples/validate_snapshot_extraction.py

    # Test auto-extraction with change streams
    python examples/validate_snapshot_extraction.py --auto-extract

================================================================================
"""

import argparse
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List

# ─────────────────────────────────────────────────────────────────────────────
# Environment Setup
# ─────────────────────────────────────────────────────────────────────────────


def load_env_file() -> bool:
    """Load .env file from project root or src/ directory."""
    script_dir = Path(__file__).parent.absolute()
    project_root = script_dir.parent

    # Try multiple locations for .env file
    env_paths = [
        project_root / ".env",
        project_root / "src" / ".env",
        Path(".env"),
        Path("src/.env"),
    ]

    for env_path in env_paths:
        if env_path.exists():
            try:
                from dotenv import load_dotenv

                load_dotenv(env_path)
                print(f"[OK] Loaded .env from {env_path}")
            except ImportError:
                # Manually parse .env file
                print(f"[INFO] python-dotenv not installed, manually parsing {env_path}")
                with open(env_path) as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#") and "=" in line:
                            key, value = line.split("=", 1)
                            value = value.strip().strip("'\"")
                            os.environ[key.strip()] = value
                print(f"[OK] Loaded .env from {env_path}")
            return True

    print(f"[ERROR] No .env file found in {project_root}")
    return False


def get_mongo_uri() -> str:
    """Get MongoDB URI from environment."""
    uri = os.getenv("MONGOMEM_MONGO_URI") or os.getenv("MONGODB_URI")
    if not uri:
        print("[ERROR] MONGODB_URI not set in .env")
        sys.exit(1)
    return uri


def get_db_name() -> str:
    """Get database name from environment."""
    name = os.getenv("MONGOMEM_DB_NAME") or os.getenv("DB_NAME")
    if not name:
        print("[ERROR] DB_NAME not set in .env")
        sys.exit(1)
    return name


# ─────────────────────────────────────────────────────────────────────────────
# Embedder and LLM Setup
# ─────────────────────────────────────────────────────────────────────────────


def get_embedder():
    """Get embedder using Voyage AI or OpenAI."""
    voyage_key = os.getenv("VOYAGE_API_KEY")
    openai_key = os.getenv("OPENAI_API_KEY")

    if voyage_key:
        try:
            import voyageai

            class VoyageEmbedder:
                def __init__(self):
                    self._client = voyageai.Client(api_key=voyage_key)
                    self._dimension = 1024  # voyage-3 dimension
                    self._call_count = 0

                def embed(self, text: str) -> List[float]:
                    self._call_count += 1
                    result = self._client.embed([text], model="voyage-3")
                    return result.embeddings[0]

                def embed_batch(self, texts: List[str]) -> List[List[float]]:
                    self._call_count += 1
                    result = self._client.embed(texts, model="voyage-3")
                    return result.embeddings

                @property
                def dimension(self) -> int:
                    return self._dimension

                @property
                def model_id(self) -> str:
                    return "voyage-3"

                @property
                def call_count(self) -> int:
                    return self._call_count

            print("  Using Voyage AI embedder (voyage-3)")
            return VoyageEmbedder()
        except ImportError:
            print("[WARN] voyageai not installed, trying OpenAI")

    if openai_key:
        try:
            import openai

            class OpenAIEmbedder:
                def __init__(self):
                    self._client = openai.OpenAI(api_key=openai_key)
                    self._dimension = 1536  # text-embedding-3-small dimension
                    self._call_count = 0

                def embed(self, text: str) -> List[float]:
                    self._call_count += 1
                    response = self._client.embeddings.create(
                        input=text, model="text-embedding-3-small"
                    )
                    return response.data[0].embedding

                def embed_batch(self, texts: List[str]) -> List[List[float]]:
                    self._call_count += 1
                    response = self._client.embeddings.create(
                        input=texts, model="text-embedding-3-small"
                    )
                    return [item.embedding for item in response.data]

                @property
                def dimension(self) -> int:
                    return self._dimension

                @property
                def model_id(self) -> str:
                    return "text-embedding-3-small"

                @property
                def call_count(self) -> int:
                    return self._call_count

            print("  Using OpenAI embedder (text-embedding-3-small)")
            return OpenAIEmbedder()
        except ImportError:
            print("[ERROR] openai not installed")
            sys.exit(1)

    print("[ERROR] No embedding API key found (VOYAGE_API_KEY or OPENAI_API_KEY)")
    sys.exit(1)


def get_llm(model: str = "gpt-4o-mini"):
    """Get LLM using litellm."""
    try:
        import json

        import litellm

        openai_key = os.getenv("OPENAI_API_KEY")
        anthropic_key = os.getenv("ANTHROPIC_API_KEY")

        if not openai_key and not anthropic_key:
            print("[ERROR] No LLM API key found (OPENAI_API_KEY or ANTHROPIC_API_KEY)")
            sys.exit(1)

        # Auto-select model based on available keys
        if not openai_key and anthropic_key:
            model = "claude-3-5-sonnet-20241022"
            print(f"  Using Anthropic model: {model}")
        else:
            print(f"  Using model: {model}")

        class LiteLLM:
            def __init__(self, model_name: str):
                self._model = model_name
                self._call_count = 0

            def complete(self, prompt: str, **kwargs) -> str:
                self._call_count += 1
                response = litellm.completion(
                    model=self._model,
                    messages=[{"role": "user", "content": prompt}],
                    max_tokens=1000,
                )
                return response.choices[0].message.content or ""

            def complete_json(
                self, prompt: str, schema: Dict[str, Any], **kwargs
            ) -> Dict[str, Any]:
                self._call_count += 1
                json_prompt = prompt + "\n\nRespond with valid JSON only."
                response = litellm.completion(
                    model=self._model,
                    messages=[{"role": "user", "content": json_prompt}],
                    max_tokens=2000,
                    response_format={"type": "json_object"},
                )
                content = response.choices[0].message.content or "{}"
                content = content.strip()
                if content.startswith("```"):
                    lines = content.split("\n")
                    content = "\n".join(lines[1:-1] if lines[-1] == "```" else lines[1:])
                return json.loads(content)

            @property
            def model_id(self) -> str:
                return self._model

            @property
            def call_count(self) -> int:
                return self._call_count

        return LiteLLM(model)
    except ImportError:
        print("[ERROR] litellm not installed")
        sys.exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# Validation Functions
# ─────────────────────────────────────────────────────────────────────────────


def validate_snapshots(engine, org_id: str, user_id: str, project_id: str, session_id: str) -> bool:
    """
    Validate that snapshots work correctly.

    Tests:
    1. Write conversation turns to STM
    2. Promote STM to snapshot
    3. Verify snapshot was created with correct data
    """
    print("\n" + "=" * 60)
    print("VALIDATING SNAPSHOTS")
    print("=" * 60)

    # Step 1: Write conversation turns
    print("\n[1/3] Writing conversation turns...")

    turns = [
        ("user", "Hi! I'm working on a machine learning project."),
        ("assistant", "That's exciting! What type of ML project are you building?"),
        ("user", "I'm building a recommendation system using Python and PyTorch."),
        (
            "assistant",
            "Great choice! PyTorch is excellent for recommendation systems. "
            "Are you using collaborative filtering or content-based approaches?",
        ),
        (
            "user",
            "I'm using a hybrid approach. The model combines user behavior "
            "data with content features.",
        ),
        (
            "assistant",
            "A hybrid approach is smart. It can capture both user preferences "
            "and item characteristics. Do you need help with the implementation?",
        ),
    ]

    for role, content in turns:
        result = engine.write_turn(
            session_id=session_id,
            role=role,
            content=content,
            org_id=org_id,
            user_id=user_id,
        )
        print(f"  [OK] Wrote {role} turn (id={result.id[:8]}..., seq={result.turn_seq})")

    print(f"  Total turns written: {len(turns)}")

    # Step 2: Promote to snapshot
    print("\n[2/3] Promoting STM to snapshot...")

    promote_result = engine.promote_stm_to_snapshot(
        session_id=session_id,
        org_id=org_id,
        user_id=user_id,
        project_id=project_id,
        force=True,
    )

    if promote_result.snapshot_id:
        print(f"  [OK] Snapshot created: id={promote_result.snapshot_id[:8]}...")
        print(f"    Messages promoted: {promote_result.promoted_count}")
        print(f"    Reason: {promote_result.reason}")
        print(f"    Has embedding: {promote_result.has_embedding}")
    else:
        print(f"  [FAIL] Snapshot NOT created. Reason: {promote_result.reason}")
        return False

    # Step 3: Verify snapshot data
    print("\n[3/3] Verifying snapshot data...")

    snapshot = engine.get_snapshot(org_id=org_id, id=promote_result.snapshot_id)
    if snapshot:
        print("  [OK] Snapshot retrieved successfully")
        print(f"    Session ID: {snapshot.session_id}")
        print(f"    Message count: {len(snapshot.messages)}")
        print(f"    Reason: {snapshot.snapshot_reason}")
        print(f"    Has embedding: {snapshot.has_embedding}")

        print("\n  Messages in snapshot:")
        for i, msg in enumerate(snapshot.messages[:3]):
            content_preview = msg.content[:50] + "..." if len(msg.content) > 50 else msg.content
            print(f"    [{i + 1}] {msg.role}: {content_preview}")
        if len(snapshot.messages) > 3:
            print(f"    ... and {len(snapshot.messages) - 3} more messages")
    else:
        print("  [FAIL] Could not retrieve snapshot")
        return False

    print("\n[OK] SNAPSHOT VALIDATION PASSED")
    return True


def validate_worker_extraction(
    engine,
    org_id: str,
    user_id: str,
    session_id: str,
    snapshot_id: str,
) -> bool:
    """
    Validate that the worker extracts data correctly using distributed mode.
    """
    print("\n" + "=" * 60)
    print("VALIDATING WORKER EXTRACTION (Distributed Mode)")
    print("=" * 60)

    from mongomem_worker import MongoMemWorker
    from mongomem_worker.config import WorkerSettings
    from mongomem_worker.queue import enqueue_task

    # Get snapshot data
    snapshot = engine.get_snapshot(org_id=org_id, id=snapshot_id)
    if not snapshot:
        print("  ✗ Could not find snapshot for extraction")
        return False

    messages = [
        {"role": msg.role, "content": msg.content} for msg in snapshot.messages if msg.content
    ]

    # Step 1: Create worker
    print("\n[1/4] Creating worker with extraction handlers...")

    worker = MongoMemWorker(
        engine=engine,
        scaling_mode="distributed",
        extraction_config={
            "semantic": {"enabled": True},
            "episodic": {"enabled": True},
            "taxonomic": {"enabled": True},
        },
    )

    print("  [OK] Worker created")
    print("    Scaling mode: distributed")
    print(f"    Handlers: {list(worker.handlers.keys())}")

    # Step 2: Enqueue extraction tasks
    print("\n[2/4] Enqueueing extraction tasks...")

    base_payload = {
        "messages": messages,
        "org_id": org_id,
        "user_id": user_id,
        "source_id": snapshot_id,
    }

    settings = WorkerSettings(mongo_uri=engine.settings.mongo_uri, db_name=engine.settings.db_name)

    for task_type in ["semantic", "episodic", "taxonomic"]:
        enqueue_task(task_type, base_payload.copy(), settings=settings)
        print(f"  [OK] Enqueued {task_type} extraction task")

    # Step 3: Start worker and process tasks
    print("\n[3/4] Starting worker to process tasks...")

    worker.start_background()
    print("  Worker started in background thread")

    max_wait = 60
    check_interval = 1.0
    elapsed = 0
    db = engine.db

    while elapsed < max_wait:
        succeeded = db.tasks.count_documents({"status": "succeeded"})
        pending = db.tasks.count_documents({"status": {"$in": ["queued", "running"]}})
        failed = db.tasks.count_documents({"status": "failed"})

        print(
            f"  [t={elapsed:.0f}s] Tasks: {succeeded} succeeded, {pending} pending, {failed} failed"
        )

        if pending == 0:
            break

        time.sleep(check_interval)
        elapsed += check_interval

    worker.stop()
    time.sleep(0.5)
    print("  Worker stopped")

    # Step 4: Verify extracted data
    print("\n[4/4] Verifying extracted data...")

    all_passed = True

    semantic_count = db.memory_semantic.count_documents({"org_id": org_id, "user_id": user_id})
    if semantic_count > 0:
        print(f"  [OK] Semantic memories extracted: {semantic_count}")
        semantics = list(db.memory_semantic.find({"org_id": org_id}).limit(2))
        for sem in semantics:
            text = sem.get("text", "")
            text_preview = text[:60] + "..." if len(text) > 60 else text
            print(f"    - {text_preview}")
    else:
        print("  [WARN] No semantic memories extracted")

    episodic_count = db.memory_episodic.count_documents({"org_id": org_id, "user_id": user_id})
    if episodic_count > 0:
        print(f"  [OK] Episodic memories extracted: {episodic_count}")
        episodes = list(db.memory_episodic.find({"org_id": org_id}).limit(2))
        for ep in episodes:
            title = ep.get("title", "Untitled")
            print(f"    - {title}")
    else:
        print("  [WARN] No episodic memories extracted")

    taxonomic_count = db.memory_taxonomic.count_documents({"org_id": org_id, "user_id": user_id})
    if taxonomic_count > 0:
        print(f"  [OK] Taxonomic memories extracted: {taxonomic_count}")
        terms = list(db.memory_taxonomic.find({"org_id": org_id}).limit(2))
        for term in terms:
            term_name = term.get("term", "Unknown")
            domain = term.get("domain", "General")
            print(f"    - {term_name} ({domain})")
    else:
        print("  [WARN] No taxonomic memories extracted")

    # Check task statuses
    print("\n  Task Summary:")
    for task_type in ["semantic", "episodic", "taxonomic"]:
        task = db.tasks.find_one({"task_type": task_type})
        if task:
            status = task.get("status", "unknown")
            attempts = task.get("max_retries", 3) - task.get("remaining_retries", 0)
            print(f"    {task_type}: {status} (attempts={attempts})")
            if status == "failed":
                error = task.get("last_error", "unknown error")
                print(f"      Error: {error[:100]}...")
                all_passed = False

    if all_passed:
        print("\n[OK] WORKER EXTRACTION VALIDATION PASSED")
    else:
        print("\n[WARN] WORKER EXTRACTION HAD SOME ISSUES")

    return all_passed


def validate_auto_extraction(
    engine,
    org_id: str,
    user_id: str,
    project_id: str,
) -> bool:
    """
    Validate auto-extraction via change streams.
    """
    print("\n" + "=" * 60)
    print("VALIDATING AUTO-EXTRACTION (Change Streams)")
    print("=" * 60)

    from mongomem_worker import MongoMemWorker

    session_id = f"auto-extract-{int(time.time())}"

    # Step 1: Create worker with auto-extraction
    print("\n[1/4] Creating worker with auto-extraction...")

    worker = MongoMemWorker(
        engine=engine,
        scaling_mode="distributed",
        extraction_config={
            "semantic": {"enabled": True},
            "episodic": {"enabled": True},
            "taxonomic": {"enabled": True},
        },
    )
    worker._config.auto_extract_on_snapshot = True

    print("  [OK] Worker created with auto-extraction")
    print(f"    Mode: {worker._config.extraction_mode}")

    # Step 2: Start worker
    print("\n[2/4] Starting worker (watching for snapshots)...")
    worker.start_background()
    time.sleep(2)
    print("  [OK] Worker running in background")

    # Step 3: Create new snapshot
    print("\n[3/4] Creating snapshot (should trigger auto-extraction)...")

    turns = [
        ("user", "I'm learning about neural networks."),
        ("assistant", "Neural networks are great! What aspect interests you?"),
        ("user", "I want to understand backpropagation and gradient descent."),
    ]

    for role, content in turns:
        engine.write_turn(
            session_id=session_id,
            role=role,
            content=content,
            org_id=org_id,
            user_id=user_id,
        )

    result = engine.promote_stm_to_snapshot(
        session_id=session_id, org_id=org_id, user_id=user_id, project_id=project_id, force=True
    )

    if result.snapshot_id:
        print(f"  [OK] Snapshot created: {result.snapshot_id[:8]}...")
    else:
        print("  [FAIL] Failed to create snapshot")
        worker.stop()
        return False

    # Step 4: Wait for auto-extraction
    print("\n[4/4] Waiting for auto-extraction tasks...")

    db = engine.db
    max_wait = 60
    check_interval = 2.0
    elapsed = 0

    while elapsed < max_wait:
        task_count = db.tasks.count_documents({"payload.source_id": result.snapshot_id})
        succeeded = db.tasks.count_documents(
            {"payload.source_id": result.snapshot_id, "status": "succeeded"}
        )

        if task_count > 0:
            print(
                f"  [t={elapsed:.0f}s] Tasks for snapshot: {task_count} total, {succeeded} succeeded"
            )
            if succeeded >= 3:
                # We have enough succeeded tasks to consider auto-extraction working,
                # but do not stop the worker yet — allow in-flight tasks to finish to
                # avoid executor shutdown errors.
                break
        else:
            print(f"  [t={elapsed:.0f}s] Waiting for extraction tasks...")

        time.sleep(check_interval)
        elapsed += check_interval

    # Gracefully wait for in-flight tasks to settle before stopping the worker.
    # This prevents errors like "cannot schedule new futures after shutdown".
    print("\n  Waiting for in-flight tasks to settle before stopping worker...")
    settle_max_wait = 30
    settle_interval = 1.0
    settle_elapsed = 0.0
    while settle_elapsed < settle_max_wait:
        pending = db.tasks.count_documents(
            {
                "payload.source_id": result.snapshot_id,
                "status": {"$in": ["queued", "running"]},
            }
        )
        if pending == 0:
            break
        time.sleep(settle_interval)
        settle_elapsed += settle_interval

    worker.stop()
    time.sleep(1.0)

    task_count = db.tasks.count_documents({"payload.source_id": result.snapshot_id})

    if task_count > 0:
        print(f"\n  [OK] Auto-extraction triggered: {task_count} tasks created")
        print("\n[OK] AUTO-EXTRACTION VALIDATION PASSED")
        return True
    else:
        print("\n  [WARN] No auto-extraction tasks were created")
        print("    This may indicate change streams are not available.")
        return False


def validate_embedding_flow(engine, embedder, org_id: str, user_id: str) -> bool:
    """
    Validate that embeddings are generated correctly.
    """
    print("\n" + "=" * 60)
    print("VALIDATING EMBEDDING FLOW")
    print("=" * 60)

    from mongomem_core.models.config.snapshot_config import SnapshotConfig
    from mongomem_core.pipelines.stm_to_snapshot import promote_stm_to_snapshot

    session_id = f"embed-test-{int(time.time())}"

    print("\n[1/2] Creating snapshot with 'generate' embedding strategy...")

    for i in range(3):
        engine.write_turn(
            session_id=session_id,
            role="user" if i % 2 == 0 else "assistant",
            content=f"Test message {i} for embedding validation.",
            org_id=org_id,
            user_id=user_id,
        )

    snapshot_config = SnapshotConfig(embedding_strategy="generate")

    snapshot = promote_stm_to_snapshot(
        db=engine.db,
        session_id=session_id,
        org_id=org_id,
        user_id=user_id,
        config=snapshot_config,
        embedder=embedder,
        force=True,
    )

    if not snapshot:
        print("  ✗ Could not create snapshot")
        return False

    print(f"  [OK] Snapshot created: {str(snapshot.id)[:8]}...")
    print(f"    Has embedding: {snapshot.has_embedding}")

    print("\n[2/2] Verifying embedding generation...")

    if snapshot.has_embedding:
        print("  [OK] Embedding generated successfully")
        print(f"    Dimension: {snapshot.embedding_dimension}")
        print(f"    Model: {snapshot.embedding_model_id}")
        print(f"    Strategy: {snapshot.embedding_strategy}")
        print("\n[OK] EMBEDDING FLOW VALIDATION PASSED")
        return True
    else:
        print("  [FAIL] Embedding was not generated")
        return False


def validate_build_context(engine, org_id: str, user_id: str, session_id: str) -> bool:
    """
    Validate that build_context works with vector search.
    """
    print("\n" + "=" * 60)
    print("VALIDATING BUILD_CONTEXT (Vector Search)")
    print("=" * 60)

    print("\n[1/2] Calling build_context...")

    try:
        context = engine.build_context(
            query="What is the user working on?",
            session_id=session_id,
            org_id=org_id,
            user_id=user_id,
        )

        print("  [OK] build_context completed successfully")

        # Get formatted context (can be string or list of messages)
        formatted = context.formatted_context
        if isinstance(formatted, str):
            context_text = formatted
        elif isinstance(formatted, list):
            # OpenAI messages format
            context_text = "\n".join(
                msg.get("content", "") for msg in formatted if isinstance(msg, dict)
            )
        else:
            context_text = str(formatted)

        print(f"    Context length: {len(context_text)} characters")
        print(f"    Token count: {context.metadata.token_count}")
        print(f"    Memory sources: {context.metadata.memory_counts}")

        print("\n[2/2] Verifying context content...")

        if context_text:
            preview = context_text[:300] + "..." if len(context_text) > 300 else context_text
            print("  Context preview:")
            for line in preview.split("\n")[:6]:
                if line.strip():
                    print(f"    {line[:80]}")

            print("\n[OK] BUILD_CONTEXT VALIDATION PASSED")
            return True
        else:
            print("  [WARN] Context is empty (may need more data or wait for indexes)")
            return True  # Not a failure, just no data yet

    except Exception as e:
        error_str = str(e)
        if "SearchNotEnabled" in error_str or "vectorSearch" in error_str:
            print("  [WARN] Vector search not available yet")
            print("    Search indexes may still be building.")
            print("    Try again in a few minutes.")
            return False
        elif "needs to be indexed" in error_str:
            print("  [WARN] Search index still building")
            print("    Wait a few minutes and try again.")
            return False
        else:
            print(f"  [FAIL] build_context failed: {e}")
            return False


# ─────────────────────────────────────────────────────────────────────────────
# Main Entry Point
# ─────────────────────────────────────────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser(
        description="Validate mongomem snapshots and worker extraction"
    )
    parser.add_argument(
        "--model",
        type=str,
        default="gpt-4o-mini",
        help="LLM model to use (default: gpt-4o-mini)",
    )
    parser.add_argument(
        "--auto-extract",
        action="store_true",
        help="Test auto-extraction via change streams (requires M30+ cluster)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose logging",
    )
    args = parser.parse_args()

    print("=" * 60)
    print("MONGOMEM VALIDATION SCRIPT")
    print("=" * 60)

    # Load .env file
    if not load_env_file():
        sys.exit(1)

    # Setup logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # Quiet down noisy loggers
    logging.getLogger("pymongo").setLevel(logging.WARNING)
    logging.getLogger("mongomem_worker").setLevel(logging.INFO)
    logging.getLogger("mongomem_core").setLevel(logging.INFO)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("litellm").setLevel(logging.WARNING)

    # Get configuration
    mongo_uri = get_mongo_uri()
    db_name = get_db_name()

    # Initialize embedder and LLM
    print("\nInitializing embedder and LLM...")
    embedder = get_embedder()
    llm = get_llm(model=args.model)

    # Import mongomem components
    from mongomem_core import MemoryEngine
    from mongomem_core.config import Settings

    print("\nConfiguration:")
    print(f"  MongoDB: {mongo_uri[:60]}...")
    print(f"  Database: {db_name}")
    print(f"  Embedder: {embedder.model_id} (dim={embedder.dimension})")
    print(f"  LLM: {llm.model_id}")

    # Create engine
    settings = Settings(
        mongo_uri=mongo_uri,
        db_name=db_name,
        embedding_dimension=embedder.dimension,
    )
    engine = MemoryEngine(settings, embedder=embedder, llm=llm)

    # Bootstrap database (including Atlas Search indexes)
    print("\nBootstrapping database...")
    print("  Creating collections and B-tree indexes...")
    engine.bootstrap(ensure_search_indexes=True, wait_for_indexes_ready=False)
    print("[OK] Database bootstrapped")
    print("  Note: Search indexes are created but may take a few minutes to become ready.")

    # Test identifiers
    org_id = "test-org"
    user_id = "test-user"
    project_id = "test-project"
    session_id = f"session-{int(time.time())}"

    # Run validations
    results = {}

    # 1. Validate snapshots
    results["snapshots"] = validate_snapshots(engine, org_id, user_id, project_id, session_id)

    # Get snapshot ID for extraction test
    snapshots = engine.list_snapshots(org_id=org_id, session_id=session_id, limit=1)
    if snapshots:
        snapshot_id = str(snapshots[0].id)

        # 2. Validate worker extraction
        results["extraction"] = validate_worker_extraction(
            engine, org_id, user_id, session_id, snapshot_id
        )

    # 3. Validate embedding flow
    results["embeddings"] = validate_embedding_flow(engine, embedder, org_id, user_id)

    # 4. Validate build_context (vector search)
    results["build_context"] = validate_build_context(engine, org_id, user_id, session_id)

    # 5. Validate auto-extraction (optional)
    if args.auto_extract:
        results["auto_extraction"] = validate_auto_extraction(engine, org_id, user_id, project_id)

    # Summary
    print("\n" + "=" * 60)
    print("VALIDATION SUMMARY")
    print("=" * 60)

    all_passed = True
    for test_name, passed in results.items():
        status = "[OK] PASSED" if passed else "[FAIL] FAILED"
        print(f"  {test_name}: {status}")
        if not passed:
            all_passed = False

    print()
    if all_passed:
        print("[OK] ALL VALIDATIONS PASSED\n")
    else:
        print("[WARN] SOME VALIDATIONS FAILED\n")

    # Show database stats
    print("Database Statistics:")
    print(f"  Short-term memories: {engine.db.memory_short_term.count_documents({})}")
    print(f"  Snapshots: {engine.db.memory_snapshot.count_documents({})}")
    print(f"  Semantic memories: {engine.db.memory_semantic.count_documents({})}")
    print(f"  Episodic memories: {engine.db.memory_episodic.count_documents({})}")
    print(f"  Taxonomic memories: {engine.db.memory_taxonomic.count_documents({})}")
    print(f"  Tasks: {engine.db.tasks.count_documents({})}")

    print(f"\nEmbedder calls: {embedder.call_count}")
    print(f"LLM calls: {llm.call_count}")

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
