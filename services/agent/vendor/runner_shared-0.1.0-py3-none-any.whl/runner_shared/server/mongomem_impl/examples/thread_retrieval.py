#!/usr/bin/env python3
"""
Conversation Thread Retrieval - Resume conversations intelligently!

This example shows how to use thread retrieval to get coherent conversation
context instead of scattered search results.

Use cases:
- "Where were we?" - Resume a conversation
- "What do you know about X?" - Cross-session knowledge
- Agent wake-up - Restore context after sleep
"""

from mongomem_core import MemoryEngine
from mongomem_core.config import Settings
from mongomem_core.models.config import ThreadRetrievalConfig

# ─────────────────────────────────────────────────────────────────────────────
# Setup (you need an embedder for thread retrieval)
# ─────────────────────────────────────────────────────────────────────────────


# For this example, we'll use a simple mock embedder
# In production, use OpenAI, Voyage, or local embeddings
class MockEmbedder:
    def embed(self, text: str) -> list[float]:
        # Simple hash-based mock (not for production!)
        import hashlib

        h = hashlib.md5(text.encode()).hexdigest()
        return [int(h[i : i + 2], 16) / 255.0 for i in range(0, 32, 2)]

    @property
    def dimension(self) -> int:
        return 16

    @property
    def model_id(self) -> str:
        return "mock-embedder"


embedder = MockEmbedder()
settings = Settings(embedding_dimension=embedder.dimension)
engine = MemoryEngine(settings, embedder=embedder)
engine.bootstrap()

ORG, USER, PROJECT = "default-org", "me", "default-project"

# ─────────────────────────────────────────────────────────────────────────────
# Create some conversation history
# ─────────────────────────────────────────────────────────────────────────────

print("Creating sample conversations...")

# Session 1: MongoDB discussion
for msg in [
    ("user", "How do I create an index in MongoDB?"),
    ("assistant", "Use db.collection.createIndex({field: 1}) for ascending..."),
    ("user", "What about compound indexes?"),
    ("assistant", "Compound indexes cover multiple fields: {field1: 1, field2: -1}..."),
]:
    engine.write_turn(
        session_id="session_mongodb",
        role=msg[0],
        content=msg[1],
        org_id=ORG,
        user_id=USER,
    )

# Session 2: Python discussion
for msg in [
    ("user", "What's a Python decorator?"),
    ("assistant", "Decorators are functions that modify other functions..."),
    ("user", "Can you show me an example?"),
    ("assistant", "@my_decorator\\ndef my_function(): pass"),
]:
    engine.write_turn(
        session_id="session_python",
        role=msg[0],
        content=msg[1],
        org_id=ORG,
        user_id=USER,
    )

# Promote to snapshots (normally done by worker, but we'll do it manually)
engine.promote_stm_to_snapshot("session_mongodb", ORG, USER, PROJECT, force=True)
engine.promote_stm_to_snapshot("session_python", ORG, USER, PROJECT, force=True)

print("[OK] Created 2 conversation sessions with snapshots")

# ─────────────────────────────────────────────────────────────────────────────
# Thread Retrieval Examples
# ─────────────────────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("THREAD RETRIEVAL EXAMPLES")
print("=" * 60)

# Example 1: Basic retrieval
print("\n[Example 1] Basic thread retrieval")
print("-" * 40)

thread = engine.retrieve_conversation_thread(
    org_id=ORG,
    query="MongoDB indexes",
)

print(f"Found {len(thread.snapshots)} snapshots")
print(f"Total tokens: {thread.total_tokens}")

if thread.snapshots:
    print("\nContext preview:")
    print(thread.to_context_string()[:500] + "...")

# Example 2: Using presets
print("\n[Example 2] Using preset configs")
print("-" * 40)

# For resuming current session (stays within session)
thread = engine.retrieve_for_resumption(ORG, "where were we with indexes?")
print(f"Resume config: {len(thread.snapshots)} snapshots")

# For cross-session knowledge
thread = engine.retrieve_cross_session_knowledge(ORG, "programming concepts")
print(f"Knowledge config: {len(thread.snapshots)} snapshots")

# Example 3: Custom configuration
print("\n[Example 3] Custom configuration")
print("-" * 40)

custom_config = ThreadRetrievalConfig(
    search_mode="vector",  # or "text", "hybrid"
    expansion="adaptive",  # or "topic", "session", "similarity"
    max_tokens=4000,  # Context budget
    max_snapshots=5,  # Max results
    allow_cross_session=True,  # Include other sessions?
)

thread = engine.retrieve_conversation_thread(
    org_id=ORG,
    query="database",
    config=custom_config,
)

print(f"Custom config results: {len(thread.snapshots)} snapshots")

# Example 4: Using the result
print("\n[Example 4] Using the thread result")
print("-" * 40)

if thread.snapshots:
    # For LLM context injection
    context_str = thread.to_context_string()
    print(f"Context string length: {len(context_str)} chars")

    # For chat API format
    messages = thread.to_messages()
    print(f"Message count: {len(messages)}")

print("\n" + "=" * 60)
print("Thread retrieval examples complete!")
print("=" * 60)
print(
    """
Key takeaways:
1. Thread retrieval returns COHERENT conversations, not scattered results
2. Use presets for common scenarios (RESUMPTION, KNOWLEDGE)
3. Customize with ThreadRetrievalConfig for specific needs
4. to_context_string() and to_messages() format for LLM consumption
"""
)
