#!/usr/bin/env python3
"""
mongomem with Embeddings - Enable vector search!

This example shows how to add an embedder for semantic search.
You can use any embedding provider (OpenAI, Voyage, Cohere, local models).
"""

from typing import List

# ─────────────────────────────────────────────────────────────────────────────
# Step 1: Create your embedder
# ─────────────────────────────────────────────────────────────────────────────


# Option A: OpenAI embeddings
class OpenAIEmbedder:
    """Embedder using OpenAI's API."""

    def __init__(self, api_key: str, model: str = "text-embedding-3-small"):
        import openai

        self.client = openai.OpenAI(api_key=api_key)
        self._model = model
        self._dimension = 1536  # text-embedding-3-small default

    def embed(self, text: str) -> List[float]:
        response = self.client.embeddings.create(
            input=text,
            model=self._model,
        )
        return response.data[0].embedding

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        response = self.client.embeddings.create(
            input=texts,
            model=self._model,
        )
        return [item.embedding for item in response.data]

    @property
    def dimension(self) -> int:
        return self._dimension

    @property
    def model_id(self) -> str:
        return self._model


# Option B: Voyage AI embeddings (recommended for retrieval)
class VoyageEmbedder:
    """Embedder using Voyage AI's API."""

    def __init__(self, api_key: str, model: str = "voyage-3-lite"):
        import voyageai

        self.client = voyageai.Client(api_key=api_key)
        self._model = model
        self._dimension = 1024 if "lite" in model else 1536

    def embed(self, text: str) -> List[float]:
        result = self.client.embed([text], model=self._model)
        return result.embeddings[0]

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        result = self.client.embed(texts, model=self._model)
        return result.embeddings

    @property
    def dimension(self) -> int:
        return self._dimension

    @property
    def model_id(self) -> str:
        return self._model


# Option C: Local embeddings (no API needed!)
class LocalEmbedder:
    """Embedder using sentence-transformers (runs locally)."""

    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        from sentence_transformers import SentenceTransformer

        self.model = SentenceTransformer(model_name)
        self._model_name = model_name
        self._dimension = self.model.get_sentence_embedding_dimension()

    def embed(self, text: str) -> List[float]:
        return self.model.encode(text).tolist()

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        return self.model.encode(texts).tolist()

    @property
    def dimension(self) -> int:
        return self._dimension

    @property
    def model_id(self) -> str:
        return self._model_name


# ─────────────────────────────────────────────────────────────────────────────
# Step 2: Create engine with embedder
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    from mongomem_core import MemoryEngine
    from mongomem_core.config import Settings

    # Choose your embedder:

    # Option A: OpenAI (requires OPENAI_API_KEY)
    # embedder = OpenAIEmbedder(api_key=os.getenv("OPENAI_API_KEY"))

    # Option B: Voyage (requires VOYAGE_API_KEY)
    # embedder = VoyageEmbedder(api_key=os.getenv("VOYAGE_API_KEY"))

    # Option C: Local (no API key needed, but slower)
    # pip install sentence-transformers
    print("Loading local embedding model...")
    embedder = LocalEmbedder()
    print(f"[OK] Using {embedder.model_id} (dimension={embedder.dimension})")

    # Create engine with embedder
    settings = Settings(embedding_dimension=embedder.dimension)
    engine = MemoryEngine(settings, embedder=embedder)
    engine.bootstrap()

    # ─────────────────────────────────────────────────────────────────────────
    # Step 3: Store data with embeddings
    # ─────────────────────────────────────────────────────────────────────────

    ORG, USER = "default", "me"

    # Store some facts - embeddings generated automatically!
    facts = [
        (
            "python-def",
            "Python is a high-level programming language known for readability.",
        ),
        (
            "mongodb-def",
            "MongoDB is a document database that stores data in JSON-like format.",
        ),
        (
            "vector-search",
            "Vector search finds similar items by comparing embedding distances.",
        ),
    ]

    for label, text in facts:
        result = engine.create_semantic(
            label=label,
            text=text,
            org_id=ORG,
            user_id=USER,
        )
        print(f"[OK] Stored '{label}' (has_embedding={result.has_embedding})")

    # Store a conversation turn with embedding
    result = engine.write_turn(
        session_id="chat_001",
        role="user",
        content="How do I use MongoDB with Python?",
        org_id=ORG,
        user_id=USER,
    )
    print(f"[OK] Stored conversation turn (has_embedding={result.has_embedding})")

    # ─────────────────────────────────────────────────────────────────────────
    # Step 4: Vector search!
    # ─────────────────────────────────────────────────────────────────────────

    print("\nSearching for 'database storage'...")

    # Generate query embedding
    query = "database storage"
    query_embedding = embedder.embed(query)

    # Note: Vector search requires MongoDB Atlas with a vector search index
    # For local MongoDB, you'll need to set up Atlas or use a different approach
    print(
        """
    NOTE: Vector search requires MongoDB Atlas with vector search indexes.

    For local development, you can:
    1. Use MongoDB Atlas free tier
    2. Use the 'list' methods with post-filtering
    3. Run the full test suite which mocks vector search

    See docs/engine-api.md for vector search setup.
    """
    )

    print("\n[OK] Done! Your data now has embeddings for semantic search.")
