"""Episodic memory HTTP routes."""

from __future__ import annotations

import logging
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from magenta_sdk_core.api.v1.memory import CreateEpisodicResult, DeleteResult
from pydantic import BaseModel, Field

from runner_shared.server.mongomem_impl.routes.v1.filters import ListEpisodicFilters

logger = logging.getLogger(__name__)

router = APIRouter()


# ============================================================================
# Request Models
# ============================================================================


class CreateEpisodicRequest(BaseModel):
    """Request to create an episodic memory."""

    title: str = Field(..., description="Title or label for this episode")
    org_id: str = Field(..., description="Organization ID")
    user_id: str = Field(..., description="User ID who owns this memory")
    content: str = Field(default="", description="Full episodic content")
    summary_text: str = Field(default="", description="Summarized text of the episode")
    session_id: str = Field(
        ...,
        min_length=1,
        description="Session ID this episode originated from",
    )
    snapshot_ref_id: Optional[str] = Field(None, description="Reference to source snapshot")
    summary_type: str = Field(default="manual", description="Method used (heuristic, llm, manual)")
    source_agent: str = Field(default="user", description="Agent/model that created this episode")
    participants: Optional[List[str]] = Field(None, description="List of participant IDs")
    tags: Optional[List[str]] = Field(None, description="Tags for categorization")
    visibility: str = Field(
        default="private", description="Visibility scope (private, shared, org)"
    )
    project_id: str = Field(..., description="Project ID")
    agent_id: Optional[str] = Field(None, description="Agent ID if created via agent")
    extraction_source: Optional[str] = Field(None, description="Source type")
    embedding: Optional[List[float]] = Field(None, description="Pre-computed embedding vector")
    skip_embedding: bool = Field(default=False, description="Skip embedding generation")


class UpdateEpisodicRequest(BaseModel):
    """Request to update an episodic memory."""

    org_id: str = Field(..., description="Organization ID")
    title: Optional[str] = Field(None, description="New title")
    content: Optional[str] = Field(None, description="New content")
    summary_text: Optional[str] = Field(None, description="New summary")
    visibility: Optional[str] = Field(None, description="New visibility")
    project_id: str = Field(..., description="Project ID")
    tags: Optional[List[str]] = Field(None, description="New tags")


# ============================================================================
# Routes
# ============================================================================


@router.post("/episodic", response_model=CreateEpisodicResult, status_code=status.HTTP_201_CREATED)
async def create_episodic(request: Request, body: CreateEpisodicRequest):
    """
    Create an episodic memory (event/experience).

    Episodic memories capture significant events, experiences, or conversation summaries.
    They can be searched by semantic similarity and filtered by session, user, or project.
    """
    engine = request.app.state.engine

    try:
        engine_result = engine.create_episodic(
            title=body.title,
            org_id=body.org_id,
            user_id=body.user_id,
            content=body.content,
            summary_text=body.summary_text,
            session_id=body.session_id,
            snapshot_ref_id=body.snapshot_ref_id,
            summary_type=body.summary_type,
            source_agent=body.source_agent,
            participants=body.participants,
            tags=body.tags,
            visibility=body.visibility,
            project_id=body.project_id,
            agent_id=body.agent_id,
            extraction_source=body.extraction_source,
            embedding=body.embedding,
            skip_embedding=body.skip_embedding,
        )

        # Convert dataclass to Pydantic model
        return CreateEpisodicResult(
            id=engine_result.id,
            title=engine_result.title,
            has_embedding=engine_result.has_embedding,
            acknowledged=engine_result.acknowledged,
        )

    except Exception as e:
        logger.error(f"Error creating episodic memory: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create episodic memory: {str(e)}",
        )


@router.get("/episodic/{memory_id}")
async def get_episodic(
    request: Request,
    memory_id: str,
    org_id: str,
    project_id: str,
    user_id: str | None = None,
    visibility: str | None = None,
):
    """
    Retrieve an episodic memory by ID.

    Args:
        memory_id: The episodic memory document ID
        org_id: Organization ID (query parameter)
        project_id: Project ID (query parameter)
        user_id: Optional user ID filter (query parameter)
        visibility: Optional visibility filter (query parameter)
    """
    engine = request.app.state.engine

    try:
        result = engine.get_episodic(
            org_id=org_id,
            id=memory_id,
            project_id=project_id,
            user_id=user_id,
            visibility=visibility,
        )

        if result is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Episodic memory not found: {memory_id}",
            )

        # Convert EpisodicOut to dict
        return (
            result
            if isinstance(result, dict)
            else (result.model_dump() if hasattr(result, "model_dump") else result.dict())
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting episodic memory: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get episodic memory: {str(e)}",
        )


@router.get("/episodic")
async def list_episodic(
    request: Request,
    filters: ListEpisodicFilters = Depends(),
):
    """
    List episodic memories with optional filters.

    Query parameters validated by ListEpisodicFilters model.
    """
    engine = request.app.state.engine

    try:
        results = engine.list_episodic(**filters.model_dump())

        # Convert list of EpisodicOut to dicts
        entries = []
        for result in results:
            if isinstance(result, dict):
                entries.append(result)
            elif hasattr(result, "model_dump"):
                entries.append(result.model_dump())
            elif hasattr(result, "dict"):
                entries.append(result.dict())
            else:
                entries.append(result)

        return {
            "entries": entries,
            "count": len(entries),
        }

    except Exception as e:
        logger.error(f"Error listing episodic memories: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list episodic memories: {str(e)}",
        )


@router.patch("/episodic/{memory_id}")
async def update_episodic(request: Request, memory_id: str, body: UpdateEpisodicRequest):
    """
    Update an episodic memory.

    Args:
        memory_id: The episodic memory document ID
        body: Fields to update
    """
    engine = request.app.state.engine

    try:
        result = engine.update_episodic(
            org_id=body.org_id,
            id=memory_id,
            title=body.title,
            content=body.content,
            summary_text=body.summary_text,
            visibility=body.visibility,
            project_id=body.project_id,
            tags=body.tags,
        )

        if result is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Episodic memory not found: {memory_id}",
            )

        return (
            result
            if isinstance(result, dict)
            else (result.model_dump() if hasattr(result, "model_dump") else result.dict())
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating episodic memory: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update episodic memory: {str(e)}",
        )


@router.delete("/episodic/{memory_id}", response_model=DeleteResult)
async def delete_episodic(
    request: Request,
    memory_id: str,
    org_id: str,
    soft: bool = True,
):
    """
    Delete an episodic memory.

    Args:
        memory_id: The episodic memory document ID
        org_id: Organization ID (query parameter)
        soft: If true, soft delete (default). If false, hard delete.
    """
    engine = request.app.state.engine

    try:
        engine_result = engine.delete_episodic(
            org_id=org_id,
            id=memory_id,
            soft=soft,
        )

        # Convert dataclass to Pydantic model
        return DeleteResult(
            deleted_count=engine_result.deleted_count,
            acknowledged=engine_result.acknowledged,
        )

    except Exception as e:
        logger.error(f"Error deleting episodic memory: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete episodic memory: {str(e)}",
        )
