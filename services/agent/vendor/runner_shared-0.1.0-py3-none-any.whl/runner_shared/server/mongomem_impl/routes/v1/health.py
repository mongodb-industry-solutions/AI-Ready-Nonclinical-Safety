"""Health check endpoint for memory server."""

from fastapi import APIRouter

router = APIRouter()


@router.get("/health")
async def health_check():
    """Memory server health check."""
    return {
        "status": "healthy",
        "service": "mongomem-server",
        "version": "1.0.0",
    }
