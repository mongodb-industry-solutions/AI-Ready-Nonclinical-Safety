"""User context/preference memory HTTP routes."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field

from runner_shared.server.mongomem_impl.routes.v1.filters import ListUserContextFilters

logger = logging.getLogger(__name__)

router = APIRouter()


# ============================================================================
# Request Models
# ============================================================================


class CreateUserContextRequest(BaseModel):
    """Request to create a user context memory."""

    org_id: str = Field(..., description="Organization ID")
    user_id: str = Field(..., description="User ID who owns this context")
    tone: Optional[str] = Field(None, description="Preferred communication tone")
    style: Optional[str] = Field(None, description="Preferred communication style")
    language: Optional[str] = Field(None, description="Preferred language for communication")
    preferred_format: Optional[str] = Field(None, description="Preferred response format")
    source: Optional[str] = Field(None, description="Source of this context")
    demographic_tags: Optional[List[str]] = Field(
        None, description="Demographic tags for personalization"
    )
    preferences: Optional[Dict[str, Any]] = Field(
        None, description="Additional user preferences dict"
    )
    visibility: str = Field(
        default="private", description="Visibility scope (private, shared, org)"
    )
    project_id: Optional[str] = Field(
        None, description="Project ID (required when visibility=shared)"
    )
    agent_id: Optional[str] = Field(None, description="Agent ID if created via agent")
    extraction_source: Optional[str] = Field(None, description="Source type")


class UpdateUserContextRequest(BaseModel):
    """Request to update a user context memory."""

    org_id: str = Field(..., description="Organization ID")
    user_id: str = Field(..., description="User ID")
    tone: Optional[str] = Field(None, description="New tone preference")
    style: Optional[str] = Field(None, description="New style preference")
    language: Optional[str] = Field(None, description="New language code")
    preferred_format: Optional[str] = Field(None, description="New format preference")
    demographic_tags: Optional[List[str]] = Field(None, description="New demographic tags")
    preferences: Optional[Dict[str, Any]] = Field(None, description="New preferences dict")
    source: Optional[str] = Field(None, description="New source")
    timezone: Optional[str] = Field(None, description="New timezone")


# ============================================================================
# Response Models
# ============================================================================


class CreateUserContextResponse(BaseModel):
    """Response after creating a user context memory."""

    id: str = Field(..., description="Created document ID")
    context_key: str = Field(..., description="Context key")
    acknowledged: bool = Field(..., description="Whether operation was acknowledged")


class DeleteUserContextResponse(BaseModel):
    """Response after deleting a user context memory."""

    deleted_count: int = Field(..., description="Number of documents deleted")
    acknowledged: bool = Field(..., description="Whether operation was acknowledged")


# ============================================================================
# Routes
# ============================================================================


@router.post(
    "/user-context", response_model=CreateUserContextResponse, status_code=status.HTTP_201_CREATED
)
async def create_user_context(request: Request, body: CreateUserContextRequest):
    """
    Create a user context/preference memory.

    User context memories store user preferences, communication style,
    and demographic information for personalized interactions.
    """
    engine = request.app.state.engine

    try:
        result = engine.create_user_context(
            org_id=body.org_id,
            user_id=body.user_id,
            tone=body.tone,
            style=body.style,
            language=body.language,
            preferred_format=body.preferred_format,
            source=body.source,
            demographic_tags=body.demographic_tags,
            preferences=body.preferences,
            visibility=body.visibility,
            project_id=body.project_id,
            agent_id=body.agent_id,
            extraction_source=body.extraction_source,
        )

        return CreateUserContextResponse(
            id=result.id,
            context_key=result.context_key,
            acknowledged=result.acknowledged,
        )

    except Exception as e:
        logger.error(f"Error creating user context: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create user context: {str(e)}",
        )


@router.get("/user-context/{org_id}/{user_id}")
async def get_user_context(request: Request, org_id: str, user_id: str):
    """
    Get a user context memory by org_id and user_id.

    Args:
        org_id: Organization ID
        user_id: User ID

    Returns:
        UserContextMemoryOut if found, or 404 if not found.
    """
    engine = request.app.state.engine

    try:
        result = engine.get_user_context(org_id=org_id, user_id=user_id)

        if result is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User context not found: org_id={org_id}, user_id={user_id}",
            )

        return (
            result
            if isinstance(result, dict)
            else (result.model_dump() if hasattr(result, "model_dump") else result.dict())
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting user context: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get user context: {str(e)}",
        )


@router.get("/user-context")
async def list_user_context(
    request: Request,
    filters: ListUserContextFilters = Depends(),
    visibility: Optional[str] = None,
    project_id: Optional[str] = None,
):
    """
    List user context memories for an organization.

    Query parameters validated by ListUserContextFilters model, plus:
        visibility: Filter by visibility scope
        project_id: Filter by project ID
    """
    engine = request.app.state.engine

    try:
        results = engine.list_user_context(
            org_id=filters.org_id,
            user_id=filters.user_id,
            visibility=visibility,
            project_id=project_id,
            limit=filters.limit,
        )

        entries = []
        for result in results:
            entries.append(
                result
                if isinstance(result, dict)
                else (result.model_dump() if hasattr(result, "model_dump") else result.dict())
            )

        return {
            "entries": entries,
            "count": len(entries),
        }

    except Exception as e:
        logger.error(f"Error listing user contexts: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list user contexts: {str(e)}",
        )


@router.patch("/user-context")
async def update_user_context(request: Request, body: UpdateUserContextRequest):
    """
    Update a user context memory.

    Args:
        body: Fields to update (org_id and user_id required, other fields optional)

    Returns:
        Updated UserContextMemoryOut or 404 if not found.
    """
    engine = request.app.state.engine

    try:
        result = engine.update_user_context(
            org_id=body.org_id,
            user_id=body.user_id,
            tone=body.tone,
            style=body.style,
            language=body.language,
            preferred_format=body.preferred_format,
            demographic_tags=body.demographic_tags,
            preferences=body.preferences,
            source=body.source,
            timezone=body.timezone,
        )

        if result is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User context not found: org_id={body.org_id}, user_id={body.user_id}",
            )

        return (
            result
            if isinstance(result, dict)
            else (result.model_dump() if hasattr(result, "model_dump") else result.dict())
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating user context: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update user context: {str(e)}",
        )


@router.delete("/user-context/{org_id}/{user_id}", response_model=DeleteUserContextResponse)
async def delete_user_context(request: Request, org_id: str, user_id: str):
    """
    Delete a user context memory.

    Note: User context only supports hard delete.

    Args:
        org_id: Organization ID
        user_id: User ID

    Returns:
        DeleteUserContextResponse with deleted_count.
    """
    engine = request.app.state.engine

    try:
        result = engine.delete_user_context(org_id=org_id, user_id=user_id)

        return DeleteUserContextResponse(
            deleted_count=result.deleted_count,
            acknowledged=result.acknowledged,
        )

    except Exception as e:
        logger.error(f"Error deleting user context: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete user context: {str(e)}",
        )
