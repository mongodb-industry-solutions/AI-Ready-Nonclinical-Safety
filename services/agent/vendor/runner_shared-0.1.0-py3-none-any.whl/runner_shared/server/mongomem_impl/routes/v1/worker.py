"""Worker process endpoint for on-demand task queue draining."""

from __future__ import annotations

import logging

from fastapi import APIRouter, BackgroundTasks, Request
from fastapi.responses import Response

router = APIRouter()
logger = logging.getLogger(__name__)

# Safety cap: prevents infinite looping if tasks keep re-enqueuing
_MAX_DRAIN_ITERATIONS = 50

# In-process flag: True while a _drain_queue background task is running.
# Safe to use without locks because uvicorn runs a single event loop thread —
# the flag is only read/written from async coroutines on that thread.
_drain_active = False


async def _drain_queue(worker: object) -> None:
    """Background task: drain the queue until empty or cap is reached."""
    global _drain_active
    iterations = 0
    total = 0
    try:
        while iterations < _MAX_DRAIN_ITERATIONS:
            processed = await worker.process_batch()  # type: ignore[attr-defined]
            iterations += 1
            if processed == 0:
                break
            total += processed
        logger.debug("Drain complete: processed=%d iterations=%d", total, iterations)
    except Exception as exc:
        # Log at ERROR so the failure is visible in server logs and any
        # attached observability middleware. Re-raise so the exception is not
        # silently swallowed — FastAPI will log it at the framework level too.
        # The OE will naturally retry on the next scan cycle since the task
        # queue preserves task state (stale tasks are re-queued on lease expiry).
        logger.error("Drain loop error: %s", exc, exc_info=True)
        raise
    finally:
        _drain_active = False


@router.post("/worker/processTasks", status_code=202)
async def process_pending(request: Request, background_tasks: BackgroundTasks) -> Response:
    """
    Trigger background draining of the task queue.

    Returns 202 Accepted immediately and drains asynchronously in the background.
    Designed to be called fire-and-forget by the OE after enqueueing check_promotion tasks.

    If a drain is already in progress, returns 202 without scheduling a second one —
    the active drain will pick up any newly enqueued tasks before it exits.

    The background pipeline:
      check_promotion → promote STM to snapshot (Voyage embedding in thread pool)
      → enqueue semantic + episodic tasks
      → semantic extraction
      → episodic extraction
      → queue empty

    Returns:
        202 Accepted — drain started or already running
        204 No Content — no worker configured, nothing to do
    """
    worker = getattr(request.app.state, "worker", None)
    if worker is None:
        return Response(status_code=204)

    global _drain_active
    if _drain_active:
        logger.debug("Drain already in progress, skipping new background task")
        return Response(status_code=202)

    # Set the flag synchronously before scheduling the background task so that
    # a second concurrent request sees it as active before _drain_queue starts.
    _drain_active = True
    background_tasks.add_task(_drain_queue, worker)
    return Response(status_code=202)
