"""Vector search/retrieval HTTP routes."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Request
from magenta_sdk_core.api.v1.memory import MemoryChunk
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


# ============================================================================
# Response Models
# ============================================================================


class RetrievalResponse(BaseModel):
    """Response from memory retrieval endpoints."""

    memories: list[MemoryChunk] = Field(..., description="Retrieved memory chunks")
    count: int = Field(..., description="Number of memories returned")


router = APIRouter()


# ============================================================================
# Request Models
# ============================================================================


class RetrieveSemanticRequest(BaseModel):
    """Request to search semantic memories."""

    query: str = Field(..., description="Query text for semantic search")
    org_id: str = Field(..., description="Organization ID")
    user_id: Optional[str] = Field(None, description="Filter by user ID")
    visibility: Optional[str] = Field(None, description="Filter by visibility scope")
    project_id: str = Field(..., description="Project ID")
    top_k: int = Field(default=50, description="Maximum number of results")
    similarity_threshold: float = Field(default=0.0, description="Minimum similarity score")
    dedup_threshold: float = Field(default=0.5, description="Deduplication similarity threshold")
    deduplicate: bool = Field(default=True, description="Whether to deduplicate results")
    rank: bool = Field(default=True, description="Whether to rank results")


class RetrieveEpisodicRequest(BaseModel):
    """Request to search episodic memories."""

    query: str = Field(..., description="Query text for semantic search")
    org_id: str = Field(..., description="Organization ID")
    user_id: Optional[str] = Field(None, description="Filter by user ID")
    session_id: Optional[str] = Field(None, description="Filter by session ID")
    visibility: Optional[str] = Field(None, description="Filter by visibility scope")
    project_id: str = Field(..., description="Project ID")
    top_k: int = Field(default=50, description="Maximum number of results")
    similarity_threshold: float = Field(default=0.0, description="Minimum similarity score")
    dedup_threshold: float = Field(default=0.5, description="Deduplication similarity threshold")
    deduplicate: bool = Field(default=True, description="Whether to deduplicate results")
    rank: bool = Field(default=True, description="Whether to rank results")


class RetrieveProceduralRequest(BaseModel):
    """Request to search procedural memories."""

    query: str = Field(..., description="Query text for semantic search")
    org_id: str = Field(..., description="Organization ID")
    user_id: Optional[str] = Field(None, description="Filter by user ID")
    visibility: Optional[str] = Field(None, description="Filter by visibility scope")
    project_id: str = Field(..., description="Project ID")
    tags: Optional[List[str]] = Field(None, description="Filter by tags")
    metadata_filter: Optional[Dict[str, Any]] = Field(
        None, description="Field-level metadata filter"
    )
    top_k: int = Field(default=50, description="Maximum number of results")
    similarity_threshold: float = Field(default=0.0, description="Minimum similarity score")
    dedup_threshold: float = Field(default=0.5, description="Deduplication similarity threshold")
    deduplicate: bool = Field(default=True, description="Whether to deduplicate results")
    rank: bool = Field(default=True, description="Whether to rank results")


# ============================================================================
# Routes
# ============================================================================


@router.post("/retrieval/semantic", response_model=RetrievalResponse)
async def retrieve_semantic_memories(request: Request, body: RetrieveSemanticRequest):
    """
    Search semantic memories using vector similarity.

    Returns ranked memories with similarity scores.
    """
    engine = request.app.state.engine

    try:
        results = engine.fetch_semantic_memories(
            query=body.query,
            org_id=body.org_id,
            user_id=body.user_id,
            visibility=body.visibility,
            project_id=body.project_id,
            top_k=body.top_k,
            similarity_threshold=body.similarity_threshold,
            dedup_threshold=body.dedup_threshold,
            deduplicate=body.deduplicate,
            rank=body.rank,
        )

        # Convert from mongomem_impl MemoryChunk to sdk-core MemoryChunk
        sdk_memories = [MemoryChunk.model_validate(chunk.model_dump()) for chunk in results]

        return RetrievalResponse(
            memories=sdk_memories,
            count=len(sdk_memories),
        )

    except Exception as e:
        logger.error(f"Error retrieving semantic memories: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve semantic memories: {str(e)}",
        )


@router.post("/retrieval/episodic", response_model=RetrievalResponse)
async def retrieve_episodic_memories(request: Request, body: RetrieveEpisodicRequest):
    """
    Search episodic memories using vector similarity.

    Returns ranked episodes with similarity scores.
    """
    engine = request.app.state.engine

    try:
        results = engine.fetch_episodic_memories(
            query=body.query,
            org_id=body.org_id,
            user_id=body.user_id,
            session_id=body.session_id,
            visibility=body.visibility,
            project_id=body.project_id,
            top_k=body.top_k,
            similarity_threshold=body.similarity_threshold,
            dedup_threshold=body.dedup_threshold,
            deduplicate=body.deduplicate,
            rank=body.rank,
        )

        # Convert from mongomem_impl MemoryChunk to sdk-core MemoryChunk
        sdk_memories = [MemoryChunk.model_validate(chunk.model_dump()) for chunk in results]

        return RetrievalResponse(
            memories=sdk_memories,
            count=len(sdk_memories),
        )

    except Exception as e:
        logger.error(f"Error retrieving episodic memories: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve episodic memories: {str(e)}",
        )


@router.post("/retrieval/procedural", response_model=RetrievalResponse)
async def retrieve_procedural_memories(request: Request, body: RetrieveProceduralRequest):
    """
    Search procedural memories using vector similarity.

    Returns ranked procedures with similarity scores.
    """
    engine = request.app.state.engine

    try:
        kwargs: Dict[str, Any] = dict(
            query=body.query,
            org_id=body.org_id,
            user_id=body.user_id,
            visibility=body.visibility,
            project_id=body.project_id,
            tags=body.tags,
            top_k=body.top_k,
            similarity_threshold=body.similarity_threshold,
            dedup_threshold=body.dedup_threshold,
            deduplicate=body.deduplicate,
            rank=body.rank,
        )
        if body.metadata_filter:
            from mongomem_core.models.filters import MetadataFilter

            kwargs["metadata_filter"] = MetadataFilter(raw=body.metadata_filter)

        results = engine.fetch_procedural_memories(**kwargs)

        # Convert from mongomem_impl MemoryChunk to sdk-core MemoryChunk
        sdk_memories = [MemoryChunk.model_validate(chunk.model_dump()) for chunk in results]

        return RetrievalResponse(
            memories=sdk_memories,
            count=len(sdk_memories),
        )

    except Exception as e:
        logger.error(f"Error retrieving procedural memories: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve procedural memories: {str(e)}",
        )
