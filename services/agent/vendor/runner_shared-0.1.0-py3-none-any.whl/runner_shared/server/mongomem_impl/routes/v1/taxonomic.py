"""Taxonomic memory (knowledge graph) HTTP routes."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from magenta_sdk_core.api.v1.memory import CreateTaxonomicResult, DeleteResult
from pydantic import BaseModel, Field

from runner_shared.server.mongomem_impl.routes.v1.filters import ListTaxonomicFilters

logger = logging.getLogger(__name__)

router = APIRouter()


# ============================================================================
# Request Models
# ============================================================================


class CreateTaxonomicRequest(BaseModel):
    """Request to create a taxonomic memory."""

    domain: str = Field(..., description="Domain/category for this term")
    term: str = Field(..., description="The term being defined")
    definition: str = Field(..., description="Definition of the term")
    org_id: str = Field(..., description="Organization ID")
    user_id: str = Field(..., description="User ID who owns this memory")
    related_terms: Optional[List[str]] = Field(
        None, description="Related terms for semantic linking"
    )
    query_expansion: bool = Field(
        default=True, description="Whether to use this term for query expansion"
    )
    visibility: str = Field(default="org", description="Visibility scope")
    project_id: str = Field(..., description="Project ID")
    contextual_metadata: Optional[Dict[str, Any]] = Field(None, description="Additional context")
    agent_id: Optional[str] = Field(None, description="Agent ID")
    extraction_source: Optional[str] = Field(None, description="Source type")
    creation_method: str = Field(default="user_created", description="How the entry was created")
    source_agent: Optional[str] = Field(None, description="Agent/model that created this entry")
    user_source: Optional[str] = Field(None, description="User ID who initiated the creation")
    source_reference: Optional[str] = Field(None, description="Reference to source document")
    evidence_spans: Optional[List[Dict[str, Any]]] = Field(
        None, description="Evidence spans for LLM extractions"
    )
    confidence_score: Optional[float] = Field(
        None, description="Confidence score for LLM extractions"
    )
    embedding: Optional[List[float]] = Field(None, description="Pre-computed embedding")
    skip_embedding: bool = Field(default=False, description="Skip embedding generation")


class BulkCreateTaxonomicRequest(BaseModel):
    """Request to bulk create taxonomic memories."""

    terms: List[Dict[str, Any]] = Field(
        ..., description="List of term dicts with term, definition, related_terms"
    )
    org_id: str = Field(..., description="Organization ID")
    user_id: str = Field(..., description="User ID of the creator")
    domain: Optional[str] = Field(None, description="Domain for all terms")
    visibility: Optional[str] = Field(None, description="Visibility scope")
    project_id: str = Field(..., description="Project ID")
    generate_embeddings: bool = Field(default=True, description="Generate embeddings for all terms")
    skip_duplicates: bool = Field(default=True, description="Skip duplicates instead of failing")


class UpdateTaxonomicRequest(BaseModel):
    """Request to update a taxonomic memory."""

    org_id: str = Field(..., description="Organization ID")
    id: Optional[str] = Field(None, description="Document ID")
    domain: Optional[str] = Field(None, description="Domain name (for lookup or new value)")
    term: Optional[str] = Field(None, description="Term name (for lookup or new value)")
    definition: Optional[str] = Field(None, description="New definition")
    related_terms: Optional[List[str]] = Field(None, description="New related terms")
    query_expansion: Optional[bool] = Field(None, description="New query_expansion flag")
    visibility: Optional[str] = Field(None, description="New visibility")
    project_id: str = Field(..., description="Project ID")
    contextual_metadata: Optional[Dict[str, Any]] = Field(None, description="New metadata")


# ============================================================================
# Routes
# ============================================================================


@router.post(
    "/taxonomic", response_model=CreateTaxonomicResult, status_code=status.HTTP_201_CREATED
)
async def create_taxonomic(request: Request, body: CreateTaxonomicRequest):
    """Create a taxonomic memory (domain-specific term with definition)."""
    engine = request.app.state.engine

    try:
        engine_result = engine.create_taxonomic(
            domain=body.domain,
            term=body.term,
            definition=body.definition,
            org_id=body.org_id,
            user_id=body.user_id,
            related_terms=body.related_terms,
            query_expansion=body.query_expansion,
            visibility=body.visibility,
            project_id=body.project_id,
            contextual_metadata=body.contextual_metadata,
            agent_id=body.agent_id,
            extraction_source=body.extraction_source,
            creation_method=body.creation_method,
            source_agent=body.source_agent,
            user_source=body.user_source,
            source_reference=body.source_reference,
            evidence_spans=body.evidence_spans,
            confidence_score=body.confidence_score,
            embedding=body.embedding,
            skip_embedding=body.skip_embedding,
        )

        # Convert dataclass to Pydantic model
        return CreateTaxonomicResult(
            id=engine_result.id,
            domain=engine_result.domain,
            term=engine_result.term,
            has_embedding=engine_result.has_embedding,
            acknowledged=engine_result.acknowledged,
        )

    except Exception as e:
        logger.error(f"Error creating taxonomic memory: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create taxonomic memory: {str(e)}",
        )


@router.post("/taxonomic/bulk", status_code=status.HTTP_201_CREATED)
async def bulk_create_taxonomic(request: Request, body: BulkCreateTaxonomicRequest):
    """Bulk create multiple taxonomic memories efficiently."""
    engine = request.app.state.engine

    try:
        results = engine.bulk_create_taxonomic(
            terms=body.terms,
            org_id=body.org_id,
            user_id=body.user_id,
            domain=body.domain,
            visibility=body.visibility,
            project_id=body.project_id,
            generate_embeddings=body.generate_embeddings,
            skip_duplicates=body.skip_duplicates,
        )

        return {
            "created_count": len(results),
            "results": [
                {
                    "id": r.id,
                    "domain": r.domain,
                    "term": r.term,
                    "has_embedding": r.has_embedding,
                }
                for r in results
            ],
        }

    except Exception as e:
        logger.error(f"Error bulk creating taxonomic memories: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to bulk create taxonomic memories: {str(e)}",
        )


@router.get("/taxonomic/domains")
async def get_taxonomic_domains(
    request: Request,
    org_id: str,
    project_id: str,
    visibility: Optional[str] = None,
    include_deleted: bool = False,
):
    """Get distinct domains for an organization."""
    engine = request.app.state.engine

    try:
        domains = engine.get_taxonomic_domains(
            org_id=org_id,
            project_id=project_id,
            visibility=visibility,
            include_deleted=include_deleted,
        )

        return {
            "domains": domains,
            "count": len(domains),
        }

    except Exception as e:
        logger.error(f"Error getting taxonomic domains: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get taxonomic domains: {str(e)}",
        )


@router.get("/taxonomic/{memory_id}")
async def get_taxonomic_by_id(
    request: Request,
    memory_id: str,
    org_id: str,
    project_id: str,
    user_id: str | None = None,
    visibility: str | None = None,
):
    """Retrieve a taxonomic memory by ID."""
    engine = request.app.state.engine

    try:
        result = engine.get_taxonomic(
            org_id=org_id,
            project_id=project_id,
            id=memory_id,
            user_id=user_id,
            visibility=visibility,
        )

        if result is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Taxonomic memory not found: {memory_id}",
            )

        return (
            result
            if isinstance(result, dict)
            else (result.model_dump() if hasattr(result, "model_dump") else result.dict())
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting taxonomic memory: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get taxonomic memory: {str(e)}",
        )


@router.get("/taxonomic")
async def list_taxonomic(
    request: Request,
    filters: ListTaxonomicFilters = Depends(),
):
    """List taxonomic memories with optional filters.

    Query parameters validated by ListTaxonomicFilters model.
    """
    engine = request.app.state.engine

    try:
        results = engine.list_taxonomic(**filters.model_dump())

        entries = []
        for result in results:
            if isinstance(result, dict):
                entries.append(result)
            elif hasattr(result, "model_dump"):
                entries.append(result.model_dump())
            elif hasattr(result, "dict"):
                entries.append(result.dict())
            else:
                entries.append(result)

        return {
            "entries": entries,
            "count": len(entries),
        }

    except Exception as e:
        logger.error(f"Error listing taxonomic memories: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list taxonomic memories: {str(e)}",
        )


@router.patch("/taxonomic/{memory_id}")
async def update_taxonomic(request: Request, memory_id: str, body: UpdateTaxonomicRequest):
    """Update a taxonomic memory."""
    engine = request.app.state.engine

    try:
        result = engine.update_taxonomic(
            org_id=body.org_id,
            id=memory_id,
            domain=body.domain,
            term=body.term,
            definition=body.definition,
            related_terms=body.related_terms,
            query_expansion=body.query_expansion,
            visibility=body.visibility,
            project_id=body.project_id,
            contextual_metadata=body.contextual_metadata,
        )

        if result is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Taxonomic memory not found: {memory_id}",
            )

        return (
            result
            if isinstance(result, dict)
            else (result.model_dump() if hasattr(result, "model_dump") else result.dict())
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating taxonomic memory: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update taxonomic memory: {str(e)}",
        )


@router.delete("/taxonomic/{memory_id}", response_model=DeleteResult)
async def delete_taxonomic(
    request: Request,
    memory_id: str,
    org_id: str,
    soft: bool = True,
):
    """Delete a taxonomic memory."""
    engine = request.app.state.engine

    try:
        engine_result = engine.delete_taxonomic(
            org_id=org_id,
            id=memory_id,
            soft=soft,
        )

        # Convert dataclass to Pydantic model
        return DeleteResult(
            deleted_count=engine_result.deleted_count,
            acknowledged=engine_result.acknowledged,
        )

    except Exception as e:
        logger.error(f"Error deleting taxonomic memory: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete taxonomic memory: {str(e)}",
        )
