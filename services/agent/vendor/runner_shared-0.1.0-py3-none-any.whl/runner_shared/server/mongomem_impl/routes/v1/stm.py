"""Short-term memory (STM) HTTP routes."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from magenta_sdk_core.api.v1.memory import WriteTurnResult
from pydantic import BaseModel, Field

from runner_shared.server.mongomem_impl.routes.v1.filters import ListSTMFilters

logger = logging.getLogger(__name__)

router = APIRouter()


# ============================================================================
# Request Models
# ============================================================================


class WriteTurnRequest(BaseModel):
    """Request to write a conversation turn."""

    session_id: str = Field(..., description="Conversation session/thread identifier")
    role: str = Field(..., description="Message role (user, assistant, system, tool)")
    org_id: str = Field(..., description="Organization ID")
    user_id: str = Field(..., description="User ID of the message author")
    content: Optional[str] = Field(None, description="Message content")
    tokens: Optional[int] = Field(None, description="Token count for this message")
    stop_reason: Optional[str] = Field(None, description="LLM stop reason if applicable")
    model_name: Optional[str] = Field(None, description="Model used to generate this message")
    tool_calls: Optional[List[Dict[str, Any]]] = Field(
        None, description="Tool calls for assistant messages"
    )
    tool_call_id: Optional[str] = Field(
        None, description="Tool call ID this result corresponds to (for tool role)"
    )
    tool_name: Optional[str] = Field(None, description="Name of the tool that produced this result")
    is_error: bool = Field(
        default=False, description="Whether this tool result represents an error"
    )
    agent_id: Optional[str] = Field(None, description="ID of the agent if applicable")
    share_learning_with_team: bool = Field(
        default=True, description="Whether to share learnings with agent's team"
    )
    visibility: str = Field(
        default="private", description="Visibility scope (private, shared, org)"
    )
    project_id: str = Field(..., description="Project ID")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Arbitrary key-value metadata")
    embedding: Optional[List[float]] = Field(None, description="Pre-computed embedding vector")
    embedding_model_id: Optional[str] = Field(
        None, description="Model used to generate the embedding"
    )
    idempotency_key: Optional[str] = Field(None, description="Optional key for idempotency checks")


# ============================================================================
# Routes
# ============================================================================


@router.post("/stm/turns", response_model=WriteTurnResult, status_code=status.HTTP_201_CREATED)
async def write_turn(request: Request, body: WriteTurnRequest):
    """
    Write a conversation turn to short-term memory.

    Short-term memory stores individual conversation turns/messages.
    These are later consolidated into episodic summaries during maintenance.
    """
    engine = request.app.state.engine

    try:
        engine_result = engine.write_turn(
            session_id=body.session_id,
            role=body.role,
            org_id=body.org_id,
            user_id=body.user_id,
            content=body.content,
            tokens=body.tokens,
            stop_reason=body.stop_reason,
            model_name=body.model_name,
            tool_calls=body.tool_calls,
            tool_call_id=body.tool_call_id,
            tool_name=body.tool_name,
            is_error=body.is_error,
            agent_id=body.agent_id,
            share_learning_with_team=body.share_learning_with_team,
            visibility=body.visibility,
            project_id=body.project_id,
            metadata=body.metadata,
            embedding=body.embedding,
            embedding_model_id=body.embedding_model_id,
            idempotency_key=body.idempotency_key,
        )

        # Convert dataclass to Pydantic model
        return WriteTurnResult(
            id=engine_result.id,
            session_id=engine_result.session_id,
            turn_seq=engine_result.turn_seq,
            acknowledged=engine_result.acknowledged,
        )

    except Exception as e:
        logger.error(f"Error writing turn: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to write turn: {str(e)}",
        )


@router.get("/stm/turns")
async def list_turns(
    request: Request,
    filters: ListSTMFilters = Depends(),
    offset: int = 0,
):
    """
    List conversation turns for a session.

    Query parameters validated by ListSTMFilters model, plus:
        offset: Skip first N results (default 0)
    """
    engine = request.app.state.engine

    try:
        # Get turns via engine method
        turns = engine.list_turns(
            session_id=filters.session_id,
            org_id=filters.org_id,
            limit=filters.limit,
            offset=offset,
        )

        # Convert to dicts if needed
        turn_dicts = []
        for turn in turns:
            if isinstance(turn, dict):
                turn_dicts.append(turn)
            elif hasattr(turn, "model_dump"):
                turn_dicts.append(turn.model_dump())
            elif hasattr(turn, "dict"):
                turn_dicts.append(turn.dict())
            else:
                turn_dicts.append(turn)

        return {
            "turns": turn_dicts,
            "count": len(turn_dicts),
            "session_id": filters.session_id,
        }

    except Exception as e:
        logger.error(f"Error listing turns: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list turns: {str(e)}",
        )
