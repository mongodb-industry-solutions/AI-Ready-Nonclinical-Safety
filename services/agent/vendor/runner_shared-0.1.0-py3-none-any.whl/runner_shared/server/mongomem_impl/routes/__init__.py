"""HTTP routes for mongomem memory operations."""
