"""Shared filter models for GET list operations."""

from typing import Optional

from pydantic import BaseModel, Field


class BaseListFilters(BaseModel):
    """Base filters shared by all memory list operations."""

    org_id: str = Field(..., description="Organization ID")
    user_id: Optional[str] = Field(None, description="Filter by user ID")
    visibility: Optional[str] = Field(None, description="Filter by visibility scope")
    project_id: str = Field(..., description="Project ID")
    limit: int = Field(default=100, ge=1, le=1000, description="Maximum number of results")
    include_deleted: bool = Field(default=False, description="Include soft-deleted documents")


class ListSemanticFilters(BaseListFilters):
    """Filters for listing semantic memories."""

    label: Optional[str] = Field(None, description="Filter by label (partial match)")


class ListEpisodicFilters(BaseListFilters):
    """Filters for listing episodic memories."""

    session_id: Optional[str] = Field(None, description="Filter by session ID")


class ListTaxonomicFilters(BaseListFilters):
    """Filters for listing taxonomic memories."""

    domain: Optional[str] = Field(None, description="Filter by domain")
    query_expansion: Optional[bool] = Field(None, description="Filter by query expansion flag")


class ListProceduralFilters(BaseListFilters):
    """Filters for listing procedural memories."""

    tags: Optional[str] = Field(None, description="Filter by tags (comma-separated)")


class ListSTMFilters(BaseModel):
    """Filters for listing STM turns."""

    session_id: str = Field(..., description="Session identifier")
    org_id: str = Field(..., description="Organization ID")
    project_id: Optional[str] = Field(None, description="Project ID")
    limit: int = Field(default=100, ge=1, le=1000, description="Maximum number of results")


class ListUserContextFilters(BaseModel):
    """Filters for listing user contexts."""

    org_id: str = Field(..., description="Organization ID")
    user_id: Optional[str] = Field(None, description="Filter by user ID")
    limit: int = Field(default=100, ge=1, le=1000, description="Maximum number of results")
