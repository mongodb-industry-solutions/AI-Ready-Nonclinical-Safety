"""Document ingestion HTTP routes."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Request, status
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

router = APIRouter()


# ============================================================================
# Request Models
# ============================================================================


class IngestDocumentsRequest(BaseModel):
    """Request to ingest documents synchronously."""

    paths: List[str] = Field(..., description="List of file paths or URIs to ingest")
    org_id: str = Field(..., description="Organization ID")
    user_id: str = Field(..., description="User ID of the creator")
    visibility: str = Field(default="org", description="Visibility scope (private, shared, org)")
    project_id: Optional[str] = Field(None, description="Project ID for shared visibility")
    generate_embeddings: bool = Field(
        default=True, description="Whether to generate embeddings synchronously"
    )
    config: Optional[Dict[str, Any]] = Field(None, description="Optional IngestConfig parameters")


class QueueIngestionRequest(BaseModel):
    """Request to queue documents for async ingestion."""

    paths: List[str] = Field(..., description="List of file paths to ingest")
    org_id: str = Field(..., description="Organization ID")
    user_id: str = Field(..., description="User ID of the creator")
    visibility: str = Field(default="org", description="Visibility scope (private, shared, org)")
    project_id: Optional[str] = Field(None, description="Project ID for shared visibility")
    generate_embeddings: bool = Field(default=True, description="Whether to generate embeddings")
    config: Optional[Dict[str, Any]] = Field(None, description="Optional IngestConfig parameters")


# ============================================================================
# Routes
# ============================================================================


@router.post("/ingest", status_code=status.HTTP_201_CREATED)
async def ingest_documents(request: Request, body: IngestDocumentsRequest):
    """
    Ingest PDF, PPTX, DOCX, and TXT documents into semantic memory (synchronous).

    Extracts text from files, chunks it, and stores as semantic memories.

    Supported file types:
    - .txt (plain text)
    - .pdf (PDF documents)
    - .pptx (PowerPoint presentations)
    - .docx (Word documents)

    Supported storage backends:
    - Local filesystem: "/path/to/file.pdf"
    - Google Cloud Storage: "gs://bucket/path/file.pdf"
    - Directories: "gs://bucket/docs/" or "/local/dir/"

    Returns:
        IngestResult with processing details including files_processed,
        files_succeeded, files_failed, total_chunks, and chunk_ids.
    """
    engine = request.app.state.engine

    try:
        # Convert config dict to IngestConfig if provided
        ingest_config = None
        if body.config:
            from runner_shared.server.mongomem_impl.src.mongomem_core.ingest.models import (
                IngestConfig,
            )

            ingest_config = IngestConfig(**body.config)

        result = engine.ingest_documents(
            paths=body.paths,
            org_id=body.org_id,
            user_id=body.user_id,
            config=ingest_config,
            visibility=body.visibility,
            project_id=body.project_id,
            generate_embeddings=body.generate_embeddings,
        )

        return {
            "files_processed": result.files_processed,
            "files_succeeded": result.files_succeeded,
            "files_failed": result.files_failed,
            "total_chunks": result.total_chunks,
            "chunk_ids": result.chunk_ids,
            "file_results": [
                {
                    "path": fr.path,
                    "success": fr.success,
                    "chunks_created": fr.chunks_created,
                    "error": fr.error,
                }
                for fr in result.file_results
            ],
        }

    except Exception as e:
        logger.error(f"Error ingesting documents: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to ingest documents: {str(e)}",
        )


@router.post("/ingest/queue", status_code=status.HTTP_202_ACCEPTED)
async def queue_ingestion(request: Request, body: QueueIngestionRequest):
    """
    Queue documents for async ingestion by the worker.

    Unlike /ingest which blocks until complete, this endpoint returns
    immediately after queuing the job. The worker processes the ingestion
    in the background.

    Returns:
        QueuedIngestJob with job_id for status tracking.

    Note:
        Requires MongoMemWorker to be running to process the job.
    """
    engine = request.app.state.engine

    try:
        # Convert config dict to IngestConfig if provided
        ingest_config = None
        if body.config:
            from runner_shared.server.mongomem_impl.src.mongomem_core.ingest.models import (
                IngestConfig,
            )

            ingest_config = IngestConfig(**body.config)

        job = engine.queue_ingestion(
            paths=body.paths,
            org_id=body.org_id,
            user_id=body.user_id,
            config=ingest_config,
            visibility=body.visibility,
            project_id=body.project_id,
            generate_embeddings=body.generate_embeddings,
        )

        return {
            "job_id": job.job_id,
            "state": job.state,
            "created_at": job.created_at.isoformat() if job.created_at else None,
        }

    except Exception as e:
        logger.error(f"Error queueing ingestion: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to queue ingestion: {str(e)}",
        )


@router.get("/ingest/status/{job_id}")
async def get_ingestion_status(request: Request, job_id: str):
    """
    Get the status of a queued ingestion job.

    Args:
        job_id: Job ID returned by POST /ingest/queue

    Returns:
        IngestJobStatus with current state and progress, or 404 if not found.
    """
    engine = request.app.state.engine

    try:
        status_obj = engine.get_ingestion_status(job_id)

        if status_obj is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Ingestion job not found: {job_id}",
            )

        return {
            "job_id": status_obj.job_id,
            "state": status_obj.state,
            "total_files": status_obj.total_files,
            "files_processed": status_obj.files_processed,
            "files_succeeded": status_obj.files_succeeded,
            "files_failed": status_obj.files_failed,
            "total_chunks": status_obj.total_chunks,
            "error": status_obj.error,
            "created_at": status_obj.created_at.isoformat() if status_obj.created_at else None,
            "updated_at": status_obj.updated_at.isoformat() if status_obj.updated_at else None,
            "completed_at": status_obj.completed_at.isoformat()
            if status_obj.completed_at
            else None,
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting ingestion status: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get ingestion status: {str(e)}",
        )
