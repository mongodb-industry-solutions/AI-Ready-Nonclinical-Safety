"""Context building HTTP routes."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Request
from magenta_sdk_core.api.v1.memory import ContextResponse
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

router = APIRouter()


# ============================================================================
# Request Models
# ============================================================================


class BuildContextRequest(BaseModel):
    """Request to build formatted context from memories."""

    query: str = Field(..., description="Query text for embedding generation")
    session_id: Optional[str] = Field(None, description="Session identifier")
    org_id: str = Field(..., description="Organization ID")
    user_id: str = Field(..., description="User ID")
    visibility: Optional[str] = Field(None, description="Memory visibility scope")
    project_id: str = Field(..., description="Project ID")
    metadata_filter: Optional[Dict[str, Any]] = Field(
        None, description="Field-level metadata filter"
    )
    query_embedding: Optional[List[float]] = Field(None, description="Pre-computed query embedding")
    model_type: str = Field(default="openai", description="Target model format (openai, claude)")
    max_tokens: Optional[int] = Field(None, description="Token budget limit")
    enabled_sources: Optional[List[str]] = Field(None, description="Memory sources to use")
    top_k: int = Field(default=50, description="Maximum number of results per source")
    similarity_threshold: float = Field(default=0.0, description="Minimum similarity score")
    format_style: Optional[str] = Field(None, description="Format style (openai, claude, jinja2)")
    include_memories: bool = Field(
        default=False, description="Include selected MemoryChunks in response"
    )


# ============================================================================
# Routes
# ============================================================================


@router.post("/retrieval/context", response_model=ContextResponse)
async def build_context(request: Request, body: BuildContextRequest):
    """
    Build formatted context from memories using the full retrieval pipeline.

    Orchestrates:
    1. Generate query embedding (if needed)
    2. Fetch memories via RetrievalHub
    3. Rank memories via MemoryRanker
    4. Select memories within budget via Budgeter
    5. Format into final context via Formatter

    Returns formatted context ready for LLM prompts with token counts and metadata.
    """
    engine = request.app.state.engine

    try:
        kwargs: Dict[str, Any] = dict(
            query=body.query,
            session_id=body.session_id or "",
            org_id=body.org_id,
            user_id=body.user_id,
            visibility=body.visibility,
            project_id=body.project_id,
            query_embedding=body.query_embedding,
            model_type=body.model_type,
            max_tokens=body.max_tokens,
            enabled_sources=set(body.enabled_sources) if body.enabled_sources else None,
            top_k=body.top_k,
            similarity_threshold=body.similarity_threshold,
            format_style=body.format_style,
            include_memories=body.include_memories,
        )
        if body.metadata_filter:
            from mongomem_core.models.filters import MetadataFilter

            kwargs["metadata_filter"] = MetadataFilter(raw=body.metadata_filter)

        engine_response = engine.build_context(**kwargs)

        # The engine already returns a Pydantic ContextResponse, just return it
        # FastAPI will serialize it automatically
        return engine_response

    except Exception as e:
        logger.error(f"Error building context: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to build context: {str(e)}",
        )
