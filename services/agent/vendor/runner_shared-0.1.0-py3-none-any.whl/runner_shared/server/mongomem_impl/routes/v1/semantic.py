"""Semantic memory HTTP routes."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from magenta_sdk_core.api.v1.memory import (
    BulkCreateSemanticResult,
    CreateSemanticResult,
    DeleteResult,
)
from pydantic import BaseModel, Field

from runner_shared.server.mongomem_impl.routes.v1.filters import ListSemanticFilters

logger = logging.getLogger(__name__)

router = APIRouter()


# ============================================================================
# Request Models
# ============================================================================


class CreateSemanticRequest(BaseModel):
    """Request to create a semantic memory."""

    label: str = Field(..., description="Unique identifier/label for this knowledge chunk")
    text: str = Field(..., description="The actual content to store and embed")
    org_id: str = Field(..., description="Organization ID")
    user_id: str = Field(..., description="User ID who owns this memory")
    source: Optional[str] = Field(None, description="Optional source reference")
    visibility: str = Field(
        default="private", description="Visibility scope (private, shared, org)"
    )
    project_id: str = Field(..., description="Project ID")
    contextual_metadata: Optional[Dict[str, Any]] = Field(None, description="Additional context")
    agent_id: Optional[str] = Field(None, description="Agent ID if created via agent")
    extraction_source: Optional[str] = Field(None, description="Source type")
    embedding: Optional[List[float]] = Field(None, description="Pre-computed embedding vector")
    skip_embedding: bool = Field(default=False, description="Skip embedding generation")
    upsert: bool = Field(
        default=False, description="Update the existing semantic memory with this label"
    )


class BulkCreateSemanticRequest(BaseModel):
    """Request to bulk create semantic memories."""

    items: List[Dict[str, Any]] = Field(..., description="List of semantic memory items")
    org_id: str = Field(..., description="Organization ID")
    user_id: str = Field(..., description="User ID who owns these memories")
    visibility: str = Field(default="private", description="Visibility scope for all items")
    project_id: str = Field(..., description="Project ID")
    generate_embeddings: bool = Field(default=True, description="Generate embeddings for all items")
    skip_duplicates: bool = Field(
        default=True, description="Skip duplicate labels instead of failing"
    )


class UpdateSemanticRequest(BaseModel):
    """Request to update a semantic memory."""

    org_id: str = Field(..., description="Organization ID")
    text: Optional[str] = Field(None, description="New text content")
    source: Optional[str] = Field(None, description="New source reference")
    visibility: Optional[str] = Field(None, description="New visibility")
    project_id: str = Field(..., description="Project ID")
    contextual_metadata: Optional[Dict[str, Any]] = Field(None, description="New metadata")


# ============================================================================
# Routes
# ============================================================================


@router.post("/semantic", response_model=CreateSemanticResult, status_code=status.HTTP_201_CREATED)
async def create_semantic(request: Request, body: CreateSemanticRequest):
    """
    Create a semantic memory (fact/knowledge chunk).

    Semantic memories store facts, knowledge, and information that can be
    retrieved via vector similarity search.
    """
    engine = request.app.state.engine

    try:
        engine_result = engine.create_semantic(
            label=body.label,
            text=body.text,
            org_id=body.org_id,
            user_id=body.user_id,
            source=body.source,
            visibility=body.visibility,
            project_id=body.project_id,
            contextual_metadata=body.contextual_metadata,
            agent_id=body.agent_id,
            extraction_source=body.extraction_source,
            embedding=body.embedding,
            skip_embedding=body.skip_embedding,
            upsert=body.upsert,
        )

        # Convert dataclass to Pydantic model
        return CreateSemanticResult(
            id=engine_result.id,
            label=engine_result.label,
            has_embedding=engine_result.has_embedding,
            acknowledged=engine_result.acknowledged,
        )

    except Exception as e:
        logger.error(f"Error creating semantic memory: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create semantic memory: {str(e)}",
        )


@router.post(
    "/semantic/bulk", response_model=BulkCreateSemanticResult, status_code=status.HTTP_201_CREATED
)
async def bulk_create_semantic(request: Request, body: BulkCreateSemanticRequest):
    """
    Bulk create multiple semantic memories efficiently.

    Uses MongoDB's insert_many for single round-trip insertion.
    Optionally generates embeddings for all items in a batch.
    """
    engine = request.app.state.engine

    try:
        engine_result = engine.bulk_create_semantic(
            items=body.items,
            org_id=body.org_id,
            user_id=body.user_id,
            visibility=body.visibility,
            project_id=body.project_id,
            generate_embeddings=body.generate_embeddings,
            skip_duplicates=body.skip_duplicates,
        )

        # Convert dataclass to Pydantic model
        return BulkCreateSemanticResult(
            created_count=engine_result.created_count,
            skipped_count=engine_result.skipped_count,
            created_ids=engine_result.created_ids,
            skipped_labels=engine_result.skipped_labels,
            has_embeddings=engine_result.has_embeddings,
            acknowledged=engine_result.acknowledged,
        )

    except Exception as e:
        logger.error(f"Error bulk creating semantic memories: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to bulk create semantic memories: {str(e)}",
        )


@router.get("/semantic/{memory_id}")
async def get_semantic_by_id(
    request: Request,
    memory_id: str,
    org_id: str,
    project_id: str,
    user_id: str | None = None,
    visibility: str | None = None,
):
    """
    Retrieve a semantic memory by ID.

    Args:
        memory_id: The semantic memory document ID
        org_id: Organization ID (query parameter)
        project_id: Project ID (query parameter)
        user_id: Optional user ID filter (query parameter)
        visibility: Optional visibility filter (query parameter)
    """
    engine = request.app.state.engine

    try:
        result = engine.get_semantic(
            org_id=org_id,
            id=memory_id,
            project_id=project_id,
            user_id=user_id,
            visibility=visibility,
        )

        if result is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Semantic memory not found: {memory_id}",
            )

        return (
            result
            if isinstance(result, dict)
            else (result.model_dump() if hasattr(result, "model_dump") else result.dict())
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting semantic memory: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get semantic memory: {str(e)}",
        )


@router.get("/semantic")
async def list_semantic(
    request: Request,
    filters: ListSemanticFilters = Depends(),
):
    """
    List semantic memories with optional filters.

    Query parameters validated by ListSemanticFilters model.
    """
    engine = request.app.state.engine

    try:
        # If label filter is provided, use get_semantic instead of list_semantic
        if filters.label:
            result = engine.get_semantic(
                org_id=filters.org_id,
                label=filters.label,
                project_id=filters.project_id,
                user_id=filters.user_id,
                visibility=filters.visibility,
            )
            if result is None:
                entries = []
            elif isinstance(result, dict):
                entries = [result]
            elif hasattr(result, "model_dump"):
                entries = [result.model_dump()]
            elif hasattr(result, "dict"):
                entries = [result.dict()]
            else:
                entries = [result]
        else:
            # Remove label from filters before passing to list_semantic
            filter_dict = filters.model_dump()
            filter_dict.pop("label", None)
            results = engine.list_semantic(**filter_dict)

            entries = []
            for result in results:
                if isinstance(result, dict):
                    entries.append(result)
                elif hasattr(result, "model_dump"):
                    entries.append(result.model_dump())
                elif hasattr(result, "dict"):
                    entries.append(result.dict())
                else:
                    entries.append(result)

        return {
            "entries": entries,
            "count": len(entries),
        }

    except Exception as e:
        logger.error(f"Error listing semantic memories: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list semantic memories: {str(e)}",
        )


@router.patch("/semantic/{memory_id}")
async def update_semantic(request: Request, memory_id: str, body: UpdateSemanticRequest):
    """
    Update a semantic memory.

    Args:
        memory_id: The semantic memory document ID
        body: Fields to update
    """
    engine = request.app.state.engine

    try:
        result = engine.update_semantic(
            org_id=body.org_id,
            id=memory_id,
            text=body.text,
            source=body.source,
            visibility=body.visibility,
            project_id=body.project_id,
            contextual_metadata=body.contextual_metadata,
        )

        if result is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Semantic memory not found: {memory_id}",
            )

        return (
            result
            if isinstance(result, dict)
            else (result.model_dump() if hasattr(result, "model_dump") else result.dict())
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating semantic memory: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update semantic memory: {str(e)}",
        )


@router.delete("/semantic/{memory_id}", response_model=DeleteResult)
async def delete_semantic(
    request: Request,
    memory_id: str,
    org_id: str,
    soft: bool = True,
):
    """
    Delete a semantic memory.

    Args:
        memory_id: The semantic memory document ID
        org_id: Organization ID (query parameter)
        soft: If true, soft delete (default). If false, hard delete.
    """
    engine = request.app.state.engine

    try:
        engine_result = engine.delete_semantic(
            org_id=org_id,
            id=memory_id,
            soft=soft,
        )

        # Convert dataclass to Pydantic model
        return DeleteResult(
            deleted_count=engine_result.deleted_count,
            acknowledged=engine_result.acknowledged,
        )

    except Exception as e:
        logger.error(f"Error deleting semantic memory: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete semantic memory: {str(e)}",
        )
