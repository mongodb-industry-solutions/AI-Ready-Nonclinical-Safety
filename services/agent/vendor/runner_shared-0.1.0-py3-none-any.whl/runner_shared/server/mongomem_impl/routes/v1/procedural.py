"""Procedural memory HTTP routes."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from magenta_sdk_core.api.v1.memory import CreateProceduralResult, DeleteResult
from pydantic import BaseModel, Field

from runner_shared.server.mongomem_impl.routes.v1.filters import ListProceduralFilters

logger = logging.getLogger(__name__)

router = APIRouter()


# ============================================================================
# Request Models
# ============================================================================


class CreateProceduralRequest(BaseModel):
    """Request to create a procedural memory."""

    procedure: str = Field(..., description="Unique kebab-case name for this procedure")
    description: str = Field(..., description="What this procedure does and when to use it")
    content: str = Field(..., description="Full instruction body (markdown)")
    org_id: str = Field(..., description="Organization ID")
    user_id: str = Field(..., description="User ID who owns this memory")
    steps: Optional[List[Dict[str, Any]]] = Field(None, description="Structured steps")
    resources: Optional[List[Dict[str, Any]]] = Field(None, description="Associated resources")
    allowed_tools: Optional[List[str]] = Field(None, description="Pre-approved tools")
    compatibility: Optional[str] = Field(None, description="Environment requirements")
    license: Optional[str] = Field(None, description="License for sharing")
    trigger_conditions: Optional[List[str]] = Field(
        None, description="Explicit activation triggers"
    )
    tags: Optional[List[str]] = Field(None, description="Categorization tags")
    visibility: str = Field(default="private", description="Visibility scope")
    project_id: str = Field(..., description="Project ID")
    agent_id: Optional[str] = Field(None, description="Agent ID")
    extraction_source: Optional[str] = Field(None, description="Source type")
    source_format: Optional[str] = Field(None, description="Original format if migrated")
    source_path: Optional[str] = Field(None, description="Original file path")
    embedding: Optional[List[float]] = Field(None, description="Pre-computed embedding")
    skip_embedding: bool = Field(default=False, description="Skip embedding generation")


class UpdateProceduralRequest(BaseModel):
    """Request to update a procedural memory."""

    org_id: str = Field(..., description="Organization ID")
    description: Optional[str] = Field(None, description="New description")
    content: Optional[str] = Field(None, description="New content")
    steps: Optional[List[Dict[str, Any]]] = Field(None, description="New steps")
    resources: Optional[List[Dict[str, Any]]] = Field(None, description="New resources")
    allowed_tools: Optional[List[str]] = Field(None, description="New allowed tools")
    trigger_conditions: Optional[List[str]] = Field(None, description="New triggers")
    tags: Optional[List[str]] = Field(None, description="New tags")
    visibility: Optional[str] = Field(None, description="New visibility")
    project_id: str = Field(..., description="Project ID")


# ============================================================================
# Routes
# ============================================================================


@router.post(
    "/procedural", response_model=CreateProceduralResult, status_code=status.HTTP_201_CREATED
)
async def create_procedural(request: Request, body: CreateProceduralRequest):
    """
    Create a procedural memory (skill/procedure).

    Procedural memories store workflows, procedures, and reusable skills
    that can be discovered and activated based on semantic similarity.
    """
    engine = request.app.state.engine

    try:
        engine_result = engine.create_procedural(
            procedure=body.procedure,
            description=body.description,
            content=body.content,
            org_id=body.org_id,
            user_id=body.user_id,
            steps=body.steps,
            resources=body.resources,
            allowed_tools=body.allowed_tools,
            compatibility=body.compatibility,
            license=body.license,
            trigger_conditions=body.trigger_conditions,
            tags=body.tags,
            visibility=body.visibility,
            project_id=body.project_id,
            agent_id=body.agent_id,
            extraction_source=body.extraction_source,
            source_format=body.source_format,
            source_path=body.source_path,
            embedding=body.embedding,
            skip_embedding=body.skip_embedding,
        )

        # Convert dataclass to Pydantic model
        return CreateProceduralResult(
            id=engine_result.id,
            procedure=engine_result.procedure,
            has_embedding=engine_result.has_embedding,
            acknowledged=engine_result.acknowledged,
        )

    except Exception as e:
        logger.error(f"Error creating procedural memory: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create procedural memory: {str(e)}",
        )


@router.get("/procedural/{memory_id}")
async def get_procedural(
    request: Request,
    memory_id: str,
    org_id: str,
    project_id: str,
    user_id: str | None = None,
    visibility: str | None = None,
):
    """
    Retrieve a procedural memory by ID.

    Args:
        memory_id: The procedural memory document ID
        org_id: Organization ID (query parameter)
        project_id: Project ID (query parameter)
        user_id: Optional user ID filter (query parameter)
        visibility: Optional visibility filter (query parameter)
    """
    engine = request.app.state.engine

    try:
        result = engine.get_procedural(
            org_id=org_id,
            project_id=project_id,
            id=memory_id,
            user_id=user_id,
            visibility=visibility,
        )

        if result is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Procedural memory not found: {memory_id}",
            )

        return (
            result
            if isinstance(result, dict)
            else (result.model_dump() if hasattr(result, "model_dump") else result.dict())
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting procedural memory: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get procedural memory: {str(e)}",
        )


@router.get("/procedural")
async def list_procedural(
    request: Request,
    filters: ListProceduralFilters = Depends(),
):
    """
    List procedural memories with optional filters.

    Query parameters validated by ListProceduralFilters model.
    """
    engine = request.app.state.engine

    try:
        # Parse comma-separated tags
        filter_dict = filters.model_dump()
        if filter_dict.get("tags"):
            filter_dict["tags"] = filter_dict["tags"].split(",")

        results = engine.list_procedural(**filter_dict)

        entries = []
        for result in results:
            if isinstance(result, dict):
                entries.append(result)
            elif hasattr(result, "model_dump"):
                entries.append(result.model_dump())
            elif hasattr(result, "dict"):
                entries.append(result.dict())
            else:
                entries.append(result)

        return {
            "entries": entries,
            "count": len(entries),
        }

    except Exception as e:
        logger.error(f"Error listing procedural memories: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list procedural memories: {str(e)}",
        )


@router.patch("/procedural/{memory_id}")
async def update_procedural(request: Request, memory_id: str, body: UpdateProceduralRequest):
    """
    Update a procedural memory.

    Args:
        memory_id: The procedural memory document ID
        body: Fields to update
    """
    engine = request.app.state.engine

    try:
        result = engine.update_procedural(
            org_id=body.org_id,
            id=memory_id,
            description=body.description,
            content=body.content,
            steps=body.steps,
            resources=body.resources,
            allowed_tools=body.allowed_tools,
            trigger_conditions=body.trigger_conditions,
            tags=body.tags,
            visibility=body.visibility,
            project_id=body.project_id,
        )

        if result is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Procedural memory not found: {memory_id}",
            )

        return (
            result
            if isinstance(result, dict)
            else (result.model_dump() if hasattr(result, "model_dump") else result.dict())
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating procedural memory: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update procedural memory: {str(e)}",
        )


@router.delete("/procedural/{memory_id}", response_model=DeleteResult)
async def delete_procedural(
    request: Request,
    memory_id: str,
    org_id: str,
    soft: bool = True,
):
    """
    Delete a procedural memory.

    Args:
        memory_id: The procedural memory document ID
        org_id: Organization ID (query parameter)
        soft: If true, soft delete (default). If false, hard delete.
    """
    engine = request.app.state.engine

    try:
        engine_result = engine.delete_procedural(
            org_id=org_id,
            id=memory_id,
            soft=soft,
        )

        # Convert dataclass to Pydantic model
        return DeleteResult(
            deleted_count=engine_result.deleted_count,
            acknowledged=engine_result.acknowledged,
        )

    except Exception as e:
        logger.error(f"Error deleting procedural memory: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete procedural memory: {str(e)}",
        )
