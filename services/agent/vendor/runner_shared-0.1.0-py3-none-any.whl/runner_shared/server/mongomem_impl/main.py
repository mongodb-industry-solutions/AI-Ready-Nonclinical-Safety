"""Memory Engine initialization and configuration."""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
from typing import Any, Optional

# Ensure mongomem_impl/src is on sys.path so that internal absolute imports
# like `from mongomem_core.xxx import yyy` resolve correctly when runner-shared
# is installed as a wheel (where mongomem_impl/src is not a top-level package).
_MONGOMEM_IMPL_SRC = Path(__file__).parent / "src"
if str(_MONGOMEM_IMPL_SRC) not in sys.path:
    sys.path.insert(0, str(_MONGOMEM_IMPL_SRC))

logger = logging.getLogger(__name__)


def create_engine(llm: Optional[Any] = None) -> Any:
    """
    Create and initialize MemoryEngine from environment variables.

    Args:
        llm: Optional LLM instance to attach to the engine. When provided, the
            engine's llm property is set so MongoMemWorker can use it to enable
            extraction handlers (semantic, episodic, etc.).

    Environment variables:
        MONGODB_URI: MongoDB connection string (default: mongodb://127.0.0.1:27017?directConnection=true)
        MONGOMEM_DB_NAME: Database name (default: agentic_memory)
        VOYAGE_API_KEY: Voyage AI API key for embeddings (optional)
        VOYAGE_URL: Voyage AI base URL override (optional)
        VOYAGE_MODEL: Model name (default: voyage-4-large)
        VOYAGE_DIMENSION: Embedding dimension (default: 1024)
        MONGOMEM_HOST: Server host (default: 127.0.0.1)
        MONGOMEM_PORT: Server port (default: 8081)

    Returns:
        MemoryEngine instance configured from environment
    """
    # Import here to avoid circular dependencies
    from runner_shared.server.mongomem_impl.src.mongomem_core import MemoryEngine
    from runner_shared.server.mongomem_impl.src.mongomem_core.config import Settings
    from runner_shared.voyage import DEFAULT_VOYAGE_DIMENSION

    # Map runner-shared env vars to mongomem env vars
    mongo_uri = os.getenv("MONGODB_URI", "mongodb://127.0.0.1:27017?directConnection=true")
    db_name = os.getenv("MONGOMEM_DB_NAME", "agentic_memory")

    voyage_api_key = os.getenv("VOYAGE_API_KEY")
    voyage_dimension_str = os.getenv("VOYAGE_DIMENSION", str(DEFAULT_VOYAGE_DIMENSION))
    try:
        voyage_dimension = int(voyage_dimension_str)
        if voyage_dimension <= 0:
            raise ValueError
    except ValueError:
        logger.warning(
            f"Invalid VOYAGE_DIMENSION '{voyage_dimension_str}', using {DEFAULT_VOYAGE_DIMENSION}"
        )
        voyage_dimension = DEFAULT_VOYAGE_DIMENSION

    # Update environment for mongomem config BEFORE creating Settings
    voyage_dimension_env = str(voyage_dimension)
    os.environ["MONGODB_URI"] = mongo_uri
    os.environ["MONGOMEM_DB_NAME"] = db_name
    os.environ["MONGOMEM_EMBEDDING_DIMENSION"] = voyage_dimension_env

    logger.info(
        "Initializing MemoryEngine: uri_hash=%s, db_name=%s, embedding_dimension=%s",
        hash(mongo_uri) % 10000,
        db_name,
        voyage_dimension,
    )

    # Create embedder if VOYAGE_API_KEY is set
    embedder = None
    if voyage_api_key:
        try:
            from runner_shared.voyage import VoyageService

            os.environ["VOYAGE_DIMENSION"] = voyage_dimension_env
            logger.info("Initializing Voyage embedder")
            embedder = VoyageService()
            voyage_dimension = embedder.dimension
            logger.info("Voyage embedder initialized successfully")
        except ImportError as e:
            logger.warning(
                f"Could not import VoyageService: {e}. Embeddings will not be available."
            )
        except Exception as e:
            logger.warning(
                f"Failed to initialize Voyage embedder: {e}. Embeddings will not be available."
            )
    else:
        logger.info("VOYAGE_API_KEY not set, embeddings will not be available")

    # Create settings from environment
    settings = Settings.from_env()

    # Override embedding dimension to match embedder
    if embedder:
        settings.embedding_dimension = voyage_dimension
        logger.info(f"Set settings.embedding_dimension={voyage_dimension} to match embedder")

    # Create engine — llm is passed so extraction handlers are enabled
    engine = MemoryEngine.from_config(
        settings,
        embedder=embedder,
        llm=llm,
    )

    # Bootstrap database (create collections and indexes)
    logger.info("Bootstrapping database")
    try:
        engine.bootstrap()
        logger.info("Database bootstrap complete")
    except Exception as e:
        logger.error(f"Database bootstrap failed: {e}", exc_info=True)
        raise

    logger.info("MemoryEngine initialized successfully")
    return engine


_ALL_EXTRACTION_TYPES = ["semantic", "episodic", "taxonomic", "entity", "preferences", "procedural"]


def _build_extraction_config() -> dict:
    """Build extraction_config from MONGOMEM_ENABLED_EXTRACTIONS env var.

    Env var:
        MONGOMEM_ENABLED_EXTRACTIONS: comma-separated list (default: "semantic,episodic,taxonomic,entity,preferences,procedural")
        Valid values: semantic, episodic, taxonomic, entity, preferences, procedural
    """
    enabled_str = os.getenv(
        "MONGOMEM_ENABLED_EXTRACTIONS", "semantic,episodic,taxonomic,entity,preferences,procedural"
    )
    enabled = {t.strip() for t in enabled_str.split(",")}
    return {t: {"enabled": t in enabled} for t in _ALL_EXTRACTION_TYPES}


# Provider detection order: openai first, then others
_LLM_PROVIDER_ENV_VARS: dict[str, str] = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "gemini": "GEMINI_API_KEY",
    "cerebras": "CEREBRAS_API_KEY",
}

_LLM_PROVIDER_DEFAULT_MODELS: dict[str, str] = {
    "openai": "gpt-4o-mini",
    "anthropic": "claude-3-5-sonnet-latest",
    "gemini": "gemini-2.5-flash-lite",
    "cerebras": "llama-3.3-70b",
}


def _detect_llm_provider() -> tuple[str, str] | None:
    """Return (provider, api_key) for the first configured LLM provider, or None."""
    for provider, env_var in _LLM_PROVIDER_ENV_VARS.items():
        api_key = os.getenv(env_var, "").strip()
        if api_key:
            return provider, api_key
    return None


def _build_llm(provider: str, api_key: str):
    """Build a LLMProtocol-compatible LiteLLM adapter for the given provider."""
    import json

    import litellm

    model_name = os.getenv(
        "MONGOMEM_LLM_MODEL", _LLM_PROVIDER_DEFAULT_MODELS.get(provider, "gpt-4o-mini")
    )
    openai_base_url = os.getenv("OPENAI_BASE_URL", "").strip()
    anthropic_base_url = os.getenv("ANTHROPIC_BASE_URL", "").strip()

    # Build litellm kwargs based on provider
    completion_kwargs: dict = {"api_key": api_key}

    if provider == "openai":
        litellm_model = model_name
        if openai_base_url and "grove-foundry" in openai_base_url:
            completion_kwargs["base_url"] = openai_base_url.split("/v1")[0] + "/v1"
            completion_kwargs["extra_headers"] = {"api-key": api_key}
        elif openai_base_url:
            completion_kwargs["base_url"] = openai_base_url.rstrip("/")
    elif provider == "anthropic":
        litellm_model = model_name if "/" in model_name else f"anthropic/{model_name}"
        if anthropic_base_url:
            completion_kwargs["base_url"] = anthropic_base_url.rstrip("/")
    elif provider == "gemini":
        litellm_model = model_name if "/" in model_name else f"gemini/{model_name}"
    elif provider == "cerebras":
        litellm_model = model_name if "/" in model_name else f"cerebras/{model_name}"
    else:
        litellm_model = model_name

    class _LiteLLMAdapter:
        """LLMProtocol adapter backed by litellm."""

        def __init__(self) -> None:
            self._model = litellm_model
            self._kwargs = completion_kwargs

        def complete(self, prompt: str, **kwargs: object) -> str:
            response = litellm.completion(
                model=self._model,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1000,
                **self._kwargs,
            )
            return response.choices[0].message.content or ""

        def complete_json(self, prompt: str, schema: dict, **kwargs: object) -> dict:
            json_prompt = prompt + "\n\nRespond with valid JSON only."
            response = litellm.completion(
                model=self._model,
                messages=[{"role": "user", "content": json_prompt}],
                max_tokens=2000,
                response_format={"type": "json_object"},
                **self._kwargs,
            )
            content = (response.choices[0].message.content or "{}").strip()
            if content.startswith("```"):
                lines = content.split("\n")
                content = "\n".join(lines[1:-1] if lines[-1] == "```" else lines[1:])
            return json.loads(content)

        @property
        def model_id(self) -> str:
            return self._model

    return _LiteLLMAdapter()


def create_worker(engine: Any) -> Optional[Any]:
    """
    Create MongoMemWorker configured for on-demand pipeline processing.

    The worker is driven externally via POST /api/v1/worker/processTasks — it does not
    run its own loop. The OE enqueues a check_promotion task and calls the endpoint
    to drain the queue (check_promotion → snapshot → semantic + episodic).

    Requires both an embedder (VOYAGE_API_KEY) and an LLM provider key. If either
    is absent the extraction pipeline is disabled and None is returned.

    LLM provider is auto-detected from whichever of these env vars is set:
        OPENAI_API_KEY, ANTHROPIC_API_KEY, GEMINI_API_KEY, CEREBRAS_API_KEY
    If none are set, the extraction pipeline is disabled.

    Other environment variables:
        MONGOMEM_LLM_MODEL: Override model name (default varies by provider)
        MONGOMEM_ENABLED_EXTRACTIONS: Comma-separated extraction types (default: semantic,episodic)
        MONGOMEM_SNAPSHOT_MAX_MESSAGES: STM message count threshold (default: 20)
        MONGOMEM_SNAPSHOT_STALE_MINUTES: Stale session threshold in minutes (default: 3)
        MONGOMEM_SNAPSHOT_DELETE_PROMOTED: Delete STM docs after promotion instead of
            marking them promoted=True (default: false — keep docs, mark promoted)
        MONGOMEM_EMBED_STM_BEFORE_PROMOTION: Batch-embed unembedded STM docs before
            evaluating promotion thresholds (default: false)
        MONGOMEM_WORKER_DB_NAME: Separate DB for task queue (default: same as core DB)

    Returns:
        MongoMemWorker instance (not yet initialized), or None if embedder or LLM not configured.
    """
    if engine.embedder is None:
        logger.warning(
            "No embedder available (VOYAGE_API_KEY not set) - extraction pipeline disabled"
        )
        return None

    if engine.llm is None:
        logger.warning("No LLM available (no provider API key set) - extraction pipeline disabled")
        return None

    try:
        from runner_shared.server.mongomem_impl.src.mongomem_core.models.config.snapshot_config import (
            SnapshotConfig,
        )
        from runner_shared.server.mongomem_impl.src.mongomem_worker.worker import MongoMemWorker

        logger.info("Creating MongoMemWorker (llm=%s)", getattr(engine.llm, "model_id", "unknown"))

        # Force change streams off — on-demand mode polls via /worker/processTasks,
        # change streams must not run alongside it.
        os.environ["MONGOMEM_WORKER_ENABLE_CHANGE_STREAMS"] = "false"

        worker = MongoMemWorker(
            engine=engine,
            scaling_mode="distributed",
            auto_extract_on_snapshot=True,
            embed_stm_before_promotion=os.getenv(
                "MONGOMEM_EMBED_STM_BEFORE_PROMOTION", "false"
            ).lower()
            == "true",
            snapshot_config=SnapshotConfig(
                strategy="auto",
                embedding_strategy="generate",
                max_messages=int(os.getenv("MONGOMEM_SNAPSHOT_MAX_MESSAGES", "20")),
                stale_minutes=int(os.getenv("MONGOMEM_SNAPSHOT_STALE_MINUTES", "3")),
                # Keep promoted STM docs so subsequent check_promotion calls for the
                # same session see them as already-promoted via exclude_promoted=True.
                delete_promoted=os.getenv("MONGOMEM_SNAPSHOT_DELETE_PROMOTED", "false").lower()
                == "true",
            ),
            extraction_config=_build_extraction_config(),
            worker_db_name=os.getenv("MONGOMEM_WORKER_DB_NAME"),
        )

        enabled = os.getenv(
            "MONGOMEM_ENABLED_EXTRACTIONS",
            "semantic,episodic,taxonomic,entity,preferences,procedural",
        )
        logger.info("MongoMemWorker created (extractions: %s)", enabled)
        return worker

    except Exception as exc:
        logger.warning("MongoMemWorker creation failed — extraction pipeline disabled: %s", exc)
        return None


if __name__ == "__main__":
    """Run the memory server."""
    import uvicorn

    from runner_shared.server.mongomem_impl.app import create_app

    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # Get server config from environment
    host = os.getenv("MONGOMEM_HOST", "127.0.0.1")
    port = int(os.getenv("MONGOMEM_PORT", "8081"))

    logger.info(f"Starting memory server on {host}:{port}")

    # Build LLM first so the engine can be constructed with it — this ensures
    # MongoMemWorker.is_extraction_enabled() returns True for configured types.
    llm = _build_llm(*detected) if (detected := _detect_llm_provider()) else None
    engine = create_engine(llm=llm)
    worker = create_worker(engine)
    app = create_app(engine, worker)

    # Run server
    uvicorn.run(app, host=host, port=port)
