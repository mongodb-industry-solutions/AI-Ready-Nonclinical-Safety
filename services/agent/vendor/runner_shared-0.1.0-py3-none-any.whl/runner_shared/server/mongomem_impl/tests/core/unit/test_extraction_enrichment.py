"""Unit tests for extraction enrichment module."""

import pytest
from mongomem_core.extraction.enrichment import (
    enrich_citations,
    enrich_single,
)
from mongomem_core.extraction.types import ExtractedItem


class TestEnrichCitations:
    """Tests for enrich_citations function."""

    @pytest.fixture
    def sample_messages(self):
        """Sample conversation messages."""
        return [
            {"role": "user", "content": "I'm a Data Scientist at a tech company in Boston."},
            {"role": "assistant", "content": "That's great! What kind of projects do you work on?"},
            {"role": "user", "content": "Mostly machine learning and data visualization."},
        ]

    def test_empty_extractions(self, sample_messages):
        """Test with empty extractions list."""
        extractions = []
        enrich_citations(extractions, sample_messages)
        assert extractions == []

    def test_no_citations(self, sample_messages):
        """Test extraction with no citations."""
        item = ExtractedItem(content="Some fact", citations=[])
        extractions = [item]

        enrich_citations(extractions, sample_messages)

        assert item.cited_text == []

    def test_single_citation(self, sample_messages):
        """Test extraction with single citation."""
        item = ExtractedItem(
            content="The user is a Data Scientist",
            citations=[0],
        )
        extractions = [item]

        enrich_citations(extractions, sample_messages)

        assert len(item.cited_text) == 1
        assert item.cited_text[0]["cited_idx"] == 0
        assert item.cited_text[0]["cited_text"] == sample_messages[0]

    def test_multiple_citations(self, sample_messages):
        """Test extraction with multiple citations."""
        item = ExtractedItem(
            content="The user works on ML and data viz",
            citations=[0, 2],
        )
        extractions = [item]

        enrich_citations(extractions, sample_messages)

        assert len(item.cited_text) == 2
        assert item.cited_text[0]["cited_idx"] == 0
        assert item.cited_text[1]["cited_idx"] == 2

    def test_out_of_bounds_citation(self, sample_messages, caplog):
        """Test handling of out-of-bounds citation index."""
        item = ExtractedItem(
            content="Some fact",
            citations=[0, 10],  # 10 is out of bounds
        )
        extractions = [item]

        enrich_citations(extractions, sample_messages)

        # Only valid citation should be added
        assert len(item.cited_text) == 1
        assert item.cited_text[0]["cited_idx"] == 0
        assert "out of bounds" in caplog.text.lower()

    def test_negative_citation_index(self, sample_messages, caplog):
        """Test handling of negative citation index."""
        item = ExtractedItem(
            content="Some fact",
            citations=[-1, 0],
        )
        extractions = [item]

        enrich_citations(extractions, sample_messages)

        # Only valid citation should be added
        assert len(item.cited_text) == 1
        assert item.cited_text[0]["cited_idx"] == 0

    def test_multiple_extractions(self, sample_messages):
        """Test enriching multiple extractions."""
        extractions = [
            ExtractedItem(content="Fact 1", citations=[0]),
            ExtractedItem(content="Fact 2", citations=[2]),
            ExtractedItem(content="Fact 3", citations=[]),
        ]

        enrich_citations(extractions, sample_messages)

        assert len(extractions[0].cited_text) == 1
        assert len(extractions[1].cited_text) == 1
        assert len(extractions[2].cited_text) == 0

    def test_empty_messages(self, caplog):
        """Test with empty messages list."""
        item = ExtractedItem(content="Some fact", citations=[0])
        extractions = [item]

        enrich_citations(extractions, [])

        # No citations should be added (all out of bounds)
        assert len(item.cited_text) == 0

    def test_modifies_in_place(self, sample_messages):
        """Test that function modifies extractions in-place."""
        item = ExtractedItem(content="Some fact", citations=[0])
        original_id = id(item)
        extractions = [item]

        enrich_citations(extractions, sample_messages)

        # Should be same object, modified in place
        assert id(extractions[0]) == original_id
        assert len(item.cited_text) == 1


class TestEnrichSingle:
    """Tests for enrich_single function."""

    @pytest.fixture
    def sample_messages(self):
        """Sample conversation messages."""
        return [
            {"role": "user", "content": "I love Python programming."},
            {"role": "assistant", "content": "Python is great for many things!"},
        ]

    def test_enrich_single(self, sample_messages):
        """Test enriching a single extraction."""
        item = ExtractedItem(
            content="The user loves Python",
            citations=[0],
        )

        result = enrich_single(item, sample_messages)

        # Returns the same item (modified in place)
        assert result is item
        assert len(result.cited_text) == 1
        assert result.cited_text[0]["cited_idx"] == 0

    def test_enrich_single_no_citations(self, sample_messages):
        """Test enriching with no citations."""
        item = ExtractedItem(content="Some fact", citations=[])

        result = enrich_single(item, sample_messages)

        assert result.cited_text == []
