"""Tests for the observability protocol and default implementations."""

from __future__ import annotations

import logging

from mongomem_core.observability import (
    CoreObservability,
    LoggingObservability,
    NoOpObservability,
    ObservabilityProtocol,
)

# Import for isinstance checks in tests
from ...conftest import RecordingObservability


class TestProtocolConformance:
    """Verify implementations satisfy ObservabilityProtocol."""

    def test_all_implementations_are_protocol_instances(self):
        """All observability implementations satisfy the protocol."""
        assert isinstance(NoOpObservability(), ObservabilityProtocol)
        assert isinstance(LoggingObservability(), ObservabilityProtocol)
        assert isinstance(RecordingObservability(), ObservabilityProtocol)


class TestNoOpObservability:
    """Tests for the no-op observability implementation."""

    def test_all_methods_do_not_raise(self):
        """All NoOpObservability methods execute without raising."""
        obs = NoOpObservability()
        obs.increment("test.counter", value=1.0, tags={"key": "value"})
        obs.gauge("test.gauge", value=42.0, tags={"key": "value"})
        obs.histogram("test.histogram", value=123.45)
        obs.timing("test.timing", value_ms=99.9)
        obs.event("test.event", attributes={"key": "value"}, level="info")
        with obs.span("test.span", kind="internal", attributes={"foo": "bar"}) as span:
            span["added"] = "value"

    def test_span_yields_empty_dict(self):
        """NoOpObservability span yields empty dict."""
        obs = NoOpObservability()
        with obs.span("test.span") as span:
            assert span == {}


class TestLoggingObservability:
    """Tests for the logging observability implementation."""

    def test_all_metric_types_log_correctly(self, caplog):
        """All metric types produce appropriate log output."""
        obs = LoggingObservability(log_level=logging.INFO)
        with caplog.at_level(logging.INFO):
            obs.increment("test.counter", value=2.0, tags={"env": "test"})
            obs.gauge("test.gauge", value=42.0)
            obs.histogram("test.histogram", value=123.45)
            obs.timing("test.timing", value_ms=99.99)

        assert "[metric:counter]" in caplog.text
        assert "[metric:gauge]" in caplog.text
        assert "[metric:histogram]" in caplog.text
        assert "[metric:timing]" in caplog.text

    def test_span_logs_start_end_and_captures_attributes(self, caplog):
        """Span logs start/end and captures added attributes."""
        obs = LoggingObservability(log_level=logging.INFO)
        with caplog.at_level(logging.INFO):
            with obs.span("test.span", kind="client") as span:
                span["result_count"] = 5

        assert "[span:start]" in caplog.text
        assert "[span:end]" in caplog.text
        assert "result_count" in caplog.text

    def test_event_logs_at_specified_level(self, caplog):
        """Event logs at the specified level with attributes."""
        obs = LoggingObservability()
        with caplog.at_level(logging.WARNING):
            obs.event("test.warning", attributes={"code": 123}, level="warning")

        assert "[event]" in caplog.text
        assert "test.warning" in caplog.text


class TestCoreObservability:
    """Tests for the CoreObservability domain-specific helper."""

    def test_defaults_to_noop_backend(self):
        """CoreObservability defaults to NoOpObservability backend."""
        metrics = CoreObservability()
        # Should not raise
        metrics.write_turn_started()
        metrics.write_turn_completed(100.0)

    def test_track_write_turn_emits_count_and_latency(self, recording_obs: RecordingObservability):
        """track_write_turn() emits count increment and latency timing."""
        metrics = CoreObservability(backend=recording_obs)

        with metrics.track_write_turn():
            pass

        assert len(recording_obs.get_increments("mongomem.engine.write_turn.count")) == 1
        timings = recording_obs.get_timings("mongomem.engine.write_turn.latency")
        assert len(timings) == 1
        assert timings[0]["value_ms"] >= 0

    def test_track_internal_state_update_emits_latency_and_tokens(
        self, recording_obs: RecordingObservability
    ):
        """track_internal_state_update() emits latency and token histogram."""
        metrics = CoreObservability(backend=recording_obs)

        with metrics.track_internal_state_update() as ctx:
            ctx["tokens"] = 500

        timings = recording_obs.get_timings("mongomem.engine.internal_state.latency")
        assert len(timings) == 1

        histograms = [h for h in recording_obs.histograms if "tokens" in h["name"]]
        assert len(histograms) == 1
        assert histograms[0]["value"] == 500

    def test_track_internal_state_update_defaults_tokens_to_zero(
        self, recording_obs: RecordingObservability
    ):
        """track_internal_state_update() defaults tokens to 0 if not set."""
        metrics = CoreObservability(backend=recording_obs)

        with metrics.track_internal_state_update():
            pass  # Forget to set tokens

        histograms = [h for h in recording_obs.histograms if "tokens" in h["name"]]
        assert histograms[0]["value"] == 0

    def test_context_built_emits_all_metrics(self, recording_obs: RecordingObservability):
        """context_built() emits latency, memories count, and tokens."""
        metrics = CoreObservability(backend=recording_obs)

        metrics.context_built(memories_count=10, tokens=2000, duration_ms=300.0)

        assert len(recording_obs.get_timings("mongomem.context.latency")) == 1
        count_histograms = [h for h in recording_obs.histograms if "memories.count" in h["name"]]
        assert count_histograms[0]["value"] == 10

    def test_span_context_stage_creates_span_with_attributes(
        self, recording_obs: RecordingObservability
    ):
        """span_context_stage() creates span and captures attributes."""
        metrics = CoreObservability(backend=recording_obs)

        with metrics.span_context_stage("embed_query", attributes={"query_len": 50}) as span:
            span["result"] = "success"

        spans = [s for s in recording_obs.spans if "embed_query" in s["name"]]
        assert len(spans) == 1
        assert spans[0]["completed"]
        assert spans[0]["attributes"]["query_len"] == 50
        assert spans[0]["attributes"]["result"] == "success"

    def test_retrieval_source_completed(self, recording_obs: RecordingObservability):
        """retrieval_source_completed() emits source-tagged metrics."""
        metrics = CoreObservability(backend=recording_obs)

        metrics.retrieval_source_completed("semantic", count=5, duration_ms=75.0)

        timings = recording_obs.get_timings("mongomem.retrieval.source.latency")
        assert timings[0]["tags"]["source"] == "semantic"

    def test_retrieval_source_completed_includes_status_tag(
        self, recording_obs: RecordingObservability
    ):
        """retrieval_source_completed() includes status=success tag for differentiation."""
        metrics = CoreObservability(backend=recording_obs)

        metrics.retrieval_source_completed(source="stm", count=5, duration_ms=100.0)

        timings = recording_obs.get_timings("mongomem.retrieval.source.latency")
        assert len(timings) == 1
        assert timings[0]["tags"]["status"] == "success"

    def test_retrieval_source_failed_emits_increment(self, recording_obs: RecordingObservability):
        """retrieval_source_failed() emits failure count metric."""
        metrics = CoreObservability(backend=recording_obs)

        metrics.retrieval_source_failed(source="semantic", error_type="timeout")

        assert len(recording_obs.increments) == 1
        inc = recording_obs.increments[0]
        assert inc["name"] == "mongomem.retrieval.source.failed"
        assert inc["tags"]["source"] == "semantic"
        assert inc["tags"]["error_type"] == "timeout"
        assert inc["tags"]["status"] == "error"

    def test_retrieval_source_failed_with_duration(self, recording_obs: RecordingObservability):
        """retrieval_source_failed() emits latency when duration provided."""
        metrics = CoreObservability(backend=recording_obs)

        metrics.retrieval_source_failed(
            source="episodic", error_type="database_error", duration_ms=150.5
        )

        assert len(recording_obs.increments) == 1
        timings = recording_obs.get_timings("mongomem.retrieval.source.latency")
        assert len(timings) == 1
        assert timings[0]["value_ms"] == 150.5
        assert timings[0]["tags"]["source"] == "episodic"
        assert timings[0]["tags"]["status"] == "error"

    def test_retrieval_source_failed_without_duration(self, recording_obs: RecordingObservability):
        """retrieval_source_failed() skips latency when duration not provided."""
        metrics = CoreObservability(backend=recording_obs)

        metrics.retrieval_source_failed(source="taxonomic", error_type="unknown")

        assert len(recording_obs.increments) == 1
        assert len(recording_obs.timings) == 0  # No timing emitted

    def test_track_context_build(self, recording_obs: RecordingObservability):
        """track_context_build() emits context metrics."""
        metrics = CoreObservability(backend=recording_obs)

        with metrics.track_context_build() as ctx:
            ctx["memories_count"] = 10
            ctx["tokens"] = 500

        assert len(recording_obs.get_timings("mongomem.context.latency")) == 1
        histograms = [h for h in recording_obs.histograms if "memories.count" in h["name"]]
        assert histograms[0]["value"] == 10
        tokens_histograms = [h for h in recording_obs.histograms if "tokens.used" in h["name"]]
        assert tokens_histograms[0]["value"] == 500

    def test_track_retrieval_source(self, recording_obs: RecordingObservability):
        """track_retrieval_source() emits source metrics."""
        metrics = CoreObservability(backend=recording_obs)

        with metrics.track_retrieval_source("semantic") as ctx:
            ctx["count"] = 25

        timings = recording_obs.get_timings("mongomem.retrieval.source.latency")
        assert len(timings) == 1
        assert timings[0]["tags"]["source"] == "semantic"

        histograms = [h for h in recording_obs.histograms if "source.count" in h["name"]]
        assert histograms[0]["value"] == 25

    def test_extraction_completed(self, recording_obs: RecordingObservability):
        """extraction_completed() emits extraction-type-tagged metrics."""
        metrics = CoreObservability(backend=recording_obs)

        metrics.extraction_completed("semantic", extracted_count=3, duration_ms=500.0)

        timings = recording_obs.get_timings("mongomem.extraction.latency")
        assert timings[0]["tags"]["extraction_type"] == "semantic"

    def test_approval_staged_emits_counter_and_event(self, recording_obs: RecordingObservability):
        """approval_staged() emits counter and structured event."""
        metrics = CoreObservability(backend=recording_obs)

        metrics.approval_staged("semantic", action="add", source_id="src-123")

        assert len(recording_obs.get_increments("mongomem.approval.staged")) == 1
        events = recording_obs.get_events("mongomem.approval.staged")
        assert events[0]["attributes"]["source_id"] == "src-123"

    def test_approval_approved_emits_counter_histogram_and_event(
        self, recording_obs: RecordingObservability
    ):
        """approval_approved() emits counter, queue time histogram, and event."""
        metrics = CoreObservability(backend=recording_obs)

        metrics.approval_approved("mem-123", queue_time_ms=5000.0, approved_by="admin")

        assert len(recording_obs.get_increments("mongomem.approval.approved")) == 1
        events = recording_obs.get_events("mongomem.approval.approved")
        assert events[0]["attributes"]["memory_id"] == "mem-123"

    def test_tags_include_org_and_user_when_provided(self, recording_obs: RecordingObservability):
        """Tags include org_id and user_id when configured."""
        metrics = CoreObservability(backend=recording_obs, org_id="test-org", user_id="test-user")

        metrics.write_turn_started()

        tags = recording_obs.increments[0]["tags"]
        assert tags["org_id"] == "test-org"
        assert tags["user_id"] == "test-user"

    def test_tags_exclude_org_and_user_when_not_provided(
        self, recording_obs: RecordingObservability
    ):
        """Tags exclude org_id and user_id when not configured."""
        metrics = CoreObservability(backend=recording_obs)

        metrics.write_turn_started()

        tags = recording_obs.increments[0]["tags"]
        assert "org_id" not in tags
        assert "user_id" not in tags

    def test_embedding_generated(self, recording_obs: RecordingObservability):
        """embedding_generated() emits dimension-tagged metrics."""
        metrics = CoreObservability(backend=recording_obs)

        metrics.embedding_generated(text_length=500, dimension=1024, duration_ms=25.0)

        increments = recording_obs.get_increments("mongomem.embedding.generated")
        assert increments[0]["tags"]["dimension"] == "1024"

    def test_ingest_file_metrics(self, recording_obs: RecordingObservability):
        """Ingest file metrics emit with file_type tag."""
        metrics = CoreObservability(backend=recording_obs)

        metrics.ingest_file_processed("pdf")
        metrics.ingest_file_failed("docx", error_type="parse_error")

        processed = recording_obs.get_increments("mongomem.ingest.files.processed")
        assert processed[0]["tags"]["file_type"] == "pdf"

        failed = recording_obs.get_increments("mongomem.ingest.files.failed")
        assert failed[0]["tags"]["error_type"] == "parse_error"
