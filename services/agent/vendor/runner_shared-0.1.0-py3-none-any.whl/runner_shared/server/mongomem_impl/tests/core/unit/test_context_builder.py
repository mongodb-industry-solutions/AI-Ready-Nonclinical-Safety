"""
Unit tests for ContextBuilder orchestration logic.

These tests validate the ContextBuilder class behavior including:
- Pipeline orchestration
- Query embedding resolution
- Config merging with user context
- Timing metadata tracking
- Error handling
"""

from datetime import datetime, timezone
from unittest.mock import MagicMock

import pytest
from mongomem_core.models.memory.user_prefs import (
    UserContextMemoryOut,
)
from mongomem_core.models.retrieval import (
    ContextConfig,
    ContextMetadata,
    ContextResponse,
    MemoryChunk,
    MemorySource,
)
from mongomem_core.retrieval.budgeting import Budgeter
from mongomem_core.retrieval.context_builder import (
    ContextBuilder,
)
from mongomem_core.retrieval.formatting import Formatter
from mongomem_core.retrieval.ranking import MemoryRanker
from mongomem_core.retrieval.sources import RetrievalHub


def _make_memory_chunk(
    id: str,
    content: str = "Test content",
    source: MemorySource = MemorySource.EPISODIC,
) -> MemoryChunk:
    """Helper to create a MemoryChunk for testing."""
    return MemoryChunk(
        id=id,
        content=content,
        source=source,
        timestamp=datetime.now(timezone.utc),
        similarity_score=0.8,
    )


def _make_user_context(
    tone: str = "formal",
    style: str = "concise",
    language: str = "en",
    preferred_format: str = "bullet_points",
) -> UserContextMemoryOut:
    """Helper to create a UserContextMemoryOut for testing."""
    return UserContextMemoryOut(
        id="user_ctx_123",
        org_id="test_org",
        user_id="test_user",
        tone=tone,
        style=style,
        language=language,
        preferred_format=preferred_format,
        source="user_input",
    )


class TestContextBuilderInitialization:
    """Tests for ContextBuilder initialization."""

    def test_default_initialization(self):
        """ContextBuilder initializes with required components."""
        hub = RetrievalHub()
        ranker = MemoryRanker()
        budgeter = Budgeter()
        formatter = Formatter()

        builder = ContextBuilder(
            retrieval_hub=hub,
            ranker=ranker,
            budgeter=budgeter,
            formatter=formatter,
        )

        assert builder._retrieval_hub is hub
        assert builder._ranker is ranker
        assert builder._budgeter is budgeter
        assert builder._formatter is formatter
        assert builder._embedder is None
        assert builder._llm is None

    def test_initialization_with_optional_protocols(self):
        """ContextBuilder accepts optional embedder and llm."""
        hub = RetrievalHub()
        ranker = MemoryRanker()
        budgeter = Budgeter()
        formatter = Formatter()

        mock_embedder = MagicMock()
        mock_embedder.embed.return_value = [0.1] * 1024
        mock_embedder.dimension = 1024
        mock_embedder.model_id = "test-embedder"

        mock_llm = MagicMock()
        mock_llm.model_id = "gpt-4"

        builder = ContextBuilder(
            retrieval_hub=hub,
            ranker=ranker,
            budgeter=budgeter,
            formatter=formatter,
            embedder=mock_embedder,
            llm=mock_llm,
        )

        assert builder._embedder is mock_embedder
        assert builder._llm is mock_llm


class TestResolveQueryEmbedding:
    """Tests for _resolve_query_embedding method."""

    def test_uses_provided_embedding(self):
        """Uses query_embedding when provided."""
        builder = ContextBuilder(
            retrieval_hub=RetrievalHub(),
            ranker=MemoryRanker(),
            budgeter=Budgeter(),
            formatter=Formatter(),
        )

        provided_embedding = [0.1, 0.2, 0.3]
        result = builder._resolve_query_embedding("test query", provided_embedding)

        assert result == provided_embedding

    def test_generates_embedding_via_embedder(self):
        """Generates embedding via embedder when query_embedding not provided."""
        mock_embedder = MagicMock()
        expected_embedding = [0.5, 0.6, 0.7]
        mock_embedder.embed.return_value = expected_embedding

        builder = ContextBuilder(
            retrieval_hub=RetrievalHub(),
            ranker=MemoryRanker(),
            budgeter=Budgeter(),
            formatter=Formatter(),
            embedder=mock_embedder,
        )

        result = builder._resolve_query_embedding("test query", None)

        assert result == expected_embedding
        mock_embedder.embed.assert_called_once_with("test query")

    def test_raises_error_when_no_embedding_available(self):
        """Raises ValueError when neither embedding nor embedder available."""
        builder = ContextBuilder(
            retrieval_hub=RetrievalHub(),
            ranker=MemoryRanker(),
            budgeter=Budgeter(),
            formatter=Formatter(),
        )

        with pytest.raises(ValueError, match="query_embedding not provided"):
            builder._resolve_query_embedding("test query", None)

    def test_raises_error_with_empty_embedding_list(self):
        """Raises ValueError when query_embedding is empty list."""
        builder = ContextBuilder(
            retrieval_hub=RetrievalHub(),
            ranker=MemoryRanker(),
            budgeter=Budgeter(),
            formatter=Formatter(),
        )

        with pytest.raises(ValueError, match="query_embedding not provided"):
            builder._resolve_query_embedding("test query", [])

    def test_raises_error_when_query_empty_for_embedding(self):
        """Raises ValueError when query is empty and embedding needs generation."""
        mock_embedder = MagicMock()

        builder = ContextBuilder(
            retrieval_hub=RetrievalHub(),
            ranker=MemoryRanker(),
            budgeter=Budgeter(),
            formatter=Formatter(),
            embedder=mock_embedder,
        )

        with pytest.raises(ValueError, match="Query text is required"):
            builder._resolve_query_embedding("", None)

    def test_raises_error_when_query_whitespace_for_embedding(self):
        """Raises ValueError when query is whitespace and embedding needs generation."""
        mock_embedder = MagicMock()

        builder = ContextBuilder(
            retrieval_hub=RetrievalHub(),
            ranker=MemoryRanker(),
            budgeter=Budgeter(),
            formatter=Formatter(),
            embedder=mock_embedder,
        )

        with pytest.raises(ValueError, match="Query text is required"):
            builder._resolve_query_embedding("   ", None)


class TestBuildContextOrchestration:
    """Tests for build_context pipeline orchestration."""

    def test_calls_all_pipeline_stages(self):
        """Calls all pipeline stages in correct order."""
        mock_hub = MagicMock(spec=RetrievalHub)
        mock_ranker = MagicMock(spec=MemoryRanker)
        mock_budgeter = MagicMock(spec=Budgeter)
        mock_formatter = MagicMock(spec=Formatter)
        mock_db = MagicMock()

        # Setup return values
        fetched_memories = [_make_memory_chunk("mem1"), _make_memory_chunk("mem2")]
        ranked_memories = fetched_memories.copy()
        selected_memories = [fetched_memories[0]]

        mock_hub.fetch_memories.return_value = fetched_memories
        mock_ranker.rank_memories.return_value = ranked_memories
        mock_budgeter.select_memories.return_value = selected_memories
        mock_formatter.format_context.return_value = ContextResponse(
            formatted_context="Test context",
            metadata=ContextMetadata(token_count=50),
        )

        builder = ContextBuilder(
            retrieval_hub=mock_hub,
            ranker=mock_ranker,
            budgeter=mock_budgeter,
            formatter=mock_formatter,
        )

        query_embedding = [0.1] * 1024
        result = builder.build_context(
            db=mock_db,
            session_id="sess_123",
            query="test query",
            org_id="org_1",
            query_embedding=query_embedding,
        )

        # Verify result is returned
        assert isinstance(result, ContextResponse)

        # Verify all stages called
        mock_hub.fetch_memories.assert_called_once()
        mock_ranker.rank_memories.assert_called_once()
        mock_budgeter.select_memories.assert_called_once()
        mock_formatter.format_context.assert_called_once()

        # Verify data flow
        assert mock_ranker.rank_memories.call_args[0][0] == fetched_memories
        assert mock_budgeter.select_memories.call_args[1]["memories"] == ranked_memories
        assert mock_formatter.format_context.call_args[1]["memories"] == selected_memories

    def test_passes_llm_to_budgeter_and_formatter(self):
        """Passes LLM to budgeter and formatter for model-specific handling."""
        mock_hub = MagicMock(spec=RetrievalHub)
        mock_ranker = MagicMock(spec=MemoryRanker)
        mock_budgeter = MagicMock(spec=Budgeter)
        mock_formatter = MagicMock(spec=Formatter)
        mock_db = MagicMock()
        mock_llm = MagicMock()
        mock_llm.model_id = "gpt-4"

        mock_hub.fetch_memories.return_value = []
        mock_ranker.rank_memories.return_value = []
        mock_budgeter.select_memories.return_value = []
        mock_formatter.format_context.return_value = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )

        builder = ContextBuilder(
            retrieval_hub=mock_hub,
            ranker=mock_ranker,
            budgeter=mock_budgeter,
            formatter=mock_formatter,
            llm=mock_llm,
        )

        builder.build_context(
            db=mock_db,
            session_id="sess_123",
            query="test",
            org_id="org_1",
            query_embedding=[0.1] * 1024,
        )

        # Verify LLM passed to budgeter
        assert mock_budgeter.select_memories.call_args[1]["llm"] is mock_llm

        # Verify LLM passed to formatter
        assert mock_formatter.format_context.call_args[1]["llm"] is mock_llm

    def test_passes_user_context_to_formatter(self):
        """Passes user_context to formatter for personalization."""
        mock_hub = MagicMock(spec=RetrievalHub)
        mock_ranker = MagicMock(spec=MemoryRanker)
        mock_budgeter = MagicMock(spec=Budgeter)
        mock_formatter = MagicMock(spec=Formatter)
        mock_db = MagicMock()

        mock_hub.fetch_memories.return_value = []
        mock_ranker.rank_memories.return_value = []
        mock_budgeter.select_memories.return_value = []
        mock_formatter.format_context.return_value = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )

        builder = ContextBuilder(
            retrieval_hub=mock_hub,
            ranker=mock_ranker,
            budgeter=mock_budgeter,
            formatter=mock_formatter,
        )

        user_context = _make_user_context()

        builder.build_context(
            db=mock_db,
            session_id="sess_123",
            query="test",
            org_id="org_1",
            query_embedding=[0.1] * 1024,
            user_context=user_context,
        )

        assert mock_formatter.format_context.call_args[1]["user_context"] is user_context

    def test_overrides_enabled_sources(self):
        """Overrides enabled_sources in config when provided."""
        mock_hub = MagicMock(spec=RetrievalHub)
        mock_ranker = MagicMock(spec=MemoryRanker)
        mock_budgeter = MagicMock(spec=Budgeter)
        mock_formatter = MagicMock(spec=Formatter)
        mock_db = MagicMock()

        mock_hub.fetch_memories.return_value = []
        mock_ranker.rank_memories.return_value = []
        mock_budgeter.select_memories.return_value = []
        mock_formatter.format_context.return_value = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )

        builder = ContextBuilder(
            retrieval_hub=mock_hub,
            ranker=mock_ranker,
            budgeter=mock_budgeter,
            formatter=mock_formatter,
        )

        enabled = {MemorySource.STM, MemorySource.EPISODIC}

        builder.build_context(
            db=mock_db,
            session_id="sess_123",
            query="test",
            org_id="org_1",
            query_embedding=[0.1] * 1024,
            enabled_sources=enabled,
        )

        # Check fetch_memories received the enabled_sources
        call_kwargs = mock_hub.fetch_memories.call_args[1]
        assert call_kwargs["enabled_sources"] == enabled

    def test_uses_default_config_when_not_provided(self):
        """Uses default ContextConfig when not provided."""
        mock_hub = MagicMock(spec=RetrievalHub)
        mock_ranker = MagicMock(spec=MemoryRanker)
        mock_budgeter = MagicMock(spec=Budgeter)
        mock_formatter = MagicMock(spec=Formatter)
        mock_db = MagicMock()

        mock_hub.fetch_memories.return_value = []
        mock_ranker.rank_memories.return_value = []
        mock_budgeter.select_memories.return_value = []
        mock_formatter.format_context.return_value = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )

        builder = ContextBuilder(
            retrieval_hub=mock_hub,
            ranker=mock_ranker,
            budgeter=mock_budgeter,
            formatter=mock_formatter,
        )

        builder.build_context(
            db=mock_db,
            session_id="sess_123",
            query="test",
            org_id="org_1",
            query_embedding=[0.1] * 1024,
        )

        # Verify ranker received a ContextConfig
        ranker_call_args = mock_ranker.rank_memories.call_args[0]
        assert len(ranker_call_args) == 2
        assert isinstance(ranker_call_args[1], ContextConfig)


class TestBuildContextTimingMetadata:
    """Tests for timing metadata tracking."""

    def test_adds_timing_metadata(self):
        """Adds timing metadata for all pipeline stages."""
        mock_hub = MagicMock(spec=RetrievalHub)
        mock_ranker = MagicMock(spec=MemoryRanker)
        mock_budgeter = MagicMock(spec=Budgeter)
        mock_formatter = MagicMock(spec=Formatter)
        mock_db = MagicMock()

        mock_hub.fetch_memories.return_value = []
        mock_ranker.rank_memories.return_value = []
        mock_budgeter.select_memories.return_value = []

        response_metadata = ContextMetadata(token_count=0)
        mock_formatter.format_context.return_value = ContextResponse(
            formatted_context="",
            metadata=response_metadata,
        )

        builder = ContextBuilder(
            retrieval_hub=mock_hub,
            ranker=mock_ranker,
            budgeter=mock_budgeter,
            formatter=mock_formatter,
        )

        result = builder.build_context(
            db=mock_db,
            session_id="sess_123",
            query="test",
            org_id="org_1",
            query_embedding=[0.1] * 1024,
        )

        # Verify timing metadata exists for all stages
        timing = result.metadata.timing
        assert "embedding" in timing
        assert "retrieval" in timing
        assert "ranking" in timing
        assert "budgeting" in timing
        assert "formatting" in timing
        assert "total" in timing

        # All timing values should be non-negative
        for stage, duration in timing.items():
            assert duration >= 0, f"Timing for {stage} should be non-negative"

        # Total should be >= sum of individual stages
        individual_total = (
            timing["embedding"]
            + timing["retrieval"]
            + timing["ranking"]
            + timing["budgeting"]
            + timing["formatting"]
        )
        assert timing["total"] >= individual_total * 0.99  # Allow for small timing variations


class TestBuildContextErrorHandling:
    """Tests for error handling in build_context."""

    def test_raises_error_without_embedding_or_embedder(self):
        """Raises ValueError when neither embedding nor embedder available."""
        mock_hub = MagicMock(spec=RetrievalHub)
        mock_ranker = MagicMock(spec=MemoryRanker)
        mock_budgeter = MagicMock(spec=Budgeter)
        mock_formatter = MagicMock(spec=Formatter)
        mock_db = MagicMock()

        builder = ContextBuilder(
            retrieval_hub=mock_hub,
            ranker=mock_ranker,
            budgeter=mock_budgeter,
            formatter=mock_formatter,
        )

        with pytest.raises(ValueError, match="query_embedding not provided"):
            builder.build_context(
                db=mock_db,
                session_id="sess_123",
                query="test",
                org_id="org_1",
            )

    def test_propagates_retrieval_errors(self):
        """Propagates errors from RetrievalHub."""
        mock_hub = MagicMock(spec=RetrievalHub)
        mock_ranker = MagicMock(spec=MemoryRanker)
        mock_budgeter = MagicMock(spec=Budgeter)
        mock_formatter = MagicMock(spec=Formatter)
        mock_db = MagicMock()

        mock_hub.fetch_memories.side_effect = ValueError("Database error")

        builder = ContextBuilder(
            retrieval_hub=mock_hub,
            ranker=mock_ranker,
            budgeter=mock_budgeter,
            formatter=mock_formatter,
        )

        with pytest.raises(ValueError, match="Database error"):
            builder.build_context(
                db=mock_db,
                session_id="sess_123",
                query="test",
                org_id="org_1",
                query_embedding=[0.1] * 1024,
            )


class TestBuildContextWithEmbedder:
    """Tests for build_context when using embedder."""

    def test_generates_embedding_when_not_provided(self):
        """Generates embedding via embedder when query_embedding not provided."""
        mock_hub = MagicMock(spec=RetrievalHub)
        mock_ranker = MagicMock(spec=MemoryRanker)
        mock_budgeter = MagicMock(spec=Budgeter)
        mock_formatter = MagicMock(spec=Formatter)
        mock_db = MagicMock()

        mock_embedder = MagicMock()
        generated_embedding = [0.5] * 1024
        mock_embedder.embed.return_value = generated_embedding

        mock_hub.fetch_memories.return_value = []
        mock_ranker.rank_memories.return_value = []
        mock_budgeter.select_memories.return_value = []
        mock_formatter.format_context.return_value = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )

        builder = ContextBuilder(
            retrieval_hub=mock_hub,
            ranker=mock_ranker,
            budgeter=mock_budgeter,
            formatter=mock_formatter,
            embedder=mock_embedder,
        )

        builder.build_context(
            db=mock_db,
            session_id="sess_123",
            query="test query",
            org_id="org_1",
        )

        # Verify embedder was called
        mock_embedder.embed.assert_called_once_with("test query")

        # Verify generated embedding was used
        call_kwargs = mock_hub.fetch_memories.call_args[1]
        assert call_kwargs["query_embedding"] == generated_embedding

    def test_uses_provided_embedding_over_embedder(self):
        """Uses provided embedding even when embedder available."""
        mock_hub = MagicMock(spec=RetrievalHub)
        mock_ranker = MagicMock(spec=MemoryRanker)
        mock_budgeter = MagicMock(spec=Budgeter)
        mock_formatter = MagicMock(spec=Formatter)
        mock_db = MagicMock()

        mock_embedder = MagicMock()
        mock_embedder.embed.return_value = [0.9] * 1024

        mock_hub.fetch_memories.return_value = []
        mock_ranker.rank_memories.return_value = []
        mock_budgeter.select_memories.return_value = []
        mock_formatter.format_context.return_value = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )

        builder = ContextBuilder(
            retrieval_hub=mock_hub,
            ranker=mock_ranker,
            budgeter=mock_budgeter,
            formatter=mock_formatter,
            embedder=mock_embedder,
        )

        provided_embedding = [0.1] * 1024
        builder.build_context(
            db=mock_db,
            session_id="sess_123",
            query="test query",
            org_id="org_1",
            query_embedding=provided_embedding,
        )

        # Verify embedder was NOT called
        mock_embedder.embed.assert_not_called()

        # Verify provided embedding was used
        call_kwargs = mock_hub.fetch_memories.call_args[1]
        assert call_kwargs["query_embedding"] == provided_embedding


class TestBuildContextParameters:
    """Tests for correct parameter passing through pipeline."""

    def test_passes_all_parameters_to_fetch(self):
        """Passes all relevant parameters to fetch_memories."""
        mock_hub = MagicMock(spec=RetrievalHub)
        mock_ranker = MagicMock(spec=MemoryRanker)
        mock_budgeter = MagicMock(spec=Budgeter)
        mock_formatter = MagicMock(spec=Formatter)
        mock_db = MagicMock()

        mock_hub.fetch_memories.return_value = []
        mock_ranker.rank_memories.return_value = []
        mock_budgeter.select_memories.return_value = []
        mock_formatter.format_context.return_value = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )

        builder = ContextBuilder(
            retrieval_hub=mock_hub,
            ranker=mock_ranker,
            budgeter=mock_budgeter,
            formatter=mock_formatter,
        )

        query_embedding = [0.1] * 1024

        from mongomem_core.models.memory.base import (
            ChunkVisibility,
        )
        from mongomem_core.models.memory.short_term import (
            ShortTermOut,
        )

        # Create minimal STM out for testing
        stm = MagicMock(spec=ShortTermOut)

        builder.build_context(
            db=mock_db,
            session_id="sess_123",
            query="test query",
            org_id="org_1",
            user_id="user_1",
            query_embedding=query_embedding,
            visibility=ChunkVisibility.PRIVATE,
            project_id="group_1",
            top_k=100,
            stm_memories=[stm],
        )

        call_kwargs = mock_hub.fetch_memories.call_args[1]
        assert call_kwargs["session_id"] == "sess_123"
        assert call_kwargs["query_embedding"] == query_embedding
        assert call_kwargs["org_id"] == "org_1"
        assert call_kwargs["user_id"] == "user_1"
        assert call_kwargs["visibility"] == ChunkVisibility.PRIVATE
        assert call_kwargs["project_id"] == "group_1"
        assert call_kwargs["top_k"] == 100
        assert call_kwargs["stm_memories"] == [stm]

    def test_passes_config_to_ranker_and_budgeter(self):
        """Passes effective config to ranker and budgeter."""
        mock_hub = MagicMock(spec=RetrievalHub)
        mock_ranker = MagicMock(spec=MemoryRanker)
        mock_budgeter = MagicMock(spec=Budgeter)
        mock_formatter = MagicMock(spec=Formatter)
        mock_db = MagicMock()

        mock_hub.fetch_memories.return_value = []
        mock_ranker.rank_memories.return_value = []
        mock_budgeter.select_memories.return_value = []
        mock_formatter.format_context.return_value = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )

        builder = ContextBuilder(
            retrieval_hub=mock_hub,
            ranker=mock_ranker,
            budgeter=mock_budgeter,
            formatter=mock_formatter,
        )

        config = ContextConfig(max_tokens=500, similarity_threshold=0.7)

        builder.build_context(
            db=mock_db,
            session_id="sess_123",
            query="test",
            org_id="org_1",
            query_embedding=[0.1] * 1024,
            config=config,
        )

        # Verify config passed to ranker
        ranker_call_args = mock_ranker.rank_memories.call_args[0]
        assert ranker_call_args[1] is config

        # Verify config passed to budgeter
        budgeter_call_kwargs = mock_budgeter.select_memories.call_args[1]
        assert budgeter_call_kwargs["config"] is config

        # Verify config passed to formatter
        formatter_call_kwargs = mock_formatter.format_context.call_args[1]
        assert formatter_call_kwargs["config"] is config
