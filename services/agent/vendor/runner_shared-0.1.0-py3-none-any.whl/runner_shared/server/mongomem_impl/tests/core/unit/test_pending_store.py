"""
Unit tests for PendingStore.

Tests CRUD operations for pending extractions.
"""

from datetime import datetime, timezone
from unittest.mock import MagicMock

import pytest
from bson import ObjectId
from mongomem_core.extraction.approval.store import (
    PendingStore,
)
from mongomem_core.extraction.approval.types import (
    PendingDecisionPayload,
    PendingPreferencesPayload,
)
from mongomem_core.models.memory.base import ChunkVisibility


class TestPendingStoreInit:
    """Tests for PendingStore initialization."""

    def test_init_with_defaults(self):
        """Store initializes with default TTLs."""
        db = MagicMock()
        store = PendingStore(db)

        assert store._pending_ttl_hours == 72  # 3 days
        assert store._audit_retention_days == 30

    def test_init_with_custom_ttls(self):
        """Store initializes with custom TTLs."""
        db = MagicMock()
        store = PendingStore(db, pending_ttl_hours=24, audit_retention_days=7)

        assert store._pending_ttl_hours == 24
        assert store._audit_retention_days == 7


class TestPendingStoreStage:
    """Tests for staging pending extractions."""

    @pytest.fixture
    def store(self):
        """Create a store with mock DB."""
        db = MagicMock()
        inserted_id = ObjectId()
        db["extraction_pending"].insert_one.return_value = MagicMock(inserted_id=inserted_id)
        store = PendingStore(db)
        store._inserted_id = inserted_id
        return store

    def test_stage_decision_payload(self, store):
        """Stage a decision payload."""
        payload = PendingDecisionPayload(
            action="ADD",
            content="User prefers Python",
            confidence=0.9,
            embedding=[0.1] * 10,
        )

        pending_id = store.stage(
            org_id="org-1",
            user_id="user-1",
            source_id="snapshot-123",
            extraction_type="semantic",
            payload=payload,
        )

        assert pending_id is not None
        store._db["extraction_pending"].insert_one.assert_called_once()

    def test_stage_preferences_payload(self, store):
        """Stage a preferences payload."""
        payload = PendingPreferencesPayload(
            session_id="session-123",
            tone="formal",
            expertise_level="expert",
            confidence=0.85,
        )

        pending_id = store.stage(
            org_id="org-1",
            user_id="user-1",
            source_id="snapshot-456",
            extraction_type="preferences",
            payload=payload,
        )

        assert pending_id is not None
        store._db["extraction_pending"].insert_one.assert_called_once()

    def test_stage_sets_expires_at(self, store):
        """Staged items should have expires_at set."""
        payload = PendingDecisionPayload(action="ADD", content="Test")

        store.stage(
            org_id="org-1",
            user_id="user-1",
            source_id="src-1",
            extraction_type="semantic",
            payload=payload,
        )

        call_args = store._db["extraction_pending"].insert_one.call_args[0][0]
        assert "expires_at" in call_args
        assert call_args["status"] == "pending"

    def test_stage_with_visibility_and_group(self, store):
        """Stage with visibility and project_id."""
        payload = PendingDecisionPayload(
            action="ADD",
            content="Team knowledge",
            confidence=0.95,
        )

        store.stage(
            org_id="org-1",
            user_id="user-1",
            source_id="src-1",
            extraction_type="semantic",
            payload=payload,
            visibility=ChunkVisibility.SHARED,
            project_id="team-alpha",
        )

        call_args = store._db["extraction_pending"].insert_one.call_args[0][0]
        assert call_args["visibility"] == "shared"
        assert call_args["project_id"] == "team-alpha"


class TestPendingStoreStageBatch:
    """Tests for batch staging."""

    @pytest.fixture
    def store(self):
        """Create a store with mock DB."""
        db = MagicMock()
        db["extraction_pending"].insert_many.return_value = MagicMock(
            inserted_ids=[ObjectId(), ObjectId(), ObjectId()]
        )
        return PendingStore(db)

    def test_stage_batch_multiple_decisions(self, store):
        """Batch stage multiple decisions."""
        items = [
            ("semantic", PendingDecisionPayload(action="ADD", content=f"Content {i}"))
            for i in range(3)
        ]

        pending_ids = store.stage_batch(
            items=items,
            org_id="org-1",
            user_id="user-1",
            source_id="snapshot-1",
        )

        assert len(pending_ids) == 3
        store._db["extraction_pending"].insert_many.assert_called_once()

    def test_stage_batch_empty_list_returns_empty(self, store):
        """Empty batch returns empty list."""
        pending_ids = store.stage_batch(
            items=[],
            org_id="org-1",
            user_id="user-1",
            source_id="snapshot-1",
        )

        assert pending_ids == []
        store._db["extraction_pending"].insert_many.assert_not_called()


class TestPendingStoreGet:
    """Tests for retrieving pending extractions."""

    @pytest.fixture
    def store(self):
        """Create a store with mock DB."""
        db = MagicMock()
        return PendingStore(db)

    def test_get_existing_pending(self, store):
        """Get an existing pending extraction."""
        pending_id = str(ObjectId())
        store._db["extraction_pending"].find_one.return_value = {
            "_id": ObjectId(pending_id),
            "org_id": "org-1",
            "user_id": "user-1",
            "source_id": "src-1",
            "extraction_type": "semantic",
            "payload": {
                "kind": "decision",
                "action": "ADD",
                "content": "Test content",
            },
            "visibility": "private",
            "status": "pending",
            "created_at": datetime.now(timezone.utc),
        }

        result = store.get(pending_id)

        assert result is not None
        assert result.id == pending_id
        assert result.extraction_type == "semantic"
        assert result.payload.content == "Test content"

    def test_get_nonexistent_returns_none(self, store):
        """Get nonexistent pending returns None."""
        store._db["extraction_pending"].find_one.return_value = None

        result = store.get(str(ObjectId()))

        assert result is None

    def test_get_invalid_id_returns_none(self, store):
        """Get with invalid ObjectId returns None."""
        result = store.get("invalid-id")

        assert result is None


class TestPendingStoreFind:
    """Tests for finding pending extractions."""

    @pytest.fixture
    def store(self):
        """Create a store with mock DB."""
        db = MagicMock()
        return PendingStore(db)

    def test_find_by_org_and_status(self, store):
        """Find pending by org_id and status."""
        store._db["extraction_pending"].find.return_value = MagicMock(
            limit=MagicMock(
                return_value=MagicMock(
                    sort=MagicMock(
                        return_value=[
                            {
                                "_id": ObjectId(),
                                "org_id": "org-1",
                                "user_id": "user-1",
                                "source_id": "src-1",
                                "extraction_type": "semantic",
                                "payload": {
                                    "kind": "decision",
                                    "action": "ADD",
                                    "content": "Test",
                                },
                                "visibility": "private",
                                "status": "pending",
                                "created_at": datetime.now(timezone.utc),
                            }
                        ]
                    )
                )
            )
        )

        results = store.find(org_id="org-1", status="pending")

        assert len(results) == 1
        assert results[0].org_id == "org-1"
        assert results[0].status == "pending"

    def test_find_with_extraction_type_filter(self, store):
        """Find pending by extraction_type."""
        store._db["extraction_pending"].find.return_value = MagicMock(
            limit=MagicMock(return_value=MagicMock(sort=MagicMock(return_value=[])))
        )

        store.find(org_id="org-1", extraction_type="episodic")

        call_args = store._db["extraction_pending"].find.call_args[0][0]
        assert call_args["extraction_type"] == "episodic"

    def test_find_with_user_filter(self, store):
        """Find pending by user_id."""
        store._db["extraction_pending"].find.return_value = MagicMock(
            limit=MagicMock(return_value=MagicMock(sort=MagicMock(return_value=[])))
        )

        store.find(org_id="org-1", user_id="user-1")

        call_args = store._db["extraction_pending"].find.call_args[0][0]
        assert call_args["user_id"] == "user-1"


class TestPendingStoreMarkApproved:
    """Tests for marking as approved."""

    @pytest.fixture
    def store(self):
        """Create a store with mock DB that returns a found document."""
        from datetime import datetime, timezone

        db = MagicMock()
        # find_one_and_update returns the document if found, None if not
        db["extraction_pending"].find_one_and_update.return_value = {
            "_id": "507f1f77bcf86cd799439011",
            "status": "pending",
            "created_at": datetime.now(timezone.utc),
        }
        return PendingStore(db)

    def test_mark_approved_updates_status(self, store):
        """Mark approved updates status and sets memory_id."""
        result = store.mark_approved(
            pending_id="507f1f77bcf86cd799439011",
            memory_id="mem-123",
        )

        assert result is True
        call_args = store._db["extraction_pending"].find_one_and_update.call_args
        update_doc = call_args[0][1]["$set"]
        assert update_doc["status"] == "approved"
        assert update_doc["memory_id"] == "mem-123"

    def test_mark_approved_extends_expires_at(self, store):
        """Mark approved extends expires_at for audit retention."""
        store.mark_approved(
            pending_id="507f1f77bcf86cd799439011",
            memory_id="mem-123",
        )

        call_args = store._db["extraction_pending"].find_one_and_update.call_args
        update_doc = call_args[0][1]["$set"]
        assert "expires_at" in update_doc

    def test_mark_approved_invalid_id_returns_false(self, store):
        """Mark approved with invalid ID returns False."""
        result = store.mark_approved(
            pending_id="invalid-id",
            memory_id="mem-123",
        )

        assert result is False


class TestPendingStoreMarkRejected:
    """Tests for marking as rejected."""

    @pytest.fixture
    def store(self):
        """Create a store with mock DB."""
        db = MagicMock()
        db["extraction_pending"].update_one.return_value = MagicMock(modified_count=1)
        return PendingStore(db)

    def test_mark_rejected_updates_status(self, store):
        """Mark rejected updates status and sets reason."""
        result = store.mark_rejected(
            pending_id="507f1f77bcf86cd799439011",
            reason="Inaccurate",
        )

        assert result is True
        call_args = store._db["extraction_pending"].update_one.call_args
        update_doc = call_args[0][1]["$set"]
        assert update_doc["status"] == "rejected"
        assert update_doc["rejection_reason"] == "Inaccurate"

    def test_mark_rejected_extends_expires_at(self, store):
        """Mark rejected extends expires_at for audit retention."""
        store.mark_rejected(
            pending_id="507f1f77bcf86cd799439011",
            reason="Not needed",
        )

        call_args = store._db["extraction_pending"].update_one.call_args
        update_doc = call_args[0][1]["$set"]
        assert "expires_at" in update_doc

    def test_mark_rejected_invalid_id_returns_false(self, store):
        """Mark rejected with invalid ID returns False."""
        result = store.mark_rejected(
            pending_id="invalid-id",
            reason="Bad",
        )

        assert result is False
