import time

from mongomem_core import MemoryEngine
from mongomem_core.config import Settings
from pymongo import MongoClient

from runner_shared.server.mongomem_impl.src.mongomem_worker import MongoMemWorker
from runner_shared.server.mongomem_impl.src.mongomem_worker.config import WorkerSettings
from runner_shared.server.mongomem_impl.src.mongomem_worker.queue import enqueue_task

from ..conftest import (
    TEST_MONGO_URI,
    FailingEmbedder,
    MockEmbedder,
    MockLLM,
    RecordingMetrics,
    make_stm_document,
    random_db_name,
)


def make_engine(db_name: str, embedder, llm=None) -> MemoryEngine:
    settings = Settings(
        mongo_uri=TEST_MONGO_URI,
        db_name=db_name,
        embedding_dimension=embedder.dimension,
    )
    return MemoryEngine(settings, embedder=embedder, llm=llm)


def wait_for_task_status(db, task_type: str, expected_statuses: set[str], timeout: float = 10.0):
    """Poll until a task reaches one of the expected statuses."""
    deadline = time.time() + timeout
    task = None
    while time.time() < deadline:
        task = db.tasks.find_one({"task_type": task_type})
        if task and task["status"] in expected_statuses:
            return task
        time.sleep(0.1)
    return task


class TestE2EEmbeddingFlow:
    def test_full_embedding_flow(self, mock_embedder: MockEmbedder):
        db_name = random_db_name()
        client = MongoClient(TEST_MONGO_URI)

        try:
            db = client[db_name]

            stm_doc = make_stm_document(content="Hello world")
            db.memory_short_term.insert_one(stm_doc)

            settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=db_name)

            enqueue_task(
                task_type="embedding",
                payload={
                    "doc_id": str(stm_doc["_id"]),
                    "org_id": stm_doc["org_id"],
                    "content": stm_doc["content"],
                    "collection": "memory_short_term",
                },
                settings=settings,
            )

            engine = make_engine(db_name, mock_embedder)
            worker = MongoMemWorker(engine=engine, scaling_mode="distributed")

            worker.start_background()
            time.sleep(1.5)
            worker.stop()
            time.sleep(0.5)

            assert mock_embedder.call_count > 0

            task = db.tasks.find_one({"task_type": "embedding"})
            assert task["status"] == "succeeded"

        finally:
            client.drop_database(db_name)
            client.close()

    def test_multiple_tasks_processed(self, mock_embedder: MockEmbedder):
        db_name = random_db_name()
        client = MongoClient(TEST_MONGO_URI)

        try:
            db = client[db_name]
            settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=db_name)

            for i in range(3):
                doc = make_stm_document(content=f"Message {i}")
                db.memory_short_term.insert_one(doc)
                enqueue_task(
                    task_type="embedding",
                    payload={
                        "doc_id": str(doc["_id"]),
                        "org_id": doc["org_id"],
                        "content": doc["content"],
                        "collection": "memory_short_term",
                    },
                    settings=settings,
                )

            engine = make_engine(db_name, mock_embedder)
            worker = MongoMemWorker(engine=engine, scaling_mode="distributed")

            worker.start_background()
            time.sleep(2.0)
            worker.stop()
            time.sleep(0.5)

            succeeded = db.tasks.count_documents({"status": "succeeded"})
            assert succeeded == 3

        finally:
            client.drop_database(db_name)
            client.close()


class TestE2ERetryFlow:
    def test_transient_error_retry(self):
        db_name = random_db_name()
        client = MongoClient(TEST_MONGO_URI)
        failing_embedder = FailingEmbedder(fail_after=0, error_type="transient")

        try:
            db = client[db_name]
            settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=db_name)

            doc = make_stm_document(content="Test content")
            db.memory_short_term.insert_one(doc)
            enqueue_task(
                task_type="embedding",
                payload={
                    "doc_id": str(doc["_id"]),
                    "org_id": doc["org_id"],
                    "content": doc["content"],
                    "collection": "memory_short_term",
                },
                settings=settings,
                max_retries=3,
            )

            engine = make_engine(db_name, failing_embedder)
            worker = MongoMemWorker(engine=engine, scaling_mode="distributed")

            worker.start_background()
            time.sleep(2.0)
            worker.stop()
            time.sleep(0.5)

            task = db.tasks.find_one({"task_type": "embedding"})
            # Task should be re-queued for retry or eventually fail
            assert task["status"] in ["queued", "failed"]

        finally:
            client.drop_database(db_name)
            client.close()

    def test_permanent_error_no_retry(self):
        db_name = random_db_name()
        client = MongoClient(TEST_MONGO_URI)
        failing_embedder = FailingEmbedder(fail_after=0, error_type="permanent")

        try:
            db = client[db_name]
            settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=db_name)

            doc = make_stm_document(content="Test content")
            db.memory_short_term.insert_one(doc)
            enqueue_task(
                task_type="embedding",
                payload={
                    "doc_id": str(doc["_id"]),
                    "org_id": doc["org_id"],
                    "content": doc["content"],
                    "collection": "memory_short_term",
                },
                settings=settings,
                max_retries=3,
            )

            engine = make_engine(db_name, failing_embedder)
            worker = MongoMemWorker(engine=engine, scaling_mode="distributed")

            worker.start_background()
            task = wait_for_task_status(db, "embedding", {"failed"})
            worker.stop()
            time.sleep(0.5)

            assert task["status"] == "failed", f"Expected 'failed', got '{task['status']}'"

        finally:
            client.drop_database(db_name)
            client.close()


class TestE2EMultiWorker:
    def test_two_workers_share_tasks(self, mock_embedder: MockEmbedder):
        db_name = random_db_name()
        client = MongoClient(TEST_MONGO_URI)
        embedder1 = MockEmbedder()
        embedder2 = MockEmbedder()

        try:
            db = client[db_name]
            settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=db_name)

            for i in range(6):
                doc = make_stm_document(content=f"Message {i}")
                db.memory_short_term.insert_one(doc)
                enqueue_task(
                    task_type="embedding",
                    payload={
                        "doc_id": str(doc["_id"]),
                        "org_id": doc["org_id"],
                        "content": doc["content"],
                        "collection": "memory_short_term",
                    },
                    settings=settings,
                )

            engine1 = make_engine(db_name, embedder1)
            engine2 = make_engine(db_name, embedder2)
            worker1 = MongoMemWorker(engine=engine1, scaling_mode="distributed")
            worker2 = MongoMemWorker(engine=engine2, scaling_mode="distributed")

            worker1.start_background()
            worker2.start_background()
            time.sleep(3.0)
            worker1.stop()
            worker2.stop()
            time.sleep(0.5)

            succeeded = db.tasks.count_documents({"status": "succeeded"})
            assert succeeded == 6

            # Both workers should have processed some tasks
            total_calls = embedder1.call_count + embedder2.call_count
            assert total_calls >= 6

        finally:
            client.drop_database(db_name)
            client.close()


class TestE2EWithLLM:
    def test_extraction_task_with_llm(self, mock_embedder: MockEmbedder, mock_llm: MockLLM):
        db_name = random_db_name()
        client = MongoClient(TEST_MONGO_URI)

        try:
            db = client[db_name]
            settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=db_name)

            doc = make_stm_document(content="John works at MongoDB in NYC")
            db.memory_short_term.insert_one(doc)

            enqueue_task(
                task_type="entity",
                payload={
                    "doc_id": str(doc["_id"]),
                    "org_id": doc["org_id"],
                    "user_id": doc["user_id"],
                    "source_id": str(doc["_id"]),
                    "content": doc["content"],
                    "collection": "memory_short_term",
                },
                settings=settings,
            )

            engine = make_engine(db_name, mock_embedder, mock_llm)
            worker = MongoMemWorker(
                engine=engine,
                scaling_mode="distributed",
                extraction_config={
                    "entity": {"enabled": True},
                },
            )

            worker.start_background()
            time.sleep(1.5)
            worker.stop()
            time.sleep(0.5)

            assert mock_llm.call_count > 0

        finally:
            client.drop_database(db_name)
            client.close()


class TestE2EMetrics:
    def test_metrics_emitted_on_task_processing(
        self, mock_embedder: MockEmbedder, recording_metrics: RecordingMetrics
    ):
        db_name = random_db_name()
        client = MongoClient(TEST_MONGO_URI)

        try:
            db = client[db_name]
            settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=db_name)

            doc = make_stm_document(content="Test content")
            db.memory_short_term.insert_one(doc)
            enqueue_task(
                task_type="embedding",
                payload={
                    "doc_id": str(doc["_id"]),
                    "org_id": doc["org_id"],
                    "content": doc["content"],
                    "collection": "memory_short_term",
                },
                settings=settings,
            )

            engine = make_engine(db_name, mock_embedder)
            worker = MongoMemWorker(
                engine=engine,
                scaling_mode="distributed",
                observability=recording_metrics,
            )

            worker.start_background()
            time.sleep(1.5)
            worker.stop()
            time.sleep(0.5)

            claimed = [i for i in recording_metrics.increments if "claimed" in i["name"]]
            completed = [i for i in recording_metrics.increments if "completed" in i["name"]]

            assert len(claimed) > 0 or len(completed) > 0

        finally:
            client.drop_database(db_name)
            client.close()
