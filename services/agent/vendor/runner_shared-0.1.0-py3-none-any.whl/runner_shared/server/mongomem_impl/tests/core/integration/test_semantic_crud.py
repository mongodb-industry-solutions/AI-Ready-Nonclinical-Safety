"""
Integration tests for semantic memory CRUD operations.

These tests use a real MongoDB database to verify end-to-end behavior
of semantic memory operations.
"""

from concurrent.futures import ThreadPoolExecutor, as_completed

from mongomem_core.memory.semantic import (
    create_semantic,
    get_semantic,
    list_semantic,
    upsert_semantic,
)
from mongomem_core.models.memory.semantic import SemanticIn


class TestSemanticMemoryCRUD:
    """Integration tests for semantic memory CRUD operations."""

    def test_create_and_get_semantic(self, bootstrapped_engine):
        """Test creating and retrieving a semantic memory document."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"

        semantic_in = SemanticIn(
            label="python_basics",
            content="Python is a high-level programming language.",
        )

        created = create_semantic(db, semantic_in, org_id=org_id, user_id=user_id)

        assert created.id is not None
        assert created.label == "python_basics"
        assert created.content == "Python is a high-level programming language."
        assert created.memory_lineage_id is not None
        assert created.memory_lineage_id == str(created.id)  # First version

        # Retrieve by ID
        retrieved = get_semantic(db, org_id, id=str(created.id))
        assert retrieved is not None
        assert retrieved.label == "python_basics"

        # Retrieve by label
        retrieved_by_label = get_semantic(db, org_id, label="python_basics")
        assert retrieved_by_label is not None
        assert retrieved_by_label.id == str(created.id)

    def test_concurrent_create_sets_lineage_before_insert(self, bootstrapped_engine):
        """Concurrent semantic creates should not collide on the latest-lineage index."""
        db = bootstrapped_engine.db
        org_id = "test-org-concurrent-create"
        user_id = "test-user-1"

        def create_one(index: int):
            label = f"concurrent_fact_{index}"
            semantic_in = SemanticIn(label=label, content=f"Content for {label}")
            return create_semantic(db, semantic_in, org_id=org_id, user_id=user_id)

        created = []
        with ThreadPoolExecutor(max_workers=24) as executor:
            futures = [executor.submit(create_one, index) for index in range(48)]
            for future in as_completed(futures):
                created.append(future.result())

        assert len(created) == 48
        assert all(doc.memory_lineage_id == str(doc.id) for doc in created)

    def test_upsert_semantic_preserves_lineage(self, bootstrapped_engine):
        """Test that upsert preserves memory_lineage_id for existing documents."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"

        semantic_in = SemanticIn(
            label="javascript_basics",
            content="JavaScript is a scripting language.",
        )

        # First upsert creates new document
        created = upsert_semantic(db, semantic_in, org_id=org_id, user_id=user_id)
        original_lineage_id = created.memory_lineage_id

        # Second upsert updates existing document
        updated_in = SemanticIn(
            label="javascript_basics",
            content="JavaScript is a high-level scripting language.",
        )
        updated = upsert_semantic(db, updated_in, org_id=org_id, user_id=user_id)

        assert updated.memory_lineage_id == original_lineage_id  # Lineage preserved

    def test_list_semantic(self, bootstrapped_engine):
        """Test listing semantic memory documents."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"

        # Create multiple documents
        labels = ["fact_1", "fact_2", "fact_3"]
        for label in labels:
            semantic_in = SemanticIn(label=label, content=f"Content for {label}")
            create_semantic(db, semantic_in, org_id=org_id, user_id=user_id)

        # List all
        all_docs = list_semantic(db, org_id)
        assert len(all_docs) >= 3

        # Verify all labels are present
        retrieved_labels = {doc.label for doc in all_docs}
        for label in labels:
            assert label in retrieved_labels
