"""
Unit tests for extraction pipeline observability.

Tests verify that extraction pipelines correctly emit metrics via CoreObservability.
We test SemanticPipeline as representative of semantic/episodic/taxonomic
(they share the same pattern), and PreferencesPipeline separately (different metrics).
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from mongomem_core.extraction.config import (
    SemanticExtractionConfig,
)
from mongomem_core.extraction.consolidator import (
    Consolidator,
    RuleBasedStrategy,
)
from mongomem_core.extraction.preferences import (
    PreferencesExtractionConfig,
    PreferencesExtractor,
    PreferencesPipeline,
)
from mongomem_core.extraction.semantic import (
    SemanticExtractor,
    SemanticPipeline,
)
from mongomem_core.extraction.types import (
    ConsolidationDecision,
    ScoredExtraction,
)
from mongomem_core.observability import CoreObservability

from ...conftest import RecordingObservability


@pytest.fixture
def mock_db() -> MagicMock:
    return MagicMock()


@pytest.fixture
def mock_llm() -> MagicMock:
    llm = MagicMock()
    llm.complete_json.return_value = {"memories": []}
    return llm


@pytest.fixture
def mock_embedder() -> MagicMock:
    embedder = MagicMock()
    embedder.model_id = "test-embedder"
    embedder.embed.return_value = [0.1] * 256
    embedder.embed_batch.return_value = [[0.1] * 256]
    return embedder


class TestSemanticPipelineObservability:
    """Tests for SemanticPipeline observability (representative of all extraction pipelines)."""

    def test_accepts_metrics_and_defaults_to_noop(
        self,
        mock_db: MagicMock,
        mock_llm: MagicMock,
        mock_embedder: MagicMock,
        core_metrics: CoreObservability,
    ):
        """SemanticPipeline accepts metrics parameter and defaults to NoOp."""
        extractor = SemanticExtractor(mock_llm)
        config = SemanticExtractionConfig()
        consolidator = Consolidator(
            db=mock_db,
            embedder=mock_embedder,
            strategy=RuleBasedStrategy(),
            search_fn=lambda **kwargs: [],
            config=config,
        )

        # With explicit metrics
        pipeline = SemanticPipeline(
            extractor=extractor,
            config=config,
            consolidator=consolidator,
            db=mock_db,
            embedding_model_id="test-embedder",
            obs=core_metrics,
        )
        assert pipeline._obs is core_metrics

        # Without metrics (defaults to NoOp)
        pipeline_default = SemanticPipeline(
            extractor=extractor,
            config=config,
            consolidator=consolidator,
            db=mock_db,
            embedding_model_id="test-embedder",
        )
        assert isinstance(pipeline_default._obs, CoreObservability)

    def test_emits_extraction_metrics_on_run(
        self,
        mock_db: MagicMock,
        mock_llm: MagicMock,
        mock_embedder: MagicMock,
        recording_obs: RecordingObservability,
        core_metrics: CoreObservability,
    ):
        """SemanticPipeline.run() emits extraction metrics even with no extractions."""
        mock_llm.complete_json.return_value = {"memories": []}

        extractor = SemanticExtractor(mock_llm)
        config = SemanticExtractionConfig()
        consolidator = Consolidator(
            db=mock_db,
            embedder=mock_embedder,
            strategy=RuleBasedStrategy(),
            search_fn=lambda **kwargs: [],
            config=config,
        )

        pipeline = SemanticPipeline(
            extractor=extractor,
            config=config,
            consolidator=consolidator,
            db=mock_db,
            embedding_model_id="test-embedder",
            obs=core_metrics,
        )

        result = pipeline.run(
            messages=[{"role": "user", "content": "Hello"}],
            org_id="org_1",
            user_id="user_1",
            source_id="snapshot_1",
        )

        # Verify extraction metrics were emitted
        assert len(recording_obs.get_timings("mongomem.extraction.latency")) == 1
        assert len(recording_obs.get_histograms("mongomem.extraction.items.extracted")) == 1
        assert result.success is True

    def test_emits_consolidation_stats(
        self,
        mock_db: MagicMock,
        mock_llm: MagicMock,
        recording_obs: RecordingObservability,
        core_metrics: CoreObservability,
    ):
        """SemanticPipeline.run() emits consolidation action metrics."""
        mock_llm.complete_json.return_value = {
            "memories": [
                {"content": "User likes Python", "citations": [0], "confidence_score": 0.9},
            ]
        }

        extractor = SemanticExtractor(mock_llm)
        config = SemanticExtractionConfig(min_combined_score_threshold=0.1)

        # Mock consolidator to return ADD decision
        consolidator = MagicMock(spec=Consolidator)
        consolidator.process.return_value = [
            ConsolidationDecision(
                extraction=ScoredExtraction(
                    content="User likes Python",
                    citations=[0],
                    confidence=0.9,
                    citation_score=0.8,
                    combined_score=0.85,
                    is_valid=True,
                ),
                action="ADD",
                reason="no similar memories",
            ),
        ]

        pipeline = SemanticPipeline(
            extractor=extractor,
            config=config,
            consolidator=consolidator,
            db=mock_db,
            embedding_model_id="test-embedder",
            obs=core_metrics,
        )

        with patch("mongomem_core.extraction.semantic.apply_decisions") as mock_apply:
            mock_apply.return_value = MagicMock(
                added=1,
                updated=0,
                reinforced=0,
                skipped=0,
                created_ids=["id1"],
                updated_new_version_ids=[],
                reinforced_ids=[],
                errors=[],
            )
            pipeline.run(
                messages=[{"role": "user", "content": "I like Python"}],
                org_id="org_1",
                user_id="user_1",
                source_id="snapshot_1",
            )

        # Verify consolidation stats were emitted
        add_increments = [
            inc
            for inc in recording_obs.get_increments("mongomem.extraction.consolidation")
            if inc["tags"].get("action") == "add"
        ]
        assert len(add_increments) == 1
        assert add_increments[0]["value"] == 1


class TestPreferencesPipelineObservability:
    """Tests for PreferencesPipeline observability."""

    def test_emits_preferences_metrics_on_run(
        self,
        mock_db: MagicMock,
        mock_llm: MagicMock,
        recording_obs: RecordingObservability,
        core_metrics: CoreObservability,
    ):
        """PreferencesPipeline.run() emits preferences update metrics."""
        mock_llm.complete_json.return_value = {"preferences": {}, "confidence": 0.0}

        pipeline = PreferencesPipeline(
            extractor=PreferencesExtractor(mock_llm),
            config=PreferencesExtractionConfig(),
            db=mock_db,
            obs=core_metrics,
        )

        result = pipeline.run(
            messages=[{"role": "user", "content": "Hello"}],
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
            source_id="snapshot_1",
        )

        assert len(recording_obs.get_timings("mongomem.extraction.preferences.latency")) == 1
        assert (
            len(recording_obs.get_histograms("mongomem.extraction.preferences.fields_updated")) == 1
        )
        assert result.success is True


class TestEmitExtractionResult:
    """Tests for CoreObservability.emit_extraction_result() helper method."""

    def test_emits_extraction_and_consolidation_metrics(
        self, recording_obs: RecordingObservability, core_metrics: CoreObservability
    ):
        """emit_extraction_result() emits all metrics in one call."""
        core_metrics.emit_extraction_result(
            extraction_type="semantic",
            extracted_count=5,
            duration_ms=100.0,
            add_count=3,
            update_count=1,
            reinforce_count=1,
            duplicate_count=0,
        )

        # Verify extraction metrics
        assert len(recording_obs.get_timings("mongomem.extraction.latency")) == 1
        assert recording_obs.get_histograms("mongomem.extraction.items.extracted")[0]["value"] == 5

        # Verify consolidation metrics (3 non-zero counts emitted)
        consolidation_metrics = recording_obs.get_increments("mongomem.extraction.consolidation")
        assert len(consolidation_metrics) == 3

    def test_skips_zero_consolidation_counts(
        self, recording_obs: RecordingObservability, core_metrics: CoreObservability
    ):
        """emit_extraction_result() doesn't emit consolidation metrics for zero counts."""
        core_metrics.emit_extraction_result(
            extraction_type="episodic",
            extracted_count=0,
            duration_ms=50.0,
        )

        # Extraction metrics emitted, consolidation metrics not emitted
        assert len(recording_obs.get_timings("mongomem.extraction.latency")) == 1
        assert len(recording_obs.get_increments("mongomem.extraction.consolidation")) == 0
