"""Tests for IS generation convenience layer."""

from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import pytest
from mongomem_core import (
    ISGenerationConfig,
    MemoryEngine,
    MemoryMode,
    ModeError,
)


class TestGenerateIsFromTurn:
    """Tests for generate_is_from_turn()."""

    @patch("mongomem_core.engine.base.get_database")
    def test_requires_iwm_or_hybrid_mode(self, mock_get_db):
        """generate_is_from_turn raises ModeError in TRADITIONAL mode."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        engine = MemoryEngine(mode=MemoryMode.TRADITIONAL)

        with pytest.raises(ModeError) as exc_info:
            engine.generate_is_from_turn(
                session_id="sess_123",
                org_id="org_1",
                user_id="user_1",
                user_message="Hello",
            )

        assert exc_info.value.method == "generate_is_from_turn"
        assert exc_info.value.current_mode == MemoryMode.TRADITIONAL

    @patch("mongomem_core.engine.base.get_database")
    def test_requires_llm(self, mock_get_db):
        """generate_is_from_turn raises ValueError if no LLM available."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        engine = MemoryEngine(mode=MemoryMode.IWM)  # No llm or is_llm

        with pytest.raises(ValueError) as exc_info:
            engine.generate_is_from_turn(
                session_id="sess_123",
                org_id="org_1",
                user_id="user_1",
                user_message="Hello",
            )

        assert "is_llm or llm" in str(exc_info.value)

    @patch("mongomem_core.engine.is_generation.get_internal_state")
    @patch("mongomem_core.engine.base.get_database")
    def test_generates_is_and_stores(self, mock_get_db, mock_get_is):
        """generate_is_from_turn generates IS content and stores it."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db
        mock_get_is.return_value = None  # No existing IS

        # Mock LLM
        mock_llm = MagicMock()
        mock_llm.generate.return_value = (
            "## User Profile\nSoftware engineer\n## Current Task\nDebugging"
        )
        mock_llm.model_id = "gpt-4"

        engine = MemoryEngine(mode=MemoryMode.IWM, llm=mock_llm)

        # Mock update_internal_state
        with patch.object(engine, "update_internal_state") as mock_update:
            mock_update.return_value = MagicMock(
                version=1,
                token_count=50,
                content_hash="abc123",
            )
            with patch.object(engine, "_update_coalesce_timestamp"):
                result = engine.generate_is_from_turn(
                    session_id="sess_123",
                    org_id="org_1",
                    user_id="user_1",
                    user_message="How do I debug?",
                    assistant_response="Use breakpoints...",
                )

        assert result.updated is True
        assert result.version == 1
        assert result.model_id == "gpt-4"
        mock_llm.generate.assert_called_once()

    @patch("mongomem_core.engine.is_generation.get_internal_state")
    @patch("mongomem_core.engine.base.get_database")
    def test_fallback_to_llm_when_is_llm_missing(self, mock_get_db, mock_get_is):
        """Falls back to llm when is_llm is not provided."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db
        mock_get_is.return_value = None

        mock_llm = MagicMock()
        mock_llm.generate.return_value = "Updated state"
        mock_llm.model_id = "gpt-4"

        engine = MemoryEngine(mode=MemoryMode.IWM, llm=mock_llm)  # No is_llm

        with patch.object(engine, "update_internal_state") as mock_update:
            mock_update.return_value = MagicMock(version=1, token_count=10, content_hash="abc")
            with patch.object(engine, "_update_coalesce_timestamp"):
                result = engine.generate_is_from_turn(
                    session_id="sess_123",
                    org_id="org_1",
                    user_id="user_1",
                    user_message="Hello",
                )

        assert result.updated is True
        mock_llm.generate.assert_called_once()

    @patch("mongomem_core.engine.is_generation.get_internal_state")
    @patch("mongomem_core.engine.base.get_database")
    def test_uses_is_llm_when_provided(self, mock_get_db, mock_get_is):
        """Uses is_llm instead of llm when both provided."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db
        mock_get_is.return_value = None

        mock_main_llm = MagicMock()
        mock_main_llm.model_id = "gpt-4"

        mock_is_llm = MagicMock()
        mock_is_llm.generate.return_value = "IS content"
        mock_is_llm.model_id = "gpt-3.5-turbo"

        engine = MemoryEngine(mode=MemoryMode.IWM, llm=mock_main_llm, is_llm=mock_is_llm)

        with patch.object(engine, "update_internal_state") as mock_update:
            mock_update.return_value = MagicMock(version=1, token_count=10, content_hash="abc")
            with patch.object(engine, "_update_coalesce_timestamp"):
                result = engine.generate_is_from_turn(
                    session_id="sess_123",
                    org_id="org_1",
                    user_id="user_1",
                    user_message="Hello",
                )

        # is_llm should be called, not main llm
        mock_is_llm.generate.assert_called_once()
        mock_main_llm.generate.assert_not_called()
        assert result.model_id == "gpt-3.5-turbo"

    @patch("mongomem_core.engine.is_generation.get_internal_state")
    @patch("mongomem_core.engine.base.get_database")
    def test_provenance_hashes_set(self, mock_get_db, mock_get_is):
        """Provenance hashes are computed and stored."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db
        mock_get_is.return_value = None

        mock_llm = MagicMock()
        mock_llm.generate.return_value = "State"
        mock_llm.model_id = "gpt-4"

        engine = MemoryEngine(mode=MemoryMode.IWM, llm=mock_llm)

        with patch.object(engine, "update_internal_state") as mock_update:
            mock_update.return_value = MagicMock(version=1, token_count=10, content_hash="abc")
            with patch.object(engine, "_update_coalesce_timestamp"):
                result = engine.generate_is_from_turn(
                    session_id="sess_123",
                    org_id="org_1",
                    user_id="user_1",
                    user_message="Hello",
                    assistant_response="Hi there",
                    tool_observations=["Observation 1"],
                )

        # Check metadata was passed with derived_from
        call_kwargs = mock_update.call_args.kwargs
        assert "metadata" in call_kwargs
        assert "derived_from" in call_kwargs["metadata"]
        derived = call_kwargs["metadata"]["derived_from"]
        assert "user_msg_hash" in derived
        assert "assistant_msg_hash" in derived
        assert "tool_obs_hashes" in derived

        # events_hash should be in result
        assert result.events_hash is not None


class TestCoalescing:
    """Tests for coalesce policy."""

    @patch("mongomem_core.engine.base.get_database")
    def test_coalesce_skips_within_window(self, mock_get_db):
        """Coalesce policy skips updates within window."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        mock_llm = MagicMock()
        mock_llm.model_id = "gpt-4"

        config = ISGenerationConfig(
            update_policy="coalesce",
            coalesce_window_ms=5000,
        )
        engine = MemoryEngine(mode=MemoryMode.IWM, llm=mock_llm, is_config=config)

        # Mock last generation time to be recent (within window)
        recent_time = datetime.now(timezone.utc) - timedelta(milliseconds=1000)
        with patch.object(engine, "_get_last_is_generation_time", return_value=recent_time):
            result = engine.generate_is_from_turn(
                session_id="sess_123",
                org_id="org_1",
                user_id="user_1",
                user_message="Hello",
            )

        assert result.updated is False
        assert result.coalesced is True
        assert result.skipped_reason == "within_coalesce_window"
        assert result.next_update_at is not None

    @patch("mongomem_core.engine.is_generation.get_internal_state")
    @patch("mongomem_core.engine.base.get_database")
    def test_force_bypasses_policy(self, mock_get_db, mock_get_is):
        """force=True bypasses coalesce policy."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db
        mock_get_is.return_value = None

        mock_llm = MagicMock()
        mock_llm.generate.return_value = "State"
        mock_llm.model_id = "gpt-4"

        config = ISGenerationConfig(
            update_policy="coalesce",
            coalesce_window_ms=5000,
        )
        engine = MemoryEngine(mode=MemoryMode.IWM, llm=mock_llm, is_config=config)

        # Even with recent generation, force should bypass
        recent_time = datetime.now(timezone.utc) - timedelta(milliseconds=1000)
        with patch.object(engine, "_get_last_is_generation_time", return_value=recent_time):
            with patch.object(engine, "update_internal_state") as mock_update:
                mock_update.return_value = MagicMock(version=1, token_count=10, content_hash="abc")
                with patch.object(engine, "_update_coalesce_timestamp"):
                    result = engine.generate_is_from_turn(
                        session_id="sess_123",
                        org_id="org_1",
                        user_id="user_1",
                        user_message="Hello",
                        force=True,  # Bypass policy
                    )

        assert result.updated is True
        assert result.coalesced is False


class TestMilestonePolicy:
    """Tests for milestone policy."""

    @patch("mongomem_core.engine.base.get_database")
    def test_milestone_skips_without_trigger(self, mock_get_db):
        """Milestone policy skips when no milestone provided."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        mock_llm = MagicMock()
        mock_llm.model_id = "gpt-4"

        config = ISGenerationConfig(update_policy="milestone")
        engine = MemoryEngine(mode=MemoryMode.IWM, llm=mock_llm, is_config=config)

        result = engine.generate_is_from_turn(
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            user_message="Hello",
            # No milestone provided
        )

        assert result.updated is False
        assert result.skipped_reason == "no_milestone_provided"

    @patch("mongomem_core.engine.is_generation.get_internal_state")
    @patch("mongomem_core.engine.base.get_database")
    def test_milestone_updates_with_valid_trigger(self, mock_get_db, mock_get_is):
        """Milestone policy updates when valid milestone provided."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db
        mock_get_is.return_value = None

        mock_llm = MagicMock()
        mock_llm.generate.return_value = "State"
        mock_llm.model_id = "gpt-4"

        config = ISGenerationConfig(
            update_policy="milestone",
            milestone_triggers=["task_complete", "error_resolved"],
        )
        engine = MemoryEngine(mode=MemoryMode.IWM, llm=mock_llm, is_config=config)

        with patch.object(engine, "update_internal_state") as mock_update:
            mock_update.return_value = MagicMock(version=1, token_count=10, content_hash="abc")
            with patch.object(engine, "_update_coalesce_timestamp"):
                result = engine.generate_is_from_turn(
                    session_id="sess_123",
                    org_id="org_1",
                    user_id="user_1",
                    user_message="Done!",
                    milestone="task_complete",  # Valid trigger
                )

        assert result.updated is True


class TestNoopDetection:
    """Tests for noop detection (skip if unchanged)."""

    @patch("mongomem_core.engine.is_generation.get_internal_state")
    @patch("mongomem_core.engine.base.get_database")
    def test_noop_does_not_update_when_unchanged(self, mock_get_db, mock_get_is):
        """Skips update when content hash is unchanged."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        # Existing IS with specific hash
        existing_is = MagicMock()
        existing_is.content = "Same content"
        existing_is.content_hash = "abc123"  # Will match generated content
        existing_is.version = 5
        mock_get_is.return_value = existing_is

        mock_llm = MagicMock()
        mock_llm.generate.return_value = "Same content"  # Same as existing
        mock_llm.model_id = "gpt-4"

        config = ISGenerationConfig(skip_if_unchanged=True)
        engine = MemoryEngine(mode=MemoryMode.IWM, llm=mock_llm, is_config=config)

        # Mock the hash function to return same hash
        with patch("mongomem_core.engine.is_generation._hash_content", return_value="abc123"):
            result = engine.generate_is_from_turn(
                session_id="sess_123",
                org_id="org_1",
                user_id="user_1",
                user_message="Hello",
            )

        assert result.updated is False
        assert result.was_noop is True
        assert result.skipped_reason == "content_unchanged"
        assert result.version == 5  # Returns existing version


class TestEveryNPolicy:
    """Tests for every_n policy."""

    @patch("mongomem_core.engine.base.get_database")
    def test_every_n_skips_non_divisible_turns(self, mock_get_db):
        """every_n policy skips turns not divisible by N."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        mock_llm = MagicMock()
        mock_llm.model_id = "gpt-4"

        config = ISGenerationConfig(
            update_policy="every_n",
            every_n_turns=3,
        )
        engine = MemoryEngine(mode=MemoryMode.IWM, llm=mock_llm, is_config=config)

        # Turn 1 (not divisible by 3)
        result = engine.generate_is_from_turn(
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            user_message="Hello",
            turn_index=1,
        )

        assert result.updated is False
        assert "every_n" in result.skipped_reason

    @patch("mongomem_core.engine.is_generation.get_internal_state")
    @patch("mongomem_core.engine.base.get_database")
    def test_every_n_updates_divisible_turns(self, mock_get_db, mock_get_is):
        """every_n policy updates turns divisible by N."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db
        mock_get_is.return_value = None

        mock_llm = MagicMock()
        mock_llm.generate.return_value = "State"
        mock_llm.model_id = "gpt-4"

        config = ISGenerationConfig(
            update_policy="every_n",
            every_n_turns=3,
        )
        engine = MemoryEngine(mode=MemoryMode.IWM, llm=mock_llm, is_config=config)

        with patch.object(engine, "update_internal_state") as mock_update:
            mock_update.return_value = MagicMock(version=1, token_count=10, content_hash="abc")
            with patch.object(engine, "_update_coalesce_timestamp"):
                # Turn 3 (divisible by 3)
                result = engine.generate_is_from_turn(
                    session_id="sess_123",
                    org_id="org_1",
                    user_id="user_1",
                    user_message="Hello",
                    turn_index=3,
                )

        assert result.updated is True
