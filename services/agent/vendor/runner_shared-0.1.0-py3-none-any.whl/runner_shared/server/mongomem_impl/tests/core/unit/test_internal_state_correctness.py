"""
Critical correctness tests for Internal State (IS) operations.

These tests verify the key guarantees documented in the implementation:
1. Version determinism: first insert returns version==1
2. Noop behavior: same content → version unchanged
3. Optimistic concurrency: expected_version enforcement
4. Hash canonicalization: consistent across platforms
5. Atomic conditional update: version bumps only on content change
"""

from __future__ import annotations

import pytest
from mongomem_core.memory.internal_state import (
    _compute_content_hash,
    _normalize_content,
    get_internal_state,
    upsert_internal_state,
)
from mongomem_core.models.memory.internal_state import (
    InternalStateIn,
    VersionConflictError,
)


class TestVersionDeterminism:
    """Test that versioning is deterministic and correct."""

    def test_first_insert_returns_version_1(self, test_db):
        """First insert should always return version=1."""
        is_in = InternalStateIn(content="Initial state content")

        result = upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        assert result.version == 1
        assert result.was_insert is True
        assert result.previous_version is None
        assert result.was_noop is False

    def test_second_update_with_different_content_bumps_version(self, test_db):
        """Update with different content should bump version to 2."""
        # First insert
        is_in_1 = InternalStateIn(content="First content")
        result_1 = upsert_internal_state(
            db=test_db,
            is_in=is_in_1,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )
        assert result_1.version == 1

        # Second update with different content
        is_in_2 = InternalStateIn(content="Second content - different!")
        result_2 = upsert_internal_state(
            db=test_db,
            is_in=is_in_2,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        assert result_2.version == 2
        assert result_2.previous_version == 1
        assert result_2.was_noop is False
        assert result_2.was_insert is False


class TestNoopBehavior:
    """Test that same content doesn't bump version (true noop)."""

    def test_same_content_does_not_bump_version(self, test_db):
        """Same content should NOT increment version."""
        content = "This is the exact same content"
        is_in = InternalStateIn(content=content)

        # First insert
        result_1 = upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )
        assert result_1.version == 1

        # Same content again
        result_2 = upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        # Version should stay at 1 (NOT bump to 2)
        assert result_2.version == 1
        assert result_2.was_noop is True
        assert result_2.previous_version == 1

    def test_same_content_with_whitespace_normalization(self, test_db):
        """Content with different whitespace that normalizes to same hash → noop."""
        content_1 = "Line 1\nLine 2"
        content_2 = "Line 1\r\nLine 2"  # CRLF instead of LF

        is_in_1 = InternalStateIn(content=content_1)
        result_1 = upsert_internal_state(
            db=test_db,
            is_in=is_in_1,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        is_in_2 = InternalStateIn(content=content_2)
        result_2 = upsert_internal_state(
            db=test_db,
            is_in=is_in_2,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        # Should be noop due to normalization
        assert result_2.was_noop is True
        assert result_2.version == result_1.version

    def test_noop_updates_metadata_but_not_version(self, test_db):
        """Even on noop, metadata like updated_at should change."""
        content = "Same content"
        is_in_1 = InternalStateIn(content=content, model_id="gpt-4")
        is_in_2 = InternalStateIn(content=content, model_id="gpt-4o")  # Different model

        result_1 = upsert_internal_state(
            db=test_db,
            is_in=is_in_1,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        result_2 = upsert_internal_state(
            db=test_db,
            is_in=is_in_2,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        # Version unchanged but model_id can be updated
        assert result_2.version == result_1.version
        assert result_2.was_noop is True


class TestOptimisticConcurrency:
    """Test expected_version and if_match_hash enforcement."""

    def test_expected_version_match_succeeds(self, test_db):
        """Update with correct expected_version should succeed."""
        is_in_1 = InternalStateIn(content="Initial")
        result_1 = upsert_internal_state(
            db=test_db,
            is_in=is_in_1,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        # Update with correct expected_version
        is_in_2 = InternalStateIn(
            content="Updated content",
            expected_version=result_1.version,
        )
        result_2 = upsert_internal_state(
            db=test_db,
            is_in=is_in_2,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        assert result_2.version == 2
        assert result_2.was_noop is False

    def test_expected_version_mismatch_raises_conflict(self, test_db):
        """Update with wrong expected_version should raise VersionConflictError."""
        is_in_1 = InternalStateIn(content="Initial")
        upsert_internal_state(
            db=test_db,
            is_in=is_in_1,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        # Update with wrong expected_version
        is_in_2 = InternalStateIn(
            content="Updated content",
            expected_version=99,  # Wrong!
        )

        with pytest.raises(VersionConflictError) as exc_info:
            upsert_internal_state(
                db=test_db,
                is_in=is_in_2,
                org_id="org_1",
                user_id="user_1",
                session_id="sess_1",
            )

        assert exc_info.value.expected_version == 99
        assert exc_info.value.actual_version == 1

    def test_if_match_hash_match_succeeds(self, test_db):
        """Update with correct if_match_hash should succeed."""
        is_in_1 = InternalStateIn(content="Initial content")
        result_1 = upsert_internal_state(
            db=test_db,
            is_in=is_in_1,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        # Update with correct hash
        is_in_2 = InternalStateIn(
            content="Updated content",
            if_match_hash=result_1.content_hash,
        )
        result_2 = upsert_internal_state(
            db=test_db,
            is_in=is_in_2,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        assert result_2.version == 2

    def test_if_match_hash_mismatch_raises_conflict(self, test_db):
        """Update with wrong if_match_hash should raise VersionConflictError."""
        is_in_1 = InternalStateIn(content="Initial")
        upsert_internal_state(
            db=test_db,
            is_in=is_in_1,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        is_in_2 = InternalStateIn(
            content="Updated content",
            if_match_hash="wronghash123456",
        )

        with pytest.raises(VersionConflictError) as exc_info:
            upsert_internal_state(
                db=test_db,
                is_in=is_in_2,
                org_id="org_1",
                user_id="user_1",
                session_id="sess_1",
            )

        assert exc_info.value.expected_hash == "wronghash123456"


class TestHashCanonicalization:
    """Test that hash is consistent across different input formats."""

    def test_crlf_normalized_to_lf(self):
        """CRLF and LF produce same hash."""
        content_lf = "Line 1\nLine 2\nLine 3"
        content_crlf = "Line 1\r\nLine 2\r\nLine 3"

        hash_lf = _compute_content_hash(content_lf)
        hash_crlf = _compute_content_hash(content_crlf)

        assert hash_lf == hash_crlf

    def test_cr_normalized_to_lf(self):
        """CR (old Mac) normalized to LF."""
        content_lf = "Line 1\nLine 2"
        content_cr = "Line 1\rLine 2"

        hash_lf = _compute_content_hash(content_lf)
        hash_cr = _compute_content_hash(content_cr)

        assert hash_lf == hash_cr

    def test_trailing_whitespace_stripped_in_strip_mode(self):
        """Trailing whitespace per line doesn't affect hash in STRIP_TRAILING mode."""
        from mongomem_core.memory.internal_state import (
            NormalizeMode,
        )

        content_clean = "Line 1\nLine 2"
        content_trailing = "Line 1   \nLine 2\t"

        # In STRIP_TRAILING mode, trailing whitespace is stripped
        hash_clean = _compute_content_hash(content_clean, NormalizeMode.STRIP_TRAILING)
        hash_trailing = _compute_content_hash(content_trailing, NormalizeMode.STRIP_TRAILING)

        assert hash_clean == hash_trailing

    def test_trailing_whitespace_preserved_in_newlines_only_mode(self):
        """Trailing whitespace IS significant in NEWLINES_ONLY mode (default)."""
        content_clean = "Line 1\nLine 2"
        content_trailing = "Line 1   \nLine 2\t"

        # In NEWLINES_ONLY mode (default), trailing whitespace is significant
        hash_clean = _compute_content_hash(content_clean)  # Default mode
        hash_trailing = _compute_content_hash(content_trailing)

        # These SHOULD be different (trailing ws matters in default mode)
        assert hash_clean != hash_trailing

    def test_leading_whitespace_preserved(self):
        """Leading whitespace (indentation) DOES affect hash."""
        content_no_indent = "Line 1\nLine 2"
        content_indented = "  Line 1\n  Line 2"

        hash_no_indent = _compute_content_hash(content_no_indent)
        hash_indented = _compute_content_hash(content_indented)

        # These should be DIFFERENT
        assert hash_no_indent != hash_indented

    def test_utf8_encoding(self):
        """UTF-8 encoding is consistent."""
        content_unicode = "Hello 世界 🎉"
        hash_1 = _compute_content_hash(content_unicode)
        hash_2 = _compute_content_hash(content_unicode)

        assert hash_1 == hash_2

    def test_normalize_ensures_trailing_newline(self):
        """Normalization ensures single trailing newline."""
        content_no_newline = "Content"
        content_one_newline = "Content\n"
        content_many_newlines = "Content\n\n\n"

        normalized_1 = _normalize_content(content_no_newline)
        normalized_2 = _normalize_content(content_one_newline)
        normalized_3 = _normalize_content(content_many_newlines)

        assert normalized_1 == "Content\n"
        assert normalized_2 == "Content\n"
        # Multiple trailing newlines are preserved (they're meaningful)
        assert normalized_3.endswith("\n")


class TestRedactionTracking:
    """Test redaction tracking fields."""

    def test_redaction_fields_stored(self, test_db):
        """Redaction tracking fields should be stored."""
        is_in = InternalStateIn(
            content="Some [REDACTED] content",
            redaction_applied=True,
            redaction_policy_id="policy_v2",
        )

        upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        # Verify via get
        doc = get_internal_state(test_db, "sess_1", "org_1")
        assert doc is not None
        assert doc.redaction_applied is True
        assert doc.redaction_policy_id == "policy_v2"


class TestTokenizerProvenance:
    """Test tokenizer_id tracking."""

    def test_tokenizer_id_stored(self, test_db):
        """tokenizer_id should be stored for token count provenance."""
        is_in = InternalStateIn(
            content="Some content",
            token_count=100,
            token_count_estimated=False,
            tokenizer_id="cl100k_base",
        )

        upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        doc = get_internal_state(test_db, "sess_1", "org_1")
        assert doc is not None
        assert doc.tokenizer_id == "cl100k_base"
        assert doc.token_count_estimated is False
