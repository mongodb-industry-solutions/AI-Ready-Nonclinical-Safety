"""
Integration tests for procedural memory CRUD operations.

These tests use a real MongoDB database to verify end-to-end behavior
of procedural memory operations.
"""

import pytest
from mongomem_core.exceptions import (
    DocumentNotFoundError,
    DuplicateDocumentError,
)
from mongomem_core.memory.procedural import (
    bulk_create_procedural,
    create_procedural,
    delete_procedural,
    delete_procedural_by_ids,
    get_procedural,
    list_procedural,
    soft_delete_procedural,
    update_procedural,
    update_procedural_embedding,
)
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.procedural import (
    ProceduralIn,
    ProceduralStep,
    ProceduralUpdate,
)


def _make_procedural_in(procedure: str = "test-proc", **overrides) -> ProceduralIn:
    """Helper to build a ProceduralIn with sensible defaults."""
    defaults = {
        "procedure": procedure,
        "description": f"Description for {procedure}",
        "content": f"# {procedure}\n\nFull instructions for {procedure}.",
    }
    defaults.update(overrides)
    return ProceduralIn(**defaults)


class TestProceduralMemoryCRUD:
    """Integration tests for procedural memory CRUD operations."""

    def test_create_and_get_by_id(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"

        proc_in = _make_procedural_in("deploy-app")

        created = create_procedural(db, proc_in, org_id=org_id, user_id=user_id)
        assert created.id is not None
        assert created.procedure == "deploy-app"
        assert created.memory_lineage_id is not None
        assert created.memory_lineage_id == str(created.id)

        retrieved = get_procedural(db, org_id, id=str(created.id))
        assert retrieved is not None
        assert retrieved.procedure == "deploy-app"
        assert retrieved.description == "Description for deploy-app"

    def test_create_and_get_by_procedure_name(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-2"
        user_id = "test-user-1"

        proc_in = _make_procedural_in("run-tests")
        created = create_procedural(db, proc_in, org_id=org_id, user_id=user_id)

        retrieved = get_procedural(db, org_id, procedure="run-tests")
        assert retrieved is not None
        assert retrieved.id == str(created.id)
        assert retrieved.procedure == "run-tests"

    def test_get_nonexistent_returns_none(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        result = get_procedural(db, "no-such-org", procedure="nonexistent")
        assert result is None

    def test_get_requires_exactly_one_identifier(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        with pytest.raises(ValueError, match="Exactly one"):
            get_procedural(db, "org-1")

        with pytest.raises(ValueError, match="Exactly one"):
            get_procedural(db, "org-1", id="some-id", procedure="some-proc")

    def test_create_with_steps_and_resources(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-steps"
        user_id = "test-user-1"

        proc_in = _make_procedural_in(
            "build-project",
            steps=[
                ProceduralStep(
                    step_type="code",
                    content="npm install",
                    description="Install dependencies",
                    language="bash",
                ),
                ProceduralStep(
                    step_type="code",
                    content="npm run build",
                    description="Run build",
                    language="bash",
                ),
            ],
        )

        created = create_procedural(db, proc_in, org_id=org_id, user_id=user_id)
        retrieved = get_procedural(db, org_id, id=str(created.id))

        assert retrieved is not None
        assert len(retrieved.steps) == 2
        assert retrieved.steps[0].step_type == "code"
        assert retrieved.steps[0].language == "bash"

    def test_create_duplicate_fails(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-dup"
        user_id = "test-user-1"

        proc_in = _make_procedural_in("unique-proc")
        create_procedural(db, proc_in, org_id=org_id, user_id=user_id)

        with pytest.raises(DuplicateDocumentError):
            create_procedural(db, proc_in, org_id=org_id, user_id=user_id)

    def test_upsert_creates_new(self, bootstrapped_engine):
        from mongomem_core.memory.procedural import (
            upsert_procedural,
        )

        db = bootstrapped_engine.db
        org_id = "test-org-upsert-new"
        user_id = "test-user-1"

        proc_in = _make_procedural_in("upsert-new")
        result = upsert_procedural(db, proc_in, org_id=org_id, user_id=user_id)

        assert result.id is not None
        assert result.procedure == "upsert-new"
        assert result.memory_lineage_id is not None

    def test_upsert_updates_existing(self, bootstrapped_engine):
        from mongomem_core.memory.procedural import (
            upsert_procedural,
        )

        db = bootstrapped_engine.db
        org_id = "test-org-upsert-upd"
        user_id = "test-user-1"

        proc_in = _make_procedural_in("upsert-upd")
        first = upsert_procedural(db, proc_in, org_id=org_id, user_id=user_id)
        original_lineage = first.memory_lineage_id

        updated_in = _make_procedural_in("upsert-upd", content="Updated content for upsert.")
        second = upsert_procedural(db, updated_in, org_id=org_id, user_id=user_id)

        assert second.memory_lineage_id == original_lineage
        assert second.content == "Updated content for upsert."

    def test_update_procedural(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-update"
        user_id = "test-user-1"

        proc_in = _make_procedural_in("update-target")
        created = create_procedural(db, proc_in, org_id=org_id, user_id=user_id)

        update = ProceduralUpdate(
            description="Updated description",
            tags=["updated", "v2"],
        )
        updated = update_procedural(db, org_id=org_id, update=update, id=str(created.id))

        assert updated is not None
        assert updated.description == "Updated description"
        assert updated.tags == ["updated", "v2"]

    def test_update_by_procedure_name(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-update-name"
        user_id = "test-user-1"

        proc_in = _make_procedural_in("update-by-name")
        create_procedural(db, proc_in, org_id=org_id, user_id=user_id)

        update = ProceduralUpdate(content="Content updated by name")
        updated = update_procedural(db, org_id=org_id, update=update, procedure="update-by-name")

        assert updated is not None
        assert updated.content == "Content updated by name"

    def test_update_nonexistent_raises(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-update-404"

        update = ProceduralUpdate(description="won't work")
        with pytest.raises(DocumentNotFoundError):
            update_procedural(db, org_id=org_id, update=update, procedure="no-such")

    def test_list_procedural(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-list"
        user_id = "test-user-1"

        procs = ["list-proc-a", "list-proc-b", "list-proc-c"]
        for name in procs:
            create_procedural(db, _make_procedural_in(name), org_id=org_id, user_id=user_id)

        all_docs = list_procedural(db, org_id)
        assert len(all_docs) >= 3

    def test_list_with_tag_filter(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-tags"
        user_id = "test-user-1"

        create_procedural(
            db,
            _make_procedural_in("tagged-one", tags=["deploy", "ci"]),
            org_id=org_id,
            user_id=user_id,
        )
        create_procedural(
            db,
            _make_procedural_in("tagged-two", tags=["deploy"]),
            org_id=org_id,
            user_id=user_id,
        )
        create_procedural(
            db,
            _make_procedural_in("untagged"),
            org_id=org_id,
            user_id=user_id,
        )

        deploy_docs = list_procedural(db, org_id, tags=["deploy"])
        assert len(deploy_docs) == 2

        ci_docs = list_procedural(db, org_id, tags=["ci"])
        assert len(ci_docs) == 1
        assert ci_docs[0].procedure == "tagged-one"

    def test_list_with_limit(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-limit"
        user_id = "test-user-1"

        for i in range(5):
            create_procedural(
                db,
                _make_procedural_in(f"limit-proc-{i}"),
                org_id=org_id,
                user_id=user_id,
            )

        limited = list_procedural(db, org_id, limit=2)
        assert len(limited) == 2

    def test_soft_delete_by_id(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-soft-del"
        user_id = "test-user-1"

        proc_in = _make_procedural_in("soft-delete-me")
        created = create_procedural(db, proc_in, org_id=org_id, user_id=user_id)

        result = soft_delete_procedural(db, org_id, id=str(created.id))
        assert result.modified_count == 1

        assert get_procedural(db, org_id, id=str(created.id)) is None

        deleted = get_procedural(db, org_id, id=str(created.id), include_deleted=True)
        assert deleted is not None
        assert deleted.deleted is True
        assert deleted.deleted_at is not None

    def test_soft_delete_by_procedure_name(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-soft-del-name"
        user_id = "test-user-1"

        proc_in = _make_procedural_in("soft-by-name")
        create_procedural(db, proc_in, org_id=org_id, user_id=user_id)

        result = soft_delete_procedural(db, org_id, procedure="soft-by-name")
        assert result.modified_count == 1

        assert get_procedural(db, org_id, procedure="soft-by-name") is None

    def test_hard_delete_by_id(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-hard-del"
        user_id = "test-user-1"

        proc_in = _make_procedural_in("hard-delete-me")
        created = create_procedural(db, proc_in, org_id=org_id, user_id=user_id)

        result = delete_procedural(db, org_id, id=str(created.id))
        assert result.deleted_count == 1

        assert get_procedural(db, org_id, id=str(created.id), include_deleted=True) is None

    def test_hard_delete_by_procedure_name(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-hard-del-name"
        user_id = "test-user-1"

        proc_in = _make_procedural_in("hard-by-name")
        create_procedural(db, proc_in, org_id=org_id, user_id=user_id)

        result = delete_procedural(db, org_id, procedure="hard-by-name")
        assert result.deleted_count == 1

    def test_delete_by_ids(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-del-ids"
        user_id = "test-user-1"

        ids = []
        for i in range(3):
            created = create_procedural(
                db,
                _make_procedural_in(f"del-batch-{i}"),
                org_id=org_id,
                user_id=user_id,
            )
            ids.append(str(created.id))

        result = delete_procedural_by_ids(db, ids[:2], org_id)
        assert result.deleted_count == 2

        assert get_procedural(db, org_id, id=ids[2]) is not None

    def test_bulk_create(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-bulk"
        user_id = "test-user-1"

        items = [
            _make_procedural_in("bulk-a"),
            _make_procedural_in("bulk-b"),
            _make_procedural_in("bulk-c"),
        ]

        created, skipped = bulk_create_procedural(db, items, org_id=org_id, user_id=user_id)
        assert len(created) == 3
        assert len(skipped) == 0
        assert all(doc.procedure.startswith("bulk-") for doc in created)

    def test_bulk_create_skips_duplicates(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-bulk-dup"
        user_id = "test-user-1"

        create_procedural(
            db,
            _make_procedural_in("pre-existing"),
            org_id=org_id,
            user_id=user_id,
        )

        items = [
            _make_procedural_in("pre-existing"),
            _make_procedural_in("brand-new"),
        ]

        created, skipped = bulk_create_procedural(
            db, items, org_id=org_id, user_id=user_id, skip_duplicates=True
        )
        assert len(created) == 1
        assert created[0].procedure == "brand-new"
        assert "pre-existing" in skipped

    def test_update_embedding(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-emb"
        user_id = "test-user-1"

        proc_in = _make_procedural_in("embed-me")
        created = create_procedural(db, proc_in, org_id=org_id, user_id=user_id)
        assert created.has_embedding is False

        embedding = [0.1] * 1024
        result = update_procedural_embedding(
            db,
            str(created.id),
            org_id,
            embedding,
            embedding_model_id="voyage-3-large",
        )
        assert result.modified_count == 1

        retrieved = get_procedural(db, org_id, id=str(created.id))
        assert retrieved is not None
        assert retrieved.has_embedding is True
        assert retrieved.embedding_model_id == "voyage-3-large"

    def test_visibility_filtering(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-vis"
        user_id = "test-user-1"

        create_procedural(
            db,
            _make_procedural_in("private-proc", visibility=ChunkVisibility.PRIVATE),
            org_id=org_id,
            user_id=user_id,
        )
        create_procedural(
            db,
            _make_procedural_in("org-proc", visibility=ChunkVisibility.ORG),
            org_id=org_id,
            user_id=user_id,
        )

        private_docs = list_procedural(db, org_id, visibility=ChunkVisibility.PRIVATE)
        org_docs = list_procedural(db, org_id, visibility=ChunkVisibility.ORG)

        assert len(private_docs) == 1
        assert private_docs[0].procedure == "private-proc"
        assert len(org_docs) == 1
        assert org_docs[0].procedure == "org-proc"

    def test_create_with_embedding(self, bootstrapped_engine):
        db = bootstrapped_engine.db
        org_id = "test-org-emb-create"
        user_id = "test-user-1"

        embedding = [0.5] * 1024
        proc_in = _make_procedural_in("with-embedding")
        created = create_procedural(
            db,
            proc_in,
            org_id=org_id,
            user_id=user_id,
            embedding=embedding,
            embedding_model_id="voyage-3",
        )
        assert created.has_embedding is True
        assert created.embedding_model_id == "voyage-3"
