"""Pytest fixtures for core tests (both unit and integration)."""

import os
import random
import string
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional

# Add mongomem_impl/src to sys.path so mongomem_core resolves to the embedded
# copy rather than any external package.
_src_path = Path(__file__).parent.parent / "src"
if str(_src_path) not in sys.path:
    sys.path.insert(0, str(_src_path))

import pytest  # noqa: E402, I001
from mongomem_core import MemoryEngine  # noqa: E402
from mongomem_core.config import Settings  # noqa: E402
from mongomem_core.observability import CoreObservability  # noqa: E402
from pymongo import MongoClient  # noqa: E402
from pymongo.database import Database  # noqa: E402
from pymongo.errors import OperationFailure  # noqa: E402


# Test MongoDB URI - use local by default, can override with env var
TEST_MONGO_URI = os.environ.get("TEST_MONGO_URI", "mongodb://localhost:27017")


def pytest_configure(config):
    """Register custom pytest markers."""
    config.addinivalue_line(
        "markers",
        "vector_search: mark test as requiring vector search (Atlas or AtlasCLI)",
    )


def is_vector_search_available(db: Database) -> bool:
    """
    Check if vector search is available in the MongoDB deployment.

    Returns True if vector search is available, False otherwise.
    """
    try:
        # Try to list search indexes - this will fail if search is not enabled
        list(db.memory_semantic.list_search_indexes())
        return True
    except OperationFailure as e:
        # Error code 31082 = SearchNotEnabled
        if e.code == 31082 or "SearchNotEnabled" in str(e):
            return False
        # Other errors might indicate search is available but misconfigured
        # In that case, assume it's available and let the test fail naturally
        return True
    except Exception:
        # Any other exception means we can't determine, assume available
        return True


def random_db_name() -> str:
    """Generate a random database name for test isolation."""
    suffix = "".join(random.choices(string.ascii_lowercase, k=8))
    return f"test_mongomem_core_{suffix}"


def _clear_all_collections(db: Database) -> None:
    """Clear all documents from all collections in the database (faster than drop_database)."""
    for collection_name in db.list_collection_names():
        db[collection_name].delete_many({})


# Session-scoped client - one connection for the entire test run
@pytest.fixture(scope="session")
def mongo_client() -> Generator[MongoClient, None, None]:
    """Provide a MongoDB client for testing (session-scoped for efficiency)."""
    client = MongoClient(TEST_MONGO_URI, serverSelectionTimeoutMS=5000)
    yield client
    client.close()


# Session-scoped database - one database for the entire test run
@pytest.fixture(scope="session")
def session_db(mongo_client: MongoClient) -> Generator[Database, None, None]:
    """Provide a test database for the session (dropped at end of session)."""
    db_name = random_db_name()
    db = mongo_client[db_name]
    yield db
    mongo_client.drop_database(db_name)


# Function-scoped database that clears collections between tests (fast)
@pytest.fixture
def test_db(session_db: Database) -> Generator[Database, None, None]:
    """Provide an isolated test database that's cleared between tests."""
    # Clear all collections before test (faster than creating new DB)
    _clear_all_collections(session_db)
    yield session_db
    # Clear after test too for cleanliness
    _clear_all_collections(session_db)


@pytest.fixture
def test_engine(test_db: Database) -> MemoryEngine:
    """Provide a MemoryEngine with test database."""
    settings = Settings(
        mongo_uri=TEST_MONGO_URI,
        db_name=test_db.name,
        embedding_dimension=1024,  # Default for tests
    )
    return MemoryEngine(settings)


@pytest.fixture
def bootstrapped_engine(test_engine: MemoryEngine) -> MemoryEngine:
    """
    Provide a MemoryEngine with bootstrapped database (collections and indexes).

    This fixture does NOT create search indexes by default. Use
    `bootstrapped_engine_with_vector_search` for tests that need vector search.
    """
    test_engine.bootstrap(ensure_search_indexes=False)
    return test_engine


@pytest.fixture
def bootstrapped_engine_with_vector_search(test_engine: MemoryEngine) -> MemoryEngine:
    """
    Provide a MemoryEngine with bootstrapped database including vector search indexes.

    This fixture attempts to create search indexes. If vector search is not available
    (requires Atlas or AtlasCLI), the bootstrap will succeed but search indexes won't
    be created. Tests using this fixture should be marked with @pytest.mark.vector_search
    to be skipped automatically when vector search is unavailable.
    """
    test_engine.bootstrap(ensure_search_indexes=True, wait_for_indexes_ready=True)
    return test_engine


def pytest_collection_modifyitems(config, items):
    """
    Automatically skip vector_search tests if vector search is not available.

    This hook runs during test collection and skips tests marked with
    @pytest.mark.vector_search if vector search is not available.

    To run vector search tests:
    - Set ENABLE_VECTOR_SEARCH_TESTS=true environment variable
    - Or ensure you're connected to MongoDB Atlas or AtlasCLI
    """
    # Check if vector search tests should be enabled
    enable_vector_search = os.getenv("ENABLE_VECTOR_SEARCH_TESTS", "false").lower() == "true"

    # Skip vector search tests in CI unless explicitly enabled
    in_ci = os.getenv("CI", "false").lower() == "true"
    if in_ci and not enable_vector_search:
        for item in items:
            if "vector_search" in item.keywords:
                item.add_marker(
                    pytest.mark.skip(
                        reason="Vector search tests skipped in CI (set ENABLE_VECTOR_SEARCH_TESTS=true to run)"
                    )
                )
        return

    # For local development, check if vector search is available
    # We need to create a test connection to check
    try:
        from pymongo import MongoClient

        test_client = MongoClient(TEST_MONGO_URI, serverSelectionTimeoutMS=1000)
        test_db = test_client.get_database("_test_vector_search_check")
        vector_search_available = is_vector_search_available(test_db)
        test_client.close()
    except Exception:
        # If we can't check, assume vector search is not available
        vector_search_available = False

    # Skip vector search tests if not available (unless explicitly enabled)
    if not vector_search_available and not enable_vector_search:
        for item in items:
            if "vector_search" in item.keywords:
                item.add_marker(
                    pytest.mark.skip(
                        reason="Vector search not available (requires Atlas or AtlasCLI, or set ENABLE_VECTOR_SEARCH_TESTS=true)"
                    )
                )


# -------------------------------------------------------------------------
# Observability Testing Fixtures
# -------------------------------------------------------------------------


class RecordingObservability:
    """
    Observability implementation that records all calls for assertions.

    Use this for testing that components correctly emit metrics, spans, and events.
    All recorded data is stored in lists that can be queried after the test.

    Example:
        def test_something(recording_obs):
            metrics = CoreObservability(backend=recording_obs)
            metrics.write_turn_started()

            assert len(recording_obs.get_increments("mongomem.engine.write_turn.count")) == 1
    """

    def __init__(self) -> None:
        self.increments: List[Dict[str, Any]] = []
        self.gauges: List[Dict[str, Any]] = []
        self.histograms: List[Dict[str, Any]] = []
        self.timings: List[Dict[str, Any]] = []
        self.spans: List[Dict[str, Any]] = []
        self.events: List[Dict[str, Any]] = []

    def increment(
        self, name: str, value: float = 1.0, tags: Optional[Dict[str, str]] = None
    ) -> None:
        self.increments.append({"name": name, "value": value, "tags": tags or {}})

    def gauge(self, name: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        self.gauges.append({"name": name, "value": value, "tags": tags or {}})

    def histogram(self, name: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        self.histograms.append({"name": name, "value": value, "tags": tags or {}})

    def timing(self, name: str, value_ms: float, tags: Optional[Dict[str, str]] = None) -> None:
        self.timings.append({"name": name, "value_ms": value_ms, "tags": tags or {}})

    @contextmanager
    def span(
        self, name: str, *, kind: str = "internal", attributes: Optional[Dict[str, Any]] = None
    ) -> Generator[Dict[str, Any], None, None]:
        span_record = {
            "name": name,
            "kind": kind,
            "attributes": dict(attributes) if attributes else {},
            "completed": False,
        }
        self.spans.append(span_record)
        try:
            yield span_record["attributes"]
        finally:
            span_record["completed"] = True

    def event(
        self, name: str, *, attributes: Optional[Dict[str, Any]] = None, level: str = "info"
    ) -> None:
        self.events.append({"name": name, "attributes": attributes or {}, "level": level})

    # -------------------------------------------------------------------------
    # Query helpers for assertions
    # -------------------------------------------------------------------------

    def get_increments(self, name: str) -> List[Dict[str, Any]]:
        """Get all increment calls matching the given metric name."""
        return [i for i in self.increments if i["name"] == name]

    def get_gauges(self, name: str) -> List[Dict[str, Any]]:
        """Get all gauge calls matching the given metric name."""
        return [g for g in self.gauges if g["name"] == name]

    def get_histograms(self, name: str) -> List[Dict[str, Any]]:
        """Get all histogram calls matching the given metric name."""
        return [h for h in self.histograms if h["name"] == name]

    def get_timings(self, name: str) -> List[Dict[str, Any]]:
        """Get all timing calls matching the given metric name."""
        return [t for t in self.timings if t["name"] == name]

    def get_spans(self, name: str) -> List[Dict[str, Any]]:
        """Get all spans matching the given span name."""
        return [s for s in self.spans if s["name"] == name]

    def get_events(self, name: str) -> List[Dict[str, Any]]:
        """Get all events matching the given event name."""
        return [e for e in self.events if e["name"] == name]

    def clear(self) -> None:
        """Clear all recorded data. Useful for multi-phase tests."""
        self.increments.clear()
        self.gauges.clear()
        self.histograms.clear()
        self.timings.clear()
        self.spans.clear()
        self.events.clear()


@pytest.fixture
def recording_obs() -> RecordingObservability:
    """Provide a fresh RecordingObservability instance for each test."""
    return RecordingObservability()


@pytest.fixture
def core_metrics(recording_obs: RecordingObservability) -> CoreObservability:
    """Provide a CoreObservability instance backed by RecordingObservability."""
    return CoreObservability(backend=recording_obs)
