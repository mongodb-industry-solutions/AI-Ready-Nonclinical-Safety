"""
End-to-end simulation of the OE-driven STM consolidation pipeline.

Three concurrent async tasks run simultaneously to simulate a real system:
  1. STM writer  — inserts messages in small bursts (simulates AER writing turns)
  2. OE scanner  — periodically scans for eligible sessions and enqueues tasks
  3. Task drainer — periodically calls process_batch() (simulates POST /processTasks)

After the simulation:
  - All sessions must have at least one snapshot
  - Semantic and episodic memories must exist per user
  - Tool-call messages with normalisation requirements must not stall the pipeline
  - Tenant isolation holds: user A's memories do not appear under user B
  - One session is intentionally failed (create_snapshot patched to raise) and its
    task retries 3× then lands in status='failed'; all other tasks complete cleanly

Requirements:
  - Local MongoDB at TEST_MONGO_URI (default: mongodb://localhost:27017)
  - No real LLM or Voyage embedder — MockLLM and MockEmbedder are used
"""

from __future__ import annotations

import asyncio
import os
from datetime import datetime, timezone
from typing import Any

import pytest
from bson import ObjectId
from mongomem_core import MemoryEngine
from mongomem_core.config import Settings
from mongomem_core.models.config.snapshot_config import (
    SnapshotConfig,
)
from pymongo import MongoClient

from runner_shared.server.mongomem_impl.src.mongomem_worker.config import WorkerSettings
from runner_shared.server.mongomem_impl.src.mongomem_worker.queue import enqueue_task

from ..conftest import MockEmbedder, MockLLM, random_db_name

TEST_MONGO_URI = os.environ.get("TEST_MONGO_URI", "mongodb://localhost:27017")

# ---------------------------------------------------------------------------
# Simulation parameters
# ---------------------------------------------------------------------------

NUM_USERS = int(os.environ.get("E2E_NUM_USERS", "10"))
SESSIONS_PER_USER = int(os.environ.get("E2E_SESSIONS_PER_USER", "3"))
MESSAGES_PER_SESSION = int(os.environ.get("E2E_MESSAGES_PER_SESSION", "103"))
BURST_SIZE = 5  # docs inserted per writer tick
WRITER_INTERVAL = 0.05  # seconds between writer bursts
SCANNER_INTERVAL = 0.5  # seconds between OE scan ticks
DRAINER_INTERVAL = 0.2  # seconds between /processTasks calls
POST_WRITE_DRAIN_SECONDS = int(os.environ.get("E2E_DRAIN_SECONDS", "120"))
MAX_DRAIN_ITERATIONS = 500
MAX_MESSAGES_THRESHOLD = 20  # snapshot trigger threshold

# Distinct extractable fact per user (used to verify semantic memories)
USER_FACTS = [
    "Alice is a Python developer at MongoDB working on vector search",
    "Bob specialises in Rust systems programming and low-latency databases",
    "Carol is a data scientist who prefers Julia for numerical computing",
    "Dave is a DevOps engineer who automates infrastructure with Terraform",
    "Eve is a machine learning researcher focused on transformer architectures",
    "Frank is a backend engineer building distributed systems in Go",
    "Grace is a product manager specialising in developer tooling products",
    "Henry is a security engineer focused on zero-trust network architecture",
    "Iris is a mobile developer building cross-platform apps with Flutter",
    "Jack is a database architect designing multi-region MongoDB deployments",
]

# ---------------------------------------------------------------------------
# Message corpus
#
# 100 messages per session built here in one block for readability.
# The corpus mixes user, assistant (text), assistant (tool_calls), and tool
# (result) turns. Several tool-call entries intentionally omit the 'id' or
# use the flat OE format to exercise the normalisation path.
# ---------------------------------------------------------------------------


def _build_corpus(user_fact: str) -> list[dict[str, Any]]:
    """
    Return a list of 100 STM-shaped message dicts for one (user, session).

    The corpus follows realistic multi-turn AER patterns:
      - user asks questions referencing user_fact
      - assistant replies with text or tool calls
      - tool results follow assistant tool-call turns
      - occasional system messages

    Several tool-call entries are in the flat OE format (name/arguments at
    top level) to exercise _normalize_tool_calls. One entry has a missing
    'name' to verify it is DLQ'd without stalling promotion of valid messages.
    """
    msgs: list[dict[str, Any]] = []

    def _user(content: str) -> dict[str, Any]:
        return {"role": "user", "content": content}

    def _assistant_text(content: str) -> dict[str, Any]:
        return {"role": "assistant", "content": content}

    def _assistant_tool(tool_id: str, name: str, args: dict) -> dict[str, Any]:
        """OpenAI-format tool call (already normalized)."""
        return {
            "role": "assistant",
            "content": None,
            "tool_calls": [
                {
                    "id": tool_id,
                    "type": "function",
                    "function": {"name": name, "arguments": args},
                }
            ],
        }

    def _assistant_tool_flat(tool_id: str, name: str, args: dict) -> dict[str, Any]:
        """Flat OE format tool call — exercises normalization path."""
        return {
            "role": "assistant",
            "content": None,
            "tool_calls": [{"id": tool_id, "name": name, "arguments": args}],
        }

    def _assistant_tool_missing_name(tool_id: str, args: dict) -> dict[str, Any]:
        """Tool call with missing name — should be DLQ'd, not stall promotion."""
        return {
            "role": "assistant",
            "content": None,
            "tool_calls": [{"id": tool_id, "arguments": args}],
        }

    def _tool_result(tool_call_id: str, content: str) -> dict[str, Any]:
        return {"role": "tool", "tool_call_id": tool_call_id, "name": "lookup", "content": content}

    # Turn group 1: introduction (user_fact embedded)
    msgs += [
        _user(f"Hi, I need help with my work. {user_fact}."),
        _assistant_text("Sure! I can help. What do you need?"),
        _user("Can you look up my profile?"),
        _assistant_tool("call_001", "lookup_profile", {"query": user_fact[:30]}),
        _tool_result("call_001", f'{{"profile": "{user_fact}", "status": "active"}}'),
        _assistant_text(f"I found your profile: {user_fact}."),
    ]

    # Turn group 2: flat format tool calls (normalization path)
    msgs += [
        _user("What tools are available?"),
        _assistant_tool_flat("call_002", "list_tools", {"filter": "all"}),
        _tool_result("call_002", '{"tools": ["lookup", "search", "summarize"]}'),
        _assistant_text("Available tools: lookup, search, summarize."),
        _user("Search for recent documents about my topic."),
        _assistant_tool_flat("call_003", "search_docs", {"query": user_fact[:20], "limit": 5}),
        _tool_result("call_003", '{"results": ["doc1", "doc2", "doc3"]}'),
        _assistant_text("Found 3 relevant documents."),
    ]

    # Turn group 3: DLQ candidate — missing tool name (1 doc to be DLQ'd)
    msgs += [
        _user("Run a special lookup."),
        _assistant_tool_missing_name("call_004", {"target": "special"}),
        _tool_result("call_004", '{"error": "unknown tool"}'),
        _assistant_text("That operation failed."),
    ]

    # Turn group 4: mixed conversation with more flat-format tool calls
    for i in range(5, 15):
        msgs += [
            _user(f"Follow-up question {i}: tell me more about {user_fact[:15]}."),
            _assistant_tool_flat(
                f"call_{i:03d}",
                "summarize",
                {"text": f"topic {i}", "max_tokens": 100},
            ),
            _tool_result(f"call_{i:03d}", f'{{"summary": "Summary of topic {i}"}}'),
            _assistant_text(f"Here is a summary for topic {i}."),
        ]

    # Turn group 5: pure text conversation (no tool calls)
    for i in range(20, 35):
        msgs += [
            _user(f"Tell me about concept {i} related to {user_fact[:10]}."),
            _assistant_text(
                f"Concept {i} is important because it relates to {user_fact}. "
                f"Here are the key points: efficiency, reliability, scalability."
            ),
        ]

    # Trim or pad to exactly MESSAGES_PER_SESSION
    while len(msgs) < MESSAGES_PER_SESSION:
        idx = len(msgs)
        msgs.append(_user(f"Additional context message {idx}: {user_fact[:20]}."))
        if len(msgs) < MESSAGES_PER_SESSION:
            msgs.append(_assistant_text(f"Understood. Noted message {idx}."))

    return msgs[:MESSAGES_PER_SESSION]


# Build all corpora upfront — one per user (shared across that user's sessions).
# USER_FACTS cycles if NUM_USERS exceeds the list length.
CORPORA = [_build_corpus(USER_FACTS[u % len(USER_FACTS)]) for u in range(NUM_USERS)]


# ---------------------------------------------------------------------------
# Simulation coroutines
# ---------------------------------------------------------------------------


async def _stm_writer(
    db,
    session_specs: list[dict],
) -> None:
    """
    Inserts MESSAGES_PER_SESSION docs per session in BURST_SIZE bursts every
    WRITER_INTERVAL seconds. Returns when all messages have been written.
    """
    cursors = {spec["session_id"]: 0 for spec in session_specs}

    while True:
        all_done = True
        for spec in session_specs:
            sid = spec["session_id"]
            corpus = spec["corpus"]
            pos = cursors[sid]
            if pos >= len(corpus):
                continue
            all_done = False
            batch = corpus[pos : pos + BURST_SIZE]
            now = datetime.now(timezone.utc)
            docs = []
            for i, msg in enumerate(batch):
                doc: dict[str, Any] = {
                    "_id": ObjectId(),
                    "session_id": sid,
                    "org_id": spec["org_id"],
                    "user_id": spec["user_id"],
                    "promoted": False,
                    "turn_seq": pos + i,
                    "timestamp": now,
                    "visibility": "private",
                }
                doc.update(msg)
                docs.append(doc)
            await asyncio.to_thread(db.memory_short_term.insert_many, docs)
            cursors[sid] = pos + len(batch)

        if all_done:
            break
        await asyncio.sleep(WRITER_INTERVAL)


async def _oe_scanner(
    db,
    worker_settings: WorkerSettings,
    max_messages: int,
    org_id: str,
    stop_event: asyncio.Event,
) -> None:
    """
    Periodically scans memory_short_term for sessions eligible for promotion
    (unpromoted doc count >= max_messages) and enqueues check_promotion tasks
    with idempotency keys — mirrors the real OE ConsolidationScanner.
    """
    while not stop_event.is_set():
        await asyncio.sleep(SCANNER_INTERVAL)

        pipeline = [
            {"$match": {"org_id": org_id, "promoted": {"$ne": True}}},
            {
                "$group": {
                    "_id": {
                        "session_id": "$session_id",
                        "user_id": "$user_id",
                    },
                    "count": {"$sum": 1},
                    "max_turn_seq": {"$max": "$turn_seq"},
                }
            },
            {"$match": {"count": {"$gte": max_messages}}},
        ]

        rows = await asyncio.to_thread(lambda: list(db.memory_short_term.aggregate(pipeline)))

        for row in rows:
            sid = row["_id"]["session_id"]
            uid = row["_id"]["user_id"]
            max_seq = row["max_turn_seq"]
            ikey = f"check_promotion:{org_id}:{sid}:{uid}:{max_seq}"

            await asyncio.to_thread(
                enqueue_task,
                "snapshot",
                {
                    "snapshot_task_type": "check_promotion",
                    "session_id": sid,
                    "org_id": org_id,
                    "user_id": uid,
                    "reason": "message_count",
                },
                idempotency_key=ikey,
                settings=worker_settings,
            )


async def _task_drainer(
    worker,
    stop_event: asyncio.Event,
) -> None:
    """
    Periodically drains the task queue by calling process_batch() in a loop
    until empty — mirrors POST /api/v1/worker/processTasks.
    """
    while not stop_event.is_set():
        await asyncio.sleep(DRAINER_INTERVAL)
        for _ in range(MAX_DRAIN_ITERATIONS):
            processed = await worker.process_batch()
            if processed == 0:
                break


# ---------------------------------------------------------------------------
# Test
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestConsolidationPipelineE2E:
    """
    Long-running end-to-end simulation of the STM→Snapshot→Semantic/Episodic
    consolidation pipeline with concurrent writer, scanner, and drainer tasks.
    """

    def setup_method(self):
        self.db_name = random_db_name()
        self.client = MongoClient(TEST_MONGO_URI)
        self.db = self.client[self.db_name]

    def teardown_method(self):
        self.client.drop_database(self.db_name)
        self.client.close()

    async def test_full_consolidation_pipeline(self):
        org_id = "e2e-test-org"

        # Build session specs — NUM_USERS × SESSIONS_PER_USER
        session_specs = []
        for u in range(NUM_USERS):
            for s in range(SESSIONS_PER_USER):
                session_specs.append(
                    {
                        "session_id": f"e2e-user{u}-sess{s}",
                        "user_id": f"e2e-user{u}",
                        "org_id": org_id,
                        "corpus": CORPORA[u],
                    }
                )

        # Configure LLM mock — returns extractable facts keyed to each user
        embedder = MockEmbedder()
        llm = MockLLM()
        for u in range(NUM_USERS):
            llm.set_json_response(
                USER_FACTS[u % len(USER_FACTS)][:20],
                {
                    "memories": [
                        {
                            "content": USER_FACTS[u % len(USER_FACTS)],
                            "citations": [0],
                            "confidence_score": 0.95,
                        }
                    ],
                    "events": [
                        {
                            "title": f"Agent interaction for user{u}",
                            "event": f"User discussed: {USER_FACTS[u % len(USER_FACTS)][:50]}",
                            "timestamp": None,
                            "participants": [f"e2e-user{u}"],
                            "significance": "medium",
                            "confidence_score": 0.85,
                        }
                    ],
                },
            )
        # For prompts not matching any user fact, return empty extraction.
        # Explicitly set _default_json to a valid extraction shape so handlers
        # don't see unexpected keys. Do NOT use set_json_response("", ...) —
        # empty string always matches and would shadow the user-specific keys.
        llm._default_json = {"memories": [], "events": []}

        # Bootstrap engine and worker
        settings_obj = Settings(
            mongo_uri=TEST_MONGO_URI,
            db_name=self.db_name,
            embedding_dimension=embedder.dimension,
        )
        engine = MemoryEngine(settings_obj, embedder=embedder, llm=llm)
        engine.bootstrap(ensure_search_indexes=False)

        from runner_shared.server.mongomem_impl.src.mongomem_worker.worker import MongoMemWorker

        # Set env var for worker construction, restore on exit to avoid leaking
        # into other tests running in the same process.
        _cs_key = "MONGOMEM_WORKER_ENABLE_CHANGE_STREAMS"
        _cs_prev = os.environ.get(_cs_key)
        os.environ[_cs_key] = "false"
        try:
            worker = MongoMemWorker(
                engine=engine,
                scaling_mode="distributed",
                auto_extract_on_snapshot=True,
                snapshot_config=SnapshotConfig(
                    strategy="auto",
                    embedding_strategy="generate",
                    max_messages=MAX_MESSAGES_THRESHOLD,
                    delete_promoted=False,
                ),
                extraction_config={
                    "semantic": {"enabled": True},
                    "episodic": {"enabled": True},
                },
            )
            worker.initialize()
        finally:
            if _cs_prev is None:
                os.environ.pop(_cs_key, None)
            else:
                os.environ[_cs_key] = _cs_prev

        worker_settings = WorkerSettings(
            mongo_uri=TEST_MONGO_URI,
            db_name=self.db_name,
        )

        # ---------------------------------------------------------------
        # Run three concurrent simulation tasks
        # ---------------------------------------------------------------
        # stop_event is only set after the post-write drain window expires,
        # so scanner and drainer keep running after writing finishes.
        stop_event = asyncio.Event()

        writer_task = asyncio.create_task(_stm_writer(self.db, session_specs))
        scanner_task = asyncio.create_task(
            _oe_scanner(self.db, worker_settings, MAX_MESSAGES_THRESHOLD, org_id, stop_event)
        )
        drainer_task = asyncio.create_task(_task_drainer(worker, stop_event))

        # Wait for all messages to be written
        await writer_task

        # Keep scanner and drainer running until the task queue goes quiet.
        # Poll every 0.5s; stop when no queued/running tasks remain or the
        # hard deadline is reached.
        import time as _time

        deadline = _time.monotonic() + POST_WRITE_DRAIN_SECONDS
        while _time.monotonic() < deadline:
            await asyncio.sleep(0.5)
            pending = await asyncio.to_thread(
                lambda: self.db.tasks.count_documents({"status": {"$in": ["queued", "running"]}})
            )
            if pending == 0:
                # Give one final drain cycle to pick up any tasks just enqueued
                await asyncio.sleep(DRAINER_INTERVAL + SCANNER_INTERVAL + 0.2)
                pending = await asyncio.to_thread(
                    lambda: self.db.tasks.count_documents(
                        {"status": {"$in": ["queued", "running"]}}
                    )
                )
                if pending == 0:
                    break

        stop_event.set()
        await asyncio.gather(scanner_task, drainer_task, return_exceptions=True)

        # Final drain to catch any stragglers
        for _ in range(MAX_DRAIN_ITERATIONS):
            processed = await worker.process_batch()
            if processed == 0:
                break

        # ---------------------------------------------------------------
        # ---------------------------------------------------------------
        # Assertions
        # ---------------------------------------------------------------

        total_sessions = NUM_USERS * SESSIONS_PER_USER

        # 1. All sessions have at least one snapshot
        snapshot_session_ids = {
            doc["session_id"]
            for doc in self.db.memory_snapshot.find({"org_id": org_id}, {"session_id": 1})
        }
        expected_session_ids = {spec["session_id"] for spec in session_specs}
        missing = expected_session_ids - snapshot_session_ids
        assert not missing, f"{len(missing)}/{total_sessions} sessions have no snapshot: {missing}"

        # 2. No failed tasks
        failed = self.db.tasks.count_documents({"status": "failed"})
        assert failed == 0, f"Expected 0 failed tasks, got {failed}"

        # 3. At least one semantic memory per user with the correct fact
        for u in range(NUM_USERS):
            uid = f"e2e-user{u}"
            fact_prefix = USER_FACTS[u % len(USER_FACTS)][:20]
            count = self.db.memory_semantic.count_documents(
                {
                    "org_id": org_id,
                    "user_id": uid,
                    "content": {"$regex": fact_prefix[:15], "$options": "i"},
                }
            )
            assert count >= 1, (
                f"Expected at least 1 semantic memory for user{u} containing "
                f"'{fact_prefix[:15]}', got {count}"
            )

        # 4. At least one episodic memory per user.
        #    The extraction payload does not carry the session_id string — the handler
        #    falls back to using the snapshot _id as session_id, so we can only
        #    assert per-user rather than per-session here.
        checked_users: set = set()
        for spec in session_specs:
            uid = spec["user_id"]
            if uid in checked_users:
                continue
            checked_users.add(uid)
            count = self.db.memory_episodic.count_documents(
                {
                    "org_id": org_id,
                    "user_id": uid,
                }
            )
            assert count >= 1, f"Expected at least 1 episodic memory for user {uid}, got {count}"

        # 5. Tenant isolation — each user's snapshots only produced memories tagged
        #    with that user's user_id.  The _id-intersection approach is wrong because
        #    both queries already filter by user_id, so the intersection is always empty.
        #    Instead: for every user, collect the _id strings of their snapshots, then
        #    assert that no semantic memory whose source points at one of those snapshots
        #    carries a different user_id.
        for u in range(NUM_USERS):
            uid = f"e2e-user{u}"
            snap_ids = [
                str(doc["_id"])
                for doc in self.db.memory_snapshot.find(
                    {"org_id": org_id, "user_id": uid}, {"_id": 1}
                )
            ]
            if not snap_ids:
                continue
            wrong = self.db.memory_semantic.count_documents(
                {
                    "org_id": org_id,
                    "source": {"$in": snap_ids},
                    "user_id": {"$ne": uid},
                }
            )
            assert wrong == 0, (
                f"Tenant isolation violated: {wrong} semantic memories sourced from "
                f"{uid}'s snapshots have a different user_id"
            )

        # 6. DLQ'd docs (promotion_error set) don't block pipeline —
        #    at least one snapshot must exist even in sessions containing
        #    the malformed tool-call doc
        dlqd_count = self.db.memory_short_term.count_documents(
            {
                "org_id": org_id,
                "promotion_error": {"$exists": True},
            }
        )
        # DLQ'd docs exist (we seeded one per session) but pipeline completed
        assert dlqd_count > 0, "Expected some DLQ'd docs from malformed tool calls"
        assert len(snapshot_session_ids) == total_sessions, (
            "DLQ'd docs stalled the pipeline — not all sessions have snapshots"
        )

        # ---------------------------------------------------------------
        # Failure scenario: extra session with broken embedding + LLM
        #
        # A separate worker is created with FailingEmbedder (always raises
        # ConnectionError, classified as transient) and a failing LLM.
        # The check_promotion task must be retried 3 times and then end in
        # status='failed' — verifying the retry/backoff path.
        # ---------------------------------------------------------------

        failing_session_id = "e2e-failing-session"
        failing_user_id = "e2e-failing-user"

        # Seed enough docs to exceed the promotion threshold
        failing_docs = []
        now = datetime.now(timezone.utc)
        for i in range(MAX_MESSAGES_THRESHOLD + 1):
            failing_docs.append(
                {
                    "_id": ObjectId(),
                    "session_id": failing_session_id,
                    "org_id": org_id,
                    "user_id": failing_user_id,
                    "role": "user" if i % 2 == 0 else "assistant",
                    "content": f"Failing session message {i}",
                    "visibility": "private",
                    "promoted": False,
                    "turn_seq": i,
                    "timestamp": now,
                }
            )
        await asyncio.to_thread(self.db.memory_short_term.insert_many, failing_docs)

        # Worker using the real MongoDB URI but with create_snapshot patched to
        # always raise ConnectionError (transient). This propagates uncaught out
        # of promote_stm_to_snapshot → task handler → retried 3 times → failed.
        # Embedding/LLM errors are swallowed by the pipeline (by design), so we
        # inject failure at the snapshot write layer instead.
        from unittest.mock import patch

        failing_settings_obj = Settings(
            mongo_uri=TEST_MONGO_URI,
            db_name=self.db_name,
            embedding_dimension=embedder.dimension,
        )
        failing_engine = MemoryEngine(
            failing_settings_obj,
            embedder=MockEmbedder(),
            llm=MockLLM(),
        )
        failing_engine.bootstrap(ensure_search_indexes=False)

        from runner_shared.server.mongomem_impl.src.mongomem_worker.worker import MongoMemWorker

        # Set env var for failing worker construction — same guard as above to
        # prevent leaking the ambient change-streams setting into initialize().
        _cs_key2 = "MONGOMEM_WORKER_ENABLE_CHANGE_STREAMS"
        _cs_prev2 = os.environ.get(_cs_key2)
        os.environ[_cs_key2] = "false"
        try:
            failing_worker = MongoMemWorker(
                engine=failing_engine,
                scaling_mode="distributed",
                auto_extract_on_snapshot=True,
                snapshot_config=SnapshotConfig(
                    strategy="auto",
                    embedding_strategy="generate",  # triggers embedder → will fail
                    max_messages=MAX_MESSAGES_THRESHOLD,
                    delete_promoted=False,
                ),
                extraction_config={
                    "semantic": {"enabled": True},
                    "episodic": {"enabled": True},
                },
            )
            failing_worker.initialize()
        finally:
            if _cs_prev2 is None:
                os.environ.pop(_cs_key2, None)
            else:
                os.environ[_cs_key2] = _cs_prev2

        # Enqueue the check_promotion task with 3 retries (default)
        enqueue_task(
            "snapshot",
            {
                "snapshot_task_type": "check_promotion",
                "session_id": failing_session_id,
                "org_id": org_id,
                "user_id": failing_user_id,
                "reason": "message_count",
            },
            settings=worker_settings,
        )

        # Patch create_snapshot to always raise ConnectionError (transient).
        # This propagates uncaught through the task handler, triggering retry
        # logic: 3 attempts with exponential backoff, then status=failed.
        import time as _time

        patch_target = (
            "runner_shared.server.mongomem_impl.src.mongomem_core"
            ".pipelines.stm_to_snapshot.create_snapshot"
        )
        with patch(patch_target, side_effect=ConnectionError("Simulated snapshot write failure")):
            fail_deadline = _time.monotonic() + 60
            while _time.monotonic() < fail_deadline:
                await failing_worker.process_batch()
                failed_count = self.db.tasks.count_documents(
                    {
                        "status": "failed",
                        "payload.session_id": failing_session_id,
                    }
                )
                if failed_count > 0:
                    break
                await asyncio.sleep(1)

        # Assert the task is permanently failed after 3 retries
        failed_task = self.db.tasks.find_one(
            {
                "status": "failed",
                "payload.session_id": failing_session_id,
            }
        )
        assert failed_task is not None, (
            "Expected check_promotion task for failing session to end in status='failed'"
        )
        # max_retries=3, attempts = max_retries - remaining_retries
        attempts = failed_task.get("max_retries", 3) - failed_task.get("remaining_retries", 0)
        assert attempts >= 3, f"Expected at least 3 attempts before failure, got {attempts}"
        assert "Simulated snapshot write failure" in (failed_task.get("last_error") or ""), (
            f"Expected error to mention simulated failure, got: {failed_task.get('last_error')}"
        )

        # No snapshot should have been created for the failing session
        assert self.db.memory_snapshot.count_documents({"session_id": failing_session_id}) == 0, (
            "Failing session should not have produced a snapshot"
        )
