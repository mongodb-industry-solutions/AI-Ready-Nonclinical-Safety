"""
Integration tests for short-term memory CRUD operations.

These tests use a real MongoDB database to verify end-to-end behavior
of short-term memory operations.
"""

from mongomem_core.memory.short_term import (
    create_stm,
    delete_session_stm,
    get_recent_stm,
    get_stm_by_id,
    get_stm_by_session,
    mark_stm_promoted,
)
from mongomem_core.models.memory.base import MessageRole
from mongomem_core.models.memory.short_term import (
    ShortTermIn,
)


class TestShortTermMemoryCRUD:
    """Integration tests for short-term memory CRUD operations."""

    def test_create_and_get_stm(self, bootstrapped_engine):
        """Test creating and retrieving a short-term memory document."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"
        session_id = "test-session-1"

        turn_in = ShortTermIn(
            session_id=session_id,
            role=MessageRole.USER,
            content="Hello, how are you?",
        )

        created = create_stm(db, turn_in, org_id=org_id, user_id=user_id)

        assert created.id is not None
        assert created.session_id == session_id
        assert created.role == "user"
        assert created.content == "Hello, how are you?"
        assert created.turn_seq == 1  # First turn in session
        assert created.org_id == org_id
        assert created.user_id == user_id

        # Retrieve by ID
        retrieved = get_stm_by_id(db, str(created.id), org_id)
        assert retrieved is not None
        assert retrieved.content == "Hello, how are you?"

    def test_turn_sequence_increments(self, bootstrapped_engine):
        """Test that turn sequence numbers increment correctly."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"
        session_id = "test-session-2"

        # Create multiple turns
        for i in range(3):
            turn_in = ShortTermIn(
                session_id=session_id,
                role=MessageRole.USER if i % 2 == 0 else MessageRole.ASSISTANT,
                content=f"Message {i}",
            )
            created = create_stm(db, turn_in, org_id=org_id, user_id=user_id)
            assert created.turn_seq == i + 1

    def test_get_stm_by_session(self, bootstrapped_engine):
        """Test retrieving all STM documents for a session."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"
        session_id = "test-session-3"

        # Create multiple turns
        for i in range(3):
            turn_in = ShortTermIn(
                session_id=session_id,
                role=MessageRole.USER if i % 2 == 0 else MessageRole.ASSISTANT,
                content=f"Message {i}",
            )
            create_stm(db, turn_in, org_id=org_id, user_id=user_id)

        # Retrieve all turns for session
        turns = get_stm_by_session(db, session_id, org_id)
        assert len(turns) == 3
        assert all(turn.session_id == session_id for turn in turns)
        assert turns[0].turn_seq == 1
        assert turns[1].turn_seq == 2
        assert turns[2].turn_seq == 3

    def test_get_recent_stm(self, bootstrapped_engine):
        """Test retrieving recent STM documents."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"
        session_id = "test-session-4"

        # Create multiple turns
        for i in range(5):
            turn_in = ShortTermIn(
                session_id=session_id,
                role=MessageRole.USER,
                content=f"Message {i}",
            )
            create_stm(db, turn_in, org_id=org_id, user_id=user_id)

        # Get recent 3
        recent = get_recent_stm(db, session_id, org_id, limit=3)
        assert len(recent) == 3
        # Should be in chronological order (oldest first)
        assert recent[0].turn_seq < recent[1].turn_seq < recent[2].turn_seq

    def test_mark_stm_promoted(self, bootstrapped_engine):
        """Test marking STM documents as promoted."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"
        session_id = "test-session-5"

        # Create turns
        turn_ids = []
        for i in range(2):
            turn_in = ShortTermIn(
                session_id=session_id,
                role=MessageRole.USER,
                content=f"Message {i}",
            )
            created = create_stm(db, turn_in, org_id=org_id, user_id=user_id)
            turn_ids.append(str(created.id))

        # Mark as promoted
        result = mark_stm_promoted(db, turn_ids, org_id)
        assert result.modified_count == 2

        # Verify promoted status
        for turn_id in turn_ids:
            turn = get_stm_by_id(db, turn_id, org_id)
            assert turn.promoted is True

    def test_delete_session_stm(self, bootstrapped_engine):
        """Test deleting all STM documents for a session."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"
        session_id = "test-session-6"

        # Create turns
        for i in range(3):
            turn_in = ShortTermIn(
                session_id=session_id,
                role=MessageRole.USER,
                content=f"Message {i}",
            )
            create_stm(db, turn_in, org_id=org_id, user_id=user_id)

        # Delete all turns for session
        result = delete_session_stm(db, session_id, org_id)
        assert result.deleted_count == 3

        # Verify all deleted
        turns = get_stm_by_session(db, session_id, org_id)
        assert len(turns) == 0
