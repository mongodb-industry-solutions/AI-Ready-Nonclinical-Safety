"""Unit tests for SKILL.md bidirectional migration utilities."""

import os
from unittest.mock import MagicMock

import pytest
from mongomem_core.common.utils import utcnow
from mongomem_core.exceptions import DuplicateDocumentError
from mongomem_core.migration.skill_importer import (
    _discover_resources,
    _ext_to_language,
    _split_frontmatter,
    discover_skills,
    export_skills,
    ingest_skills,
    parse_skill_md,
    to_skill_md,
)
from mongomem_core.models.memory.procedural import (
    ProceduralOut,
)


class TestSplitFrontmatter:
    """Tests for YAML frontmatter splitting."""

    def test_basic_frontmatter(self):
        raw = "---\nname: test-skill\ndescription: A skill\n---\n\nBody text here."
        fm, body = _split_frontmatter(raw)
        assert fm is not None
        assert fm["name"] == "test-skill"
        assert fm["description"] == "A skill"
        assert "Body text here." in body

    def test_no_frontmatter(self):
        raw = "Just some markdown without frontmatter."
        fm, body = _split_frontmatter(raw)
        assert fm is None
        assert body == raw

    def test_invalid_yaml(self):
        raw = "---\n: invalid: yaml: [unclosed\n---\n\nBody."
        fm, body = _split_frontmatter(raw)
        assert fm is None

    def test_frontmatter_not_dict(self):
        raw = "---\n- just\n- a\n- list\n---\n\nBody."
        fm, body = _split_frontmatter(raw)
        assert fm is None


class TestParseSkillMd:
    """Tests for parse_skill_md."""

    def _write_skill(self, tmpdir, content, filename="SKILL.md"):
        path = os.path.join(tmpdir, filename)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return path

    def test_basic_parse(self, tmp_path):
        content = (
            "---\n"
            "name: deploy-app\n"
            "description: Deploy the application\n"
            "---\n\n"
            "# Deploy\n\nRun the deploy command."
        )
        path = self._write_skill(str(tmp_path), content)
        result = parse_skill_md(path)

        assert result.procedure == "deploy-app"
        assert result.description == "Deploy the application"
        assert "# Deploy" in result.content
        assert result.source_format == "skill.md"
        assert result.source_path == os.path.abspath(path)

    def test_parse_with_allowed_tools_string(self, tmp_path):
        content = (
            "---\n"
            "name: code-review\n"
            "description: Review code\n"
            "allowed-tools: Bash Read Write\n"
            "---\n\n"
            "Review the code."
        )
        path = self._write_skill(str(tmp_path), content)
        result = parse_skill_md(path)

        assert result.allowed_tools == ["Bash", "Read", "Write"]

    def test_parse_with_allowed_tools_list(self, tmp_path):
        content = (
            "---\n"
            "name: code-review\n"
            "description: Review code\n"
            "allowed-tools:\n"
            "  - Bash\n"
            "  - Read\n"
            "---\n\n"
            "Review the code."
        )
        path = self._write_skill(str(tmp_path), content)
        result = parse_skill_md(path)

        assert result.allowed_tools == ["Bash", "Read"]

    def test_parse_with_optional_fields(self, tmp_path):
        content = (
            "---\n"
            "name: deploy-app\n"
            "description: Deploy the app\n"
            "compatibility: linux, macOS\n"
            "license: MIT\n"
            "---\n\n"
            "Deploy instructions."
        )
        path = self._write_skill(str(tmp_path), content)
        result = parse_skill_md(path)

        assert result.compatibility == "linux, macOS"
        assert result.license == "MIT"

    def test_parse_missing_name_raises(self, tmp_path):
        content = "---\ndescription: No name\n---\n\nBody."
        path = self._write_skill(str(tmp_path), content)

        with pytest.raises(ValueError, match="missing required 'name'"):
            parse_skill_md(path)

    def test_parse_missing_description_raises(self, tmp_path):
        content = "---\nname: no-desc\n---\n\nBody."
        path = self._write_skill(str(tmp_path), content)

        with pytest.raises(ValueError, match="missing required 'description'"):
            parse_skill_md(path)

    def test_parse_no_frontmatter_raises(self, tmp_path):
        content = "Just markdown, no frontmatter."
        path = self._write_skill(str(tmp_path), content)

        with pytest.raises(ValueError, match="No YAML frontmatter"):
            parse_skill_md(path)

    def test_parse_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            parse_skill_md("/nonexistent/path/SKILL.md")


class TestToSkillMd:
    """Tests for to_skill_md export."""

    def _make_out(self, **overrides):
        defaults = {
            "_id": "abc123",
            "procedure": "test-skill",
            "description": "A test skill",
            "content": "# Test\n\nDo the thing.",
            "org_id": "org-1",
            "user_id": "user-1",
            "timestamp": utcnow(),
            "updated_at": utcnow(),
            "version": 1,
            "is_latest": True,
        }
        defaults.update(overrides)
        return ProceduralOut.model_validate(defaults)

    def test_basic_export(self):
        proc = self._make_out()
        md = to_skill_md(proc)

        assert "---" in md
        assert "name: test-skill" in md
        assert "description: A test skill" in md
        assert "# Test" in md
        assert "Do the thing." in md

    def test_export_with_allowed_tools(self):
        proc = self._make_out(allowed_tools=["Bash", "Read"])
        md = to_skill_md(proc)

        assert "allowed-tools: Bash Read" in md

    def test_export_with_all_optional_fields(self):
        proc = self._make_out(
            allowed_tools=["Bash"],
            compatibility="linux",
            license="MIT",
        )
        md = to_skill_md(proc)

        assert "compatibility: linux" in md
        assert "license: MIT" in md

    def test_export_drops_mongomem_extensions(self):
        proc = self._make_out(
            tags=["deploy", "ci"],
            trigger_conditions=["when deploying"],
            steps=[],
        )
        md = to_skill_md(proc)

        assert "tags" not in md
        assert "trigger_conditions" not in md
        assert "steps" not in md

    def test_roundtrip(self, tmp_path):
        """Parse a SKILL.md, convert back, and verify key fields survive."""
        original = (
            "---\n"
            "name: roundtrip-skill\n"
            "description: Tests roundtrip\n"
            "allowed-tools: Bash Read\n"
            "compatibility: linux\n"
            "license: MIT\n"
            "---\n\n"
            "# Roundtrip\n\nInstructions here."
        )
        path = os.path.join(str(tmp_path), "SKILL.md")
        with open(path, "w") as f:
            f.write(original)

        parsed = parse_skill_md(path)

        out = ProceduralOut.model_validate(
            {
                "_id": "rt-123",
                "procedure": parsed.procedure,
                "description": parsed.description,
                "content": parsed.content,
                "allowed_tools": parsed.allowed_tools,
                "compatibility": parsed.compatibility,
                "license": parsed.license,
                "org_id": "org-1",
                "user_id": "user-1",
                "timestamp": utcnow(),
                "updated_at": utcnow(),
                "version": 1,
                "is_latest": True,
            }
        )
        exported = to_skill_md(out)

        assert "name: roundtrip-skill" in exported
        assert "description: Tests roundtrip" in exported
        assert "allowed-tools: Bash Read" in exported
        assert "compatibility: linux" in exported
        assert "license: MIT" in exported
        assert "# Roundtrip" in exported
        assert "Instructions here." in exported


class TestDiscoverSkills:
    """Tests for discover_skills."""

    def test_discovers_skill_files(self, tmp_path):
        skill_dir = tmp_path / "skills" / "deploy"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text("---\nname: deploy\n---\n\nBody")

        another_dir = tmp_path / "skills" / "review"
        another_dir.mkdir(parents=True)
        (another_dir / "SKILL.md").write_text("---\nname: review\n---\n\nBody")

        found = discover_skills(str(tmp_path))
        assert len(found) == 2
        assert all(p.endswith("SKILL.md") for p in found)

    def test_discovers_hidden_skill_dir(self, tmp_path):
        hidden_dir = tmp_path / ".skill"
        hidden_dir.mkdir()
        (hidden_dir / "SKILL.md").write_text("---\nname: hidden\n---\n\nBody")

        found = discover_skills(str(tmp_path))
        assert len(found) == 1

    def test_empty_directory(self, tmp_path):
        found = discover_skills(str(tmp_path))
        assert found == []

    def test_custom_patterns(self, tmp_path):
        (tmp_path / "custom.md").write_text("content")
        found = discover_skills(str(tmp_path), patterns=["**/custom.md"])
        assert len(found) == 1


class TestDiscoverResources:
    """Tests for _discover_resources."""

    def test_discovers_scripts(self, tmp_path):
        scripts_dir = tmp_path / "scripts"
        scripts_dir.mkdir()
        (scripts_dir / "deploy.py").write_text("print('deploy')")
        (scripts_dir / "build.sh").write_text("#!/bin/bash\necho build")

        resources = _discover_resources(str(tmp_path))
        assert len(resources) == 2
        assert all(r.resource_type == "script" for r in resources)

        py_res = next(r for r in resources if r.path.endswith(".py"))
        assert py_res.language == "python"

        sh_res = next(r for r in resources if r.path.endswith(".sh"))
        assert sh_res.language == "bash"

    def test_discovers_references_and_assets(self, tmp_path):
        (tmp_path / "references").mkdir()
        (tmp_path / "references" / "docs.md").write_text("# Docs")

        (tmp_path / "assets").mkdir()
        (tmp_path / "assets" / "config.json").write_text('{"key": "value"}')

        resources = _discover_resources(str(tmp_path))
        assert len(resources) == 2

        ref = next(r for r in resources if r.resource_type == "reference")
        assert ref.path == os.path.join("references", "docs.md")

        asset = next(r for r in resources if r.resource_type == "asset")
        assert asset.path == os.path.join("assets", "config.json")

    def test_inline_content_for_small_files(self, tmp_path):
        (tmp_path / "scripts").mkdir()
        (tmp_path / "scripts" / "small.py").write_text("x = 1")

        resources = _discover_resources(str(tmp_path))
        assert len(resources) == 1
        assert resources[0].content == "x = 1"

    def test_no_resource_dirs(self, tmp_path):
        resources = _discover_resources(str(tmp_path))
        assert resources == []


class TestExtToLanguage:
    """Tests for _ext_to_language mapping."""

    def test_known_extensions(self):
        assert _ext_to_language(".py") == "python"
        assert _ext_to_language(".js") == "javascript"
        assert _ext_to_language(".ts") == "typescript"
        assert _ext_to_language(".sh") == "bash"
        assert _ext_to_language(".sql") == "sql"
        assert _ext_to_language(".go") == "go"
        assert _ext_to_language(".rs") == "rust"

    def test_unknown_extension(self):
        assert _ext_to_language(".xyz") is None
        assert _ext_to_language(".csv") is None


class TestIngestSkills:
    """Tests for batch skill ingestion using a mock engine."""

    def test_ingest_basic(self, tmp_path):
        skill_dir = tmp_path / "my-skill"
        skill_dir.mkdir()
        skill_file = skill_dir / "SKILL.md"
        skill_file.write_text("---\nname: my-skill\ndescription: A skill\n---\n\nDo things.")

        mock_engine = MagicMock()
        mock_result = MagicMock()
        mock_result.id = "created-id"
        mock_engine.create_procedural.return_value = mock_result

        result = ingest_skills(mock_engine, [str(skill_file)], org_id="org-1", user_id="user-1")

        assert result["imported_count"] == 1
        assert result["error_count"] == 0
        mock_engine.create_procedural.assert_called_once()

    def test_ingest_with_tags(self, tmp_path):
        skill_dir = tmp_path / "tagged-skill"
        skill_dir.mkdir()
        skill_file = skill_dir / "SKILL.md"
        skill_file.write_text("---\nname: tagged-skill\ndescription: Tagged\n---\n\nContent.")

        mock_engine = MagicMock()
        mock_result = MagicMock()
        mock_result.id = "id-1"
        mock_engine.create_procedural.return_value = mock_result

        result = ingest_skills(
            mock_engine,
            [str(skill_file)],
            org_id="org-1",
            user_id="user-1",
            tags=["imported", "v1"],
        )

        assert result["imported_count"] == 1
        call_kwargs = mock_engine.create_procedural.call_args
        tags = call_kwargs.kwargs.get("tags") or call_kwargs[1].get("tags")
        assert "imported" in tags
        assert "migrated:skill.md" in tags

    def test_ingest_skips_duplicates(self, tmp_path):
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text("---\nname: dup-skill\ndescription: Dup\n---\n\nContent.")

        mock_engine = MagicMock()
        mock_engine.create_procedural.side_effect = DuplicateDocumentError(
            "duplicate key",
            collection="memory_procedural",
            details={"procedure": "dup-skill"},
        )

        result = ingest_skills(
            mock_engine,
            [str(skill_file)],
            org_id="org-1",
            user_id="user-1",
            skip_duplicates=True,
        )

        assert result["imported_count"] == 0
        assert result["skipped_count"] == 1

    def test_ingest_records_errors(self, tmp_path):
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text("---\nname: err-skill\ndescription: Err\n---\n\nContent.")

        mock_engine = MagicMock()
        mock_engine.create_procedural.side_effect = RuntimeError("DB down")

        result = ingest_skills(
            mock_engine,
            [str(skill_file)],
            org_id="org-1",
            user_id="user-1",
        )

        assert result["imported_count"] == 0
        assert result["error_count"] == 1
        assert "DB down" in result["errors"][0]["error"]


class TestExportSkills:
    """Tests for batch skill export using a mock engine."""

    def _make_out(self, procedure, **overrides):
        defaults = {
            "_id": f"id-{procedure}",
            "procedure": procedure,
            "description": f"Description for {procedure}",
            "content": f"# {procedure}\n\nInstructions.",
            "org_id": "org-1",
            "user_id": "user-1",
            "timestamp": utcnow(),
            "updated_at": utcnow(),
            "version": 1,
            "is_latest": True,
        }
        defaults.update(overrides)
        return ProceduralOut.model_validate(defaults)

    def test_export_basic(self, tmp_path):
        mock_engine = MagicMock()
        mock_engine.list_procedural.return_value = [
            self._make_out("skill-one"),
            self._make_out("skill-two"),
        ]

        result = export_skills(mock_engine, org_id="org-1", output_dir=str(tmp_path))

        assert result["exported_count"] == 2
        assert result["error_count"] == 0

        assert (tmp_path / "skill-one" / "SKILL.md").exists()
        assert (tmp_path / "skill-two" / "SKILL.md").exists()

        content = (tmp_path / "skill-one" / "SKILL.md").read_text()
        assert "name: skill-one" in content

    def test_export_empty(self, tmp_path):
        mock_engine = MagicMock()
        mock_engine.list_procedural.return_value = []

        result = export_skills(mock_engine, org_id="org-1", output_dir=str(tmp_path))

        assert result["exported_count"] == 0
