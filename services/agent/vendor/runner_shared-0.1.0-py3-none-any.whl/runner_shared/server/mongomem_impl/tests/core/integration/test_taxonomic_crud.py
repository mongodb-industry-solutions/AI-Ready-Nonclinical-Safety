"""
Integration tests for taxonomic memory CRUD operations.

These tests use a real MongoDB database to verify end-to-end behavior
of taxonomic memory operations.
"""

import pytest
from mongomem_core.memory.taxonomic import (
    bulk_create_taxonomic,
    count_taxonomic,
    create_taxonomic,
    delete_taxonomic,
    get_distinct_domains,
    get_taxonomic,
    list_taxonomic,
    list_taxonomic_by_domains,
    soft_delete_taxonomic,
    update_taxonomic,
    upsert_taxonomic,
)
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.taxonomic import (
    TaxonomicIn,
    TaxonomicUpdate,
)


class TestTaxonomicMemoryCRUD:
    """Integration tests for taxonomic memory CRUD operations."""

    def test_create_and_get_taxonomic(self, bootstrapped_engine):
        """Test creating and retrieving a taxonomic memory document."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"

        taxonomic_in = TaxonomicIn(
            domain="programming",
            term="Python",
            definition="A high-level programming language known for readability.",
            related_terms=["JavaScript", "Ruby"],
        )

        created = create_taxonomic(db, taxonomic_in, org_id=org_id, user_id=user_id)

        assert created.id is not None
        assert created.domain == "programming"
        assert created.term == "Python"
        assert created.definition == "A high-level programming language known for readability."
        assert created.related_terms == ["JavaScript", "Ruby"]
        assert created.memory_lineage_id is not None
        assert created.memory_lineage_id == str(created.id)  # First version

        # Retrieve by ID
        retrieved = get_taxonomic(db, org_id, id=str(created.id))
        assert retrieved is not None
        assert retrieved.term == "Python"
        assert retrieved.domain == "programming"

        # Retrieve by domain+term
        retrieved_by_key = get_taxonomic(db, org_id, domain="programming", term="Python")
        assert retrieved_by_key is not None
        assert retrieved_by_key.id == str(created.id)

    def test_create_duplicate_fails(self, bootstrapped_engine):
        """Test that creating duplicate domain+term fails."""
        db = bootstrapped_engine.db
        org_id = "test-org-dup"
        user_id = "test-user-1"

        taxonomic_in = TaxonomicIn(
            domain="databases",
            term="MongoDB",
            definition="A document database.",
        )

        # First create succeeds
        create_taxonomic(db, taxonomic_in, org_id=org_id, user_id=user_id)

        # Second create with same domain+term should fail
        from mongomem_core.exceptions import (
            DuplicateDocumentError,
        )

        with pytest.raises(DuplicateDocumentError):
            create_taxonomic(db, taxonomic_in, org_id=org_id, user_id=user_id)

    def test_upsert_taxonomic_creates_new(self, bootstrapped_engine):
        """Test that upsert creates new document when not exists."""
        db = bootstrapped_engine.db
        org_id = "test-org-upsert"
        user_id = "test-user-1"

        taxonomic_in = TaxonomicIn(
            domain="frameworks",
            term="FastAPI",
            definition="A modern web framework for Python.",
        )

        created = upsert_taxonomic(db, taxonomic_in, org_id=org_id, user_id=user_id)

        assert created.id is not None
        assert created.term == "FastAPI"
        assert created.domain == "frameworks"

    def test_upsert_taxonomic_updates_existing(self, bootstrapped_engine):
        """Test that upsert updates existing document."""
        db = bootstrapped_engine.db
        org_id = "test-org-upsert-update"
        user_id = "test-user-1"

        # First create
        taxonomic_in = TaxonomicIn(
            domain="frameworks",
            term="Django",
            definition="A Python web framework.",
        )
        created = upsert_taxonomic(db, taxonomic_in, org_id=org_id, user_id=user_id)
        original_lineage = created.memory_lineage_id

        # Upsert with updated definition
        updated_in = TaxonomicIn(
            domain="frameworks",
            term="Django",
            definition="A batteries-included Python web framework for building web apps.",
        )
        updated = upsert_taxonomic(db, updated_in, org_id=org_id, user_id=user_id)

        # Should be same lineage (conceptually same term) and same document (upsert updates in place)
        assert updated.memory_lineage_id == original_lineage
        assert (
            updated.definition == "A batteries-included Python web framework for building web apps."
        )

    def test_update_taxonomic(self, bootstrapped_engine):
        """Test updating a taxonomic memory document."""
        db = bootstrapped_engine.db
        org_id = "test-org-update"
        user_id = "test-user-1"

        # Create
        taxonomic_in = TaxonomicIn(
            domain="languages",
            term="Rust",
            definition="A systems programming language.",
        )
        created = create_taxonomic(db, taxonomic_in, org_id=org_id, user_id=user_id)

        # Update
        update = TaxonomicUpdate(
            definition="A memory-safe systems programming language.",
            related_terms=["C++", "Go"],
        )
        updated = update_taxonomic(
            db,
            org_id=org_id,
            id=str(created.id),
            update=update,
        )

        assert updated is not None
        assert updated.definition == "A memory-safe systems programming language."
        assert updated.related_terms == ["C++", "Go"]

    def test_list_taxonomic(self, bootstrapped_engine):
        """Test listing taxonomic memory documents."""
        db = bootstrapped_engine.db
        org_id = "test-org-list"
        user_id = "test-user-1"

        # Create multiple documents
        terms = [
            ("cloud", "AWS", "Amazon Web Services"),
            ("cloud", "GCP", "Google Cloud Platform"),
            ("cloud", "Azure", "Microsoft Azure"),
        ]
        for domain, term, definition in terms:
            taxonomic_in = TaxonomicIn(
                domain=domain,
                term=term,
                definition=definition,
            )
            create_taxonomic(db, taxonomic_in, org_id=org_id, user_id=user_id)

        # List all
        all_docs = list_taxonomic(db, org_id)
        assert len(all_docs) >= 3

        # List by domain
        cloud_docs = list_taxonomic(db, org_id, domain="cloud")
        assert len(cloud_docs) == 3

    def test_list_taxonomic_by_domains(self, bootstrapped_engine):
        """Test listing taxonomic documents by multiple domains."""
        db = bootstrapped_engine.db
        org_id = "test-org-domains"
        user_id = "test-user-1"

        # Create documents in different domains
        entries = [
            ("frontend", "React", "A JavaScript library"),
            ("frontend", "Vue", "A progressive framework"),
            ("backend", "Express", "A Node.js framework"),
            ("database", "PostgreSQL", "A relational database"),
        ]
        for domain, term, definition in entries:
            taxonomic_in = TaxonomicIn(
                domain=domain,
                term=term,
                definition=definition,
            )
            create_taxonomic(db, taxonomic_in, org_id=org_id, user_id=user_id)

        # Query by multiple domains
        docs = list_taxonomic_by_domains(db, org_id, domains=["frontend", "backend"])

        assert len(docs) == 3  # 2 frontend + 1 backend
        domains = {doc.domain for doc in docs}
        assert "frontend" in domains
        assert "backend" in domains
        assert "database" not in domains

    def test_get_distinct_domains(self, bootstrapped_engine):
        """Test getting distinct domain names."""
        db = bootstrapped_engine.db
        org_id = "test-org-distinct"
        user_id = "test-user-1"

        # Create documents in different domains
        for domain in ["security", "networking", "devops"]:
            taxonomic_in = TaxonomicIn(
                domain=domain,
                term=f"{domain}_term",
                definition=f"Definition for {domain}",
            )
            create_taxonomic(db, taxonomic_in, org_id=org_id, user_id=user_id)

        # Get distinct domains
        domains = get_distinct_domains(db, org_id)

        assert "security" in domains
        assert "networking" in domains
        assert "devops" in domains

    def test_soft_delete_taxonomic(self, bootstrapped_engine):
        """Test soft deleting a taxonomic document."""
        db = bootstrapped_engine.db
        org_id = "test-org-soft-delete"
        user_id = "test-user-1"

        taxonomic_in = TaxonomicIn(
            domain="testing",
            term="pytest",
            definition="A Python testing framework.",
        )
        created = create_taxonomic(db, taxonomic_in, org_id=org_id, user_id=user_id)

        # Soft delete
        result = soft_delete_taxonomic(db, org_id, id=str(created.id))
        assert result.modified_count == 1

        # Should not be found by default
        retrieved = get_taxonomic(db, org_id, id=str(created.id))
        assert retrieved is None

        # Should be found with include_deleted
        retrieved_deleted = get_taxonomic(db, org_id, id=str(created.id), include_deleted=True)
        assert retrieved_deleted is not None
        assert retrieved_deleted.deleted is True

    def test_hard_delete_taxonomic(self, bootstrapped_engine):
        """Test hard deleting a taxonomic document."""
        db = bootstrapped_engine.db
        org_id = "test-org-hard-delete"
        user_id = "test-user-1"

        taxonomic_in = TaxonomicIn(
            domain="testing",
            term="unittest",
            definition="Python's built-in testing framework.",
        )
        created = create_taxonomic(db, taxonomic_in, org_id=org_id, user_id=user_id)

        # Hard delete
        result = delete_taxonomic(db, org_id, id=str(created.id))
        assert result.deleted_count == 1

        # Should not be found even with include_deleted
        retrieved = get_taxonomic(db, org_id, id=str(created.id), include_deleted=True)
        assert retrieved is None

    def test_delete_by_domain_term(self, bootstrapped_engine):
        """Test deleting by domain+term."""
        db = bootstrapped_engine.db
        org_id = "test-org-delete-key"
        user_id = "test-user-1"

        taxonomic_in = TaxonomicIn(
            domain="tools",
            term="Git",
            definition="A version control system.",
        )
        create_taxonomic(db, taxonomic_in, org_id=org_id, user_id=user_id)

        # Delete by domain+term
        result = soft_delete_taxonomic(db, org_id, domain="tools", term="Git")
        assert result.modified_count == 1

        # Verify deleted
        retrieved = get_taxonomic(db, org_id, domain="tools", term="Git")
        assert retrieved is None

    def test_bulk_create_taxonomic(self, bootstrapped_engine):
        """Test bulk creating taxonomic documents."""
        db = bootstrapped_engine.db
        org_id = "test-org-bulk"
        user_id = "test-user-1"

        terms = [
            TaxonomicIn(domain="ml", term="TensorFlow", definition="ML framework by Google"),
            TaxonomicIn(domain="ml", term="PyTorch", definition="ML framework by Meta"),
            TaxonomicIn(domain="ml", term="Scikit-learn", definition="ML library for Python"),
        ]

        created = bulk_create_taxonomic(db, terms, org_id=org_id, user_id=user_id)

        assert len(created) == 3
        assert all(doc.domain == "ml" for doc in created)

    def test_bulk_create_skips_duplicates(self, bootstrapped_engine):
        """Test that bulk create skips duplicates when configured."""
        db = bootstrapped_engine.db
        org_id = "test-org-bulk-dup"
        user_id = "test-user-1"

        # Create one first
        first = TaxonomicIn(domain="data", term="Pandas", definition="Data manipulation library")
        create_taxonomic(db, first, org_id=org_id, user_id=user_id)

        # Bulk create including the duplicate
        terms = [
            TaxonomicIn(
                domain="data", term="Pandas", definition="Different definition"
            ),  # Duplicate
            TaxonomicIn(domain="data", term="NumPy", definition="Numerical computing"),
        ]

        created = bulk_create_taxonomic(
            db, terms, org_id=org_id, user_id=user_id, skip_duplicates=True
        )

        # Only NumPy should be created
        assert len(created) == 1
        assert created[0].term == "NumPy"

    def test_count_taxonomic(self, bootstrapped_engine):
        """Test counting taxonomic documents."""
        db = bootstrapped_engine.db
        org_id = "test-org-count"
        user_id = "test-user-1"

        # Create some documents
        for i in range(5):
            taxonomic_in = TaxonomicIn(
                domain="counting",
                term=f"term_{i}",
                definition=f"Definition {i}",
            )
            create_taxonomic(db, taxonomic_in, org_id=org_id, user_id=user_id)

        # Count all
        count = count_taxonomic(db, org_id)
        assert count >= 5

        # Count by domain
        domain_count = count_taxonomic(db, org_id, domain="counting")
        assert domain_count == 5

    def test_visibility_filtering(self, bootstrapped_engine):
        """Test filtering by visibility."""
        db = bootstrapped_engine.db
        org_id = "test-org-visibility"
        user_id = "test-user-1"

        # Create with different visibilities
        private_term = TaxonomicIn(
            domain="visibility_test",
            term="private_term",
            definition="A private term",
            visibility=ChunkVisibility.PRIVATE,
        )
        org_term = TaxonomicIn(
            domain="visibility_test",
            term="org_term",
            definition="An org-wide term",
            visibility=ChunkVisibility.ORG,
        )

        create_taxonomic(db, private_term, org_id=org_id, user_id=user_id)
        create_taxonomic(db, org_term, org_id=org_id, user_id=user_id)

        # Filter by visibility
        private_docs = list_taxonomic(
            db, org_id, visibility=ChunkVisibility.PRIVATE, domain="visibility_test"
        )
        org_docs = list_taxonomic(
            db, org_id, visibility=ChunkVisibility.ORG, domain="visibility_test"
        )

        assert len(private_docs) == 1
        assert private_docs[0].term == "private_term"
        assert len(org_docs) == 1
        assert org_docs[0].term == "org_term"

    def test_query_expansion_filtering(self, bootstrapped_engine):
        """Test filtering by query_expansion flag."""
        db = bootstrapped_engine.db
        org_id = "test-org-qe"
        user_id = "test-user-1"

        # Create with different query_expansion settings
        expand_term = TaxonomicIn(
            domain="qe_test",
            term="expand_term",
            definition="Term for query expansion",
            query_expansion=True,
        )
        no_expand_term = TaxonomicIn(
            domain="qe_test",
            term="no_expand_term",
            definition="Term not for query expansion",
            query_expansion=False,
        )

        create_taxonomic(db, expand_term, org_id=org_id, user_id=user_id)
        create_taxonomic(db, no_expand_term, org_id=org_id, user_id=user_id)

        # Filter by query_expansion
        expand_docs = list_taxonomic(db, org_id, domain="qe_test", query_expansion=True)
        no_expand_docs = list_taxonomic(db, org_id, domain="qe_test", query_expansion=False)

        assert len(expand_docs) == 1
        assert expand_docs[0].term == "expand_term"
        assert len(no_expand_docs) == 1
        assert no_expand_docs[0].term == "no_expand_term"
