"""
Unit tests for MemoryEngine observability integration.

These tests verify that:
- MemoryEngine correctly accepts observability parameter
- write_turn() emits metrics (count + latency)
- update_internal_state() emits metrics (latency + tokens)
- Engine works correctly with NoOpObservability (no errors)
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from mongomem_core.engine import MemoryEngine
from mongomem_core.modes import MemoryMode
from mongomem_core.observability import NoOpObservability

from ...conftest import RecordingObservability


class TestEngineObservability:
    """Tests for MemoryEngine observability integration."""

    @patch("mongomem_core.engine.base.get_database")
    def test_accepts_observability_parameter(
        self, mock_get_db: MagicMock, recording_obs: RecordingObservability
    ):
        """Engine can be constructed with custom observability."""
        mock_get_db.return_value = MagicMock()
        engine = MemoryEngine(observability=recording_obs)
        assert engine.observability is recording_obs

    @patch("mongomem_core.engine.base.get_database")
    def test_defaults_to_noop_observability(self, mock_get_db: MagicMock):
        """Engine defaults to NoOpObservability when not provided."""
        mock_get_db.return_value = MagicMock()
        engine = MemoryEngine()
        assert isinstance(engine.observability, NoOpObservability)


class TestWriteTurnObservability:
    """Tests for write_turn() metrics emission."""

    @patch("mongomem_core.engine.base.get_database")
    @patch("mongomem_core.engine.base.create_stm")
    def test_emits_count_and_latency_metrics(
        self,
        mock_create_stm: MagicMock,
        mock_get_db: MagicMock,
        recording_obs: RecordingObservability,
    ):
        """write_turn emits both count and latency metrics."""
        mock_get_db.return_value = MagicMock()
        mock_stm_doc = MagicMock()
        mock_stm_doc.id = "stm_123"
        mock_stm_doc.session_id = "sess_123"
        mock_stm_doc.turn_seq = 1
        mock_create_stm.return_value = mock_stm_doc

        engine = MemoryEngine(observability=recording_obs)
        result = engine.write_turn(
            session_id="sess_123",
            role="user",
            content="Hello",
            org_id="org_1",
            user_id="user_1",
        )

        assert len(recording_obs.get_increments("mongomem.engine.write_turn.count")) == 1
        timings = recording_obs.get_timings("mongomem.engine.write_turn.latency")
        assert len(timings) == 1
        assert timings[0]["value_ms"] >= 0
        assert result.acknowledged is True

    @patch("mongomem_core.engine.base.get_database")
    @patch("mongomem_core.engine.base.create_stm")
    def test_works_with_noop_observability(
        self, mock_create_stm: MagicMock, mock_get_db: MagicMock
    ):
        """write_turn works correctly with default NoOpObservability."""
        mock_get_db.return_value = MagicMock()
        mock_stm_doc = MagicMock()
        mock_stm_doc.id = "stm_123"
        mock_stm_doc.session_id = "sess_123"
        mock_stm_doc.turn_seq = 1
        mock_create_stm.return_value = mock_stm_doc

        engine = MemoryEngine()
        result = engine.write_turn(
            session_id="sess_123",
            role="user",
            content="Hello",
            org_id="org_1",
            user_id="user_1",
        )

        assert result.acknowledged is True
        assert result.id == "stm_123"


class TestUpdateInternalStateObservability:
    """Tests for update_internal_state() metrics emission."""

    @patch("mongomem_core.engine.internal_state.upsert_internal_state")
    @patch("mongomem_core.engine.base.get_database")
    def test_emits_latency_and_tokens_metrics(
        self,
        mock_get_db: MagicMock,
        mock_upsert: MagicMock,
        recording_obs: RecordingObservability,
    ):
        """update_internal_state emits both latency and token metrics."""
        mock_get_db.return_value = MagicMock()
        mock_result = MagicMock()
        mock_result.session_id = "sess_123"
        mock_result.version = 1
        mock_result.previous_version = None
        mock_result.token_count = 250
        mock_result.content_hash = "abc123"
        mock_result.was_noop = False
        mock_upsert.return_value = mock_result

        engine = MemoryEngine(mode=MemoryMode.IWM, observability=recording_obs)
        result = engine.update_internal_state(
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            content="User prefers dark mode.",
        )

        timings = recording_obs.get_timings("mongomem.engine.internal_state.latency")
        assert len(timings) == 1
        assert timings[0]["value_ms"] >= 0

        histograms = recording_obs.get_histograms("mongomem.engine.internal_state.tokens")
        assert len(histograms) == 1
        assert histograms[0]["value"] == 250
        assert result.acknowledged is True

    @patch("mongomem_core.engine.internal_state.upsert_internal_state")
    @patch("mongomem_core.engine.base.get_database")
    def test_works_with_noop_observability(self, mock_get_db: MagicMock, mock_upsert: MagicMock):
        """update_internal_state works correctly with default NoOpObservability."""
        mock_get_db.return_value = MagicMock()
        mock_result = MagicMock()
        mock_result.session_id = "sess_123"
        mock_result.version = 1
        mock_result.previous_version = None
        mock_result.token_count = 100
        mock_result.content_hash = "abc123"
        mock_result.was_noop = False
        mock_upsert.return_value = mock_result

        engine = MemoryEngine(mode=MemoryMode.IWM)
        result = engine.update_internal_state(
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            content="User prefers dark mode.",
        )

        assert result.acknowledged is True
        assert result.version == 1
