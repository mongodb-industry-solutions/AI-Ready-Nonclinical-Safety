import pytest
from pymongo.database import Database

from runner_shared.server.mongomem_impl.src.mongomem_worker.handlers.embeddings import (
    EmbeddingHandler,
)
from runner_shared.server.mongomem_impl.src.mongomem_worker.handlers.entity import EntityHandler
from runner_shared.server.mongomem_impl.src.mongomem_worker.handlers.learning import (
    EpisodicHandler,
    SemanticHandler,
    TaxonomicHandler,
)
from runner_shared.server.mongomem_impl.src.mongomem_worker.handlers.maintenance import (
    MaintenanceHandler,
)
from runner_shared.server.mongomem_impl.src.mongomem_worker.handlers.snapshots import (
    SnapshotHandler,
)

from ..conftest import (
    MockEmbedder,
    MockLLM,
    make_episodic_document,
    make_semantic_document,
    make_stm_document,
)


class TestEmbeddingHandler:
    """Tests for the embedding handler."""

    def test_handler_initialization(self, test_db: Database, mock_embedder: MockEmbedder):
        handler = EmbeddingHandler(
            db=test_db,
            embedder=mock_embedder,
        )

        assert handler is not None
        assert handler._embedder is mock_embedder
        assert handler._db is test_db

    @pytest.mark.asyncio
    async def test_handle_task(self, test_db: Database, mock_embedder: MockEmbedder):
        # Insert a test document
        stm_doc = make_stm_document(content="Test message for embedding")
        test_db.memory_short_term.insert_one(stm_doc)

        handler = EmbeddingHandler(
            db=test_db,
            embedder=mock_embedder,
        )

        await handler.handle_task(
            {
                "doc_id": stm_doc["_id"],
                "org_id": stm_doc["org_id"],
                "content": stm_doc["content"],
                "collection": "memory_short_term",
            }
        )

        # Embedder should have been called
        assert mock_embedder.call_count > 0

    @pytest.mark.asyncio
    async def test_process_pending_all_basic(self, test_db: Database, mock_embedder: MockEmbedder):
        """process_pending_all processes all memory types."""
        # Insert documents without embeddings
        for i in range(3):
            doc = make_stm_document(content=f"Message {i}")
            doc["has_embedding"] = False
            test_db.memory_short_term.insert_one(doc)

        handler = EmbeddingHandler(
            db=test_db,
            embedder=mock_embedder,
            batch_size=10,
        )

        results = await handler.process_pending_all()

        # Should return a dict with counts for each type
        assert isinstance(results, dict)
        # STM async embedding may be disabled by default
        assert results.get("stm", 0) >= 0

    @pytest.mark.asyncio
    async def test_process_pending_stm(self, test_db: Database, mock_embedder: MockEmbedder):
        """process_pending_stm embeds unembedded STM documents."""
        # Insert STM documents without embeddings
        for i in range(2):
            doc = make_stm_document(content=f"STM message {i}")
            doc["has_embedding"] = False
            test_db.memory_short_term.insert_one(doc)

        handler = EmbeddingHandler(db=test_db, embedder=mock_embedder, batch_size=10)
        processed = await handler.process_pending_stm()

        # Should process the documents
        assert processed >= 0  # May be 0 if collection doesn't have proper indexes

    @pytest.mark.asyncio
    async def test_process_pending_semantic(self, test_db: Database, mock_embedder: MockEmbedder):
        """process_pending_semantic embeds unembedded semantic documents."""
        # Insert semantic documents without embeddings
        for i in range(3):
            doc = make_semantic_document(
                label=f"fact-{i}",
                text=f"This is semantic fact number {i}.",
                has_embedding=False,
            )
            test_db.memory_semantic.insert_one(doc)

        handler = EmbeddingHandler(
            db=test_db,
            embedder=mock_embedder,
            batch_size=10,
        )

        processed = await handler.process_pending_semantic()

        # Should have processed all 3 documents
        assert processed == 3
        assert mock_embedder.batch_call_count >= 1

        # Verify documents are now embedded
        embedded_count = test_db.memory_semantic.count_documents({"has_embedding": True})
        assert embedded_count == 3

    @pytest.mark.asyncio
    async def test_process_pending_episodic(self, test_db: Database, mock_embedder: MockEmbedder):
        """process_pending_episodic embeds unembedded episodic documents."""
        # Insert episodic documents without embeddings
        for i in range(2):
            doc = make_episodic_document(
                title=f"Episode {i}",
                content=f"This is episodic memory number {i}.",
                has_embedding=False,
            )
            test_db.memory_episodic.insert_one(doc)

        handler = EmbeddingHandler(
            db=test_db,
            embedder=mock_embedder,
            batch_size=10,
        )

        processed = await handler.process_pending_episodic()

        # Should have processed all 2 documents
        assert processed == 2
        assert mock_embedder.batch_call_count >= 1

        # Verify documents are now embedded
        embedded_count = test_db.memory_episodic.count_documents({"has_embedding": True})
        assert embedded_count == 2

    @pytest.mark.asyncio
    async def test_process_pending_all(self, test_db: Database, mock_embedder: MockEmbedder):
        """process_pending_all embeds both semantic and episodic documents."""
        # Insert semantic documents
        for i in range(2):
            doc = make_semantic_document(
                label=f"fact-{i}",
                text=f"Semantic fact {i}.",
                has_embedding=False,
            )
            test_db.memory_semantic.insert_one(doc)

        # Insert episodic documents
        for i in range(2):
            doc = make_episodic_document(
                title=f"Episode {i}",
                content=f"Episodic memory {i}.",
                has_embedding=False,
            )
            test_db.memory_episodic.insert_one(doc)

        handler = EmbeddingHandler(
            db=test_db,
            embedder=mock_embedder,
            batch_size=10,
        )

        results = await handler.process_pending_all()

        # Should have processed all documents
        assert results["semantic"] == 2
        assert results["episodic"] == 2
        assert results.get("stm", 0) == 0  # STM async disabled by default

        # Verify all documents are embedded
        assert test_db.memory_semantic.count_documents({"has_embedding": True}) == 2
        assert test_db.memory_episodic.count_documents({"has_embedding": True}) == 2

    @pytest.mark.asyncio
    async def test_process_pending_semantic_skips_already_embedded(
        self, test_db: Database, mock_embedder: MockEmbedder
    ):
        """process_pending_semantic skips documents that already have embeddings."""
        # Insert one embedded, one not embedded
        embedded_doc = make_semantic_document(label="embedded", has_embedding=True)
        embedded_doc["embedding"] = [0.1] * 1024
        test_db.memory_semantic.insert_one(embedded_doc)

        unembedded_doc = make_semantic_document(label="unembedded", has_embedding=False)
        test_db.memory_semantic.insert_one(unembedded_doc)

        handler = EmbeddingHandler(db=test_db, embedder=mock_embedder, batch_size=10)
        processed = await handler.process_pending_semantic()

        # Should only process the unembedded one
        assert processed == 1


class TestEntityHandler:
    """Tests for the entity extraction handler."""

    def test_handler_initialization(self, test_db: Database, mock_llm: MockLLM):
        handler = EntityHandler(
            db=test_db,
            llm=mock_llm,
        )

        assert handler is not None
        assert handler._llm is mock_llm

    @pytest.mark.asyncio
    async def test_handle_task_calls_llm(self, test_db: Database, mock_llm: MockLLM):
        """Test that entity extraction calls LLM but raises NotImplementedError on storage.

        Storage is not yet implemented, so the handler logs a warning but succeeds.
        """
        mock_llm.set_json_response(
            "entity",
            [
                {"name": "John", "type": "person"},
                {"name": "MongoDB", "type": "organization"},
            ],
        )

        handler = EntityHandler(
            db=test_db,
            llm=mock_llm,
        )

        # Should complete successfully (logs warning about storage not implemented)
        await handler.handle_task(
            {
                "content": "John works at MongoDB",
                "org_id": "test-org",
                "user_id": "test-user",
                "source_id": "stm:test-123",
                "source_type": "stm",
            }
        )

        # LLM should have been called
        assert mock_llm.call_count > 0

    @pytest.mark.asyncio
    async def test_handle_task_empty_entities_skips_storage(
        self, test_db: Database, mock_llm: MockLLM
    ):
        """Test that empty entity extraction result skips storage without error."""
        # Return empty list
        mock_llm.set_json_response("entity", [])

        handler = EntityHandler(
            db=test_db,
            llm=mock_llm,
        )

        # Should complete without error since empty result skips storage
        await handler.handle_task(
            {
                "content": "Some content with no entities",
                "org_id": "test-org",
                "user_id": "test-user",
                "source_id": "stm:test-123",
                "source_type": "stm",
            }
        )

        assert mock_llm.call_count > 0

    @pytest.mark.asyncio
    async def test_handle_task_empty_content(self, test_db: Database, mock_llm: MockLLM):
        handler = EntityHandler(db=test_db, llm=mock_llm)

        # Should handle gracefully without calling LLM
        await handler.handle_task(
            {
                "content": "",  # Empty content
                "org_id": "test-org",
                "user_id": "test-user",
                "source_id": "stm:test-123",
            }
        )

        assert mock_llm.call_count == 0


class TestLearningHandlers:
    """Tests for the learning extraction handlers (Taxonomic, Episodic, Semantic)."""

    def test_taxonomic_handler_initialization(
        self, test_db: Database, mock_llm: MockLLM, mock_embedder: MockEmbedder
    ):
        handler = TaxonomicHandler(db=test_db, llm=mock_llm, embedder=mock_embedder)

        assert handler is not None
        assert handler.task_type == "taxonomic"
        assert handler._extraction_type == "taxonomic"
        assert handler._taxonomic_pipeline is not None

    def test_episodic_handler_initialization(
        self, test_db: Database, mock_llm: MockLLM, mock_embedder: MockEmbedder
    ):
        handler = EpisodicHandler(db=test_db, llm=mock_llm, embedder=mock_embedder)

        assert handler is not None
        assert handler.task_type == "episodic"
        assert handler._extraction_type == "episodic"

    def test_semantic_handler_initialization(
        self, test_db: Database, mock_llm: MockLLM, mock_embedder: MockEmbedder
    ):
        handler = SemanticHandler(db=test_db, llm=mock_llm, embedder=mock_embedder)

        assert handler is not None
        assert handler.task_type == "semantic"
        assert handler._extraction_type == "semantic"

    @pytest.mark.asyncio
    async def test_taxonomic_extraction(
        self, test_db: Database, mock_llm: MockLLM, mock_embedder: MockEmbedder
    ):
        """Test that taxonomic extraction uses the full pipeline.

        Taxonomic extraction now uses TaxonomicPipeline for extraction
        and storage with consolidation support.
        """
        mock_llm.set_json_response(
            "taxonomic",
            {
                "terms": [
                    {
                        "domain": "technology",
                        "term": "NoSQL",
                        "definition": "A non-relational database approach",
                        "related_terms": ["mongodb", "database"],
                        "evidence_spans": [{"start": 0, "end": 25}],
                        "confidence_score": 0.88,
                    }
                ]
            },
        )

        handler = TaxonomicHandler(db=test_db, llm=mock_llm, embedder=mock_embedder)

        # Should complete successfully using the full pipeline
        await handler.handle_task(
            {
                "content": "We use MongoDB for our NoSQL database needs",
                "org_id": "test-org",
                "user_id": "test-user",
                "source_id": "stm:test-123",
            }
        )

        # LLM should have been called
        assert mock_llm.call_count > 0

    @pytest.mark.asyncio
    async def test_episodic_extraction(
        self, test_db: Database, mock_llm: MockLLM, mock_embedder: MockEmbedder
    ):
        """Test that episodic extraction stores extracted events.

        Episodic extraction now uses EpisodicPipeline with:
        - messages format (or backward-compat content)
        - embedder for consolidation
        - events array response format
        """
        # New response format matches EpisodicExtractor schema
        mock_llm.set_json_response(
            "episodic",
            {
                "events": [
                    {
                        "title": "Meeting about project",
                        "event": "Team had a meeting about the project",
                        "participants": ["team"],
                        "timestamp_hint": "yesterday",
                        "outcome": None,
                        "citations": [0],
                        "confidence_score": 0.9,
                    }
                ]
            },
        )

        handler = EpisodicHandler(db=test_db, llm=mock_llm, embedder=mock_embedder)

        # Uses backward-compatible content format
        await handler.handle_task(
            {
                "content": "Yesterday we had a meeting about the project",
                "org_id": "test-org",
                "user_id": "test-user",
                "source_id": "stm:test-123",
            }
        )

        # LLM should have been called
        assert mock_llm.call_count > 0

        # Verify episodic memory was stored
        from mongomem_core.memory.episodic import (
            list_episodic,
        )

        docs = list_episodic(db=test_db, org_id="test-org")
        assert len(docs) == 1
        assert "Meeting about project" in docs[0].title
        assert docs[0].participants == ["team"]

    @pytest.mark.asyncio
    async def test_semantic_extraction_requires_embedder(
        self, test_db: Database, mock_llm: MockLLM
    ):
        """Test that semantic extraction requires an embedder.

        Semantic extraction now uses a pipeline that requires:
        - messages (list of dicts with role/content)
        - embedder for vector operations
        """
        handler = SemanticHandler(
            db=test_db,
            llm=mock_llm,
            embedder=None,  # No embedder provided
        )

        # Should raise ValueError because embedder is required
        with pytest.raises(ValueError, match="requires an embedder"):
            await handler.handle_task(
                {
                    "messages": [
                        {"role": "user", "content": "What is MongoDB?"},
                        {"role": "assistant", "content": "MongoDB is a document database."},
                    ],
                    "org_id": "test-org",
                    "user_id": "test-user",
                    "source_id": "stm:test-123",
                }
            )

    @pytest.mark.asyncio
    async def test_semantic_extraction_requires_messages(
        self, test_db: Database, mock_llm: MockLLM, mock_embedder: MockEmbedder
    ):
        """Test that semantic extraction requires messages, not content."""
        handler = SemanticHandler(
            db=test_db,
            llm=mock_llm,
            embedder=mock_embedder,
        )

        # Should raise ValueError because messages are required
        with pytest.raises(ValueError, match="Missing required fields"):
            await handler.handle_task(
                {
                    "content": "MongoDB is a document database",  # Wrong format
                    "org_id": "test-org",
                    "user_id": "test-user",
                    "source_id": "stm:test-123",
                }
            )

    @pytest.mark.asyncio
    async def test_taxonomic_extraction_with_messages(
        self, test_db: Database, mock_llm: MockLLM, mock_embedder: MockEmbedder
    ):
        """Test that taxonomic extraction works with messages format.

        Taxonomic extraction now uses TaxonomicPipeline with:
        - messages format (or backward-compat content)
        - embedder for consolidation
        - terms array response format
        """
        # New response format matches TaxonomicExtractor schema
        mock_llm.set_json_response(
            "taxonomic",
            {
                "terms": [
                    {
                        "domain": "programming",
                        "term": "Python",
                        "definition": "A high-level programming language",
                        "related_terms": ["JavaScript", "Ruby"],
                        "evidence_spans": [{"start": 0, "end": 20}],
                        "confidence_score": 0.9,
                    }
                ]
            },
        )

        handler = TaxonomicHandler(db=test_db, llm=mock_llm, embedder=mock_embedder)

        await handler.handle_task(
            {
                "messages": [
                    {"role": "user", "content": "Python is a great programming language."},
                    {"role": "assistant", "content": "Yes, Python is very popular!"},
                ],
                "org_id": "test-org",
                "user_id": "test-user",
                "source_id": "stm:test-123",
            }
        )

        # LLM should have been called
        assert mock_llm.call_count > 0

    @pytest.mark.asyncio
    async def test_taxonomic_extraction_with_content_backward_compat(
        self, test_db: Database, mock_llm: MockLLM, mock_embedder: MockEmbedder
    ):
        """Test that taxonomic extraction supports legacy content format.

        For backward compatibility, content is converted to messages format.
        """
        mock_llm.set_json_response(
            "taxonomic",
            {
                "terms": [
                    {
                        "domain": "databases",
                        "term": "MongoDB",
                        "definition": "A document database",
                        "related_terms": [],
                        "evidence_spans": [{"start": 0, "end": 15}],
                        "confidence_score": 0.85,
                    }
                ]
            },
        )

        handler = TaxonomicHandler(db=test_db, llm=mock_llm, embedder=mock_embedder)

        # Uses backward-compatible content format
        await handler.handle_task(
            {
                "content": "MongoDB is a document database",
                "org_id": "test-org",
                "user_id": "test-user",
                "source_id": "stm:test-123",
            }
        )

        assert mock_llm.call_count > 0

    @pytest.mark.asyncio
    async def test_taxonomic_extraction_requires_embedder(
        self, test_db: Database, mock_llm: MockLLM
    ):
        """Test that taxonomic extraction requires an embedder.

        Taxonomic extraction now uses a pipeline that requires embedder
        for consolidation flow.
        """
        handler = TaxonomicHandler(
            db=test_db,
            llm=mock_llm,
            embedder=None,  # No embedder provided
        )

        # Should raise ValueError because embedder is required
        with pytest.raises(ValueError, match="requires an embedder"):
            await handler.handle_task(
                {
                    "messages": [
                        {"role": "user", "content": "Python is great"},
                    ],
                    "org_id": "test-org",
                    "user_id": "test-user",
                    "source_id": "stm:test-123",
                }
            )

    @pytest.mark.asyncio
    async def test_taxonomic_extraction_stores_terms(
        self, test_db: Database, mock_llm: MockLLM, mock_embedder: MockEmbedder
    ):
        """Test that taxonomic extraction stores extracted terms.

        The pipeline should persist terms to the taxonomic collection.
        """
        mock_llm.set_json_response(
            "taxonomic",
            {
                "terms": [
                    {
                        "domain": "frameworks",
                        "term": "FastAPI",
                        "definition": "A modern web framework for Python",
                        "related_terms": ["Flask", "Django"],
                        "evidence_spans": [{"start": 0, "end": 30}],
                        "confidence_score": 0.95,
                    }
                ]
            },
        )

        handler = TaxonomicHandler(db=test_db, llm=mock_llm, embedder=mock_embedder)

        await handler.handle_task(
            {
                "messages": [
                    {"role": "user", "content": "FastAPI is a modern web framework for Python."},
                ],
                "org_id": "test-org",
                "user_id": "test-user",
                "source_id": "stm:test-123",
            }
        )

        # Verify LLM was called (storage depends on validation thresholds)
        assert mock_llm.call_count > 0

        # Verify we can list taxonomic memories (may be 0 if validation filters out)
        from mongomem_core.memory.taxonomic import (
            list_taxonomic,
        )

        docs = list_taxonomic(db=test_db, org_id="test-org")
        assert isinstance(docs, list)  # Ensure list_taxonomic works correctly


class TestSnapshotHandler:
    """Tests for the snapshot handler."""

    def test_handler_initialization(self, test_db: Database, mock_embedder: MockEmbedder):
        handler = SnapshotHandler(
            db=test_db,
            embedder=mock_embedder,
        )

        assert handler is not None
        assert handler._embedder is mock_embedder

    @pytest.mark.asyncio
    async def test_handle_task_embed(self, test_db: Database, mock_embedder: MockEmbedder):
        # Insert a snapshot document
        snapshot_id = "snap:test-123"
        test_db.memory_snapshot.insert_one(
            {
                "_id": snapshot_id,
                "org_id": "test-org",
                "session_id": "test-session",
                "messages": [
                    {"role": "user", "content": "Hello"},
                    {"role": "assistant", "content": "Hi there!"},
                ],
            }
        )

        handler = SnapshotHandler(db=test_db, embedder=mock_embedder)

        await handler.handle_task(
            {
                "snapshot_task_type": "embed",
                "snapshot_id": snapshot_id,
                "org_id": "test-org",
            }
        )

        # Embedder should have been called
        assert mock_embedder.call_count > 0

        # Check embedding was stored
        snapshot = test_db.memory_snapshot.find_one({"_id": snapshot_id})
        assert snapshot.get("has_embedding") is True

    @pytest.mark.asyncio
    async def test_handle_task_missing_snapshot(
        self, test_db: Database, mock_embedder: MockEmbedder
    ):
        handler = SnapshotHandler(db=test_db, embedder=mock_embedder)

        # Should handle gracefully
        await handler.handle_task(
            {
                "snapshot_task_type": "embed",
                "snapshot_id": "snap:does-not-exist",
                "org_id": "test-org",
            }
        )

        # Embedder should NOT have been called
        assert mock_embedder.call_count == 0


class TestMaintenanceHandler:
    """Tests for the maintenance handler."""

    def test_handler_initialization(self, test_db: Database):
        handler = MaintenanceHandler(db=test_db)
        assert handler is not None
        assert handler._db is test_db

    @pytest.mark.asyncio
    async def test_cleanup_expired_snapshots(self, test_db: Database):
        """Test cleanup of expired AND promoted snapshots.

        IMPORTANT: STM documents are NOT deleted by cleanup_expired!
        They should be promoted to snapshots first, then the promoted
        snapshots can be deleted.

        This cleanup only handles:
        - Expired snapshots that are already promoted to episodic
        """
        from datetime import datetime, timedelta, timezone

        # Insert expired and non-expired snapshots
        now = datetime.now(timezone.utc)
        expired_time = now - timedelta(days=1)
        future_time = now + timedelta(days=1)

        # Expired AND promoted snapshot - should be deleted
        test_db.memory_snapshot.insert_one(
            {
                "_id": "snap:expired_promoted",
                "org_id": "test-org",
                "expires_at": expired_time,
                "promoted": True,  # Already promoted to episodic
            }
        )

        # Expired but NOT promoted snapshot - should NOT be deleted
        test_db.memory_snapshot.insert_one(
            {
                "_id": "snap:expired_not_promoted",
                "org_id": "test-org",
                "expires_at": expired_time,
                "promoted": False,
            }
        )

        # Valid snapshot - should NOT be deleted
        test_db.memory_snapshot.insert_one(
            {
                "_id": "snap:valid",
                "org_id": "test-org",
                "expires_at": future_time,
                "promoted": True,
            }
        )

        handler = MaintenanceHandler(db=test_db)

        await handler.handle_task(
            {
                "maintenance_type": "cleanup_expired",
                "org_id": "test-org",
            }
        )

        # Expired AND promoted should be deleted
        assert test_db.memory_snapshot.find_one({"_id": "snap:expired_promoted"}) is None
        # Expired but NOT promoted should remain
        assert test_db.memory_snapshot.find_one({"_id": "snap:expired_not_promoted"}) is not None
        # Valid should remain
        assert test_db.memory_snapshot.find_one({"_id": "snap:valid"}) is not None

    @pytest.mark.asyncio
    async def test_cleanup_does_not_delete_stm(self, test_db: Database):
        """Test that cleanup_expired does NOT delete STM documents.

        STM documents should be promoted to snapshots first, not deleted directly.
        """
        from datetime import datetime, timedelta, timezone

        # Insert expired STM document
        now = datetime.now(timezone.utc)
        expired_time = now - timedelta(days=1)

        test_db.memory_short_term.insert_one(
            {
                "_id": "stm:expired",
                "org_id": "test-org",
                "expires_at": expired_time,
                "content": "Expired content",
            }
        )

        handler = MaintenanceHandler(db=test_db)

        await handler.handle_task(
            {
                "maintenance_type": "cleanup_expired",
                "org_id": "test-org",
            }
        )

        # STM document should NOT be deleted (needs promotion first)
        assert test_db.memory_short_term.find_one({"_id": "stm:expired"}) is not None

    @pytest.mark.asyncio
    async def test_promote_snapshot(self, test_db: Database):
        handler = MaintenanceHandler(db=test_db)

        # Should handle gracefully (even if promotion logic is TODO)
        await handler.handle_task(
            {
                "maintenance_type": "promote_snapshot",
                "session_id": "test-session",
                "org_id": "test-org",
                "reason": "manual",
            }
        )


class TestHandlerErrorHandling:
    """Tests for handler error handling."""

    @pytest.mark.asyncio
    async def test_entity_handler_llm_error_propagates(self, test_db: Database):
        """Entity handler propagates LLM errors for task queue retry."""

        class FailingLLM:
            def complete(self, prompt: str, **kwargs) -> str:
                raise RuntimeError("LLM service unavailable")

            def complete_json(self, prompt: str, schema: dict, **kwargs) -> dict:
                raise RuntimeError("LLM service unavailable")

        handler = EntityHandler(
            db=test_db,
            llm=FailingLLM(),
        )

        # Handler propagates LLM errors - task queue handles retry
        with pytest.raises(RuntimeError, match="LLM service unavailable"):
            await handler.handle_task(
                {
                    "content": "Test text",
                    "org_id": "test-org",
                    "user_id": "test-user",
                    "source_id": "stm:test-123",
                }
            )

    @pytest.mark.asyncio
    async def test_learning_handler_empty_content_raises(
        self, test_db: Database, mock_llm: MockLLM, mock_embedder: MockEmbedder
    ):
        """Test that empty content raises ValueError instead of silently succeeding.

        Empty content is an invalid task and should fail so the task queue
        can mark it as failed and it can be investigated.
        """
        handler = TaxonomicHandler(db=test_db, llm=mock_llm, embedder=mock_embedder)

        # Should raise ValueError for missing messages/content
        with pytest.raises(ValueError, match="messages.*content"):
            await handler.handle_task(
                {
                    "content": "",  # Empty
                    "org_id": "test-org",
                    "user_id": "test-user",
                    "source_id": "stm:test-123",
                }
            )

        # LLM should NOT have been called since validation fails first
        assert mock_llm.call_count == 0
