"""
Tests for the ingestion pipeline.

Tests ingest_documents() orchestration and IngestConfig.
"""

from pathlib import Path
from unittest.mock import MagicMock

import pytest
from mongomem_core.ingest.models import (
    SUPPORTED_EXTENSIONS,
    ChunkConfig,
    ChunkerType,
    ExtractorType,
    IngestConfig,
    IngestResult,
    validate_file_extension,
)


class TestIngestConfig:
    """Tests for IngestConfig dataclass."""

    def test_default_values(self):
        """Test default configuration values."""
        config = IngestConfig()

        assert config.extractor == ExtractorType.SIMPLE
        assert config.chunker == ChunkerType.AUTO
        assert config.max_retries == 2
        assert config.on_failure == "skip"

    def test_custom_chunk_config(self):
        """Test custom chunk configuration."""
        chunk_config = ChunkConfig(max_chunk_size=500, min_chunk_size=100)
        config = IngestConfig(chunk_config=chunk_config)

        assert config.chunk_config.max_chunk_size == 500
        assert config.chunk_config.min_chunk_size == 100

    def test_get_effective_chunker_auto_simple(self):
        """Test effective chunker selection for simple extractor."""
        config = IngestConfig(
            extractor=ExtractorType.SIMPLE,
            chunker=ChunkerType.AUTO,
        )

        assert config.get_effective_chunker() == ChunkerType.RECURSIVE

    def test_get_effective_chunker_explicit(self):
        """Test explicit chunker selection."""
        config = IngestConfig(chunker=ChunkerType.RECURSIVE)

        assert config.get_effective_chunker() == ChunkerType.RECURSIVE


class TestFileValidation:
    """Tests for file extension validation."""

    def test_supported_extensions(self):
        """Test that expected extensions are supported."""
        assert ".txt" in SUPPORTED_EXTENSIONS
        assert ".pdf" in SUPPORTED_EXTENSIONS
        assert ".pptx" in SUPPORTED_EXTENSIONS
        assert ".docx" in SUPPORTED_EXTENSIONS

    def test_unsupported_extensions(self):
        """Test that unexpected extensions are not supported."""
        assert ".xlsx" not in SUPPORTED_EXTENSIONS
        assert ".doc" not in SUPPORTED_EXTENSIONS
        assert ".jpg" not in SUPPORTED_EXTENSIONS

    def test_validate_supported_extension(self):
        """Test validation passes for supported files."""
        error = validate_file_extension("document.pdf", ExtractorType.SIMPLE)
        assert error is None

        error = validate_file_extension("notes.txt", ExtractorType.SIMPLE)
        assert error is None

    def test_validate_unsupported_extension(self):
        """Test validation fails for unsupported files."""
        error = validate_file_extension("data.xlsx", ExtractorType.SIMPLE)
        assert error is not None
        assert "Unsupported file type" in error
        assert ".xlsx" in error

    def test_validate_case_insensitive(self):
        """Test validation is case-insensitive."""
        error = validate_file_extension("DOCUMENT.PDF", ExtractorType.SIMPLE)
        assert error is None

        error = validate_file_extension("Notes.TXT", ExtractorType.SIMPLE)
        assert error is None


class TestIngestResult:
    """Tests for IngestResult dataclass."""

    def test_result_attributes(self):
        """Test IngestResult has all expected attributes."""
        from mongomem_core.ingest.models import FileResult

        result = IngestResult(
            files_processed=3,
            files_succeeded=2,
            files_failed=1,
            total_chunks=10,
            file_results=[
                FileResult(path="doc1.pdf", success=True, chunks_created=5),
                FileResult(path="doc2.txt", success=True, chunks_created=5),
                FileResult(path="bad.xlsx", success=False, error="Unsupported"),
            ],
            chunk_ids=["id1", "id2"],
        )

        assert result.files_processed == 3
        assert result.files_succeeded == 2
        assert result.files_failed == 1
        assert result.total_chunks == 10
        assert len(result.file_results) == 3
        assert len(result.chunk_ids) == 2


class TestIngestDocuments:
    """Integration-style tests for ingest_documents pipeline."""

    def test_ingest_single_txt_file(self, tmp_path: Path):
        """Test ingesting a single text file."""
        from mongomem_core.ingest.pipeline import (
            ingest_documents,
        )

        # Create test file with enough content to form chunks
        txt_file = tmp_path / "test.txt"
        txt_file.write_text("This is a test document with enough content to create a chunk. " * 20)

        # Create mock engine
        mock_engine = MagicMock()
        mock_engine.bulk_create_semantic.return_value = MagicMock(
            created_ids=["id1"], created_count=1, skipped_count=0
        )

        # Use config with small min_chunk_size to ensure chunks are created
        config = IngestConfig(
            chunk_config=ChunkConfig(min_chunk_size=10, discard_small_chunks=False)
        )
        result = ingest_documents(
            engine=mock_engine,
            paths=[str(txt_file)],
            org_id="test-org",
            user_id="test-user",
            config=config,
        )

        assert result.files_processed == 1
        assert result.files_succeeded == 1
        assert result.files_failed == 0
        mock_engine.bulk_create_semantic.assert_called_once()

    def test_ingest_multiple_files(self, tmp_path: Path):
        """Test ingesting multiple files."""
        from mongomem_core.ingest.pipeline import (
            ingest_documents,
        )

        # Create test files
        (tmp_path / "doc1.txt").write_text("Document 1 content with enough text.")
        (tmp_path / "doc2.txt").write_text("Document 2 content with enough text.")

        mock_engine = MagicMock()
        mock_engine.bulk_create_semantic.return_value = MagicMock(
            created_ids=["id1", "id2"], created_count=2, skipped_count=0
        )

        result = ingest_documents(
            engine=mock_engine,
            paths=[str(tmp_path / "doc1.txt"), str(tmp_path / "doc2.txt")],
            org_id="test-org",
            user_id="test-user",
        )

        assert result.files_processed == 2
        assert result.files_succeeded == 2

    def test_ingest_skip_unsupported_files(self, tmp_path: Path):
        """Test skipping unsupported files with on_failure='skip'."""
        from mongomem_core.ingest.pipeline import (
            ingest_documents,
        )

        # Create test files
        (tmp_path / "doc.txt").write_text("Valid document content.")
        (tmp_path / "data.xlsx").write_text("fake excel")

        mock_engine = MagicMock()
        mock_engine.bulk_create_semantic.return_value = MagicMock(
            created_ids=["id1"], created_count=1, skipped_count=0
        )

        config = IngestConfig(on_failure="skip")
        result = ingest_documents(
            engine=mock_engine,
            paths=[str(tmp_path / "doc.txt"), str(tmp_path / "data.xlsx")],
            org_id="test-org",
            user_id="test-user",
            config=config,
        )

        assert result.files_processed == 2
        assert result.files_succeeded == 1
        assert result.files_failed == 1

    def test_ingest_raise_on_unsupported(self, tmp_path: Path):
        """Test raising exception on unsupported files with on_failure='raise'."""
        from mongomem_core.ingest.pipeline import (
            ingest_documents,
        )

        (tmp_path / "data.xlsx").write_text("fake excel")

        mock_engine = MagicMock()
        config = IngestConfig(on_failure="raise")

        with pytest.raises(ValueError, match="Unsupported file type"):
            ingest_documents(
                engine=mock_engine,
                paths=[str(tmp_path / "data.xlsx")],
                org_id="test-org",
                user_id="test-user",
                config=config,
            )

    def test_ingest_nonexistent_file(self, tmp_path: Path):
        """Test handling non-existent files."""
        from mongomem_core.ingest.pipeline import (
            ingest_documents,
        )

        mock_engine = MagicMock()
        mock_engine.bulk_create_semantic.return_value = MagicMock(
            created_ids=[], created_count=0, skipped_count=0
        )

        config = IngestConfig(on_failure="skip")
        result = ingest_documents(
            engine=mock_engine,
            paths=[str(tmp_path / "nonexistent.txt")],
            org_id="test-org",
            user_id="test-user",
            config=config,
        )

        assert result.files_processed == 1
        assert result.files_failed == 1
        assert "not found" in result.file_results[0].error.lower()

    def test_ingest_with_custom_chunk_config(self, tmp_path: Path):
        """Test ingestion with custom chunk configuration."""
        from mongomem_core.ingest.pipeline import (
            ingest_documents,
        )

        txt_file = tmp_path / "test.txt"
        txt_file.write_text("Content. " * 100)  # Enough content for chunking

        mock_engine = MagicMock()
        mock_engine.bulk_create_semantic.return_value = MagicMock(
            created_ids=["id1"], created_count=1, skipped_count=0
        )

        config = IngestConfig(chunk_config=ChunkConfig(max_chunk_size=50, chunk_overlap=10))
        result = ingest_documents(
            engine=mock_engine,
            paths=[str(txt_file)],
            org_id="test-org",
            user_id="test-user",
            config=config,
        )

        assert result.files_succeeded == 1
        # Check that bulk_create_semantic was called with items
        call_args = mock_engine.bulk_create_semantic.call_args
        assert "items" in call_args.kwargs or len(call_args.args) > 0

    def test_ingest_passes_correct_metadata(self, tmp_path: Path):
        """Test that ingestion passes correct metadata to bulk_create_semantic."""
        from mongomem_core.ingest.pipeline import (
            ingest_documents,
        )

        txt_file = tmp_path / "myfile.txt"
        txt_file.write_text("Test content for metadata verification. " * 20)

        mock_engine = MagicMock()
        mock_engine.bulk_create_semantic.return_value = MagicMock(
            created_ids=["id1"], created_count=1, skipped_count=0
        )

        # Use config with small min_chunk_size to ensure chunks are created
        config = IngestConfig(
            chunk_config=ChunkConfig(min_chunk_size=10, discard_small_chunks=False)
        )
        ingest_documents(
            engine=mock_engine,
            paths=[str(txt_file)],
            org_id="my-org",
            user_id="my-user",
            visibility="private",
            project_id="my-group",
            config=config,
        )

        # Verify the call was made
        assert mock_engine.bulk_create_semantic.called
        call_kwargs = mock_engine.bulk_create_semantic.call_args.kwargs
        assert call_kwargs["org_id"] == "my-org"
        assert call_kwargs["user_id"] == "my-user"
        assert call_kwargs["visibility"] == "private"
        assert call_kwargs["project_id"] == "my-group"
