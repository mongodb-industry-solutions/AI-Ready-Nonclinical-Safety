"""Unit tests for semantic extraction module."""

from unittest.mock import MagicMock, patch

import pytest
from mongomem_core.extraction.config import (
    SemanticExtractionConfig,
)
from mongomem_core.extraction.semantic import (
    SemanticExtractor,
    SemanticPipeline,
    create_semantic_pipeline,
)
from mongomem_core.extraction.types import ExtractedItem


class TestSemanticExtractor:
    """Tests for SemanticExtractor class."""

    @pytest.fixture
    def mock_llm(self):
        """Mock LLM that returns valid extraction response."""
        llm = MagicMock()
        llm.complete_json.return_value = {
            "memories": [
                {
                    "content": "The user is a Data Scientist",
                    "citations": [0],
                    "confidence_score": 0.95,
                },
                {
                    "content": "The user works at a tech company in Boston",
                    "citations": [0],
                    "confidence_score": 0.90,
                },
            ]
        }
        return llm

    @pytest.fixture
    def sample_messages(self):
        """Sample conversation messages."""
        return [
            {"role": "user", "content": "I'm a Data Scientist at a tech company in Boston."},
            {"role": "assistant", "content": "That's great! What kind of projects do you work on?"},
        ]

    def test_extract_basic(self, mock_llm, sample_messages):
        """Test basic extraction from messages."""
        extractor = SemanticExtractor(mock_llm)

        result = extractor.extract(sample_messages)

        assert len(result) == 2
        assert result[0].content == "The user is a Data Scientist"
        assert result[0].citations == [0]
        assert result[0].confidence == 0.95

    def test_extract_empty_messages(self, mock_llm):
        """Test extraction with empty messages."""
        extractor = SemanticExtractor(mock_llm)

        result = extractor.extract([])

        assert result == []
        mock_llm.complete_json.assert_not_called()

    def test_extract_no_memories(self, mock_llm, sample_messages):
        """Test extraction when LLM returns no memories."""
        mock_llm.complete_json.return_value = {"memories": []}
        extractor = SemanticExtractor(mock_llm)

        result = extractor.extract(sample_messages)

        assert result == []

    def test_extract_filters_empty_content(self, mock_llm, sample_messages):
        """Test that empty content is filtered out."""
        mock_llm.complete_json.return_value = {
            "memories": [
                {"content": "Valid content", "citations": [0], "confidence_score": 0.9},
                {"content": "", "citations": [0], "confidence_score": 0.9},  # Empty
                {"content": "   ", "citations": [0], "confidence_score": 0.9},  # Whitespace
            ]
        }
        extractor = SemanticExtractor(mock_llm)

        result = extractor.extract(sample_messages)

        assert len(result) == 1
        assert result[0].content == "Valid content"

    def test_extract_llm_failure(self, mock_llm, sample_messages):
        """Test handling of LLM failure."""
        mock_llm.complete_json.side_effect = Exception("LLM error")
        extractor = SemanticExtractor(mock_llm)

        result = extractor.extract(sample_messages)

        assert result == []

    def test_prompt_resolver(self, mock_llm, sample_messages):
        """Test custom prompt resolver is used."""
        custom_prompt = "Custom extraction prompt"
        resolver = MagicMock(return_value=custom_prompt)
        extractor = SemanticExtractor(mock_llm, prompt_resolver=resolver)

        extractor.extract(sample_messages)

        resolver.assert_called_once()
        # Custom prompt should be in the LLM call
        call_args = mock_llm.complete_json.call_args
        assert custom_prompt in call_args[1]["prompt"]

    def test_prompt_resolver_fallback(self, mock_llm, sample_messages):
        """Test fallback to default when resolver returns None."""
        resolver = MagicMock(return_value=None)
        extractor = SemanticExtractor(mock_llm, prompt_resolver=resolver)

        extractor.extract(sample_messages)

        resolver.assert_called_once()
        # Should still call LLM with default prompt
        mock_llm.complete_json.assert_called_once()

    def test_extraction_type(self, mock_llm):
        """Test extraction_type property."""
        extractor = SemanticExtractor(mock_llm)
        assert extractor.extraction_type == "semantic"


class TestSemanticPipeline:
    """Tests for SemanticPipeline class."""

    @pytest.fixture
    def mock_extractor(self):
        """Mock extractor."""
        extractor = MagicMock()
        extractor.extract.return_value = [
            ExtractedItem(
                content="The user likes Python",
                citations=[0],
                confidence=0.9,
            )
        ]
        return extractor

    @pytest.fixture
    def mock_consolidator(self):
        """Mock consolidator."""
        from mongomem_core.extraction.types import (
            ConsolidationDecision,
            ScoredExtraction,
        )

        consolidator = MagicMock()
        extraction = ScoredExtraction(
            content="The user likes Python",
            citations=[0],
            confidence=0.9,
            citation_score=1.0,
            combined_score=0.96,
            is_valid=True,
            embedding=[0.1, 0.2, 0.3],
        )
        consolidator.process.return_value = [
            ConsolidationDecision(
                extraction=extraction,
                action="ADD",
                reason="new fact",
            )
        ]
        return consolidator

    @pytest.fixture
    def mock_db(self):
        """Mock database."""
        return MagicMock()

    @pytest.fixture
    def config(self):
        """Default config."""
        return SemanticExtractionConfig()

    @pytest.fixture
    def sample_messages(self):
        """Sample messages."""
        return [
            {"role": "user", "content": "I love Python programming."},
        ]

    def test_run_basic(self, mock_extractor, mock_consolidator, mock_db, config, sample_messages):
        """Test basic pipeline run."""
        with patch("mongomem_core.extraction.semantic.apply_decisions") as mock_apply:
            from mongomem_core.extraction.types import (
                PersistenceResult,
            )

            mock_apply.return_value = PersistenceResult(
                added=1,
                created_ids=["id1"],
            )

            pipeline = SemanticPipeline(
                extractor=mock_extractor,
                config=config,
                consolidator=mock_consolidator,
                db=mock_db,
                embedding_model_id="text-embedding-ada-002",
            )

            result = pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

            assert result.success is True
            assert result.extracted_count == 1
            assert result.stored_count == 1
            assert "id1" in result.created_ids

    def test_run_disabled(self, mock_extractor, mock_consolidator, mock_db, sample_messages):
        """Test pipeline when extraction is disabled."""
        config = SemanticExtractionConfig(enabled=False)

        pipeline = SemanticPipeline(
            extractor=mock_extractor,
            config=config,
            consolidator=mock_consolidator,
            db=mock_db,
            embedding_model_id="text-embedding-ada-002",
        )

        result = pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

        assert result.success is True
        assert result.extracted_count == 0
        mock_extractor.extract.assert_not_called()

    def test_run_no_extractions(self, mock_consolidator, mock_db, config, sample_messages):
        """Test pipeline when no extractions found."""
        mock_extractor = MagicMock()
        mock_extractor.extract.return_value = []

        pipeline = SemanticPipeline(
            extractor=mock_extractor,
            config=config,
            consolidator=mock_consolidator,
            db=mock_db,
            embedding_model_id="text-embedding-ada-002",
        )

        result = pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

        assert result.success is True
        assert result.extracted_count == 0
        mock_consolidator.process.assert_not_called()

    def test_run_error_handling(
        self, mock_extractor, mock_consolidator, mock_db, config, sample_messages
    ):
        """Test error handling in pipeline."""
        mock_extractor.extract.side_effect = Exception("Extraction error")

        pipeline = SemanticPipeline(
            extractor=mock_extractor,
            config=config,
            consolidator=mock_consolidator,
            db=mock_db,
            embedding_model_id="text-embedding-ada-002",
        )

        result = pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

        assert result.success is False
        assert len(result.errors) == 1
        assert "Extraction error" in result.errors[0]

    def test_run_limits_extractions(self, mock_consolidator, mock_db, sample_messages):
        """Test that extractions are limited per snapshot."""
        mock_extractor = MagicMock()
        # Return more than limit
        mock_extractor.extract.return_value = [
            ExtractedItem(content=f"Fact {i}", citations=[0], confidence=0.9) for i in range(15)
        ]
        config = SemanticExtractionConfig(max_facts_per_snapshot=10)

        with patch("mongomem_core.extraction.semantic.enrich_citations"):
            with patch("mongomem_core.extraction.semantic.score_batch") as mock_score:
                mock_score.return_value = []  # Short-circuit

                pipeline = SemanticPipeline(
                    extractor=mock_extractor,
                    config=config,
                    consolidator=mock_consolidator,
                    db=mock_db,
                    embedding_model_id="text-embedding-ada-002",
                )

                pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

                # enrich_citations should receive limited list
                call_args = mock_score.call_args
                assert len(call_args[0][0]) == 10

    def test_run_tracks_processing_time(
        self, mock_extractor, mock_consolidator, mock_db, config, sample_messages
    ):
        """Test that processing time is tracked."""
        with patch("mongomem_core.extraction.semantic.apply_decisions") as mock_apply:
            from mongomem_core.extraction.types import (
                PersistenceResult,
            )

            mock_apply.return_value = PersistenceResult(added=1)

            pipeline = SemanticPipeline(
                extractor=mock_extractor,
                config=config,
                consolidator=mock_consolidator,
                db=mock_db,
                embedding_model_id="text-embedding-ada-002",
            )

            result = pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

            assert result.metadata.processing_time_ms >= 0
            assert result.metadata.extraction_timestamp is not None


class TestCreateSemanticPipeline:
    """Tests for create_semantic_pipeline factory function."""

    @pytest.fixture
    def mock_db(self):
        """Mock database."""
        return MagicMock()

    @pytest.fixture
    def mock_llm(self):
        """Mock LLM."""
        return MagicMock()

    @pytest.fixture
    def mock_embedder(self):
        """Mock embedder."""
        embedder = MagicMock()
        embedder.model_id = "text-embedding-ada-002"
        return embedder

    def test_creates_pipeline(self, mock_db, mock_llm, mock_embedder):
        """Test basic pipeline creation."""
        pipeline = create_semantic_pipeline(
            db=mock_db,
            llm=mock_llm,
            embedder=mock_embedder,
        )

        assert isinstance(pipeline, SemanticPipeline)
        assert isinstance(pipeline.extractor, SemanticExtractor)

    def test_uses_default_config(self, mock_db, mock_llm, mock_embedder):
        """Test default config is used when not provided."""
        pipeline = create_semantic_pipeline(
            db=mock_db,
            llm=mock_llm,
            embedder=mock_embedder,
        )

        assert pipeline.config.enabled is True
        assert pipeline.config.min_combined_score_threshold == 0.5

    def test_uses_custom_config(self, mock_db, mock_llm, mock_embedder):
        """Test custom config is used."""
        config = SemanticExtractionConfig(
            min_combined_score_threshold=0.8,
            max_facts_per_snapshot=5,
        )

        pipeline = create_semantic_pipeline(
            db=mock_db,
            llm=mock_llm,
            embedder=mock_embedder,
            config=config,
        )

        assert pipeline.config.min_combined_score_threshold == 0.8
        assert pipeline.config.max_facts_per_snapshot == 5

    def test_uses_llm_consolidation_by_default(self, mock_db, mock_llm, mock_embedder):
        """Test LLM-based consolidation is used by default."""
        from mongomem_core.extraction.consolidator import (
            LLMBasedStrategy,
        )

        pipeline = create_semantic_pipeline(
            db=mock_db,
            llm=mock_llm,
            embedder=mock_embedder,
        )

        assert isinstance(pipeline.consolidator._strategy, LLMBasedStrategy)

    def test_uses_rule_based_consolidation(self, mock_db, mock_llm, mock_embedder):
        """Test rule-based consolidation option."""
        from mongomem_core.extraction.consolidator import (
            RuleBasedStrategy,
        )

        pipeline = create_semantic_pipeline(
            db=mock_db,
            llm=mock_llm,
            embedder=mock_embedder,
            use_llm_consolidation=False,
        )

        assert isinstance(pipeline.consolidator._strategy, RuleBasedStrategy)

    def test_prompt_resolvers_passed(self, mock_db, mock_llm, mock_embedder):
        """Test prompt resolvers are passed to components."""
        extraction_resolver = MagicMock(return_value=None)
        consolidation_resolver = MagicMock(return_value=None)

        pipeline = create_semantic_pipeline(
            db=mock_db,
            llm=mock_llm,
            embedder=mock_embedder,
            extraction_prompt_resolver=extraction_resolver,
            consolidation_prompt_resolver=consolidation_resolver,
        )

        # Resolvers should be stored on the extractor
        assert pipeline.extractor._prompt_resolver is extraction_resolver

    def test_embedding_model_id_captured(self, mock_db, mock_llm, mock_embedder):
        """Test embedding model ID is captured from embedder."""
        mock_embedder.model_id = "custom-embedding-model"

        pipeline = create_semantic_pipeline(
            db=mock_db,
            llm=mock_llm,
            embedder=mock_embedder,
        )

        assert pipeline._embedding_model_id == "custom-embedding-model"
