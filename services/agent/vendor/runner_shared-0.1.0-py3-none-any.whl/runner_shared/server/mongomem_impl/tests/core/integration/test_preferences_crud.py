"""
Integration tests for preferences extraction CRUD and pipeline.

Tests the full flow from extraction to persistence.
"""

from __future__ import annotations

import os
from typing import Any, Dict

import pytest
from mongomem_core.extraction.preferences import (
    ExtractedPreferences,
    PreferencesExtractionConfig,
    create_preferences_pipeline,
)
from mongomem_core.extraction.preferences.persistence import (
    upsert_extracted_preferences,
)
from mongomem_core.memory.user_prefs import (
    create_user_context,
    delete_user_context,
    get_session_preferences_with_fallback,
    get_user_context,
    update_user_context,
)
from mongomem_core.models.memory.user_prefs import (
    UserContextMemoryIn,
    UserContextMemoryUpdate,
)
from pymongo import MongoClient


class MockLLM:
    """Mock LLM that returns configurable preferences."""

    def __init__(self, preferences: Dict[str, Any]):
        self.preferences = preferences

    def complete_json(self, prompt: str, schema: Dict) -> Dict[str, Any]:
        return {"preferences": self.preferences}


@pytest.fixture
def test_db():
    """Create a test database connection."""
    uri = os.environ.get("MONGODB_URI", "mongodb://localhost:27017")
    client = MongoClient(uri)
    db = client["test_preferences_extraction"]

    # Cleanup before test
    db.memory_user_context.delete_many({})

    yield db

    # Cleanup after test
    db.memory_user_context.delete_many({})
    client.close()


class TestPreferencesCRUD:
    """Test CRUD operations for session-scoped preferences."""

    def test_create_session_preferences(self, test_db):
        """Test creating session-scoped preferences."""
        ctx_in = UserContextMemoryIn(
            session_id="sess_123",
            tone="casual",
            style="concise",
            expertise_level="expert",
        )

        doc = create_user_context(
            db=test_db,
            ctx_in=ctx_in,
            org_id="org_1",
            user_id="user_1",
        )

        assert doc.session_id == "sess_123"
        assert doc.tone == "casual"
        assert doc.style == "concise"
        assert doc.expertise_level == "expert"

    def test_get_session_preferences(self, test_db):
        """Test retrieving session-specific preferences."""
        # Create session prefs
        ctx_in = UserContextMemoryIn(
            session_id="sess_456",
            tone="formal",
        )
        create_user_context(test_db, ctx_in, "org_1", "user_1")

        # Retrieve
        fetched = get_user_context(test_db, "org_1", "user_1", session_id="sess_456")

        assert fetched is not None
        assert fetched.session_id == "sess_456"
        assert fetched.tone == "formal"

    def test_update_session_preferences(self, test_db):
        """Test updating session preferences."""
        # Create
        ctx_in = UserContextMemoryIn(
            session_id="sess_789",
            tone="casual",
            style="detailed",
        )
        create_user_context(test_db, ctx_in, "org_1", "user_1")

        # Update
        update = UserContextMemoryUpdate(
            expertise_level="beginner",
            custom_instructions="Explain everything step by step",
        )
        updated = update_user_context(test_db, "org_1", "user_1", update, session_id="sess_789")

        assert updated.expertise_level == "beginner"
        assert updated.custom_instructions == "Explain everything step by step"
        assert updated.tone == "casual"  # Unchanged

    def test_fallback_to_user_defaults(self, test_db):
        """Test fallback from session to user-level defaults."""
        # Create user-level defaults (no session_id)
        default_ctx = UserContextMemoryIn(
            tone="formal",
            style="detailed",
            language="en",
        )
        create_user_context(test_db, default_ctx, "org_1", "user_1")

        # Get non-existent session should fall back
        prefs = get_session_preferences_with_fallback(
            test_db, "org_1", "user_1", "non_existent_session"
        )

        assert prefs is not None
        assert prefs.session_id is None  # User default
        assert prefs.tone == "formal"
        assert prefs.style == "detailed"

    def test_session_prefs_override_defaults(self, test_db):
        """Test session preferences override user defaults."""
        # Create user defaults
        default_ctx = UserContextMemoryIn(
            tone="formal",
            style="detailed",
        )
        create_user_context(test_db, default_ctx, "org_1", "user_1")

        # Create session-specific prefs
        session_ctx = UserContextMemoryIn(
            session_id="sess_override",
            tone="casual",  # Different from default
        )
        create_user_context(test_db, session_ctx, "org_1", "user_1")

        # Get with fallback
        prefs = get_session_preferences_with_fallback(test_db, "org_1", "user_1", "sess_override")

        assert prefs.session_id == "sess_override"
        assert prefs.tone == "casual"  # Session-specific

    def test_delete_session_preferences(self, test_db):
        """Test deleting session preferences leaves user defaults."""
        # Create user defaults
        default_ctx = UserContextMemoryIn(tone="formal")
        create_user_context(test_db, default_ctx, "org_1", "user_1")

        # Create session prefs
        session_ctx = UserContextMemoryIn(
            session_id="sess_delete",
            tone="casual",
        )
        create_user_context(test_db, session_ctx, "org_1", "user_1")

        # Delete session prefs
        delete_user_context(test_db, "org_1", "user_1", session_id="sess_delete")

        # Session should be gone
        session = get_user_context(test_db, "org_1", "user_1", session_id="sess_delete")
        assert session is None

        # User defaults should remain
        defaults = get_user_context(test_db, "org_1", "user_1", session_id=None)
        assert defaults is not None
        assert defaults.tone == "formal"


class TestPreferencesExtraction:
    """Test extracted preferences persistence."""

    def test_upsert_creates_new_preferences(self, test_db):
        """Test upserting new extracted preferences."""
        extracted = ExtractedPreferences(
            tone="casual",
            style="concise",
            expertise_level="expert",
            confidence=0.9,
        )

        result = upsert_extracted_preferences(
            db=test_db,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_new",
            extracted=extracted,
            source_id="snap_123",
        )

        assert result.success is True
        assert result.action == "add"
        assert result.doc_id is not None

        # Verify in DB
        doc = get_user_context(test_db, "org_1", "user_1", session_id="sess_new")
        assert doc.tone == "casual"
        assert doc.style == "concise"
        assert doc.expertise_level == "expert"

    def test_upsert_merges_with_existing(self, test_db):
        """Test upserting merges with existing preferences."""
        # Create initial prefs
        initial_ctx = UserContextMemoryIn(
            session_id="sess_merge",
            tone="casual",
            style="concise",
        )
        create_user_context(test_db, initial_ctx, "org_1", "user_1")

        # Extract new field
        extracted = ExtractedPreferences(
            expertise_level="beginner",
            confidence=0.85,
        )

        result = upsert_extracted_preferences(
            db=test_db,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_merge",
            extracted=extracted,
            source_id="snap_456",
        )

        assert result.success is True
        assert result.action == "merge"
        assert result.fields_updated == 1

        # Verify merged
        doc = get_user_context(test_db, "org_1", "user_1", session_id="sess_merge")
        assert doc.tone == "casual"  # Original
        assert doc.style == "concise"  # Original
        assert doc.expertise_level == "beginner"  # New

    def test_upsert_respects_user_override(self, test_db):
        """Test extraction doesn't override user_input source."""
        # Create user-set preference
        user_ctx = UserContextMemoryIn(
            session_id="sess_user",
            tone="formal",
            source="user_input",  # User explicitly set this
        )
        create_user_context(test_db, user_ctx, "org_1", "user_1")

        # Try to extract different tone
        extracted = ExtractedPreferences(
            tone="casual",  # Different from user's choice
            style="detailed",  # New field
            confidence=0.95,
        )

        upsert_extracted_preferences(
            db=test_db,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_user",
            extracted=extracted,
            source_id="snap_789",
        )

        # Should only add style, not override tone
        doc = get_user_context(test_db, "org_1", "user_1", session_id="sess_user")
        assert doc.tone == "formal"  # User's choice preserved
        assert doc.style == "detailed"  # New field added

    def test_upsert_skips_low_confidence(self, test_db):
        """Test extraction skipped for low confidence."""
        extracted = ExtractedPreferences(
            tone="casual",
            confidence=0.3,  # Below threshold
        )

        result = upsert_extracted_preferences(
            db=test_db,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_low",
            extracted=extracted,
            source_id="snap_low",
            min_confidence=0.5,
        )

        assert result.success is True
        assert result.action == "skip"

        # Verify nothing was created
        doc = get_user_context(test_db, "org_1", "user_1", session_id="sess_low")
        assert doc is None


class TestPreferencesPipeline:
    """Integration tests for full preferences pipeline."""

    def test_pipeline_full_flow(self, test_db):
        """Test full extraction pipeline flow."""
        mock_llm = MockLLM(
            {
                "tone": "casual",
                "style": "concise",
                "expertise_level": "expert",
                "confidence": 0.9,
            }
        )

        pipeline = create_preferences_pipeline(
            db=test_db,
            llm=mock_llm,
        )

        result = pipeline.run(
            messages=[
                {"role": "user", "content": "Skip the intro, I know this stuff."},
                {"role": "assistant", "content": "Got it, here's the implementation..."},
            ],
            org_id="org_1",
            user_id="user_1",
            session_id="sess_pipeline",
            source_id="snap_pipeline",
        )

        assert result.success is True
        assert result.extracted is True
        assert result.action == "add"
        assert result.duration_ms > 0

        # Verify in DB
        doc = get_user_context(test_db, "org_1", "user_1", session_id="sess_pipeline")
        assert doc.tone == "casual"
        assert doc.expertise_level == "expert"

    def test_pipeline_no_preferences_extracted(self, test_db):
        """Test pipeline when no preferences found."""
        mock_llm = MockLLM(
            {
                "confidence": 0.0,  # No preferences found
            }
        )

        pipeline = create_preferences_pipeline(
            db=test_db,
            llm=mock_llm,
        )

        result = pipeline.run(
            messages=[{"role": "user", "content": "What's 2+2?"}],
            org_id="org_1",
            user_id="user_1",
            session_id="sess_empty",
            source_id="snap_empty",
        )

        assert result.success is True
        assert result.extracted is False
        assert result.action == "skip"

    def test_pipeline_with_custom_config(self, test_db):
        """Test pipeline with custom threshold."""
        mock_llm = MockLLM(
            {
                "tone": "casual",
                "confidence": 0.6,
            }
        )

        config = PreferencesExtractionConfig(
            min_confidence_threshold=0.7,  # Higher threshold
        )

        pipeline = create_preferences_pipeline(
            db=test_db,
            llm=mock_llm,
            config=config,
        )

        result = pipeline.run(
            messages=[{"role": "user", "content": "Be casual."}],
            org_id="org_1",
            user_id="user_1",
            session_id="sess_threshold",
            source_id="snap_threshold",
        )

        # Should skip due to confidence below threshold
        assert result.success is True
        assert result.action == "skip"
