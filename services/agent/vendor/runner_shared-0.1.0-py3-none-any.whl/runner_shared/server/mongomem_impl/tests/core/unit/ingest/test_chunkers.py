"""
Tests for document chunkers.

Tests the RecursiveChunker with LangChain's RecursiveCharacterTextSplitter.
"""

from mongomem_core.ingest.chunkers.recursive import (
    RecursiveChunker,
)
from mongomem_core.ingest.models import ChunkConfig


class TestRecursiveChunker:
    """Tests for RecursiveChunker."""

    def test_initialization(self):
        """Test chunker initializes with default config."""
        config = ChunkConfig()
        chunker = RecursiveChunker(config)

        assert chunker.config.max_chunk_size == 400
        assert chunker.config.min_chunk_size == 50
        assert chunker.config.chunk_overlap == 50

    def test_chunk_short_text(self):
        """Test chunking short text that fits in one chunk."""
        config = ChunkConfig(max_chunk_size=100, min_chunk_size=5, discard_small_chunks=False)
        chunker = RecursiveChunker(config)

        text = "This is a short text that should fit in one chunk."
        chunks = chunker.chunk(text)

        assert len(chunks) == 1
        assert chunks[0] == text  # chunk() returns List[str]

    def test_chunk_long_text(self):
        """Test chunking long text into multiple chunks."""
        config = ChunkConfig(max_chunk_size=50, min_chunk_size=10, chunk_overlap=10)
        chunker = RecursiveChunker(config)

        # Create a text that will be split
        text = " ".join(["word"] * 200)  # Lots of words
        chunks = chunker.chunk(text)

        assert len(chunks) > 1
        # Each chunk should have text (chunk() returns List[str])
        for chunk in chunks:
            assert len(chunk) > 0

    def test_chunk_with_offsets(self):
        """Test that chunks include character offset metadata."""
        config = ChunkConfig(max_chunk_size=50, min_chunk_size=10, chunk_overlap=10)
        chunker = RecursiveChunker(config)

        text = " ".join(["word"] * 200)
        chunks = chunker.chunk_with_offsets(text)

        assert len(chunks) > 1
        for chunk in chunks:
            assert hasattr(chunk, "text")
            assert hasattr(chunk, "start_char")
            assert hasattr(chunk, "end_char")
            assert chunk.start_char >= 0
            assert chunk.end_char > chunk.start_char

    def test_discard_small_chunks(self):
        """Test that small chunks are discarded when configured."""
        config = ChunkConfig(
            max_chunk_size=100,
            min_chunk_size=20,
            discard_small_chunks=True,
        )
        chunker = RecursiveChunker(config)

        # Text with some very short segments
        text = "A. B. C. D. " + "This is a longer segment that should be kept. " * 5
        chunks = chunker.chunk(text)

        # All chunks should have content (chunk() returns List[str])
        for chunk in chunks:
            assert len(chunk) >= 10  # Some buffer for tokenization differences

    def test_keep_small_chunks(self):
        """Test that small chunks are kept when discard_small_chunks is False."""
        config = ChunkConfig(
            max_chunk_size=100,
            min_chunk_size=20,
            discard_small_chunks=False,
        )
        chunker = RecursiveChunker(config)

        text = "Short. " + "This is a longer segment. " * 10
        chunks = chunker.chunk(text)

        # Should have at least one chunk
        assert len(chunks) >= 1

    def test_empty_text(self):
        """Test chunking empty text."""
        config = ChunkConfig()
        chunker = RecursiveChunker(config)

        chunks = chunker.chunk("")
        assert chunks == []

    def test_whitespace_text(self):
        """Test chunking whitespace-only text."""
        config = ChunkConfig()
        chunker = RecursiveChunker(config)

        chunks = chunker.chunk("   \n\n\t  ")
        # Empty or very small chunks should be discarded
        assert len(chunks) == 0

    def test_custom_encoding(self):
        """Test chunker with custom encoding."""
        # Use small min_chunk_size so short text isn't discarded
        config = ChunkConfig(
            encoding_name="cl100k_base", min_chunk_size=5, discard_small_chunks=False
        )
        chunker = RecursiveChunker(config)

        text = "Test with custom encoding. This needs enough content to form a valid chunk."
        chunks = chunker.chunk(text)

        assert len(chunks) >= 1


class TestChunkConfig:
    """Tests for ChunkConfig dataclass."""

    def test_default_values(self):
        """Test default configuration values."""
        config = ChunkConfig()

        assert config.max_chunk_size == 400
        assert config.min_chunk_size == 50
        assert config.chunk_overlap == 50
        assert config.encoding_name == "cl100k_base"
        assert config.discard_small_chunks is True

    def test_custom_values(self):
        """Test custom configuration values."""
        config = ChunkConfig(
            max_chunk_size=200,
            min_chunk_size=25,
            chunk_overlap=30,
            encoding_name="p50k_base",
            discard_small_chunks=False,
        )

        assert config.max_chunk_size == 200
        assert config.min_chunk_size == 25
        assert config.chunk_overlap == 30
        assert config.encoding_name == "p50k_base"
        assert config.discard_small_chunks is False
