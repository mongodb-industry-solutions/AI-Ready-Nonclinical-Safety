"""
Unit tests for thread retrieval pipeline.

Tests cover:
- Anchor selection (vector, text, hybrid)
- Expansion strategies (topic, session, similarity, adaptive)
- Token/snapshot budget enforcement
- Cross-session behavior
- ConversationThread utilities
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import List, Optional
from unittest.mock import MagicMock

import pytest
from mongomem_core.common.utils import utcnow
from mongomem_core.models.config.thread_retrieval import (
    DEEP_CONTEXT_CONFIG,
    KNOWLEDGE_RETRIEVAL_CONFIG,
    QUICK_CONTEXT_CONFIG,
    RESUME_SESSION_CONFIG,
    ThreadRetrievalConfig,
)
from mongomem_core.models.memory.base import MessageRole
from mongomem_core.models.memory.snapshot import (
    SnapshotMessage,
    SnapshotOut,
)
from mongomem_core.models.retrieval import (
    ConversationThread,
    ThreadRetrievalMetrics,
)
from mongomem_core.retrieval.thread import (
    _estimate_tokens,
    _expand_adaptive,
    _expand_by_session,
    _expand_by_similarity,
    _expand_by_topic,
    _finalize_thread,
    _select_anchors,
    retrieve_conversation_thread,
)

# ─────────────────────────────────────────────────────────────────────────────
# Fixtures and Helpers
# ─────────────────────────────────────────────────────────────────────────────


def make_snapshot(
    id: str,
    session_id: str = "session_1",
    topic_id: Optional[str] = None,
    content: str = "Hello world",
    timestamp: Optional[datetime] = None,
    score: Optional[float] = None,
    embedding: Optional[List[float]] = None,
    token_count: Optional[int] = None,
) -> SnapshotOut:
    """Create a test snapshot."""
    now = timestamp or utcnow()
    messages = [
        SnapshotMessage(
            role=MessageRole.USER,
            content=content,
            timestamp=now,
        )
    ]

    metadata = {}
    if token_count is not None:
        metadata["token_count"] = token_count

    return SnapshotOut(
        _id=id,
        org_id="org_1",
        user_id="user_1",
        session_id=session_id,
        messages=messages,
        snapshot_reason="auto",
        timestamp=now,
        has_embedding=embedding is not None,
        embedding=embedding,
        topic_id=topic_id,
        score=score,
        metadata=metadata if metadata else None,
    )


@dataclass
class MockBackend:
    """Mock snapshot search backend for testing."""

    vector_results: List[SnapshotOut] = None
    text_results: List[SnapshotOut] = None
    topic_results: List[SnapshotOut] = None
    session_results: List[SnapshotOut] = None

    def __post_init__(self):
        self.vector_results = self.vector_results or []
        self.text_results = self.text_results or []
        self.topic_results = self.topic_results or []
        self.session_results = self.session_results or []

    def vector_search(
        self,
        org_id: str,
        embedding: List[float],
        top_k: int,
        *,
        exclude_ids: Optional[set] = None,
    ) -> List[SnapshotOut]:
        results = self.vector_results[:top_k]
        if exclude_ids:
            results = [r for r in results if r.id not in exclude_ids]
        return results

    def text_search(
        self,
        org_id: str,
        query: str,
        top_k: int,
    ) -> List[SnapshotOut]:
        return self.text_results[:top_k]

    def hybrid_search(
        self,
        org_id: str,
        query: str,
        embedder,
        top_k: int,
    ) -> List[SnapshotOut]:
        # Combine vector and text for mock
        combined = self.vector_results + self.text_results
        seen = set()
        unique = []
        for r in combined:
            if r.id not in seen:
                seen.add(r.id)
                unique.append(r)
        return unique[:top_k]

    def list_by_topic(
        self,
        org_id: str,
        session_id: str,
        topic_id: str,
    ) -> List[SnapshotOut]:
        return [r for r in self.topic_results if r.topic_id == topic_id]

    def list_by_session(
        self,
        org_id: str,
        session_id: str,
        *,
        limit: int = 100,
    ) -> List[SnapshotOut]:
        return [r for r in self.session_results if r.session_id == session_id][:limit]


@pytest.fixture
def mock_embedder():
    """Create a mock embedder."""
    embedder = MagicMock()
    embedder.embed.return_value = [0.1, 0.2, 0.3]
    return embedder


# ─────────────────────────────────────────────────────────────────────────────
# ThreadRetrievalConfig Tests
# ─────────────────────────────────────────────────────────────────────────────


class TestThreadRetrievalConfig:
    """Tests for ThreadRetrievalConfig model."""

    def test_default_config(self):
        """Default config has sensible values."""
        config = ThreadRetrievalConfig()
        assert config.search_mode == "vector"
        assert config.expansion == "adaptive"
        assert config.max_tokens == 8_000
        assert config.max_snapshots == 10
        assert config.allow_cross_session is True

    def test_with_overrides(self):
        """with_overrides creates new config without mutation."""
        config = ThreadRetrievalConfig(max_tokens=4000)
        new_config = config.with_overrides(max_tokens=8000, max_snapshots=5)

        assert config.max_tokens == 4000  # Original unchanged
        assert new_config.max_tokens == 8000
        assert new_config.max_snapshots == 5

    def test_preset_configs(self):
        """Preset configs have expected values."""
        assert RESUME_SESSION_CONFIG.allow_cross_session is False
        assert RESUME_SESSION_CONFIG.expansion == "session"

        assert KNOWLEDGE_RETRIEVAL_CONFIG.allow_cross_session is True
        assert KNOWLEDGE_RETRIEVAL_CONFIG.expansion == "adaptive"

        assert DEEP_CONTEXT_CONFIG.max_tokens == 12_000
        assert DEEP_CONTEXT_CONFIG.max_snapshots == 15

        assert QUICK_CONTEXT_CONFIG.max_tokens == 2_000
        assert QUICK_CONTEXT_CONFIG.max_snapshots == 3


# ─────────────────────────────────────────────────────────────────────────────
# ConversationThread Tests
# ─────────────────────────────────────────────────────────────────────────────


class TestConversationThread:
    """Tests for ConversationThread result model."""

    def test_empty_thread(self):
        """Empty thread has correct defaults."""
        thread = ConversationThread()
        assert thread.is_empty is True
        assert thread.is_cross_session is False
        assert thread.message_count == 0
        assert thread.time_range is None

    def test_thread_properties(self):
        """Thread properties calculate correctly."""
        now = utcnow()
        snaps = [
            make_snapshot("1", session_id="s1", timestamp=now - timedelta(hours=2)),
            make_snapshot("2", session_id="s1", timestamp=now - timedelta(hours=1)),
            make_snapshot("3", session_id="s2", timestamp=now),
        ]
        thread = ConversationThread(
            snapshots=snaps,
            sessions_included=["s1", "s2"],
        )

        assert thread.is_empty is False
        assert thread.is_cross_session is True
        assert thread.message_count == 3

        time_range = thread.time_range
        assert time_range is not None
        assert time_range[0] == snaps[0].timestamp
        assert time_range[1] == snaps[2].timestamp

    def test_to_context_string(self):
        """to_context_string formats correctly."""
        snaps = [
            make_snapshot("1", content="Hello"),
            make_snapshot("2", content="World"),
        ]
        thread = ConversationThread(snapshots=snaps)

        context = thread.to_context_string()
        assert "user: Hello" in context
        assert "user: World" in context

    def test_to_messages(self):
        """to_messages creates LLM-compatible format."""
        snaps = [make_snapshot("1", content="Hello")]
        thread = ConversationThread(snapshots=snaps)

        messages = thread.to_messages()
        assert len(messages) == 1
        assert messages[0]["role"] == "user"
        assert messages[0]["content"] == "Hello"


# ─────────────────────────────────────────────────────────────────────────────
# Anchor Selection Tests
# ─────────────────────────────────────────────────────────────────────────────


class TestAnchorSelection:
    """Tests for anchor selection logic."""

    def test_vector_search_with_embedding(self):
        """Vector search works with pre-computed embedding."""
        snap = make_snapshot("1", score=0.9)
        backend = MockBackend(vector_results=[snap])
        config = ThreadRetrievalConfig(search_mode="vector")

        anchors = _select_anchors(backend, "org_1", [0.1, 0.2, 0.3], config, embedder=None)

        assert len(anchors) == 1
        assert anchors[0].id == "1"

    def test_vector_search_with_text_query(self, mock_embedder):
        """Vector search embeds text query when needed."""
        snap = make_snapshot("1", score=0.9)
        backend = MockBackend(vector_results=[snap])
        config = ThreadRetrievalConfig(search_mode="vector")

        anchors = _select_anchors(backend, "org_1", "search query", config, embedder=mock_embedder)

        mock_embedder.embed.assert_called_once_with("search query")
        assert len(anchors) == 1

    def test_text_search_mode(self):
        """Text search mode uses text_search backend method."""
        snap = make_snapshot("1", score=0.8)
        backend = MockBackend(text_results=[snap])
        config = ThreadRetrievalConfig(search_mode="text")

        anchors = _select_anchors(backend, "org_1", "search query", config, None)

        assert len(anchors) == 1
        assert anchors[0].id == "1"

    def test_hybrid_search_mode(self, mock_embedder):
        """Hybrid search combines vector and text."""
        snap1 = make_snapshot("1", score=0.9)
        snap2 = make_snapshot("2", score=0.8)
        backend = MockBackend(vector_results=[snap1], text_results=[snap2])
        config = ThreadRetrievalConfig(search_mode="hybrid")

        anchors = _select_anchors(backend, "org_1", "search query", config, mock_embedder)

        # Hybrid combines both
        assert len(anchors) >= 1

    def test_vector_search_requires_embedder(self):
        """Vector search with text query raises without embedder."""
        backend = MockBackend()
        config = ThreadRetrievalConfig(search_mode="vector")

        with pytest.raises(ValueError, match="embedder is required"):
            _select_anchors(backend, "org_1", "text query", config, embedder=None)


# ─────────────────────────────────────────────────────────────────────────────
# Expansion Strategy Tests
# ─────────────────────────────────────────────────────────────────────────────


class TestTopicExpansion:
    """Tests for topic-based expansion."""

    def test_expand_by_topic(self):
        """Topic expansion returns all snapshots with same topic_id."""
        now = utcnow()
        anchor = make_snapshot("1", topic_id="topic_a", timestamp=now)
        related = [
            make_snapshot("2", topic_id="topic_a", timestamp=now - timedelta(hours=1)),
            make_snapshot("3", topic_id="topic_a", timestamp=now + timedelta(hours=1)),
        ]
        backend = MockBackend(topic_results=[anchor] + related)
        config = ThreadRetrievalConfig()

        snaps, path = _expand_by_topic(backend, "org_1", anchor, config)

        assert len(snaps) == 3
        assert "topic" in path

    def test_no_topic_id_returns_anchor(self):
        """Anchor without topic_id returns only anchor."""
        anchor = make_snapshot("1", topic_id=None)
        backend = MockBackend()
        config = ThreadRetrievalConfig()

        snaps, path = _expand_by_topic(backend, "org_1", anchor, config)

        assert len(snaps) == 1
        assert snaps[0].id == "1"


class TestSessionExpansion:
    """Tests for session-based expansion."""

    def test_expand_by_session_window(self):
        """Session expansion returns window around anchor."""
        now = utcnow()
        snaps = [
            make_snapshot("1", timestamp=now - timedelta(hours=3)),
            make_snapshot("2", timestamp=now - timedelta(hours=2)),
            make_snapshot("3", timestamp=now - timedelta(hours=1)),  # Anchor
            make_snapshot("4", timestamp=now),
            make_snapshot("5", timestamp=now + timedelta(hours=1)),
        ]
        anchor = snaps[2]
        backend = MockBackend(session_results=snaps)
        config = ThreadRetrievalConfig(
            session_window_before=2,
            session_window_after=1,
        )

        result, path = _expand_by_session(backend, "org_1", anchor, config)

        # Should get 2 before + anchor + 1 after = 4 snapshots
        assert len(result) == 4
        assert "session" in path

    def test_window_at_start(self):
        """Session window handles anchor at start of list."""
        now = utcnow()
        snaps = [
            make_snapshot("1", timestamp=now),  # Anchor at start
            make_snapshot("2", timestamp=now + timedelta(hours=1)),
            make_snapshot("3", timestamp=now + timedelta(hours=2)),
        ]
        anchor = snaps[0]
        backend = MockBackend(session_results=snaps)
        config = ThreadRetrievalConfig(
            session_window_before=5,
            session_window_after=2,
        )

        result, path = _expand_by_session(backend, "org_1", anchor, config)

        # Should get anchor + 2 after = 3 snapshots
        assert len(result) == 3


class TestSimilarityExpansion:
    """Tests for similarity cascade expansion."""

    def test_expand_by_similarity(self, mock_embedder):
        """Similarity cascade follows embeddings."""
        anchor = make_snapshot("1", embedding=[0.1, 0.2], score=0.95)
        related1 = make_snapshot("2", embedding=[0.2, 0.3], score=0.85)
        related2 = make_snapshot("3", embedding=[0.3, 0.4], score=0.75)
        related3 = make_snapshot("4", embedding=[0.4, 0.5], score=0.50)  # Below threshold

        # Each search returns next in cascade
        backend = MockBackend(
            vector_results=[related1, related2, related3],
        )
        config = ThreadRetrievalConfig(
            similarity_min_score=0.70,
            max_snapshots=10,
        )

        snaps, path = _expand_by_similarity(backend, "org_1", anchor, config, mock_embedder)

        # Should include anchor + related1 + related2 (related3 below threshold)
        assert len(snaps) >= 1
        assert "similarity" in path

    def test_similarity_respects_token_budget(self, mock_embedder):
        """Similarity cascade stops at token budget."""
        anchor = make_snapshot("1", embedding=[0.1], token_count=3000)
        related = make_snapshot("2", embedding=[0.2], score=0.9, token_count=3000)

        backend = MockBackend(vector_results=[related])
        config = ThreadRetrievalConfig(
            max_tokens=5000,  # Only room for anchor
        )

        snaps, path = _expand_by_similarity(backend, "org_1", anchor, config, mock_embedder)

        # Should only have anchor (related would exceed budget)
        assert len(snaps) >= 1


class TestAdaptiveExpansion:
    """Tests for adaptive expansion strategy."""

    def test_adaptive_combines_strategies(self, mock_embedder):
        """Adaptive expansion combines topic, session, and cross-session."""
        now = utcnow()

        # Primary anchor with topic
        anchor = make_snapshot("1", session_id="s1", topic_id="topic_a", timestamp=now, score=0.95)

        # Topic-related snapshots
        topic_snaps = [
            anchor,
            make_snapshot(
                "2", session_id="s1", topic_id="topic_a", timestamp=now - timedelta(hours=1)
            ),
        ]

        # Session snapshots
        session_snaps = [
            make_snapshot("3", session_id="s1", timestamp=now - timedelta(hours=2)),
            anchor,
            make_snapshot("4", session_id="s1", timestamp=now + timedelta(hours=1)),
        ]

        # Cross-session anchor
        cross_anchor = make_snapshot("5", session_id="s2", timestamp=now, score=0.8)
        cross_session_snaps = [
            make_snapshot("6", session_id="s2", timestamp=now - timedelta(hours=1)),
            cross_anchor,
        ]

        backend = MockBackend(
            topic_results=topic_snaps,
            session_results=session_snaps + cross_session_snaps,
        )
        config = ThreadRetrievalConfig(
            expansion="adaptive",
            allow_cross_session=True,
        )

        snaps, path = _expand_adaptive(
            backend, "org_1", anchor, [anchor, cross_anchor], config, mock_embedder
        )

        # Should include snapshots from multiple phases
        assert len(snaps) >= 2
        assert "adaptive" in path

    def test_adaptive_respects_budget(self):
        """Adaptive expansion stops at budget limits."""
        anchor = make_snapshot("1", topic_id="topic_a", token_count=3000)
        topic_snaps = [
            anchor,
            make_snapshot("2", topic_id="topic_a", token_count=3000),
            make_snapshot("3", topic_id="topic_a", token_count=3000),
        ]

        backend = MockBackend(topic_results=topic_snaps)
        config = ThreadRetrievalConfig(
            expansion="adaptive",
            max_tokens=5000,  # Only room for ~2 snapshots
        )

        snaps, path = _expand_adaptive(backend, "org_1", anchor, [anchor], config, None)

        # Should stop due to token budget
        assert len(snaps) <= 2


# ─────────────────────────────────────────────────────────────────────────────
# Finalization Tests
# ─────────────────────────────────────────────────────────────────────────────


class TestFinalization:
    """Tests for thread finalization."""

    def test_deduplication(self):
        """Finalization removes duplicates."""
        snap = make_snapshot("1")
        config = ThreadRetrievalConfig()

        final, tokens, filtered = _finalize_thread([snap, snap, snap], config)

        assert len(final) == 1

    def test_chronological_sort(self):
        """Finalization sorts by timestamp."""
        now = utcnow()
        snaps = [
            make_snapshot("3", timestamp=now + timedelta(hours=2)),
            make_snapshot("1", timestamp=now),
            make_snapshot("2", timestamp=now + timedelta(hours=1)),
        ]
        config = ThreadRetrievalConfig()

        final, tokens, filtered = _finalize_thread(snaps, config)

        assert final[0].id == "1"
        assert final[1].id == "2"
        assert final[2].id == "3"

    def test_token_budget_enforcement(self):
        """Finalization enforces token budget."""
        snaps = [
            make_snapshot("1", token_count=3000),
            make_snapshot("2", token_count=3000),
            make_snapshot("3", token_count=3000),
        ]
        config = ThreadRetrievalConfig(max_tokens=5000)

        final, total_tokens, filtered = _finalize_thread(snaps, config)

        # Should only fit 1-2 snapshots
        assert len(final) <= 2
        assert total_tokens <= 5000
        assert filtered >= 1

    def test_snapshot_count_enforcement(self):
        """Finalization enforces max_snapshots."""
        snaps = [make_snapshot(str(i)) for i in range(20)]
        config = ThreadRetrievalConfig(max_snapshots=5, max_tokens=100000)

        final, tokens, filtered = _finalize_thread(snaps, config)

        assert len(final) == 5
        assert filtered == 15


class TestTokenEstimation:
    """Tests for token estimation."""

    def test_estimate_from_metadata(self):
        """Uses metadata token_count when available."""
        snap = make_snapshot("1", token_count=1234)
        assert _estimate_tokens(snap) == 1234

    def test_estimate_from_content(self):
        """Estimates tokens from content when no metadata."""
        snap = make_snapshot("1", content="Hello world")  # ~11 chars
        tokens = _estimate_tokens(snap)
        # Should be roughly content_length / 4
        assert 1 <= tokens <= 20


# ─────────────────────────────────────────────────────────────────────────────
# Integration Tests
# ─────────────────────────────────────────────────────────────────────────────


class TestRetrieveConversationThread:
    """Integration tests for the main entry point."""

    def test_basic_retrieval(self, mock_embedder):
        """Basic thread retrieval works end-to-end."""
        anchor = make_snapshot("1", score=0.9)
        backend = MockBackend(
            vector_results=[anchor],
            session_results=[anchor],
        )
        config = ThreadRetrievalConfig()

        thread = retrieve_conversation_thread(
            backend, "org_1", "test query", config=config, embedder=mock_embedder
        )

        assert not thread.is_empty
        assert thread.anchor is not None
        assert thread.anchor.id == "1"

    def test_empty_results(self, mock_embedder):
        """Returns empty thread when no results."""
        backend = MockBackend()
        config = ThreadRetrievalConfig()

        thread = retrieve_conversation_thread(
            backend, "org_1", "no results", config=config, embedder=mock_embedder
        )

        assert thread.is_empty
        assert thread.anchor is None

    def test_return_metrics(self, mock_embedder):
        """Returns metrics when requested."""
        anchor = make_snapshot("1", score=0.9)
        backend = MockBackend(
            vector_results=[anchor],
            session_results=[anchor],
        )
        config = ThreadRetrievalConfig()

        result = retrieve_conversation_thread(
            backend,
            "org_1",
            "test query",
            config=config,
            embedder=mock_embedder,
            return_metrics=True,
        )

        assert isinstance(result, tuple)
        thread, metrics = result
        assert isinstance(thread, ConversationThread)
        assert isinstance(metrics, ThreadRetrievalMetrics)
        assert metrics.anchors_considered >= 1
