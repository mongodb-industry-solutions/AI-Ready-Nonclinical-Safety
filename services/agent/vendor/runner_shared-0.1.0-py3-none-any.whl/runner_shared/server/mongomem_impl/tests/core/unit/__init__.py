"""Tests for mongomem_core."""
