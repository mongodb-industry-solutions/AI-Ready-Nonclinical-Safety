"""
Unit tests for token budgeting and memory selection logic.

These tests validate the Budgeter class behavior. Token counting utilities
(TokenCounter, resolve_model_name) are tested in test_token_counting.py.
"""

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

from mongomem_core.common.token_counting import TokenCounter
from mongomem_core.models.retrieval import (
    ContextConfig,
    MemoryChunk,
    MemorySource,
)
from mongomem_core.retrieval.budgeting import Budgeter


class TestBudgeterInitialization:
    """Tests for Budgeter initialization."""

    def test_default_initialization(self):
        """Budgeter initializes with default TokenCounter."""
        budgeter = Budgeter()
        assert budgeter._token_counter is not None
        assert isinstance(budgeter._token_counter, TokenCounter)

    def test_custom_token_counter(self):
        """Budgeter accepts custom TokenCounter instance."""
        custom_counter = TokenCounter()
        budgeter = Budgeter(token_counter=custom_counter)
        assert budgeter._token_counter is custom_counter

    def test_uses_shared_singleton_by_default(self):
        """Default initialization uses shared singleton for cache efficiency."""
        budgeter1 = Budgeter()
        budgeter2 = Budgeter()
        # Both should use the same shared singleton
        assert budgeter1._token_counter is budgeter2._token_counter


class TestSelectMemories:
    """Tests for select_memories method."""

    @patch.object(TokenCounter, "count")
    def test_basic_selection(self, mock_count):
        """Selects memories that fit within budget."""
        budgeter = Budgeter(token_counter=TokenCounter())
        config = ContextConfig(max_tokens=100, token_buffer=0)  # Use full budget

        # Mock token counts: 30, 40, 50 tokens
        mock_count.side_effect = [30, 40, 50]

        memories = [
            MemoryChunk(
                id="mem1",
                content="Memory 1",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
            MemoryChunk(
                id="mem2",
                content="Memory 2",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
            MemoryChunk(
                id="mem3",
                content="Memory 3",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
        ]

        result = budgeter.select_memories(memories, config)
        # Should select first two (30 + 40 = 70 <= 100)
        assert len(result) == 2
        assert result[0].id == "mem1"
        assert result[1].id == "mem2"

    @patch.object(TokenCounter, "count")
    def test_budget_limit(self, mock_count):
        """Stops when adding next memory would exceed budget."""
        budgeter = Budgeter(token_counter=TokenCounter())
        config = ContextConfig(max_tokens=50, token_buffer=0)

        # Mock token counts: 20, 30, 10 tokens
        mock_count.side_effect = [20, 30, 10]

        memories = [
            MemoryChunk(
                id="mem1",
                content="Memory 1",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
            MemoryChunk(
                id="mem2",
                content="Memory 2",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
            MemoryChunk(
                id="mem3",
                content="Memory 3",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
        ]

        result = budgeter.select_memories(memories, config)
        # Should select first two (20 + 30 = 50 <= 50)
        # Third memory (10 tokens) would exceed budget (50 + 10 = 60 > 50)
        assert len(result) == 2
        assert result[0].id == "mem1"
        assert result[1].id == "mem2"

    def test_empty_memories(self):
        """Returns empty list when no memories provided."""
        budgeter = Budgeter()
        config = ContextConfig(max_tokens=100, token_buffer=0)

        result = budgeter.select_memories([], config)
        assert result == []

    @patch.object(TokenCounter, "count")
    def test_invalid_max_tokens(self, mock_count):
        """Defaults to 16000 when max_tokens <= 0."""
        budgeter = Budgeter(token_counter=TokenCounter())
        # Create config with valid max_tokens first, then modify it to test invalid case
        config = ContextConfig(max_tokens=1)  # Valid minimum
        # Manually set to invalid value to test the warning path
        config.max_tokens = 0  # Invalid, will trigger default

        mock_count.return_value = 100

        memories = [
            MemoryChunk(
                id="mem1",
                content="Memory 1",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
        ]

        result = budgeter.select_memories(memories, config)
        # Should use default 16000, so memory fits
        assert len(result) == 1
        assert mock_count.call_count == 1

    @patch.object(TokenCounter, "count")
    def test_empty_content_skipped(self, mock_count):
        """Skips memories with empty or None content."""
        budgeter = Budgeter(token_counter=TokenCounter())
        config = ContextConfig(max_tokens=100, token_buffer=0)

        memories = [
            MemoryChunk(
                id="mem1",
                content="",  # Empty content
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
            MemoryChunk(
                id="mem2",
                content="Valid content",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
        ]

        mock_count.return_value = 50

        result = budgeter.select_memories(memories, config)
        # Should skip mem1, select mem2
        assert len(result) == 1
        assert result[0].id == "mem2"
        # Should not call count for empty content
        assert mock_count.call_count == 1

    @patch.object(TokenCounter, "count")
    def test_none_content_skipped(self, mock_count):
        """Skips memories with empty content (None not allowed by Pydantic, so test with empty string)."""
        budgeter = Budgeter(token_counter=TokenCounter())
        config = ContextConfig(max_tokens=100, token_buffer=0)

        memories = [
            MemoryChunk(
                id="mem1",
                content="",  # Empty content (None not allowed by Pydantic)
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
            MemoryChunk(
                id="mem2",
                content="Valid content",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
        ]

        mock_count.return_value = 50

        result = budgeter.select_memories(memories, config)
        # Should skip mem1, select mem2
        assert len(result) == 1
        assert result[0].id == "mem2"
        # Should not call count for empty content
        assert mock_count.call_count == 1

    @patch.object(TokenCounter, "count")
    def test_zero_tokens_skipped(self, mock_count):
        """Skips memories with zero token count."""
        budgeter = Budgeter(token_counter=TokenCounter())
        config = ContextConfig(max_tokens=100, token_buffer=0)

        memories = [
            MemoryChunk(
                id="mem1",
                content="Some content",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
            MemoryChunk(
                id="mem2",
                content="Valid content",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
        ]

        # First memory has 0 tokens, second has 50
        mock_count.side_effect = [0, 50]

        result = budgeter.select_memories(memories, config)
        # Should skip mem1 (0 tokens), select mem2
        assert len(result) == 1
        assert result[0].id == "mem2"

    @patch.object(TokenCounter, "count")
    def test_maintains_order(self, mock_count):
        """Maintains the order of memories (already sorted by ranker)."""
        budgeter = Budgeter(token_counter=TokenCounter())
        config = ContextConfig(max_tokens=200, token_buffer=0)

        mock_count.side_effect = [50, 30, 40]

        memories = [
            MemoryChunk(
                id="mem1",
                content="Memory 1",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
            MemoryChunk(
                id="mem2",
                content="Memory 2",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
            MemoryChunk(
                id="mem3",
                content="Memory 3",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
        ]

        result = budgeter.select_memories(memories, config)
        # All fit (50 + 30 + 40 = 120 <= 200)
        assert len(result) == 3
        # Order should be preserved
        assert result[0].id == "mem1"
        assert result[1].id == "mem2"
        assert result[2].id == "mem3"

    @patch.object(TokenCounter, "count")
    def test_all_memories_fit(self, mock_count):
        """Selects all memories when they all fit within budget."""
        budgeter = Budgeter(token_counter=TokenCounter())
        config = ContextConfig(max_tokens=500, token_buffer=0)

        mock_count.side_effect = [50, 30, 40, 20]

        memories = [
            MemoryChunk(
                id=f"mem{i}",
                content=f"Memory {i}",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            )
            for i in range(1, 5)
        ]

        result = budgeter.select_memories(memories, config)
        # All fit (50 + 30 + 40 + 20 = 140 <= 500)
        assert len(result) == 4

    @patch.object(TokenCounter, "count")
    def test_no_memories_fit(self, mock_count):
        """Returns empty list when no memories fit within budget."""
        budgeter = Budgeter(token_counter=TokenCounter())
        config = ContextConfig(max_tokens=10, token_buffer=0)

        mock_count.return_value = 50  # All memories exceed budget

        memories = [
            MemoryChunk(
                id="mem1",
                content="Memory 1",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
            MemoryChunk(
                id="mem2",
                content="Memory 2",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
        ]

        result = budgeter.select_memories(memories, config)
        # No memories fit (50 > 10)
        assert len(result) == 0

    @patch.object(TokenCounter, "count")
    def test_mixed_content_types(self, mock_count):
        """Handles mix of valid, empty, and zero-token memories."""
        budgeter = Budgeter(token_counter=TokenCounter())
        config = ContextConfig(max_tokens=200, token_buffer=0)

        # Token counts: 0 (skip), 50 (add), "" (skip), 30 (add), None (skip), 40 (add)
        mock_count.side_effect = [0, 50, 30, 40]

        memories = [
            MemoryChunk(
                id="mem1",
                content="Some content",  # 0 tokens (skip)
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
            MemoryChunk(
                id="mem2",
                content="Valid content 1",  # 50 tokens (add)
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
            MemoryChunk(
                id="mem3",
                content="",  # Empty (skip)
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
            MemoryChunk(
                id="mem4",
                content="Valid content 2",  # 30 tokens (add)
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
            MemoryChunk(
                id="mem5",
                content="",  # Empty (skip) - None not allowed by Pydantic
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
            MemoryChunk(
                id="mem6",
                content="Valid content 3",  # 40 tokens (add)
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
        ]

        result = budgeter.select_memories(memories, config)
        # Should select mem2, mem4, mem6 (50 + 30 + 40 = 120 <= 200)
        assert len(result) == 3
        assert result[0].id == "mem2"
        assert result[1].id == "mem4"
        assert result[2].id == "mem6"
        # count is called for mem1 (0 tokens, then skipped), mem2, mem4, mem6
        # mem3 and mem5 are skipped immediately (empty content) without calling count
        assert mock_count.call_count == 4

    @patch.object(TokenCounter, "count")
    def test_uses_llm_for_model_name(self, mock_count):
        """Passes LLM to resolve_model_name for model resolution."""
        budgeter = Budgeter(token_counter=TokenCounter())
        config = ContextConfig(max_tokens=100, token_buffer=0)

        mock_llm = MagicMock()
        mock_llm.model_id = "custom-model"

        mock_count.return_value = 10

        memories = [
            MemoryChunk(
                id="mem1",
                content="Memory 1",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
        ]

        with patch("mongomem_core.retrieval.budgeting.resolve_model_name") as mock_resolve:
            mock_resolve.return_value = "custom-model"
            budgeter.select_memories(memories, config, llm=mock_llm)
            mock_resolve.assert_called_once_with(mock_llm, config)

    @patch.object(TokenCounter, "count")
    def test_token_buffer_applied(self, mock_count):
        """Token buffer reserves tokens for formatting overhead."""
        budgeter = Budgeter(token_counter=TokenCounter())
        # max_tokens=100, token_buffer=30, so available_tokens=70
        config = ContextConfig(max_tokens=100, token_buffer=30)

        # Mock token counts: 40, 40 tokens
        mock_count.side_effect = [40, 40]

        memories = [
            MemoryChunk(
                id="mem1",
                content="Memory 1",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
            MemoryChunk(
                id="mem2",
                content="Memory 2",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
        ]

        result = budgeter.select_memories(memories, config)
        # Should select only first memory (40 <= 70)
        # Second memory would exceed available budget (40 + 40 = 80 > 70)
        assert len(result) == 1
        assert result[0].id == "mem1"

    @patch.object(TokenCounter, "count")
    def test_token_buffer_exceeds_max_tokens(self, mock_count):
        """Returns empty list when token buffer exceeds max_tokens."""
        budgeter = Budgeter(token_counter=TokenCounter())
        # max_tokens=50, token_buffer=100, so available_tokens=-50 (invalid)
        config = ContextConfig(max_tokens=50, token_buffer=100)

        mock_count.return_value = 10

        memories = [
            MemoryChunk(
                id="mem1",
                content="Memory 1",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            ),
        ]

        result = budgeter.select_memories(memories, config)
        # Should return empty list (no available tokens)
        assert result == []

    @patch.object(TokenCounter, "count")
    def test_default_token_buffer(self, mock_count):
        """Default token buffer reserves space for formatting."""
        budgeter = Budgeter(token_counter=TokenCounter())
        # Default: token_buffer=500
        # max_tokens=2000, so available=1500
        config = ContextConfig(max_tokens=2000)  # Uses default token_buffer=500

        # Mock token counts: 400, 400, 400, 400 tokens
        mock_count.side_effect = [400, 400, 400, 400]

        memories = [
            MemoryChunk(
                id=f"mem{i}",
                content=f"Memory {i}",
                source=MemorySource.EPISODIC,
                timestamp=datetime.now(timezone.utc),
            )
            for i in range(1, 5)
        ]

        result = budgeter.select_memories(memories, config)
        # available_tokens = 2000 - 500 = 1500
        # First: 400 <= 1500, add (total=400)
        # Second: 800 <= 1500, add (total=800)
        # Third: 1200 <= 1500, add (total=1200)
        # Fourth: 1600 > 1500, skip
        assert len(result) == 3
        assert result[0].id == "mem1"
        assert result[1].id == "mem2"
        assert result[2].id == "mem3"
