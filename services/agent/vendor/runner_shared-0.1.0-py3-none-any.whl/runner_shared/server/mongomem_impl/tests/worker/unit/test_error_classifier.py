from runner_shared.server.mongomem_impl.src.mongomem_worker.errors import (
    ConfigurationError,
    DatabaseError,
    DocumentMissingError,
    EmbeddingError,
    ErrorTaxonomy,
    ErrorType,
    HandlerNotFoundError,
    InvalidPayloadError,
    LeaseExpiredError,
    LLMError,
    RateLimitError,
    WorkerErrorSeverity,
    classify_error,
    classify_exception,
    get_error_taxonomy,
    get_retry_delay,
    should_retry,
    wrap_handler_error,
)
from runner_shared.server.mongomem_impl.src.mongomem_worker.errors import (
    TimeoutError as WorkerTimeoutError,
)


class TestClassifyError:
    """Tests for error classification logic."""

    def test_validation_error_is_permanent(self):
        error_type = classify_error("ValidationError: field 'name' is required")
        assert error_type == ErrorType.PERMANENT

    def test_not_found_error_is_permanent(self):
        error_type = classify_error("Document not found: stm:12345")
        assert error_type == ErrorType.PERMANENT

    def test_timeout_error_is_transient(self):
        error_type = classify_error("Connection timeout after 30s")
        assert error_type == ErrorType.TRANSIENT

    def test_rate_limit_error_is_transient(self):
        error_type = classify_error("Rate limit exceeded, retry after 60s")
        assert error_type == ErrorType.TRANSIENT

    def test_connection_error_is_transient(self):
        error_type = classify_error("Connection refused: mongodb://localhost:27017")
        assert error_type == ErrorType.TRANSIENT

    def test_network_error_is_transient(self):
        error_type = classify_error("Network unreachable")
        assert error_type == ErrorType.TRANSIENT

    def test_unknown_error_is_unknown(self):
        error_type = classify_error("Something weird happened")
        assert error_type == ErrorType.UNKNOWN

    def test_duplicate_key_is_permanent(self):
        error_type = classify_error("E11000 duplicate key error collection: db.tasks")
        assert error_type == ErrorType.PERMANENT

    def test_case_insensitive(self):
        assert classify_error("TIMEOUT ERROR") == ErrorType.TRANSIENT
        assert classify_error("validation error") == ErrorType.PERMANENT


class TestClassifyTypedExceptions:
    """Tests for typed exception classification."""

    def test_embedding_error_is_transient(self):
        exc = EmbeddingError("API failed", model_id="voyage-3")
        assert classify_error(exc) == ErrorType.TRANSIENT

    def test_llm_error_is_transient(self):
        exc = LLMError("Model overloaded", model_id="claude-3")
        assert classify_error(exc) == ErrorType.TRANSIENT

    def test_rate_limit_error_is_transient(self):
        exc = RateLimitError("Too many requests", retry_after=60.0)
        assert classify_error(exc) == ErrorType.TRANSIENT

    def test_timeout_error_is_transient(self):
        exc = WorkerTimeoutError("Task exceeded 30s", timeout_seconds=30.0)
        assert classify_error(exc) == ErrorType.TRANSIENT

    def test_database_error_is_transient(self):
        exc = DatabaseError("Connection lost", operation="insert")
        assert classify_error(exc) == ErrorType.TRANSIENT

    def test_lease_expired_is_transient(self):
        exc = LeaseExpiredError("Lease expired, task may be reclaimed")
        assert classify_error(exc) == ErrorType.TRANSIENT

    def test_configuration_error_is_permanent(self):
        exc = ConfigurationError("Invalid mongo_uri")
        assert classify_error(exc) == ErrorType.PERMANENT

    def test_handler_not_found_is_permanent(self):
        exc = HandlerNotFoundError("No handler for task type: unknown")
        assert classify_error(exc) == ErrorType.PERMANENT

    def test_invalid_payload_is_permanent(self):
        exc = InvalidPayloadError("Missing field: session_id")
        assert classify_error(exc) == ErrorType.PERMANENT

    def test_document_missing_is_permanent(self):
        exc = DocumentMissingError("STM not found", document_id="stm:123")
        assert classify_error(exc) == ErrorType.PERMANENT

    def test_python_value_error_is_permanent(self):
        exc = ValueError("invalid literal")
        assert classify_error(exc) == ErrorType.PERMANENT

    def test_python_type_error_is_permanent(self):
        exc = TypeError("expected str, got int")
        assert classify_error(exc) == ErrorType.PERMANENT

    def test_python_connection_error_is_transient(self):
        exc = ConnectionError("refused")
        assert classify_error(exc) == ErrorType.TRANSIENT


class TestGetErrorTaxonomy:
    """Tests for error taxonomy classification."""

    def test_validation_taxonomy(self):
        taxonomy = get_error_taxonomy("ValidationError: invalid input")
        assert taxonomy == ErrorTaxonomy.VALIDATION

    def test_timeout_taxonomy(self):
        taxonomy = get_error_taxonomy("Request timeout after 30s")
        assert taxonomy == ErrorTaxonomy.TIMEOUT

    def test_rate_limit_taxonomy(self):
        taxonomy = get_error_taxonomy("429 Too Many Requests")
        assert taxonomy == ErrorTaxonomy.RATE_LIMIT

    def test_connection_taxonomy(self):
        taxonomy = get_error_taxonomy("ConnectionError: host unreachable")
        assert taxonomy == ErrorTaxonomy.CONNECTION

    def test_embedding_taxonomy(self):
        taxonomy = get_error_taxonomy("Embedding API error: quota exceeded")
        assert taxonomy == ErrorTaxonomy.EMBEDDING

    def test_llm_taxonomy(self):
        taxonomy = get_error_taxonomy("LLM error: model overloaded")
        assert taxonomy == ErrorTaxonomy.LLM

    def test_database_taxonomy(self):
        taxonomy = get_error_taxonomy("pymongo.errors.DuplicateKeyError: E11000")
        assert taxonomy == ErrorTaxonomy.DATABASE

    def test_unknown_taxonomy(self):
        taxonomy = get_error_taxonomy("Some random error")
        assert taxonomy == ErrorTaxonomy.UNKNOWN


class TestGetErrorTaxonomyTyped:
    """Tests for typed exception taxonomy."""

    def test_embedding_error_taxonomy(self):
        exc = EmbeddingError("API failed")
        assert get_error_taxonomy(exc) == ErrorTaxonomy.EMBEDDING

    def test_llm_error_taxonomy(self):
        exc = LLMError("Model failed")
        assert get_error_taxonomy(exc) == ErrorTaxonomy.LLM

    def test_rate_limit_taxonomy(self):
        exc = RateLimitError("Too many requests")
        assert get_error_taxonomy(exc) == ErrorTaxonomy.RATE_LIMIT

    def test_timeout_taxonomy(self):
        exc = WorkerTimeoutError("Timed out")
        assert get_error_taxonomy(exc) == ErrorTaxonomy.TIMEOUT

    def test_database_error_taxonomy(self):
        exc = DatabaseError("Connection lost")
        assert get_error_taxonomy(exc) == ErrorTaxonomy.DATABASE

    def test_lease_expired_taxonomy(self):
        exc = LeaseExpiredError("Lease lost")
        assert get_error_taxonomy(exc) == ErrorTaxonomy.LEASE_EXPIRED

    def test_configuration_error_taxonomy(self):
        exc = ConfigurationError("Bad config")
        assert get_error_taxonomy(exc) == ErrorTaxonomy.CONFIG

    def test_handler_not_found_taxonomy(self):
        exc = HandlerNotFoundError("No handler")
        assert get_error_taxonomy(exc) == ErrorTaxonomy.NO_HANDLER

    def test_invalid_payload_taxonomy(self):
        exc = InvalidPayloadError("Bad payload")
        assert get_error_taxonomy(exc) == ErrorTaxonomy.VALIDATION

    def test_document_missing_taxonomy(self):
        exc = DocumentMissingError("Not found")
        assert get_error_taxonomy(exc) == ErrorTaxonomy.NOT_FOUND


class TestShouldRetry:
    """Tests for retry decision logic."""

    def test_permanent_error_no_retry(self):
        # Validation error is permanent - should not retry
        assert should_retry("ValidationError: field missing", attempts=1, max_retries=3) is False

    def test_transient_error_retry_if_attempts_left(self):
        assert should_retry("Connection timeout", attempts=1, max_retries=3) is True
        assert should_retry("Connection timeout", attempts=2, max_retries=3) is True

    def test_transient_error_no_retry_if_exhausted(self):
        assert should_retry("Connection timeout", attempts=3, max_retries=3) is False
        assert should_retry("Connection timeout", attempts=4, max_retries=3) is False

    def test_unknown_error_retry_conservatively(self):
        # Unknown errors should retry but with caution
        assert should_retry("Something weird happened", attempts=1, max_retries=3) is True

    def test_zero_max_retries(self):
        assert should_retry("Connection timeout", attempts=1, max_retries=0) is False


class TestGetRetryDelay:
    """Tests for retry delay calculation."""

    def test_exponential_backoff(self):
        error = "Connection timeout"
        delay0 = get_retry_delay(error, attempts=0, jitter=0.0)
        delay1 = get_retry_delay(error, attempts=1, jitter=0.0)
        delay2 = get_retry_delay(error, attempts=2, jitter=0.0)

        # Delays should double each attempt (no jitter)
        assert delay0 == 2.0  # base_delay * 2^0 = 2.0
        assert delay1 == 4.0  # base_delay * 2^1 = 4.0
        assert delay2 == 8.0  # base_delay * 2^2 = 8.0

    def test_first_retry_uses_base_delay(self):
        error = "Connection timeout"
        delay = get_retry_delay(error, attempts=0, base_delay=5.0, jitter=0.0)
        assert delay == 5.0  # First retry should use full base_delay

    def test_base_delay(self):
        error = "Connection timeout"
        delay = get_retry_delay(error, attempts=0, base_delay=10.0)
        # With jitter, delay is between base_delay and base_delay * (1 + jitter)
        assert delay >= 10.0

    def test_max_delay_cap(self):
        error = "Connection timeout"
        # Even with many attempts, delay should not exceed max (plus jitter)
        delay = get_retry_delay(error, attempts=10, max_delay=300.0)
        # With 50% jitter, max is 300 * 1.5 = 450
        assert delay <= 450.0

    def test_jitter_adds_randomness(self):
        error = "Connection timeout"
        # With jitter, repeated calls should give different values
        delays = [get_retry_delay(error, attempts=2, jitter=0.5) for _ in range(10)]
        unique_delays = set(delays)
        # With jitter, we expect some variation
        assert len(unique_delays) > 1


class TestClassifyException:
    """Tests for classify_exception utility."""

    def test_worker_error_uses_severity(self):
        exc = EmbeddingError("Failed")
        assert classify_exception(exc) == WorkerErrorSeverity.TRANSIENT

        exc = InvalidPayloadError("Bad data")
        assert classify_exception(exc) == WorkerErrorSeverity.PERMANENT

    def test_python_builtin_classification(self):
        assert classify_exception(ValueError("bad")) == WorkerErrorSeverity.PERMANENT
        assert classify_exception(TypeError("wrong type")) == WorkerErrorSeverity.PERMANENT
        assert classify_exception(KeyError("missing")) == WorkerErrorSeverity.PERMANENT
        assert classify_exception(ConnectionError("refused")) == WorkerErrorSeverity.TRANSIENT

    def test_timeout_classification(self):
        import asyncio

        assert classify_exception(asyncio.TimeoutError()) == WorkerErrorSeverity.TRANSIENT

    def test_unknown_exception_fallback(self):
        class CustomError(Exception):
            pass

        # Unknown exception with no pattern match -> UNKNOWN
        assert classify_exception(CustomError("weird")) == WorkerErrorSeverity.UNKNOWN

        # Unknown exception with pattern match -> appropriate severity
        assert classify_exception(CustomError("timeout occurred")) == WorkerErrorSeverity.TRANSIENT
        assert classify_exception(CustomError("validation failed")) == WorkerErrorSeverity.PERMANENT


class TestWrapHandlerError:
    """Tests for wrap_handler_error utility."""

    def test_wrap_adds_task_context(self):
        exc = ValueError("bad input")
        wrapped = wrap_handler_error(exc, task_type="embedding", task_id="task:123")

        assert wrapped.task_type == "embedding"
        assert wrapped.task_id == "task:123"
        assert "bad input" in str(wrapped)

    def test_wrap_preserves_worker_error(self):
        original = EmbeddingError("API failed", model_id="voyage-3")
        wrapped = wrap_handler_error(original, task_type="embedding", task_id="task:123")

        # Should be the same object, just with added context
        assert wrapped is original
        assert wrapped.task_type == "embedding"
        assert wrapped.task_id == "task:123"

    def test_wrap_with_context_message(self):
        exc = RuntimeError("something broke")
        wrapped = wrap_handler_error(
            exc,
            task_type="entity",
            context="Entity extraction",
        )

        assert "Entity extraction" in str(wrapped)
        assert "something broke" in str(wrapped)

    def test_wrap_permanent_error_type(self):
        exc = ValueError("invalid data")
        wrapped = wrap_handler_error(exc, task_type="embedding")

        assert wrapped.severity == WorkerErrorSeverity.PERMANENT

    def test_wrap_transient_error_type(self):
        exc = ConnectionError("refused")
        wrapped = wrap_handler_error(exc, task_type="embedding")

        assert wrapped.severity == WorkerErrorSeverity.TRANSIENT
