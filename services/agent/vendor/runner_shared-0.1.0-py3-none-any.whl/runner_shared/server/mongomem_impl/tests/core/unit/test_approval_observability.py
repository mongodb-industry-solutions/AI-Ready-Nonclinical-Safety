"""Tests for approval workflow observability (Phase 5)."""

from __future__ import annotations

from mongomem_core.extraction.approval import (
    ApprovalOrchestrator,
    PendingDecisionPayload,
    PendingStore,
)
from mongomem_core.observability import CoreObservability


class TestPendingStoreObservability:
    """Tests for PendingStore observability integration."""

    def test_accepts_metrics_parameter(self, test_db, recording_obs):
        """PendingStore accepts metrics parameter."""
        metrics = CoreObservability(backend=recording_obs)
        store = PendingStore(test_db, obs=metrics)
        assert store._obs is metrics

    def test_defaults_to_noop_metrics(self, test_db):
        """PendingStore uses NoOp metrics when not provided."""
        store = PendingStore(test_db)
        assert store._obs is not None

    def test_stage_emits_staged_event(self, test_db, recording_obs):
        """Staging an extraction emits staging metrics and event."""
        metrics = CoreObservability(backend=recording_obs)
        store = PendingStore(test_db, obs=metrics)

        payload = PendingDecisionPayload(
            action="ADD",
            content="Test content",
            confidence=0.9,
        )
        store.stage(
            org_id="org-1",
            user_id="user-1",
            source_id="source-123",
            extraction_type="semantic",
            payload=payload,
        )

        # Check increment
        staged_increments = recording_obs.get_increments("mongomem.approval.staged")
        assert len(staged_increments) == 1
        assert staged_increments[0]["tags"]["extraction_type"] == "semantic"
        assert staged_increments[0]["tags"]["action"] == "ADD"

        # Check event
        staged_events = recording_obs.get_events("mongomem.approval.staged")
        assert len(staged_events) == 1
        assert staged_events[0]["attributes"]["extraction_type"] == "semantic"
        assert staged_events[0]["attributes"]["action"] == "ADD"
        assert staged_events[0]["attributes"]["source_id"] == "source-123"

    def test_stage_batch_emits_staged_events(self, test_db, recording_obs):
        """Staging multiple extractions emits staging metrics for each."""
        metrics = CoreObservability(backend=recording_obs)
        store = PendingStore(test_db, obs=metrics)

        items = [
            (
                "semantic",
                PendingDecisionPayload(action="ADD", content="Content 1", confidence=0.9),
            ),
            (
                "semantic",
                PendingDecisionPayload(
                    action="UPDATE",
                    content="Content 2",
                    confidence=0.8,
                    existing_id="existing-1",
                ),
            ),
        ]

        store.stage_batch(
            items=items,
            org_id="org-1",
            user_id="user-1",
            source_id="source-456",
        )

        # Check increments
        staged_increments = recording_obs.get_increments("mongomem.approval.staged")
        assert len(staged_increments) == 2

        # Check events
        staged_events = recording_obs.get_events("mongomem.approval.staged")
        assert len(staged_events) == 2
        actions = [e["attributes"]["action"] for e in staged_events]
        assert "ADD" in actions
        assert "UPDATE" in actions

    def test_mark_approved_emits_metrics(self, test_db, recording_obs):
        """Approving an extraction emits approval metrics with queue time."""
        metrics = CoreObservability(backend=recording_obs)
        store = PendingStore(test_db, obs=metrics)

        # Stage an item first
        payload = PendingDecisionPayload(
            action="ADD",
            content="Test content",
            confidence=0.9,
        )
        pending_id = store.stage(
            org_id="org-1",
            user_id="user-1",
            source_id="source-789",
            extraction_type="semantic",
            payload=payload,
        )

        recording_obs.clear()

        # Approve the item
        result = store.mark_approved(pending_id, "memory-abc", reviewed_by="admin")

        assert result is True

        # Check increment
        approved_increments = recording_obs.get_increments("mongomem.approval.approved")
        assert len(approved_increments) == 1

        # Check queue time histogram
        queue_times = recording_obs.get_histograms("mongomem.approval.queue_time")
        assert len(queue_times) == 1
        assert queue_times[0]["value"] >= 0  # Queue time should be non-negative

        # Check event
        approved_events = recording_obs.get_events("mongomem.approval.approved")
        assert len(approved_events) == 1
        assert approved_events[0]["attributes"]["memory_id"] == "memory-abc"
        assert approved_events[0]["attributes"]["approved_by"] == "admin"
        assert approved_events[0]["attributes"]["queue_time_ms"] >= 0

    def test_mark_rejected_emits_metrics(self, test_db, recording_obs):
        """Rejecting an extraction emits rejection metrics."""
        metrics = CoreObservability(backend=recording_obs)
        store = PendingStore(test_db, obs=metrics)

        # Stage an item first
        payload = PendingDecisionPayload(
            action="ADD",
            content="Test content",
            confidence=0.9,
        )
        pending_id = store.stage(
            org_id="org-1",
            user_id="user-1",
            source_id="source-000",
            extraction_type="semantic",
            payload=payload,
        )

        recording_obs.clear()

        # Reject the item
        result = store.mark_rejected(pending_id, reason="Low quality", reviewed_by="moderator")

        assert result is True

        # Check increment
        rejected_increments = recording_obs.get_increments("mongomem.approval.rejected")
        assert len(rejected_increments) == 1

        # Check event
        rejected_events = recording_obs.get_events("mongomem.approval.rejected")
        assert len(rejected_events) == 1
        assert rejected_events[0]["attributes"]["pending_id"] == pending_id
        assert rejected_events[0]["attributes"]["rejection_reason"] == "Low quality"
        assert rejected_events[0]["attributes"]["reviewed_by"] == "moderator"

    def test_approve_nonexistent_does_not_emit(self, test_db, recording_obs):
        """Approving a non-existent item doesn't emit metrics."""
        metrics = CoreObservability(backend=recording_obs)
        store = PendingStore(test_db, obs=metrics)

        result = store.mark_approved("000000000000000000000000", "memory-xyz")

        assert result is False
        assert len(recording_obs.get_increments("mongomem.approval.approved")) == 0
        assert len(recording_obs.get_events("mongomem.approval.approved")) == 0

    def test_reject_nonexistent_does_not_emit(self, test_db, recording_obs):
        """Rejecting a non-existent item doesn't emit metrics."""
        metrics = CoreObservability(backend=recording_obs)
        store = PendingStore(test_db, obs=metrics)

        result = store.mark_rejected("000000000000000000000000")

        assert result is False
        assert len(recording_obs.get_increments("mongomem.approval.rejected")) == 0
        assert len(recording_obs.get_events("mongomem.approval.rejected")) == 0


class TestApprovalOrchestratorObservability:
    """Tests for ApprovalOrchestrator observability integration."""

    def test_accepts_metrics_parameter(self, test_db, recording_obs):
        """ApprovalOrchestrator accepts metrics parameter."""
        metrics = CoreObservability(backend=recording_obs)
        orchestrator = ApprovalOrchestrator(test_db, obs=metrics)
        assert orchestrator._store._obs is metrics

    def test_defaults_to_noop_metrics(self, test_db):
        """ApprovalOrchestrator uses NoOp metrics when not provided."""
        orchestrator = ApprovalOrchestrator(test_db)
        assert orchestrator._store._obs is not None


class TestCoreObservabilityApprovalMethods:
    """Tests for CoreObservability approval helper methods."""

    def test_approval_staged_emits_counter_and_event(self, recording_obs, core_metrics):
        """approval_staged emits both counter and event."""
        core_metrics.approval_staged("semantic", "ADD", "source-123")

        # Check counter
        increments = recording_obs.get_increments("mongomem.approval.staged")
        assert len(increments) == 1
        assert increments[0]["tags"]["extraction_type"] == "semantic"
        assert increments[0]["tags"]["action"] == "ADD"

        # Check event
        events = recording_obs.get_events("mongomem.approval.staged")
        assert len(events) == 1
        assert events[0]["attributes"]["extraction_type"] == "semantic"
        assert events[0]["attributes"]["action"] == "ADD"
        assert events[0]["attributes"]["source_id"] == "source-123"

    def test_approval_approved_emits_counter_histogram_and_event(self, recording_obs, core_metrics):
        """approval_approved emits counter, histogram, and event."""
        core_metrics.approval_approved("mem-123", 5000.0, "admin")

        # Check counter
        increments = recording_obs.get_increments("mongomem.approval.approved")
        assert len(increments) == 1

        # Check histogram
        histograms = recording_obs.get_histograms("mongomem.approval.queue_time")
        assert len(histograms) == 1
        assert histograms[0]["value"] == 5000.0

        # Check event
        events = recording_obs.get_events("mongomem.approval.approved")
        assert len(events) == 1
        assert events[0]["attributes"]["memory_id"] == "mem-123"
        assert events[0]["attributes"]["queue_time_ms"] == 5000.0
        assert events[0]["attributes"]["approved_by"] == "admin"

    def test_approval_rejected_emits_counter_and_event(self, recording_obs, core_metrics):
        """approval_rejected emits counter and event."""
        core_metrics.approval_rejected("pending-456", "Low confidence", "moderator")

        # Check counter
        increments = recording_obs.get_increments("mongomem.approval.rejected")
        assert len(increments) == 1

        # Check event
        events = recording_obs.get_events("mongomem.approval.rejected")
        assert len(events) == 1
        assert events[0]["attributes"]["pending_id"] == "pending-456"
        assert events[0]["attributes"]["rejection_reason"] == "Low confidence"
        assert events[0]["attributes"]["reviewed_by"] == "moderator"
