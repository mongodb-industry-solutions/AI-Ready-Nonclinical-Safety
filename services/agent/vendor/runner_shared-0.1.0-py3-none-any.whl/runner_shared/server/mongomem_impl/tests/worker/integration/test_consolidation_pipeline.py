"""
Integration tests for the OE-driven STM→Snapshot→[Semantic, Episodic] consolidation pipeline.

These tests exercise the full pipeline end-to-end against a real MongoDB instance:
  1. STM docs seeded for a session
  2. check_promotion task enqueued (as OE would do)
  3. _process_batch() called in a drain loop (mirroring POST /api/v1/worker/processTasks)
  4. Assertions on DB state: snapshot created, semantic + episodic memories written

Requirements:
  - Local MongoDB at TEST_MONGO_URI (default: mongodb://localhost:27017)
  - No real LLM or embedder needed — MockLLM and MockEmbedder are used
"""

from __future__ import annotations

import asyncio
import os

import pytest
from mongomem_core import MemoryEngine
from mongomem_core.config import Settings
from mongomem_core.models.config.snapshot_config import (
    SnapshotConfig,
)
from pymongo import MongoClient

from runner_shared.server.mongomem_impl.src.mongomem_worker.config import WorkerSettings
from runner_shared.server.mongomem_impl.src.mongomem_worker.queue import enqueue_task

from ..conftest import MockEmbedder, MockLLM, random_db_name

TEST_MONGO_URI = os.environ.get("TEST_MONGO_URI", "mongodb://localhost:27017")

_MAX_DRAIN = 50


def _make_engine(db_name: str, embedder: MockEmbedder, llm: MockLLM) -> MemoryEngine:
    settings = Settings(
        mongo_uri=TEST_MONGO_URI,
        db_name=db_name,
        embedding_dimension=embedder.dimension,
    )
    return MemoryEngine(settings, embedder=embedder, llm=llm)


def _make_worker(engine: MemoryEngine, llm: MockLLM, snapshot_config: SnapshotConfig | None = None):
    import os

    from runner_shared.server.mongomem_impl.src.mongomem_worker.worker import MongoMemWorker

    # Disable change streams — required by initialize() for on-demand mode
    os.environ["MONGOMEM_WORKER_ENABLE_CHANGE_STREAMS"] = "false"

    return MongoMemWorker(
        engine=engine,
        scaling_mode="distributed",
        auto_extract_on_snapshot=True,
        snapshot_config=snapshot_config
        or SnapshotConfig(
            strategy="auto",
            embedding_strategy="generate",
            max_messages=5,  # low threshold so test doesn't need many docs
            delete_promoted=False,  # mark as promoted, do not delete
        ),
        extraction_config={
            "semantic": {"enabled": True},
            "episodic": {"enabled": True},
        },
    )


async def _drain(worker, max_iterations: int = _MAX_DRAIN) -> int:
    """Drain the task queue synchronously — mirrors the /worker/process endpoint."""
    total = 0
    for _ in range(max_iterations):
        processed = await worker.process_batch()
        if processed == 0:
            break
        total += processed
    return total


class TestOEPipelineEndToEnd:
    """Full pipeline: check_promotion → snapshot → semantic + episodic."""

    def setup_method(self):
        self.db_name = random_db_name()
        self.client = MongoClient(TEST_MONGO_URI)
        self.db = self.client[self.db_name]

    def teardown_method(self):
        self.client.drop_database(self.db_name)
        self.client.close()

    def _seed_stm(self, session_id: str, org_id: str, user_id: str, n: int = 6):
        """Insert n STM docs for the given session — enough to exceed max_messages=5."""
        from datetime import datetime, timezone

        from bson import ObjectId

        docs = []
        for i in range(n):
            role = "user" if i % 2 == 0 else "assistant"
            docs.append(
                {
                    "_id": ObjectId(),
                    "session_id": session_id,
                    "org_id": org_id,
                    "user_id": user_id,
                    "role": role,
                    "content": f"Message {i}: user prefers Python and works at MongoDB.",
                    "visibility": "private",
                    "promoted": False,
                    "turn_seq": i,
                    "timestamp": datetime.now(timezone.utc),
                }
            )
        self.db.memory_short_term.insert_many(docs)
        return docs

    @pytest.mark.asyncio
    async def test_stm_promoted_to_snapshot(self):
        """After drain: snapshot exists, STM docs deleted."""
        session_id = "test-session-001"
        org_id = "test-org"
        user_id = "test-user"

        embedder = MockEmbedder()
        llm = MockLLM()
        # Semantic extractor expects {"memories": [...]}
        llm.set_json_response("", {"memories": [], "events": []})

        self._seed_stm(session_id, org_id, user_id, n=6)

        engine = _make_engine(self.db_name, embedder, llm)
        engine.bootstrap(ensure_search_indexes=False)

        worker = _make_worker(engine, llm)
        worker.initialize()

        # Enqueue check_promotion as OE would
        settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=self.db_name)
        enqueue_task(
            "snapshot",
            {
                "snapshot_task_type": "check_promotion",
                "session_id": session_id,
                "org_id": org_id,
                "user_id": user_id,
            },
            settings=settings,
        )

        total = await _drain(worker)

        # At minimum the check_promotion task ran
        assert total >= 1

        # Snapshot was created
        snapshot = self.db.memory_snapshot.find_one({"session_id": session_id, "org_id": org_id})
        assert snapshot is not None, "Snapshot should have been created"
        assert len(snapshot.get("messages", [])) > 0

        # Snapshot has an embedding (generate strategy uses MockEmbedder)
        assert snapshot.get("has_embedding") is True
        assert snapshot.get("embedding") is not None

        # STM docs are marked promoted=True (not deleted)
        unpromoted = self.db.memory_short_term.count_documents(
            {"session_id": session_id, "org_id": org_id, "promoted": {"$ne": True}}
        )
        assert unpromoted == 0, "All STM docs should be marked promoted"

        promoted = self.db.memory_short_term.count_documents(
            {"session_id": session_id, "org_id": org_id, "promoted": True}
        )
        assert promoted > 0, "STM docs should still exist with promoted=True"

    @pytest.mark.asyncio
    async def test_extraction_tasks_enqueued_and_processed(self):
        """After drain: semantic + episodic extraction tasks ran."""
        session_id = "test-session-002"
        org_id = "test-org"
        user_id = "test-user"

        embedder = MockEmbedder()
        llm = MockLLM()
        # Return valid extraction responses
        llm.set_json_response(
            "",
            {
                "memories": [
                    {"content": "User prefers Python", "citations": [0], "confidence_score": 0.9}
                ],
                "events": [
                    {
                        "title": "User discussed Python preferences",
                        "description": "User expressed preference for Python",
                        "timestamp": None,
                        "participants": [],
                        "location": None,
                        "significance": "medium",
                        "confidence_score": 0.8,
                    }
                ],
            },
        )

        self._seed_stm(session_id, org_id, user_id, n=6)

        engine = _make_engine(self.db_name, embedder, llm)
        engine.bootstrap(ensure_search_indexes=False)

        worker = _make_worker(engine, llm)
        worker.initialize()

        settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=self.db_name)
        enqueue_task(
            "snapshot",
            {
                "snapshot_task_type": "check_promotion",
                "session_id": session_id,
                "org_id": org_id,
                "user_id": user_id,
            },
            settings=settings,
        )

        total = await _drain(worker)

        # check_promotion + semantic + episodic = at least 3
        assert total >= 3, f"Expected at least 3 tasks processed, got {total}"

        # All tasks succeeded
        failed = self.db.tasks.count_documents({"status": "failed"})
        assert failed == 0, f"Expected no failed tasks, got {failed}"

        succeeded = self.db.tasks.count_documents({"status": "succeeded"})
        assert succeeded >= 3

    @pytest.mark.asyncio
    async def test_stale_session_oe_reason_bypasses_threshold(self):
        """
        OE enqueues check_promotion with reason="stale_session" for a session
        with only 2 docs (below max_messages=5). Because the reason is propagated,
        _check_and_promote skips should_promote and promotes unconditionally.
        The snapshot_reason stored on the snapshot should be "idle".
        """
        session_id = "test-session-stale-reason"
        org_id = "test-org"
        user_id = "test-user"

        embedder = MockEmbedder()
        llm = MockLLM()
        llm.set_json_response("", {"memories": [], "events": []})

        from datetime import datetime, timedelta, timezone

        from bson import ObjectId

        stale_ts = datetime.now(timezone.utc) - timedelta(minutes=40)
        docs = [
            {
                "_id": ObjectId(),
                "session_id": session_id,
                "org_id": org_id,
                "user_id": user_id,
                "role": "user" if i % 2 == 0 else "assistant",
                "content": f"Stale message {i}: user prefers Python.",
                "visibility": "private",
                "promoted": False,
                "turn_seq": i,
                "timestamp": stale_ts,
            }
            for i in range(2)
        ]
        self.db.memory_short_term.insert_many(docs)

        engine = _make_engine(self.db_name, embedder, llm)
        engine.bootstrap(ensure_search_indexes=False)

        worker = _make_worker(engine, llm)
        worker.initialize()

        settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=self.db_name)
        # OE stamps "stale_session" as the reason — worker must honour it
        enqueue_task(
            "snapshot",
            {
                "snapshot_task_type": "check_promotion",
                "session_id": session_id,
                "org_id": org_id,
                "user_id": user_id,
                "reason": "idle_session",
            },
            settings=settings,
        )

        total = await _drain(worker)
        assert total >= 1

        # Snapshot was created despite being below the message count threshold
        snapshot = self.db.memory_snapshot.find_one({"session_id": session_id, "org_id": org_id})
        assert snapshot is not None, (
            "Stale session should be promoted when OE propagates reason='idle_session'"
        )
        assert len(snapshot.get("messages", [])) == 2

        # snapshot_reason should reflect the stale trigger mapped to "idle"
        assert snapshot.get("snapshot_reason") == "idle", (
            f"Expected snapshot_reason='idle', got {snapshot.get('snapshot_reason')!r}"
        )

        # All STM docs marked promoted
        unpromoted = self.db.memory_short_term.count_documents(
            {"session_id": session_id, "org_id": org_id, "promoted": {"$ne": True}}
        )
        assert unpromoted == 0

    @pytest.mark.asyncio
    async def test_below_threshold_no_snapshot(self):
        """If STM count is below max_messages, no snapshot is created."""
        session_id = "test-session-003"
        org_id = "test-org"
        user_id = "test-user"

        embedder = MockEmbedder()
        llm = MockLLM()

        # Seed only 3 docs — below max_messages=5
        self._seed_stm(session_id, org_id, user_id, n=3)

        engine = _make_engine(self.db_name, embedder, llm)
        engine.bootstrap(ensure_search_indexes=False)

        worker = _make_worker(engine, llm)
        worker.initialize()

        settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=self.db_name)
        enqueue_task(
            "snapshot",
            {
                "snapshot_task_type": "check_promotion",
                "session_id": session_id,
                "org_id": org_id,
                "user_id": user_id,
            },
            settings=settings,
        )

        total = await _drain(worker)

        # check_promotion ran (returned 1), but was a no-op
        assert total == 1

        # No snapshot created
        snapshot = self.db.memory_snapshot.find_one({"session_id": session_id, "org_id": org_id})
        assert snapshot is None, "No snapshot should be created below threshold"

        # No extraction tasks enqueued
        extraction_tasks = self.db.tasks.count_documents(
            {"task_type": {"$in": ["semantic", "episodic"]}}
        )
        assert extraction_tasks == 0

    @pytest.mark.asyncio
    async def test_idempotent_double_enqueue(self):
        """Enqueueing check_promotion twice for the same snapshot produces one snapshot."""
        session_id = "test-session-004"
        org_id = "test-org"
        user_id = "test-user"

        embedder = MockEmbedder()
        llm = MockLLM()
        llm.set_json_response("", {"memories": [], "events": []})

        self._seed_stm(session_id, org_id, user_id, n=6)

        engine = _make_engine(self.db_name, embedder, llm)
        engine.bootstrap(ensure_search_indexes=False)

        worker = _make_worker(engine, llm)
        worker.initialize()

        settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=self.db_name)
        payload = {
            "snapshot_task_type": "check_promotion",
            "session_id": session_id,
            "org_id": org_id,
            "user_id": user_id,
        }

        # Enqueue twice
        enqueue_task("snapshot", payload, settings=settings)
        enqueue_task("snapshot", payload, settings=settings)

        await _drain(worker)

        # Exactly one snapshot
        snapshot_count = self.db.memory_snapshot.count_documents(
            {"session_id": session_id, "org_id": org_id}
        )
        assert snapshot_count == 1, f"Expected 1 snapshot, got {snapshot_count}"

    @pytest.mark.asyncio
    async def test_mixture_promoted_and_unpromoted_only_unpromoted_included(self):
        """
        Session has a mix of already-promoted and new unpromoted STM docs.
        Promotion should only include the unpromoted docs in the snapshot.
        """
        session_id = "test-session-005"
        org_id = "test-org"
        user_id = "test-user"

        embedder = MockEmbedder()
        llm = MockLLM()
        llm.set_json_response("", {"memories": [], "events": []})

        engine = _make_engine(self.db_name, embedder, llm)
        engine.bootstrap(ensure_search_indexes=False)

        # Seed 3 already-promoted docs (simulating a previous promotion run)
        promoted_docs = self._seed_stm(session_id, org_id, user_id, n=3)
        self.db.memory_short_term.update_many(
            {"_id": {"$in": [d["_id"] for d in promoted_docs]}},
            {"$set": {"promoted": True}},
        )

        # Seed 6 new unpromoted docs — above threshold
        new_docs = self._seed_stm(session_id, org_id, user_id, n=6)

        worker = _make_worker(engine, llm)
        worker.initialize()

        settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=self.db_name)
        enqueue_task(
            "snapshot",
            {
                "snapshot_task_type": "check_promotion",
                "session_id": session_id,
                "org_id": org_id,
                "user_id": user_id,
            },
            settings=settings,
        )

        await _drain(worker)

        # Snapshot was created
        snapshot = self.db.memory_snapshot.find_one({"session_id": session_id, "org_id": org_id})
        assert snapshot is not None

        # Snapshot contains only the new (unpromoted) messages — not the 3 old ones
        snapshot_message_count = len(snapshot.get("messages", []))
        assert snapshot_message_count == len(new_docs) or snapshot_message_count <= len(new_docs), (
            f"Snapshot should contain only unpromoted messages, got {snapshot_message_count}"
        )

        # The 3 originally-promoted docs are still promoted
        still_promoted = self.db.memory_short_term.count_documents(
            {"_id": {"$in": [d["_id"] for d in promoted_docs]}, "promoted": True}
        )
        assert still_promoted == 3

        # The 6 new docs are now also marked promoted
        newly_promoted = self.db.memory_short_term.count_documents(
            {"_id": {"$in": [d["_id"] for d in new_docs]}, "promoted": True}
        )
        assert newly_promoted == len(new_docs)

    @pytest.mark.asyncio
    async def test_mixture_only_promoted_docs_no_new_snapshot(self):
        """
        Session has only already-promoted docs and no new unpromoted ones.
        check_promotion should be a no-op — no new snapshot created.
        """
        session_id = "test-session-006"
        org_id = "test-org"
        user_id = "test-user"

        embedder = MockEmbedder()
        llm = MockLLM()

        engine = _make_engine(self.db_name, embedder, llm)
        engine.bootstrap(ensure_search_indexes=False)

        # Seed docs and mark them all as promoted
        docs = self._seed_stm(session_id, org_id, user_id, n=6)
        self.db.memory_short_term.update_many(
            {"_id": {"$in": [d["_id"] for d in docs]}},
            {"$set": {"promoted": True}},
        )

        worker = _make_worker(engine, llm)
        worker.initialize()

        settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=self.db_name)
        enqueue_task(
            "snapshot",
            {
                "snapshot_task_type": "check_promotion",
                "session_id": session_id,
                "org_id": org_id,
                "user_id": user_id,
            },
            settings=settings,
        )

        total = await _drain(worker)

        # check_promotion ran but was a no-op (no unpromoted docs to promote)
        assert total == 1

        # No snapshot was created
        snapshot_count = self.db.memory_snapshot.count_documents(
            {"session_id": session_id, "org_id": org_id}
        )
        assert snapshot_count == 0, (
            "No snapshot should be created when all docs are already promoted"
        )

    @pytest.mark.asyncio
    async def test_concurrent_process_calls_multiple_sessions_and_users(self):
        """
        10 concurrent /process calls (drain loops) over a shared worker with
        10 distinct (session_id, user_id) combinations in the task queue.

        Verifies:
        - Each session gets exactly one snapshot (no double-promotion)
        - Each user's STM docs are not mixed into another user's snapshot
        - Concurrent atomic task claiming works correctly under load
        - All 10 sessions are fully processed across the concurrent drainers
        """
        NUM_SESSIONS = 10
        ORG_ID = "test-org-concurrent"
        STM_PER_SESSION = 6  # above max_messages=5

        embedder = MockEmbedder()
        llm = MockLLM()
        llm.set_json_response("", {"memories": [], "events": []})

        engine = _make_engine(self.db_name, embedder, llm)
        engine.bootstrap(ensure_search_indexes=False)

        worker = _make_worker(engine, llm)
        worker.initialize()

        settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=self.db_name)

        # Seed STM docs and enqueue check_promotion for each (session, user) pair
        sessions = [
            {"session_id": f"session-{i:03d}", "user_id": f"user-{i:03d}"}
            for i in range(NUM_SESSIONS)
        ]

        for s in sessions:
            self._seed_stm(s["session_id"], ORG_ID, s["user_id"], n=STM_PER_SESSION)
            enqueue_task(
                "snapshot",
                {
                    "snapshot_task_type": "check_promotion",
                    "session_id": s["session_id"],
                    "org_id": ORG_ID,
                    "user_id": s["user_id"],
                },
                settings=settings,
            )

        # Fire 10 concurrent drain loops — mirrors 10 simultaneous /process calls
        async def drain_worker() -> int:
            return await _drain(worker)

        await asyncio.gather(*[drain_worker() for _ in range(NUM_SESSIONS)])

        # Mop up any extraction tasks enqueued after a drainer already exited.
        # This mirrors real OE behaviour where the next /process call picks up stragglers.
        await _drain(worker)

        # All 10 check_promotion tasks must have succeeded — no double-processing
        snapshot_tasks = self.db.tasks.count_documents(
            {"task_type": "snapshot", "status": "succeeded"}
        )
        assert snapshot_tasks == NUM_SESSIONS, (
            f"Expected {NUM_SESSIONS} snapshot tasks succeeded, got {snapshot_tasks}"
        )

        # No tasks failed or are still queued
        failed = self.db.tasks.count_documents({"status": "failed"})
        queued = self.db.tasks.count_documents({"status": "queued"})
        assert failed == 0, f"Expected 0 failed tasks, got {failed}"
        assert queued == 0, f"Expected 0 queued tasks remaining, got {queued}"

        # Exactly one snapshot per session — no duplicates
        for s in sessions:
            count = self.db.memory_snapshot.count_documents(
                {"session_id": s["session_id"], "org_id": ORG_ID}
            )
            assert count == 1, (
                f"Expected exactly 1 snapshot for session={s['session_id']}, got {count}"
            )

        # Each snapshot contains only that session's messages — no cross-session contamination
        for s in sessions:
            snapshot = self.db.memory_snapshot.find_one(
                {"session_id": s["session_id"], "org_id": ORG_ID}
            )
            assert snapshot is not None
            # Verify snapshot is scoped to the correct user
            assert snapshot["user_id"] == s["user_id"], (
                f"Snapshot for session={s['session_id']} has wrong user_id: "
                f"expected {s['user_id']}, got {snapshot['user_id']}"
            )

        # All STM docs across all sessions are marked promoted (not mixed up)
        for s in sessions:
            unpromoted = self.db.memory_short_term.count_documents(
                {
                    "session_id": s["session_id"],
                    "org_id": ORG_ID,
                    "promoted": {"$ne": True},
                }
            )
            assert unpromoted == 0, (
                f"Session {s['session_id']} still has {unpromoted} unpromoted STM docs"
            )

        # Each snapshot must have produced its own distinct extraction tasks —
        # verifies that source_id is the actual snapshot _id (not "None"),
        # which would cause all sessions to share the same idempotency key.
        snapshot_ids = set()
        for s in sessions:
            snapshot = self.db.memory_snapshot.find_one(
                {"session_id": s["session_id"], "org_id": ORG_ID}
            )
            assert snapshot is not None
            snapshot_ids.add(str(snapshot["_id"]))

        semantic_source_ids = {
            t["payload"].get("source_id")
            for t in self.db.tasks.find({"task_type": "semantic", "status": "succeeded"})
        }
        assert snapshot_ids == semantic_source_ids, (
            "Semantic extraction tasks do not have unique per-snapshot source_ids. "
            f"Expected {len(snapshot_ids)} distinct IDs, got source_ids={semantic_source_ids}"
        )


# Note: malformed STM doc / DLQ tests live in test_consolidation_malformed_docs.py


class TestNonDefaultThresholds:
    """
    Tests for promotion with non-default max_messages and stale_minutes thresholds.

    Verifies that the worker respects custom SnapshotConfig values rather than
    always using the built-in defaults (max_messages=20, stale_minutes=3).
    """

    def setup_method(self):
        self.db_name = random_db_name()
        self.client = MongoClient(TEST_MONGO_URI)
        self.db = self.client[self.db_name]

    def teardown_method(self):
        self.client.drop_database(self.db_name)
        self.client.close()

    def _seed_stm(self, session_id, org_id, user_id, n, timestamp=None):
        from datetime import datetime, timezone

        from bson import ObjectId

        if timestamp is None:
            timestamp = datetime.now(timezone.utc)
        docs = [
            {
                "_id": ObjectId(),
                "session_id": session_id,
                "org_id": org_id,
                "user_id": user_id,
                "role": "user" if i % 2 == 0 else "assistant",
                "content": f"Message {i}",
                "visibility": "private",
                "promoted": False,
                "turn_seq": i,
                "timestamp": timestamp,
            }
            for i in range(n)
        ]
        self.db.memory_short_term.insert_many(docs)
        return docs

    @pytest.mark.asyncio
    async def test_custom_max_messages_threshold(self):
        """
        With max_messages=3, a session with exactly 3 docs should be promoted.
        With the default of 5 it would not trigger.
        """
        session_id = "threshold-session-001"
        org_id = "test-org"
        user_id = "test-user"

        embedder = MockEmbedder()
        llm = MockLLM()
        llm.set_json_response("", {"memories": [], "events": []})

        # Seed exactly 3 docs — below default max_messages=5 but at custom threshold=3
        self._seed_stm(session_id, org_id, user_id, n=3)

        engine = _make_engine(self.db_name, embedder, llm)
        engine.bootstrap(ensure_search_indexes=False)

        custom_config = SnapshotConfig(
            strategy="auto",
            embedding_strategy="generate",
            max_messages=3,
            stale_minutes=60,  # high stale threshold so only message_count triggers
            delete_promoted=False,
        )
        worker = _make_worker(engine, llm, snapshot_config=custom_config)
        worker.initialize()

        settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=self.db_name)
        enqueue_task(
            "snapshot",
            {
                "snapshot_task_type": "check_promotion",
                "session_id": session_id,
                "org_id": org_id,
                "user_id": user_id,
                "reason": "message_count",
            },
            settings=settings,
        )

        total = await _drain(worker)
        assert total >= 1

        snapshot = self.db.memory_snapshot.find_one({"session_id": session_id})
        assert snapshot is not None, "Snapshot should be created at custom max_messages=3 threshold"
        # _preserve_pairs may trim the last unpaired message, so >= 2 rather than == 3
        assert len(snapshot.get("messages", [])) >= 2

        # _preserve_pairs may leave an unpaired trailing doc unpromoted (to be
        # included in the next promotion cycle). At least one doc must be promoted.
        promoted = self.db.memory_short_term.count_documents(
            {"session_id": session_id, "promoted": True}
        )
        assert promoted >= 2

    @pytest.mark.asyncio
    async def test_custom_max_messages_below_threshold_no_snapshot(self):
        """
        With max_messages=3, a session with only 2 docs should NOT be promoted
        via message_count (only staleness could trigger it, which is not the reason here).
        """
        session_id = "threshold-session-002"
        org_id = "test-org"
        user_id = "test-user"

        embedder = MockEmbedder()
        llm = MockLLM()

        # Seed 2 docs — below custom max_messages=3
        self._seed_stm(session_id, org_id, user_id, n=2)

        engine = _make_engine(self.db_name, embedder, llm)
        engine.bootstrap(ensure_search_indexes=False)

        custom_config = SnapshotConfig(
            strategy="auto",
            embedding_strategy="generate",
            max_messages=3,
            stale_minutes=60,
            delete_promoted=False,
        )
        worker = _make_worker(engine, llm, snapshot_config=custom_config)
        worker.initialize()

        settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=self.db_name)
        # No OE reason — worker evaluates thresholds locally via should_promote
        enqueue_task(
            "snapshot",
            {
                "snapshot_task_type": "check_promotion",
                "session_id": session_id,
                "org_id": org_id,
                "user_id": user_id,
            },
            settings=settings,
        )

        total = await _drain(worker)
        assert total == 1  # task ran but was a no-op

        snapshot = self.db.memory_snapshot.find_one({"session_id": session_id})
        assert snapshot is None, (
            "No snapshot should be created: 2 docs < max_messages=3 and no OE reason"
        )

    @pytest.mark.asyncio
    async def test_custom_stale_minutes_triggers_promotion(self):
        """
        With stale_minutes=1, a session whose last STM doc is 2 minutes old
        should be promoted even though the doc count is below max_messages.
        The OE stamps reason='idle_session' to bypass should_promote checks.
        """
        from datetime import datetime, timedelta, timezone

        session_id = "threshold-session-003"
        org_id = "test-org"
        user_id = "test-user"

        embedder = MockEmbedder()
        llm = MockLLM()
        llm.set_json_response("", {"memories": [], "events": []})

        # Seed 2 docs with a 2-minute-old timestamp (below max_messages=10)
        stale_ts = datetime.now(timezone.utc) - timedelta(minutes=2)
        self._seed_stm(session_id, org_id, user_id, n=2, timestamp=stale_ts)

        engine = _make_engine(self.db_name, embedder, llm)
        engine.bootstrap(ensure_search_indexes=False)

        custom_config = SnapshotConfig(
            strategy="auto",
            embedding_strategy="generate",
            max_messages=10,  # high — won't trigger on 2 docs
            stale_minutes=1,  # low — 2-minute-old docs exceed this
            delete_promoted=False,
        )
        worker = _make_worker(engine, llm, snapshot_config=custom_config)
        worker.initialize()

        settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=self.db_name)
        # OE stamps idle_session reason — worker promotes unconditionally
        enqueue_task(
            "snapshot",
            {
                "snapshot_task_type": "check_promotion",
                "session_id": session_id,
                "org_id": org_id,
                "user_id": user_id,
                "reason": "idle_session",
            },
            settings=settings,
        )

        total = await _drain(worker)
        assert total >= 1

        snapshot = self.db.memory_snapshot.find_one({"session_id": session_id})
        assert snapshot is not None, (
            "Stale session should be promoted when OE sends reason='idle_session'"
        )
        assert len(snapshot.get("messages", [])) == 2

        # snapshot_reason should reflect idle trigger
        assert snapshot.get("snapshot_reason") == "idle", (
            f"Expected snapshot_reason='idle', got {snapshot.get('snapshot_reason')!r}"
        )

        unpromoted = self.db.memory_short_term.count_documents(
            {"session_id": session_id, "promoted": {"$ne": True}}
        )
        assert unpromoted == 0
