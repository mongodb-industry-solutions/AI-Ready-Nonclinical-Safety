"""
Unit tests for STM to snapshot promotion pipeline.

These tests verify the promotion logic without database interactions.
"""

import pytest
from mongomem_core.models.config.snapshot_config import (
    SnapshotConfig,
)
from mongomem_core.pipelines.stm_to_snapshot import (
    _estimate_token_count,
    _normalize_tool_calls,
    _preserve_pairs,
    should_promote,
    transfer_embeddings,
)


class TestShouldPromote:
    """Tests for should_promote function."""

    def test_should_promote_empty_docs(self):
        """Returns False for empty STM docs."""
        config = SnapshotConfig()
        should, reason = should_promote([], config)

        assert should is False
        assert reason == "none"

    def test_should_promote_by_message_count(self):
        """Returns True when message count threshold is met."""
        config = SnapshotConfig(max_messages=5)
        stm_docs = [{"content": f"Message {i}", "role": "user"} for i in range(5)]

        should, reason = should_promote(stm_docs, config)

        assert should is True
        assert reason == "message_count"

    def test_should_not_promote_below_threshold(self):
        """Returns False when below message count threshold."""
        config = SnapshotConfig(max_messages=10)
        stm_docs = [{"content": f"Message {i}", "role": "user"} for i in range(5)]

        should, reason = should_promote(stm_docs, config)

        assert should is False
        assert reason == "none"

    def test_should_promote_by_token_count(self):
        """Returns True when token count threshold is met."""
        config = SnapshotConfig(max_messages=100, max_tokens=50)
        # Each message ~50 chars = ~12.5 tokens
        stm_docs = [{"content": "A" * 50, "role": "user"} for _ in range(5)]  # ~62.5 tokens

        should, reason = should_promote(stm_docs, config)

        assert should is True
        assert reason == "token_count"

    def test_should_promote_topic_shift_disabled(self):
        """Does not check topic shift when disabled."""
        config = SnapshotConfig(max_messages=100, topic_shift_enabled=False)
        stm_docs = [{"content": "Message", "role": "user"}]

        should, reason = should_promote(stm_docs, config)

        assert should is False
        assert reason == "none"


class TestEstimateTokenCount:
    """Tests for _estimate_token_count function."""

    def test_estimate_token_count_basic(self):
        """Estimates tokens from content."""
        stm_docs = [
            {"content": "Hello world"},  # 11 chars -> ~2-3 tokens
            {"content": "Another message here"},  # 20 chars -> ~5 tokens
        ]

        count = _estimate_token_count(stm_docs)

        # 31 chars / 4 = ~7 tokens
        assert count == 7

    def test_estimate_token_count_empty_content(self):
        """Handles empty content."""
        stm_docs = [
            {"content": ""},
            {"content": None},
        ]

        count = _estimate_token_count(stm_docs)

        assert count == 0


class TestTransferEmbeddings:
    """Tests for transfer_embeddings function."""

    def test_transfer_embeddings_from_user_messages(self):
        """Transfers embeddings from user messages."""
        stm_docs = [
            {"role": "user", "content": "Hello", "embedding": [1.0, 0.0, 0.0]},
            {"role": "assistant", "content": "Hi", "embedding": [0.0, 1.0, 0.0]},
            {"role": "user", "content": "How are you?", "embedding": [0.0, 0.0, 1.0]},
        ]

        embedding, strategy = transfer_embeddings(stm_docs)

        assert embedding is not None
        assert strategy == "transfer"
        assert len(embedding) == 3
        # Average of user embeddings: [1,0,0] and [0,0,1] = [0.5, 0, 0.5]
        assert abs(embedding[0] - 0.5) < 0.01
        assert abs(embedding[1] - 0.0) < 0.01
        assert abs(embedding[2] - 0.5) < 0.01

    def test_transfer_embeddings_no_embeddings(self):
        """Returns None when no embeddings available."""
        stm_docs = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi"},
        ]

        embedding, strategy = transfer_embeddings(stm_docs)

        assert embedding is None
        assert strategy is None

    def test_transfer_embeddings_fallback_to_all(self):
        """Falls back to all embeddings if no user embeddings."""
        stm_docs = [
            {"role": "assistant", "content": "Hi", "embedding": [1.0, 0.0, 0.0]},
            {"role": "system", "content": "System", "embedding": [0.0, 1.0, 0.0]},
        ]

        embedding, strategy = transfer_embeddings(stm_docs)

        assert embedding is not None
        assert strategy == "transfer"


class TestPreservePairs:
    """Tests for _preserve_pairs function."""

    def test_preserve_pairs_keeps_full_list(self):
        """Keeps full list when last message is assistant."""
        config = SnapshotConfig(preserve_pairs=True)
        stm_docs = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi"},
        ]

        result = _preserve_pairs(stm_docs, config)

        assert len(result) == 2

    def test_preserve_pairs_removes_last_user(self):
        """Removes last user message when no assistant response."""
        config = SnapshotConfig(preserve_pairs=True)
        stm_docs = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi"},
            {"role": "user", "content": "How are you?"},
        ]

        result = _preserve_pairs(stm_docs, config)

        assert len(result) == 2
        assert result[-1]["content"] == "Hi"

    def test_preserve_pairs_disabled(self):
        """Returns full list when preserve_pairs is disabled."""
        config = SnapshotConfig(preserve_pairs=False)
        stm_docs = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi"},
            {"role": "user", "content": "How are you?"},
        ]

        result = _preserve_pairs(stm_docs, config)

        assert len(result) == 3

    def test_preserve_pairs_empty_list(self):
        """Handles empty list."""
        config = SnapshotConfig(preserve_pairs=True)

        result = _preserve_pairs([], config)

        assert len(result) == 0


class TestNormalizeToolCalls:
    """Tests for _normalize_tool_calls."""

    def test_none_passthrough(self):
        """None is returned unchanged."""
        assert _normalize_tool_calls(None) is None

    def test_empty_list_passthrough(self):
        """Empty list is returned unchanged."""
        assert _normalize_tool_calls([]) == []

    def test_flat_oe_format_converted(self):
        """Flat OE format {name, arguments, id} is converted to OpenAI format."""
        result = _normalize_tool_calls(
            [{"id": "call_1", "name": "get_weather", "arguments": {"city": "NYC"}}]
        )
        assert result == [
            {
                "id": "call_1",
                "type": "function",
                "function": {"name": "get_weather", "arguments": '{"city": "NYC"}'},
            }
        ]

    def test_openai_format_passthrough(self):
        """Already-normalized OpenAI format passes through unchanged."""
        result = _normalize_tool_calls(
            [
                {
                    "id": "call_1",
                    "type": "function",
                    "function": {"name": "get_weather", "arguments": '{"city": "NYC"}'},
                }
            ]
        )
        assert result[0]["id"] == "call_1"
        assert result[0]["function"]["name"] == "get_weather"

    def test_arguments_dict_serialized_to_string(self):
        """arguments dict in OpenAI format is serialized to a JSON string."""
        result = _normalize_tool_calls(
            [
                {
                    "id": "call_1",
                    "type": "function",
                    "function": {"name": "fn", "arguments": {"k": "v"}},
                }
            ]
        )
        assert isinstance(result[0]["function"]["arguments"], str)
        assert '"k"' in result[0]["function"]["arguments"]

    def test_missing_id_raises(self):
        """Missing or empty id raises ValueError."""
        with pytest.raises(ValueError, match="missing required 'id'"):
            _normalize_tool_calls([{"id": "", "name": "fn", "arguments": {}}])

    def test_missing_name_raises(self):
        """Missing or empty name raises ValueError."""
        with pytest.raises(ValueError, match="missing required 'name'"):
            _normalize_tool_calls([{"id": "call_1", "name": "", "arguments": {}}])

    def test_missing_function_name_raises(self):
        """Missing function.name in OpenAI format raises ValueError."""
        with pytest.raises(ValueError, match="missing required 'function.name'"):
            _normalize_tool_calls(
                [{"id": "call_1", "type": "function", "function": {"name": "", "arguments": "{}"}}]
            )

    def test_multiple_calls_all_converted(self):
        """Multiple tool calls are all normalized."""
        result = _normalize_tool_calls(
            [
                {"id": "c1", "name": "fn1", "arguments": {}},
                {"id": "c2", "name": "fn2", "arguments": {"x": 1}},
            ]
        )
        assert len(result) == 2
        assert result[0]["id"] == "c1"
        assert result[1]["function"]["name"] == "fn2"


class TestSnapshotConfig:
    """Tests for SnapshotConfig."""

    def test_default_config(self):
        """Default config has sensible defaults."""
        config = SnapshotConfig()

        assert config.strategy == "auto"
        assert config.max_messages == 20
        assert config.embedding_strategy == "transfer"
        assert config.preserve_pairs is True
        assert config.ttl_days == 30

    def test_manual_strategy(self):
        """Manual strategy doesn't require thresholds."""
        config = SnapshotConfig(strategy="manual", max_messages=None)

        assert config.strategy == "manual"
        assert config.is_auto_promotion_enabled() is False

    def test_auto_strategy_requires_threshold(self):
        """Auto strategy requires at least one threshold."""
        with pytest.raises(ValueError):
            SnapshotConfig(strategy="auto", max_messages=None, max_tokens=None)

    def test_should_snapshot_by_count(self):
        """Tests message count threshold check."""
        config = SnapshotConfig(max_messages=10)

        assert config.should_snapshot_by_count(5) is False
        assert config.should_snapshot_by_count(10) is True
        assert config.should_snapshot_by_count(15) is True

    def test_should_snapshot_by_tokens(self):
        """Tests token count threshold check."""
        config = SnapshotConfig(max_tokens=100)

        assert config.should_snapshot_by_tokens(50) is False
        assert config.should_snapshot_by_tokens(100) is True
        assert config.should_snapshot_by_tokens(150) is True

    def test_should_snapshot_by_topic(self):
        """Tests topic shift threshold check."""
        config = SnapshotConfig(topic_shift_enabled=True, topic_shift_threshold=0.5)

        assert config.should_snapshot_by_topic(0.6) is False  # Above threshold
        assert config.should_snapshot_by_topic(0.4) is True  # Below threshold

    def test_embedding_strategies(self):
        """Tests all embedding strategy values."""
        for strategy in ["transfer", "generate", "defer"]:
            config = SnapshotConfig(embedding_strategy=strategy)
            assert config.embedding_strategy == strategy
