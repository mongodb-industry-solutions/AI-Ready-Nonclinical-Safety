"""
Integration tests for episodic memory CRUD operations.

These tests use a real MongoDB database to verify end-to-end behavior
of episodic memory operations.
"""

from mongomem_core.memory.episodic import (
    create_episodic,
    delete_episodic,
    get_episodic,
    list_episodic,
    soft_delete_episodic,
    update_episodic,
    upsert_episodic,
)
from mongomem_core.models.memory.episodic import (
    EpisodicIn,
    EpisodicUpdate,
)


class TestEpisodicMemoryCRUD:
    """Integration tests for episodic memory CRUD operations."""

    def test_create_and_get_episodic(self, bootstrapped_engine):
        """Test creating and retrieving an episodic memory document."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"

        # Create episodic memory
        episodic_in = EpisodicIn(
            session_id="session-1",
            title="Team Meeting",
            snapshot_ref_id="snap-1",
            summary_text="Discussed project timeline and milestones",
        )

        created = create_episodic(db, episodic_in, org_id=org_id, user_id=user_id)

        assert created.id is not None
        assert created.session_id == "session-1"
        assert created.title == "Team Meeting"
        assert created.org_id == org_id
        assert created.user_id == user_id
        assert created.timestamp is not None

        # Retrieve by ID
        retrieved = get_episodic(db, org_id, id=str(created.id))
        assert retrieved is not None
        assert retrieved.id == str(created.id)
        assert retrieved.title == "Team Meeting"

        # Retrieve by session_id and snapshot_ref_id
        retrieved_by_key = get_episodic(
            db, org_id, session_id="session-1", snapshot_ref_id="snap-1"
        )
        assert retrieved_by_key is not None
        assert retrieved_by_key.id == str(created.id)

    def test_upsert_episodic(self, bootstrapped_engine):
        """Test upserting episodic memory (create or update)."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"

        episodic_in = EpisodicIn(
            session_id="session-2",
            title="Initial Title",
            snapshot_ref_id="snap-2",
            summary_text="Initial summary",
        )

        # First upsert creates new document
        created = upsert_episodic(db, episodic_in, org_id=org_id, user_id=user_id)
        original_id = created.id
        original_timestamp = created.timestamp

        # Second upsert updates existing document
        updated_in = EpisodicIn(
            session_id="session-2",
            title="Updated Title",
            snapshot_ref_id="snap-2",
            summary_text="Updated summary",
        )
        updated = upsert_episodic(db, updated_in, org_id=org_id, user_id=user_id)

        assert updated.id == original_id
        assert updated.title == "Updated Title"
        assert updated.timestamp == original_timestamp  # Timestamp preserved

    def test_update_episodic(self, bootstrapped_engine):
        """Test updating an existing episodic memory document."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"

        # Create document
        episodic_in = EpisodicIn(
            session_id="session-3",
            title="Original Title",
            snapshot_ref_id="snap-3",
        )
        created = create_episodic(db, episodic_in, org_id=org_id, user_id=user_id)

        # Update document
        update = EpisodicUpdate(title="New Title", summary_text="New summary")
        updated = update_episodic(db, org_id, update, id=str(created.id))

        assert updated.title == "New Title"
        assert updated.summary_text == "New summary"

    def test_list_episodic(self, bootstrapped_engine):
        """Test listing episodic memory documents with filters."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"

        # Create multiple documents
        for i in range(3):
            episodic_in = EpisodicIn(
                session_id=f"session-{i}",
                title=f"Meeting {i}",
                snapshot_ref_id=f"snap-{i}",
            )
            create_episodic(db, episodic_in, org_id=org_id, user_id=user_id)

        # List all
        all_docs = list_episodic(db, org_id)
        assert len(all_docs) >= 3

        # List with user filter
        user_docs = list_episodic(db, org_id, user_id=user_id)
        assert len(user_docs) >= 3

    def test_soft_delete_episodic(self, bootstrapped_engine):
        """Test soft deleting an episodic memory document."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"

        # Create document
        episodic_in = EpisodicIn(
            session_id="session-4",
            title="To Delete",
            snapshot_ref_id="snap-4",
        )
        created = create_episodic(db, episodic_in, org_id=org_id, user_id=user_id)

        # Soft delete
        result = soft_delete_episodic(db, org_id, id=str(created.id))
        assert result.modified_count == 1

        # Document should not be found by default
        retrieved = get_episodic(db, org_id, id=str(created.id))
        assert retrieved is None

        # But should be found with include_deleted=True
        retrieved_deleted = get_episodic(db, org_id, id=str(created.id), include_deleted=True)
        assert retrieved_deleted is not None
        assert retrieved_deleted.deleted is True

    def test_delete_episodic(self, bootstrapped_engine):
        """Test hard deleting an episodic memory document."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"

        # Create document
        episodic_in = EpisodicIn(
            session_id="session-5",
            title="To Hard Delete",
            snapshot_ref_id="snap-5",
        )
        created = create_episodic(db, episodic_in, org_id=org_id, user_id=user_id)

        # Hard delete
        result = delete_episodic(db, org_id, id=str(created.id))
        assert result.deleted_count == 1

        # Document should not be found even with include_deleted
        retrieved = get_episodic(db, org_id, id=str(created.id), include_deleted=True)
        assert retrieved is None
