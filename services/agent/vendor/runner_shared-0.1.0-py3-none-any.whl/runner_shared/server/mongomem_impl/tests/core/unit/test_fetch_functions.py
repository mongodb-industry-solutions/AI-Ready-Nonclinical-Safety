"""
Unit tests for standalone fetch_episodic_memories and fetch_semantic_memories functions.

These tests validate the refactored fetch functions in sources.py, including:
- Query resolution (text vs embedding)
- DB mode vs pre-fetched mode
- Deduplication and ranking options
- Error handling
- RBAC parameter passing
"""

from unittest.mock import MagicMock, patch

import pytest
from mongomem_core.common.utils import utcnow
from mongomem_core.exceptions import DatabaseOperationError
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.episodic import EpisodicOut
from mongomem_core.models.memory.semantic import SemanticOut
from mongomem_core.models.retrieval import MemoryChunk
from mongomem_core.retrieval.sources import (
    fetch_episodic_memories,
    fetch_semantic_memories,
)
from pymongo.database import Database


class TestFetchEpisodicMemories:
    """Tests for fetch_episodic_memories function."""

    @pytest.fixture
    def mock_db(self):
        """Create a mock MongoDB database."""
        return MagicMock(spec=Database)

    @pytest.fixture
    def query_embedding(self):
        """Create a test query embedding."""
        return [0.1] * 1024

    @pytest.fixture
    def mock_embedder(self):
        """Create a mock embedder."""
        embedder = MagicMock()
        embedder.embed.return_value = [0.1] * 1024
        return embedder

    @pytest.fixture
    def sample_episodic(self):
        """Create a sample episodic memory."""
        return EpisodicOut(
            _id="ep_1",
            session_id="sess_123",
            title="Test Episode",
            snapshot_ref_id="snap_1",
            content="Episode content",
            summary_text="Episode summary",
            summary_type="llm",
            source_agent="user",
            participants=[],
            tags=[],
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
            score=0.85,
        )

    def test_fetch_episodic_with_query_embedding(self, mock_db, query_embedding, sample_episodic):
        """fetch_episodic_memories uses query_embedding when provided."""
        with patch(
            "mongomem_core.retrieval.sources.vector_search_episodic",
            return_value=[sample_episodic],
        ) as mock_search:
            chunks = fetch_episodic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=query_embedding,
            )

            assert len(chunks) == 1
            assert chunks[0].id == "ep_1"
            mock_search.assert_called_once()
            call_kwargs = mock_search.call_args.kwargs
            assert call_kwargs["query_embedding"] == query_embedding

    def test_fetch_episodic_with_text_query(self, mock_db, mock_embedder, sample_episodic):
        """fetch_episodic_memories generates embedding from text query."""
        with patch(
            "mongomem_core.retrieval.sources.vector_search_episodic",
            return_value=[sample_episodic],
        ) as mock_search:
            chunks = fetch_episodic_memories(
                db=mock_db,
                org_id="org_1",
                query="test query",
                embedder=mock_embedder,
            )

            assert len(chunks) == 1
            mock_embedder.embed.assert_called_once_with("test query")
            mock_search.assert_called_once()

    def test_fetch_episodic_with_embedding_list_query(
        self, mock_db, query_embedding, sample_episodic
    ):
        """fetch_episodic_memories accepts List[float] as query."""
        with patch(
            "mongomem_core.retrieval.sources.vector_search_episodic",
            return_value=[sample_episodic],
        ) as mock_search:
            chunks = fetch_episodic_memories(
                db=mock_db,
                org_id="org_1",
                query=query_embedding,  # List[float] as query
            )

            assert len(chunks) == 1
            mock_search.assert_called_once()

    def test_fetch_episodic_requires_query_or_embedding(self, mock_db):
        """fetch_episodic_memories raises ValueError if neither query nor query_embedding provided."""
        with pytest.raises(
            ValueError, match="Either 'query' or 'query_embedding' must be provided"
        ):
            fetch_episodic_memories(
                db=mock_db,
                org_id="org_1",
            )

    def test_fetch_episodic_requires_embedder_for_text(self, mock_db):
        """fetch_episodic_memories raises ValueError if text query but no embedder."""
        with pytest.raises(ValueError, match="embedder not available"):
            fetch_episodic_memories(
                db=mock_db,
                org_id="org_1",
                query="test query",
            )

    def test_fetch_episodic_with_prefetched(self, mock_db, query_embedding, sample_episodic):
        """fetch_episodic_memories uses pre-fetched memories when provided."""
        with patch("mongomem_core.retrieval.sources.vector_search_episodic") as mock_search:
            chunks = fetch_episodic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=query_embedding,
                prefetched=[sample_episodic],
            )

            assert len(chunks) == 1
            assert chunks[0].id == "ep_1"
            mock_search.assert_not_called()  # Should not call DB

    def test_fetch_episodic_with_deduplication(self, mock_db, query_embedding):
        """fetch_episodic_memories deduplicates when deduplicate=True."""
        # Create duplicate memories
        episodic1 = EpisodicOut(
            _id="ep_1",
            session_id="sess_123",
            title="Test",
            snapshot_ref_id="snap_1",
            content="Same content",
            summary_text="Summary",
            summary_type="llm",
            source_agent="user",
            participants=[],
            tags=[],
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
            score=0.85,
        )
        episodic2 = EpisodicOut(
            _id="ep_2",
            session_id="sess_123",
            title="Test",
            snapshot_ref_id="snap_1",
            content="Same content",  # Same content = duplicate
            summary_text="Summary",
            summary_type="llm",
            source_agent="user",
            participants=[],
            tags=[],
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
            score=0.90,
        )

        with patch(
            "mongomem_core.retrieval.sources.vector_search_episodic",
            return_value=[episodic1, episodic2],
        ):
            chunks = fetch_episodic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=query_embedding,
                deduplicate=True,
            )

            # Should deduplicate (keep one)
            assert len(chunks) == 1

    def test_fetch_episodic_without_deduplication(self, mock_db, query_embedding):
        """fetch_episodic_memories skips deduplication when deduplicate=False."""
        episodic1 = EpisodicOut(
            _id="ep_1",
            session_id="sess_123",
            title="Test",
            snapshot_ref_id="snap_1",
            content="Same content",
            summary_text="Summary",
            summary_type="llm",
            source_agent="user",
            participants=[],
            tags=[],
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
            score=0.85,
        )
        episodic2 = EpisodicOut(
            _id="ep_2",
            session_id="sess_123",
            title="Test",
            snapshot_ref_id="snap_1",
            content="Same content",
            summary_text="Summary",
            summary_type="llm",
            source_agent="user",
            participants=[],
            tags=[],
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
            score=0.90,
        )

        with patch(
            "mongomem_core.retrieval.sources.vector_search_episodic",
            return_value=[episodic1, episodic2],
        ):
            chunks = fetch_episodic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=query_embedding,
                deduplicate=False,
            )

            # Should not deduplicate
            assert len(chunks) == 2

    def test_fetch_episodic_with_ranking(self, mock_db, query_embedding, sample_episodic):
        """fetch_episodic_memories ranks results when rank=True."""
        with (
            patch(
                "mongomem_core.retrieval.sources.vector_search_episodic",
                return_value=[sample_episodic],
            ),
            patch("mongomem_core.retrieval.ranking.MemoryRanker") as mock_ranker_class,
        ):
            mock_ranker = MagicMock()
            mock_ranker.rank_memories.return_value = [MemoryChunk.from_episodic(sample_episodic)]
            mock_ranker_class.return_value = mock_ranker

            chunks = fetch_episodic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=query_embedding,
                rank=True,
            )

            assert len(chunks) == 1
            mock_ranker.rank_memories.assert_called_once()

    def test_fetch_episodic_passes_rbac_params(self, mock_db, query_embedding, sample_episodic):
        """fetch_episodic_memories passes RBAC parameters to vector search."""
        user_id = "user_1"
        visibility = ChunkVisibility.PRIVATE
        project_id = "group_1"
        session_id = "sess_123"

        with patch(
            "mongomem_core.retrieval.sources.vector_search_episodic",
            return_value=[sample_episodic],
        ) as mock_search:
            fetch_episodic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=query_embedding,
                user_id=user_id,
                visibility=visibility,
                project_id=project_id,
                session_id=session_id,
            )

            call_kwargs = mock_search.call_args.kwargs
            assert call_kwargs["user_id"] == user_id
            assert call_kwargs["visibility"] == visibility
            assert call_kwargs["project_id"] == project_id
            assert call_kwargs["session_id"] == session_id

    def test_fetch_episodic_raises_on_empty_query_embedding(self, mock_db):
        """fetch_episodic_memories raises ValueError for empty query_embedding."""
        with pytest.raises(ValueError, match="query_embedding cannot be empty"):
            fetch_episodic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=[],  # Empty embedding
            )

    def test_fetch_episodic_filters_prefetched_org_id_mismatch(self, mock_db, query_embedding):
        """fetch_episodic_memories filters prefetched memories with org_id mismatch."""
        # Create prefetched memories with mismatched org_id
        prefetched = [
            EpisodicOut(
                _id="ep_1",
                session_id="sess_1",
                title="Test 1",
                snapshot_ref_id="snap_1",
                content="Content 1",
                summary_text="Summary",
                summary_type="llm",
                source_agent="user",
                participants=[],
                tags=[],
                org_id="org_1",  # Correct org_id
                user_id="user_1",
                timestamp=utcnow(),
                score=0.8,
            ),
            EpisodicOut(
                _id="ep_2",
                session_id="sess_2",
                title="Test 2",
                snapshot_ref_id="snap_2",
                content="Content 2",
                summary_text="Summary",
                summary_type="llm",
                source_agent="user",
                participants=[],
                tags=[],
                org_id="org_2",  # Wrong org_id - should be filtered
                user_id="user_1",
                timestamp=utcnow(),
                score=0.7,
            ),
            EpisodicOut(
                _id="ep_3",
                session_id="sess_3",
                title="Test 3",
                snapshot_ref_id="snap_3",
                content="Content 3",
                summary_text="Summary",
                summary_type="llm",
                source_agent="user",
                participants=[],
                tags=[],
                org_id="org_1",  # Correct org_id
                user_id="user_1",
                timestamp=utcnow(),
                score=0.6,
            ),
        ]

        with patch("mongomem_core.retrieval.sources.logger") as mock_logger:
            chunks = fetch_episodic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=query_embedding,
                prefetched=prefetched,
                deduplicate=False,  # Disable deduplication to test org_id filtering
            )

            # Should only return memories with matching org_id
            assert len(chunks) == 2
            assert all(chunk.org_id == "org_1" for chunk in chunks)
            assert any(chunk.id == "ep_1" for chunk in chunks)
            assert any(chunk.id == "ep_3" for chunk in chunks)
            # Verify warning was logged
            mock_logger.warning.assert_called_once()
            assert "org_id mismatch" in str(mock_logger.warning.call_args)

    def test_fetch_episodic_db_error_raises(self, mock_db, query_embedding):
        """fetch_episodic_memories raises DatabaseOperationError on DB failure."""
        with patch(
            "mongomem_core.retrieval.sources.vector_search_episodic",
            side_effect=DatabaseOperationError("DB error", operation="test"),
        ):
            with pytest.raises(DatabaseOperationError):
                fetch_episodic_memories(
                    db=mock_db,
                    org_id="org_1",
                    query_embedding=query_embedding,
                )

    def test_fetch_episodic_with_top_k_and_threshold(
        self, mock_db, query_embedding, sample_episodic
    ):
        """fetch_episodic_memories passes top_k and similarity_threshold."""
        with patch(
            "mongomem_core.retrieval.sources.vector_search_episodic",
            return_value=[sample_episodic],
        ) as mock_search:
            fetch_episodic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=query_embedding,
                top_k=20,
                similarity_threshold=0.7,
            )

            call_kwargs = mock_search.call_args.kwargs
            assert call_kwargs["top_k"] == 20
            assert call_kwargs["similarity_threshold"] == 0.7


class TestFetchSemanticMemories:
    """Tests for fetch_semantic_memories function."""

    @pytest.fixture
    def mock_db(self):
        """Create a mock MongoDB database."""
        return MagicMock(spec=Database)

    @pytest.fixture
    def query_embedding(self):
        """Create a test query embedding."""
        return [0.1] * 1024

    @pytest.fixture
    def mock_embedder(self):
        """Create a mock embedder."""
        embedder = MagicMock()
        embedder.embed.return_value = [0.1] * 1024
        return embedder

    @pytest.fixture
    def sample_semantic(self):
        """Create a sample semantic memory."""
        return SemanticOut(
            _id="sem_1",
            label="Test Knowledge",
            content="Semantic content",
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
            score=0.75,
        )

    def test_fetch_semantic_with_query_embedding(self, mock_db, query_embedding, sample_semantic):
        """fetch_semantic_memories uses query_embedding when provided."""
        with patch(
            "mongomem_core.retrieval.sources.search_semantic",
            return_value=[sample_semantic],
        ) as mock_search:
            chunks = fetch_semantic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=query_embedding,
            )

            assert len(chunks) == 1
            assert chunks[0].id == "sem_1"
            mock_search.assert_called_once()
            call_kwargs = mock_search.call_args.kwargs
            assert call_kwargs["query_embedding"] == query_embedding

    def test_fetch_semantic_with_text_query(self, mock_db, mock_embedder, sample_semantic):
        """fetch_semantic_memories generates embedding from text query."""
        with patch(
            "mongomem_core.retrieval.sources.search_semantic",
            return_value=[sample_semantic],
        ) as mock_search:
            chunks = fetch_semantic_memories(
                db=mock_db,
                org_id="org_1",
                query="test query",
                embedder=mock_embedder,
            )

            assert len(chunks) == 1
            mock_embedder.embed.assert_called_once_with("test query")
            mock_search.assert_called_once()

    def test_fetch_semantic_requires_query_or_embedding(self, mock_db):
        """fetch_semantic_memories raises ValueError if neither query nor query_embedding provided."""
        with pytest.raises(
            ValueError, match="Either 'query' or 'query_embedding' must be provided"
        ):
            fetch_semantic_memories(
                db=mock_db,
                org_id="org_1",
            )

    def test_fetch_semantic_with_prefetched(self, mock_db, query_embedding, sample_semantic):
        """fetch_semantic_memories uses pre-fetched memories when provided."""
        with patch("mongomem_core.retrieval.sources.search_semantic") as mock_search:
            chunks = fetch_semantic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=query_embedding,
                prefetched=[sample_semantic],
            )

            assert len(chunks) == 1
            assert chunks[0].id == "sem_1"
            mock_search.assert_not_called()  # Should not call DB

    def test_fetch_semantic_db_error_returns_empty(self, mock_db, query_embedding):
        """fetch_semantic_memories returns empty list on DB failure (graceful)."""
        with patch(
            "mongomem_core.retrieval.sources.search_semantic",
            side_effect=DatabaseOperationError("DB error", operation="test"),
        ):
            chunks = fetch_semantic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=query_embedding,
            )

            assert chunks == []

    def test_fetch_semantic_with_deduplication(self, mock_db, query_embedding):
        """fetch_semantic_memories deduplicates when deduplicate=True."""
        semantic1 = SemanticOut(
            _id="sem_1",
            label="Test",
            content="Same content",
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
            score=0.75,
        )
        semantic2 = SemanticOut(
            _id="sem_2",
            label="Test",
            content="Same content",  # Same content = duplicate
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
            score=0.80,
        )

        with patch(
            "mongomem_core.retrieval.sources.search_semantic",
            return_value=[semantic1, semantic2],
        ):
            chunks = fetch_semantic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=query_embedding,
                deduplicate=True,
            )

            # Should deduplicate (keep one)
            assert len(chunks) == 1

    def test_fetch_semantic_with_ranking(self, mock_db, query_embedding, sample_semantic):
        """fetch_semantic_memories ranks results when rank=True."""
        with (
            patch(
                "mongomem_core.retrieval.sources.search_semantic",
                return_value=[sample_semantic],
            ),
            patch("mongomem_core.retrieval.ranking.MemoryRanker") as mock_ranker_class,
        ):
            mock_ranker = MagicMock()
            mock_ranker.rank_memories.return_value = [MemoryChunk.from_semantic(sample_semantic)]
            mock_ranker_class.return_value = mock_ranker

            chunks = fetch_semantic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=query_embedding,
                rank=True,
            )

            assert len(chunks) == 1
            mock_ranker.rank_memories.assert_called_once()

    def test_fetch_semantic_passes_rbac_params(self, mock_db, query_embedding, sample_semantic):
        """fetch_semantic_memories passes RBAC parameters to vector search."""
        user_id = "user_1"
        visibility = ChunkVisibility.SHARED
        project_id = "group_1"

        with patch(
            "mongomem_core.retrieval.sources.search_semantic",
            return_value=[sample_semantic],
        ) as mock_search:
            fetch_semantic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=query_embedding,
                user_id=user_id,
                visibility=visibility,
                project_id=project_id,
            )

            call_kwargs = mock_search.call_args.kwargs
            assert call_kwargs["user_id"] == user_id
            assert call_kwargs["visibility"] == visibility
            assert call_kwargs["project_id"] == project_id

    def test_fetch_semantic_with_top_k_and_threshold(
        self, mock_db, query_embedding, sample_semantic
    ):
        """fetch_semantic_memories passes top_k and similarity_threshold."""
        with patch(
            "mongomem_core.retrieval.sources.search_semantic",
            return_value=[sample_semantic],
        ) as mock_search:
            fetch_semantic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=query_embedding,
                top_k=30,
                similarity_threshold=0.6,
            )

            call_kwargs = mock_search.call_args.kwargs
            assert call_kwargs["top_k"] == 30
            assert call_kwargs["similarity_threshold"] == 0.6

    def test_fetch_semantic_raises_on_empty_query_embedding(self, mock_db):
        """fetch_semantic_memories raises ValueError for empty query_embedding."""
        with pytest.raises(ValueError, match="query_embedding cannot be empty"):
            fetch_semantic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=[],  # Empty embedding
            )

    def test_fetch_semantic_filters_prefetched_org_id_mismatch(self, mock_db, query_embedding):
        """fetch_semantic_memories filters prefetched memories with org_id mismatch."""
        # Create prefetched memories with mismatched org_id
        prefetched = [
            SemanticOut(
                _id="sem_1",
                label="Test 1",
                content="Python is a programming language used for data science and web development.",
                org_id="org_1",  # Correct org_id
                user_id="user_1",
                timestamp=utcnow(),
                score=0.8,
                version=1,
                is_latest=True,
            ),
            SemanticOut(
                _id="sem_2",
                label="Test 2",
                content="JavaScript is used for frontend and backend development with Node.js.",
                org_id="org_2",  # Wrong org_id - should be filtered
                user_id="user_1",
                timestamp=utcnow(),
                score=0.7,
                version=1,
                is_latest=True,
            ),
            SemanticOut(
                _id="sem_3",
                label="Test 3",
                content="Machine learning algorithms can be trained on large datasets to make predictions.",
                org_id="org_1",  # Correct org_id
                user_id="user_1",
                timestamp=utcnow(),
                score=0.6,
                version=1,
                is_latest=True,
            ),
        ]

        with patch("mongomem_core.retrieval.sources.logger") as mock_logger:
            chunks = fetch_semantic_memories(
                db=mock_db,
                org_id="org_1",
                query_embedding=query_embedding,
                prefetched=prefetched,
            )

            # Should only return memories with matching org_id
            assert len(chunks) == 2
            assert all(chunk.org_id == "org_1" for chunk in chunks)
            assert any(chunk.id == "sem_1" for chunk in chunks)
            assert any(chunk.id == "sem_3" for chunk in chunks)
            # Verify warning was logged
            mock_logger.warning.assert_called_once()
            assert "org_id mismatch" in str(mock_logger.warning.call_args)
