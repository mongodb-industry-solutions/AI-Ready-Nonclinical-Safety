"""
Unit tests for visibility/project_id parameters in persistence functions.

Tests that semantic, episodic, and taxonomic persistence functions
accept visibility and project_id parameters.
"""

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest
from bson import ObjectId
from mongomem_core.extraction.types import (
    ConsolidationDecision,
    ScoredExtraction,
)
from mongomem_core.models.memory.base import ChunkVisibility


@pytest.fixture
def mock_db():
    """Create a mock MongoDB database."""
    db = MagicMock()

    def collection_factory(name):
        col = MagicMock()
        col.update_one.return_value = MagicMock(upserted_id=ObjectId(), modified_count=0)
        col.insert_one.return_value = MagicMock(inserted_id=ObjectId())
        col.find_one.return_value = None
        return col

    db.__getitem__ = MagicMock(side_effect=collection_factory)
    return db


@pytest.fixture
def sample_decision():
    """Create a sample consolidation decision."""
    scored = ScoredExtraction(
        content="User prefers Python programming",
        citations=[0, 1],
        confidence=0.9,
        citation_score=0.85,
        combined_score=0.87,
        is_valid=True,
        cited_text=[{"text": "I love Python", "idx": 0}],
        embedding=[0.1] * 256,
        metadata={"domain": "preferences"},
    )
    return ConsolidationDecision(
        extraction=scored,
        action="ADD",
        existing_id=None,
        reason="New fact",
    )


class TestSemanticPersistenceVisibility:
    """Tests for semantic persistence visibility/project_id."""

    def test_perform_add_accepts_visibility_param(self, mock_db, sample_decision):
        """perform_add should accept visibility parameter."""
        from mongomem_core.extraction.persistence import (
            perform_add,
        )

        mock_collection = MagicMock()
        mock_collection.update_one.return_value = MagicMock(
            upserted_id=ObjectId(), modified_count=0
        )

        with patch(
            "mongomem_core.extraction.persistence.get_collection",
            return_value=mock_collection,
        ):
            # Should not raise an error when passing visibility
            result = perform_add(
                db=mock_db,
                decision=sample_decision,
                org_id="org-1",
                user_id="user-1",
                source_id="src-1",
                extraction_timestamp=datetime.now(timezone.utc),
                embedding_model_id="model-1",
                visibility=ChunkVisibility.SHARED,
                project_id="group-1",
            )

            # Function should complete successfully
            assert result is not None or result is None  # May return None for dupes
            mock_collection.update_one.assert_called()

    def test_perform_add_defaults_to_private(self, mock_db, sample_decision):
        """perform_add should default to PRIVATE visibility."""
        from mongomem_core.extraction.persistence import (
            perform_add,
        )

        mock_collection = MagicMock()
        mock_collection.update_one.return_value = MagicMock(
            upserted_id=ObjectId(), modified_count=0
        )

        with patch(
            "mongomem_core.extraction.persistence.get_collection",
            return_value=mock_collection,
        ):
            # Call without visibility - should use default
            perform_add(
                db=mock_db,
                decision=sample_decision,
                org_id="org-1",
                user_id="user-1",
                source_id="src-1",
                extraction_timestamp=datetime.now(timezone.utc),
                embedding_model_id="model-1",
            )

            # Function completes without error
            mock_collection.update_one.assert_called()


class TestEpisodicPersistenceVisibility:
    """Tests for episodic persistence visibility/project_id."""

    def test_perform_episodic_add_accepts_visibility_param(self, mock_db, sample_decision):
        """perform_episodic_add should accept visibility parameter."""
        from mongomem_core.extraction.episodic.persistence import (
            perform_episodic_add,
        )

        mock_collection = MagicMock()
        mock_collection.update_one.return_value = MagicMock(
            upserted_id=ObjectId(), modified_count=0
        )

        with patch(
            "mongomem_core.extraction.episodic.persistence.get_collection",
            return_value=mock_collection,
        ):
            result = perform_episodic_add(
                db=mock_db,
                decision=sample_decision,
                org_id="org-1",
                user_id="user-1",
                source_id="src-1",
                extraction_timestamp=datetime.now(timezone.utc),
                embedding_model_id="model-1",
                visibility=ChunkVisibility.ORG,
                project_id=None,
            )

            # Function should complete
            assert result is not None or result is None
            mock_collection.update_one.assert_called()

    def test_perform_episodic_add_with_project_id(self, mock_db, sample_decision):
        """perform_episodic_add should accept project_id parameter."""
        from mongomem_core.extraction.episodic.persistence import (
            perform_episodic_add,
        )

        mock_collection = MagicMock()
        mock_collection.update_one.return_value = MagicMock(
            upserted_id=ObjectId(), modified_count=0
        )

        with patch(
            "mongomem_core.extraction.episodic.persistence.get_collection",
            return_value=mock_collection,
        ):
            result = perform_episodic_add(
                db=mock_db,
                decision=sample_decision,
                org_id="org-1",
                user_id="user-1",
                source_id="src-1",
                extraction_timestamp=datetime.now(timezone.utc),
                embedding_model_id="model-1",
                visibility=ChunkVisibility.SHARED,
                project_id="group-abc",
            )

            assert result is not None or result is None
            mock_collection.update_one.assert_called()


class TestTaxonomicPersistenceVisibility:
    """Tests for taxonomic persistence visibility/project_id."""

    def test_perform_taxonomic_add_accepts_visibility_param(self, mock_db):
        """perform_taxonomic_add should accept visibility parameter."""
        from mongomem_core.extraction.taxonomic.persistence import (
            perform_taxonomic_add,
        )

        # Create a taxonomic-specific decision with proper metadata
        # TaxonomicIn requires evidence_spans for LLM extractions
        scored = ScoredExtraction(
            content="API: Application Programming Interface",
            citations=[0],
            confidence=0.95,
            citation_score=0.9,
            combined_score=0.92,
            is_valid=True,
            cited_text=[{"text": "API stands for Application Programming Interface", "idx": 0}],
            embedding=[0.1] * 256,
            metadata={
                "domain": "software",
                "term": "API",
                "definition": "Application Programming Interface",
                "evidence_spans": [{"text": "API stands for Application Programming Interface"}],
            },
        )
        decision = ConsolidationDecision(
            extraction=scored,
            action="ADD",
            existing_id=None,
            reason="New term",
        )

        mock_doc = MagicMock()
        mock_doc.id = str(ObjectId())

        with patch(
            "mongomem_core.extraction.taxonomic.persistence.upsert_taxonomic",
            return_value=mock_doc,
        ) as mock_upsert:
            result = perform_taxonomic_add(
                db=mock_db,
                decision=decision,
                org_id="org-1",
                user_id="user-1",
                source_id="src-1",
                extraction_timestamp=datetime.now(timezone.utc),
                embedding_model_id="model-1",
                visibility=ChunkVisibility.SHARED,
                project_id="group-1",
            )

            # The function should complete without error (visibility param accepted)
            assert result is not None
            mock_upsert.assert_called_once()
            # Verify visibility was passed through TaxonomicIn
            call_kwargs = mock_upsert.call_args
            taxonomic_in = call_kwargs.kwargs.get("taxonomic_in") or call_kwargs.args[1]
            assert taxonomic_in.visibility == ChunkVisibility.SHARED

    def test_perform_taxonomic_add_defaults_to_org_visibility(self, mock_db):
        """perform_taxonomic_add should default to ORG visibility."""
        from mongomem_core.extraction.taxonomic.persistence import (
            perform_taxonomic_add,
        )

        scored = ScoredExtraction(
            content="SDK: Software Development Kit",
            citations=[0],
            confidence=0.9,
            citation_score=0.85,
            combined_score=0.87,
            is_valid=True,
            cited_text=[{"text": "SDK stands for Software Development Kit", "idx": 0}],
            embedding=[0.1] * 256,
            metadata={
                "domain": "software",
                "term": "SDK",
                "definition": "Software Development Kit",
                "evidence_spans": [{"text": "SDK stands for Software Development Kit"}],
            },
        )
        decision = ConsolidationDecision(
            extraction=scored,
            action="ADD",
            existing_id=None,
            reason="New term",
        )

        mock_doc = MagicMock()
        mock_doc.id = str(ObjectId())

        with patch(
            "mongomem_core.extraction.taxonomic.persistence.upsert_taxonomic",
            return_value=mock_doc,
        ) as mock_upsert:
            # Call without explicit visibility - should use ORG default
            perform_taxonomic_add(
                db=mock_db,
                decision=decision,
                org_id="org-1",
                user_id="user-1",
                source_id="src-1",
                extraction_timestamp=datetime.now(timezone.utc),
                embedding_model_id="model-1",
            )

            # Function should complete (using default ORG visibility)
            mock_upsert.assert_called_once()
            # Verify default ORG visibility was used
            call_kwargs = mock_upsert.call_args
            taxonomic_in = call_kwargs.kwargs.get("taxonomic_in") or call_kwargs.args[1]
            assert taxonomic_in.visibility == ChunkVisibility.ORG
