"""Unit tests for metadata filter models."""

from datetime import datetime

import pytest
from mongomem_core.common.utils import utcnow
from mongomem_core.models.filters import (
    FieldFilter,
    FilterOperator,
    MetadataFilter,
)


class TestFieldFilter:
    """Tests for FieldFilter model."""

    def test_equality_default_operator(self) -> None:
        """Default operator is $eq."""
        f = FieldFilter(field="label", value="python_basics")
        assert f.operator == FilterOperator.EQ
        assert f.to_mongo_condition() == {"label": "python_basics"}

    def test_equality_explicit(self) -> None:
        """Explicit $eq operator works."""
        f = FieldFilter(field="label", operator=FilterOperator.EQ, value="test")
        assert f.to_mongo_condition() == {"label": "test"}

    def test_not_equal(self) -> None:
        """$ne operator."""
        f = FieldFilter(field="status", operator=FilterOperator.NE, value="deleted")
        assert f.to_mongo_condition() == {"status": {"$ne": "deleted"}}

    def test_greater_than(self) -> None:
        """$gt operator."""
        f = FieldFilter(field="version", operator=FilterOperator.GT, value=1)
        assert f.to_mongo_condition() == {"version": {"$gt": 1}}

    def test_greater_than_or_equal(self) -> None:
        """$gte operator."""
        f = FieldFilter(field="version", operator=FilterOperator.GTE, value=2)
        assert f.to_mongo_condition() == {"version": {"$gte": 2}}

    def test_less_than(self) -> None:
        """$lt operator."""
        f = FieldFilter(field="score", operator=FilterOperator.LT, value=0.5)
        assert f.to_mongo_condition() == {"score": {"$lt": 0.5}}

    def test_less_than_or_equal(self) -> None:
        """$lte operator."""
        f = FieldFilter(field="score", operator=FilterOperator.LTE, value=0.8)
        assert f.to_mongo_condition() == {"score": {"$lte": 0.8}}

    def test_in_operator(self) -> None:
        """$in operator for list membership."""
        f = FieldFilter(field="tags", operator=FilterOperator.IN, value=["python", "tutorial"])
        assert f.to_mongo_condition() == {"tags": {"$in": ["python", "tutorial"]}}

    def test_nin_operator(self) -> None:
        """$nin operator for list exclusion."""
        f = FieldFilter(field="status", operator=FilterOperator.NIN, value=["archived", "deleted"])
        assert f.to_mongo_condition() == {"status": {"$nin": ["archived", "deleted"]}}

    def test_exists_true(self) -> None:
        """$exists operator for field presence."""
        f = FieldFilter(field="agent_id", operator=FilterOperator.EXISTS, value=True)
        assert f.to_mongo_condition() == {"agent_id": {"$exists": True}}

    def test_exists_false(self) -> None:
        """$exists operator for field absence."""
        f = FieldFilter(field="deleted_at", operator=FilterOperator.EXISTS, value=False)
        assert f.to_mongo_condition() == {"deleted_at": {"$exists": False}}

    def test_datetime_value(self) -> None:
        """DateTime values work correctly."""
        now = utcnow()
        f = FieldFilter(field="timestamp", operator=FilterOperator.GTE, value=now)
        assert f.to_mongo_condition() == {"timestamp": {"$gte": now}}

    def test_nested_field_path(self) -> None:
        """Nested field paths work."""
        f = FieldFilter(field="metadata.source", value="api")
        assert f.to_mongo_condition() == {"metadata.source": "api"}


class TestMetadataFilter:
    """Tests for MetadataFilter model."""

    def test_empty_filter(self) -> None:
        """Empty filter returns empty dict."""
        mf = MetadataFilter()
        assert mf.is_empty()
        assert mf.to_mongo_filter() == {}

    def test_empty_conditions_list(self) -> None:
        """Empty conditions list returns empty dict."""
        mf = MetadataFilter(conditions=[])
        assert mf.is_empty()
        assert mf.to_mongo_filter() == {}

    def test_single_condition(self) -> None:
        """Single condition works."""
        mf = MetadataFilter(conditions=[FieldFilter(field="label", value="test")])
        assert not mf.is_empty()
        assert mf.to_mongo_filter() == {"label": "test"}

    def test_multiple_conditions_and(self) -> None:
        """Multiple conditions combine with AND."""
        mf = MetadataFilter(
            conditions=[
                FieldFilter(field="version", operator=FilterOperator.GTE, value=2),
                FieldFilter(field="source", value="documentation"),
            ]
        )
        result = mf.to_mongo_filter()
        assert result == {"version": {"$gte": 2}, "source": "documentation"}

    def test_raw_mode_simple(self) -> None:
        """Raw mode passes dict through."""
        raw_filter = {"label": "test", "version": {"$gte": 2}}
        mf = MetadataFilter(raw=raw_filter)
        assert not mf.is_empty()
        assert mf.to_mongo_filter() == raw_filter

    def test_raw_mode_or_query(self) -> None:
        """Raw mode supports $or queries."""
        raw_filter = {
            "$or": [
                {"label": "python_basics"},
                {"tags": {"$in": ["python", "tutorial"]}},
            ]
        }
        mf = MetadataFilter(raw=raw_filter)
        assert mf.to_mongo_filter() == raw_filter

    def test_raw_mode_nested_and(self) -> None:
        """Raw mode supports nested $and queries."""
        raw_filter = {
            "$or": [
                {"label": "python_basics"},
                {"$and": [{"source": "documentation"}, {"version": {"$gte": 2}}]},
            ]
        }
        mf = MetadataFilter(raw=raw_filter)
        assert mf.to_mongo_filter() == raw_filter

    def test_exclusive_validation(self) -> None:
        """Cannot specify both conditions and raw."""
        with pytest.raises(ValueError, match="Cannot specify both"):
            MetadataFilter(
                conditions=[FieldFilter(field="a", value=1)],
                raw={"b": 2},
            )

    def test_duplicate_field_last_wins(self) -> None:
        """For duplicate fields, later conditions take precedence."""
        mf = MetadataFilter(
            conditions=[
                FieldFilter(field="version", value=1),
                FieldFilter(field="version", value=2),
            ]
        )
        assert mf.to_mongo_filter() == {"version": 2}


class TestRawModePatterns:
    """Tests for common raw mode usage patterns."""

    def test_simple_equality(self) -> None:
        """Simple equality using raw mode."""
        mf = MetadataFilter(raw={"label": "python_basics"})
        assert mf.to_mongo_filter() == {"label": "python_basics"}

    def test_multi_field_equality(self) -> None:
        """Multiple fields with equality using raw mode."""
        mf = MetadataFilter(raw={"source": "documentation", "is_latest": True})
        assert mf.to_mongo_filter() == {"source": "documentation", "is_latest": True}

    def test_in_operator(self) -> None:
        """$in operator using raw mode."""
        mf = MetadataFilter(raw={"tags": {"$in": ["python", "tutorial"]}})
        assert mf.to_mongo_filter() == {"tags": {"$in": ["python", "tutorial"]}}

    def test_comparison_operators(self) -> None:
        """Comparison operators using raw mode."""
        mf = MetadataFilter(raw={"version": {"$gte": 2}})
        assert mf.to_mongo_filter() == {"version": {"$gte": 2}}

    def test_exists_operator(self) -> None:
        """$exists operator using raw mode."""
        mf = MetadataFilter(raw={"agent_id": {"$exists": True}})
        assert mf.to_mongo_filter() == {"agent_id": {"$exists": True}}


class TestIntegrationScenarios:
    """Tests for realistic usage scenarios."""

    def test_semantic_memory_filter(self) -> None:
        """Filter scenario for semantic memory search using structured mode."""
        mf = MetadataFilter(
            conditions=[
                FieldFilter(field="label", value="python_basics"),
                FieldFilter(field="is_latest", value=True),
                FieldFilter(field="version", operator=FilterOperator.GTE, value=2),
            ]
        )
        result = mf.to_mongo_filter()
        assert result == {
            "label": "python_basics",
            "is_latest": True,
            "version": {"$gte": 2},
        }

    def test_episodic_memory_filter_by_tags(self) -> None:
        """Filter scenario for episodic memory by tags using raw mode."""
        mf = MetadataFilter(raw={"tags": {"$in": ["meeting", "project-alpha"]}})
        assert mf.to_mongo_filter() == {"tags": {"$in": ["meeting", "project-alpha"]}}

    def test_date_range_filter_structured_limitation(self) -> None:
        """Structured mode has limitation for same-field conditions."""
        start = datetime(2024, 1, 1)
        end = datetime(2024, 12, 31)
        mf = MetadataFilter(
            conditions=[
                FieldFilter(field="timestamp", operator=FilterOperator.GTE, value=start),
                FieldFilter(field="timestamp", operator=FilterOperator.LT, value=end),
            ]
        )
        # Last condition wins - this is a known limitation
        result = mf.to_mongo_filter()
        assert result == {"timestamp": {"$lt": end}}

    def test_date_range_filter_raw_mode(self) -> None:
        """Proper date range filter using raw mode with $and."""
        start = datetime(2024, 1, 1)
        end = datetime(2024, 12, 31)
        mf = MetadataFilter(
            raw={
                "$and": [
                    {"timestamp": {"$gte": start}},
                    {"timestamp": {"$lt": end}},
                ]
            }
        )
        result = mf.to_mongo_filter()
        assert result == {
            "$and": [
                {"timestamp": {"$gte": start}},
                {"timestamp": {"$lt": end}},
            ]
        }

    def test_complex_or_query(self) -> None:
        """Complex OR with nested AND using raw mode."""
        mf = MetadataFilter(
            raw={
                "$or": [
                    {"label": "python_basics"},
                    {
                        "$and": [
                            {"source": "documentation"},
                            {"version": {"$gte": 2}},
                        ]
                    },
                ]
            }
        )
        result = mf.to_mongo_filter()
        assert "$or" in result
        assert len(result["$or"]) == 2

    def test_filter_agent_attributed_memories(self) -> None:
        """Filter for agent-attributed memories using structured mode."""
        mf = MetadataFilter(
            conditions=[
                FieldFilter(field="agent_id", operator=FilterOperator.EXISTS, value=True),
                FieldFilter(field="extraction_source", value="agent_mediated"),
            ]
        )
        result = mf.to_mongo_filter()
        assert result == {
            "agent_id": {"$exists": True},
            "extraction_source": "agent_mediated",
        }

    def test_filter_agent_attributed_memories_raw(self) -> None:
        """Filter for agent-attributed memories using raw mode."""
        mf = MetadataFilter(
            raw={"agent_id": {"$exists": True}, "extraction_source": "agent_mediated"}
        )
        result = mf.to_mongo_filter()
        assert result == {
            "agent_id": {"$exists": True},
            "extraction_source": "agent_mediated",
        }
