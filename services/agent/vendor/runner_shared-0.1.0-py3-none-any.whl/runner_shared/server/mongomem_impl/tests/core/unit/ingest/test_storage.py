"""
Tests for storage backends.

Tests LocalStorage and GCSStorage implementations.
"""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from mongomem_core.ingest.storage.local import LocalStorage


class TestLocalStorage:
    """Tests for LocalStorage backend."""

    def test_supports_local_paths(self):
        """Test that LocalStorage supports local paths."""
        storage = LocalStorage()

        assert storage.supports("/absolute/path/file.pdf") is True
        assert storage.supports("relative/path/file.pdf") is True
        assert storage.supports("./file.pdf") is True
        assert storage.supports("file.pdf") is True

    def test_does_not_support_cloud_uris(self):
        """Test that LocalStorage does not support cloud URIs."""
        storage = LocalStorage()

        assert storage.supports("gs://bucket/file.pdf") is False
        assert storage.supports("s3://bucket/file.pdf") is False
        assert storage.supports("https://example.com/file.pdf") is False

    def test_resolve_existing_file(self, tmp_path: Path):
        """Test resolving an existing local file."""
        storage = LocalStorage()

        test_file = tmp_path / "test.txt"
        test_file.write_text("test content")

        result = storage.resolve(str(test_file))
        assert result == test_file
        assert result.exists()

    def test_resolve_nonexistent_file(self, tmp_path: Path):
        """Test resolving a non-existent file raises error."""
        storage = LocalStorage()

        with pytest.raises(FileNotFoundError):
            storage.resolve(str(tmp_path / "nonexistent.txt"))

    def test_list_files_in_directory(self, tmp_path: Path):
        """Test listing files in a directory."""
        storage = LocalStorage()

        # Create test files
        (tmp_path / "doc1.pdf").touch()
        (tmp_path / "doc2.txt").touch()
        (tmp_path / "image.jpg").touch()
        (tmp_path / "doc3.docx").touch()

        files = storage.list_files(str(tmp_path), {".pdf", ".txt", ".docx"})

        assert len(files) == 3
        assert any("doc1.pdf" in f for f in files)
        assert any("doc2.txt" in f for f in files)
        assert any("doc3.docx" in f for f in files)
        assert not any("image.jpg" in f for f in files)

    def test_list_files_empty_directory(self, tmp_path: Path):
        """Test listing files in an empty directory."""
        storage = LocalStorage()

        files = storage.list_files(str(tmp_path), {".pdf"})
        assert files == []

    def test_cleanup_is_noop(self, tmp_path: Path):
        """Test that cleanup doesn't delete local files."""
        storage = LocalStorage()

        test_file = tmp_path / "test.txt"
        test_file.write_text("content")

        storage.cleanup(test_file)
        assert test_file.exists()  # File should still exist


class TestGCSStorage:
    """Tests for GCSStorage backend."""

    def test_supports_gcs_uris(self):
        """Test that GCSStorage supports gs:// URIs."""
        # Mock the google.cloud.storage import
        with patch.dict("sys.modules", {"google.cloud.storage": MagicMock()}):
            from mongomem_core.ingest.storage.gcs import (
                GCSStorage,
            )

            storage = GCSStorage()

            assert storage.supports("gs://bucket/file.pdf") is True
            assert storage.supports("gs://bucket/path/to/file.pdf") is True

    def test_does_not_support_other_uris(self):
        """Test that GCSStorage does not support other URIs."""
        with patch.dict("sys.modules", {"google.cloud.storage": MagicMock()}):
            from mongomem_core.ingest.storage.gcs import (
                GCSStorage,
            )

            storage = GCSStorage()

            assert storage.supports("/local/path/file.pdf") is False
            assert storage.supports("s3://bucket/file.pdf") is False

    def test_parse_uri(self):
        """Test parsing GCS URIs."""
        with patch.dict("sys.modules", {"google.cloud.storage": MagicMock()}):
            from mongomem_core.ingest.storage.gcs import (
                GCSStorage,
            )

            storage = GCSStorage()

            bucket, path = storage._parse_uri("gs://my-bucket/path/to/file.pdf")
            assert bucket == "my-bucket"
            assert path == "path/to/file.pdf"

            bucket, path = storage._parse_uri("gs://bucket/file.pdf")
            assert bucket == "bucket"
            assert path == "file.pdf"

            bucket, path = storage._parse_uri("gs://bucket/")
            assert bucket == "bucket"
            assert path == ""

    def test_parse_uri_invalid(self):
        """Test parsing invalid URIs raises error."""
        with patch.dict("sys.modules", {"google.cloud.storage": MagicMock()}):
            from mongomem_core.ingest.storage.gcs import (
                GCSStorage,
            )

            storage = GCSStorage()

            with pytest.raises(ValueError, match="Invalid GCS URI"):
                storage._parse_uri("/local/path/file.pdf")


class TestStorageBackendDetection:
    """Tests for automatic backend detection."""

    def test_detect_backend_local(self):
        """Test detecting LocalStorage for local paths."""
        from mongomem_core.ingest.storage import LocalStorage
        from mongomem_core.ingest.storage.base import (
            detect_backend,
        )

        backends = [LocalStorage()]
        backend = detect_backend("/local/file.pdf", backends)

        assert isinstance(backend, LocalStorage)

    def test_detect_backend_no_match(self):
        """Test error when no backend matches."""
        from mongomem_core.ingest.storage import LocalStorage
        from mongomem_core.ingest.storage.base import (
            detect_backend,
        )

        # LocalStorage doesn't support gs://
        backends = [LocalStorage()]

        with pytest.raises(ValueError, match="No storage backend supports URI"):
            detect_backend("gs://bucket/file.pdf", backends)
