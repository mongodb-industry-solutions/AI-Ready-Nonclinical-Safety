"""Unit tests for MemoryMode and mode gating."""

import os

import pytest
from mongomem_core import MemoryEngine, MemoryMode, ModeError
from mongomem_core.modes import require_mode

TEST_MONGO_URI = os.environ.get("TEST_MONGO_URI", "mongodb://localhost:27017")


class TestMemoryModeEnum:
    """Test MemoryMode enum properties."""

    def test_mode_values(self):
        """Modes serialize to lowercase strings."""
        assert MemoryMode.TRADITIONAL.value == "traditional"
        assert MemoryMode.IWM.value == "iwm"
        assert MemoryMode.HYBRID.value == "hybrid"

    def test_uses_stm(self):
        """uses_stm is True for TRADITIONAL and HYBRID."""
        assert MemoryMode.TRADITIONAL.uses_stm is True
        assert MemoryMode.IWM.uses_stm is False
        assert MemoryMode.HYBRID.uses_stm is True

    def test_uses_internal_state(self):
        """uses_internal_state is True for IWM and HYBRID."""
        assert MemoryMode.TRADITIONAL.uses_internal_state is False
        assert MemoryMode.IWM.uses_internal_state is True
        assert MemoryMode.HYBRID.uses_internal_state is True

    def test_requires_is_for_context(self):
        """requires_is_for_context is True only for IWM."""
        assert MemoryMode.TRADITIONAL.requires_is_for_context is False
        assert MemoryMode.IWM.requires_is_for_context is True
        assert MemoryMode.HYBRID.requires_is_for_context is False

    def test_mode_from_string(self):
        """Modes can be created from string values."""
        assert MemoryMode("traditional") == MemoryMode.TRADITIONAL
        assert MemoryMode("iwm") == MemoryMode.IWM
        assert MemoryMode("hybrid") == MemoryMode.HYBRID


class TestRequireMode:
    """Test the require_mode helper."""

    def test_require_mode_passes_when_allowed(self):
        """No error when current mode is in allowed list."""
        # Should not raise
        require_mode(
            MemoryMode.TRADITIONAL,
            [MemoryMode.TRADITIONAL, MemoryMode.HYBRID],
            "write_turn",
        )

    def test_require_mode_raises_when_not_allowed(self):
        """Raises ModeError when current mode is not in allowed list."""
        with pytest.raises(ModeError) as exc_info:
            require_mode(
                MemoryMode.IWM,
                [MemoryMode.TRADITIONAL, MemoryMode.HYBRID],
                "write_turn",
            )

        error = exc_info.value
        assert error.current_mode == MemoryMode.IWM
        assert error.required_modes == [MemoryMode.TRADITIONAL, MemoryMode.HYBRID]
        assert error.method == "write_turn"
        assert "write_turn" in str(error)
        assert "iwm" in str(error).lower()


class TestModeError:
    """Test ModeError exception."""

    def test_mode_error_properties(self):
        """ModeError has correct properties."""
        error = ModeError(
            "test message",
            current_mode=MemoryMode.IWM,
            required_modes=[MemoryMode.TRADITIONAL],
            method="write_turn",
        )

        assert error.current_mode == MemoryMode.IWM
        assert error.required_modes == [MemoryMode.TRADITIONAL]
        assert error.method == "write_turn"
        assert error.fix is not None  # Default fix generated

    def test_mode_error_custom_fix(self):
        """ModeError respects custom fix message."""
        error = ModeError(
            "test message",
            current_mode=MemoryMode.IWM,
            required_modes=[MemoryMode.TRADITIONAL],
            method="write_turn",
            fix="Use a different method",
        )

        assert error.fix == "Use a different method"

    def test_mode_error_str_includes_context(self):
        """Error string includes mode, method, and fix."""
        error = ModeError(
            "write_turn() is not available in iwm mode",
            current_mode=MemoryMode.IWM,
            required_modes=[MemoryMode.TRADITIONAL, MemoryMode.HYBRID],
            method="write_turn",
        )

        error_str = str(error)
        assert "iwm" in error_str.lower()
        assert "traditional" in error_str.lower()
        assert "hybrid" in error_str.lower()
        assert "Fix:" in error_str


class TestEngineMode:
    """Test engine mode configuration."""

    def test_default_mode_is_traditional(self, test_db):
        """Engine defaults to TRADITIONAL mode."""
        from mongomem_core.config import Settings

        settings = Settings(mongo_uri=TEST_MONGO_URI, db_name=test_db.name)
        engine = MemoryEngine(settings)
        assert engine.mode == MemoryMode.TRADITIONAL

    def test_engine_accepts_mode_parameter(self, test_db):
        """Engine accepts mode parameter."""
        from mongomem_core.config import Settings

        settings = Settings(mongo_uri=TEST_MONGO_URI, db_name=test_db.name)
        engine = MemoryEngine(settings, mode=MemoryMode.IWM)
        assert engine.mode == MemoryMode.IWM

    def test_engine_mode_resolver(self, test_db):
        """Engine uses mode resolver when provided."""
        from mongomem_core.config import Settings

        def my_resolver(org_id: str, session_id: str | None) -> MemoryMode:
            if org_id == "iwm_org":
                return MemoryMode.IWM
            return MemoryMode.TRADITIONAL

        settings = Settings(mongo_uri=TEST_MONGO_URI, db_name=test_db.name)

        # V0: mode_resolver is DEPRECATED and IGNORED
        # Engine should emit a DeprecationWarning
        import warnings

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            engine = MemoryEngine(settings, mode=MemoryMode.TRADITIONAL, mode_resolver=my_resolver)

            # Should have one deprecation warning
            assert len(w) == 1
            assert issubclass(w[0].category, DeprecationWarning)
            assert "mode_resolver is deprecated" in str(w[0].message)

        # V0: mode_resolver is IGNORED, engine always returns its fixed mode
        # This is intentional for v0 - no dynamic mode resolution
        assert engine.resolve_mode(org_id="iwm_org", session_id="sess") == MemoryMode.TRADITIONAL
        assert engine.resolve_mode(org_id="other_org", session_id="sess") == MemoryMode.TRADITIONAL

    def test_resolve_mode_without_resolver_returns_default(self, test_db):
        """resolve_mode returns engine mode when no resolver provided."""
        from mongomem_core.config import Settings

        settings = Settings(mongo_uri=TEST_MONGO_URI, db_name=test_db.name)
        engine = MemoryEngine(settings, mode=MemoryMode.HYBRID)

        assert engine.resolve_mode(org_id="any", session_id="any") == MemoryMode.HYBRID


class TestModeGating:
    """Test mode-gated method behavior."""

    def test_write_turn_blocked_in_iwm_mode(self, test_db):
        """write_turn raises ModeError in IWM mode."""
        from mongomem_core.config import Settings

        settings = Settings(mongo_uri=TEST_MONGO_URI, db_name=test_db.name)
        engine = MemoryEngine(settings, mode=MemoryMode.IWM)

        with pytest.raises(ModeError) as exc_info:
            engine.write_turn(
                session_id="sess",
                role="user",
                content="Hello",
                org_id="org",
                user_id="user",
            )

        assert exc_info.value.current_mode == MemoryMode.IWM
        assert exc_info.value.method == "write_turn"

    def test_write_turn_allowed_in_traditional_mode(self, bootstrapped_engine):
        """write_turn works in TRADITIONAL mode."""
        # bootstrapped_engine is TRADITIONAL by default
        result = bootstrapped_engine.write_turn(
            session_id="sess",
            role="user",
            content="Hello",
            org_id="org",
            user_id="user",
        )

        assert result.session_id == "sess"
        assert result.turn_seq == 1

    def test_update_internal_state_blocked_in_traditional_mode(self, bootstrapped_engine):
        """update_internal_state raises ModeError in TRADITIONAL mode."""
        with pytest.raises(ModeError) as exc_info:
            bootstrapped_engine.update_internal_state(
                session_id="sess",
                org_id="org",
                user_id="user",
                content="Agent state",
            )

        assert exc_info.value.current_mode == MemoryMode.TRADITIONAL
        assert exc_info.value.method == "update_internal_state"

    def test_get_internal_state_allowed_in_all_modes(self, test_db):
        """get_internal_state works in all modes (observability)."""
        from mongomem_core.config import Settings

        for mode in [MemoryMode.TRADITIONAL, MemoryMode.IWM, MemoryMode.HYBRID]:
            settings = Settings(mongo_uri=TEST_MONGO_URI, db_name=test_db.name)
            engine = MemoryEngine(settings, mode=mode)
            engine.bootstrap(ensure_search_indexes=False)

            # Should not raise - returns None since no IS exists
            result = engine.get_internal_state(session_id="sess", org_id="org")
            assert result is None
