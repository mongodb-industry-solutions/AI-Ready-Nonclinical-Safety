"""Unit tests for taxonomic memory operations."""

from unittest.mock import MagicMock, patch

import pytest
from mongomem_core.extraction.config import (
    TaxonomicExtractionConfig,
)
from mongomem_core.extraction.taxonomic import (
    TaxonomicExtractor,
    TaxonomicPipeline,
    create_taxonomic_pipeline,
    filter_valid_taxonomic,
    score_taxonomic_batch,
    score_taxonomic_extraction,
)
from mongomem_core.extraction.types import (
    ExtractedItem,
    ScoredExtraction,
)
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.taxonomic import (
    CreationMethod,
    TaxonomicIn,
    TaxonomicUpdate,
)


class TestTaxonomicModels:
    """Tests for taxonomic Pydantic models."""

    def test_taxonomic_in_basic(self):
        """Test basic TaxonomicIn creation."""
        term = TaxonomicIn(
            domain="programming",
            term="Python",
            definition="A high-level programming language.",
        )
        assert term.domain == "programming"
        assert term.term == "Python"
        assert term.definition == "A high-level programming language."
        assert term.query_expansion is True  # Default
        assert term.visibility == ChunkVisibility.ORG  # Default

    def test_taxonomic_in_with_related_terms(self):
        """Test TaxonomicIn with related terms."""
        term = TaxonomicIn(
            domain="programming",
            term="Python",
            definition="A programming language.",
            related_terms=["Java", "JavaScript", "Ruby"],
        )
        assert term.related_terms == ["Java", "JavaScript", "Ruby"]

    def test_taxonomic_in_llm_extraction_requires_evidence(self):
        """Test that LLM extractions require evidence spans."""
        with pytest.raises(ValueError, match="evidence spans"):
            TaxonomicIn(
                domain="test",
                term="test",
                definition="test",
                creation_method=CreationMethod.LLM_EXTRACTION,
                source_agent="gpt-4",
                source_reference="snap_123",
                user_source="user_1",
                # Missing evidence_spans - should fail
            )

    def test_taxonomic_in_llm_extraction_requires_source_agent(self):
        """Test that LLM extractions require source_agent."""
        with pytest.raises(ValueError, match="source agent"):
            TaxonomicIn(
                domain="test",
                term="test",
                definition="test",
                creation_method=CreationMethod.LLM_EXTRACTION,
                evidence_spans=[{"start": 0, "end": 10}],
                source_reference="snap_123",
                user_source="user_1",
                # Missing source_agent - should fail
            )

    def test_taxonomic_in_llm_extraction_requires_source_reference(self):
        """Test that LLM extractions require source_reference."""
        with pytest.raises(ValueError, match="source reference"):
            TaxonomicIn(
                domain="test",
                term="test",
                definition="test",
                creation_method=CreationMethod.LLM_EXTRACTION,
                evidence_spans=[{"start": 0, "end": 10}],
                source_agent="gpt-4",
                user_source="user_1",
                # Missing source_reference - should fail
            )

    def test_taxonomic_in_llm_extraction_requires_user_source(self):
        """Test that LLM extractions require user_source."""
        with pytest.raises(ValueError, match="user source"):
            TaxonomicIn(
                domain="test",
                term="test",
                definition="test",
                creation_method=CreationMethod.LLM_EXTRACTION,
                evidence_spans=[{"start": 0, "end": 10}],
                source_agent="gpt-4",
                source_reference="snap_123",
                # Missing user_source - should fail
            )

    def test_taxonomic_in_llm_extraction_valid(self):
        """Test valid LLM extraction with all required fields."""
        term = TaxonomicIn(
            domain="programming",
            term="async/await",
            definition="Asynchronous programming pattern",
            creation_method=CreationMethod.LLM_EXTRACTION,
            evidence_spans=[{"start": 10, "end": 50, "text": "async/await pattern"}],
            source_agent="gpt-4o",
            source_reference="snap_abc123",
            user_source="user_456",
        )
        assert term.creation_method == CreationMethod.LLM_EXTRACTION
        assert len(term.evidence_spans) == 1

    def test_taxonomic_update_partial(self):
        """Test partial update model."""
        update = TaxonomicUpdate(definition="Updated definition only")
        assert update.definition == "Updated definition only"
        assert update.term is None
        assert update.domain is None


class TestTaxonomicExtractor:
    """Tests for TaxonomicExtractor class."""

    @pytest.fixture
    def mock_llm(self):
        """Mock LLM that returns valid extraction response."""
        llm = MagicMock()
        llm.complete_json.return_value = {
            "terms": [
                {
                    "domain": "programming",
                    "term": "Python",
                    "definition": "A high-level interpreted programming language",
                    "related_terms": ["JavaScript", "Ruby"],
                    "evidence_spans": [{"start": 0, "end": 50}],
                    "confidence_score": 0.95,
                },
                {
                    "domain": "programming",
                    "term": "FastAPI",
                    "definition": "A modern web framework for Python",
                    "related_terms": ["Flask", "Django"],
                    "evidence_spans": [{"start": 60, "end": 100}],
                    "confidence_score": 0.88,
                },
            ]
        }
        return llm

    @pytest.fixture
    def sample_messages(self):
        """Sample conversation messages."""
        return [
            {"role": "user", "content": "Python is a great language. I use FastAPI for APIs."},
            {"role": "assistant", "content": "Yes, FastAPI is excellent for building APIs!"},
        ]

    def test_extract_basic(self, mock_llm, sample_messages):
        """Test basic extraction from messages."""
        extractor = TaxonomicExtractor(mock_llm)

        result = extractor.extract(sample_messages)

        assert len(result) == 2
        assert result[0].metadata["domain"] == "programming"
        assert result[0].metadata["term"] == "Python"
        assert result[0].confidence == 0.95

    def test_extract_empty_messages(self, mock_llm):
        """Test extraction with empty messages."""
        extractor = TaxonomicExtractor(mock_llm)

        result = extractor.extract([])

        assert result == []
        mock_llm.complete_json.assert_not_called()

    def test_extract_no_terms(self, mock_llm, sample_messages):
        """Test extraction when LLM returns no terms."""
        mock_llm.complete_json.return_value = {"terms": []}
        extractor = TaxonomicExtractor(mock_llm)

        result = extractor.extract(sample_messages)

        assert result == []

    def test_extract_llm_failure(self, mock_llm, sample_messages):
        """Test handling of LLM failure."""
        mock_llm.complete_json.side_effect = Exception("LLM error")
        extractor = TaxonomicExtractor(mock_llm)

        result = extractor.extract(sample_messages)

        assert result == []

    def test_extraction_type(self, mock_llm):
        """Test extraction_type property."""
        extractor = TaxonomicExtractor(mock_llm)
        assert extractor.extraction_type == "taxonomic"

    def test_prompt_resolver(self, mock_llm, sample_messages):
        """Test custom prompt resolver is used."""
        custom_prompt = "Custom taxonomic extraction prompt"
        resolver = MagicMock(return_value=custom_prompt)
        extractor = TaxonomicExtractor(mock_llm, prompt_resolver=resolver)

        extractor.extract(sample_messages)

        resolver.assert_called_once()
        call_args = mock_llm.complete_json.call_args
        assert custom_prompt in call_args[1]["prompt"]


class TestTaxonomicScoring:
    """Tests for taxonomic scoring functions."""

    @pytest.fixture
    def config(self):
        """Default taxonomic config."""
        return TaxonomicExtractionConfig()

    def test_score_extraction_with_evidence(self, config):
        """Test scoring with evidence spans."""
        extraction = ExtractedItem(
            content="Python: A programming language",
            citations=[0],
            confidence=0.9,
            metadata={
                "domain": "programming",
                "term": "Python",
                "definition": "A programming language",
                "evidence_spans": [{"start": 0, "end": 20}],
            },
        )

        scored = score_taxonomic_extraction(extraction, config)

        assert scored.is_valid is True
        assert scored.combined_score > 0.5
        assert scored.content == extraction.content
        assert scored.confidence == extraction.confidence

    def test_score_extraction_without_evidence_invalid(self, config):
        """Test scoring without evidence (invalid when required)."""
        config = TaxonomicExtractionConfig(
            evidence_span_required=True,
            min_evidence_spans=1,
        )
        extraction = ExtractedItem(
            content="Python: A programming language",
            citations=[0],
            confidence=0.9,
            metadata={
                "domain": "programming",
                "term": "Python",
                "evidence_spans": [],  # No evidence
            },
        )

        scored = score_taxonomic_extraction(extraction, config)

        assert scored.is_valid is False

    def test_score_batch(self, config):
        """Test batch scoring."""
        extractions = [
            ExtractedItem(
                content=f"Term {i}",
                citations=[0],
                confidence=0.9,
                metadata={"evidence_spans": [{"start": 0, "end": 10}]},
            )
            for i in range(3)
        ]

        scored = score_taxonomic_batch(extractions, config)

        assert len(scored) == 3
        assert all(isinstance(s, ScoredExtraction) for s in scored)

    def test_filter_valid(self, config):
        """Test filtering valid extractions."""
        scored = [
            ScoredExtraction(
                content="Valid",
                citations=[0],
                confidence=0.9,
                citation_score=1.0,
                combined_score=0.8,
                is_valid=True,
            ),
            ScoredExtraction(
                content="Invalid",
                citations=[0],
                confidence=0.3,
                citation_score=0.0,
                combined_score=0.2,
                is_valid=False,
            ),
        ]

        valid = filter_valid_taxonomic(scored)

        assert len(valid) == 1
        assert valid[0].content == "Valid"


class TestTaxonomicPipeline:
    """Tests for TaxonomicPipeline class."""

    @pytest.fixture
    def mock_extractor(self):
        """Mock extractor."""
        extractor = MagicMock()
        extractor.extract.return_value = [
            ExtractedItem(
                content="Python: A programming language",
                citations=[0],
                confidence=0.9,
                metadata={
                    "domain": "programming",
                    "term": "Python",
                    "definition": "A programming language",
                    "evidence_spans": [{"start": 0, "end": 30}],
                },
            )
        ]
        return extractor

    @pytest.fixture
    def mock_consolidator(self):
        """Mock consolidator."""
        from mongomem_core.extraction.types import (
            ConsolidationDecision,
        )

        consolidator = MagicMock()
        extraction = ScoredExtraction(
            content="Python: A programming language",
            citations=[0],
            confidence=0.9,
            citation_score=1.0,
            combined_score=0.9,
            is_valid=True,
            embedding=[0.1, 0.2, 0.3],
        )
        consolidator.process.return_value = [
            ConsolidationDecision(
                extraction=extraction,
                action="ADD",
                reason="new term",
            )
        ]
        return consolidator

    @pytest.fixture
    def mock_embedder(self):
        """Mock embedder."""
        embedder = MagicMock()
        embedder.embed.return_value = [0.1, 0.2, 0.3]
        embedder.model_id = "text-embedding-ada-002"
        return embedder

    @pytest.fixture
    def mock_db(self):
        """Mock database."""
        return MagicMock()

    @pytest.fixture
    def config(self):
        """Default config."""
        return TaxonomicExtractionConfig()

    @pytest.fixture
    def sample_messages(self):
        """Sample messages."""
        return [
            {"role": "user", "content": "Python is great for data science."},
        ]

    def test_run_basic(
        self,
        mock_extractor,
        mock_consolidator,
        mock_embedder,
        mock_db,
        config,
        sample_messages,
    ):
        """Test basic pipeline run."""
        with patch("mongomem_core.extraction.taxonomic.apply_taxonomic_decisions") as mock_apply:
            from mongomem_core.extraction.types import (
                PersistenceResult,
            )

            mock_apply.return_value = PersistenceResult(
                added=1,
                created_ids=["id1"],
            )

            pipeline = TaxonomicPipeline(
                extractor=mock_extractor,
                config=config,
                consolidator=mock_consolidator,
                db=mock_db,
                embedder=mock_embedder,
                embedding_model_id="text-embedding-ada-002",
            )

            result = pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

            assert result.success is True
            assert result.extracted_count == 1
            assert result.stored_count == 1
            assert "id1" in result.created_ids

    def test_run_disabled(
        self,
        mock_extractor,
        mock_consolidator,
        mock_embedder,
        mock_db,
        sample_messages,
    ):
        """Test pipeline when extraction is disabled."""
        config = TaxonomicExtractionConfig(enabled=False)

        pipeline = TaxonomicPipeline(
            extractor=mock_extractor,
            config=config,
            consolidator=mock_consolidator,
            db=mock_db,
            embedder=mock_embedder,
            embedding_model_id="text-embedding-ada-002",
        )

        result = pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

        assert result.success is True
        assert result.extracted_count == 0
        mock_extractor.extract.assert_not_called()

    def test_run_no_extractions(
        self,
        mock_consolidator,
        mock_embedder,
        mock_db,
        config,
        sample_messages,
    ):
        """Test pipeline when no extractions found."""
        mock_extractor = MagicMock()
        mock_extractor.extract.return_value = []

        pipeline = TaxonomicPipeline(
            extractor=mock_extractor,
            config=config,
            consolidator=mock_consolidator,
            db=mock_db,
            embedder=mock_embedder,
            embedding_model_id="text-embedding-ada-002",
        )

        result = pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

        assert result.success is True
        assert result.extracted_count == 0
        mock_consolidator.process.assert_not_called()

    def test_run_error_handling(
        self,
        mock_extractor,
        mock_consolidator,
        mock_embedder,
        mock_db,
        config,
        sample_messages,
    ):
        """Test error handling in pipeline."""
        mock_extractor.extract.side_effect = Exception("Extraction error")

        pipeline = TaxonomicPipeline(
            extractor=mock_extractor,
            config=config,
            consolidator=mock_consolidator,
            db=mock_db,
            embedder=mock_embedder,
            embedding_model_id="text-embedding-ada-002",
        )

        result = pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

        assert result.success is False
        assert len(result.errors) == 1
        assert "Extraction error" in result.errors[0]

    def test_run_limits_extractions(
        self,
        mock_consolidator,
        mock_embedder,
        mock_db,
        sample_messages,
    ):
        """Test that extractions are limited per snapshot."""
        mock_extractor = MagicMock()
        # Return more than limit
        mock_extractor.extract.return_value = [
            ExtractedItem(
                content=f"Term {i}",
                citations=[0],
                confidence=0.9,
                metadata={
                    "domain": "test",
                    "term": f"term{i}",
                    "evidence_spans": [{"start": 0, "end": 10}],
                },
            )
            for i in range(15)
        ]
        config = TaxonomicExtractionConfig(max_terms_per_snapshot=10)

        with patch("mongomem_core.extraction.taxonomic.score_taxonomic_batch") as mock_score:
            mock_score.return_value = []  # Short-circuit

            pipeline = TaxonomicPipeline(
                extractor=mock_extractor,
                config=config,
                consolidator=mock_consolidator,
                db=mock_db,
                embedder=mock_embedder,
                embedding_model_id="text-embedding-ada-002",
            )

            pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

            # score_taxonomic_batch should receive limited list
            call_args = mock_score.call_args
            assert len(call_args[0][0]) == 10

    def test_run_tracks_processing_time(
        self,
        mock_extractor,
        mock_consolidator,
        mock_embedder,
        mock_db,
        config,
        sample_messages,
    ):
        """Test that processing time is tracked."""
        with patch("mongomem_core.extraction.taxonomic.apply_taxonomic_decisions") as mock_apply:
            from mongomem_core.extraction.types import (
                PersistenceResult,
            )

            mock_apply.return_value = PersistenceResult(added=1)

            pipeline = TaxonomicPipeline(
                extractor=mock_extractor,
                config=config,
                consolidator=mock_consolidator,
                db=mock_db,
                embedder=mock_embedder,
                embedding_model_id="text-embedding-ada-002",
            )

            result = pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

            assert result.metadata.processing_time_ms >= 0
            assert result.metadata.extraction_timestamp is not None


class TestCreateTaxonomicPipeline:
    """Tests for create_taxonomic_pipeline factory function."""

    @pytest.fixture
    def mock_db(self):
        """Mock database."""
        return MagicMock()

    @pytest.fixture
    def mock_llm(self):
        """Mock LLM."""
        return MagicMock()

    @pytest.fixture
    def mock_embedder(self):
        """Mock embedder."""
        embedder = MagicMock()
        embedder.model_id = "text-embedding-ada-002"
        return embedder

    def test_creates_pipeline(self, mock_db, mock_llm, mock_embedder):
        """Test basic pipeline creation."""
        pipeline = create_taxonomic_pipeline(
            db=mock_db,
            llm=mock_llm,
            embedder=mock_embedder,
        )

        assert isinstance(pipeline, TaxonomicPipeline)
        assert isinstance(pipeline.extractor, TaxonomicExtractor)

    def test_uses_default_config(self, mock_db, mock_llm, mock_embedder):
        """Test default config is used when not provided."""
        pipeline = create_taxonomic_pipeline(
            db=mock_db,
            llm=mock_llm,
            embedder=mock_embedder,
        )

        assert pipeline.config.enabled is True
        assert pipeline.config.min_combined_score_threshold == 0.6

    def test_uses_custom_config(self, mock_db, mock_llm, mock_embedder):
        """Test custom config is used."""
        config = TaxonomicExtractionConfig(
            min_combined_score_threshold=0.8,
            max_terms_per_snapshot=5,
        )

        pipeline = create_taxonomic_pipeline(
            db=mock_db,
            llm=mock_llm,
            embedder=mock_embedder,
            config=config,
        )

        assert pipeline.config.min_combined_score_threshold == 0.8
        assert pipeline.config.max_terms_per_snapshot == 5

    def test_uses_llm_consolidation_by_default(self, mock_db, mock_llm, mock_embedder):
        """Test LLM-based consolidation is used by default."""
        pipeline = create_taxonomic_pipeline(
            db=mock_db,
            llm=mock_llm,
            embedder=mock_embedder,
        )

        # Use public strategy_type property instead of private _strategy
        assert pipeline.consolidator.strategy_type == "LLMBasedStrategy"

    def test_uses_rule_based_consolidation(self, mock_db, mock_llm, mock_embedder):
        """Test rule-based consolidation option."""
        pipeline = create_taxonomic_pipeline(
            db=mock_db,
            llm=mock_llm,
            embedder=mock_embedder,
            use_llm_consolidation=False,
        )

        # Use public strategy_type property instead of private _strategy
        assert pipeline.consolidator.strategy_type == "RuleBasedStrategy"

    def test_embedding_model_id_captured(self, mock_db, mock_llm, mock_embedder):
        """Test embedding model ID is captured from embedder."""
        mock_embedder.model_id = "custom-embedding-model"

        pipeline = create_taxonomic_pipeline(
            db=mock_db,
            llm=mock_llm,
            embedder=mock_embedder,
        )

        assert pipeline._embedding_model_id == "custom-embedding-model"


class TestTaxonomicExtractionConfig:
    """Tests for TaxonomicExtractionConfig."""

    def test_default_values(self):
        """Test default config values."""
        config = TaxonomicExtractionConfig()

        assert config.enabled is True
        assert config.min_combined_score_threshold == 0.6
        assert config.evidence_weight == 0.5
        assert config.confidence_weight == 0.5
        assert config.evidence_span_required is True
        assert config.min_evidence_spans == 1
        assert config.max_terms_per_snapshot == 10

    def test_custom_values(self):
        """Test custom config values."""
        config = TaxonomicExtractionConfig(
            enabled=False,
            min_combined_score_threshold=0.8,
            max_terms_per_snapshot=20,
        )

        assert config.enabled is False
        assert config.min_combined_score_threshold == 0.8
        assert config.max_terms_per_snapshot == 20
