"""Unit tests for extraction consolidator module."""

from unittest.mock import MagicMock

import pytest
from mongomem_core.extraction.config import (
    SemanticExtractionConfig,
)
from mongomem_core.extraction.consolidator import (
    Consolidator,
    LLMBasedStrategy,
    MemoryIdMapper,
    RuleBasedStrategy,
)
from mongomem_core.extraction.types import (
    ScoredExtraction,
    SimilarMatch,
)


class TestMemoryIdMapper:
    """Tests for MemoryIdMapper class."""

    def test_create_empty(self):
        """Test creating mapper with empty lists."""
        mapper = MemoryIdMapper.create([], [])

        assert mapper.existing_to_temp == {}
        assert mapper.temp_to_existing == {}
        assert mapper.new_to_data == {}

    def test_create_with_existing_memories(self):
        """Test creating mapper with existing memories."""
        existing = [
            SimilarMatch(id="mem1", content="Memory 1", score=0.9),
            SimilarMatch(id="mem2", content="Memory 2", score=0.8),
        ]

        mapper = MemoryIdMapper.create(existing, [])

        assert mapper.existing_to_temp["mem1"] == "existing_0"
        assert mapper.existing_to_temp["mem2"] == "existing_1"
        assert mapper.temp_to_existing["existing_0"] == "mem1"
        assert mapper.temp_to_existing["existing_1"] == "mem2"

    def test_create_with_new_extractions(self):
        """Test creating mapper with new extractions."""
        extractions = [
            ScoredExtraction(
                content="Fact 1",
                citations=[],
                confidence=0.9,
                citation_score=0.0,
                combined_score=0.36,
                is_valid=True,
            ),
            ScoredExtraction(
                content="Fact 2",
                citations=[0],
                confidence=0.8,
                citation_score=1.0,
                combined_score=0.92,
                is_valid=True,
            ),
        ]

        mapper = MemoryIdMapper.create([], extractions)

        assert "new_0" in mapper.new_to_data
        assert "new_1" in mapper.new_to_data
        assert mapper.new_to_data["new_0"].content == "Fact 1"

    def test_valid_ids_properties(self):
        """Test valid ID set properties."""
        existing = [
            SimilarMatch(id="mem1", content="Memory 1", score=0.9),
        ]
        extractions = [
            ScoredExtraction(
                content="Fact 1",
                citations=[],
                confidence=0.9,
                citation_score=0.0,
                combined_score=0.36,
                is_valid=True,
            ),
        ]

        mapper = MemoryIdMapper.create(existing, extractions)

        assert mapper.valid_existing_ids == {"existing_0"}
        assert mapper.valid_new_ids == {"new_0"}

    def test_get_new_extraction(self):
        """Test getting new extraction by temp ID."""
        extraction = ScoredExtraction(
            content="Fact 1",
            citations=[],
            confidence=0.9,
            citation_score=0.0,
            combined_score=0.36,
            is_valid=True,
        )

        mapper = MemoryIdMapper.create([], [extraction])

        assert mapper.get_new_extraction("new_0") is extraction
        assert mapper.get_new_extraction("new_999") is None

    def test_resolve_existing_id(self):
        """Test resolving temp ID to real ObjectID."""
        existing = [SimilarMatch(id="507f1f77bcf86cd799439011", content="M1", score=0.9)]

        mapper = MemoryIdMapper.create(existing, [])

        assert mapper.resolve_existing_id("existing_0") == "507f1f77bcf86cd799439011"
        assert mapper.resolve_existing_id("existing_999") is None


class TestRuleBasedStrategy:
    """Tests for RuleBasedStrategy class."""

    @pytest.fixture
    def strategy(self):
        """Default rule-based strategy."""
        return RuleBasedStrategy(
            reinforce_threshold=0.95,
            update_threshold=0.85,
        )

    @pytest.fixture
    def extraction(self):
        """Sample extraction."""
        return ScoredExtraction(
            content="The user likes Python",
            citations=[0],
            confidence=0.9,
            citation_score=1.0,
            combined_score=0.96,
            is_valid=True,
        )

    def test_add_no_similar(self, strategy, extraction):
        """Test ADD decision when no similar memories exist."""
        decision = strategy.decide(extraction, [])

        assert decision.action == "ADD"
        assert decision.existing_id is None
        assert "no similar" in decision.reason.lower()

    def test_reinforce_high_similarity(self, strategy, extraction):
        """Test REINFORCE decision for high similarity."""
        similar = [SimilarMatch(id="mem1", content="The user likes Python", score=0.97)]

        decision = strategy.decide(extraction, similar)

        assert decision.action == "REINFORCE"
        assert decision.existing_id == "mem1"
        assert "0.97" in decision.reason

    def test_update_medium_similarity(self, strategy, extraction):
        """Test UPDATE decision for medium similarity."""
        similar = [SimilarMatch(id="mem1", content="The user uses Python", score=0.90)]

        decision = strategy.decide(extraction, similar)

        assert decision.action == "UPDATE"
        assert decision.existing_id == "mem1"

    def test_add_low_similarity(self, strategy, extraction):
        """Test ADD decision for low similarity."""
        similar = [SimilarMatch(id="mem1", content="Something different", score=0.60)]

        decision = strategy.decide(extraction, similar)

        assert decision.action == "ADD"
        assert decision.existing_id is None

    def test_selects_best_match(self, strategy, extraction):
        """Test that strategy selects the best matching memory."""
        similar = [
            SimilarMatch(id="mem1", content="Low match", score=0.70),
            SimilarMatch(id="mem2", content="Best match", score=0.96),  # Above reinforce
            SimilarMatch(id="mem3", content="Medium match", score=0.88),
        ]

        decision = strategy.decide(extraction, similar)

        assert decision.action == "REINFORCE"
        assert decision.existing_id == "mem2"


class TestLLMBasedStrategy:
    """Tests for LLMBasedStrategy class."""

    @pytest.fixture
    def mock_llm(self):
        """Mock LLM that returns valid consolidation response."""
        llm = MagicMock()
        llm.complete_json.return_value = {
            "memories": [
                {
                    "id": "new_0",
                    "text": "The user likes Python",
                    "action": "ADD",
                    "existing_memory_id": None,
                }
            ]
        }
        return llm

    @pytest.fixture
    def extraction(self):
        """Sample extraction."""
        return ScoredExtraction(
            content="The user likes Python",
            citations=[0],
            confidence=0.9,
            citation_score=1.0,
            combined_score=0.96,
            is_valid=True,
        )

    def test_add_no_similar(self, mock_llm, extraction):
        """Test ADD decision when no similar memories."""
        strategy = LLMBasedStrategy(mock_llm)

        decisions = strategy.decide_batch([extraction], [])

        assert len(decisions) == 1
        assert decisions[0].action == "ADD"
        # LLM should not be called when no similar memories
        mock_llm.complete_json.assert_not_called()

    def test_llm_called_with_similar(self, mock_llm, extraction):
        """Test LLM is called when similar memories exist."""
        strategy = LLMBasedStrategy(mock_llm)
        similar = [SimilarMatch(id="mem1", content="The user uses Python", score=0.85)]

        strategy.decide_batch([extraction], similar)

        mock_llm.complete_json.assert_called_once()

    def test_parses_update_response(self, extraction):
        """Test parsing UPDATE response from LLM."""
        mock_llm = MagicMock()
        mock_llm.complete_json.return_value = {
            "memories": [
                {
                    "id": "new_0",
                    "text": "The user likes Python a lot",
                    "action": "UPDATE",
                    "existing_memory_id": "existing_0",
                }
            ]
        }
        strategy = LLMBasedStrategy(mock_llm)
        similar = [SimilarMatch(id="mem1", content="The user uses Python", score=0.85)]

        decisions = strategy.decide_batch([extraction], similar)

        assert len(decisions) == 1
        assert decisions[0].action == "UPDATE"
        assert decisions[0].existing_id == "mem1"

    def test_parses_none_as_reinforce(self, extraction):
        """Test that NONE action is mapped to REINFORCE."""
        mock_llm = MagicMock()
        mock_llm.complete_json.return_value = {
            "memories": [
                {
                    "id": "new_0",
                    "text": "The user likes Python",
                    "action": "NONE",
                    "existing_memory_id": "existing_0",
                }
            ]
        }
        strategy = LLMBasedStrategy(mock_llm)
        similar = [SimilarMatch(id="mem1", content="The user likes Python", score=0.95)]

        decisions = strategy.decide_batch([extraction], similar)

        assert decisions[0].action == "REINFORCE"

    def test_handles_invalid_temp_id(self, extraction):
        """Test handling of invalid temp ID in LLM response."""
        mock_llm = MagicMock()
        mock_llm.complete_json.return_value = {
            "memories": [
                {
                    "id": "invalid_id",  # Not in valid_new_ids
                    "text": "Something",
                    "action": "ADD",
                    "existing_memory_id": None,
                }
            ]
        }
        strategy = LLMBasedStrategy(mock_llm)
        similar = [SimilarMatch(id="mem1", content="Memory", score=0.85)]

        decisions = strategy.decide_batch([extraction], similar)

        # Should default to ADD for missing extraction
        assert len(decisions) == 1
        assert decisions[0].action == "ADD"

    def test_llm_failure_fallback(self, extraction):
        """Test fallback to ADD when LLM fails."""
        mock_llm = MagicMock()
        mock_llm.complete_json.side_effect = Exception("LLM error")
        strategy = LLMBasedStrategy(mock_llm)
        similar = [SimilarMatch(id="mem1", content="Memory", score=0.85)]

        decisions = strategy.decide_batch([extraction], similar)

        assert len(decisions) == 1
        assert decisions[0].action == "ADD"
        assert "failed" in decisions[0].reason.lower()

    def test_prompt_resolver(self, mock_llm, extraction):
        """Test custom prompt resolver is used."""
        custom_prompt = "Custom consolidation prompt"
        resolver = MagicMock(return_value=custom_prompt)
        strategy = LLMBasedStrategy(mock_llm, prompt_resolver=resolver)
        similar = [SimilarMatch(id="mem1", content="Memory", score=0.85)]

        strategy.decide_batch([extraction], similar)

        resolver.assert_called_once()
        # Custom prompt should be in the LLM call
        call_args = mock_llm.complete_json.call_args
        assert custom_prompt in call_args[1]["prompt"]


class TestConsolidator:
    """Tests for Consolidator class."""

    @pytest.fixture
    def mock_db(self):
        """Mock database."""
        return MagicMock()

    @pytest.fixture
    def mock_embedder(self):
        """Mock embedder."""
        embedder = MagicMock()
        embedder.embed_batch.return_value = [[0.1, 0.2, 0.3]]
        embedder.embed.return_value = [0.1, 0.2, 0.3]
        return embedder

    @pytest.fixture
    def mock_search_fn(self):
        """Mock search function that returns no results."""
        return MagicMock(return_value=[])

    @pytest.fixture
    def config(self):
        """Default config."""
        return SemanticExtractionConfig()

    @pytest.fixture
    def extraction(self):
        """Sample extraction."""
        return ScoredExtraction(
            content="The user likes Python",
            citations=[0],
            confidence=0.9,
            citation_score=1.0,
            combined_score=0.96,
            is_valid=True,
        )

    def test_empty_extractions(self, mock_db, mock_embedder, mock_search_fn, config):
        """Test processing empty extractions list."""
        strategy = RuleBasedStrategy()
        consolidator = Consolidator(
            db=mock_db,
            embedder=mock_embedder,
            strategy=strategy,
            search_fn=mock_search_fn,
            config=config,
        )

        decisions = consolidator.process([], "org1", "user1")

        assert decisions == []
        mock_embedder.embed_batch.assert_not_called()

    def test_batch_embedding(self, mock_db, mock_embedder, mock_search_fn, config, extraction):
        """Test that batch embedding is used."""
        mock_embedder.embed_batch.return_value = [[0.1, 0.2, 0.3]]
        strategy = RuleBasedStrategy()
        consolidator = Consolidator(
            db=mock_db,
            embedder=mock_embedder,
            strategy=strategy,
            search_fn=mock_search_fn,
            config=config,
        )

        consolidator.process([extraction], "org1", "user1")

        mock_embedder.embed_batch.assert_called_once_with(["The user likes Python"])

    def test_embedding_stored_on_extraction(
        self, mock_db, mock_embedder, mock_search_fn, config, extraction
    ):
        """Test that embedding is stored on extraction."""
        expected_embedding = [0.1, 0.2, 0.3]
        mock_embedder.embed_batch.return_value = [expected_embedding]
        strategy = RuleBasedStrategy()
        consolidator = Consolidator(
            db=mock_db,
            embedder=mock_embedder,
            strategy=strategy,
            search_fn=mock_search_fn,
            config=config,
        )

        consolidator.process([extraction], "org1", "user1")

        assert extraction.embedding == expected_embedding

    def test_search_called_for_each_extraction(self, mock_db, mock_embedder, config):
        """Test that search is called for each extraction."""
        mock_search_fn = MagicMock(return_value=[])
        mock_embedder.embed_batch.return_value = [
            [0.1, 0.2, 0.3],
            [0.4, 0.5, 0.6],
        ]
        extractions = [
            ScoredExtraction(
                content=f"Fact {i}",
                citations=[0],
                confidence=0.9,
                citation_score=1.0,
                combined_score=0.96,
                is_valid=True,
            )
            for i in range(2)
        ]
        strategy = RuleBasedStrategy()
        consolidator = Consolidator(
            db=mock_db,
            embedder=mock_embedder,
            strategy=strategy,
            search_fn=mock_search_fn,
            config=config,
        )

        consolidator.process(extractions, "org1", "user1")

        assert mock_search_fn.call_count == 2

    def test_all_add_when_no_similar(self, mock_db, mock_embedder, mock_search_fn, config):
        """Test all ADD decisions when no similar memories found."""
        mock_embedder.embed_batch.return_value = [[0.1, 0.2], [0.3, 0.4]]
        extractions = [
            ScoredExtraction(
                content=f"Fact {i}",
                citations=[0],
                confidence=0.9,
                citation_score=1.0,
                combined_score=0.96,
                is_valid=True,
            )
            for i in range(2)
        ]
        strategy = RuleBasedStrategy()
        consolidator = Consolidator(
            db=mock_db,
            embedder=mock_embedder,
            strategy=strategy,
            search_fn=mock_search_fn,
            config=config,
        )

        decisions = consolidator.process(extractions, "org1", "user1")

        assert len(decisions) == 2
        assert all(d.action == "ADD" for d in decisions)
