"""
Unit tests for short-term memory models.

These tests validate the Pydantic models for STM.
"""

import pytest
from mongomem_core.models.memory.base import (
    ChunkVisibility,
    MessageRole,
)
from mongomem_core.models.memory.short_term import (
    ShortTermDB,
    ShortTermIn,
    ShortTermOut,
    ToolCall,
    ToolResult,
)
from pydantic import ValidationError


class TestToolCall:
    """Tests for ToolCall model."""

    def test_tool_call_with_dict_arguments(self):
        """ToolCall accepts dict arguments natively."""
        tc = ToolCall(
            name="get_weather",
            arguments={"location": "NYC", "units": "celsius"},
            id="call_123",
        )
        assert tc.name == "get_weather"
        assert tc.arguments == {"location": "NYC", "units": "celsius"}
        assert tc.get_arguments_dict() == {"location": "NYC", "units": "celsius"}

    def test_tool_call_with_json_string_arguments(self):
        """ToolCall accepts JSON string arguments (OpenAI style)."""
        tc = ToolCall(
            name="search",
            arguments='{"query": "python tutorials", "limit": 10}',
            id="call_456",
        )
        assert isinstance(tc.arguments, str)
        assert tc.get_arguments_dict() == {"query": "python tutorials", "limit": 10}
        assert tc.get_arguments_json() == '{"query": "python tutorials", "limit": 10}'

    def test_tool_call_invalid_json_arguments(self):
        """ToolCall handles invalid JSON gracefully."""
        tc = ToolCall(name="test", arguments="not valid json")
        assert tc.get_arguments_dict() == {"raw": "not valid json"}

    def test_tool_call_dict_to_json(self):
        """get_arguments_json serializes dict to JSON."""
        tc = ToolCall(name="test", arguments={"key": "value"})
        assert tc.get_arguments_json() == '{"key": "value"}'

    def test_tool_call_with_provider(self):
        """ToolCall tracks provider metadata."""
        tc = ToolCall(
            name="func",
            arguments={},
            provider="anthropic",
        )
        assert tc.provider == "anthropic"

    def test_tool_call_minimal(self):
        """ToolCall only requires name."""
        tc = ToolCall(name="simple_tool")
        assert tc.name == "simple_tool"
        assert tc.arguments == {}
        assert tc.id is None


class TestToolResult:
    """Tests for ToolResult model."""

    def test_tool_result_basic(self):
        """ToolResult captures tool output."""
        tr = ToolResult(
            tool_call_id="call_123",
            content="Temperature is 72°F",
            name="get_weather",
        )
        assert tr.tool_call_id == "call_123"
        assert tr.content == "Temperature is 72°F"
        assert tr.is_error is False

    def test_tool_result_error(self):
        """ToolResult can represent errors."""
        tr = ToolResult(
            tool_call_id="call_456",
            content="API rate limit exceeded",
            is_error=True,
        )
        assert tr.is_error is True


class TestShortTermIn:
    """Tests for ShortTermIn validation."""

    def test_user_message_valid(self):
        """User message with content is valid."""
        stm = ShortTermIn(
            session_id="sess_123",
            role=MessageRole.USER,
            content="Hello, how are you?",
        )
        assert stm.role == MessageRole.USER
        assert stm.content == "Hello, how are you?"

    def test_user_message_requires_content(self):
        """User message without content raises ValidationError."""
        with pytest.raises(ValidationError) as exc_info:
            ShortTermIn(
                session_id="sess_123",
                role=MessageRole.USER,
                content=None,
            )
        assert "messages must have content" in str(exc_info.value)

    def test_system_message_requires_content(self):
        """System message without content raises ValidationError."""
        with pytest.raises(ValidationError) as exc_info:
            ShortTermIn(
                session_id="sess_123",
                role=MessageRole.SYSTEM,
                content=None,
            )
        assert "messages must have content" in str(exc_info.value)

    def test_assistant_message_with_content(self):
        """Assistant message with content is valid."""
        stm = ShortTermIn(
            session_id="sess_123",
            role=MessageRole.ASSISTANT,
            content="I'm doing well, thank you!",
        )
        assert stm.role == MessageRole.ASSISTANT

    def test_assistant_message_with_tool_calls(self):
        """Assistant message with tool_calls (no content) is valid."""
        stm = ShortTermIn(
            session_id="sess_123",
            role=MessageRole.ASSISTANT,
            content=None,
            tool_calls=[ToolCall(name="get_weather", arguments={"city": "NYC"}, id="call_1")],
        )
        assert stm.content is None
        assert len(stm.tool_calls) == 1

    def test_assistant_message_requires_content_or_tool_calls(self):
        """Assistant message without content or tool_calls raises ValidationError."""
        with pytest.raises(ValidationError) as exc_info:
            ShortTermIn(
                session_id="sess_123",
                role=MessageRole.ASSISTANT,
                content=None,
                tool_calls=None,
            )
        assert "assistant messages must have either content or tool_calls" in str(exc_info.value)

    def test_tool_message_valid(self):
        """Tool message with tool_call_id and content is valid."""
        stm = ShortTermIn(
            session_id="sess_123",
            role=MessageRole.TOOL,
            content="Weather is sunny, 75°F",
            tool_call_id="call_1",
            tool_name="get_weather",
        )
        assert stm.role == MessageRole.TOOL
        assert stm.tool_call_id == "call_1"

    def test_tool_message_requires_tool_call_id(self):
        """Tool message without tool_call_id raises ValidationError."""
        with pytest.raises(ValidationError) as exc_info:
            ShortTermIn(
                session_id="sess_123",
                role=MessageRole.TOOL,
                content="Result",
                tool_call_id=None,
            )
        assert "tool role messages must have tool_call_id" in str(exc_info.value)

    def test_tool_message_requires_content(self):
        """Tool message without content raises ValidationError."""
        with pytest.raises(ValidationError) as exc_info:
            ShortTermIn(
                session_id="sess_123",
                role=MessageRole.TOOL,
                content=None,
                tool_call_id="call_1",
            )
        assert "tool role messages must have content" in str(exc_info.value)

    def test_visibility_shared_requires_project_id(self):
        """Shared visibility requires project_id."""
        with pytest.raises(ValidationError) as exc_info:
            ShortTermIn(
                session_id="sess_123",
                role=MessageRole.USER,
                content="Hello",
                visibility=ChunkVisibility.SHARED,
            )
        assert "project_id" in str(exc_info.value)

    def test_visibility_shared_with_project_id(self):
        """Shared visibility with project_id is valid."""
        stm = ShortTermIn(
            session_id="sess_123",
            role=MessageRole.USER,
            content="Hello team!",
            visibility=ChunkVisibility.SHARED,
            project_id="team_alpha",
        )
        assert stm.visibility == ChunkVisibility.SHARED
        assert stm.project_id == "team_alpha"

    def test_has_embeddings_false_by_default(self):
        """has_embedding is False when no embedding provided."""
        stm = ShortTermIn(
            session_id="sess_123",
            role=MessageRole.USER,
            content="Hello",
        )
        assert stm.has_embedding is False
        assert stm.embedding_present() is False

    def test_has_embeddings_true_when_provided(self):
        """has_embedding is True when embedding provided."""
        stm = ShortTermIn(
            session_id="sess_123",
            role=MessageRole.USER,
            content="Hello",
            embedding=[0.1, 0.2, 0.3],
            has_embedding=True,
        )
        assert stm.embedding_present() is True

    def test_optional_metadata(self):
        """Metadata can be provided."""
        stm = ShortTermIn(
            session_id="sess_123",
            role=MessageRole.USER,
            content="Hello",
            metadata={"source": "web", "priority": 1},
        )
        assert stm.metadata == {"source": "web", "priority": 1}

    def test_agent_id_optional(self):
        """agent_id is optional."""
        stm = ShortTermIn(
            session_id="sess_123",
            role=MessageRole.ASSISTANT,
            content="Response",
            agent_id="agent_007",
        )
        assert stm.agent_id == "agent_007"


class TestShortTermDB:
    """Tests for ShortTermDB model."""

    def test_shortterm_db_defaults(self):
        """ShortTermDB has sensible defaults."""
        stm = ShortTermDB(
            session_id="sess_123",
            role=MessageRole.USER,
            content="Hello",
            org_id="org_1",
            user_id="user_1",
        )
        assert stm.promoted is False
        assert stm.turn_seq == 0
        assert stm.id is not None  # Auto-generated ObjectId
        assert stm.timestamp is not None

    def test_shortterm_db_serializes_id(self):
        """ShortTermDB serializes ObjectId to string in JSON."""
        stm = ShortTermDB(
            session_id="sess_123",
            role=MessageRole.USER,
            content="Hello",
            org_id="org_1",
            user_id="user_1",
        )
        json_data = stm.model_dump(mode="json")
        # In JSON mode, _id should be serialized as string
        assert isinstance(json_data.get("_id") or json_data.get("id"), str)


class TestShortTermOut:
    """Tests for ShortTermOut model."""

    def test_shortterm_out_accepts_string_id(self):
        """ShortTermOut accepts string ID."""
        stm = ShortTermOut(
            _id="507f1f77bcf86cd799439011",
            session_id="sess_123",
            role=MessageRole.USER,
            content="Hello",
            org_id="org_1",
            user_id="user_1",
        )
        assert stm.id == "507f1f77bcf86cd799439011"
        assert stm.promoted is False
        assert stm.turn_seq == 0
