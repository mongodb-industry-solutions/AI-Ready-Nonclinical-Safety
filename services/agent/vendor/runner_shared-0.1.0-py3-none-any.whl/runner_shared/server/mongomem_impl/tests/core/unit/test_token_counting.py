"""
Unit tests for shared token counting utilities.

These tests validate the TokenCounter class, resolve_model_name function,
and MODEL_TYPE_TO_LITELLM mapping used by Budgeter and Formatter.
"""

from unittest.mock import MagicMock, patch

from mongomem_core.common.token_counting import (
    MODEL_TYPE_TO_LITELLM,
    TokenCounter,
    get_token_counter,
    reset_token_counter,
    resolve_model_name,
)
from mongomem_core.models.retrieval import (
    ContextConfig,
    ModelType,
)


class TestResolveModelName:
    """Tests for resolve_model_name function."""

    def test_llm_protocol_priority(self):
        """LLM protocol model_id takes highest priority."""
        config = ContextConfig()

        # Mock LLM with model_id
        mock_llm = MagicMock()
        mock_llm.model_id = "claude-3-opus"

        model_name = resolve_model_name(mock_llm, config)
        assert model_name == "claude-3-opus"

    def test_config_model_type_priority(self):
        """Config model_type is used when LLM not provided."""
        config = ContextConfig(model_type=ModelType.OPENAI)

        model_name = resolve_model_name(None, config)
        assert model_name == "gpt-4"

    def test_config_model_type_when_llm_no_model_id(self):
        """Config model_type is used when LLM has no model_id."""
        config = ContextConfig(model_type=ModelType.GEMINI)

        # Mock LLM without model_id attribute
        mock_llm = MagicMock()
        del mock_llm.model_id

        model_name = resolve_model_name(mock_llm, config)
        assert model_name == "gemini-pro"

    def test_default_fallback(self):
        """Defaults to 'gpt-4' when no model name available."""
        config = ContextConfig()  # No model_type

        model_name = resolve_model_name(None, config)
        assert model_name == "gpt-4"

    def test_llm_with_none_model_id(self):
        """Config model_type is used when LLM model_id is None."""
        config = ContextConfig(model_type=ModelType.CLAUDE)

        # Mock LLM with None model_id
        mock_llm = MagicMock()
        mock_llm.model_id = None

        model_name = resolve_model_name(mock_llm, config)
        assert model_name == "claude-3-opus"

    def test_all_model_types_mapped(self):
        """All ModelType enum values are correctly mapped."""
        test_cases = [
            (ModelType.OPENAI, "gpt-4"),
            (ModelType.CLAUDE, "claude-3-opus"),
            (ModelType.ANTHROPIC, "claude-3-opus"),  # Alias for CLAUDE
            (ModelType.GEMINI, "gemini-pro"),
            (ModelType.GENERIC, "gpt-4"),
        ]

        for model_type, expected_name in test_cases:
            config = ContextConfig(model_type=model_type)
            model_name = resolve_model_name(None, config)
            assert model_name == expected_name, f"Failed for {model_type}"


class TestModelTypeToLiteLLMMapping:
    """Tests for MODEL_TYPE_TO_LITELLM mapping."""

    def test_openai_mapping(self):
        """ModelType.OPENAI maps to 'gpt-4'."""
        assert MODEL_TYPE_TO_LITELLM[ModelType.OPENAI] == "gpt-4"

    def test_claude_mapping(self):
        """ModelType.CLAUDE maps to 'claude-3-opus'."""
        assert MODEL_TYPE_TO_LITELLM[ModelType.CLAUDE] == "claude-3-opus"

    def test_anthropic_mapping(self):
        """ModelType.ANTHROPIC maps to 'claude-3-opus' (alias)."""
        assert MODEL_TYPE_TO_LITELLM[ModelType.ANTHROPIC] == "claude-3-opus"

    def test_gemini_mapping(self):
        """ModelType.GEMINI maps to 'gemini-pro'."""
        assert MODEL_TYPE_TO_LITELLM[ModelType.GEMINI] == "gemini-pro"

    def test_generic_mapping(self):
        """ModelType.GENERIC maps to 'gpt-4'."""
        assert MODEL_TYPE_TO_LITELLM[ModelType.GENERIC] == "gpt-4"


class TestTokenCounterInitialization:
    """Tests for TokenCounter initialization."""

    def test_default_initialization(self):
        """TokenCounter initializes with empty cache."""
        counter = TokenCounter()
        assert counter._cache == {}
        assert isinstance(counter._cache, dict)

    def test_cache_size_property(self):
        """cache_size property returns correct count."""
        counter = TokenCounter()
        assert counter.cache_size == 0

        # Manually add something to cache
        counter._cache["test_key"] = 100
        assert counter.cache_size == 1


class TestTokenCounterCount:
    """Tests for TokenCounter.count method."""

    @patch("mongomem_core.common.token_counting.token_counter")
    def test_count_basic(self, mock_token_counter):
        """Uses token_counter() to count tokens."""
        counter = TokenCounter()
        mock_token_counter.return_value = 10

        result = counter.count("test text", "gpt-4")
        assert result == 10
        mock_token_counter.assert_called_once_with(
            model="gpt-4", messages=[{"role": "user", "content": "test text"}]
        )

    @patch("mongomem_core.common.token_counting.token_counter")
    def test_count_caching(self, mock_token_counter):
        """Token counts are cached per (text, model) combination."""
        counter = TokenCounter()
        mock_token_counter.return_value = 10

        # First call
        result1 = counter.count("test text", "gpt-4")
        assert result1 == 10
        assert mock_token_counter.call_count == 1

        # Second call with same text and model (should use cache)
        result2 = counter.count("test text", "gpt-4")
        assert result2 == 10
        assert mock_token_counter.call_count == 1  # Not called again

        # Different model (should call again)
        result3 = counter.count("test text", "claude-3-opus")
        assert result3 == 10
        assert mock_token_counter.call_count == 2

    @patch("mongomem_core.common.token_counting.token_counter")
    def test_count_fallback_on_error(self, mock_token_counter):
        """Falls back to character-based approximation on LiteLLM errors."""
        counter = TokenCounter()
        mock_token_counter.side_effect = Exception("LiteLLM error")

        result = counter.count("test text", "gpt-4")
        # Character-based fallback: len("test text") // 4 = 9 // 4 = 2, max(1, 2) = 2
        assert result == 2

    @patch("mongomem_core.common.token_counting.token_counter")
    def test_count_fallback_cached(self, mock_token_counter):
        """Fallback token counts are also cached."""
        counter = TokenCounter()
        mock_token_counter.side_effect = Exception("LiteLLM error")

        # First call (fallback)
        result1 = counter.count("test text", "gpt-4")
        assert result1 == 2

        # Second call (should use cached fallback)
        result2 = counter.count("test text", "gpt-4")
        assert result2 == 2
        # Should only be called once (first time)
        assert mock_token_counter.call_count == 1

    @patch("mongomem_core.common.token_counting.token_counter")
    def test_count_empty_text(self, mock_token_counter):
        """Empty text returns 0 without calling token_counter."""
        counter = TokenCounter()
        mock_token_counter.return_value = 0

        result = counter.count("", "gpt-4")
        assert result == 0
        mock_token_counter.assert_not_called()

    @patch("mongomem_core.common.token_counting.token_counter")
    def test_count_cache_key_uniqueness(self, mock_token_counter):
        """Cache keys are unique per (text_hash, model_name) combination."""
        counter = TokenCounter()
        mock_token_counter.return_value = 10

        # Different texts should have different cache entries
        result1 = counter.count("text1", "gpt-4")
        result2 = counter.count("text2", "gpt-4")
        assert result1 == 10
        assert result2 == 10
        assert mock_token_counter.call_count == 2
        assert counter.cache_size == 2


class TestTokenCounterCountMessages:
    """Tests for TokenCounter.count_messages method."""

    @patch("mongomem_core.common.token_counting.token_counter")
    def test_count_messages_basic(self, mock_token_counter):
        """Counts tokens for message list."""
        counter = TokenCounter()
        mock_token_counter.return_value = 25

        messages = [
            {"role": "system", "content": "You are helpful."},
            {"role": "user", "content": "Hello!"},
        ]

        result = counter.count_messages(messages, "gpt-4")
        assert result == 25
        mock_token_counter.assert_called_once_with(model="gpt-4", messages=messages)

    @patch("mongomem_core.common.token_counting.token_counter")
    def test_count_messages_empty(self, mock_token_counter):
        """Empty message list returns 0."""
        counter = TokenCounter()

        result = counter.count_messages([], "gpt-4")
        assert result == 0
        mock_token_counter.assert_not_called()

    @patch("mongomem_core.common.token_counting.token_counter")
    def test_count_messages_caching(self, mock_token_counter):
        """Message token counts are cached."""
        counter = TokenCounter()
        mock_token_counter.return_value = 20

        messages = [{"role": "user", "content": "Hello"}]

        # First call
        result1 = counter.count_messages(messages, "gpt-4")
        assert result1 == 20
        assert mock_token_counter.call_count == 1

        # Second call (cached)
        result2 = counter.count_messages(messages, "gpt-4")
        assert result2 == 20
        assert mock_token_counter.call_count == 1


class TestTokenCounterCountFormatted:
    """Tests for TokenCounter.count_formatted method."""

    @patch("mongomem_core.common.token_counting.token_counter")
    def test_count_formatted_string(self, mock_token_counter):
        """Dispatches to count() for string input."""
        counter = TokenCounter()
        mock_token_counter.return_value = 15

        result = counter.count_formatted("Hello world", "gpt-4")
        assert result == 15

    @patch("mongomem_core.common.token_counting.token_counter")
    def test_count_formatted_list(self, mock_token_counter):
        """Dispatches to count_messages() for list input."""
        counter = TokenCounter()
        mock_token_counter.return_value = 25

        messages = [{"role": "user", "content": "Hello"}]

        result = counter.count_formatted(messages, "gpt-4")
        assert result == 25


class TestTokenCounterClearCache:
    """Tests for TokenCounter.clear_cache method."""

    def test_clear_cache(self):
        """clear_cache() clears the token count cache."""
        counter = TokenCounter()

        # Manually add something to cache
        counter._cache["test_key"] = 100
        assert counter.cache_size > 0

        # Clear cache
        counter.clear_cache()
        assert counter.cache_size == 0


class TestGetTokenCounter:
    """Tests for get_token_counter singleton function."""

    def test_returns_token_counter(self):
        """Returns a TokenCounter instance."""
        counter = get_token_counter()
        assert isinstance(counter, TokenCounter)

    def test_returns_same_instance(self):
        """Returns the same singleton instance."""
        counter1 = get_token_counter()
        counter2 = get_token_counter()
        assert counter1 is counter2


class TestResetTokenCounter:
    """Tests for reset_token_counter function."""

    def test_reset_creates_new_instance(self):
        """reset_token_counter() causes get_token_counter() to return a new instance."""
        counter1 = get_token_counter()

        reset_token_counter()

        counter2 = get_token_counter()
        assert counter1 is not counter2

    def test_reset_clears_cache_state(self):
        """New instance after reset has empty cache."""
        counter = get_token_counter()
        # Add something to the cache
        counter._cache["test_key"] = 100
        assert counter.cache_size > 0

        reset_token_counter()

        new_counter = get_token_counter()
        assert new_counter.cache_size == 0
