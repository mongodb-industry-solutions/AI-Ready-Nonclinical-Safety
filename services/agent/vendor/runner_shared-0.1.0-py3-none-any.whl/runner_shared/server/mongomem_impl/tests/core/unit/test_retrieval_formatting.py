"""
Unit tests for Formatter class.

These tests validate the Formatter class behavior including:
- OpenAI message list format
- Claude XML format with proper escaping
- Jinja2 template rendering with grouped memories
- User preferences injection
- Auto format style detection from LLM
- Token counting and metadata generation
- Edge cases (empty content, empty memories, etc.)
"""

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

from mongomem_core.common.token_counting import TokenCounter
from mongomem_core.models.memory.user_prefs import (
    UserContextMemoryOut,
)
from mongomem_core.models.retrieval import (
    ContextConfig,
    FormatStyle,
    MemoryChunk,
    MemorySource,
    ModelType,
)
from mongomem_core.retrieval.formatting import (
    JINJA2_CONTEXT_TEMPLATE,
    SOURCE_DISPLAY_NAMES,
    Formatter,
)


def _make_memory_chunk(
    id: str,
    content: str = "Test content",
    source: MemorySource = MemorySource.EPISODIC,
    timestamp: datetime = None,
) -> MemoryChunk:
    """Helper to create a MemoryChunk for testing."""
    return MemoryChunk(
        id=id,
        content=content,
        source=source,
        timestamp=timestamp or datetime.now(timezone.utc),
        similarity_score=0.8,
    )


def _make_user_context(
    tone: str = "",
    style: str = "",
    language: str = "",
    preferred_format: str = "",
) -> UserContextMemoryOut:
    """Helper to create a UserContextMemoryOut for testing.

    All preference fields are required by the model (non-optional strings).
    We use empty strings as defaults so tests can specify only the fields they care about.
    The Formatter._build_user_preferences_system_message method handles empty strings gracefully.
    """
    return UserContextMemoryOut(
        id="user_ctx_123",
        org_id="test_org",
        user_id="test_user",
        tone=tone,
        style=style,
        language=language,
        preferred_format=preferred_format,
        source="user_input",
    )


class TestFormatterInitialization:
    """Tests for Formatter initialization."""

    def test_default_initialization(self):
        """Formatter initializes with default TokenCounter."""
        formatter = Formatter()
        assert formatter._token_counter is not None
        assert isinstance(formatter._token_counter, TokenCounter)

    def test_custom_token_counter(self):
        """Formatter accepts custom TokenCounter instance."""
        custom_counter = TokenCounter()
        formatter = Formatter(token_counter=custom_counter)
        assert formatter._token_counter is custom_counter

    def test_uses_shared_singleton_by_default(self):
        """Default initialization uses shared singleton for cache efficiency."""
        formatter1 = Formatter()
        formatter2 = Formatter()
        assert formatter1._token_counter is formatter2._token_counter


class TestFormatOpenAI:
    """Tests for _format_openai method."""

    def test_format_openai_basic(self):
        """OpenAI format produces correct message list structure."""
        formatter = Formatter()
        memories = [
            _make_memory_chunk("mem1", "First memory content"),
            _make_memory_chunk("mem2", "Second memory content"),
        ]

        result = formatter._format_openai(memories, None)

        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0] == {"role": "system", "content": "First memory content"}
        assert result[1] == {"role": "system", "content": "Second memory content"}

    def test_format_openai_with_user_context(self):
        """OpenAI format includes user preferences as first system message."""
        formatter = Formatter()
        memories = [_make_memory_chunk("mem1", "Memory content")]
        user_context = _make_user_context(
            tone="formal",
            style="concise",
            language="en",
        )

        result = formatter._format_openai(memories, user_context)

        assert len(result) == 2
        # First message should be user preferences
        assert result[0]["role"] == "system"
        assert "Tone: formal" in result[0]["content"]
        assert "Style: concise" in result[0]["content"]
        assert "Language: en" in result[0]["content"]
        # Second message should be memory
        assert result[1]["content"] == "Memory content"

    def test_format_openai_empty_content_filtered(self):
        """OpenAI format filters out memories with empty content."""
        formatter = Formatter()
        memories = [
            _make_memory_chunk("mem1", "Valid content"),
            _make_memory_chunk("mem2", ""),  # Empty content
            _make_memory_chunk("mem3", "Another valid content"),
        ]

        result = formatter._format_openai(memories, None)

        assert len(result) == 2
        assert result[0]["content"] == "Valid content"
        assert result[1]["content"] == "Another valid content"

    def test_format_openai_empty_memories(self):
        """OpenAI format handles empty memories list."""
        formatter = Formatter()

        result = formatter._format_openai([], None)

        assert result == []

    def test_format_openai_user_context_only(self):
        """OpenAI format includes user context even with no memories."""
        formatter = Formatter()
        user_context = _make_user_context(tone="friendly")

        result = formatter._format_openai([], user_context)

        assert len(result) == 1
        assert "Tone: friendly" in result[0]["content"]

    def test_format_openai_empty_user_context(self):
        """OpenAI format handles user context with no preferences set."""
        formatter = Formatter()
        memories = [_make_memory_chunk("mem1", "Content")]
        user_context = _make_user_context()  # All empty strings

        result = formatter._format_openai(memories, user_context)

        # Should only have memory, no user context message (all prefs are empty)
        assert len(result) == 1
        assert result[0]["content"] == "Content"


class TestFormatClaude:
    """Tests for _format_claude method."""

    def test_format_claude_basic(self):
        """Claude format produces correct XML structure."""
        formatter = Formatter()
        timestamp = datetime(2024, 1, 15, 10, 30, 0, tzinfo=timezone.utc)
        memories = [
            _make_memory_chunk("mem1", "Memory content", MemorySource.EPISODIC, timestamp),
        ]

        result = formatter._format_claude(memories, None)

        assert isinstance(result, str)
        assert '<memory source="episodic"' in result
        assert "timestamp=" in result
        assert ">Memory content</memory>" in result

    def test_format_claude_xml_escaping(self):
        """Claude format properly escapes XML special characters."""
        formatter = Formatter()
        memories = [
            _make_memory_chunk("mem1", "Content with <brackets> & 'quotes' and \"double quotes\""),
        ]

        result = formatter._format_claude(memories, None)

        # XML special characters should be escaped
        assert "&lt;brackets&gt;" in result
        assert "&amp;" in result
        # Quotes in content are escaped
        assert "Content with" in result

    def test_format_claude_memory_attributes(self):
        """Claude format includes source and timestamp attributes."""
        formatter = Formatter()
        timestamp = datetime(2024, 6, 20, 14, 45, 30, tzinfo=timezone.utc)
        memories = [
            _make_memory_chunk("mem1", "Content", MemorySource.SEMANTIC, timestamp),
        ]

        result = formatter._format_claude(memories, None)

        assert 'source="semantic"' in result
        assert 'timestamp="2024-06-20T14:45:30+00:00"' in result

    def test_format_claude_with_user_context(self):
        """Claude format includes user preferences in XML tags."""
        formatter = Formatter()
        memories = [_make_memory_chunk("mem1", "Memory")]
        user_context = _make_user_context(
            tone="professional",
            style="detailed",
        )

        result = formatter._format_claude(memories, user_context)

        assert "<user_preferences>" in result
        assert "Tone: professional" in result
        assert "Style: detailed" in result
        assert "</user_preferences>" in result

    def test_format_claude_user_preferences_escaped(self):
        """Claude format escapes user preferences content."""
        formatter = Formatter()
        memories = []
        user_context = _make_user_context(tone="<script>alert('xss')</script>")

        result = formatter._format_claude(memories, user_context)

        # XSS attempt should be escaped
        assert "&lt;script&gt;" in result
        assert "<script>" not in result

    def test_format_claude_empty_content_filtered(self):
        """Claude format filters out memories with empty content."""
        formatter = Formatter()
        memories = [
            _make_memory_chunk("mem1", "Valid"),
            _make_memory_chunk("mem2", ""),
            _make_memory_chunk("mem3", "Also valid"),
        ]

        result = formatter._format_claude(memories, None)

        assert result.count("<memory") == 2
        assert "Valid" in result
        assert "Also valid" in result

    def test_format_claude_multiple_sources(self):
        """Claude format handles multiple memory sources."""
        formatter = Formatter()
        memories = [
            _make_memory_chunk("mem1", "STM content", MemorySource.STM),
            _make_memory_chunk("mem2", "Episodic content", MemorySource.EPISODIC),
            _make_memory_chunk("mem3", "Semantic content", MemorySource.SEMANTIC),
        ]

        result = formatter._format_claude(memories, None)

        assert 'source="stm"' in result
        assert 'source="episodic"' in result
        assert 'source="semantic"' in result


class TestFormatJinja2:
    """Tests for _format_jinja2 method."""

    def test_format_jinja2_basic(self):
        """Jinja2 format produces structured markdown."""
        formatter = Formatter()
        memories = [
            _make_memory_chunk("mem1", "Memory content"),
        ]

        result = formatter._format_jinja2(memories, None)

        assert "## Relevant Context" in result
        assert "- Memory content" in result

    def test_format_jinja2_grouping(self):
        """Jinja2 format groups memories by source type."""
        formatter = Formatter()
        memories = [
            _make_memory_chunk("mem1", "STM 1", MemorySource.STM),
            _make_memory_chunk("mem2", "Episodic 1", MemorySource.EPISODIC),
            _make_memory_chunk("mem3", "STM 2", MemorySource.STM),
            _make_memory_chunk("mem4", "Semantic 1", MemorySource.SEMANTIC),
        ]

        result = formatter._format_jinja2(memories, None)

        # Check that groups are created
        assert "### Short-Term Memory" in result
        assert "### Episodic Memory" in result
        assert "### Semantic Memory" in result
        # Check content is in result
        assert "- STM 1" in result
        assert "- STM 2" in result
        assert "- Episodic 1" in result
        assert "- Semantic 1" in result

    def test_format_jinja2_with_user_preferences(self):
        """Jinja2 format includes user preferences section."""
        formatter = Formatter()
        memories = [_make_memory_chunk("mem1", "Content")]
        user_context = _make_user_context(
            tone="casual",
            language="Spanish",
        )

        result = formatter._format_jinja2(memories, user_context)

        assert "### User Preferences" in result
        assert "Tone: casual" in result
        assert "Language: Spanish" in result

    def test_format_jinja2_empty_content_filtered(self):
        """Jinja2 format filters out memories with empty content."""
        formatter = Formatter()
        memories = [
            _make_memory_chunk("mem1", "Valid content", MemorySource.STM),
            _make_memory_chunk("mem2", "", MemorySource.STM),
            _make_memory_chunk("mem3", "More content", MemorySource.STM),
        ]

        result = formatter._format_jinja2(memories, None)

        assert "- Valid content" in result
        assert "- More content" in result
        # Empty content should not create an empty bullet
        lines = result.split("\n")
        empty_bullets = [line for line in lines if line.strip() == "-"]
        assert len(empty_bullets) == 0

    def test_format_jinja2_empty_memories(self):
        """Jinja2 format handles empty memories list."""
        formatter = Formatter()

        result = formatter._format_jinja2([], None)

        assert result == ""

    def test_format_jinja2_source_display_names(self):
        """Jinja2 format uses human-readable source names."""
        formatter = Formatter()
        memories = [
            _make_memory_chunk("mem1", "Content", MemorySource.STM),
        ]

        result = formatter._format_jinja2(memories, None)

        # Should use display name, not raw source value
        assert "### Short-Term Memory" in result
        assert "### stm" not in result


class TestBuildUserPreferencesSystemMessage:
    """Tests for _build_user_preferences_system_message method."""

    def test_build_all_preferences(self):
        """Builds message with all preferences set."""
        formatter = Formatter()
        user_context = _make_user_context(
            tone="formal",
            style="bullet_points",
            language="French",
            preferred_format="markdown",
        )

        result = formatter._build_user_preferences_system_message(user_context)

        assert "Tone: formal" in result
        assert "Style: bullet_points" in result
        assert "Language: French" in result
        assert "Preferred format: markdown" in result

    def test_build_partial_preferences(self):
        """Builds message with only some preferences set."""
        formatter = Formatter()
        user_context = _make_user_context(
            tone="casual",
            language="German",
        )

        result = formatter._build_user_preferences_system_message(user_context)

        assert "Tone: casual" in result
        assert "Language: German" in result
        assert "Style:" not in result
        assert "Preferred format:" not in result

    def test_build_no_preferences(self):
        """Returns empty string when no preferences set."""
        formatter = Formatter()
        user_context = _make_user_context()  # All empty strings

        result = formatter._build_user_preferences_system_message(user_context)

        assert result == ""

    def test_preferences_newline_separated(self):
        """Preferences are separated by newlines."""
        formatter = Formatter()
        user_context = _make_user_context(
            tone="professional",
            style="verbose",
        )

        result = formatter._build_user_preferences_system_message(user_context)

        lines = result.split("\n")
        assert len(lines) == 2
        assert lines[0] == "Tone: professional"
        assert lines[1] == "Style: verbose"


class TestFormatContextIntegration:
    """Integration tests for format_context method."""

    @patch.object(TokenCounter, "count_formatted")
    def test_format_context_openai_style(self, mock_count):
        """format_context produces OpenAI format when configured."""
        mock_count.return_value = 100
        formatter = Formatter(token_counter=TokenCounter())
        config = ContextConfig(format_style=FormatStyle.OPENAI)
        memories = [_make_memory_chunk("mem1", "Content")]

        result = formatter.format_context(memories, config)

        assert isinstance(result.formatted_context, list)
        assert result.formatted_context[0]["role"] == "system"

    @patch.object(TokenCounter, "count_formatted")
    def test_format_context_claude_style(self, mock_count):
        """format_context produces Claude XML format when model_type is CLAUDE.

        Note: Format style is determined by model_type (priority 2) before format_style
        (priority 3) when no LLM is provided. So we need to set model_type=CLAUDE
        to get Claude format output.
        """
        mock_count.return_value = 50
        formatter = Formatter(token_counter=TokenCounter())
        config = ContextConfig(model_type=ModelType.CLAUDE, format_style=FormatStyle.CLAUDE)
        memories = [_make_memory_chunk("mem1", "Content")]

        result = formatter.format_context(memories, config)

        assert isinstance(result.formatted_context, str)
        assert "<memory" in result.formatted_context

    def test_format_jinja2_method_directly(self):
        """_format_jinja2 produces correct Jinja2 template output.

        Note: Since there's no ModelType that maps to JINJA2 format, we test
        the _format_jinja2 method directly. In practice, JINJA2 format is only
        used when explicitly calling the internal method or when a custom LLM
        model_id triggers it.
        """
        formatter = Formatter(token_counter=TokenCounter())
        memories = [_make_memory_chunk("mem1", "Content")]

        result = formatter._format_jinja2(memories, None)

        assert isinstance(result, str)
        assert "## Relevant Context" in result

    @patch.object(TokenCounter, "count_formatted")
    def test_format_context_metadata_token_count(self, mock_count):
        """format_context includes accurate token count in metadata."""
        mock_count.return_value = 150
        formatter = Formatter(token_counter=TokenCounter())
        config = ContextConfig()
        memories = [_make_memory_chunk("mem1", "Content")]

        result = formatter.format_context(memories, config)

        assert result.metadata.token_count == 150
        mock_count.assert_called_once()

    @patch.object(TokenCounter, "count_formatted")
    def test_format_context_metadata_memory_counts(self, mock_count):
        """format_context includes memory counts by source in metadata."""
        mock_count.return_value = 100
        formatter = Formatter(token_counter=TokenCounter())
        config = ContextConfig()
        memories = [
            _make_memory_chunk("mem1", "STM 1", MemorySource.STM),
            _make_memory_chunk("mem2", "STM 2", MemorySource.STM),
            _make_memory_chunk("mem3", "Episodic 1", MemorySource.EPISODIC),
            _make_memory_chunk("mem4", "Semantic 1", MemorySource.SEMANTIC),
        ]

        result = formatter.format_context(memories, config)

        assert result.metadata.memory_counts["stm"] == 2
        assert result.metadata.memory_counts["episodic"] == 1
        assert result.metadata.memory_counts["semantic"] == 1

    @patch.object(TokenCounter, "count_formatted")
    def test_format_context_with_user_context(self, mock_count):
        """format_context passes user_context to format methods."""
        mock_count.return_value = 100
        formatter = Formatter(token_counter=TokenCounter())
        config = ContextConfig(format_style=FormatStyle.OPENAI)
        memories = [_make_memory_chunk("mem1", "Content")]
        user_context = _make_user_context(tone="friendly")

        result = formatter.format_context(memories, config, user_context=user_context)

        # User preferences should be in the formatted output
        messages = result.formatted_context
        assert any("Tone: friendly" in msg["content"] for msg in messages)


class TestAutoFormatDetection:
    """Tests for automatic format style detection from LLM."""

    @patch.object(TokenCounter, "count_formatted")
    def test_auto_format_detection_from_claude_llm(self, mock_count):
        """Format style is auto-detected as Claude from LLM model_id."""
        mock_count.return_value = 100
        formatter = Formatter(token_counter=TokenCounter())
        config = ContextConfig(format_style=FormatStyle.OPENAI)  # Config says OpenAI
        memories = [_make_memory_chunk("mem1", "Content")]

        mock_llm = MagicMock()
        mock_llm.model_id = "claude-3-opus"

        result = formatter.format_context(memories, config, llm=mock_llm)

        # Should use Claude format because LLM is Claude
        assert isinstance(result.formatted_context, str)
        assert "<memory" in result.formatted_context

    @patch.object(TokenCounter, "count_formatted")
    def test_auto_format_detection_from_openai_llm(self, mock_count):
        mock_count.return_value = 100
        formatter = Formatter(token_counter=TokenCounter())
        config = ContextConfig()  # format_style=OPENAI (default), model_type=OPENAI (default)
        memories = [_make_memory_chunk("mem1", "Content")]

        mock_llm = MagicMock()
        mock_llm.model_id = "gpt-4"

        result = formatter.format_context(memories, config, llm=mock_llm)

        # Should use OpenAI format because LLM is GPT (Priority 2: LLM inference)
        assert isinstance(result.formatted_context, list)

    @patch.object(TokenCounter, "count_formatted")
    def test_auto_format_detection_from_gemini_llm(self, mock_count):
        """Format style is auto-detected as OpenAI-compatible from Gemini LLM."""
        mock_count.return_value = 100
        formatter = Formatter(token_counter=TokenCounter())
        config = ContextConfig()
        memories = [_make_memory_chunk("mem1", "Content")]

        mock_llm = MagicMock()
        mock_llm.model_id = "gemini-pro"

        result = formatter.format_context(memories, config, llm=mock_llm)

        # Gemini uses OpenAI-compatible format (message list)
        assert isinstance(result.formatted_context, list)

    @patch.object(TokenCounter, "count_formatted")
    def test_format_detection_fallback_to_config_model_type(self, mock_count):
        mock_count.return_value = 100
        formatter = Formatter(token_counter=TokenCounter())
        config = ContextConfig(model_type=ModelType.CLAUDE, format_style=FormatStyle.CLAUDE)
        memories = [_make_memory_chunk("mem1", "Content")]

        result = formatter.format_context(memories, config, llm=None)
        assert isinstance(result.formatted_context, str)
        assert "<memory" in result.formatted_context

    @patch.object(TokenCounter, "count_formatted")
    def test_explicit_format_style_takes_precedence_over_model_type(self, mock_count):
        """Explicit config.format_style takes precedence over config.model_type.

        The format resolution priority is:
        1. Explicit config.format_style (if different from model_type inference)
        2. Infer from llm.model_id (if provided)
        3. Infer from config.model_type
        4. Fall back to config.format_style default

        This test verifies that when format_style=JINJA2 is explicitly set,
        it takes precedence over the default model_type=OPENAI.
        """
        mock_count.return_value = 100
        formatter = Formatter(token_counter=TokenCounter())
        # format_style=JINJA2 explicitly set, model_type defaults to OPENAI
        config = ContextConfig(format_style=FormatStyle.JINJA2)
        memories = [_make_memory_chunk("mem1", "Content")]

        result = formatter.format_context(memories, config, llm=None)

        # Explicit format_style=JINJA2 takes precedence, so we get Jinja2 format (string)
        assert isinstance(result.formatted_context, str)
        assert "## Relevant Context" in result.formatted_context
        assert "Episodic Memory" in result.formatted_context


class TestFormatterEdgeCases:
    """Tests for edge cases and error handling."""

    @patch.object(TokenCounter, "count_formatted")
    def test_empty_memories_list(self, mock_count):
        """Handles empty memories list gracefully."""
        mock_count.return_value = 0
        formatter = Formatter(token_counter=TokenCounter())
        config = ContextConfig()

        result = formatter.format_context([], config)

        assert result.metadata.memory_counts == {}
        assert result.metadata.token_count == 0

    @patch.object(TokenCounter, "count_formatted")
    def test_jinja2_empty_memories_returns_empty_context(self, mock_count):
        """Jinja2 format should not emit a context header without memories."""
        mock_count.return_value = 0
        formatter = Formatter(token_counter=TokenCounter())
        config = ContextConfig(format_style=FormatStyle.JINJA2)

        result = formatter.format_context([], config)

        assert result.formatted_context == ""
        assert result.metadata.memory_counts == {}
        assert result.metadata.token_count == 0

    @patch.object(TokenCounter, "count_formatted")
    def test_all_memories_empty_content(self, mock_count):
        """Handles all memories having empty content."""
        mock_count.return_value = 10
        formatter = Formatter(token_counter=TokenCounter())
        config = ContextConfig(format_style=FormatStyle.OPENAI)
        memories = [
            _make_memory_chunk("mem1", ""),
            _make_memory_chunk("mem2", ""),
        ]

        result = formatter.format_context(memories, config)

        # OpenAI format should produce empty list (all filtered)
        assert result.formatted_context == []
        # But memory counts still reflect input
        assert result.metadata.memory_counts["episodic"] == 2

    @patch.object(TokenCounter, "count_formatted")
    def test_unicode_content(self, mock_count):
        """Handles unicode content correctly."""
        mock_count.return_value = 50
        formatter = Formatter(token_counter=TokenCounter())
        config = ContextConfig(format_style=FormatStyle.OPENAI)
        memories = [
            _make_memory_chunk("mem1", "日本語テスト 🎉 émojis"),
        ]

        result = formatter.format_context(memories, config)

        assert "日本語テスト" in result.formatted_context[0]["content"]
        assert "🎉" in result.formatted_context[0]["content"]
        assert "émojis" in result.formatted_context[0]["content"]

    @patch.object(TokenCounter, "count_formatted")
    def test_very_long_content(self, mock_count):
        """Handles very long content strings."""
        mock_count.return_value = 10000
        formatter = Formatter(token_counter=TokenCounter())
        config = ContextConfig(format_style=FormatStyle.OPENAI)
        long_content = "x" * 100000  # 100K characters
        memories = [_make_memory_chunk("mem1", long_content)]

        result = formatter.format_context(memories, config)

        assert len(result.formatted_context[0]["content"]) == 100000

    @patch.object(TokenCounter, "count_formatted")
    def test_special_characters_in_content(self, mock_count):
        """Handles special characters in content with XML escaping for Claude format."""
        mock_count.return_value = 50
        formatter = Formatter(token_counter=TokenCounter())
        # Must set model_type=CLAUDE to get Claude format (model_type takes precedence)
        config = ContextConfig(model_type=ModelType.CLAUDE, format_style=FormatStyle.CLAUDE)
        memories = [
            _make_memory_chunk("mem1", "Special: <>&\"'`\\n\\t"),
        ]

        result = formatter.format_context(memories, config)

        # XML special chars should be escaped in Claude format
        assert "&lt;" in result.formatted_context
        assert "&gt;" in result.formatted_context
        assert "&amp;" in result.formatted_context


class TestSourceDisplayNames:
    """Tests for SOURCE_DISPLAY_NAMES constant."""

    def test_source_display_names_defined(self):
        """SOURCE_DISPLAY_NAMES contains expected mappings."""
        assert SOURCE_DISPLAY_NAMES["stm"] == "Short-Term Memory"
        assert SOURCE_DISPLAY_NAMES["episodic"] == "Episodic Memory"
        assert SOURCE_DISPLAY_NAMES["semantic"] == "Semantic Memory"

    def test_source_display_names_coverage(self):
        """All MemorySource values have display names."""
        for source in MemorySource:
            assert source.value in SOURCE_DISPLAY_NAMES


class TestJinja2Template:
    """Tests for JINJA2_CONTEXT_TEMPLATE constant."""

    def test_template_has_required_sections(self):
        """Template contains required sections."""
        assert "## Relevant Context" in JINJA2_CONTEXT_TEMPLATE
        assert "### User Preferences" in JINJA2_CONTEXT_TEMPLATE
        assert "grouped_memories" in JINJA2_CONTEXT_TEMPLATE
        assert "source_display_names" in JINJA2_CONTEXT_TEMPLATE

    def test_template_is_valid_jinja2(self):
        """Template is valid Jinja2 syntax."""
        from jinja2 import Template

        # Should not raise
        template = Template(JINJA2_CONTEXT_TEMPLATE)
        assert template is not None
