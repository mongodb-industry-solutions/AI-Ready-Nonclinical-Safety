"""
Integration tests for fetch_episodic_memories and fetch_semantic_memories.

These tests validate the full integration flow including:
- Real database operations
- Vector search with embeddings
- Deduplication across sources
- Ranking integration
- Pre-fetched memory handling
"""

import pytest
from bson import ObjectId
from mongomem_core.common.utils import utcnow
from mongomem_core.models.memory.episodic import EpisodicOut
from mongomem_core.models.memory.semantic import SemanticOut
from mongomem_core.retrieval.sources import (
    fetch_episodic_memories,
    fetch_semantic_memories,
)


class TestFetchEpisodicIntegration:
    """Integration tests for fetch_episodic_memories."""

    @pytest.mark.vector_search
    def test_fetch_episodic_from_db(self, bootstrapped_engine_with_vector_search):
        """fetch_episodic_memories retrieves from database."""
        engine = bootstrapped_engine_with_vector_search
        db = engine._db
        org_id = "org_test_episodic"
        user_id = "user_1"
        session_id = "sess_123"

        # Create test episodic memory with embedding
        embedding = [0.1] * 1024
        episodic_doc = {
            "_id": ObjectId(),
            "session_id": session_id,
            "title": "Test Episode",
            "snapshot_ref_id": "snap_1",
            "content": "This is a test episodic memory about Python dictionaries.",
            "summary_text": "Episode summary",
            "summary_type": "llm",
            "source_agent": "user",
            "participants": [],
            "tags": [],
            "org_id": org_id,
            "user_id": user_id,
            "visibility": "private",
            "timestamp": utcnow(),
            "embedding": embedding,
            "has_embedding": True,
            "deleted_at": None,
        }
        db.memory_episodic.insert_one(episodic_doc)

        # Create query embedding (similar to document embedding)
        query_embedding = [0.1] * 1024

        # Fetch memories
        chunks = fetch_episodic_memories(
            db=db,
            org_id=org_id,
            query_embedding=query_embedding,
            user_id=user_id,
            top_k=10,
        )

        assert len(chunks) >= 1
        assert any(chunk.id == str(episodic_doc["_id"]) for chunk in chunks)

    def test_fetch_episodic_with_prefetched(self, bootstrapped_engine):
        """fetch_episodic_memories uses pre-fetched memories."""
        engine = bootstrapped_engine
        db = engine._db
        org_id = "org_test_episodic_prefetched"

        # Create pre-fetched episodic memory
        prefetched = EpisodicOut(
            _id="ep_prefetched",
            session_id="sess_123",
            title="Prefetched Episode",
            snapshot_ref_id="snap_1",
            content="Prefetched content",
            summary_text="Summary",
            summary_type="llm",
            source_agent="user",
            participants=[],
            tags=[],
            org_id=org_id,
            user_id="user_1",
            timestamp=utcnow(),
            score=0.85,
        )

        query_embedding = [0.1] * 1024

        # Fetch with pre-fetched (should not query DB)
        chunks = fetch_episodic_memories(
            db=db,
            org_id=org_id,
            query_embedding=query_embedding,
            prefetched=[prefetched],
        )

        assert len(chunks) == 1
        assert chunks[0].id == "ep_prefetched"

    @pytest.mark.vector_search
    def test_fetch_episodic_with_deduplication(self, bootstrapped_engine_with_vector_search):
        """fetch_episodic_memories deduplicates results."""
        engine = bootstrapped_engine_with_vector_search
        db = engine._db
        org_id = "org_test_episodic_dedup"
        user_id = "user_1"

        # Create two episodic memories with same content (duplicates)
        embedding = [0.1] * 1024
        content = "Duplicate content for testing"

        episodic1 = {
            "_id": ObjectId(),
            "session_id": "sess_1",
            "title": "Test 1",
            "snapshot_ref_id": "snap_1",
            "content": content,
            "summary_text": "Summary",
            "summary_type": "llm",
            "source_agent": "user",
            "participants": [],
            "tags": [],
            "org_id": org_id,
            "user_id": user_id,
            "visibility": "private",
            "timestamp": utcnow(),
            "embedding": embedding,
            "has_embedding": True,
            "deleted_at": None,
        }

        episodic2 = {
            "_id": ObjectId(),
            "session_id": "sess_2",
            "title": "Test 2",
            "snapshot_ref_id": "snap_2",
            "content": content,  # Same content
            "summary_text": "Summary",
            "summary_type": "llm",
            "source_agent": "user",
            "participants": [],
            "tags": [],
            "org_id": org_id,
            "user_id": user_id,
            "visibility": "private",
            "timestamp": utcnow(),
            "embedding": embedding,
            "has_embedding": True,
            "deleted_at": None,
        }

        db.memory_episodic.insert_many([episodic1, episodic2])

        query_embedding = [0.1] * 1024

        # Fetch with deduplication
        chunks = fetch_episodic_memories(
            db=db,
            org_id=org_id,
            query_embedding=query_embedding,
            user_id=user_id,
            deduplicate=True,
            top_k=10,
        )

        # Should deduplicate (keep one)
        assert len(chunks) == 1

    @pytest.mark.vector_search
    def test_fetch_episodic_with_rbac_filtering(self, bootstrapped_engine_with_vector_search):
        """fetch_episodic_memories respects RBAC parameters."""
        engine = bootstrapped_engine_with_vector_search
        db = engine._db
        org_id = "org_test_episodic_rbac"
        user_id = "user_1"
        other_user_id = "user_2"

        embedding = [0.1] * 1024

        # Create memory for user_1
        episodic1 = {
            "_id": ObjectId(),
            "session_id": "sess_1",
            "title": "User 1 Memory",
            "snapshot_ref_id": "snap_1",
            "content": "User 1 content",
            "summary_text": "Summary",
            "summary_type": "llm",
            "source_agent": "user",
            "participants": [],
            "tags": [],
            "org_id": org_id,
            "user_id": user_id,
            "visibility": "private",
            "timestamp": utcnow(),
            "embedding": embedding,
            "has_embedding": True,
            "deleted_at": None,
        }

        # Create memory for user_2
        episodic2 = {
            "_id": ObjectId(),
            "session_id": "sess_2",
            "title": "User 2 Memory",
            "snapshot_ref_id": "snap_2",
            "content": "User 2 content",
            "summary_text": "Summary",
            "summary_type": "llm",
            "source_agent": "user",
            "participants": [],
            "tags": [],
            "org_id": org_id,
            "user_id": other_user_id,
            "visibility": "private",
            "timestamp": utcnow(),
            "embedding": embedding,
            "has_embedding": True,
            "deleted_at": None,
        }

        db.memory_episodic.insert_many([episodic1, episodic2])

        query_embedding = [0.1] * 1024

        # Fetch with user_id filter
        chunks = fetch_episodic_memories(
            db=db,
            org_id=org_id,
            query_embedding=query_embedding,
            user_id=user_id,
            top_k=10,
        )

        # Should only return user_1's memory
        assert len(chunks) >= 1
        assert all(chunk.user_id == user_id for chunk in chunks)


class TestFetchSemanticIntegration:
    """Integration tests for fetch_semantic_memories."""

    @pytest.mark.vector_search
    def test_fetch_semantic_from_db(self, bootstrapped_engine_with_vector_search):
        """fetch_semantic_memories retrieves from database."""
        engine = bootstrapped_engine_with_vector_search
        db = engine._db
        org_id = "org_test_semantic"
        user_id = "user_1"

        # Create test semantic memory with embedding
        embedding = [0.1] * 1024
        semantic_doc = {
            "_id": ObjectId(),
            "label": "Test Knowledge",
            "content": "This is a test semantic memory about Python dictionaries.",
            "org_id": org_id,
            "user_id": user_id,
            "visibility": "private",
            "timestamp": utcnow(),
            "embedding": embedding,
            "has_embedding": True,
            "deleted_at": None,
        }
        db.memory_semantic.insert_one(semantic_doc)

        # Create query embedding
        query_embedding = [0.1] * 1024

        # Fetch memories
        chunks = fetch_semantic_memories(
            db=db,
            org_id=org_id,
            query_embedding=query_embedding,
            user_id=user_id,
            top_k=10,
        )

        assert len(chunks) >= 1
        assert any(chunk.id == str(semantic_doc["_id"]) for chunk in chunks)

    def test_fetch_semantic_with_prefetched(self, bootstrapped_engine):
        """fetch_semantic_memories uses pre-fetched memories."""
        engine = bootstrapped_engine
        db = engine._db
        org_id = "org_test_semantic_prefetched"

        # Create pre-fetched semantic memory
        prefetched = SemanticOut(
            _id="sem_prefetched",
            label="Prefetched Knowledge",
            content="Prefetched content",
            org_id=org_id,
            user_id="user_1",
            timestamp=utcnow(),
            score=0.75,
        )

        query_embedding = [0.1] * 1024

        # Fetch with pre-fetched (should not query DB)
        chunks = fetch_semantic_memories(
            db=db,
            org_id=org_id,
            query_embedding=query_embedding,
            prefetched=[prefetched],
        )

        assert len(chunks) == 1
        assert chunks[0].id == "sem_prefetched"

    def test_fetch_semantic_graceful_failure(self, bootstrapped_engine):
        """fetch_semantic_memories returns empty list on DB error."""
        engine = bootstrapped_engine
        db = engine._db
        org_id = "org_test_semantic_failure"

        # Use invalid org_id or cause DB error
        query_embedding = [0.1] * 1024

        # Should not raise, just return empty
        chunks = fetch_semantic_memories(
            db=db,
            org_id=org_id,
            query_embedding=query_embedding,
            top_k=10,
        )

        # Should return empty list (no error raised)
        assert isinstance(chunks, list)

    @pytest.mark.vector_search
    def test_fetch_semantic_with_deduplication(self, bootstrapped_engine_with_vector_search):
        """fetch_semantic_memories deduplicates results."""
        engine = bootstrapped_engine_with_vector_search
        db = engine._db
        org_id = "org_test_semantic_dedup"
        user_id = "user_1"

        # Create two semantic memories with same content (duplicates)
        embedding = [0.1] * 1024
        content = "Duplicate semantic content for testing"

        semantic1 = {
            "_id": ObjectId(),
            "label": "Test 1",
            "content": content,
            "org_id": org_id,
            "user_id": user_id,
            "visibility": "private",
            "timestamp": utcnow(),
            "embedding": embedding,
            "has_embedding": True,
            "deleted_at": None,
        }

        semantic2 = {
            "_id": ObjectId(),
            "label": "Test 2",
            "content": content,  # Same content
            "org_id": org_id,
            "user_id": user_id,
            "visibility": "private",
            "timestamp": utcnow(),
            "embedding": embedding,
            "has_embedding": True,
            "deleted_at": None,
        }

        db.memory_semantic.insert_many([semantic1, semantic2])

        query_embedding = [0.1] * 1024

        # Fetch with deduplication
        chunks = fetch_semantic_memories(
            db=db,
            org_id=org_id,
            query_embedding=query_embedding,
            user_id=user_id,
            deduplicate=True,
            top_k=10,
        )

        # Should deduplicate (keep one)
        assert len(chunks) == 1

    @pytest.mark.vector_search
    def test_fetch_semantic_with_rbac_filtering(self, bootstrapped_engine_with_vector_search):
        """fetch_semantic_memories respects RBAC parameters."""
        engine = bootstrapped_engine_with_vector_search
        db = engine._db
        org_id = "org_test_semantic_rbac"
        user_id = "user_1"
        other_user_id = "user_2"

        embedding = [0.1] * 1024

        # Create memory for user_1
        semantic1 = {
            "_id": ObjectId(),
            "label": "User 1 Knowledge",
            "content": "User 1 content",
            "org_id": org_id,
            "user_id": user_id,
            "visibility": "private",
            "timestamp": utcnow(),
            "embedding": embedding,
            "has_embedding": True,
            "deleted_at": None,
        }

        # Create memory for user_2
        semantic2 = {
            "_id": ObjectId(),
            "label": "User 2 Knowledge",
            "content": "User 2 content",
            "org_id": org_id,
            "user_id": other_user_id,
            "visibility": "private",
            "timestamp": utcnow(),
            "embedding": embedding,
            "has_embedding": True,
            "deleted_at": None,
        }

        db.memory_semantic.insert_many([semantic1, semantic2])

        query_embedding = [0.1] * 1024

        # Fetch with user_id filter
        chunks = fetch_semantic_memories(
            db=db,
            org_id=org_id,
            query_embedding=query_embedding,
            user_id=user_id,
            top_k=10,
        )

        # Should only return user_1's memory
        assert len(chunks) >= 1
        assert all(chunk.user_id == user_id for chunk in chunks)
