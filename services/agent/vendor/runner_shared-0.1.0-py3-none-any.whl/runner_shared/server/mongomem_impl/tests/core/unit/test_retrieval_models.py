"""
Unit tests for retrieval models.

These tests validate the Pydantic models for the retrieval pipeline,
including MemoryChunk conversion methods, ContextConfig validation,
and ContextMetadata helpers.
"""

import pytest
from mongomem_core.common.utils import utcnow
from mongomem_core.models.memory.base import MessageRole
from mongomem_core.models.memory.episodic import EpisodicOut
from mongomem_core.models.memory.semantic import SemanticOut
from mongomem_core.models.memory.short_term import (
    ShortTermOut,
    ToolCall,
)
from mongomem_core.models.retrieval import (
    ContextConfig,
    ContextMetadata,
    ContextResponse,
    FormatStyle,
    MemoryChunk,
    MemorySource,
    ModelType,
)
from pydantic import ValidationError


class TestMemoryChunk:
    """Tests for MemoryChunk model and conversion methods."""

    def test_memory_chunk_basic(self):
        """MemoryChunk can be created directly."""
        chunk = MemoryChunk(
            id="chunk_123",
            content="Test content",
            source=MemorySource.STM,
            timestamp=utcnow(),
        )
        assert chunk.id == "chunk_123"
        assert chunk.content == "Test content"
        assert chunk.source == MemorySource.STM
        assert chunk.embedding is None
        assert chunk.similarity_score is None

    def test_memory_chunk_with_embedding(self):
        """MemoryChunk can include embedding and similarity score."""
        embedding = [0.1, 0.2, 0.3]
        chunk = MemoryChunk(
            id="chunk_123",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=utcnow(),
            embedding=embedding,
            similarity_score=0.95,
        )
        assert chunk.embedding == embedding
        assert chunk.similarity_score == 0.95

    def test_from_short_term_basic(self):
        """from_short_term converts ShortTermOut to MemoryChunk."""
        stm = ShortTermOut(
            _id="stm_123",
            session_id="sess_1",
            role=MessageRole.USER,
            content="Hello, how are you?",
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
        )
        chunk = MemoryChunk.from_short_term(stm)
        assert chunk.id == "stm_123"
        assert chunk.content == "Hello, how are you?"
        assert chunk.source == MemorySource.STM
        assert chunk.timestamp == stm.timestamp
        assert "session_id" in chunk.metadata
        assert chunk.metadata["session_id"] == "sess_1"
        assert chunk.metadata["role"] == "user"

    def test_from_short_term_with_tool_calls(self):
        """from_short_term handles tool calls when content is None."""
        stm = ShortTermOut(
            _id="stm_456",
            session_id="sess_1",
            role=MessageRole.ASSISTANT,
            content=None,
            tool_calls=[ToolCall(name="get_weather", arguments={"city": "NYC"}, id="call_1")],
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
        )
        chunk = MemoryChunk.from_short_term(stm)
        assert "get_weather" in chunk.content
        assert "NYC" in chunk.content
        # Verify lightweight summary structure (not full serialization)
        assert chunk.metadata["tool_calls"] is not None
        assert chunk.metadata["tool_calls"]["tool_calls_count"] == 1
        assert "get_weather" in chunk.metadata["tool_calls"]["tool_names"]
        assert "call_1" in chunk.metadata["tool_calls"]["tool_call_ids"]

    def test_from_short_term_with_similarity_score(self):
        """from_short_term accepts optional similarity_score parameter."""
        stm = ShortTermOut(
            _id="stm_789",
            session_id="sess_1",
            role=MessageRole.USER,
            content="Test",
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
        )
        chunk = MemoryChunk.from_short_term(stm, similarity_score=0.87)
        assert chunk.similarity_score == 0.87

    def test_from_short_term_with_embedding(self):
        """from_short_term preserves embedding if present."""
        stm = ShortTermOut(
            _id="stm_emb",
            session_id="sess_1",
            role=MessageRole.USER,
            content="Test",
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
            embedding=[0.1, 0.2, 0.3],
            has_embedding=True,
        )
        chunk = MemoryChunk.from_short_term(stm)
        assert chunk.embedding == [0.1, 0.2, 0.3]

    def test_from_episodic_basic(self):
        """from_episodic converts EpisodicOut to MemoryChunk."""
        episodic = EpisodicOut(
            _id="ep_123",
            session_id="sess_1",
            title="Python Discussion",
            snapshot_ref_id="snap_1",
            content="Full content here",
            summary_text="Summary of Python discussion",
            summary_type="llm",
            source_agent="user",
            participants=["user_1", "agent_1"],
            tags=["python", "tutorial"],
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
        )
        chunk = MemoryChunk.from_episodic(episodic)
        assert chunk.id == "ep_123"
        assert chunk.content == "Summary of Python discussion"  # Prefers summary_text
        assert chunk.source == MemorySource.EPISODIC
        assert chunk.metadata["title"] == "Python Discussion"
        assert chunk.metadata["session_id"] == "sess_1"
        assert chunk.metadata["participants"] == ["user_1", "agent_1"]
        assert chunk.metadata["tags"] == ["python", "tutorial"]

    def test_from_episodic_fallback_to_content(self):
        """from_episodic falls back to content if summary_text is empty."""
        episodic = EpisodicOut(
            _id="ep_456",
            session_id="sess_1",
            title="Test",
            snapshot_ref_id="snap_1",
            content="Full content here",
            summary_text="",  # Empty summary
            summary_type="llm",
            source_agent="user",
            participants=[],
            tags=[],
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
        )
        chunk = MemoryChunk.from_episodic(episodic)
        assert chunk.content == "Full content here"

    def test_from_episodic_with_similarity_score(self):
        """from_episodic accepts optional similarity_score parameter."""
        episodic = EpisodicOut(
            _id="ep_789",
            session_id="sess_1",
            title="Test",
            snapshot_ref_id="snap_1",
            content="Test",
            summary_text="Test",
            summary_type="llm",
            source_agent="user",
            participants=[],
            tags=[],
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
        )
        chunk = MemoryChunk.from_episodic(episodic, similarity_score=0.92)
        assert chunk.similarity_score == 0.92

    def test_from_semantic_basic(self):
        """from_semantic converts SemanticOut to MemoryChunk."""
        semantic = SemanticOut(
            _id="sem_123",
            label="Python Best Practices",
            content="Always use type hints and docstrings",
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
        )
        chunk = MemoryChunk.from_semantic(semantic)
        assert chunk.id == "sem_123"
        assert chunk.content == "Always use type hints and docstrings"
        assert chunk.source == MemorySource.SEMANTIC
        assert chunk.metadata["label"] == "Python Best Practices"
        assert chunk.metadata["version"] == 1
        assert chunk.metadata["is_latest"] is True

    def test_from_semantic_with_optional_fields(self):
        """from_semantic includes optional fields in metadata."""
        semantic = SemanticOut(
            _id="sem_456",
            label="Test",
            content="Test content",
            source="document.pdf",
            contextual_metadata={"page": 42},
            agent_id="agent_1",
            extraction_source="agent_mediated",
            memory_lineage_id="lineage_123",
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
        )
        chunk = MemoryChunk.from_semantic(semantic)
        assert chunk.metadata["source"] == "document.pdf"
        assert chunk.metadata["contextual_metadata"] == {"page": 42}
        assert chunk.metadata["agent_id"] == "agent_1"
        assert chunk.metadata["extraction_source"] == "agent_mediated"
        assert chunk.metadata["memory_lineage_id"] == "lineage_123"

    def test_from_semantic_with_similarity_score(self):
        """from_semantic accepts optional similarity_score parameter."""
        semantic = SemanticOut(
            _id="sem_789",
            label="Test",
            content="Test",
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
        )
        chunk = MemoryChunk.from_semantic(semantic, similarity_score=0.88)
        assert chunk.similarity_score == 0.88


class TestContextConfig:
    """Tests for ContextConfig model and validation."""

    def test_context_config_defaults(self):
        """ContextConfig has sensible defaults."""
        config = ContextConfig()
        assert config.max_tokens == 16000
        assert config.format_style == FormatStyle.OPENAI
        assert config.model_type == ModelType.OPENAI
        assert config.similarity_threshold == 0.0
        assert config.ranking_weights == {}
        # Default enabled_sources includes EPISODIC and SEMANTIC (not STM)
        assert MemorySource.EPISODIC in config.enabled_sources
        assert MemorySource.SEMANTIC in config.enabled_sources
        assert MemorySource.STM not in config.enabled_sources

    def test_context_config_custom_values(self):
        """ContextConfig accepts custom values."""
        config = ContextConfig(
            max_tokens=4096,
            format_style=FormatStyle.CLAUDE,
            model_type=ModelType.CLAUDE,
            similarity_threshold=0.5,
            ranking_weights={"recency": 0.3, "relevance": 0.7},
            enabled_sources={MemorySource.STM, MemorySource.EPISODIC},
        )
        assert config.max_tokens == 4096
        assert config.format_style == FormatStyle.CLAUDE
        assert config.model_type == ModelType.CLAUDE
        assert config.similarity_threshold == 0.5
        assert config.ranking_weights == {"recency": 0.3, "relevance": 0.7}
        assert MemorySource.SEMANTIC not in config.enabled_sources

    def test_context_config_enabled_sources_from_strings(self):
        """ContextConfig accepts string literals for enabled_sources."""
        config = ContextConfig(enabled_sources=["stm", "episodic"])
        assert MemorySource.STM in config.enabled_sources
        assert MemorySource.EPISODIC in config.enabled_sources
        assert MemorySource.SEMANTIC not in config.enabled_sources

    def test_context_config_max_tokens_validation(self):
        """ContextConfig validates max_tokens is positive."""
        with pytest.raises(ValidationError) as exc_info:
            ContextConfig(max_tokens=0)
        assert "greater than or equal to 1" in str(exc_info.value)

    def test_context_config_similarity_threshold_range(self):
        """ContextConfig validates similarity_threshold is in [0.0, 1.0]."""
        # Valid: 0.0
        config = ContextConfig(similarity_threshold=0.0)
        assert config.similarity_threshold == 0.0

        # Valid: 1.0
        config = ContextConfig(similarity_threshold=1.0)
        assert config.similarity_threshold == 1.0

        # Invalid: negative
        with pytest.raises(ValidationError):
            ContextConfig(similarity_threshold=-0.1)

        # Invalid: > 1.0
        with pytest.raises(ValidationError):
            ContextConfig(similarity_threshold=1.1)

    def test_context_config_enabled_sources_cannot_be_empty(self):
        """ContextConfig requires at least one enabled source."""
        with pytest.raises(ValidationError) as exc_info:
            ContextConfig(enabled_sources=set())
        assert "enabled_sources cannot be empty" in str(exc_info.value)


class TestContextMetadata:
    """Tests for ContextMetadata model and helper methods."""

    def test_context_metadata_defaults(self):
        """ContextMetadata has sensible defaults."""
        metadata = ContextMetadata()
        assert metadata.token_count == 0
        assert metadata.memory_counts == {}
        assert metadata.timing == {}

    def test_context_metadata_custom_values(self):
        """ContextMetadata accepts custom values."""
        metadata = ContextMetadata(
            token_count=1500,
            memory_counts={"stm": 5, "episodic": 3, "semantic": 2},
            timing={"retrieval": 0.15, "formatting": 0.02},
        )
        assert metadata.token_count == 1500
        assert metadata.memory_counts == {"stm": 5, "episodic": 3, "semantic": 2}
        assert metadata.timing == {"retrieval": 0.15, "formatting": 0.02}

    def test_add_timing(self):
        """add_timing adds timing information."""
        metadata = ContextMetadata()
        metadata.add_timing("retrieval", 0.15)
        metadata.add_timing("formatting", 0.02)
        assert metadata.timing["retrieval"] == 0.15
        assert metadata.timing["formatting"] == 0.02

    def test_increment_memory_count(self):
        """increment_memory_count increments counts by source."""
        metadata = ContextMetadata()
        metadata.increment_memory_count(MemorySource.STM)
        metadata.increment_memory_count(MemorySource.STM)
        metadata.increment_memory_count(MemorySource.EPISODIC)
        assert metadata.memory_counts["stm"] == 2
        assert metadata.memory_counts["episodic"] == 1

    def test_increment_memory_count_with_string(self):
        """increment_memory_count accepts string source names."""
        metadata = ContextMetadata()
        metadata.increment_memory_count("stm")
        metadata.increment_memory_count("semantic")
        assert metadata.memory_counts["stm"] == 1
        assert metadata.memory_counts["semantic"] == 1

    def test_token_count_validation(self):
        """ContextMetadata validates token_count is non-negative."""
        metadata = ContextMetadata(token_count=100)
        assert metadata.token_count == 100

        with pytest.raises(ValidationError):
            ContextMetadata(token_count=-1)


class TestContextResponse:
    """Tests for ContextResponse model."""

    def test_context_response_with_string(self):
        """ContextResponse accepts string formatted_context."""
        metadata = ContextMetadata(token_count=100)
        response = ContextResponse(
            formatted_context="System: You are a helpful assistant...",
            metadata=metadata,
        )
        assert isinstance(response.formatted_context, str)
        assert response.metadata.token_count == 100

    def test_context_response_with_list(self):
        """ContextResponse accepts list formatted_context (OpenAI format)."""
        metadata = ContextMetadata(token_count=200)
        formatted = [
            {"role": "system", "content": "You are helpful"},
            {"role": "user", "content": "Hello"},
        ]
        response = ContextResponse(formatted_context=formatted, metadata=metadata)
        assert isinstance(response.formatted_context, list)
        assert len(response.formatted_context) == 2
        assert response.formatted_context[0]["role"] == "system"
