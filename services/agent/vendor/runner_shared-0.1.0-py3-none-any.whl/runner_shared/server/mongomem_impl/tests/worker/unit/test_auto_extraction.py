"""
Tests for auto-extraction feature.

Tests:
- WorkerConfig factory methods (auto_extraction, manual)
- Config validation and properties
- Change stream watcher triggering
- End-to-end extraction flow
"""

import logging
from unittest.mock import MagicMock, patch

import pytest

from runner_shared.server.mongomem_impl.src.mongomem_worker.config import (
    ExtractionConfig,
    WorkerConfig,
)


class TestWorkerConfigFactories:
    """Test WorkerConfig factory methods for 10/10 DX."""

    def test_auto_extraction_defaults_to_semantic(self):
        """auto_extraction() should enable semantic by default."""
        mock_llm = MagicMock()

        config = WorkerConfig.auto_extraction(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            llm=mock_llm,
        )

        assert config.auto_extract_on_snapshot is True
        assert config.extraction_mode == "auto"
        assert "semantic" in config.enabled_extractions
        assert config.semantic.enabled is True

    def test_auto_extraction_with_multiple_types(self):
        """auto_extraction() should enable specified types."""
        mock_llm = MagicMock()

        config = WorkerConfig.auto_extraction(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            llm=mock_llm,
            extractions=["semantic", "taxonomic", "episodic"],
        )

        # Check that the specified types are enabled
        assert config.semantic.enabled is True
        assert config.taxonomic.enabled is True
        assert config.episodic.enabled is True
        # Entity should stay with default (enabled=False since ExtractionConfig default)
        # Unless LLM is passed, is_extraction_enabled checks llm presence too

    def test_auto_extraction_validates_types(self):
        """auto_extraction() should reject invalid extraction types."""
        mock_llm = MagicMock()

        with pytest.raises(ValueError) as exc_info:
            WorkerConfig.auto_extraction(
                mongo_uri="mongodb://localhost:27017",
                db_name="test_db",
                llm=mock_llm,
                extractions=["semantic", "invalid_type"],
            )

        assert "invalid_type" in str(exc_info.value)
        assert "Valid options" in str(exc_info.value)

    def test_manual_factory(self):
        """manual() should create config with auto mode disabled."""
        mock_llm = MagicMock()

        config = WorkerConfig.manual(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            llm=mock_llm,
        )

        assert config.auto_extract_on_snapshot is False
        assert config.extraction_mode == "manual"

    def test_manual_factory_without_llm(self):
        """manual() should work without LLM (for embedding-only workers)."""
        config = WorkerConfig.manual(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
        )

        assert config.llm is None
        assert config.extraction_mode == "manual"


class TestWorkerConfigProperties:
    """Test WorkerConfig computed properties."""

    def test_extraction_mode_auto(self):
        """extraction_mode should return 'auto' when enabled."""
        config = WorkerConfig(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            auto_extract_on_snapshot=True,
        )
        assert config.extraction_mode == "auto"

    def test_extraction_mode_manual(self):
        """extraction_mode should return 'manual' when disabled."""
        config = WorkerConfig(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            auto_extract_on_snapshot=False,
        )
        assert config.extraction_mode == "manual"

    def test_enabled_extractions_with_llm(self):
        """enabled_extractions should only include types with LLM."""
        mock_llm = MagicMock()

        config = WorkerConfig(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            llm=mock_llm,
            semantic=ExtractionConfig(enabled=True),
            taxonomic=ExtractionConfig(enabled=True),
            episodic=ExtractionConfig(enabled=False),
        )

        assert "semantic" in config.enabled_extractions
        assert "taxonomic" in config.enabled_extractions
        assert "episodic" not in config.enabled_extractions

    def test_enabled_extractions_without_llm(self):
        """enabled_extractions should be empty without LLM."""
        config = WorkerConfig(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            semantic=ExtractionConfig(enabled=True),
        )

        # No LLM, so nothing is truly enabled
        assert config.enabled_extractions == []


class TestWorkerConfigValidation:
    """Test WorkerConfig validation."""

    def test_post_init_warns_auto_without_extractions(self, caplog):
        """Should warn if auto mode but no extractions enabled."""
        with caplog.at_level(logging.WARNING):
            WorkerConfig(
                mongo_uri="mongodb://localhost:27017",
                db_name="test_db",
                auto_extract_on_snapshot=True,
                # No LLM, no extractions enabled
            )

        assert "auto_extract_on_snapshot=True but no extractions are enabled" in caplog.text

    def test_post_init_warns_auto_without_change_streams(self, caplog):
        """Should warn if auto mode but change streams disabled."""
        mock_llm = MagicMock()

        with caplog.at_level(logging.WARNING):
            WorkerConfig(
                mongo_uri="mongodb://localhost:27017",
                db_name="test_db",
                llm=mock_llm,
                auto_extract_on_snapshot=True,
                enable_change_streams=False,
                semantic=ExtractionConfig(enabled=True),
            )

        assert "enable_change_streams=False" in caplog.text

    def test_validate_returns_issues(self):
        """validate() should return list of issues."""
        config = WorkerConfig(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            auto_extract_on_snapshot=True,
            enable_change_streams=False,
        )

        issues = config.validate()

        # Change streams are preferred, but polling fallback exists for standalone/dev.
        assert len(issues) == 1
        assert any("no extractions" in issue for issue in issues)

    def test_validate_returns_empty_for_valid(self):
        """validate() should return empty list for valid config."""
        mock_llm = MagicMock()

        config = WorkerConfig.auto_extraction(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            llm=mock_llm,
        )

        issues = config.validate()
        assert issues == []

    def test_summary_output(self):
        """summary() should return readable config description."""
        mock_llm = MagicMock()

        config = WorkerConfig.auto_extraction(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            llm=mock_llm,
            extractions=["semantic", "taxonomic"],
        )

        summary = config.summary()

        assert "Mode: auto" in summary
        assert "semantic" in summary
        assert "taxonomic" in summary
        assert "Change stream" in summary


class TestOnSnapshotCreated:
    """Test the _on_snapshot_created handler in worker."""

    @pytest.fixture
    def mock_worker(self):
        """Create a mock worker with necessary attributes."""
        # Instead of creating a real worker, we'll create a mock with the
        # necessary methods and attributes to test _on_snapshot_created

        mock_llm = MagicMock()
        config = WorkerConfig.auto_extraction(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            llm=mock_llm,
            extractions=["semantic", "taxonomic"],
        )

        # Create a simple object with the methods we need to test
        class MockWorker:
            def __init__(self):
                self._config = config
                self._scaling_mode = "distributed"
                self._executor = None

            def _enqueue_extraction(self, extraction_type, payload, snapshot_id):
                from runner_shared.server.mongomem_impl.src.mongomem_worker.queue import (
                    enqueue_task,
                )

                if self._scaling_mode == "distributed":
                    enqueue_task(extraction_type, payload)

            def _on_snapshot_created(self, snapshot_doc):
                """Simulate the actual method."""
                messages = snapshot_doc.get("messages", [])
                if not messages:
                    return

                formatted_messages = []
                for msg in messages:
                    if isinstance(msg, dict):
                        formatted_messages.append(
                            {
                                "role": msg.get("role", "user"),
                                "content": msg.get("content", ""),
                            }
                        )

                base_payload = {
                    "messages": formatted_messages,
                    "org_id": snapshot_doc.get("org_id"),
                    "user_id": snapshot_doc.get("user_id"),
                    "source_id": str(snapshot_doc.get("_id")),
                }

                extraction_types = ["semantic", "taxonomic", "episodic", "entity"]
                for extraction_type in extraction_types:
                    if self._config.is_extraction_enabled(extraction_type):
                        self._enqueue_extraction(
                            extraction_type, base_payload, snapshot_doc.get("_id")
                        )

        return MockWorker()

    def test_on_snapshot_created_triggers_enabled_extractions(self, mock_worker):
        """Should enqueue tasks for all enabled extraction types."""
        snapshot_doc = {
            "_id": "snap:123",
            "org_id": "org-1",
            "user_id": "user-1",
            "messages": [
                {"role": "user", "content": "Hello"},
                {"role": "assistant", "content": "Hi there"},
            ],
        }

        with patch(
            "runner_shared.server.mongomem_impl.src.mongomem_worker.queue.enqueue_task"
        ) as mock_enqueue:
            mock_worker._on_snapshot_created(snapshot_doc)

            # Should enqueue both semantic and taxonomic
            assert mock_enqueue.call_count == 2

            call_types = [call[0][0] for call in mock_enqueue.call_args_list]
            assert "semantic" in call_types
            assert "taxonomic" in call_types

    def test_on_snapshot_created_skips_empty_messages(self, mock_worker):
        """Should skip extraction if snapshot has no messages."""
        snapshot_doc = {
            "_id": "snap:123",
            "org_id": "org-1",
            "user_id": "user-1",
            "messages": [],
        }

        with patch(
            "runner_shared.server.mongomem_impl.src.mongomem_worker.queue.enqueue_task"
        ) as mock_enqueue:
            mock_worker._on_snapshot_created(snapshot_doc)
            mock_enqueue.assert_not_called()

    def test_on_snapshot_created_formats_payload_correctly(self, mock_worker):
        """Should format extraction payload correctly."""
        snapshot_doc = {
            "_id": "snap:456",
            "org_id": "org-2",
            "user_id": "user-2",
            "messages": [
                {"role": "user", "content": "Test message"},
            ],
        }

        with patch(
            "runner_shared.server.mongomem_impl.src.mongomem_worker.queue.enqueue_task"
        ) as mock_enqueue:
            mock_worker._on_snapshot_created(snapshot_doc)

            # Check payload structure
            call_args = mock_enqueue.call_args_list[0]
            payload = call_args[0][1]

            assert payload["org_id"] == "org-2"
            assert payload["user_id"] == "user-2"
            assert payload["source_id"] == "snap:456"
            assert payload["messages"] == [{"role": "user", "content": "Test message"}]


class TestSnapshotExtractionWatcher:
    """Test the change stream watcher for auto-extraction."""

    def test_watcher_only_watches_inserts(self):
        """Watcher should only process INSERT operations."""
        from runner_shared.server.mongomem_impl.src.mongomem_worker.streams.change_streams import (
            _SnapshotExtractionWatcher,
        )

        mock_db = MagicMock()
        mock_resume_store = MagicMock()
        mock_callback = MagicMock()

        watcher = _SnapshotExtractionWatcher(
            db=mock_db,
            collection_name="memory_snapshot",
            stream_name="test_stream",
            resume_store=mock_resume_store,
            on_snapshot_created=mock_callback,
        )

        # Verify it's set up correctly
        assert watcher._on_snapshot_created is mock_callback

    def test_handle_insert_calls_callback(self):
        """_handle_insert should call the callback with document."""
        from runner_shared.server.mongomem_impl.src.mongomem_worker.streams.change_streams import (
            _SnapshotExtractionWatcher,
        )

        mock_db = MagicMock()
        mock_resume_store = MagicMock()
        mock_callback = MagicMock()

        watcher = _SnapshotExtractionWatcher(
            db=mock_db,
            collection_name="memory_snapshot",
            stream_name="test_stream",
            resume_store=mock_resume_store,
            on_snapshot_created=mock_callback,
        )

        change = {
            "operationType": "insert",
            "fullDocument": {"_id": "snap:1", "messages": []},
            "documentKey": {"_id": "snap:1"},
        }
        resume_token = {"_data": "token123"}

        watcher._handle_insert(change, resume_token)

        # Callback should be called with the document
        mock_callback.assert_called_once_with({"_id": "snap:1", "messages": []})

        # Resume token should be saved
        mock_resume_store.save_token.assert_called_once()

    def test_handle_insert_skips_without_document(self):
        """_handle_insert should skip if no fullDocument."""
        from runner_shared.server.mongomem_impl.src.mongomem_worker.streams.change_streams import (
            _SnapshotExtractionWatcher,
        )

        mock_db = MagicMock()
        mock_resume_store = MagicMock()
        mock_callback = MagicMock()

        watcher = _SnapshotExtractionWatcher(
            db=mock_db,
            collection_name="memory_snapshot",
            stream_name="test_stream",
            resume_store=mock_resume_store,
            on_snapshot_created=mock_callback,
        )

        change = {
            "operationType": "insert",
            "fullDocument": None,  # No document
        }

        watcher._handle_insert(change, {})

        mock_callback.assert_not_called()


class TestChangeStreamManager:
    """Test MemoryChangeStreamManager integration."""

    def test_create_snapshot_extraction_watcher(self):
        """Should create watcher with callback."""
        from runner_shared.server.mongomem_impl.src.mongomem_worker.streams.change_streams import (
            MemoryChangeStreamManager,
        )

        mock_db = MagicMock()
        manager = MemoryChangeStreamManager(mock_db)

        callback = MagicMock()
        watcher = manager.create_snapshot_extraction_watcher(on_snapshot_created=callback)

        assert watcher is not None
        assert "snapshot_extraction" in manager._watchers


class TestEnqueueExtraction:
    """Test the _enqueue_extraction helper method logic."""

    def test_enqueue_in_distributed_mode(self):
        """Should use enqueue_task in distributed mode."""
        # Test the logic directly without creating a real worker
        with patch(
            "runner_shared.server.mongomem_impl.src.mongomem_worker.queue.enqueue_task"
        ) as mock_enqueue:
            # Simulate what _enqueue_extraction does in distributed mode
            payload = {
                "messages": [],
                "org_id": "org-1",
                "user_id": "user-1",
                "source_id": "snap:1",
            }
            scaling_mode = "distributed"

            if scaling_mode == "distributed":
                from runner_shared.server.mongomem_impl.src.mongomem_worker.queue import (
                    enqueue_task,
                )

                enqueue_task("semantic", payload)

            mock_enqueue.assert_called_once_with("semantic", payload)

    def test_enqueue_in_single_mode_uses_executor(self):
        """Should use executor in single mode."""
        # Test the logic: in single mode, executor.submit should be called
        mock_executor = MagicMock()
        scaling_mode = "single"

        payload = {"messages": [], "org_id": "org-1", "user_id": "user-1", "source_id": "snap:1"}

        if scaling_mode == "single" and mock_executor:
            mock_executor.submit(MagicMock(), "semantic", payload)

        mock_executor.submit.assert_called_once()


class TestEndToEndAutoExtraction:
    """Integration-style tests for auto-extraction flow."""

    @pytest.mark.asyncio
    async def test_change_stream_manager_creates_watcher(self):
        """MemoryChangeStreamManager should create extraction watcher with callback."""
        from runner_shared.server.mongomem_impl.src.mongomem_worker.streams.change_streams import (
            MemoryChangeStreamManager,
        )

        mock_db = MagicMock()
        manager = MemoryChangeStreamManager(mock_db)

        callback = MagicMock()
        watcher = manager.create_snapshot_extraction_watcher(on_snapshot_created=callback)

        # Watcher should be created and stored
        assert watcher is not None
        assert "snapshot_extraction" in manager._watchers
        assert watcher._on_snapshot_created is callback

    @pytest.mark.asyncio
    async def test_watcher_start_returns_false_without_replica_set(self):
        """Watcher should return False if change streams unavailable."""
        from runner_shared.server.mongomem_impl.src.mongomem_worker.streams.change_streams import (
            _SnapshotExtractionWatcher,
        )

        mock_db = MagicMock()
        mock_collection = MagicMock()
        # Simulate change streams not available
        mock_collection.watch.side_effect = Exception("Requires replica set")

        with patch(
            "runner_shared.server.mongomem_impl.src.mongomem_worker.storage.cache.get_collection",
            return_value=mock_collection,
        ):
            watcher = _SnapshotExtractionWatcher(
                db=mock_db,
                collection_name="memory_snapshot",
                stream_name="test",
                resume_store=MagicMock(),
                on_snapshot_created=MagicMock(),
            )
            watcher._collection = mock_collection

            # _test_change_stream_available should return False
            result = watcher._test_change_stream_available()
            assert result is False


class TestDXCompleteness:
    """Meta-tests to ensure DX is complete."""

    def test_factory_methods_exist(self):
        """All expected factory methods should exist."""
        assert hasattr(WorkerConfig, "auto_extraction")
        assert hasattr(WorkerConfig, "manual")
        assert hasattr(WorkerConfig, "from_dict")

    def test_helper_properties_exist(self):
        """All expected helper properties should exist."""
        config = WorkerConfig(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
        )

        assert hasattr(config, "extraction_mode")
        assert hasattr(config, "enabled_extractions")
        assert hasattr(config, "validate")
        assert hasattr(config, "summary")

    def test_auto_extraction_is_one_liner(self):
        """auto_extraction should work with minimal args."""
        mock_llm = MagicMock()

        # This should be all that's needed
        config = WorkerConfig.auto_extraction(
            "mongodb://localhost:27017",
            "test_db",
            mock_llm,
        )

        assert config.extraction_mode == "auto"
        assert "semantic" in config.enabled_extractions

    def test_manual_is_one_liner(self):
        """manual should work with minimal args."""
        # This should be all that's needed
        config = WorkerConfig.manual(
            "mongodb://localhost:27017",
            "test_db",
        )

        assert config.extraction_mode == "manual"
