"""Integration tests for Internal Working Memory (IWM) flow."""

import os

import pytest
from mongomem_core import MemoryEngine, MemoryMode, ModeError
from mongomem_core.config import Settings

TEST_MONGO_URI = os.environ.get("TEST_MONGO_URI", "mongodb://localhost:27017")


class TestIWMFullFlow:
    """End-to-end IWM flow tests."""

    @pytest.fixture
    def iwm_engine(self, test_db) -> MemoryEngine:
        """Provide a MemoryEngine in IWM mode."""
        settings = Settings(
            mongo_uri=TEST_MONGO_URI,
            db_name=test_db.name,
            embedding_dimension=1024,
        )
        engine = MemoryEngine(settings, mode=MemoryMode.IWM)
        engine.bootstrap(ensure_search_indexes=False)
        return engine

    @pytest.fixture
    def hybrid_engine(self, test_db) -> MemoryEngine:
        """Provide a MemoryEngine in HYBRID mode."""
        settings = Settings(
            mongo_uri=TEST_MONGO_URI,
            db_name=test_db.name,
            embedding_dimension=1024,
        )
        engine = MemoryEngine(settings, mode=MemoryMode.HYBRID)
        engine.bootstrap(ensure_search_indexes=False)
        return engine

    def test_iwm_update_and_retrieve(self, iwm_engine):
        """Complete IWM flow: update IS, retrieve, verify content."""
        # Update internal state
        result = iwm_engine.update_internal_state(
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            content="User prefers dark mode. Currently discussing project X.",
        )

        assert result.version == 1
        assert result.session_id == "sess_123"
        assert result.token_count > 0

        # Retrieve internal state
        state = iwm_engine.get_internal_state(
            session_id="sess_123",
            org_id="org_1",
        )

        assert state is not None
        # Content is normalized with trailing newline
        assert state.content.strip() == "User prefers dark mode. Currently discussing project X."
        assert state.version == 1

    def test_is_overwrites_previous_content(self, iwm_engine):
        """IS content is replaced on each update."""
        # First update
        iwm_engine.update_internal_state(
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            content="First state with lots of information that is quite long.",
        )

        # Second update - shorter content
        result = iwm_engine.update_internal_state(
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            content="Updated.",
        )

        assert result.version == 2

        state = iwm_engine.get_internal_state(
            session_id="sess_123",
            org_id="org_1",
        )

        # Content is normalized with trailing newline
        assert state.content.strip() == "Updated."

    def test_version_increments_on_each_update(self, iwm_engine):
        """Version number increments with each update."""
        for i in range(1, 6):
            result = iwm_engine.update_internal_state(
                session_id="sess_123",
                org_id="org_1",
                user_id="user_1",
                content=f"State version {i}",
            )
            assert result.version == i

    def test_iwm_mode_blocks_write_turn(self, iwm_engine):
        """IWM mode does not allow write_turn."""
        with pytest.raises(ModeError) as exc_info:
            iwm_engine.write_turn(
                session_id="sess_123",
                role="user",
                content="Hello",
                org_id="org_1",
                user_id="user_1",
            )

        assert exc_info.value.current_mode == MemoryMode.IWM

    def test_clear_internal_state(self, iwm_engine):
        """clear_internal_state removes IS document."""
        # Create IS
        iwm_engine.update_internal_state(
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            content="Some state",
        )

        # Clear it
        deleted = iwm_engine.clear_internal_state(
            session_id="sess_123",
            org_id="org_1",
        )

        assert deleted is True

        # Verify it's gone
        state = iwm_engine.get_internal_state(
            session_id="sess_123",
            org_id="org_1",
        )
        assert state is None

    def test_hybrid_mode_allows_both_operations(self, hybrid_engine):
        """HYBRID mode allows both write_turn and update_internal_state."""
        # Write a turn
        turn_result = hybrid_engine.write_turn(
            session_id="sess_123",
            role="user",
            content="Hello!",
            org_id="org_1",
            user_id="user_1",
        )
        assert turn_result.turn_seq == 1

        # Update internal state
        is_result = hybrid_engine.update_internal_state(
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            content="User said hello.",
        )
        assert is_result.version == 1

        # Both should be retrievable
        state = hybrid_engine.get_internal_state(
            session_id="sess_123",
            org_id="org_1",
        )
        assert state is not None
        # Content is normalized with trailing newline
        assert state.content.strip() == "User said hello."


class TestBuildMemoryContext:
    """Test build_memory_context in different modes."""

    @pytest.fixture
    def iwm_engine(self, test_db) -> MemoryEngine:
        """Provide a MemoryEngine in IWM mode."""
        settings = Settings(
            mongo_uri=TEST_MONGO_URI,
            db_name=test_db.name,
            embedding_dimension=1024,
        )
        engine = MemoryEngine(settings, mode=MemoryMode.IWM)
        engine.bootstrap(ensure_search_indexes=False)
        return engine

    def test_iwm_context_has_empty_stm(self, iwm_engine):
        """IWM context has stm_turns=[]."""
        # Create some internal state
        iwm_engine.update_internal_state(
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            content="Test state content",
        )

        context = iwm_engine.build_memory_context(
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
        )

        assert context.source == "iwm"
        assert len(context.stm_turns) == 0
        assert context.invariants.stm_empty is True

    def test_iwm_context_includes_internal_state(self, iwm_engine):
        """IWM context includes internal_state content."""
        iwm_engine.update_internal_state(
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            content="Agent believes user prefers Python.",
        )

        context = iwm_engine.build_memory_context(
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
        )

        # Content is normalized with trailing newline
        assert context.internal_state.strip() == "Agent believes user prefers Python."
        assert context.invariants.is_present is True
        assert context.invariants.is_primary is True

    def test_iwm_context_without_is_returns_empty_is(self, iwm_engine):
        """IWM context without IS returns None for internal_state."""
        context = iwm_engine.build_memory_context(
            session_id="nonexistent",
            org_id="org_1",
            user_id="user_1",
        )

        assert context.internal_state is None
        assert context.invariants.is_present is False

    def test_traditional_context_has_no_is(self, bootstrapped_engine):
        """Traditional context has internal_state=None."""
        # Write some turns
        bootstrapped_engine.write_turn(
            session_id="sess_123",
            role="user",
            content="Hello!",
            org_id="org_1",
            user_id="user_1",
        )

        context = bootstrapped_engine.build_memory_context(
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
        )

        assert context.source == "traditional"
        assert context.internal_state is None
        assert context.invariants.is_present is False


class TestContextSizeStability:
    """Test that IWM context size stays stable."""

    @pytest.fixture
    def iwm_engine(self, test_db) -> MemoryEngine:
        """Provide a MemoryEngine in IWM mode."""
        settings = Settings(
            mongo_uri=TEST_MONGO_URI,
            db_name=test_db.name,
            embedding_dimension=1024,
        )
        engine = MemoryEngine(settings, mode=MemoryMode.IWM)
        engine.bootstrap(ensure_search_indexes=False)
        return engine

    def test_is_token_count_stays_bounded(self, iwm_engine):
        """IS token count stays within budget across updates."""
        is_budget = 100  # Small budget for test
        token_counts = []

        for i in range(10):
            # Each update has similar-sized content
            iwm_engine.update_internal_state(
                session_id="sess_123",
                org_id="org_1",
                user_id="user_1",
                content=f"Turn {i}: User discussed topic {i}. Agent noted preference.",
            )

            context = iwm_engine.build_memory_context(
                session_id="sess_123",
                org_id="org_1",
                user_id="user_1",
                is_token_budget=is_budget,
            )

            token_counts.append(context.internal_state_tokens)

        # All token counts should be similar (within 50% variance)
        if token_counts:
            avg = sum(token_counts) / len(token_counts)
            for count in token_counts:
                assert abs(count - avg) < avg * 0.5, (
                    f"Token count {count} deviates too much from average {avg}"
                )


class TestBootstrapIdempotency:
    """Test that bootstrap is idempotent."""

    def test_bootstrap_twice_no_error(self, test_db):
        """Calling bootstrap twice doesn't error."""
        settings = Settings(
            mongo_uri=TEST_MONGO_URI,
            db_name=test_db.name,
            embedding_dimension=1024,
        )
        engine = MemoryEngine(settings, mode=MemoryMode.IWM)

        # First bootstrap
        engine.bootstrap(ensure_search_indexes=False)

        # Second bootstrap should not raise
        engine.bootstrap(ensure_search_indexes=False)

    def test_mode_switch_after_bootstrap_works(self, test_db):
        """Creating new engine with different mode after bootstrap works."""
        settings = Settings(
            mongo_uri=TEST_MONGO_URI,
            db_name=test_db.name,
            embedding_dimension=1024,
        )

        # First engine in TRADITIONAL mode
        engine1 = MemoryEngine(settings, mode=MemoryMode.TRADITIONAL)
        engine1.bootstrap(ensure_search_indexes=False)

        engine1.write_turn(
            session_id="sess_1",
            role="user",
            content="Hello",
            org_id="org_1",
            user_id="user_1",
        )

        # Second engine in IWM mode - should work
        engine2 = MemoryEngine(settings, mode=MemoryMode.IWM)
        engine2.bootstrap(ensure_search_indexes=False)

        engine2.update_internal_state(
            session_id="sess_2",
            org_id="org_1",
            user_id="user_1",
            content="New session in IWM mode",
        )

        # Both data should exist
        state = engine2.get_internal_state(session_id="sess_2", org_id="org_1")
        assert state is not None
