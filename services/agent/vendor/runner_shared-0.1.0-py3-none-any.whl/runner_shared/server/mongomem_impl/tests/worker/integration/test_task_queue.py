import asyncio
from datetime import datetime, timedelta, timezone
from typing import Any, Dict

import pytest
from bson import ObjectId
from pymongo.database import Database

from runner_shared.server.mongomem_impl.src.mongomem_worker.observability import WorkerObservability
from runner_shared.server.mongomem_impl.src.mongomem_worker.queue import (
    TaskQueueProcessor,
    claim_task,
    complete_task,
    heartbeat_task,
    requeue_stale_tasks,
)

from ..conftest import RecordingMetrics


def create_task(
    test_db: Database,
    task_type: str,
    payload: Dict[str, Any],
    priority: int = 0,
    max_retries: int = 3,
    tenant_id: str | None = None,
    ttl_days: int = 14,
) -> ObjectId:
    """Helper to create tasks directly in test database with proper format."""
    now = datetime.now(timezone.utc)
    task_id = ObjectId()
    doc = {
        "_id": task_id,
        "task_type": task_type,
        "payload": payload,
        "status": "queued",
        "priority": priority,
        "created_at": now,
        "run_after": now,  # Can be claimed immediately
        "expires_at": now + timedelta(days=ttl_days),  # TTL
        "max_retries": max_retries,
        "remaining_retries": max_retries,
        "worker_id": None,
        "lease_expires_at": None,
    }
    if tenant_id:
        doc["tenant_id"] = tenant_id
    test_db.tasks.insert_one(doc)
    return task_id


def ensure_tz_aware(dt: datetime) -> datetime:
    """Ensure datetime is timezone-aware (UTC)."""
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


class TestEnqueueTask:
    """Tests for task enqueueing."""

    def test_enqueue_basic_task(self, test_db: Database):
        task_id = create_task(
            test_db,
            task_type="embedding",
            payload={"doc_id": "stm:12345"},
        )

        assert task_id is not None

        # Verify task in database
        task = test_db.tasks.find_one({"_id": task_id})
        assert task is not None
        assert task["task_type"] == "embedding"
        assert task["status"] == "queued"
        assert task["payload"]["doc_id"] == "stm:12345"
        assert task["run_after"] is not None
        assert task["expires_at"] is not None

    def test_enqueue_with_priority(self, test_db: Database):
        low_priority = create_task(test_db, "embedding", {"id": "1"}, priority=0)
        high_priority = create_task(test_db, "embedding", {"id": "2"}, priority=10)

        low_task = test_db.tasks.find_one({"_id": low_priority})
        high_task = test_db.tasks.find_one({"_id": high_priority})

        assert low_task["priority"] == 0
        assert high_task["priority"] == 10

    def test_enqueue_with_tenant(self, test_db: Database):
        task_id = create_task(
            test_db,
            task_type="embedding",
            payload={"doc_id": "test"},
            tenant_id="tenant-123",
        )

        task = test_db.tasks.find_one({"_id": task_id})
        assert task["tenant_id"] == "tenant-123"

    def test_enqueue_with_custom_retries(self, test_db: Database):
        task_id = create_task(
            test_db,
            task_type="embedding",
            payload={},
            max_retries=5,
        )

        task = test_db.tasks.find_one({"_id": task_id})
        assert task["max_retries"] == 5
        assert task["remaining_retries"] == 5


class TestClaimTask:
    """Tests for task claiming."""

    def test_claim_queued_task(self, test_db: Database):
        task_id = create_task(test_db, "embedding", {"doc_id": "test"})

        claimed = claim_task(
            test_db.tasks,
            worker_id="worker-1",
            task_types=["embedding"],
            lease_seconds=300,
        )

        assert claimed is not None
        assert claimed.id == task_id
        assert claimed.task_type == "embedding"

        # Verify task status updated
        task = test_db.tasks.find_one({"_id": task_id})
        assert task["status"] == "running"
        assert task["worker_id"] == "worker-1"
        assert task["lease_expires_at"] is not None

    def test_claim_returns_none_when_no_tasks(self, test_db: Database):
        claimed = claim_task(
            test_db.tasks,
            worker_id="worker-1",
            task_types=["embedding"],
            lease_seconds=300,
        )

        assert claimed is None

    def test_claim_filters_by_task_type(self, test_db: Database):
        create_task(test_db, "snapshot", {"id": "1"})

        # Try to claim embedding task when only snapshot exists
        claimed = claim_task(
            test_db.tasks,
            worker_id="worker-1",
            task_types=["embedding"],
            lease_seconds=300,
        )

        assert claimed is None

    def test_claim_respects_priority(self, test_db: Database):
        # Create with low priority first
        low_id = create_task(test_db, "embedding", {"id": "low"}, priority=10)
        # Create with high priority (higher number = higher priority in sort)
        high_id = create_task(test_db, "embedding", {"id": "high"}, priority=0)

        # Lower priority number should be claimed first (ASCENDING sort)
        claimed = claim_task(test_db.tasks, "worker-1", ["embedding"], 300)
        assert claimed.id == high_id

        # Then higher priority number
        claimed = claim_task(test_db.tasks, "worker-1", ["embedding"], 300)
        assert claimed.id == low_id

    def test_claim_skips_processing_tasks(self, test_db: Database):
        _task_id = create_task(test_db, "embedding", {"id": "1"})

        # First worker claims it
        claim_task(test_db.tasks, "worker-1", ["embedding"], 300)

        # Second worker should not claim same task
        claimed = claim_task(test_db.tasks, "worker-2", ["embedding"], 300)
        assert claimed is None

    def test_claim_all_task_types_when_none_specified(self, test_db: Database):
        create_task(test_db, "embedding", {"id": "1"})
        create_task(test_db, "snapshot", {"id": "2"})

        # Claim with task_types=None should get any task
        claimed = claim_task(test_db.tasks, "worker-1", None, 300)
        assert claimed is not None

    def test_claim_skips_future_tasks(self, test_db: Database):
        now = datetime.now(timezone.utc)
        task_id = ObjectId()
        test_db.tasks.insert_one(
            {
                "_id": task_id,
                "task_type": "embedding",
                "payload": {},
                "status": "queued",
                "priority": 0,
                "created_at": now,
                "run_after": now + timedelta(hours=1),  # Future
                "expires_at": now + timedelta(days=1),
                "max_retries": 3,
                "remaining_retries": 3,
                "worker_id": None,
                "lease_expires_at": None,
            }
        )

        claimed = claim_task(test_db.tasks, "worker-1", ["embedding"], 300)
        assert claimed is None  # Should not claim future tasks


class TestCompleteTask:
    """Tests for task completion."""

    def test_complete_task_success(self, test_db: Database):
        task_id = create_task(test_db, "embedding", {"id": "1"})
        claim_task(test_db.tasks, "worker-1", ["embedding"], 300)

        complete_task(
            test_db.tasks,
            task_id=task_id,
            worker_id="worker-1",
            success=True,
            result={"embeddings": [0.1, 0.2]},
        )

        task = test_db.tasks.find_one({"_id": task_id})
        assert task["status"] == "succeeded"
        assert task["result"]["embeddings"] == [0.1, 0.2]
        assert task["completed_at"] is not None

    def test_complete_task_failure_with_retry(self, test_db: Database):
        task_id = create_task(test_db, "embedding", {"id": "1"}, max_retries=3)
        claimed = claim_task(test_db.tasks, "worker-1", ["embedding"], 300)

        complete_task(
            test_db.tasks,
            task_id=task_id,
            worker_id="worker-1",
            success=False,
            error="Connection timeout",
            attempts=claimed.attempts + 1,
            max_retries=3,
        )

        task = test_db.tasks.find_one({"_id": task_id})
        # Should be requeued for retry
        assert task["status"] == "queued"
        assert task["remaining_retries"] == 2  # Decremented from 3
        assert task["last_error"] == "Connection timeout"
        assert task["worker_id"] is None

    def test_complete_task_failure_no_retries_left(self, test_db: Database):
        # Create with only 1 retry
        task_id = create_task(test_db, "embedding", {"id": "1"}, max_retries=1)
        claimed = claim_task(test_db.tasks, "worker-1", ["embedding"], 300)

        # First failure uses the retry
        complete_task(
            test_db.tasks,
            task_id=task_id,
            worker_id="worker-1",
            success=False,
            error="First failure",
            attempts=claimed.attempts + 1,
            max_retries=1,
        )

        # Claim again for retry
        claimed = claim_task(test_db.tasks, "worker-1", ["embedding"], 300)
        if claimed:
            # Second failure should mark as failed
            complete_task(
                test_db.tasks,
                task_id=task_id,
                worker_id="worker-1",
                success=False,
                error="Permanent failure",
                attempts=claimed.attempts + 1,
                max_retries=1,
            )

            task = test_db.tasks.find_one({"_id": task_id})
            assert task["status"] == "failed"

    def test_complete_wrong_worker_ignored(self, test_db: Database):
        task_id = create_task(test_db, "embedding", {"id": "1"})
        claim_task(test_db.tasks, "worker-1", ["embedding"], 300)

        # Worker-2 tries to complete task owned by worker-1
        result = complete_task(
            test_db.tasks,
            task_id=task_id,
            worker_id="worker-2",
            success=True,
        )

        # Should return False (didn't update)
        assert result is False

        # Task should still be running
        task = test_db.tasks.find_one({"_id": task_id})
        assert task["status"] == "running"
        assert task["worker_id"] == "worker-1"


class TestHeartbeatTask:
    """Tests for task heartbeat/lease extension."""

    def test_heartbeat_extends_lease(self, test_db: Database):
        task_id = create_task(test_db, "embedding", {"id": "1"})
        _claimed = claim_task(test_db.tasks, "worker-1", ["embedding"], 60)

        original_expires = test_db.tasks.find_one({"_id": task_id})["lease_expires_at"]

        # Heartbeat with longer lease
        result = heartbeat_task(test_db.tasks, task_id, "worker-1", 120)
        assert result is True

        updated_task = test_db.tasks.find_one({"_id": task_id})
        assert updated_task["lease_expires_at"] > original_expires

    def test_heartbeat_wrong_worker_ignored(self, test_db: Database):
        task_id = create_task(test_db, "embedding", {"id": "1"})
        claim_task(test_db.tasks, "worker-1", ["embedding"], 60)

        original_expires = test_db.tasks.find_one({"_id": task_id})["lease_expires_at"]

        # Wrong worker tries to heartbeat
        result = heartbeat_task(test_db.tasks, task_id, "worker-2", 120)
        assert result is False

        # Lease should not be extended
        task = test_db.tasks.find_one({"_id": task_id})
        assert task["lease_expires_at"] == original_expires


class TestRequeueStaleTasks:
    """Tests for stale task recovery."""

    def test_requeue_expired_lease(self, test_db: Database):
        task_id = create_task(test_db, "embedding", {"id": "1"})
        claim_task(test_db.tasks, "worker-1", ["embedding"], 1)  # 1 second lease

        # Manually expire the lease
        test_db.tasks.update_one(
            {"_id": task_id},
            {"$set": {"lease_expires_at": datetime.now(timezone.utc) - timedelta(minutes=35)}},
        )

        requeued = requeue_stale_tasks(test_db.tasks, max_age_minutes=30)

        assert requeued >= 1

        task = test_db.tasks.find_one({"_id": task_id})
        assert task["status"] == "queued"
        assert task["worker_id"] is None

    def test_requeue_only_expired_tasks(self, test_db: Database):
        task1 = create_task(test_db, "embedding", {"id": "1"})
        task2 = create_task(test_db, "embedding", {"id": "2"})

        # Claim both
        claim_task(test_db.tasks, "worker-1", ["embedding"], 300)
        claim_task(test_db.tasks, "worker-1", ["embedding"], 300)

        # Expire only task1 (past the max_age_minutes threshold)
        test_db.tasks.update_one(
            {"_id": task1},
            {"$set": {"lease_expires_at": datetime.now(timezone.utc) - timedelta(minutes=35)}},
        )

        requeued = requeue_stale_tasks(test_db.tasks, max_age_minutes=30)

        assert requeued >= 1

        t1 = test_db.tasks.find_one({"_id": task1})
        t2 = test_db.tasks.find_one({"_id": task2})

        assert t1["status"] == "queued"
        assert t2["status"] == "running"


class TestTaskQueueProcessor:
    """Integration tests for the task queue processor."""

    @pytest.mark.asyncio
    async def test_process_one_success(
        self, test_db: Database, recording_metrics: RecordingMetrics
    ):
        task_id = create_task(test_db, "embedding", {"text": "hello"})

        obs = WorkerObservability(backend=recording_metrics)
        processor = TaskQueueProcessor(
            db=test_db,
            task_types=["embedding"],
            observability=obs,
        )

        # Register a handler
        results = []

        def embedding_handler(payload):
            results.append(payload)
            return {"embedding": [0.1, 0.2]}

        processor.register_handler("embedding", embedding_handler)

        # Process one task
        processed = await processor.process_one()

        assert processed is True
        assert len(results) == 1
        assert results[0]["text"] == "hello"

        # Verify task succeeded
        task = test_db.tasks.find_one({"_id": task_id})
        assert task["status"] == "succeeded"

        # Verify metrics
        claimed = recording_metrics.get_increments("tasks_claimed")
        completed = recording_metrics.get_increments("tasks_completed")
        assert len(claimed) == 1
        assert len(completed) == 1

    @pytest.mark.asyncio
    async def test_process_one_async_handler(self, test_db: Database):
        task_id = create_task(test_db, "embedding", {"text": "async test"})

        processor = TaskQueueProcessor(db=test_db, task_types=["embedding"])

        # Register an async handler
        async def async_handler(payload):
            await asyncio.sleep(0.01)  # Simulate async work
            return {"done": True}

        processor.register_handler("embedding", async_handler)

        processed = await processor.process_one()

        assert processed is True
        task = test_db.tasks.find_one({"_id": task_id})
        assert task["status"] == "succeeded"

    @pytest.mark.asyncio
    async def test_process_one_handler_failure(
        self, test_db: Database, recording_metrics: RecordingMetrics
    ):
        task_id = create_task(test_db, "embedding", {"text": "fail"}, max_retries=3)

        obs = WorkerObservability(backend=recording_metrics)
        processor = TaskQueueProcessor(
            db=test_db,
            task_types=["embedding"],
            observability=obs,
        )

        def failing_handler(payload):
            raise ValueError("Handler error")

        processor.register_handler("embedding", failing_handler)

        processed = await processor.process_one()

        assert processed is True

        task = test_db.tasks.find_one({"_id": task_id})
        # Should be requeued (has retries left)
        assert task["status"] == "queued"
        assert task["remaining_retries"] == 2  # Was 3, now 2

        # Verify failure metrics
        failed = recording_metrics.get_increments("tasks_failed")
        assert len(failed) == 1

    @pytest.mark.asyncio
    async def test_process_one_timeout(
        self, test_db: Database, recording_metrics: RecordingMetrics
    ):
        _task_id = create_task(test_db, "embedding", {"text": "slow"})

        obs = WorkerObservability(backend=recording_metrics)
        processor = TaskQueueProcessor(
            db=test_db,
            task_types=["embedding"],
            task_timeouts={"embedding": 0.1},  # 100ms timeout
            observability=obs,
        )

        async def slow_handler(payload):
            await asyncio.sleep(1.0)  # Takes 1 second
            return {"done": True}

        processor.register_handler("embedding", slow_handler)

        processed = await processor.process_one()

        assert processed is True

        # Verify timeout metrics
        timeouts = recording_metrics.get_increments("tasks_timeout")
        assert len(timeouts) == 1

    @pytest.mark.asyncio
    async def test_process_one_no_handler(self, test_db: Database):
        _task_id = create_task(test_db, "unknown_type", {"text": "test"})

        processor = TaskQueueProcessor(db=test_db, task_types=["unknown_type"])
        # No handler registered

        processed = await processor.process_one()

        assert processed is True

        # Task should be failed (no handler)
        tasks = list(test_db.tasks.find({"task_type": "unknown_type"}))
        assert len(tasks) == 1
        assert tasks[0]["status"] == "failed"
        assert "No handler" in tasks[0].get("last_error", "")

    @pytest.mark.asyncio
    async def test_process_one_no_tasks(self, test_db: Database):
        processor = TaskQueueProcessor(db=test_db, task_types=["embedding"])

        processed = await processor.process_one()

        assert processed is False

    @pytest.mark.asyncio
    async def test_multiple_workers_no_duplicate_processing(self, test_db: Database):
        # Enqueue a single task
        _task_id = create_task(test_db, "embedding", {"id": "single"})

        processed_by = []

        def handler_factory(worker_id):
            async def handler(payload):
                processed_by.append(worker_id)
                await asyncio.sleep(0.1)
                return {"worker": worker_id}

            return handler

        # Create two workers
        processor1 = TaskQueueProcessor(db=test_db, worker_id="worker-1", task_types=["embedding"])
        processor2 = TaskQueueProcessor(db=test_db, worker_id="worker-2", task_types=["embedding"])

        processor1.register_handler("embedding", handler_factory("worker-1"))
        processor2.register_handler("embedding", handler_factory("worker-2"))

        # Both try to process concurrently
        results = await asyncio.gather(
            processor1.process_one(),
            processor2.process_one(),
        )

        # Only one should succeed
        assert results.count(True) == 1
        assert results.count(False) == 1

        # Only one worker should have processed
        assert len(processed_by) == 1

    def test_get_timeout_known_type(self, test_db: Database):
        processor = TaskQueueProcessor(
            db=test_db,
            task_timeouts={"embedding": 45.0, "entity": 180.0},
        )

        assert processor.get_timeout("embedding") == 45.0
        assert processor.get_timeout("entity") == 180.0

    def test_get_timeout_unknown_type_uses_default(self, test_db: Database):
        processor = TaskQueueProcessor(
            db=test_db,
            task_timeouts={"embedding": 45.0},
        )

        # Unknown type should use default
        timeout = processor.get_timeout("unknown_type")
        assert timeout == processor._default_timeout
