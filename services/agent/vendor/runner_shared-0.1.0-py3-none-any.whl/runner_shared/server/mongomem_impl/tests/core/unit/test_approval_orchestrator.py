"""
Unit tests for ApprovalOrchestrator.

Tests approval, rejection, and unpublish logic.
"""

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest
from bson import ObjectId
from mongomem_core.extraction.approval.orchestrator import (
    ApprovalOrchestrator,
)
from mongomem_core.extraction.approval.types import (
    PendingDecisionPayload,
    PendingExtraction,
    PendingPreferencesPayload,
)
from mongomem_core.models.memory.base import ChunkVisibility


class TestApprovalOrchestratorInit:
    """Tests for ApprovalOrchestrator initialization."""

    def test_init_with_embedder(self):
        """Orchestrator initializes with embedder."""
        db = MagicMock()
        embedder = MagicMock()
        embedder.model_id = "test-model"

        orch = ApprovalOrchestrator(db, embedder)
        assert orch._embedder is embedder

    def test_init_without_embedder(self):
        """Orchestrator can initialize without embedder."""
        db = MagicMock()

        orch = ApprovalOrchestrator(db, embedder=None)
        assert orch._embedder is None


class TestApprovalOrchestratorApprove:
    """Tests for the approve method."""

    @pytest.fixture
    def orchestrator(self):
        """Create an orchestrator with mocks."""
        db = MagicMock()
        embedder = MagicMock()
        embedder.model_id = "test-model"
        return ApprovalOrchestrator(db, embedder)

    @pytest.fixture
    def pending_add_decision(self):
        """Create a pending ADD decision."""
        return PendingExtraction(
            id="pending-123",
            org_id="org-1",
            user_id="user-1",
            source_id="snapshot-1",
            extraction_type="semantic",
            payload=PendingDecisionPayload(
                action="ADD",
                content="User prefers Python",
                confidence=0.9,
                embedding=[0.1] * 10,
            ),
            visibility=ChunkVisibility.PRIVATE,
            status="pending",
            created_at=datetime.now(timezone.utc),
        )

    def test_approve_not_found_returns_failure(self, orchestrator):
        """Approve on non-existent pending returns failure."""
        with patch.object(orchestrator._store, "get", return_value=None):
            result = orchestrator.approve("nonexistent", reviewed_by="admin")

        assert result.success is False
        assert result.error is not None
        assert "not found" in result.error.lower()

    def test_approve_already_approved_returns_failure(self, orchestrator, pending_add_decision):
        """Approve on already-approved pending returns failure."""
        pending_add_decision.status = "approved"
        with patch.object(orchestrator._store, "get", return_value=pending_add_decision):
            result = orchestrator.approve("pending-123", reviewed_by="admin")

        assert result.success is False
        assert "already" in result.error.lower()

    def test_approve_semantic_add_calls_perform_add(self, orchestrator, pending_add_decision):
        """Approve of semantic ADD should call perform_add."""
        with (
            patch.object(orchestrator._store, "get", return_value=pending_add_decision),
            patch.object(orchestrator._store, "mark_approved", return_value=True),
            patch(
                "mongomem_core.extraction.persistence.perform_add",
                return_value="mem-123",
            ) as mock_add,
        ):
            result = orchestrator.approve("pending-123", reviewed_by="admin")

        assert result.success is True
        assert result.memory_id == "mem-123"
        mock_add.assert_called_once()

    def test_approve_semantic_update_calls_perform_update(self, orchestrator):
        """Approve of semantic UPDATE should call perform_update."""
        pending = PendingExtraction(
            id="pending-456",
            org_id="org-1",
            user_id="user-1",
            source_id="snapshot-1",
            extraction_type="semantic",
            payload=PendingDecisionPayload(
                action="UPDATE",
                content="Updated content",
                confidence=0.95,
                embedding=[0.2] * 10,
                existing_id="existing-mem-1",
            ),
            visibility=ChunkVisibility.PRIVATE,
            status="pending",
            created_at=datetime.now(timezone.utc),
        )

        with (
            patch.object(orchestrator._store, "get", return_value=pending),
            patch.object(orchestrator._store, "mark_approved", return_value=True),
            patch(
                "mongomem_core.extraction.persistence.perform_update",
                return_value=("existing-mem-1", True),
            ) as mock_update,
        ):
            result = orchestrator.approve("pending-456", reviewed_by="admin")

        assert result.success is True
        mock_update.assert_called_once()

    def test_approve_with_visibility_override(self, orchestrator, pending_add_decision):
        """Approve should use visibility override when provided."""
        with (
            patch.object(orchestrator._store, "get", return_value=pending_add_decision),
            patch.object(orchestrator._store, "mark_approved", return_value=True),
            patch(
                "mongomem_core.extraction.persistence.perform_add",
                return_value="mem-123",
            ) as mock_add,
        ):
            result = orchestrator.approve(
                "pending-123",
                reviewed_by="admin",
                target_visibility=ChunkVisibility.SHARED,
                target_project_id="team-alpha",
            )

        assert result.success is True
        # Verify the persistence was called
        assert mock_add.call_args is not None


class TestApprovalOrchestratorReject:
    """Tests for the reject method."""

    @pytest.fixture
    def orchestrator(self):
        """Create an orchestrator with mocks."""
        db = MagicMock()
        return ApprovalOrchestrator(db, embedder=None)

    def test_reject_marks_as_rejected(self, orchestrator):
        """Reject should mark pending as rejected with reason."""
        pending = PendingExtraction(
            id="pending-123",
            org_id="org-1",
            user_id="user-1",
            source_id="snapshot-1",
            extraction_type="semantic",
            payload=PendingDecisionPayload(
                action="ADD",
                content="Test",
            ),
            visibility=ChunkVisibility.PRIVATE,
            status="pending",
            created_at=datetime.now(timezone.utc),
        )

        with (
            patch.object(orchestrator._store, "get", return_value=pending),
            patch.object(orchestrator._store, "mark_rejected", return_value=True) as mock_reject,
        ):
            result = orchestrator.reject("pending-123", reason="Inaccurate", reviewed_by="admin")

        assert result is True
        mock_reject.assert_called_once_with("pending-123", "Inaccurate", "admin")

    def test_reject_not_found_returns_false(self, orchestrator):
        """Reject on non-existent pending returns False."""
        with patch.object(orchestrator._store, "get", return_value=None):
            result = orchestrator.reject("nonexistent", reason="Bad", reviewed_by="admin")

        assert result is False


class TestApprovalOrchestratorBatch:
    """Tests for batch approve/reject methods."""

    @pytest.fixture
    def orchestrator(self):
        """Create an orchestrator with mocks."""
        db = MagicMock()
        embedder = MagicMock()
        embedder.model_id = "test-model"
        return ApprovalOrchestrator(db, embedder)

    def test_approve_batch_processes_all(self, orchestrator):
        """Batch approve should process all items."""
        pending_items = []
        for i in range(3):
            pending_items.append(
                PendingExtraction(
                    id=f"pending-{i}",
                    org_id="org-1",
                    user_id="user-1",
                    source_id="snapshot-1",
                    extraction_type="semantic",
                    payload=PendingDecisionPayload(
                        action="ADD",
                        content=f"Content {i}",
                        embedding=[0.1] * 10,
                    ),
                    visibility=ChunkVisibility.PRIVATE,
                    status="pending",
                    created_at=datetime.now(timezone.utc),
                )
            )
        pending_map = {p.id: p for p in pending_items}

        with (
            patch.object(orchestrator._store, "get_many", return_value=pending_map),
            patch.object(orchestrator._store, "mark_approved", return_value=True),
            patch(
                "mongomem_core.extraction.persistence.perform_add",
                return_value="mem-new",
            ),
        ):
            result = orchestrator.approve_batch(
                ["pending-0", "pending-1", "pending-2"],
                reviewed_by="admin",
            )

        assert result.approved == 3
        assert result.failed == 0
        assert len(result.results) == 3

    def test_reject_batch_processes_all(self, orchestrator):
        """Batch reject should reject all items."""
        pending_items = []
        for i in range(2):
            pending_items.append(
                PendingExtraction(
                    id=f"pending-{i}",
                    org_id="org-1",
                    user_id="user-1",
                    source_id="snapshot-1",
                    extraction_type="semantic",
                    payload=PendingDecisionPayload(
                        action="ADD",
                        content=f"Content {i}",
                    ),
                    visibility=ChunkVisibility.PRIVATE,
                    status="pending",
                    created_at=datetime.now(timezone.utc),
                )
            )

        def mock_get(pid):
            for p in pending_items:
                if p.id == pid:
                    return p
            return None

        with (
            patch.object(orchestrator._store, "get", side_effect=mock_get),
            patch.object(orchestrator._store, "mark_rejected", return_value=True),
        ):
            result = orchestrator.reject_batch(
                ["pending-0", "pending-1"],
                reason="All inaccurate",
                reviewed_by="admin",
            )

        assert result == 2


class TestApprovalOrchestratorUnpublish:
    """Tests for unpublish functionality."""

    @pytest.fixture
    def orchestrator(self):
        """Create an orchestrator."""
        db = MagicMock()
        db["memory_semantic"].update_one.return_value = MagicMock(modified_count=1)
        db["memory_semantic"].find_one.return_value = {
            "_id": ObjectId(),
            "org_id": "org-1",
            "user_id": "user-1",
            "text": "Test content",
        }
        db["extraction_pending"].insert_one.return_value = MagicMock(inserted_id=ObjectId())
        return ApprovalOrchestrator(db, embedder=None)

    def test_unpublish_without_restage(self, orchestrator):
        """Unpublish without restage should soft-delete only."""
        result = orchestrator.unpublish(
            memory_id="507f1f77bcf86cd799439011",
            memory_type="semantic",
            org_id="org-1",
            user_id="user-1",
            unpublished_by="admin",
            reason="Incorrect",
            restage=False,
        )

        assert result is None
        orchestrator._db["memory_semantic"].update_one.assert_called_once()

    def test_unpublish_with_restage_creates_pending(self, orchestrator):
        """Unpublish with restage should create pending memory_ref."""
        result = orchestrator.unpublish(
            memory_id="507f1f77bcf86cd799439011",
            memory_type="semantic",
            org_id="org-1",
            user_id="user-1",
            unpublished_by="admin",
            reason="Needs review",
            restage=True,
        )

        assert result is not None
        orchestrator._db["extraction_pending"].insert_one.assert_called_once()


class TestApprovalOrchestratorPreferences:
    """Tests for preferences approval."""

    @pytest.fixture
    def orchestrator(self):
        """Create an orchestrator without embedder (not needed for prefs)."""
        db = MagicMock()
        return ApprovalOrchestrator(db, embedder=None)

    def test_approve_preferences_calls_upsert(self, orchestrator):
        """Approve of preferences should call upsert_extracted_preferences."""
        pending = PendingExtraction(
            id="pending-pref",
            org_id="org-1",
            user_id="user-1",
            source_id="snapshot-1",
            extraction_type="preferences",
            payload=PendingPreferencesPayload(
                session_id="session-123",
                tone="formal",
                confidence=0.9,
            ),
            visibility=ChunkVisibility.PRIVATE,
            status="pending",
            created_at=datetime.now(timezone.utc),
        )

        with (
            patch.object(orchestrator._store, "get", return_value=pending),
            patch.object(orchestrator._store, "mark_approved", return_value=True),
            patch(
                "mongomem_core.extraction.preferences.persistence.upsert_extracted_preferences",
                return_value=MagicMock(success=True, doc_id="pref-123"),
            ) as mock_upsert,
        ):
            result = orchestrator.approve("pending-pref", reviewed_by="admin")

        assert result.success is True
        assert result.memory_id == "pref-123"
        mock_upsert.assert_called_once()

    def test_approve_preferences_without_embedder(self, orchestrator):
        """Preferences approval should work without embedder."""
        pending = PendingExtraction(
            id="pending-pref",
            org_id="org-1",
            user_id="user-1",
            source_id="snapshot-1",
            extraction_type="preferences",
            payload=PendingPreferencesPayload(
                session_id="session-123",
                tone="casual",
                confidence=0.85,
            ),
            visibility=ChunkVisibility.PRIVATE,
            status="pending",
            created_at=datetime.now(timezone.utc),
        )

        with (
            patch.object(orchestrator._store, "get", return_value=pending),
            patch.object(orchestrator._store, "mark_approved", return_value=True),
            patch(
                "mongomem_core.extraction.preferences.persistence.upsert_extracted_preferences",
                return_value=MagicMock(success=True, doc_id="pref-456"),
            ),
        ):
            result = orchestrator.approve("pending-pref", reviewed_by="admin")

        assert result.success is True


class TestEmbedderRequired:
    """Tests for embedder requirement validation."""

    def test_semantic_without_embedder_raises(self):
        """Semantic approval without embedder should raise."""
        db = MagicMock()
        orchestrator = ApprovalOrchestrator(db, embedder=None)

        pending = PendingExtraction(
            id="pending-123",
            org_id="org-1",
            user_id="user-1",
            source_id="snapshot-1",
            extraction_type="semantic",
            payload=PendingDecisionPayload(
                action="ADD",
                content="Test",
                embedding=None,  # No pre-computed embedding
            ),
            visibility=ChunkVisibility.PRIVATE,
            status="pending",
            created_at=datetime.now(timezone.utc),
        )

        with patch.object(orchestrator._store, "get", return_value=pending):
            # Should handle missing embedder gracefully or fail
            # depending on implementation
            approval_result = orchestrator.approve("pending-123", reviewed_by="admin")
            # If embedding is None and no embedder, this should fail
            # The implementation should handle this case
            assert approval_result is not None
