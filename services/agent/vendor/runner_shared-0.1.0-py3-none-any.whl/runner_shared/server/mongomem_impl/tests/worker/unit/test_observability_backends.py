"""Tests for WorkerObservability helper class.

Note: LoggingObservability and NoOpObservability are tested in
tests/core/unit/test_observability_protocol.py
"""

from runner_shared.server.mongomem_impl.src.mongomem_worker.observability import WorkerObservability

from ..conftest import RecordingMetrics


class TestWorkerObservability:
    """Tests for the worker-specific observability helper."""

    def test_task_claimed(self, recording_metrics: RecordingMetrics):
        obs = WorkerObservability(
            backend=recording_metrics,
            worker_id="worker-1",
            tenant_id="tenant-a",
        )

        obs.task_claimed("embedding")

        increments = recording_metrics.get_increments("tasks_claimed")
        assert len(increments) == 1
        assert increments[0]["tags"]["task_type"] == "embedding"
        assert increments[0]["tags"]["worker_id"] == "worker-1"
        assert increments[0]["tags"]["tenant_id"] == "tenant-a"

    def test_task_completed(self, recording_metrics: RecordingMetrics):
        obs = WorkerObservability(backend=recording_metrics)

        obs.task_completed("snapshot", duration_ms=150.5)

        increments = recording_metrics.get_increments("tasks_completed")
        assert len(increments) == 1
        assert increments[0]["tags"]["task_type"] == "snapshot"

        timings = recording_metrics.timings
        assert len(timings) == 1
        assert timings[0]["name"] == "task_duration"
        assert timings[0]["value_ms"] == 150.5

    def test_task_failed(self, recording_metrics: RecordingMetrics):
        obs = WorkerObservability(backend=recording_metrics)

        obs.task_failed("entity", "transient", "timeout")

        increments = recording_metrics.get_increments("tasks_failed")
        assert len(increments) == 1
        assert increments[0]["tags"]["task_type"] == "entity"
        assert increments[0]["tags"]["error_type"] == "transient"
        assert increments[0]["tags"]["error_taxonomy"] == "timeout"

    def test_task_timeout(self, recording_metrics: RecordingMetrics):
        obs = WorkerObservability(backend=recording_metrics)

        obs.task_timeout("maintenance", 300.0)

        increments = recording_metrics.get_increments("tasks_timeout")
        assert len(increments) == 1
        assert increments[0]["tags"]["task_type"] == "maintenance"
        assert increments[0]["tags"]["timeout"] == "300.0"

    def test_task_retried(self, recording_metrics: RecordingMetrics):
        obs = WorkerObservability(backend=recording_metrics)

        obs.task_retried("embedding", attempt=2)

        increments = recording_metrics.get_increments("tasks_retried")
        assert len(increments) == 1
        assert increments[0]["tags"]["attempt"] == "2"

    def test_queue_depth(self, recording_metrics: RecordingMetrics):
        obs = WorkerObservability(backend=recording_metrics)

        obs.queue_depth(42, status="queued")

        gauges = recording_metrics.get_gauges("queue_depth")
        assert len(gauges) == 1
        assert gauges[0]["value"] == 42
        assert gauges[0]["tags"]["status"] == "queued"

    def test_queue_time(self, recording_metrics: RecordingMetrics):
        obs = WorkerObservability(backend=recording_metrics)

        obs.queue_time("embedding", wait_ms=5000.0)

        histograms = recording_metrics.histograms
        assert len(histograms) == 1
        assert histograms[0]["name"] == "queue_wait_time"
        assert histograms[0]["value"] == 5000.0

    def test_worker_active(self, recording_metrics: RecordingMetrics):
        obs = WorkerObservability(backend=recording_metrics)

        obs.worker_active(True)
        obs.worker_active(False)

        gauges = recording_metrics.get_gauges("worker_active")
        assert len(gauges) == 2
        assert gauges[0]["value"] == 1.0
        assert gauges[1]["value"] == 0.0

    def test_worker_idle(self, recording_metrics: RecordingMetrics):
        obs = WorkerObservability(backend=recording_metrics)

        obs.worker_idle(120.5)

        gauges = recording_metrics.get_gauges("worker_idle_seconds")
        assert len(gauges) == 1
        assert gauges[0]["value"] == 120.5

    def test_active_tasks(self, recording_metrics: RecordingMetrics):
        obs = WorkerObservability(backend=recording_metrics)

        obs.active_tasks(3)

        gauges = recording_metrics.get_gauges("active_tasks")
        assert len(gauges) == 1
        assert gauges[0]["value"] == 3

    def test_change_stream_metrics(self, recording_metrics: RecordingMetrics):
        obs = WorkerObservability(backend=recording_metrics)

        obs.change_stream_active(True)
        obs.change_stream_reconnect()
        obs.change_stream_notification("memory_short_term")
        obs.change_stream_latency(25.5)

        gauges = recording_metrics.get_gauges("change_stream_active")
        assert gauges[0]["value"] == 1.0

        reconnects = recording_metrics.get_increments("change_stream_reconnects")
        assert len(reconnects) == 1

        notifications = recording_metrics.get_increments("change_stream_notifications")
        assert notifications[0]["tags"]["collection"] == "memory_short_term"

        histograms = recording_metrics.histograms
        assert any(h["name"] == "change_stream_latency" for h in histograms)

    def test_heartbeat_metrics(self, recording_metrics: RecordingMetrics):
        obs = WorkerObservability(backend=recording_metrics)

        obs.heartbeat_sent("embedding")
        obs.heartbeat_failed("embedding")

        sent = recording_metrics.get_increments("heartbeats_sent")
        assert len(sent) == 1

        failed = recording_metrics.get_increments("heartbeats_failed")
        assert len(failed) == 1

    def test_stale_tasks_reclaimed(self, recording_metrics: RecordingMetrics):
        obs = WorkerObservability(backend=recording_metrics)

        obs.stale_tasks_reclaimed(5)

        increments = recording_metrics.get_increments("stale_tasks_reclaimed")
        assert len(increments) == 1
        assert increments[0]["value"] == 5

    def test_track_task_duration_context_manager(self, recording_metrics: RecordingMetrics):
        obs = WorkerObservability(backend=recording_metrics)

        with obs.track_task_duration("embedding"):
            # Simulate some work
            pass

        increments = recording_metrics.get_increments("tasks_completed")
        assert len(increments) == 1

        timings = recording_metrics.timings
        assert len(timings) == 1
        assert timings[0]["value_ms"] >= 0

    def test_tags_include_worker_and_tenant(self, recording_metrics: RecordingMetrics):
        obs = WorkerObservability(
            backend=recording_metrics,
            worker_id="w-123",
            tenant_id="t-456",
        )

        obs.task_claimed("test")

        tags = recording_metrics.increments[0]["tags"]
        assert tags["worker_id"] == "w-123"
        assert tags["tenant_id"] == "t-456"

    def test_tags_without_worker_tenant(self, recording_metrics: RecordingMetrics):
        obs = WorkerObservability(backend=recording_metrics)

        obs.task_claimed("test")

        tags = recording_metrics.increments[0]["tags"]
        assert "worker_id" not in tags
        assert "tenant_id" not in tags
