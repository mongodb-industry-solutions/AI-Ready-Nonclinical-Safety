"""Unit tests for Internal State CRUD operations."""

from mongomem_core.memory.internal_state import (
    delete_internal_state,
    get_internal_state,
    mark_promoted,
    upsert_internal_state,
)
from mongomem_core.models.memory.internal_state import (
    InternalStateIn,
)


class TestUpsertInternalState:
    """Test upsert_internal_state function."""

    def test_first_upsert_creates_document_with_version_1(self, test_db):
        """First upsert creates document with version=1."""
        is_in = InternalStateIn(content="Agent believes X is true")

        result = upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        assert result.version == 1
        assert result.session_id == "sess_1"
        assert result.org_id == "org_1"
        assert result.content_hash is not None
        assert len(result.content_hash) == 64  # Full SHA256 (no truncation)
        assert result.was_insert is True

        # Verify full document via get
        doc = get_internal_state(test_db, "sess_1", "org_1")
        assert doc is not None
        assert doc.content.strip() == "Agent believes X is true"

    def test_second_upsert_increments_version(self, test_db):
        """Second upsert with different content increments version to 2."""
        is_in = InternalStateIn(content="Initial state")

        result1 = upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )
        assert result1.version == 1

        is_in2 = InternalStateIn(content="Updated state")
        result2 = upsert_internal_state(
            db=test_db,
            is_in=is_in2,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        assert result2.version == 2
        assert result2.previous_version == 1
        assert result2.was_noop is False

        # Verify content via get
        doc = get_internal_state(test_db, "sess_1", "org_1")
        assert doc.content.strip() == "Updated state"

    def test_upsert_overwrites_content(self, test_db):
        """Upsert replaces previous content entirely."""
        is_in1 = InternalStateIn(content="First content that is quite long")
        upsert_internal_state(
            db=test_db,
            is_in=is_in1,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        is_in2 = InternalStateIn(content="Short")
        upsert_internal_state(
            db=test_db,
            is_in=is_in2,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        # Verify via get
        doc = get_internal_state(test_db, "sess_1", "org_1")
        assert doc.content.strip() == "Short"

    def test_different_sessions_have_separate_documents(self, test_db):
        """Different sessions get separate IS documents."""
        is_in = InternalStateIn(content="Session 1 state")
        result1 = upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        is_in2 = InternalStateIn(content="Session 2 state")
        result2 = upsert_internal_state(
            db=test_db,
            is_in=is_in2,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_2",
        )

        assert result1.version == 1
        assert result2.version == 1
        assert result1.session_id == "sess_1"
        assert result2.session_id == "sess_2"

    def test_upsert_estimates_token_count(self, test_db):
        """Upsert estimates token count if not provided."""
        content = "This is a test content with about twenty tokens or so."
        is_in = InternalStateIn(content=content)

        result = upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        assert result.token_count > 0

        # Verify token_count_estimated via get
        doc = get_internal_state(test_db, "sess_1", "org_1")
        assert doc.token_count_estimated is True

    def test_upsert_preserves_provided_token_count(self, test_db):
        """Upsert uses provided token count when given."""
        is_in = InternalStateIn(
            content="Test content",
            token_count=42,
            token_count_estimated=False,
        )

        result = upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        assert result.token_count == 42

        # Verify via get
        doc = get_internal_state(test_db, "sess_1", "org_1")
        assert doc.token_count_estimated is False

    def test_upsert_stores_metadata(self, test_db):
        """Upsert stores model_id, agent_id, and metadata."""
        is_in = InternalStateIn(
            content="Test content",
            model_id="gpt-4",
            agent_id="agent_123",
            source_turn_id="turn_456",
            update_reason="explicit",
            metadata={"key": "value"},
        )

        upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        # Verify via get (must pass agent_id since it's part of the unique key)
        doc = get_internal_state(test_db, "sess_1", "org_1", agent_id="agent_123")
        assert doc is not None
        assert doc.model_id == "gpt-4"
        assert doc.agent_id == "agent_123"
        assert doc.source_turn_id == "turn_456"
        assert doc.update_reason == "explicit"
        assert doc.metadata == {"key": "value"}

    def test_upsert_defaults_empty_metadata(self, test_db):
        """Upsert stores empty metadata without triggering a Mongo pipeline error."""
        is_in = InternalStateIn(content="Test content")

        upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        doc = get_internal_state(test_db, "sess_1", "org_1")
        assert doc is not None
        assert doc.metadata == {}


class TestGetInternalState:
    """Test get_internal_state function."""

    def test_get_returns_none_when_not_found(self, test_db):
        """get_internal_state returns None when no document exists."""
        result = get_internal_state(
            db=test_db,
            session_id="nonexistent",
            org_id="org_1",
        )

        assert result is None

    def test_get_returns_document_when_exists(self, test_db):
        """get_internal_state returns the document when it exists."""
        is_in = InternalStateIn(content="Test content")
        upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        result = get_internal_state(
            db=test_db,
            session_id="sess_1",
            org_id="org_1",
        )

        assert result is not None
        # Content is normalized with trailing newline
        assert result.content.strip() == "Test content"
        assert result.session_id == "sess_1"
        assert result.id is not None  # Stringified ID

    def test_get_respects_org_isolation(self, test_db):
        """get_internal_state only returns documents for the correct org."""
        is_in = InternalStateIn(content="Org 1 content")
        upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        # Different org should not see it
        result = get_internal_state(
            db=test_db,
            session_id="sess_1",
            org_id="org_2",
        )

        assert result is None


class TestDeleteInternalState:
    """Test delete_internal_state function."""

    def test_delete_returns_true_when_document_exists(self, test_db):
        """delete_internal_state returns True when document was deleted."""
        is_in = InternalStateIn(content="Test content")
        upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        result = delete_internal_state(
            db=test_db,
            session_id="sess_1",
            org_id="org_1",
        )

        assert result is True

        # Verify it's actually deleted
        get_result = get_internal_state(
            db=test_db,
            session_id="sess_1",
            org_id="org_1",
        )
        assert get_result is None

    def test_delete_returns_false_when_not_found(self, test_db):
        """delete_internal_state returns False when no document to delete."""
        result = delete_internal_state(
            db=test_db,
            session_id="nonexistent",
            org_id="org_1",
        )

        assert result is False

    def test_delete_is_idempotent(self, test_db):
        """Calling delete twice doesn't error."""
        is_in = InternalStateIn(content="Test content")
        upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        # First delete
        result1 = delete_internal_state(
            db=test_db,
            session_id="sess_1",
            org_id="org_1",
        )
        assert result1 is True

        # Second delete
        result2 = delete_internal_state(
            db=test_db,
            session_id="sess_1",
            org_id="org_1",
        )
        assert result2 is False


class TestMarkPromoted:
    """Test mark_promoted function."""

    def test_mark_promoted_updates_timestamp(self, test_db):
        """mark_promoted sets last_promoted_at."""
        is_in = InternalStateIn(content="Test content")
        upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        result = mark_promoted(
            db=test_db,
            session_id="sess_1",
            org_id="org_1",
        )

        assert result is True

        # Verify the update
        state = get_internal_state(
            db=test_db,
            session_id="sess_1",
            org_id="org_1",
        )
        assert state is not None
        assert state.last_promoted_at is not None
        assert state.promotion_count == 1

    def test_mark_promoted_increments_count(self, test_db):
        """mark_promoted increments promotion_count."""
        is_in = InternalStateIn(content="Test content")
        upsert_internal_state(
            db=test_db,
            is_in=is_in,
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
        )

        # Promote twice
        mark_promoted(db=test_db, session_id="sess_1", org_id="org_1")
        mark_promoted(db=test_db, session_id="sess_1", org_id="org_1")

        state = get_internal_state(
            db=test_db,
            session_id="sess_1",
            org_id="org_1",
        )
        assert state is not None
        assert state.promotion_count == 2

    def test_mark_promoted_returns_false_when_not_found(self, test_db):
        """mark_promoted returns False when no document exists."""
        result = mark_promoted(
            db=test_db,
            session_id="nonexistent",
            org_id="org_1",
        )

        assert result is False
