"""Unit tests for extraction persistence module."""

from datetime import datetime, timezone
from unittest.mock import MagicMock

import pytest
from bson import ObjectId
from mongomem_core.extraction.config import (
    SemanticExtractionConfig,
)
from mongomem_core.extraction.persistence import (
    apply_decisions,
    generate_extraction_id,
    perform_add,
    perform_reinforce,
    perform_update,
)
from mongomem_core.extraction.types import (
    ConsolidationDecision,
    ScoredExtraction,
)
from mongomem_core.storage.collections import (
    SemanticMemoryCollection,
)

# Use canonical collection name
SEMANTIC_COLLECTION = SemanticMemoryCollection.name


class TestGenerateExtractionId:
    """Tests for generate_extraction_id function."""

    def test_deterministic(self):
        """Test that same inputs produce same ID."""
        id1 = generate_extraction_id("source1", "content1")
        id2 = generate_extraction_id("source1", "content1")

        assert id1 == id2

    def test_different_source(self):
        """Test that different sources produce different IDs."""
        id1 = generate_extraction_id("source1", "content")
        id2 = generate_extraction_id("source2", "content")

        assert id1 != id2

    def test_different_content(self):
        """Test that different content produces different IDs."""
        id1 = generate_extraction_id("source", "content1")
        id2 = generate_extraction_id("source", "content2")

        assert id1 != id2

    def test_with_idempotency_key(self):
        """Test with additional idempotency key."""
        id1 = generate_extraction_id("source", "content", "key1")
        id2 = generate_extraction_id("source", "content", "key2")
        id3 = generate_extraction_id("source", "content")

        assert id1 != id2
        assert id1 != id3
        assert id2 != id3

    def test_returns_sha256_hex(self):
        """Test that output is SHA-256 hex string."""
        id1 = generate_extraction_id("source", "content")

        # SHA-256 produces 64 character hex string
        assert len(id1) == 64
        assert all(c in "0123456789abcdef" for c in id1)


class TestPerformAdd:
    """Tests for perform_add function."""

    @pytest.fixture
    def mock_db(self):
        """Mock database with collection."""
        db = MagicMock()
        col = MagicMock()
        db.__getitem__.return_value = col
        return db

    @pytest.fixture
    def decision(self):
        """Sample ADD decision."""
        extraction = ScoredExtraction(
            content="The user likes Python",
            citations=[0],
            confidence=0.9,
            citation_score=1.0,
            combined_score=0.96,
            is_valid=True,
            embedding=[0.1, 0.2, 0.3],
            cited_text=[{"cited_idx": 0, "cited_text": {"role": "user", "content": "test"}}],
            metadata={"key": "value"},
        )
        return ConsolidationDecision(
            extraction=extraction,
            action="ADD",
            reason="new fact",
        )

    def test_successful_insert(self, mock_db, decision):
        """Test successful document insertion."""
        col = mock_db[SEMANTIC_COLLECTION]
        col.update_one.return_value = MagicMock(
            upserted_id=ObjectId("507f1f77bcf86cd799439011"),
            matched_count=0,
        )

        result = perform_add(
            db=mock_db,
            decision=decision,
            org_id="org1",
            user_id="user1",
            source_id="snapshot_123",
            extraction_timestamp=datetime.now(timezone.utc),
            embedding_model_id="text-embedding-ada-002",
        )

        assert result == "507f1f77bcf86cd799439011"
        col.update_one.assert_called()

    def test_idempotent_duplicate(self, mock_db, decision):
        """Test idempotent handling of duplicate extraction."""
        col = mock_db[SEMANTIC_COLLECTION]
        col.update_one.return_value = MagicMock(
            upserted_id=None,  # No upsert - document existed
            matched_count=1,
        )

        result = perform_add(
            db=mock_db,
            decision=decision,
            org_id="org1",
            user_id="user1",
            source_id="snapshot_123",
            extraction_timestamp=datetime.now(timezone.utc),
            embedding_model_id="text-embedding-ada-002",
        )

        # Should return None for idempotent duplicate
        assert result is None

    def test_uses_setOnInsert_for_idempotency(self, mock_db, decision):
        """Test that $setOnInsert is used for idempotent upsert."""
        col = mock_db[SEMANTIC_COLLECTION]
        col.update_one.return_value = MagicMock(
            upserted_id=ObjectId(),
            matched_count=0,
        )

        perform_add(
            db=mock_db,
            decision=decision,
            org_id="org1",
            user_id="user1",
            source_id="snapshot_123",
            extraction_timestamp=datetime.now(timezone.utc),
            embedding_model_id="text-embedding-ada-002",
        )

        # First call should be the idempotent upsert with $setOnInsert
        first_call_args = col.update_one.call_args_list[0]
        update_doc = first_call_args[0][1]
        assert "$setOnInsert" in update_doc


class TestPerformUpdate:
    """Tests for perform_update function."""

    @pytest.fixture
    def mock_db(self):
        """Mock database with collection."""
        db = MagicMock()
        col = MagicMock()
        db.__getitem__.return_value = col
        return db

    @pytest.fixture
    def decision(self):
        """Sample UPDATE decision."""
        extraction = ScoredExtraction(
            content="The user now prefers Rust",
            citations=[0],
            confidence=0.95,
            citation_score=1.0,
            combined_score=0.98,
            is_valid=True,
            embedding=[0.4, 0.5, 0.6],
        )
        return ConsolidationDecision(
            extraction=extraction,
            action="UPDATE",
            existing_id="507f1f77bcf86cd799439011",
            reason="supersedes existing",
        )

    def test_missing_existing_id(self, mock_db):
        """Test handling of missing existing_id."""
        extraction = ScoredExtraction(
            content="New content",
            citations=[],
            confidence=0.9,
            citation_score=0.0,
            combined_score=0.36,
            is_valid=True,
        )
        decision = ConsolidationDecision(
            extraction=extraction,
            action="UPDATE",
            existing_id=None,  # Missing
        )

        result = perform_update(
            db=mock_db,
            decision=decision,
            org_id="org1",
            user_id="user1",
            source_id="snapshot_123",
            extraction_timestamp=datetime.now(timezone.utc),
            embedding_model_id="text-embedding-ada-002",
        )

        assert result is None

    def test_existing_not_found(self, mock_db, decision):
        """Test handling when existing document not found."""
        col = mock_db[SEMANTIC_COLLECTION]
        col.find_one.return_value = None  # Not found

        result = perform_update(
            db=mock_db,
            decision=decision,
            org_id="org1",
            user_id="user1",
            source_id="snapshot_123",
            extraction_timestamp=datetime.now(timezone.utc),
            embedding_model_id="text-embedding-ada-002",
        )

        assert result is None


class TestPerformReinforce:
    """Tests for perform_reinforce function."""

    @pytest.fixture
    def mock_db(self):
        """Mock database with collection."""
        db = MagicMock()
        col = MagicMock()
        db.__getitem__.return_value = col
        return db

    @pytest.fixture
    def decision(self):
        """Sample REINFORCE decision."""
        extraction = ScoredExtraction(
            content="The user likes Python",
            citations=[0],
            confidence=0.9,
            citation_score=1.0,
            combined_score=0.96,
            is_valid=True,
        )
        return ConsolidationDecision(
            extraction=extraction,
            action="REINFORCE",
            existing_id="507f1f77bcf86cd799439011",
            reason="semantic duplicate",
        )

    def test_missing_existing_id(self, mock_db):
        """Test handling of missing existing_id."""
        extraction = ScoredExtraction(
            content="Content",
            citations=[],
            confidence=0.9,
            citation_score=0.0,
            combined_score=0.36,
            is_valid=True,
        )
        decision = ConsolidationDecision(
            extraction=extraction,
            action="REINFORCE",
            existing_id=None,
        )

        result = perform_reinforce(
            db=mock_db,
            decision=decision,
            org_id="org1",
            source_id="snapshot_123",
            extraction_timestamp=datetime.now(timezone.utc),
        )

        assert result is None

    def test_successful_reinforce(self, mock_db, decision):
        """Test successful reinforcement."""
        col = mock_db[SEMANTIC_COLLECTION]
        col.update_one.return_value = MagicMock(
            modified_count=1,
            matched_count=1,
        )

        result = perform_reinforce(
            db=mock_db,
            decision=decision,
            org_id="org1",
            source_id="snapshot_123",
            extraction_timestamp=datetime.now(timezone.utc),
        )

        assert result == "507f1f77bcf86cd799439011"

    def test_idempotent_already_reinforced(self, mock_db, decision):
        """Test idempotent when already reinforced from same source."""
        col = mock_db[SEMANTIC_COLLECTION]
        col.update_one.return_value = MagicMock(
            modified_count=0,  # Not modified (idempotent)
            matched_count=1,
        )

        result = perform_reinforce(
            db=mock_db,
            decision=decision,
            org_id="org1",
            source_id="snapshot_123",
            extraction_timestamp=datetime.now(timezone.utc),
        )

        # Should still return ID (idempotent success)
        assert result == "507f1f77bcf86cd799439011"

    def test_document_not_found(self, mock_db, decision):
        """Test when document doesn't exist."""
        col = mock_db[SEMANTIC_COLLECTION]
        col.update_one.return_value = MagicMock(
            modified_count=0,
            matched_count=0,  # Not found
        )

        result = perform_reinforce(
            db=mock_db,
            decision=decision,
            org_id="org1",
            source_id="snapshot_123",
            extraction_timestamp=datetime.now(timezone.utc),
        )

        assert result is None

    def test_uses_aggregation_pipeline(self, mock_db, decision):
        """Test that aggregation pipeline is used for atomic update."""
        col = mock_db[SEMANTIC_COLLECTION]
        col.update_one.return_value = MagicMock(modified_count=1, matched_count=1)

        perform_reinforce(
            db=mock_db,
            decision=decision,
            org_id="org1",
            source_id="snapshot_123",
            extraction_timestamp=datetime.now(timezone.utc),
        )

        call_args = col.update_one.call_args
        update_doc = call_args[0][1]
        # Aggregation pipeline is a list
        assert isinstance(update_doc, list)


class TestApplyDecisions:
    """Tests for apply_decisions function."""

    @pytest.fixture
    def mock_db(self):
        """Mock database with collection."""
        db = MagicMock()
        col = MagicMock()
        db.__getitem__.return_value = col
        return db

    @pytest.fixture
    def config(self):
        """Default config."""
        return SemanticExtractionConfig()

    def test_empty_decisions(self, mock_db, config):
        """Test with empty decisions list."""
        result = apply_decisions(
            db=mock_db,
            decisions=[],
            org_id="org1",
            user_id="user1",
            source_id="snapshot_123",
            extraction_timestamp=datetime.now(timezone.utc),
            embedding_model_id="text-embedding-ada-002",
            config=config,
        )

        assert result.added == 0
        assert result.updated == 0
        assert result.reinforced == 0
        assert result.skipped == 0

    def test_handles_duplicate_action(self, mock_db, config):
        """Test DUPLICATE action is skipped."""
        extraction = ScoredExtraction(
            content="Content",
            citations=[],
            confidence=0.9,
            citation_score=0.0,
            combined_score=0.36,
            is_valid=True,
        )
        decisions = [
            ConsolidationDecision(
                extraction=extraction,
                action="DUPLICATE",
                reason="duplicate",
            )
        ]

        result = apply_decisions(
            db=mock_db,
            decisions=decisions,
            org_id="org1",
            user_id="user1",
            source_id="snapshot_123",
            extraction_timestamp=datetime.now(timezone.utc),
            embedding_model_id="text-embedding-ada-002",
            config=config,
        )

        assert result.skipped == 1

    def test_error_handling(self, mock_db, config):
        """Test errors are captured in result."""
        col = mock_db[SEMANTIC_COLLECTION]
        col.update_one.side_effect = Exception("Database error")

        extraction = ScoredExtraction(
            content="Content",
            citations=[],
            confidence=0.9,
            citation_score=0.0,
            combined_score=0.36,
            is_valid=True,
            embedding=[0.1, 0.2],
        )
        decisions = [
            ConsolidationDecision(
                extraction=extraction,
                action="ADD",
            )
        ]

        result = apply_decisions(
            db=mock_db,
            decisions=decisions,
            org_id="org1",
            user_id="user1",
            source_id="snapshot_123",
            extraction_timestamp=datetime.now(timezone.utc),
            embedding_model_id="text-embedding-ada-002",
            config=config,
        )

        assert len(result.errors) == 1
        assert "Database error" in result.errors[0]
