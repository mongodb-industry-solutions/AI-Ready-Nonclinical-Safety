"""
Unit tests for ranking and scoring logic.

These tests validate the MemoryRanker class, including multi-factor scoring,
recency decay, weight configuration, and ranking score calculations.
"""

import math
from datetime import datetime, timedelta, timezone

import pytest
from mongomem_core.common.utils import utcnow
from mongomem_core.models.retrieval import (
    ContextConfig,
    MemoryChunk,
    MemorySource,
)
from mongomem_core.retrieval.ranking import MemoryRanker


class TestMemoryRankerInitialization:
    """Tests for MemoryRanker initialization."""

    def test_default_initialization(self):
        """MemoryRanker initializes with default weights."""
        ranker = MemoryRanker()
        assert ranker.similarity_weight == 0.6
        assert ranker.recency_weight == 0.3
        assert ranker.importance_weight == 0.1
        assert ranker.recency_decay_rate == 0.1

    def test_custom_initialization(self):
        """MemoryRanker accepts custom weights and decay rate."""
        ranker = MemoryRanker(
            similarity_weight=0.7,
            recency_weight=0.2,
            importance_weight=0.1,
            recency_decay_rate=0.05,
        )
        assert ranker.similarity_weight == 0.7
        assert ranker.recency_weight == 0.2
        assert ranker.importance_weight == 0.1
        assert ranker.recency_decay_rate == 0.05


class TestGetWeights:
    """Tests for _get_weights method."""

    def test_default_weights(self):
        """Uses default weights when config has no ranking_weights."""
        ranker = MemoryRanker()
        config = ContextConfig()
        weights = ranker._get_weights(config)
        assert weights["similarity"] == pytest.approx(0.6)
        assert weights["recency"] == pytest.approx(0.3)
        assert weights["importance"] == pytest.approx(0.1)

    def test_config_weights_override(self):
        """Config ranking_weights override default weights."""
        ranker = MemoryRanker()
        config = ContextConfig(
            ranking_weights={"similarity": 0.8, "recency": 0.15, "importance": 0.05}
        )
        weights = ranker._get_weights(config)
        assert weights["similarity"] == pytest.approx(0.8)
        assert weights["recency"] == pytest.approx(0.15)
        assert weights["importance"] == pytest.approx(0.05)

    def test_config_weights_partial_override(self):
        """Config weights can partially override (missing keys use defaults), and weights are normalized."""
        ranker = MemoryRanker()
        config = ContextConfig(ranking_weights={"similarity": 0.9})
        weights = ranker._get_weights(config)
        # Should use config similarity (0.9), but defaults for recency (0.3) and importance (0.1)
        # Total = 0.9 + 0.3 + 0.1 = 1.3, so normalized values are:
        assert weights["similarity"] == pytest.approx(0.9 / 1.3)  # 0.6923...
        assert weights["recency"] == pytest.approx(0.3 / 1.3)  # 0.2307...
        assert weights["importance"] == pytest.approx(0.1 / 1.3)  # 0.0769...
        # Verify weights sum to 1.0
        total = weights["similarity"] + weights["recency"] + weights["importance"]
        assert total == pytest.approx(1.0)

    def test_weight_normalization(self):
        """Weights are normalized when total > 0."""
        ranker = MemoryRanker()
        config = ContextConfig(
            ranking_weights={"similarity": 2.0, "recency": 1.0, "importance": 1.0}
        )
        weights = ranker._get_weights(config)
        total = weights["similarity"] + weights["recency"] + weights["importance"]
        assert total == pytest.approx(1.0)
        assert weights["similarity"] == pytest.approx(0.5)  # 2.0 / 4.0
        assert weights["recency"] == pytest.approx(0.25)  # 1.0 / 4.0
        assert weights["importance"] == pytest.approx(0.25)  # 1.0 / 4.0

    def test_zero_total_weight(self):
        """Returns normalized default weights when total weight is zero."""
        ranker = MemoryRanker()
        config = ContextConfig(
            ranking_weights={"similarity": 0.0, "recency": 0.0, "importance": 0.0}
        )
        weights = ranker._get_weights(config)
        # Should return normalized defaults (0.6, 0.3, 0.1 sum to 1.0, so same values)
        assert weights["similarity"] == pytest.approx(0.6)
        assert weights["recency"] == pytest.approx(0.3)
        assert weights["importance"] == pytest.approx(0.1)
        # Verify weights sum to 1.0
        total = weights["similarity"] + weights["recency"] + weights["importance"]
        assert total == pytest.approx(1.0)


class TestGetSimilarityScore:
    """Tests for _get_similarity_score method."""

    def test_valid_similarity_score(self):
        """Extracts similarity score from memory chunk."""
        ranker = MemoryRanker()
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=utcnow(),
            similarity_score=0.85,
        )
        score = ranker._get_similarity_score(memory)
        assert score == 0.85

    def test_missing_similarity_score(self):
        """Returns 0.0 when similarity_score is None."""
        ranker = MemoryRanker()
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.STM,
            timestamp=utcnow(),
            similarity_score=None,
        )
        score = ranker._get_similarity_score(memory)
        assert score == 0.0

    def test_similarity_score_clamping_above_one(self):
        """Clamps similarity score above 1.0 to 1.0."""
        ranker = MemoryRanker()
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=utcnow(),
            similarity_score=1.5,
        )
        score = ranker._get_similarity_score(memory)
        assert score == 1.0

    def test_similarity_score_clamping_below_zero(self):
        """Clamps similarity score below 0.0 to 0.0."""
        ranker = MemoryRanker()
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=utcnow(),
            similarity_score=-0.5,
        )
        score = ranker._get_similarity_score(memory)
        assert score == 0.0

    def test_similarity_score_numeric_types(self):
        """Handles different numeric types (int, float)."""
        ranker = MemoryRanker()
        # Test with int
        memory1 = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=utcnow(),
            similarity_score=1,  # int
        )
        score1 = ranker._get_similarity_score(memory1)
        assert score1 == 1.0

        # Test with float
        memory2 = MemoryChunk(
            id="mem_2",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=utcnow(),
            similarity_score=0.75,  # float
        )
        score2 = ranker._get_similarity_score(memory2)
        assert score2 == 0.75


class TestCalculateRecencyScore:
    """Tests for _calculate_recency_score method."""

    def test_recent_memory_high_score(self):
        """Recent memories get high recency scores."""
        ranker = MemoryRanker(recency_decay_rate=0.1)
        now = datetime.now(timezone.utc)
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.EPISODIC,
            timestamp=now - timedelta(hours=1),  # 1 hour ago
        )
        score = ranker._calculate_recency_score(memory, now)
        # Should be close to 1.0 (very recent)
        assert score > 0.99
        assert score <= 1.0

    def test_old_memory_low_score(self):
        """Old memories get low recency scores."""
        ranker = MemoryRanker(recency_decay_rate=0.1)
        now = datetime.now(timezone.utc)
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.EPISODIC,
            timestamp=now - timedelta(days=30),  # 30 days ago
        )
        score = ranker._calculate_recency_score(memory, now)
        # Should be low (exp(-0.1 * 30) ≈ 0.05)
        assert score < 0.1
        assert score > 0.0

    def test_exponential_decay_formula(self):
        """Recency score follows exponential decay formula."""
        ranker = MemoryRanker(recency_decay_rate=0.1)
        now = datetime.now(timezone.utc)
        days_old = 10
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.EPISODIC,
            timestamp=now - timedelta(days=days_old),
        )
        score = ranker._calculate_recency_score(memory, now)
        expected = math.exp(-0.1 * days_old)
        assert score == pytest.approx(expected, rel=1e-6)

    def test_timezone_naive_timestamp(self):
        """Handles timezone-naive timestamps (assumes UTC)."""
        ranker = MemoryRanker()
        now = datetime.now(timezone.utc)
        # Create timezone-naive timestamp
        naive_timestamp = datetime.now()  # No timezone
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.EPISODIC,
            timestamp=naive_timestamp,
        )
        # Should not raise error
        score = ranker._calculate_recency_score(memory, now)
        assert 0.0 <= score <= 1.0

    def test_timezone_aware_timestamp(self):
        """Handles timezone-aware timestamps correctly."""
        ranker = MemoryRanker()
        now = datetime.now(timezone.utc)
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.EPISODIC,
            timestamp=now - timedelta(hours=2),
        )
        score = ranker._calculate_recency_score(memory, now)
        assert 0.0 <= score <= 1.0
        assert score > 0.9  # Very recent

    def test_future_timestamp(self):
        """Future timestamps result in days_old = 0 (max recency score)."""
        ranker = MemoryRanker()
        now = datetime.now(timezone.utc)
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.EPISODIC,
            timestamp=now + timedelta(days=1),  # Future
        )
        score = ranker._calculate_recency_score(memory, now)
        # Should be 1.0 (max) since days_old = 0
        assert score == 1.0

    def test_recency_score_clamping(self):
        """Recency score is clamped to [0.0, 1.0]."""
        ranker = MemoryRanker(recency_decay_rate=0.1)
        now = datetime.now(timezone.utc)
        # Very old memory
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.EPISODIC,
            timestamp=now - timedelta(days=365),  # 1 year ago
        )
        score = ranker._calculate_recency_score(memory, now)
        assert 0.0 <= score <= 1.0

    def test_custom_decay_rate(self):
        """Custom decay rate affects recency scoring."""
        # Fast decay
        fast_ranker = MemoryRanker(recency_decay_rate=0.5)
        # Slow decay
        slow_ranker = MemoryRanker(recency_decay_rate=0.01)

        now = datetime.now(timezone.utc)
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.EPISODIC,
            timestamp=now - timedelta(days=10),
        )

        fast_score = fast_ranker._calculate_recency_score(memory, now)
        slow_score = slow_ranker._calculate_recency_score(memory, now)

        # Slow decay should give higher score (memories stay "fresh" longer)
        assert slow_score > fast_score


class TestGetImportanceScore:
    """Tests for _get_importance_score method."""

    def test_valid_importance_in_metadata(self):
        """Extracts importance score from metadata."""
        ranker = MemoryRanker()
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=utcnow(),
            metadata={"importance": 0.8},
        )
        score = ranker._get_importance_score(memory)
        assert score == 0.8

    def test_missing_importance(self):
        """Returns 0.0 when importance is not in metadata."""
        ranker = MemoryRanker()
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.STM,
            timestamp=utcnow(),
            metadata={},
        )
        score = ranker._get_importance_score(memory)
        assert score == 0.0

    def test_none_metadata(self):
        """Returns 0.0 when metadata is None or empty."""
        ranker = MemoryRanker()
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.STM,
            timestamp=utcnow(),
            metadata=None,
        )
        score = ranker._get_importance_score(memory)
        assert score == 0.0

    def test_importance_score_clamping_above_one(self):
        """Clamps importance score above 1.0 to 1.0."""
        ranker = MemoryRanker()
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=utcnow(),
            metadata={"importance": 1.5},
        )
        score = ranker._get_importance_score(memory)
        assert score == 1.0

    def test_importance_score_clamping_below_zero(self):
        """Clamps importance score below 0.0 to 0.0."""
        ranker = MemoryRanker()
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=utcnow(),
            metadata={"importance": -0.3},
        )
        score = ranker._get_importance_score(memory)
        assert score == 0.0

    def test_invalid_importance_type_string(self):
        """Handles invalid importance type (string) gracefully."""
        ranker = MemoryRanker()
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=utcnow(),
            metadata={"importance": "not_a_number"},
        )
        score = ranker._get_importance_score(memory)
        assert score == 0.0  # Should default to 0.0 on error

    def test_invalid_importance_type_dict(self):
        """Handles invalid importance type (dict) gracefully."""
        ranker = MemoryRanker()
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=utcnow(),
            metadata={"importance": {"nested": "dict"}},
        )
        score = ranker._get_importance_score(memory)
        assert score == 0.0  # Should default to 0.0 on error

    def test_importance_numeric_types(self):
        """Handles different numeric types (int, float)."""
        ranker = MemoryRanker()
        # Test with int
        memory1 = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=utcnow(),
            metadata={"importance": 1},  # int
        )
        score1 = ranker._get_importance_score(memory1)
        assert score1 == 1.0

        # Test with float
        memory2 = MemoryChunk(
            id="mem_2",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=utcnow(),
            metadata={"importance": 0.75},  # float
        )
        score2 = ranker._get_importance_score(memory2)
        assert score2 == 0.75


class TestRankMemories:
    """Tests for rank_memories method."""

    def test_empty_memories_list(self):
        """Returns empty list when given empty memories."""
        ranker = MemoryRanker()
        config = ContextConfig()
        result = ranker.rank_memories([], config)
        assert result == []

    def test_single_memory_ranking(self):
        """Ranks a single memory correctly."""
        ranker = MemoryRanker()
        config = ContextConfig()
        now = datetime.now(timezone.utc)
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=now - timedelta(hours=1),
            similarity_score=0.9,
            metadata={"importance": 0.8},
        )
        result = ranker.rank_memories([memory], config)
        assert len(result) == 1
        assert result[0].id == "mem_1"
        assert "ranking_scores" in result[0].metadata
        assert "final_score" in result[0].metadata["ranking_scores"]

    def test_multiple_memories_sorted_by_final_score(self):
        """Memories are sorted by final_score (descending)."""
        ranker = MemoryRanker()
        config = ContextConfig()
        now = datetime.now(timezone.utc)

        # Memory 1: High similarity, recent, high importance
        mem1 = MemoryChunk(
            id="mem_1",
            content="High score",
            source=MemorySource.SEMANTIC,
            timestamp=now - timedelta(hours=1),
            similarity_score=0.95,
            metadata={"importance": 0.9},
        )

        # Memory 2: Low similarity, old, low importance
        mem2 = MemoryChunk(
            id="mem_2",
            content="Low score",
            source=MemorySource.SEMANTIC,
            timestamp=now - timedelta(days=30),
            similarity_score=0.3,
            metadata={"importance": 0.1},
        )

        # Memory 3: Medium similarity, recent, medium importance
        mem3 = MemoryChunk(
            id="mem_3",
            content="Medium score",
            source=MemorySource.SEMANTIC,
            timestamp=now - timedelta(hours=2),
            similarity_score=0.6,
            metadata={"importance": 0.5},
        )

        result = ranker.rank_memories([mem2, mem1, mem3], config)
        assert len(result) == 3
        # Should be sorted by final_score descending
        assert result[0].id == "mem_1"  # Highest score
        assert result[1].id == "mem_3"  # Medium score
        assert result[2].id == "mem_2"  # Lowest score

        # Verify scores are in descending order
        scores = [m.metadata["ranking_scores"]["final_score"] for m in result]
        assert scores == sorted(scores, reverse=True)

    def test_ranking_scores_stored_in_metadata(self):
        """Ranking scores are stored in memory metadata."""
        ranker = MemoryRanker()
        config = ContextConfig()
        now = datetime.now(timezone.utc)
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=now - timedelta(hours=1),
            similarity_score=0.8,
            metadata={"importance": 0.7},
        )
        result = ranker.rank_memories([memory], config)
        ranking_scores = result[0].metadata["ranking_scores"]
        assert "similarity" in ranking_scores
        assert "recency" in ranking_scores
        assert "importance" in ranking_scores
        assert "final_score" in ranking_scores
        assert ranking_scores["similarity"] == 0.8
        assert ranking_scores["importance"] == 0.7
        assert ranking_scores["final_score"] > 0

    def test_weighted_combination(self):
        """Final score is weighted combination of all factors."""
        ranker = MemoryRanker(
            similarity_weight=0.5,
            recency_weight=0.3,
            importance_weight=0.2,
        )
        config = ContextConfig()
        now = datetime.now(timezone.utc)
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=now - timedelta(hours=1),
            similarity_score=1.0,
            metadata={"importance": 1.0},
        )
        result = ranker.rank_memories([memory], config)
        ranking_scores = result[0].metadata["ranking_scores"]
        similarity = ranking_scores["similarity"]
        recency = ranking_scores["recency"]
        importance = ranking_scores["importance"]
        final_score = ranking_scores["final_score"]

        # Verify weighted combination (with normalization)
        expected = (0.5 * similarity + 0.3 * recency + 0.2 * importance) / (0.5 + 0.3 + 0.2)
        assert final_score == pytest.approx(expected, rel=1e-6)

    def test_config_weights_override_defaults(self):
        """Config ranking_weights override ranker defaults."""
        ranker = MemoryRanker()  # Default: 0.6, 0.3, 0.1
        config = ContextConfig(
            ranking_weights={"similarity": 0.8, "recency": 0.15, "importance": 0.05}
        )
        now = datetime.now(timezone.utc)
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=now - timedelta(hours=1),
            similarity_score=0.9,
            metadata={"importance": 0.5},
        )
        result = ranker.rank_memories([memory], config)
        # Should use config weights (0.8, 0.15, 0.05) not defaults
        # This is verified by checking the final score calculation
        ranking_scores = result[0].metadata["ranking_scores"]
        similarity = ranking_scores["similarity"]
        recency = ranking_scores["recency"]
        importance = ranking_scores["importance"]
        final_score = ranking_scores["final_score"]

        # With config weights normalized: 0.8/1.0, 0.15/1.0, 0.05/1.0
        expected = 0.8 * similarity + 0.15 * recency + 0.05 * importance
        assert final_score == pytest.approx(expected, rel=1e-6)

    def test_memories_without_similarity_scores(self):
        """Handles memories without similarity scores (defaults to 0.0)."""
        ranker = MemoryRanker()
        config = ContextConfig()
        now = datetime.now(timezone.utc)
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.STM,  # STM typically doesn't have similarity scores
            timestamp=now - timedelta(hours=1),
            similarity_score=None,
        )
        result = ranker.rank_memories([memory], config)
        ranking_scores = result[0].metadata["ranking_scores"]
        assert ranking_scores["similarity"] == 0.0
        # Final score should still be calculated (using recency and importance)
        assert ranking_scores["final_score"] >= 0.0

    def test_memories_without_importance(self):
        """Handles memories without importance scores (defaults to 0.0)."""
        ranker = MemoryRanker()
        config = ContextConfig()
        now = datetime.now(timezone.utc)
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.EPISODIC,
            timestamp=now - timedelta(hours=1),
            similarity_score=0.8,
            metadata={},  # No importance
        )
        result = ranker.rank_memories([memory], config)
        ranking_scores = result[0].metadata["ranking_scores"]
        assert ranking_scores["importance"] == 0.0
        # Final score should still be calculated (using similarity and recency)
        assert ranking_scores["final_score"] >= 0.0

    def test_all_factors_combined(self):
        """All three factors (similarity, recency, importance) contribute to final score."""
        ranker = MemoryRanker()
        config = ContextConfig()
        now = datetime.now(timezone.utc)

        # Memory with all factors
        memory = MemoryChunk(
            id="mem_1",
            content="Test",
            source=MemorySource.SEMANTIC,
            timestamp=now - timedelta(hours=1),  # Recent
            similarity_score=0.9,  # High similarity
            metadata={"importance": 0.8},  # High importance
        )
        result = ranker.rank_memories([memory], config)
        ranking_scores = result[0].metadata["ranking_scores"]

        # All factors should be > 0
        assert ranking_scores["similarity"] > 0
        assert ranking_scores["recency"] > 0
        assert ranking_scores["importance"] > 0
        assert ranking_scores["final_score"] > 0

        # Final score should be reasonable combination
        assert (
            ranking_scores["final_score"] > ranking_scores["similarity"] * 0.5
        )  # At least half of similarity
        assert ranking_scores["final_score"] < 1.0  # Should not exceed 1.0
