"""Test package root for mongodb-agentic-memory."""
