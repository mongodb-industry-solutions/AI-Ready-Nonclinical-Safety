"""
Integration tests for the full approval workflow.

Tests end-to-end flows including staging, approval, rejection,
and unpublish with restage.
"""

from datetime import timedelta
from unittest.mock import MagicMock, patch

import pytest
from bson import ObjectId
from mongomem_core.extraction.approval.orchestrator import ApprovalOrchestrator
from mongomem_core.extraction.approval.store import PendingStore
from mongomem_core.extraction.approval.types import (
    PendingDecisionPayload,
    PendingPreferencesPayload,
)
from mongomem_core.models.memory.base import ChunkVisibility


class MockDatabase:
    """Mock database that tracks inserts for testing."""

    def __init__(self):
        self._documents = {}
        self._collections = {}

    def __getitem__(self, name):
        if name not in self._collections:
            self._documents[name] = {}
            self._collections[name] = self._create_collection(name)
        return self._collections[name]

    def _create_collection(self, name):
        col = MagicMock()
        docs = self._documents[name]

        def insert_one(doc):
            doc_id = doc.get("_id") or ObjectId()
            doc["_id"] = doc_id
            docs[str(doc_id)] = doc.copy()
            return MagicMock(inserted_id=doc_id)

        def find_one(query):
            oid = query.get("_id")
            if oid:
                return docs.get(str(oid))
            return None

        def update_one(query, update):
            oid = query.get("_id")
            if oid and str(oid) in docs:
                doc = docs[str(oid)]
                # Check if other query conditions match
                matches = True
                for key, expected in query.items():
                    if key == "_id":
                        continue
                    if isinstance(expected, dict) and "$ne" in expected:
                        # Handle $ne operator
                        if doc.get(key) == expected["$ne"]:
                            matches = False
                            break
                    elif doc.get(key) != expected:
                        matches = False
                        break
                if matches:
                    for key, value in update.get("$set", {}).items():
                        doc[key] = value
                    return MagicMock(modified_count=1)
            return MagicMock(modified_count=0)

        def find_one_and_update(query, update, **kwargs):
            """Mock find_one_and_update - returns original doc before update."""
            oid = query.get("_id")
            if oid and str(oid) in docs:
                doc = docs[str(oid)]
                # Check if other query conditions match
                matches = True
                for key, expected in query.items():
                    if key == "_id":
                        continue
                    if doc.get(key) != expected:
                        matches = False
                        break
                if matches:
                    # Return original doc before update (default behavior)
                    original = doc.copy()
                    for key, value in update.get("$set", {}).items():
                        doc[key] = value
                    return original
            return None

        col.insert_one = insert_one
        col.find_one = find_one
        col.update_one = update_one
        col.find_one_and_update = find_one_and_update
        col.insert_many = MagicMock(
            side_effect=lambda docs_list: MagicMock(inserted_ids=[ObjectId() for _ in docs_list])
        )
        col.find = MagicMock(
            return_value=MagicMock(
                limit=MagicMock(return_value=MagicMock(sort=MagicMock(return_value=[])))
            )
        )

        return col


def create_mock_db():
    """Create a mock database that tracks inserts."""
    return MockDatabase()


class TestApprovalWorkflowIntegration:
    """Integration tests for the approval workflow."""

    @pytest.fixture
    def mock_db(self):
        """Create a mock database that tracks inserts."""
        return create_mock_db()

    @pytest.fixture
    def mock_embedder(self):
        """Create a mock embedder."""
        embedder = MagicMock()
        embedder.model_id = "test-model"
        embedder.embed = MagicMock(return_value=[0.1] * 256)
        return embedder

    def test_semantic_manual_mode_stages_decisions(self, mock_db):
        """Semantic pipeline in manual mode should stage decisions, not persist."""
        store = PendingStore(mock_db)

        # Stage a decision
        payload = PendingDecisionPayload(
            action="ADD",
            content="User prefers Python",
            confidence=0.9,
            embedding=[0.1] * 10,
        )
        pending_id = store.stage(
            org_id="org-1",
            user_id="user-1",
            source_id="snapshot-123",
            extraction_type="semantic",
            payload=payload,
        )

        # Verify staged
        assert pending_id is not None
        pending = store.get(pending_id)
        assert pending is not None
        assert pending.extraction_type == "semantic"
        assert pending.status == "pending"
        assert pending.payload.content == "User prefers Python"

    def test_approve_creates_memory(self, mock_db, mock_embedder):
        """Approving a staged decision should create a memory."""
        store = PendingStore(mock_db)
        orchestrator = ApprovalOrchestrator(mock_db, mock_embedder)

        # Stage a decision
        payload = PendingDecisionPayload(
            action="ADD",
            content="User prefers Python",
            confidence=0.9,
            embedding=[0.1] * 10,
        )
        pending_id = store.stage(
            org_id="org-1",
            user_id="user-1",
            source_id="snapshot-123",
            extraction_type="semantic",
            payload=payload,
        )

        # Mock the persistence function
        with patch(
            "mongomem_core.extraction.persistence.perform_add",
            return_value="mem-123",
        ):
            result = orchestrator.approve(pending_id, reviewed_by="admin")

        assert result.success is True
        assert result.memory_id == "mem-123"

        # Verify marked as approved
        pending = store.get(pending_id)
        assert pending.status == "approved"
        assert pending.memory_id == "mem-123"

    def test_reject_does_not_create_memory(self, mock_db, mock_embedder):
        """Rejecting a staged decision should not create a memory."""
        store = PendingStore(mock_db)
        orchestrator = ApprovalOrchestrator(mock_db, mock_embedder)

        # Stage a decision
        payload = PendingDecisionPayload(
            action="ADD",
            content="User prefers Python",
            confidence=0.9,
            embedding=[0.1] * 10,
        )
        pending_id = store.stage(
            org_id="org-1",
            user_id="user-1",
            source_id="snapshot-123",
            extraction_type="semantic",
            payload=payload,
        )

        # Reject
        result = orchestrator.reject(pending_id, reason="Inaccurate", reviewed_by="admin")

        assert result is True

        # Verify marked as rejected
        pending = store.get(pending_id)
        assert pending.status == "rejected"
        assert pending.rejection_reason == "Inaccurate"
        assert pending.memory_id is None

    def test_port_private_to_shared_at_approval(self, mock_db, mock_embedder):
        """Approving with visibility override should port to group."""
        store = PendingStore(mock_db)
        orchestrator = ApprovalOrchestrator(mock_db, mock_embedder)

        # Stage as private
        payload = PendingDecisionPayload(
            action="ADD",
            content="Team knowledge",
            confidence=0.95,
            embedding=[0.1] * 10,
        )
        pending_id = store.stage(
            org_id="org-1",
            user_id="user-1",
            source_id="snapshot-123",
            extraction_type="semantic",
            payload=payload,
            visibility=ChunkVisibility.PRIVATE,
            project_id=None,
        )

        # Approve with SHARED visibility override
        with patch(
            "mongomem_core.extraction.persistence.perform_add",
            return_value="mem-123",
        ) as mock_persist:
            result = orchestrator.approve(
                pending_id,
                reviewed_by="admin",
                target_visibility=ChunkVisibility.SHARED,
                target_project_id="team-alpha",
            )

        assert result.success is True
        assert mock_persist.call_args is not None

    def test_preferences_manual_mode_stages(self, mock_db):
        """Preferences in manual mode should stage for review."""
        store = PendingStore(mock_db)

        payload = PendingPreferencesPayload(
            session_id="session-123",
            tone="formal",
            expertise_level="expert",
            confidence=0.85,
            evidence=[0, 1, 2],
        )
        pending_id = store.stage(
            org_id="org-1",
            user_id="user-1",
            source_id="snapshot-123",
            extraction_type="preferences",
            payload=payload,
        )

        pending = store.get(pending_id)
        assert pending is not None
        assert pending.extraction_type == "preferences"
        assert pending.payload.kind == "preferences"
        assert pending.payload.tone == "formal"

    def test_preferences_approval_persists(self, mock_db):
        """Approving preferences should persist them."""
        store = PendingStore(mock_db)
        orchestrator = ApprovalOrchestrator(mock_db, embedder=None)

        payload = PendingPreferencesPayload(
            session_id="session-123",
            tone="formal",
            confidence=0.9,
        )
        pending_id = store.stage(
            org_id="org-1",
            user_id="user-1",
            source_id="snapshot-123",
            extraction_type="preferences",
            payload=payload,
        )

        with patch(
            "mongomem_core.extraction.preferences.persistence.upsert_extracted_preferences",
            return_value=MagicMock(success=True, doc_id="pref-123"),
        ):
            result = orchestrator.approve(pending_id, reviewed_by="admin")

        assert result.success is True
        assert result.memory_id == "pref-123"


class TestUnpublishWorkflow:
    """Tests for unpublish and restage functionality."""

    @pytest.fixture
    def mock_db_with_memory(self):
        """Create a mock DB with an existing memory."""
        db = create_mock_db()
        memory_id = ObjectId()
        memory_id_str = str(memory_id)

        # Access the collection to initialize it
        _ = db["memory_semantic"]

        # Pre-populate with an existing memory
        db._documents["memory_semantic"][memory_id_str] = {
            "_id": memory_id,
            "org_id": "org-1",
            "user_id": "user-1",
            "text": "User likes Python",
            "deleted": False,
        }

        return db, memory_id_str

    def test_unpublish_soft_deletes_memory(self, mock_db_with_memory):
        """Unpublish should soft-delete the memory."""
        db, memory_id = mock_db_with_memory
        orchestrator = ApprovalOrchestrator(db, embedder=None)

        result = orchestrator.unpublish(
            memory_id=memory_id,
            memory_type="semantic",
            org_id="org-1",
            user_id="user-1",
            unpublished_by="admin",
            reason="Incorrect",
            restage=False,
        )

        # Should return None (no restage)
        assert result is None

        # Verify soft-delete was applied
        memory = db._documents["memory_semantic"].get(memory_id)
        assert memory["deleted"] is True
        assert "deleted_at" in memory

    def test_unpublish_with_restage_creates_pending(self, mock_db_with_memory):
        """Unpublish with restage should create a pending memory_ref."""
        db, memory_id = mock_db_with_memory
        orchestrator = ApprovalOrchestrator(db, embedder=None)

        result = orchestrator.unpublish(
            memory_id=memory_id,
            memory_type="semantic",
            org_id="org-1",
            user_id="user-1",
            unpublished_by="admin",
            reason="Needs review",
            restage=True,
        )

        # Should return the pending_id
        assert result is not None

        # Verify pending was created
        assert len(db._documents["extraction_pending"]) == 1


class TestTTLBehavior:
    """Tests for TTL expiration behavior."""

    def test_pending_items_have_expires_at(self):
        """Pending items should have expires_at set."""
        mock_db = create_mock_db()

        store = PendingStore(mock_db, pending_ttl_hours=168)

        payload = PendingDecisionPayload(action="ADD", content="Test")
        store.stage(
            org_id="org-1",
            user_id="user-1",
            source_id="src-1",
            extraction_type="semantic",
            payload=payload,
        )

        # Get the staged document
        docs = list(mock_db._documents["extraction_pending"].values())
        assert len(docs) == 1
        doc = docs[0]
        assert "expires_at" in doc
        assert doc["expires_at"] is not None

        # Verify it's ~7 days from now
        expected = doc["created_at"] + timedelta(hours=168)
        assert abs((doc["expires_at"] - expected).total_seconds()) < 1

    def test_approved_items_get_audit_retention(self):
        """Approved items should get extended expires_at for audit."""
        mock_db = create_mock_db()

        # Stage first
        store = PendingStore(mock_db, pending_ttl_hours=168, audit_retention_days=30)
        payload = PendingDecisionPayload(action="ADD", content="Test")
        pending_id = store.stage(
            org_id="org-1",
            user_id="user-1",
            source_id="src-1",
            extraction_type="semantic",
            payload=payload,
        )

        # Mark approved
        store.mark_approved(
            pending_id=pending_id,
            memory_id="mem-123",
        )

        # Check the expires_at was extended
        doc = mock_db._documents["extraction_pending"].get(pending_id)
        assert doc is not None
        assert doc["status"] == "approved"
