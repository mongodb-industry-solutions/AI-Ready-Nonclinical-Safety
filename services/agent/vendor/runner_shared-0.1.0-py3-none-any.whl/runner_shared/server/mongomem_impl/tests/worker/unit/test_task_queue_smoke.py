from runner_shared.server.mongomem_impl.src.mongomem_worker.queue import EnqueuedTask, enqueue_task


def test_enqueue_task_smoke(monkeypatch):
    class FakeResult:
        def __init__(self):
            self.inserted_id = "fake-id"

    class FakeCollection:
        def insert_one(self, doc):  # type: ignore[no-untyped-def]
            return FakeResult()

    def fake_tasks_collection(settings=None):  # type: ignore[no-untyped-def]
        return FakeCollection()

    monkeypatch.setattr(
        "runner_shared.server.mongomem_impl.src.mongomem_worker.queue.operations._tasks_collection",
        fake_tasks_collection,
    )

    task = enqueue_task("test", {"x": 1})
    assert isinstance(task, EnqueuedTask)
    assert task.status == "queued"
