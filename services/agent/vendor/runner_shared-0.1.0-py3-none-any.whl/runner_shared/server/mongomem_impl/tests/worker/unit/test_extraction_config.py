"""
Unit tests for ExtractionConfigStore with hierarchical defaults.
"""

import pytest
from pymongo.database import Database

from runner_shared.server.mongomem_impl.src.mongomem_worker.storage.extraction_config import (
    ExtractionConfigStore,
)


class TestExtractionConfigStore:
    """Tests for ExtractionConfigStore."""

    @pytest.fixture
    def store(self, test_db: Database) -> ExtractionConfigStore:
        """Create a fresh store for each test."""
        return ExtractionConfigStore(test_db)

    # -------------------------------------------------------------------------
    # Basic CRUD
    # -------------------------------------------------------------------------

    def test_create_system_default(self, store: ExtractionConfigStore):
        """Test creating a system-level default prompt."""
        config_id = store.create(
            org_id=None,
            extraction_type="taxonomic",
            prompt="System default: {content}",
            notes="Initial system default",
        )

        assert config_id is not None

        # Should not be active until explicitly activated
        prompt = store.get_active(None, "taxonomic")
        assert prompt is None

    def test_create_and_activate(self, store: ExtractionConfigStore):
        """Test creating and immediately activating a config."""
        store.create(
            org_id=None,
            extraction_type="taxonomic",
            prompt="System default: {content}",
            activate=True,
        )

        prompt = store.get_active(None, "taxonomic")
        assert prompt == "System default: {content}"

    def test_create_increments_version(self, store: ExtractionConfigStore):
        """Test that versions auto-increment."""
        store.create(None, "taxonomic", "v1", activate=True)
        store.create(None, "taxonomic", "v2")
        store.create(None, "taxonomic", "v3")

        versions = store.list_versions(None, "taxonomic")
        assert len(versions) == 3
        assert versions[0]["version"] == 3  # Newest first
        assert versions[1]["version"] == 2
        assert versions[2]["version"] == 1

    def test_activate_by_version(self, store: ExtractionConfigStore):
        """Test activating a specific version."""
        store.create(None, "taxonomic", "v1", activate=True)
        store.create(None, "taxonomic", "v2")

        # v1 should be active
        assert store.get_active(None, "taxonomic") == "v1"

        # Activate v2
        store.activate(None, "taxonomic", version=2)
        assert store.get_active(None, "taxonomic") == "v2"

    def test_only_one_active_per_scope(self, store: ExtractionConfigStore):
        """Test that activating a version deactivates the previous."""
        store.create(None, "taxonomic", "v1", activate=True)
        store.create(None, "taxonomic", "v2", activate=True)

        versions = store.list_versions(None, "taxonomic")
        active_versions = [v for v in versions if v["is_active"]]
        assert len(active_versions) == 1
        assert active_versions[0]["version"] == 2

    def test_rollback(self, store: ExtractionConfigStore):
        """Test rolling back to previous version."""
        store.create(None, "taxonomic", "v1", activate=True)
        store.create(None, "taxonomic", "v2", activate=True)

        assert store.get_active(None, "taxonomic") == "v2"

        rolled_back = store.rollback(None, "taxonomic")
        assert rolled_back == 1
        assert store.get_active(None, "taxonomic") == "v1"

    def test_rollback_no_previous(self, store: ExtractionConfigStore):
        """Test rollback when there's no previous version."""
        store.create(None, "taxonomic", "v1", activate=True)

        rolled_back = store.rollback(None, "taxonomic")
        assert rolled_back is None
        assert store.get_active(None, "taxonomic") == "v1"  # Still active

    def test_delete_version(self, store: ExtractionConfigStore):
        """Test deleting a non-active version."""
        store.create(None, "taxonomic", "v1", activate=True)
        store.create(None, "taxonomic", "v2")

        # Can delete v2 (not active)
        deleted = store.delete_version(None, "taxonomic", version=2)
        assert deleted is True

        versions = store.list_versions(None, "taxonomic")
        assert len(versions) == 1

    def test_cannot_delete_active_version(self, store: ExtractionConfigStore):
        """Test that active version cannot be deleted."""
        store.create(None, "taxonomic", "v1", activate=True)

        deleted = store.delete_version(None, "taxonomic", version=1)
        assert deleted is False

        # Still exists
        assert store.get_active(None, "taxonomic") == "v1"

    # -------------------------------------------------------------------------
    # Hierarchical Resolution
    # -------------------------------------------------------------------------

    def test_hierarchy_user_overrides_group(self, store: ExtractionConfigStore):
        """Test that user-level config overrides group-level."""
        # Set up hierarchy
        store.create(None, "taxonomic", "system", activate=True)
        store.create("acme", "taxonomic", "org", activate=True)
        store.create("acme", "taxonomic", "group", project_id="eng", activate=True)
        store.create("acme", "taxonomic", "user", project_id="eng", user_id="alice", activate=True)

        # User should get user-level prompt
        prompt = store.get_active("acme", "taxonomic", project_id="eng", user_id="alice")
        assert prompt == "user"

    def test_hierarchy_group_overrides_org(self, store: ExtractionConfigStore):
        """Test that group-level config overrides org-level."""
        store.create(None, "taxonomic", "system", activate=True)
        store.create("acme", "taxonomic", "org", activate=True)
        store.create("acme", "taxonomic", "group", project_id="eng", activate=True)

        # User in group should get group-level prompt (no user override)
        prompt = store.get_active("acme", "taxonomic", project_id="eng", user_id="bob")
        assert prompt == "group"

    def test_hierarchy_org_overrides_system(self, store: ExtractionConfigStore):
        """Test that org-level config overrides system-level."""
        store.create(None, "taxonomic", "system", activate=True)
        store.create("acme", "taxonomic", "org", activate=True)

        # User in org (no group) should get org-level prompt
        prompt = store.get_active("acme", "taxonomic", user_id="carol")
        assert prompt == "org"

    def test_hierarchy_fallback_to_system(self, store: ExtractionConfigStore):
        """Test fallback to system default when no overrides exist."""
        store.create(None, "taxonomic", "system", activate=True)

        # New org with no config should get system default
        prompt = store.get_active("newcorp", "taxonomic")
        assert prompt == "system"

    def test_hierarchy_no_config_returns_none(self, store: ExtractionConfigStore):
        """Test that None is returned when no config exists at any level."""
        prompt = store.get_active("acme", "taxonomic")
        assert prompt is None

    def test_hierarchy_group_fallback_skips_missing_levels(self, store: ExtractionConfigStore):
        """Test that resolution skips levels that don't exist."""
        # Only system and group exist (no org level)
        store.create(None, "taxonomic", "system", activate=True)
        store.create("acme", "taxonomic", "group", project_id="eng", activate=True)

        # Should get group, not org (which doesn't exist)
        prompt = store.get_active("acme", "taxonomic", project_id="eng", user_id="dave")
        assert prompt == "group"

    def test_hierarchy_different_groups_isolated(self, store: ExtractionConfigStore):
        """Test that different groups have isolated configs."""
        store.create("acme", "taxonomic", "engineering", project_id="eng", activate=True)
        store.create("acme", "taxonomic", "sales", project_id="sales", activate=True)

        prompt_eng = store.get_active("acme", "taxonomic", project_id="eng")
        prompt_sales = store.get_active("acme", "taxonomic", project_id="sales")

        assert prompt_eng == "engineering"
        assert prompt_sales == "sales"

    def test_hierarchy_different_orgs_isolated(self, store: ExtractionConfigStore):
        """Test that different orgs have isolated configs."""
        store.create("acme", "taxonomic", "acme prompt", activate=True)
        store.create("globex", "taxonomic", "globex prompt", activate=True)

        assert store.get_active("acme", "taxonomic") == "acme prompt"
        assert store.get_active("globex", "taxonomic") == "globex prompt"

    def test_hierarchy_different_extraction_types_isolated(self, store: ExtractionConfigStore):
        """Test that different extraction types have isolated configs."""
        store.create("acme", "taxonomic", "taxonomic prompt", activate=True)
        store.create("acme", "episodic", "episodic prompt", activate=True)

        assert store.get_active("acme", "taxonomic") == "taxonomic prompt"
        assert store.get_active("acme", "episodic") == "episodic prompt"

    # -------------------------------------------------------------------------
    # Scope Operations
    # -------------------------------------------------------------------------

    def test_delete_scope_removes_override(self, store: ExtractionConfigStore):
        """Test that deleting a scope removes the override."""
        store.create(None, "taxonomic", "system", activate=True)
        store.create("acme", "taxonomic", "org", activate=True)
        store.create("acme", "taxonomic", "user", project_id="eng", user_id="alice", activate=True)

        # Delete user scope
        deleted = store.delete_scope("acme", "taxonomic", project_id="eng", user_id="alice")
        assert deleted == 1

        # Now falls back to org (no group exists)
        prompt = store.get_active("acme", "taxonomic", project_id="eng", user_id="alice")
        assert prompt == "org"

    def test_get_resolution_chain(self, store: ExtractionConfigStore):
        """Test getting the full resolution chain."""
        store.create(None, "taxonomic", "system", activate=True)
        store.create("acme", "taxonomic", "org", activate=True)
        store.create("acme", "taxonomic", "group", project_id="eng", activate=True)
        # No user level

        chain = store.get_resolution_chain("acme", "taxonomic", project_id="eng", user_id="alice")

        assert len(chain) == 4

        # User level exists in chain but no config
        assert chain[0]["level"] == "user"
        assert chain[0]["exists"] is False
        assert chain[0]["is_resolved"] is False

        # Group level is resolved (first found)
        assert chain[1]["level"] == "group"
        assert chain[1]["exists"] is True
        assert chain[1]["is_resolved"] is True

        # Org level exists but not resolved (group was found first)
        assert chain[2]["level"] == "org"
        assert chain[2]["exists"] is True
        assert chain[2]["is_resolved"] is False

        # System level exists
        assert chain[3]["level"] == "system"
        assert chain[3]["exists"] is True
        assert chain[3]["is_resolved"] is False

    # -------------------------------------------------------------------------
    # Version Details
    # -------------------------------------------------------------------------

    def test_get_version_returns_full_doc(self, store: ExtractionConfigStore):
        """Test that get_version returns the full document."""
        store.create(
            "acme",
            "taxonomic",
            "test prompt",
            notes="Test notes",
            created_by="admin",
            activate=True,
        )

        version = store.get_version("acme", "taxonomic", version=1)

        assert version is not None
        assert version["prompt"] == "test prompt"
        assert version["notes"] == "Test notes"
        assert version["created_by"] == "admin"
        assert version["is_active"] is True
        assert "created_at" in version

    def test_list_versions_returns_metadata(self, store: ExtractionConfigStore):
        """Test that list_versions returns version metadata."""
        store.create("acme", "taxonomic", "v1", notes="First", activate=True)
        store.create("acme", "taxonomic", "v2", notes="Second", activate=True)

        versions = store.list_versions("acme", "taxonomic")

        assert len(versions) == 2
        assert versions[0]["version"] == 2
        assert versions[0]["notes"] == "Second"
        assert versions[0]["is_active"] is True
        assert versions[1]["version"] == 1
        assert versions[1]["notes"] == "First"
        assert versions[1]["is_active"] is False

    # -------------------------------------------------------------------------
    # Edge Cases
    # -------------------------------------------------------------------------

    def test_activate_nonexistent_version_returns_false(self, store: ExtractionConfigStore):
        """Test that activating a non-existent version returns False."""
        result = store.activate("acme", "taxonomic", version=999)
        assert result is False

    def test_rollback_with_no_active_returns_none(self, store: ExtractionConfigStore):
        """Test rollback when nothing is active."""
        store.create("acme", "taxonomic", "v1")  # Not activated

        result = store.rollback("acme", "taxonomic")
        assert result is None

    def test_empty_prompt_is_valid(self, store: ExtractionConfigStore):
        """Test that an empty prompt string is valid."""
        store.create("acme", "taxonomic", "", activate=True)
        prompt = store.get_active("acme", "taxonomic")
        assert prompt == ""

    def test_special_characters_in_prompt(self, store: ExtractionConfigStore):
        """Test prompts with special characters."""
        special_prompt = 'Extract {{json}} from: {content}\n\t"quotes" & symbols'
        store.create("acme", "taxonomic", special_prompt, activate=True)
        prompt = store.get_active("acme", "taxonomic")
        assert prompt == special_prompt

    def test_unicode_in_prompt(self, store: ExtractionConfigStore):
        """Test prompts with unicode characters."""
        unicode_prompt = "提取信息: {content} 🎉"
        store.create("acme", "taxonomic", unicode_prompt, activate=True)
        prompt = store.get_active("acme", "taxonomic")
        assert prompt == unicode_prompt

    def test_concurrent_scopes_independent(self, store: ExtractionConfigStore):
        """Test that operations on one scope don't affect others."""
        store.create("acme", "taxonomic", "v1", project_id="eng", activate=True)
        store.create("acme", "taxonomic", "v2", project_id="eng", activate=True)

        # Activating v2 in eng group shouldn't affect sales
        store.create("acme", "taxonomic", "sales-v1", project_id="sales", activate=True)

        eng_versions = store.list_versions("acme", "taxonomic", project_id="eng")
        sales_versions = store.list_versions("acme", "taxonomic", project_id="sales")

        assert len(eng_versions) == 2
        assert len(sales_versions) == 1

        # Check active status
        eng_active = [v for v in eng_versions if v["is_active"]]
        sales_active = [v for v in sales_versions if v["is_active"]]
        assert len(eng_active) == 1
        assert len(sales_active) == 1


class TestExtractionConfigCache:
    """Tests for caching behavior."""

    @pytest.fixture
    def store(self, test_db: Database) -> ExtractionConfigStore:
        # Short TTL for testing
        return ExtractionConfigStore(test_db, cache_ttl=1.0)

    def test_cache_hit_avoids_db_query(self, store: ExtractionConfigStore):
        """Test that cache hits avoid database queries."""
        store.create("acme", "taxonomic", "cached prompt", activate=True)

        # First call - cache miss, hits DB
        prompt1 = store.get_active("acme", "taxonomic")
        assert prompt1 == "cached prompt"

        # Second call - should be cache hit
        prompt2 = store.get_active("acme", "taxonomic")
        assert prompt2 == "cached prompt"

    def test_cache_invalidated_on_activate(self, store: ExtractionConfigStore):
        """Test that cache is invalidated when config is activated."""
        store.create("acme", "taxonomic", "v1", activate=True)

        # Prime cache
        assert store.get_active("acme", "taxonomic") == "v1"

        # Create and activate v2
        store.create("acme", "taxonomic", "v2", activate=True)

        # Should get v2 (cache was invalidated)
        assert store.get_active("acme", "taxonomic") == "v2"

    def test_skip_cache_parameter(self, store: ExtractionConfigStore):
        """Test that skip_cache bypasses cache."""
        store.create("acme", "taxonomic", "prompt", activate=True)

        # Prime cache
        store.get_active("acme", "taxonomic")

        # skip_cache should still return correct value
        prompt = store.get_active("acme", "taxonomic", skip_cache=True)
        assert prompt == "prompt"

    def test_cache_stores_none_results(self, store: ExtractionConfigStore):
        """Test that None results are also cached."""
        # No config exists
        result1 = store.get_active("acme", "taxonomic")
        assert result1 is None

        # Second call should also return None (from cache)
        result2 = store.get_active("acme", "taxonomic")
        assert result2 is None

    def test_invalidate_cache_by_org(self, store: ExtractionConfigStore):
        """Test selective cache invalidation by org."""
        store.create("acme", "taxonomic", "acme", activate=True)
        store.create("globex", "taxonomic", "globex", activate=True)

        # Prime both caches
        store.get_active("acme", "taxonomic")
        store.get_active("globex", "taxonomic")

        # Invalidate only acme
        count = store.invalidate_cache(org_id="acme")
        assert count >= 1

    def test_single_query_efficiency(self, store: ExtractionConfigStore, test_db: Database):
        """Test that get_active uses single query for hierarchy resolution."""
        # Set up full hierarchy
        store.create(None, "taxonomic", "system", activate=True)
        store.create("acme", "taxonomic", "org", activate=True)
        store.create("acme", "taxonomic", "group", project_id="eng", activate=True)
        store.create("acme", "taxonomic", "user", project_id="eng", user_id="alice", activate=True)

        # Clear cache to force DB query
        store.invalidate_cache()

        # This should use single $or query, not 4 separate queries
        prompt = store.get_active("acme", "taxonomic", project_id="eng", user_id="alice")
        assert prompt == "user"


class TestExtractionConfigStoreIntegration:
    """Integration tests that verify full workflows."""

    @pytest.fixture
    def store(self, test_db: Database) -> ExtractionConfigStore:
        return ExtractionConfigStore(test_db)

    def test_full_hierarchy_workflow(self, store: ExtractionConfigStore):
        """Test a complete workflow with all hierarchy levels."""
        # 1. Admin sets system default
        store.create(None, "taxonomic", "DEFAULT: {content}", activate=True)

        # 2. Acme customizes org-level
        store.create("acme", "taxonomic", "ACME: {content}", activate=True)

        # 3. Engineering team customizes
        store.create("acme", "taxonomic", "ENG: {content}", project_id="engineering", activate=True)

        # 4. Alice customizes her experience
        store.create(
            "acme",
            "taxonomic",
            "ALICE: {content}",
            project_id="engineering",
            user_id="alice",
            activate=True,
        )

        # Verify resolution at each level
        assert store.get_active("newcorp", "taxonomic") == "DEFAULT: {content}"
        assert store.get_active("acme", "taxonomic") == "ACME: {content}"
        assert store.get_active("acme", "taxonomic", project_id="engineering") == "ENG: {content}"
        assert (
            store.get_active("acme", "taxonomic", project_id="engineering", user_id="alice")
            == "ALICE: {content}"
        )
        assert (
            store.get_active("acme", "taxonomic", project_id="engineering", user_id="bob")
            == "ENG: {content}"
        )
        assert store.get_active("acme", "taxonomic", project_id="sales") == "ACME: {content}"

    def test_version_iteration_workflow(self, store: ExtractionConfigStore):
        """Test iterating through prompt versions."""
        # Initial version
        store.create(
            "acme", "taxonomic", "v1: Basic extraction", notes="Initial version", activate=True
        )

        # Improve prompt
        store.create(
            "acme",
            "taxonomic",
            "v2: Extract with context: {content}",
            notes="Added context",
            activate=True,
        )

        # v2 has a bug, rollback
        store.rollback("acme", "taxonomic")
        assert "v1" in store.get_active("acme", "taxonomic")

        # Fix and deploy v3
        store.create(
            "acme",
            "taxonomic",
            "v3: Fixed extraction: {content}",
            notes="Fixed v2 bugs",
            activate=True,
        )
        assert "v3" in store.get_active("acme", "taxonomic")

        # Verify history
        versions = store.list_versions("acme", "taxonomic")
        assert len(versions) == 3
        assert versions[0]["version"] == 3
        assert versions[0]["is_active"] is True
