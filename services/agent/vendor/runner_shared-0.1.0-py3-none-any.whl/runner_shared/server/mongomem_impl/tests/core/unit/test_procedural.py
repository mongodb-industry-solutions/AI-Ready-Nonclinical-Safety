"""Unit tests for procedural memory models, engine mixin, and retrieval integration."""

import pytest
from mongomem_core.common.utils import utcnow
from mongomem_core.models.engine import (
    CreateProceduralResult,
)
from mongomem_core.models.execution import ExecutionResult
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.procedural import (
    ProceduralIn,
    ProceduralOut,
    ProceduralResource,
    ProceduralStep,
    ProceduralUpdate,
)
from mongomem_core.models.retrieval import (
    MemoryChunk,
    MemorySource,
)
from pydantic import ValidationError


class TestProceduralStep:
    """Tests for ProceduralStep model."""

    def test_instruction_step(self):
        step = ProceduralStep(
            step_type="instruction",
            content="Run the deploy script",
            description="Deploy the application",
        )
        assert step.step_type == "instruction"
        assert step.language is None
        assert step.timeout_ms == 30000

    def test_code_step_with_language(self):
        step = ProceduralStep(
            step_type="code",
            content="print('hello')",
            description="Print hello",
            language="python",
            dependencies=["requests"],
        )
        assert step.language == "python"
        assert step.dependencies == ["requests"]

    def test_validation_step(self):
        step = ProceduralStep(
            step_type="validation",
            content="assert result == 42",
            description="Check the result",
            expected_output="42",
        )
        assert step.expected_output == "42"

    def test_prompt_step(self):
        step = ProceduralStep(
            step_type="prompt",
            content="Summarize the document: {doc}",
            description="Summarize input document",
        )
        assert step.step_type == "prompt"

    def test_human_input_step(self):
        step = ProceduralStep(
            step_type="human_input",
            content="Please review and approve the changes",
            description="Human approval gate",
        )
        assert step.step_type == "human_input"

    def test_invalid_step_type(self):
        with pytest.raises(ValidationError):
            ProceduralStep(
                step_type="unknown",
                content="test",
                description="test",
            )

    def test_timeout_bounds(self):
        with pytest.raises(ValidationError):
            ProceduralStep(
                step_type="code",
                content="test",
                description="test",
                timeout_ms=500,  # Below 1000 minimum
            )

        with pytest.raises(ValidationError):
            ProceduralStep(
                step_type="code",
                content="test",
                description="test",
                timeout_ms=700000,  # Above 600000 maximum
            )

    def test_custom_timeout(self):
        step = ProceduralStep(
            step_type="code",
            content="test",
            description="test",
            timeout_ms=120000,
        )
        assert step.timeout_ms == 120000


class TestProceduralResource:
    """Tests for ProceduralResource model."""

    def test_script_resource(self):
        resource = ProceduralResource(
            path="scripts/deploy.py",
            resource_type="script",
            language="python",
            content="#!/usr/bin/env python\nprint('deploying')",
        )
        assert resource.resource_type == "script"
        assert resource.language == "python"

    def test_reference_resource(self):
        resource = ProceduralResource(
            path="references/api-docs.md",
            resource_type="reference",
            description="API documentation",
        )
        assert resource.resource_type == "reference"
        assert resource.content is None

    def test_asset_resource(self):
        resource = ProceduralResource(
            path="assets/config.json",
            resource_type="asset",
        )
        assert resource.resource_type == "asset"

    def test_invalid_resource_type(self):
        with pytest.raises(ValidationError):
            ProceduralResource(
                path="test.txt",
                resource_type="invalid",
            )


class TestProceduralIn:
    """Tests for ProceduralIn input model."""

    def test_basic_creation(self):
        proc = ProceduralIn(
            procedure="deploy-app",
            description="Deploy the application to production",
            content="# Deploy\n\nRun the deploy script...",
        )
        assert proc.procedure == "deploy-app"
        assert proc.visibility == ChunkVisibility.PRIVATE  # Default from BaseMemoryIn

    def test_kebab_case_validation(self):
        ProceduralIn(
            procedure="my-cool-skill",
            description="A cool skill",
            content="Do the thing",
        )
        ProceduralIn(
            procedure="simple",
            description="Simple",
            content="Content",
        )
        ProceduralIn(
            procedure="a1-b2-c3",
            description="Alphanumeric",
            content="Content",
        )

    def test_invalid_procedure_name_uppercase(self):
        with pytest.raises(ValidationError):
            ProceduralIn(
                procedure="MySkill",
                description="Invalid",
                content="Content",
            )

    def test_invalid_procedure_name_spaces(self):
        with pytest.raises(ValidationError):
            ProceduralIn(
                procedure="my skill",
                description="Invalid",
                content="Content",
            )

    def test_invalid_procedure_name_underscores(self):
        with pytest.raises(ValidationError):
            ProceduralIn(
                procedure="my_skill",
                description="Invalid",
                content="Content",
            )

    def test_empty_procedure_name(self):
        with pytest.raises(ValidationError):
            ProceduralIn(
                procedure="",
                description="Invalid",
                content="Content",
            )

    def test_procedure_name_max_length(self):
        with pytest.raises(ValidationError):
            ProceduralIn(
                procedure="a" * 65,
                description="Too long name",
                content="Content",
            )

    def test_description_max_length(self):
        with pytest.raises(ValidationError):
            ProceduralIn(
                procedure="test",
                description="x" * 1025,
                content="Content",
            )

    def test_full_creation(self):
        proc = ProceduralIn(
            procedure="deploy-app",
            description="Deploy the application",
            content="# Deploy\n\nFull instructions...",
            content_token_count=150,
            steps=[
                ProceduralStep(
                    step_type="code",
                    content="./deploy.sh",
                    description="Run deploy script",
                    language="bash",
                )
            ],
            resources=[
                ProceduralResource(
                    path="scripts/deploy.sh",
                    resource_type="script",
                    language="bash",
                )
            ],
            allowed_tools=["Bash", "Read"],
            compatibility="linux",
            license="MIT",
            trigger_conditions=["user asks to deploy"],
            tags=["deployment", "production"],
            source_format="skill.md",
            source_path="/skills/deploy/SKILL.md",
            agent_id="agent-123",
            extraction_source="user_direct",
        )
        assert len(proc.steps) == 1
        assert len(proc.resources) == 1
        assert proc.allowed_tools == ["Bash", "Read"]
        assert proc.tags == ["deployment", "production"]

    def test_content_token_count_non_negative(self):
        with pytest.raises(ValidationError):
            ProceduralIn(
                procedure="test",
                description="Test",
                content="Content",
                content_token_count=-1,
            )


class TestProceduralUpdate:
    """Tests for ProceduralUpdate partial update model."""

    def test_partial_description_only(self):
        update = ProceduralUpdate(description="Updated description")
        assert update.description == "Updated description"
        assert update.content is None
        assert update.tags is None
        assert update.steps is None

    def test_partial_tags(self):
        update = ProceduralUpdate(tags=["new-tag", "another"])
        assert update.tags == ["new-tag", "another"]

    def test_partial_steps(self):
        steps = [
            ProceduralStep(
                step_type="instruction",
                content="Step 1",
                description="First step",
            )
        ]
        update = ProceduralUpdate(steps=steps)
        assert len(update.steps) == 1

    def test_empty_update(self):
        update = ProceduralUpdate()
        assert update.description is None
        assert update.content is None

    def test_description_max_length(self):
        with pytest.raises(ValidationError):
            ProceduralUpdate(description="x" * 1025)


class TestProceduralOut:
    """Tests for ProceduralOut output model."""

    def _make_out(self, **overrides):
        defaults = {
            "_id": "abc123",
            "procedure": "test-proc",
            "description": "Test procedure",
            "content": "Do the thing",
            "org_id": "org-1",
            "user_id": "user-1",
            "timestamp": utcnow(),
            "updated_at": utcnow(),
            "version": 1,
            "is_latest": True,
        }
        defaults.update(overrides)
        return ProceduralOut.model_validate(defaults)

    def test_basic_out(self):
        out = self._make_out()
        assert out.id == "abc123"
        assert out.procedure == "test-proc"
        assert out.score is None

    def test_out_with_score(self):
        out = self._make_out(score=0.95)
        assert out.score == 0.95

    def test_of_from_dict(self):
        from bson import ObjectId

        oid = ObjectId()
        doc = {
            "_id": oid,
            "procedure": "from-dict",
            "description": "From dict",
            "content": "Content",
            "org_id": "org-1",
            "user_id": "user-1",
            "timestamp": utcnow(),
            "updated_at": utcnow(),
            "version": 1,
            "is_latest": True,
        }
        out = ProceduralOut.of(doc)
        assert out is not None
        assert out.id == str(oid)
        assert out.procedure == "from-dict"

    def test_of_none(self):
        assert ProceduralOut.of(None) is None


class TestMemoryChunkFromProcedural:
    """Tests for MemoryChunk.from_procedural conversion."""

    def _make_procedural_out(self, **overrides):
        defaults = {
            "_id": "proc-123",
            "procedure": "test-skill",
            "description": "A test skill",
            "content": "Full skill content here",
            "org_id": "org-1",
            "user_id": "user-1",
            "timestamp": utcnow(),
            "updated_at": utcnow(),
            "version": 1,
            "is_latest": True,
        }
        defaults.update(overrides)
        return ProceduralOut.model_validate(defaults)

    def test_basic_conversion(self):
        proc = self._make_procedural_out()
        chunk = MemoryChunk.from_procedural(proc)
        assert chunk.id == "proc-123"
        assert chunk.content == "Full skill content here"
        assert chunk.source == MemorySource.PROCEDURAL
        assert chunk.metadata["procedure"] == "test-skill"
        assert chunk.metadata["description"] == "A test skill"
        assert chunk.metadata["version"] == 1
        assert chunk.metadata["is_latest"] is True

    def test_conversion_with_similarity_score(self):
        proc = self._make_procedural_out()
        chunk = MemoryChunk.from_procedural(proc, similarity_score=0.88)
        assert chunk.similarity_score == 0.88

    def test_conversion_with_tags(self):
        proc = self._make_procedural_out(tags=["deploy", "ci"])
        chunk = MemoryChunk.from_procedural(proc)
        assert chunk.metadata["tags"] == ["deploy", "ci"]

    def test_conversion_with_optional_fields(self):
        proc = self._make_procedural_out(
            allowed_tools=["Bash"],
            trigger_conditions=["when deploying"],
            agent_id="agent-1",
            extraction_source="user_direct",
            memory_lineage_id="lineage-1",
        )
        chunk = MemoryChunk.from_procedural(proc)
        assert chunk.metadata["allowed_tools"] == ["Bash"]
        assert chunk.metadata["trigger_conditions"] == ["when deploying"]
        assert chunk.metadata["agent_id"] == "agent-1"
        assert chunk.metadata["extraction_source"] == "user_direct"
        assert chunk.metadata["memory_lineage_id"] == "lineage-1"


class TestExecutionResult:
    """Tests for ExecutionResult dataclass."""

    def test_basic_creation(self):
        result = ExecutionResult(
            success=True,
            stdout="Hello, world!",
            stderr="",
            exit_code=0,
            duration_ms=150,
            language="python",
            executor_id="sandbox-1",
        )
        assert result.success is True
        assert result.exit_code == 0
        assert result.language == "python"

    def test_failed_execution(self):
        result = ExecutionResult(
            success=False,
            stdout="",
            stderr="NameError: name 'x' is not defined",
            exit_code=1,
            duration_ms=50,
            language="python",
            executor_id="sandbox-1",
        )
        assert result.success is False
        assert result.exit_code == 1


class TestCreateProceduralResult:
    """Tests for CreateProceduralResult dataclass."""

    def test_basic(self):
        result = CreateProceduralResult(
            id="abc123",
            procedure="deploy-app",
            has_embedding=True,
        )
        assert result.id == "abc123"
        assert result.procedure == "deploy-app"
        assert result.has_embedding is True
        assert result.acknowledged is True

    def test_without_embedding(self):
        result = CreateProceduralResult(
            id="abc123",
            procedure="deploy-app",
            has_embedding=False,
            acknowledged=True,
        )
        assert result.has_embedding is False


class TestMemorySourceProcedural:
    """Tests that PROCEDURAL is a valid MemorySource value."""

    def test_procedural_enum_exists(self):
        assert MemorySource.PROCEDURAL == "procedural"
        assert MemorySource.PROCEDURAL.value == "procedural"

    def test_procedural_in_enum_values(self):
        assert "procedural" in [s.value for s in MemorySource]
