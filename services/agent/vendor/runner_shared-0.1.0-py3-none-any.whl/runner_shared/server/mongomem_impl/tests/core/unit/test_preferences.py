"""
Unit tests for preferences extraction pipeline.

Tests the extractor, persistence, and pipeline components.
"""

from __future__ import annotations

from typing import Any, Dict, List
from unittest.mock import MagicMock, patch

import pytest
from mongomem_core.extraction.preferences import (
    ExtractedPreferences,
    PreferencesExtractionConfig,
    PreferencesExtractionResult,
    PreferencesPipeline,
    create_preferences_pipeline,
)
from mongomem_core.extraction.preferences.extractor import (
    PreferencesExtractor,
)
from mongomem_core.extraction.preferences.persistence import (
    merge_preferences,
    should_update_field,
)
from mongomem_core.models.memory.user_prefs import (
    UserContextMemoryOut,
)


class MockLLM:
    """Mock LLM for testing."""

    def __init__(self, response: Dict[str, Any]):
        self.response = response
        self.calls: List[tuple] = []

    def complete_json(self, prompt: str, schema: Dict) -> Dict[str, Any]:
        self.calls.append((prompt, schema))
        return self.response


class TestExtractedPreferences:
    """Tests for ExtractedPreferences dataclass."""

    def test_has_any_preference_true(self):
        """Test has_any_preference returns True when preferences exist."""
        prefs = ExtractedPreferences(tone="casual", confidence=0.8)
        assert prefs.has_any_preference() is True

    def test_has_any_preference_false(self):
        """Test has_any_preference returns False when no preferences."""
        prefs = ExtractedPreferences(confidence=0.0)
        assert prefs.has_any_preference() is False

    def test_to_dict_excludes_none(self):
        """Test to_dict excludes None values."""
        prefs = ExtractedPreferences(
            tone="casual",
            style=None,
            expertise_level="expert",
            confidence=0.9,
        )
        result = prefs.to_dict()
        assert result == {
            "tone": "casual",
            "expertise_level": "expert",
            "confidence": 0.9,
        }
        assert "style" not in result


class TestPreferencesExtractor:
    """Tests for PreferencesExtractor."""

    def test_extract_returns_preferences(self):
        """Test successful extraction returns preferences."""
        mock_llm = MockLLM(
            {
                "preferences": {
                    "tone": "casual",
                    "expertise_level": "beginner",
                    "confidence": 0.85,
                }
            }
        )

        extractor = PreferencesExtractor(mock_llm)
        messages = [
            {"role": "user", "content": "I'm new to this, can you explain simply?"},
            {"role": "assistant", "content": "Of course!"},
        ]

        result = extractor.extract(messages)

        assert result is not None
        assert result.tone == "casual"
        assert result.expertise_level == "beginner"
        assert result.confidence == 0.85

    def test_extract_empty_messages(self):
        """Test extraction with empty messages returns None."""
        mock_llm = MockLLM({})
        extractor = PreferencesExtractor(mock_llm)

        result = extractor.extract([])

        assert result is None

    def test_extract_no_preferences_found(self):
        """Test extraction when no preferences detected."""
        mock_llm = MockLLM({"preferences": {"confidence": 0.0}})
        extractor = PreferencesExtractor(mock_llm)

        messages = [{"role": "user", "content": "Hello"}]
        result = extractor.extract(messages)

        assert result is not None
        assert result.has_any_preference() is False
        assert result.confidence == 0.0

    def test_extract_llm_error(self):
        """Test extraction handles LLM errors gracefully."""
        mock_llm = MagicMock()
        mock_llm.complete_json.side_effect = Exception("API error")

        extractor = PreferencesExtractor(mock_llm)
        messages = [{"role": "user", "content": "Hello"}]

        result = extractor.extract(messages)

        assert result is None

    def test_extract_raw_returns_dict(self):
        """Test extract_raw returns dict format."""
        mock_llm = MockLLM(
            {
                "preferences": {
                    "tone": "formal",
                    "style": "detailed",
                    "confidence": 0.9,
                }
            }
        )

        extractor = PreferencesExtractor(mock_llm)
        messages = [{"role": "user", "content": "Please be formal and detailed."}]

        result = extractor.extract_raw(messages)

        assert isinstance(result, dict)
        assert result["tone"] == "formal"
        assert result["style"] == "detailed"


class TestShouldUpdateField:
    """Tests for should_update_field logic."""

    def test_should_update_when_new_value_provided(self):
        """Test updates when new value is provided."""
        assert should_update_field(None, "casual", None) is True
        assert should_update_field("formal", "casual", None) is True

    def test_should_not_update_when_new_value_none(self):
        """Test no update when new value is None."""
        assert should_update_field("formal", None, None) is False

    def test_should_not_override_user_input(self):
        """Test user_input source prevents overwrite."""
        assert should_update_field("formal", "casual", "user_input") is False

    def test_allows_update_for_extracted_source(self):
        """Test allows update for extracted source."""
        assert should_update_field("formal", "casual", "extracted") is True


class TestMergePreferences:
    """Tests for merge_preferences logic."""

    def test_merge_all_new_fields(self):
        """Test merging when no existing preferences."""
        extracted = ExtractedPreferences(
            tone="casual",
            style="concise",
            expertise_level="expert",
            confidence=0.9,
        )

        merged, count = merge_preferences(None, extracted)

        assert merged["tone"] == "casual"
        assert merged["style"] == "concise"
        assert merged["expertise_level"] == "expert"
        assert count == 3

    def test_merge_respects_user_input(self):
        """Test merge respects user_input source."""
        existing = UserContextMemoryOut(
            id="test-id",
            org_id="org",
            user_id="user",
            tone="formal",
            source="user_input",
            created_at="2024-01-01T00:00:00Z",
            updated_at="2024-01-01T00:00:00Z",
        )
        extracted = ExtractedPreferences(
            tone="casual",  # Should be ignored due to user_input
            style="detailed",  # Should be added
            confidence=0.9,
        )

        merged, count = merge_preferences(existing, extracted)

        # tone should not be updated (user override prevents modification)
        assert "tone" not in merged
        assert merged["style"] == "detailed"
        assert count == 1

    def test_merge_null_fields_ignored(self):
        """Test null extracted fields are not merged."""
        extracted = ExtractedPreferences(
            tone=None,
            style=None,
            expertise_level="beginner",
            confidence=0.8,
        )

        merged, count = merge_preferences(None, extracted)

        assert "tone" not in merged
        assert "style" not in merged
        assert merged["expertise_level"] == "beginner"
        assert count == 1


class TestPreferencesPipeline:
    """Tests for PreferencesPipeline."""

    @pytest.fixture
    def mock_db(self):
        """Create mock database."""
        return MagicMock()

    @pytest.fixture
    def mock_llm(self):
        """Create mock LLM that returns preferences."""
        return MockLLM(
            {
                "preferences": {
                    "tone": "casual",
                    "expertise_level": "beginner",
                    "confidence": 0.85,
                }
            }
        )

    def test_pipeline_creation(self, mock_db, mock_llm):
        """Test pipeline can be created via factory function."""
        pipeline = create_preferences_pipeline(
            db=mock_db,
            llm=mock_llm,
        )

        assert isinstance(pipeline, PreferencesPipeline)
        assert pipeline.config.enabled is True
        assert pipeline.config.min_confidence_threshold == 0.5

    def test_pipeline_custom_config(self, mock_db, mock_llm):
        """Test pipeline with custom config."""
        config = PreferencesExtractionConfig(
            enabled=True,
            min_confidence_threshold=0.7,
        )

        pipeline = create_preferences_pipeline(
            db=mock_db,
            llm=mock_llm,
            config=config,
        )

        assert pipeline.config.min_confidence_threshold == 0.7

    def test_pipeline_disabled(self, mock_db, mock_llm):
        """Test pipeline returns early when disabled."""
        config = PreferencesExtractionConfig(enabled=False)
        pipeline = create_preferences_pipeline(
            db=mock_db,
            llm=mock_llm,
            config=config,
        )

        result = pipeline.run(
            messages=[{"role": "user", "content": "Hello"}],
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
            source_id="snap_1",
        )

        assert result.success is True
        assert result.extracted is False

    @patch("mongomem_core.extraction.preferences.persistence.get_user_context")
    @patch("mongomem_core.extraction.preferences.persistence.upsert_user_context")
    def test_pipeline_run_creates_new_prefs(self, mock_upsert, mock_get, mock_db, mock_llm):
        """Test pipeline creates new preferences when none exist."""
        mock_get.return_value = None
        mock_upsert.return_value = UserContextMemoryOut(
            id="new-id",
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
            tone="casual",
            created_at="2024-01-01T00:00:00Z",
            updated_at="2024-01-01T00:00:00Z",
        )

        pipeline = create_preferences_pipeline(db=mock_db, llm=mock_llm)

        result = pipeline.run(
            messages=[{"role": "user", "content": "Be casual with me"}],
            org_id="org_1",
            user_id="user_1",
            session_id="sess_1",
            source_id="snap_1",
        )

        assert result.success is True
        assert result.extracted is True
        assert result.action == "add"
        assert result.doc_id == "new-id"


class TestPreferencesExtractionConfig:
    """Tests for PreferencesExtractionConfig."""

    def test_default_config(self):
        """Test default configuration values."""
        config = PreferencesExtractionConfig()

        assert config.enabled is True
        assert config.min_confidence_threshold == 0.5

    def test_custom_config(self):
        """Test custom configuration."""
        config = PreferencesExtractionConfig(
            enabled=False,
            min_confidence_threshold=0.8,
        )

        assert config.enabled is False
        assert config.min_confidence_threshold == 0.8


class TestPreferencesExtractionResult:
    """Tests for PreferencesExtractionResult."""

    def test_default_result(self):
        """Test default result values."""
        result = PreferencesExtractionResult()

        assert result.success is True
        assert result.extracted is False
        assert result.action == "none"
        assert result.doc_id is None
        assert result.fields_updated == 0
        assert result.errors == []

    def test_result_with_values(self):
        """Test result with all values set."""
        result = PreferencesExtractionResult(
            success=True,
            source_reference="snap_123",
            session_id="sess_123",
            extracted=True,
            confidence=0.9,
            action="add",
            doc_id="doc_123",
            fields_updated=3,
            duration_ms=150.5,
        )

        assert result.success is True
        assert result.source_reference == "snap_123"
        assert result.session_id == "sess_123"
        assert result.extracted is True
        assert result.confidence == 0.9
        assert result.action == "add"
        assert result.doc_id == "doc_123"
        assert result.fields_updated == 3
        assert result.duration_ms == 150.5
