"""
Unit tests for RetrievalHub and source fetching.

These tests validate the RetrievalHub class, including:
- DB mode: Fetching from MongoDB (mocked)
- Pre-fetched mode: Using provided memories
- Mixed mode: Combining DB and pre-fetched sources
- Consolidation: Combining STM + episodic + semantic
- Deduplication: Removing ID, text, and similarity duplicates
- Error handling: Semantic graceful failures, STM/episodic required failures
"""

from concurrent.futures import TimeoutError as FutureTimeoutError
from unittest.mock import MagicMock, patch

import pytest
from mongomem_core.common.utils import utcnow
from mongomem_core.exceptions import DatabaseOperationError
from mongomem_core.models.memory.base import (
    ChunkVisibility,
    MessageRole,
)
from mongomem_core.models.memory.episodic import EpisodicOut
from mongomem_core.models.memory.semantic import SemanticOut
from mongomem_core.models.memory.short_term import (
    ShortTermOut,
)
from mongomem_core.models.retrieval import (
    MemoryChunk,
    MemorySource,
)
from mongomem_core.retrieval.deduplication import (
    deduplicate_memory_chunks,
)
from mongomem_core.retrieval.sources import (
    RetrievalHub,
    calculate_similarity_for_prefetched,
)
from pymongo.database import Database


class TestRetrievalHubDBMode:
    """Tests for RetrievalHub in DB mode (fetching from MongoDB)."""

    @pytest.fixture
    def mock_db(self):
        """Create a mock MongoDB database."""
        return MagicMock(spec=Database)

    @pytest.fixture
    def query_embedding(self):
        """Create a test query embedding."""
        return [0.1] * 1024  # 1024-dimensional embedding

    @pytest.fixture
    def hub(self):
        """Create a RetrievalHub instance."""
        return RetrievalHub()

    def test_fetch_memories_all_sources_db_mode(self, hub, mock_db, query_embedding):
        """fetch_memories fetches from all sources in DB mode."""
        session_id = "sess_123"
        org_id = "org_1"

        # Mock STM fetch
        stm_memories = [
            ShortTermOut(
                _id="stm_1",
                session_id=session_id,
                role=MessageRole.USER,
                content="Hello",
                org_id=org_id,
                user_id="user_1",
                timestamp=utcnow(),
            )
        ]

        # Mock episodic fetch
        episodic_memories = [
            EpisodicOut(
                _id="ep_1",
                session_id=session_id,
                title="Test Episode",
                snapshot_ref_id="snap_1",
                content="Episode content",
                summary_text="Episode summary",
                summary_type="llm",
                source_agent="user",
                participants=[],
                tags=[],
                org_id=org_id,
                user_id="user_1",
                timestamp=utcnow(),
                score=0.85,
            )
        ]

        # Mock semantic fetch
        semantic_memories = [
            SemanticOut(
                _id="sem_1",
                label="Test Knowledge",
                content="Semantic content",
                org_id=org_id,
                user_id="user_1",
                timestamp=utcnow(),
                score=0.75,
            )
        ]

        with (
            patch("mongomem_core.retrieval.sources.get_stm_by_session", return_value=stm_memories),
            patch(
                "mongomem_core.retrieval.sources.vector_search_episodic",
                return_value=episodic_memories,
            ),
            patch(
                "mongomem_core.retrieval.sources.search_semantic",
                return_value=semantic_memories,
            ),
        ):
            chunks = hub.fetch_memories(
                db=mock_db,
                session_id=session_id,
                query_embedding=query_embedding,
                org_id=org_id,
            )

            assert len(chunks) == 3
            assert any(chunk.id == "stm_1" and chunk.source == MemorySource.STM for chunk in chunks)
            assert any(
                chunk.id == "ep_1" and chunk.source == MemorySource.EPISODIC for chunk in chunks
            )
            assert any(
                chunk.id == "sem_1" and chunk.source == MemorySource.SEMANTIC for chunk in chunks
            )

    def test_fetch_memories_with_enabled_sources(self, hub, mock_db, query_embedding):
        """fetch_memories respects enabled_sources parameter."""
        session_id = "sess_123"
        org_id = "org_1"

        stm_memories = [
            ShortTermOut(
                _id="stm_1",
                session_id=session_id,
                role=MessageRole.USER,
                content="Hello",
                org_id=org_id,
                user_id="user_1",
                timestamp=utcnow(),
            )
        ]

        with (
            patch("mongomem_core.retrieval.sources.get_stm_by_session", return_value=stm_memories),
            patch("mongomem_core.retrieval.sources.vector_search_episodic") as mock_episodic,
            patch("mongomem_core.retrieval.sources.search_semantic") as mock_semantic,
        ):
            chunks = hub.fetch_memories(
                db=mock_db,
                session_id=session_id,
                query_embedding=query_embedding,
                org_id=org_id,
                enabled_sources={MemorySource.STM},
            )

            assert len(chunks) == 1
            assert chunks[0].id == "stm_1"
            mock_episodic.assert_not_called()
            mock_semantic.assert_not_called()

    def test_fetch_memories_requires_query_embedding_for_vector_sources(self, hub, mock_db):
        """fetch_memories requires query_embedding when vector sources are enabled."""
        with pytest.raises(ValueError) as exc_info:
            hub.fetch_memories(
                db=mock_db,
                session_id="sess_123",
                query_embedding=[],
                org_id="org_1",
                enabled_sources={MemorySource.EPISODIC},
            )
        assert "query_embedding is required" in str(exc_info.value)

    def test_fetch_memories_stm_only_no_embedding_required(self, hub, mock_db):
        """fetch_memories does not require query_embedding for STM-only retrieval."""
        session_id = "sess_123"
        org_id = "org_1"

        stm_memories = [
            ShortTermOut(
                _id="stm_1",
                session_id=session_id,
                role=MessageRole.USER,
                content="Hello",
                org_id=org_id,
                user_id="user_1",
                timestamp=utcnow(),
            )
        ]

        with patch("mongomem_core.retrieval.sources.get_stm_by_session", return_value=stm_memories):
            chunks = hub.fetch_memories(
                db=mock_db,
                session_id=session_id,
                query_embedding=[],  # Empty embedding OK for STM-only
                org_id=org_id,
                enabled_sources={MemorySource.STM},
            )

            assert len(chunks) == 1

    def test_fetch_memories_rbac_filtering(self, hub, mock_db, query_embedding):
        """fetch_memories passes RBAC parameters to database queries."""
        session_id = "sess_123"
        org_id = "org_1"
        user_id = "user_1"
        visibility = ChunkVisibility.PRIVATE
        project_id = "group_1"

        with (
            patch("mongomem_core.retrieval.sources.get_stm_by_session", return_value=[]),
            patch("mongomem_core.retrieval.sources.vector_search_episodic", return_value=[]),
            patch("mongomem_core.retrieval.sources.search_semantic", return_value=[]),
        ):
            hub.fetch_memories(
                db=mock_db,
                session_id=session_id,
                query_embedding=query_embedding,
                org_id=org_id,
                user_id=user_id,
                visibility=visibility,
                project_id=project_id,
            )

            # Verify RBAC parameters were passed
            from mongomem_core.retrieval.sources import (
                get_stm_by_session,
                search_semantic,
                vector_search_episodic,
            )

            get_stm_by_session.assert_called_once()
            call_kwargs = get_stm_by_session.call_args.kwargs
            assert call_kwargs["user_id"] == user_id
            assert call_kwargs["visibility"] == visibility
            assert call_kwargs["project_id"] == project_id

            vector_search_episodic.assert_called_once()
            call_kwargs = vector_search_episodic.call_args.kwargs
            assert call_kwargs["user_id"] == user_id
            assert call_kwargs["visibility"] == visibility
            assert call_kwargs["project_id"] == project_id

            search_semantic.assert_called_once()
            call_kwargs = search_semantic.call_args.kwargs
            assert call_kwargs["user_id"] == user_id
            assert call_kwargs["visibility"] == visibility
            assert call_kwargs["project_id"] == project_id


class TestRetrievalHubPrefetchedMode:
    """Tests for RetrievalHub in pre-fetched mode (using provided memories)."""

    @pytest.fixture
    def mock_db(self):
        """Create a mock MongoDB database."""
        return MagicMock(spec=Database)

    @pytest.fixture
    def query_embedding(self):
        """Create a test query embedding."""
        return [0.1] * 1024

    @pytest.fixture
    def hub(self):
        """Create a RetrievalHub instance."""
        return RetrievalHub()

    def test_fetch_memories_prefetched_stm(self, hub, mock_db, query_embedding):
        """fetch_memories uses pre-fetched STM memories."""
        session_id = "sess_123"
        org_id = "org_1"

        stm_memories = [
            ShortTermOut(
                _id="stm_1",
                session_id=session_id,
                role=MessageRole.USER,
                content="Hello",
                org_id=org_id,
                user_id="user_1",
                timestamp=utcnow(),
            )
        ]

        with (
            patch("mongomem_core.retrieval.sources.get_stm_by_session") as mock_stm,
            patch("mongomem_core.retrieval.sources.vector_search_episodic", return_value=[]),
            patch("mongomem_core.retrieval.sources.search_semantic", return_value=[]),
        ):
            chunks = hub.fetch_memories(
                db=mock_db,
                session_id=session_id,
                query_embedding=query_embedding,
                org_id=org_id,
                stm_memories=stm_memories,
            )

            assert len(chunks) == 1
            assert chunks[0].id == "stm_1"
            mock_stm.assert_not_called()  # Should not call DB

    def test_fetch_memories_prefetched_stm_session_mismatch(self, hub, mock_db, query_embedding):
        """fetch_memories logs warning for STM session_id mismatches."""
        session_id = "sess_123"
        org_id = "org_1"

        stm_memories = [
            ShortTermOut(
                _id="stm_1",
                session_id="wrong_session",  # Mismatch
                role=MessageRole.USER,
                content="Hello",
                org_id=org_id,
                user_id="user_1",
                timestamp=utcnow(),
            )
        ]

        with (
            patch("mongomem_core.retrieval.sources.get_stm_by_session", return_value=[]),
            patch("mongomem_core.retrieval.sources.vector_search_episodic", return_value=[]),
            patch("mongomem_core.retrieval.sources.search_semantic", return_value=[]),
            patch("mongomem_core.retrieval.sources.logger") as mock_logger,
        ):
            chunks = hub.fetch_memories(
                db=mock_db,
                session_id=session_id,
                query_embedding=query_embedding,
                org_id=org_id,
                stm_memories=stm_memories,
            )

            # Should still return chunks but log warning
            assert len(chunks) == 1
            mock_logger.warning.assert_called()
            assert "session_id mismatch" in str(mock_logger.warning.call_args)

    def test_fetch_memories_prefetched_episodic_with_embedding(self, hub, mock_db, query_embedding):
        """fetch_memories calculates similarity for pre-fetched episodic memories with embeddings."""
        org_id = "org_1"

        # Create episodic memory with embedding
        memory_embedding = [0.2] * 1024  # Different from query
        episodic_memories = [
            EpisodicOut(
                _id="ep_1",
                session_id="sess_1",
                title="Test",
                snapshot_ref_id="snap_1",
                content="Content",
                summary_text="Summary",
                summary_type="llm",
                source_agent="user",
                participants=[],
                tags=[],
                org_id=org_id,
                user_id="user_1",
                timestamp=utcnow(),
                embedding=memory_embedding,
                has_embedding=True,
                score=0.5,  # Old score, should be recalculated
            )
        ]

        with (
            patch("mongomem_core.retrieval.sources.get_stm_by_session", return_value=[]),
            patch("mongomem_core.retrieval.sources.vector_search_episodic") as mock_episodic,
            patch("mongomem_core.retrieval.sources.search_semantic", return_value=[]),
        ):
            chunks = hub.fetch_memories(
                db=mock_db,
                session_id="sess_123",
                query_embedding=query_embedding,
                org_id=org_id,
                episodic_memories=episodic_memories,
            )

            assert len(chunks) == 1
            assert chunks[0].id == "ep_1"
            # Similarity should be recalculated (not the old score of 0.5)
            # Cosine similarity between [0.1]*1024 and [0.2]*1024 should be 1.0 (normalized vectors)
            assert chunks[0].similarity_score is not None
            assert chunks[0].similarity_score != 0.5
            mock_episodic.assert_not_called()  # Should not call DB

    def test_fetch_memories_prefetched_episodic_no_embedding(self, hub, mock_db, query_embedding):
        """fetch_memories uses existing score for pre-fetched episodic memories without embeddings."""
        org_id = "org_1"

        episodic_memories = [
            EpisodicOut(
                _id="ep_1",
                session_id="sess_1",
                title="Test",
                snapshot_ref_id="snap_1",
                content="Content",
                summary_text="Summary",
                summary_type="llm",
                source_agent="user",
                participants=[],
                tags=[],
                org_id=org_id,
                user_id="user_1",
                timestamp=utcnow(),
                embedding=None,
                has_embedding=False,
                score=0.85,  # Should be preserved
            )
        ]

        with (
            patch("mongomem_core.retrieval.sources.get_stm_by_session", return_value=[]),
            patch("mongomem_core.retrieval.sources.vector_search_episodic") as mock_episodic,
            patch("mongomem_core.retrieval.sources.search_semantic", return_value=[]),
        ):
            chunks = hub.fetch_memories(
                db=mock_db,
                session_id="sess_123",
                query_embedding=query_embedding,
                org_id=org_id,
                episodic_memories=episodic_memories,
            )

            assert len(chunks) == 1
            assert chunks[0].similarity_score == 0.85  # Preserved
            mock_episodic.assert_not_called()

    def test_fetch_memories_prefetched_semantic(self, hub, mock_db, query_embedding):
        """fetch_memories calculates similarity for pre-fetched semantic memories."""
        org_id = "org_1"

        memory_embedding = [0.2] * 1024
        semantic_memories = [
            SemanticOut(
                _id="sem_1",
                label="Test",
                content="Content",
                org_id=org_id,
                user_id="user_1",
                timestamp=utcnow(),
                embedding=memory_embedding,
                has_embedding=True,
                score=0.6,
            )
        ]

        with (
            patch("mongomem_core.retrieval.sources.get_stm_by_session", return_value=[]),
            patch("mongomem_core.retrieval.sources.vector_search_episodic", return_value=[]),
            patch("mongomem_core.retrieval.sources.search_semantic") as mock_semantic,
        ):
            chunks = hub.fetch_memories(
                db=mock_db,
                session_id="sess_123",
                query_embedding=query_embedding,
                org_id=org_id,
                semantic_memories=semantic_memories,
            )

            assert len(chunks) == 1
            assert chunks[0].id == "sem_1"
            assert chunks[0].similarity_score is not None
            assert chunks[0].similarity_score != 0.6  # Recalculated
            mock_semantic.assert_not_called()

    def test_fetch_memories_mixed_mode(self, hub, mock_db, query_embedding):
        """fetch_memories supports mixed mode (some DB, some pre-fetched)."""
        session_id = "sess_123"
        org_id = "org_1"

        # Pre-fetched STM
        stm_memories = [
            ShortTermOut(
                _id="stm_prefetched",
                session_id=session_id,
                role=MessageRole.USER,
                content="Prefetched STM",
                org_id=org_id,
                user_id="user_1",
                timestamp=utcnow(),
            )
        ]

        # DB episodic
        episodic_memories_db = [
            EpisodicOut(
                _id="ep_db",
                session_id=session_id,
                title="DB Episode",
                snapshot_ref_id="snap_1",
                content="DB content",
                summary_text="DB summary",
                summary_type="llm",
                source_agent="user",
                participants=[],
                tags=[],
                org_id=org_id,
                user_id="user_1",
                timestamp=utcnow(),
                score=0.9,
            )
        ]

        with (
            patch("mongomem_core.retrieval.sources.get_stm_by_session") as mock_stm,
            patch(
                "mongomem_core.retrieval.sources.vector_search_episodic",
                return_value=episodic_memories_db,
            ),
            patch("mongomem_core.retrieval.sources.search_semantic", return_value=[]),
        ):
            chunks = hub.fetch_memories(
                db=mock_db,
                session_id=session_id,
                query_embedding=query_embedding,
                org_id=org_id,
                stm_memories=stm_memories,  # Pre-fetched
                # episodic_memories not provided, so uses DB
            )

            assert len(chunks) == 2
            assert any(chunk.id == "stm_prefetched" for chunk in chunks)
            assert any(chunk.id == "ep_db" for chunk in chunks)
            mock_stm.assert_not_called()  # STM was pre-fetched


class TestRetrievalHubErrorHandling:
    """Tests for error handling in RetrievalHub."""

    @pytest.fixture
    def mock_db(self):
        """Create a mock MongoDB database."""
        return MagicMock(spec=Database)

    @pytest.fixture
    def query_embedding(self):
        """Create a test query embedding."""
        return [0.1] * 1024

    @pytest.fixture
    def hub(self):
        """Create a RetrievalHub instance."""
        return RetrievalHub()

    def test_fetch_memories_stm_failure_raises_error(self, hub, mock_db, query_embedding):
        """fetch_memories raises DatabaseOperationError when required STM source fails."""
        with (
            patch(
                "mongomem_core.retrieval.sources.get_stm_by_session",
                side_effect=Exception("DB error"),
            ),
            patch("mongomem_core.retrieval.sources.vector_search_episodic", return_value=[]),
            patch("mongomem_core.retrieval.sources.search_semantic", return_value=[]),
        ):
            with pytest.raises(DatabaseOperationError) as exc_info:
                hub.fetch_memories(
                    db=mock_db,
                    session_id="sess_123",
                    query_embedding=query_embedding,
                    org_id="org_1",
                )
            assert "Failed to fetch required memory sources" in str(exc_info.value)
            assert "stm" in str(exc_info.value).lower()

    def test_fetch_memories_episodic_failure_raises_error(self, hub, mock_db, query_embedding):
        """fetch_memories raises DatabaseOperationError when required episodic source fails."""
        with (
            patch("mongomem_core.retrieval.sources.get_stm_by_session", return_value=[]),
            patch(
                "mongomem_core.retrieval.sources.vector_search_episodic",
                side_effect=Exception("DB error"),
            ),
            patch("mongomem_core.retrieval.sources.search_semantic", return_value=[]),
        ):
            with pytest.raises(DatabaseOperationError) as exc_info:
                hub.fetch_memories(
                    db=mock_db,
                    session_id="sess_123",
                    query_embedding=query_embedding,
                    org_id="org_1",
                )
            assert "Failed to fetch required memory sources" in str(exc_info.value)
            assert "episodic" in str(exc_info.value).lower()

    def test_fetch_memories_semantic_failure_graceful(self, hub, mock_db, query_embedding):
        """fetch_memories handles semantic source failure gracefully (optional source)."""
        stm_memories = [
            ShortTermOut(
                _id="stm_1",
                session_id="sess_123",
                role=MessageRole.USER,
                content="Hello",
                org_id="org_1",
                user_id="user_1",
                timestamp=utcnow(),
            )
        ]

        with (
            patch("mongomem_core.retrieval.sources.get_stm_by_session", return_value=stm_memories),
            patch("mongomem_core.retrieval.sources.vector_search_episodic", return_value=[]),
            patch(
                "mongomem_core.retrieval.sources.search_semantic",
                side_effect=Exception("DB error"),
            ),
        ):
            # Should not raise, semantic is optional
            chunks = hub.fetch_memories(
                db=mock_db,
                session_id="sess_123",
                query_embedding=query_embedding,
                org_id="org_1",
            )

            assert len(chunks) == 1  # Only STM, semantic failed gracefully

    def test_fetch_memories_timeout_raises_error(self, hub, mock_db, query_embedding):
        """fetch_memories raises DatabaseOperationError on timeout for required sources."""
        with (
            patch("mongomem_core.retrieval.sources.get_stm_by_session"),
            patch("mongomem_core.retrieval.sources.vector_search_episodic"),
            patch("mongomem_core.retrieval.sources.search_semantic", return_value=[]),
            patch("mongomem_core.retrieval.sources.search_taxonomic", return_value=[]),
            patch("mongomem_core.retrieval.sources.ThreadPoolExecutor") as mock_executor_class,
            patch("mongomem_core.retrieval.sources.as_completed") as mock_as_completed,
        ):
            mock_future_stm = MagicMock()
            mock_future_stm.done.return_value = False
            mock_future_episodic = MagicMock()
            mock_future_episodic.done.return_value = False
            mock_future_semantic = MagicMock()
            mock_future_semantic.done.return_value = False
            mock_future_taxonomic = MagicMock()
            mock_future_taxonomic.done.return_value = False

            mock_executor = MagicMock()
            mock_executor.__enter__.return_value = mock_executor
            mock_executor.submit.side_effect = [
                mock_future_stm,
                mock_future_episodic,
                mock_future_semantic,
                mock_future_taxonomic,
            ]
            mock_executor_class.return_value = mock_executor

            # Simulate timeout - as_completed raises FutureTimeoutError when iterated
            # The code does: for future in as_completed(...), so we need to raise during iteration
            class TimeoutIterator:
                def __init__(self, *args, **kwargs):
                    pass

                def __iter__(self):
                    return self

                def __next__(self):
                    raise FutureTimeoutError()

            mock_as_completed.return_value = TimeoutIterator()

            with pytest.raises(DatabaseOperationError) as exc_info:
                hub.fetch_memories(
                    db=mock_db,
                    session_id="sess_123",
                    query_embedding=query_embedding,
                    org_id="org_1",
                )
            assert "Timeout" in str(exc_info.value)


class TestRetrievalHubDeduplication:
    """Tests for deduplication logic in RetrievalHub."""

    @pytest.fixture
    def hub(self):
        """Create a RetrievalHub instance."""
        return RetrievalHub()

    def test_deduplicate_memories_exact_id_duplicates(self, hub):
        """_deduplicate_memories removes exact ID duplicates."""
        chunks = [
            MemoryChunk(
                id="chunk_1",
                content="First unique content here",
                source=MemorySource.STM,
                timestamp=utcnow(),
            ),
            MemoryChunk(
                id="chunk_1",  # Duplicate ID
                content="Second different content entirely",
                source=MemorySource.EPISODIC,
                timestamp=utcnow(),
            ),
            MemoryChunk(
                id="chunk_2",
                content="Completely unrelated third piece of text",
                source=MemorySource.STM,
                timestamp=utcnow(),
            ),
        ]

        result = deduplicate_memory_chunks(
            chunks, similarity_threshold=0.9
        )  # High threshold to avoid similarity dedup
        assert len(result) == 2
        assert result[0].id == "chunk_1"
        assert result[1].id == "chunk_2"

    def test_deduplicate_memories_exact_text_duplicates(self, hub):
        """_deduplicate_memories removes exact text duplicates (normalized)."""
        chunks = [
            MemoryChunk(
                id="chunk_1",
                content="Hello World",
                source=MemorySource.STM,
                timestamp=utcnow(),
            ),
            MemoryChunk(
                id="chunk_2",
                content="  hello world  ",  # Normalized to same text
                source=MemorySource.EPISODIC,
                timestamp=utcnow(),
            ),
            MemoryChunk(
                id="chunk_3",
                content="Different content",
                source=MemorySource.STM,
                timestamp=utcnow(),
            ),
        ]

        result = deduplicate_memory_chunks(chunks)
        assert len(result) == 2
        assert result[0].id == "chunk_1"  # First occurrence kept
        assert result[1].id == "chunk_3"

    def test_deduplicate_memories_similarity_duplicates(self, hub):
        """_deduplicate_memories removes high similarity duplicates."""
        chunks = [
            MemoryChunk(
                id="chunk_1",
                content="The quick brown fox jumps over the lazy dog",
                source=MemorySource.STM,
                timestamp=utcnow(),
                similarity_score=0.8,
            ),
            MemoryChunk(
                id="chunk_2",
                content="The quick brown fox jumps over the lazy dog.",  # Very similar
                source=MemorySource.EPISODIC,
                timestamp=utcnow(),
                similarity_score=0.9,  # Higher score
            ),
            MemoryChunk(
                id="chunk_3",
                content="Completely different content here",
                source=MemorySource.STM,
                timestamp=utcnow(),
                similarity_score=0.7,
            ),
        ]

        result = deduplicate_memory_chunks(chunks, similarity_threshold=0.85)
        # Should keep chunk_2 (higher score) and chunk_3 (different content)
        assert len(result) == 2
        assert any(chunk.id == "chunk_2" for chunk in result)
        assert any(chunk.id == "chunk_3" for chunk in result)

    def test_deduplicate_memories_keeps_higher_score(self, hub):
        """_deduplicate_memories keeps memory with higher similarity score."""
        chunks = [
            MemoryChunk(
                id="chunk_1",
                content="Similar text content here",
                source=MemorySource.STM,
                timestamp=utcnow(),
                similarity_score=0.7,
            ),
            MemoryChunk(
                id="chunk_2",
                content="Similar text content here",  # Same text
                source=MemorySource.EPISODIC,
                timestamp=utcnow(),
                similarity_score=0.9,  # Higher score
            ),
        ]

        result = deduplicate_memory_chunks(chunks)
        # Exact text duplicate, but if they pass through, higher score wins
        assert len(result) == 1
        # Since text is identical, first one is kept (exact text dedup happens first)

    def test_deduplicate_memories_empty_list(self, hub):
        """_deduplicate_memories handles empty list."""
        result = deduplicate_memory_chunks([])
        assert result == []

    def test_deduplicate_memories_single_item(self, hub):
        """_deduplicate_memories handles single item."""
        chunks = [
            MemoryChunk(
                id="chunk_1",
                content="Content",
                source=MemorySource.STM,
                timestamp=utcnow(),
            )
        ]
        result = deduplicate_memory_chunks(chunks)
        assert len(result) == 1
        assert result[0].id == "chunk_1"


class TestRetrievalHubSimilarityCalculation:
    """Tests for similarity calculation in RetrievalHub."""

    @pytest.fixture
    def hub(self):
        """Create a RetrievalHub instance."""
        return RetrievalHub()

    def test_calculate_similarity_for_prefetched_with_embedding(self, hub):
        """_calculate_similarity_for_prefetched calculates cosine similarity."""
        query_embedding = [1.0, 0.0, 0.0]  # Unit vector
        memory_embedding = [1.0, 0.0, 0.0]  # Same vector

        episodic = EpisodicOut(
            _id="ep_1",
            session_id="sess_1",
            title="Test",
            snapshot_ref_id="snap_1",
            content="Content",
            summary_text="Summary",
            summary_type="llm",
            source_agent="user",
            participants=[],
            tags=[],
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
            embedding=memory_embedding,
            has_embedding=True,
            score=0.5,  # Old score
        )

        chunks = calculate_similarity_for_prefetched([episodic], query_embedding, "episodic")
        assert len(chunks) == 1
        assert chunks[0].similarity_score == pytest.approx(
            1.0, abs=0.01
        )  # Cosine similarity of identical vectors

    def test_calculate_similarity_for_prefetched_orthogonal_vectors(self, hub):
        """_calculate_similarity_for_prefetched handles orthogonal vectors."""
        query_embedding = [1.0, 0.0, 0.0]
        memory_embedding = [0.0, 1.0, 0.0]  # Orthogonal

        episodic = EpisodicOut(
            _id="ep_1",
            session_id="sess_1",
            title="Test",
            snapshot_ref_id="snap_1",
            content="Content",
            summary_text="Summary",
            summary_type="llm",
            source_agent="user",
            participants=[],
            tags=[],
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
            embedding=memory_embedding,
            has_embedding=True,
            score=0.5,
        )

        chunks = calculate_similarity_for_prefetched([episodic], query_embedding, "episodic")
        assert len(chunks) == 1
        assert chunks[0].similarity_score == pytest.approx(
            0.0, abs=0.01
        )  # Orthogonal = 0 similarity

    def test_calculate_similarity_for_prefetched_no_embedding(self, hub):
        """_calculate_similarity_for_prefetched uses existing score when no embedding."""
        query_embedding = [1.0, 0.0, 0.0]

        episodic = EpisodicOut(
            _id="ep_1",
            session_id="sess_1",
            title="Test",
            snapshot_ref_id="snap_1",
            content="Content",
            summary_text="Summary",
            summary_type="llm",
            source_agent="user",
            participants=[],
            tags=[],
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
            embedding=None,
            has_embedding=False,
            score=0.85,  # Should be preserved
        )

        chunks = calculate_similarity_for_prefetched([episodic], query_embedding, "episodic")
        assert len(chunks) == 1
        assert chunks[0].similarity_score == 0.85

    def test_calculate_similarity_for_prefetched_embedding_error(self, hub):
        """_calculate_similarity_for_prefetched handles embedding calculation errors gracefully."""
        query_embedding = [1.0, 0.0, 0.0]
        memory_embedding = [1.0, 0.0]  # Dimension mismatch

        episodic = EpisodicOut(
            _id="ep_1",
            session_id="sess_1",
            title="Test",
            snapshot_ref_id="snap_1",
            content="Content",
            summary_text="Summary",
            summary_type="llm",
            source_agent="user",
            participants=[],
            tags=[],
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
            embedding=memory_embedding,
            has_embedding=True,
            score=0.75,  # Should fall back to this
        )

        with patch("mongomem_core.retrieval.sources.logger") as mock_logger:
            chunks = calculate_similarity_for_prefetched([episodic], query_embedding, "episodic")
            assert len(chunks) == 1
            assert chunks[0].similarity_score == 0.75  # Falls back to existing score
            mock_logger.warning.assert_called()


class TestRetrievalHubEdgeCases:
    """Tests for edge cases in RetrievalHub."""

    @pytest.fixture
    def mock_db(self):
        """Create a mock MongoDB database."""
        return MagicMock(spec=Database)

    @pytest.fixture
    def query_embedding(self):
        """Create a test query embedding."""
        return [0.1] * 1024

    @pytest.fixture
    def hub(self):
        """Create a RetrievalHub instance."""
        return RetrievalHub()

    def test_fetch_memories_no_sources_enabled(self, hub, mock_db, query_embedding):
        """fetch_memories returns empty list when no sources enabled."""
        chunks = hub.fetch_memories(
            db=mock_db,
            session_id="sess_123",
            query_embedding=query_embedding,
            org_id="org_1",
            enabled_sources=set(),  # Empty set
        )
        assert chunks == []

    def test_fetch_memories_empty_results(self, hub, mock_db, query_embedding):
        """fetch_memories handles empty results from all sources."""
        with (
            patch("mongomem_core.retrieval.sources.get_stm_by_session", return_value=[]),
            patch("mongomem_core.retrieval.sources.vector_search_episodic", return_value=[]),
            patch("mongomem_core.retrieval.sources.search_semantic", return_value=[]),
        ):
            chunks = hub.fetch_memories(
                db=mock_db,
                session_id="sess_123",
                query_embedding=query_embedding,
                org_id="org_1",
            )
            assert chunks == []

    def test_fetch_memories_top_k_parameter(self, hub, mock_db, query_embedding):
        """fetch_memories passes top_k parameter to vector search."""
        with (
            patch("mongomem_core.retrieval.sources.get_stm_by_session", return_value=[]),
            patch(
                "mongomem_core.retrieval.sources.vector_search_episodic", return_value=[]
            ) as mock_episodic,
            patch(
                "mongomem_core.retrieval.sources.search_semantic", return_value=[]
            ) as mock_semantic,
        ):
            hub.fetch_memories(
                db=mock_db,
                session_id="sess_123",
                query_embedding=query_embedding,
                org_id="org_1",
                top_k=100,
            )

            mock_episodic.assert_called_once()
            assert mock_episodic.call_args.kwargs["top_k"] == 100
            mock_semantic.assert_called_once()
            assert mock_semantic.call_args.kwargs["top_k"] == 100

    def test_fetch_memories_similarity_threshold_parameter(self, hub, mock_db, query_embedding):
        """fetch_memories passes similarity_threshold parameter to vector search."""
        with (
            patch("mongomem_core.retrieval.sources.get_stm_by_session", return_value=[]),
            patch(
                "mongomem_core.retrieval.sources.vector_search_episodic", return_value=[]
            ) as mock_episodic,
            patch(
                "mongomem_core.retrieval.sources.search_semantic", return_value=[]
            ) as mock_semantic,
        ):
            hub.fetch_memories(
                db=mock_db,
                session_id="sess_123",
                query_embedding=query_embedding,
                org_id="org_1",
                similarity_threshold=0.7,
            )

            mock_episodic.assert_called_once()
            assert mock_episodic.call_args.kwargs["similarity_threshold"] == 0.7
            mock_semantic.assert_called_once()
            assert mock_semantic.call_args.kwargs["similarity_threshold"] == 0.7
