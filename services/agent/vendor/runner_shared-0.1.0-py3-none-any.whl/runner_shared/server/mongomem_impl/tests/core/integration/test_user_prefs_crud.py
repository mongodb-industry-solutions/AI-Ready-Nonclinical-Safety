"""
Integration tests for user preferences/context CRUD operations.

These tests use a real MongoDB database to verify end-to-end behavior
of user preferences memory operations.
"""

from mongomem_core.memory.user_prefs import (
    create_user_context,
    get_user_context,
    list_user_context,
    update_user_context,
    upsert_user_context,
)
from mongomem_core.models.memory.user_prefs import (
    UserContextMemoryIn,
    UserContextMemoryUpdate,
)


class TestUserPreferencesCRUD:
    """Integration tests for user preferences/context CRUD operations."""

    def test_create_and_get_user_context(self, bootstrapped_engine):
        """Test creating and retrieving user context."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"

        ctx_in = UserContextMemoryIn(
            tone="formal",
            style="concise",
            language="en",
            preferred_format="bullet_points",
            source="user_input",
        )

        created = create_user_context(db, ctx_in, org_id=org_id, user_id=user_id)

        assert created.id is not None
        assert created.tone == "formal"
        assert created.style == "concise"
        assert created.org_id == org_id
        assert created.user_id == user_id

        # Retrieve
        retrieved = get_user_context(db, org_id=org_id, user_id=user_id)
        assert retrieved is not None
        assert retrieved.tone == "formal"

    def test_upsert_user_context(self, bootstrapped_engine):
        """Test upserting user context."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"

        ctx_in = UserContextMemoryIn(
            tone="casual",
            style="detailed",
            language="en",
            preferred_format="paragraphs",
            source="user_input",
        )

        # First upsert creates
        created = upsert_user_context(db, ctx_in, org_id=org_id, user_id=user_id)
        original_timestamp = created.timestamp

        # Second upsert updates
        updated_in = UserContextMemoryIn(
            tone="formal",
            style="concise",
            language="en",
            preferred_format="bullet_points",
            source="user_input",
        )
        updated = upsert_user_context(db, updated_in, org_id=org_id, user_id=user_id)

        assert updated.tone == "formal"
        assert updated.timestamp == original_timestamp  # Timestamp preserved

    def test_update_user_context(self, bootstrapped_engine):
        """Test updating user context."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"
        user_id = "test-user-1"

        # Create
        ctx_in = UserContextMemoryIn(
            tone="casual",
            style="detailed",
            language="en",
            preferred_format="paragraphs",
            source="user_input",
        )
        create_user_context(db, ctx_in, org_id=org_id, user_id=user_id)

        # Update
        update = UserContextMemoryUpdate(tone="formal")
        updated = update_user_context(db, org_id=org_id, user_id=user_id, update=update)

        assert updated.tone == "formal"
        assert updated.style == "detailed"  # Other fields preserved

    def test_list_user_context(self, bootstrapped_engine):
        """Test listing user context documents."""
        db = bootstrapped_engine.db
        org_id = "test-org-1"

        # Create contexts for multiple users
        for i in range(3):
            ctx_in = UserContextMemoryIn(
                tone="formal",
                style="concise",
                language="en",
                preferred_format="bullet_points",
                source="user_input",
            )
            create_user_context(db, ctx_in, org_id=org_id, user_id=f"user-{i}")

        # List all
        all_contexts = list_user_context(db, org_id=org_id)
        assert len(all_contexts) >= 3

        # List with user filter
        user_contexts = list_user_context(db, org_id=org_id, user_id="user-1")
        assert len(user_contexts) == 1
        assert user_contexts[0].user_id == "user-1"
