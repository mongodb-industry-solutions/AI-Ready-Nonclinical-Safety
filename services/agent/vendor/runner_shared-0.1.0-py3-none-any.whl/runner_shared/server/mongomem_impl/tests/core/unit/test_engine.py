"""
Unit tests for MemoryEngine.

These tests validate the headless memory engine including:
- Initialization (from_env, from_config)
- write_turn method for short-term memory operations
- build_context for retrieval
- fetch_episodic_memories and fetch_semantic_memories methods

All database interactions are mocked - no real MongoDB required.
"""

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest
from bson import ObjectId
from mongomem_core.common.utils import utcnow
from mongomem_core.config import Settings
from mongomem_core.engine import MemoryEngine
from mongomem_core.exceptions import EmbeddingGenerationError
from mongomem_core.memory.semantic import (
    _build_update_fields,
)
from mongomem_core.models.engine import (
    WriteTurnResult,
)
from mongomem_core.models.memory.base import (
    ChunkVisibility,
    MessageRole,
)
from mongomem_core.models.memory.episodic import EpisodicOut
from mongomem_core.models.memory.semantic import SemanticOut
from mongomem_core.models.memory.short_term import (
    ShortTermOut,
)
from mongomem_core.models.retrieval import (
    ContextConfig,
    ContextMetadata,
    ContextResponse,
    MemoryChunk,
    MemorySource,
    ModelType,
)


class TestMemoryEngineInit:
    """Tests for MemoryEngine initialization."""

    @patch("mongomem_core.engine.base.get_database")
    def test_from_env(self, mock_get_db):
        """Engine can be constructed from environment."""
        mock_get_db.return_value = MagicMock()
        engine = MemoryEngine.from_env()
        assert engine.settings is not None
        assert isinstance(engine.settings, Settings)
        assert engine._db is not None

    @patch("mongomem_core.engine.base.get_database")
    def test_from_config(self, mock_get_db):
        """Engine can be constructed from explicit Settings."""
        mock_get_db.return_value = MagicMock()
        settings = Settings(
            mongo_uri="mongodb://custom:27017",
            db_name="test_db",
            embedding_dimension=768,
        )
        engine = MemoryEngine.from_config(settings)
        assert engine.settings.mongo_uri == "mongodb://custom:27017"
        assert engine.settings.db_name == "test_db"
        assert engine.settings.embedding_dimension == 768

    @patch("mongomem_core.engine.base.get_database")
    def test_default_init(self, mock_get_db):
        """Engine can be constructed with default settings."""
        mock_get_db.return_value = MagicMock()
        engine = MemoryEngine()
        # db_name may be overridden by .env, just verify settings exist
        assert engine.settings is not None
        assert engine.settings.db_name is not None


class TestWriteTurn:
    """Tests for write_turn method."""

    @patch("mongomem_core.engine.base.get_database")
    @patch("mongomem_core.engine.base.create_stm")
    def test_write_turn_user_message(self, mock_create_stm, mock_get_db):
        """write_turn creates user message STM document."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        doc_id = ObjectId()
        mock_stm_doc = MagicMock()
        mock_stm_doc.id = doc_id
        mock_stm_doc.session_id = "sess_123"
        mock_stm_doc.turn_seq = 1
        mock_create_stm.return_value = mock_stm_doc

        engine = MemoryEngine()
        result = engine.write_turn(
            session_id="sess_123",
            role="user",
            content="Hello, how are you?",
            org_id="org_1",
            user_id="user_1",
        )

        assert isinstance(result, WriteTurnResult)
        assert result.id == str(doc_id)
        assert result.session_id == "sess_123"
        assert result.turn_seq == 1
        assert result.acknowledged is True

        # Verify create_stm was called with correct args
        mock_create_stm.assert_called_once()
        call_kwargs = mock_create_stm.call_args
        assert call_kwargs.kwargs["org_id"] == "org_1"
        assert call_kwargs.kwargs["user_id"] == "user_1"

    @patch("mongomem_core.engine.base.get_database")
    @patch("mongomem_core.engine.base.create_stm")
    def test_write_turn_assistant_message(self, mock_create_stm, mock_get_db):
        """write_turn creates assistant message STM document."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        doc_id = ObjectId()
        mock_stm_doc = MagicMock()
        mock_stm_doc.id = doc_id
        mock_stm_doc.session_id = "sess_123"
        mock_stm_doc.turn_seq = 2
        mock_create_stm.return_value = mock_stm_doc

        engine = MemoryEngine()
        result = engine.write_turn(
            session_id="sess_123",
            role="assistant",
            content="I'm doing well, thank you for asking!",
            agent_id="agent_007",
            model_name="gpt-4",
            tokens=25,
            org_id="org_1",
            user_id="agent_1",
        )

        assert result.turn_seq == 2
        assert result.acknowledged is True

        # Verify ShortTermIn was passed correctly
        call_kwargs = mock_create_stm.call_args.kwargs
        passed_turn_in = call_kwargs["turn_in"]
        assert passed_turn_in.role == MessageRole.ASSISTANT
        assert passed_turn_in.agent_id == "agent_007"
        assert passed_turn_in.model_name == "gpt-4"
        assert passed_turn_in.tokens == 25

    @patch("mongomem_core.engine.base.get_database")
    @patch("mongomem_core.engine.base.create_stm")
    def test_write_turn_with_tool_calls(self, mock_create_stm, mock_get_db):
        """write_turn creates assistant message with tool calls."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        doc_id = ObjectId()
        mock_stm_doc = MagicMock()
        mock_stm_doc.id = doc_id
        mock_stm_doc.session_id = "sess_123"
        mock_stm_doc.turn_seq = 3
        mock_create_stm.return_value = mock_stm_doc

        engine = MemoryEngine()
        result = engine.write_turn(
            session_id="sess_123",
            role="assistant",
            content=None,
            tool_calls=[{"name": "get_weather", "arguments": {"city": "NYC"}, "id": "call_1"}],
            org_id="org_1",
            user_id="agent_1",
        )

        assert result.acknowledged is True

        # Verify tool_calls passed through (Pydantic converts dicts to ToolCall)
        call_kwargs = mock_create_stm.call_args.kwargs
        passed_turn_in = call_kwargs["turn_in"]
        assert passed_turn_in.tool_calls is not None
        assert len(passed_turn_in.tool_calls) == 1

    @patch("mongomem_core.engine.base.get_database")
    @patch("mongomem_core.engine.base.create_stm")
    def test_write_turn_tool_result(self, mock_create_stm, mock_get_db):
        """write_turn creates tool result message."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        doc_id = ObjectId()
        mock_stm_doc = MagicMock()
        mock_stm_doc.id = doc_id
        mock_stm_doc.session_id = "sess_123"
        mock_stm_doc.turn_seq = 4
        mock_create_stm.return_value = mock_stm_doc

        engine = MemoryEngine()
        result = engine.write_turn(
            session_id="sess_123",
            role="tool",
            content="Temperature is 72°F, sunny",
            tool_call_id="call_1",
            tool_name="get_weather",
            org_id="org_1",
            user_id="system",
        )

        assert result.acknowledged is True

        call_kwargs = mock_create_stm.call_args.kwargs
        passed_turn_in = call_kwargs["turn_in"]
        assert passed_turn_in.role == MessageRole.TOOL
        assert passed_turn_in.tool_call_id == "call_1"
        assert passed_turn_in.tool_name == "get_weather"

    @patch("mongomem_core.engine.base.get_database")
    @patch("mongomem_core.engine.base.create_stm")
    def test_write_turn_with_embedding(self, mock_create_stm, mock_get_db):
        """write_turn passes embedding to create_stm."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        doc_id = ObjectId()
        mock_stm_doc = MagicMock()
        mock_stm_doc.id = doc_id
        mock_stm_doc.session_id = "sess_123"
        mock_stm_doc.turn_seq = 1
        mock_create_stm.return_value = mock_stm_doc

        engine = MemoryEngine()
        embedding = [0.1] * 1536
        result = engine.write_turn(
            session_id="sess_123",
            role="user",
            content="What's the weather?",
            org_id="org_1",
            user_id="user_1",
            embedding=embedding,
            embedding_model_id="voyage-3-large",
        )

        assert result.acknowledged is True

        call_kwargs = mock_create_stm.call_args.kwargs
        assert call_kwargs["embedding"] == embedding
        assert call_kwargs["embedding_model_id"] == "voyage-3-large"

    @patch("mongomem_core.engine.base.get_database")
    @patch("mongomem_core.engine.base.create_stm")
    def test_write_turn_with_idempotency_key(self, mock_create_stm, mock_get_db):
        """write_turn passes idempotency_key to create_stm."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        doc_id = ObjectId()
        mock_stm_doc = MagicMock()
        mock_stm_doc.id = doc_id
        mock_stm_doc.session_id = "sess_123"
        mock_stm_doc.turn_seq = 1
        mock_create_stm.return_value = mock_stm_doc

        engine = MemoryEngine()
        engine.write_turn(
            session_id="sess_123",
            role="user",
            content="Hello",
            org_id="org_1",
            user_id="user_1",
            idempotency_key="unique-request-id-123",
        )

        call_kwargs = mock_create_stm.call_args.kwargs
        assert call_kwargs["idempotency_key"] == "unique-request-id-123"

    @patch("mongomem_core.engine.base.get_database")
    @patch("mongomem_core.engine.base.create_stm")
    def test_write_turn_tool_error(self, mock_create_stm, mock_get_db):
        """write_turn creates tool error result message."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        doc_id = ObjectId()
        mock_stm_doc = MagicMock()
        mock_stm_doc.id = doc_id
        mock_stm_doc.session_id = "sess_123"
        mock_stm_doc.turn_seq = 5
        mock_create_stm.return_value = mock_stm_doc

        engine = MemoryEngine()
        write_result = engine.write_turn(
            session_id="sess_123",
            role="tool",
            content="Error: API rate limit exceeded",
            tool_call_id="call_2",
            tool_name="external_api",
            is_error=True,
            org_id="org_1",
            user_id="system",
        )

        assert write_result.acknowledged is True

        call_kwargs = mock_create_stm.call_args.kwargs
        passed_turn_in = call_kwargs["turn_in"]
        assert passed_turn_in.is_error is True


class TestBootstrap:
    """Tests for engine bootstrap method."""

    @patch("mongomem_core.engine.base.ensure_engine_search_indexes")
    @patch("mongomem_core.engine.base.ensure_engine_indexes")
    @patch("mongomem_core.engine.base.ensure_engine_collections")
    @patch("mongomem_core.engine.base.get_database")
    def test_bootstrap_with_search_indexes(
        self,
        mock_get_db,
        mock_ensure_cols,
        mock_ensure_idx,
        mock_ensure_search,
    ):
        """Bootstrap creates collections, indexes, and search indexes."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        engine = MemoryEngine()
        engine.bootstrap(ensure_search_indexes=True)

        mock_ensure_cols.assert_called_once_with(mock_db)
        mock_ensure_idx.assert_called_once_with(mock_db)
        mock_ensure_search.assert_called_once()

    @patch("mongomem_core.engine.base.ensure_engine_search_indexes")
    @patch("mongomem_core.engine.base.ensure_engine_indexes")
    @patch("mongomem_core.engine.base.ensure_engine_collections")
    @patch("mongomem_core.engine.base.get_database")
    def test_bootstrap_without_search_indexes(
        self,
        mock_get_db,
        mock_ensure_cols,
        mock_ensure_idx,
        mock_ensure_search,
    ):
        """Bootstrap skips search indexes when disabled."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        engine = MemoryEngine()
        engine.bootstrap(ensure_search_indexes=False)

        mock_ensure_cols.assert_called_once()
        mock_ensure_idx.assert_called_once()
        mock_ensure_search.assert_not_called()


class TestBuildContext:
    """Tests for build_context method."""

    @patch("mongomem_core.engine.retrieval.ContextBuilder")
    @patch("mongomem_core.engine.base.get_database")
    def test_build_context_basic(self, mock_get_db, mock_context_builder_cls):
        """build_context delegates to ContextBuilder with correct parameters."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        # Mock ContextBuilder instance and its build_context method
        mock_builder = MagicMock()
        mock_context_builder_cls.return_value = mock_builder
        mock_response = ContextResponse(
            formatted_context="Test context",
            metadata=ContextMetadata(token_count=100, memory_counts={"stm": 2}),
        )
        mock_builder.build_context.return_value = mock_response

        engine = MemoryEngine()
        result = engine.build_context(
            query="What did we discuss?",
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
        )

        assert result == mock_response
        assert result.metadata.token_count == 100

        # Verify ContextBuilder was constructed with correct components
        mock_context_builder_cls.assert_called_once()
        call_kwargs = mock_context_builder_cls.call_args.kwargs
        assert call_kwargs["embedder"] is None
        assert call_kwargs["llm"] is None
        assert "retrieval_hub" in call_kwargs
        assert "ranker" in call_kwargs
        assert "budgeter" in call_kwargs
        assert "formatter" in call_kwargs

        # Verify build_context was called with correct args
        mock_builder.build_context.assert_called_once()
        build_call_kwargs = mock_builder.build_context.call_args.kwargs
        assert build_call_kwargs["db"] == mock_db
        assert build_call_kwargs["session_id"] == "sess_123"
        assert build_call_kwargs["query"] == "What did we discuss?"
        assert build_call_kwargs["org_id"] == "org_1"
        assert build_call_kwargs["user_id"] == "user_1"

    @patch("mongomem_core.engine.retrieval.ContextBuilder")
    @patch("mongomem_core.engine.base.get_database")
    def test_build_context_with_embedder_and_llm(self, mock_get_db, mock_context_builder_cls):
        """build_context passes engine's embedder and llm to ContextBuilder."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        # Create mock embedder and llm with explicit dimension
        mock_embedder = MagicMock()
        mock_embedder.dimension = 1024
        mock_llm = MagicMock()

        mock_builder = MagicMock()
        mock_context_builder_cls.return_value = mock_builder
        mock_response = ContextResponse(
            formatted_context=[],
            metadata=ContextMetadata(),
        )
        mock_builder.build_context.return_value = mock_response

        # Pass explicit settings to match embedder dimension
        settings = Settings(embedding_dimension=1024)
        engine = MemoryEngine(settings=settings, embedder=mock_embedder, llm=mock_llm)
        engine.build_context(
            query="Test query",
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
        )

        # Verify embedder and llm were passed to ContextBuilder
        call_kwargs = mock_context_builder_cls.call_args.kwargs
        assert call_kwargs["embedder"] == mock_embedder
        assert call_kwargs["llm"] == mock_llm

    @patch("mongomem_core.engine.retrieval.ContextBuilder")
    @patch("mongomem_core.engine.base.get_database")
    def test_build_context_with_model_type_string(self, mock_get_db, mock_context_builder_cls):
        """build_context converts model_type string to enum."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        mock_builder = MagicMock()
        mock_context_builder_cls.return_value = mock_builder
        mock_response = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )
        mock_builder.build_context.return_value = mock_response

        engine = MemoryEngine()
        engine.build_context(
            query="Test",
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            model_type="claude",
        )

        # Verify config was passed with correct model_type
        build_call_kwargs = mock_builder.build_context.call_args.kwargs
        config = build_call_kwargs["config"]
        assert isinstance(config, ContextConfig)
        assert config.model_type == ModelType.CLAUDE

    @patch("mongomem_core.engine.retrieval.ContextBuilder")
    @patch("mongomem_core.engine.base.get_database")
    def test_build_context_with_model_type_enum(self, mock_get_db, mock_context_builder_cls):
        """build_context accepts ModelType enum directly."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        mock_builder = MagicMock()
        mock_context_builder_cls.return_value = mock_builder
        mock_response = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )
        mock_builder.build_context.return_value = mock_response

        engine = MemoryEngine()
        engine.build_context(
            query="Test",
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            model_type=ModelType.GEMINI,
        )

        build_call_kwargs = mock_builder.build_context.call_args.kwargs
        config = build_call_kwargs["config"]
        assert config.model_type == ModelType.GEMINI

    @patch("mongomem_core.engine.retrieval.ContextBuilder")
    @patch("mongomem_core.engine.base.get_database")
    def test_build_context_with_enabled_sources_strings(
        self, mock_get_db, mock_context_builder_cls
    ):
        """build_context converts enabled_sources strings to enums."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        mock_builder = MagicMock()
        mock_context_builder_cls.return_value = mock_builder
        mock_response = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )
        mock_builder.build_context.return_value = mock_response

        engine = MemoryEngine()
        engine.build_context(
            query="Test",
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            enabled_sources={"stm", "episodic"},
        )

        build_call_kwargs = mock_builder.build_context.call_args.kwargs
        config = build_call_kwargs["config"]
        assert config.enabled_sources == {MemorySource.STM, MemorySource.EPISODIC}

    @patch("mongomem_core.engine.retrieval.ContextBuilder")
    @patch("mongomem_core.engine.base.get_database")
    def test_build_context_with_enabled_sources_enums(self, mock_get_db, mock_context_builder_cls):
        """build_context accepts MemorySource enums directly."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        mock_builder = MagicMock()
        mock_context_builder_cls.return_value = mock_builder
        mock_response = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )
        mock_builder.build_context.return_value = mock_response

        engine = MemoryEngine()
        engine.build_context(
            query="Test",
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            enabled_sources={MemorySource.SEMANTIC},
        )

        build_call_kwargs = mock_builder.build_context.call_args.kwargs
        config = build_call_kwargs["config"]
        assert config.enabled_sources == {MemorySource.SEMANTIC}

    @patch("mongomem_core.engine.retrieval.ContextBuilder")
    @patch("mongomem_core.engine.base.get_database")
    def test_build_context_with_max_tokens(self, mock_get_db, mock_context_builder_cls):
        """build_context passes max_tokens to ContextConfig."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        mock_builder = MagicMock()
        mock_context_builder_cls.return_value = mock_builder
        mock_response = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )
        mock_builder.build_context.return_value = mock_response

        engine = MemoryEngine()
        engine.build_context(
            query="Test",
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            max_tokens=8000,
        )

        build_call_kwargs = mock_builder.build_context.call_args.kwargs
        config = build_call_kwargs["config"]
        assert config.max_tokens == 8000

    @patch("mongomem_core.engine.retrieval.ContextBuilder")
    @patch("mongomem_core.engine.base.get_database")
    def test_build_context_with_similarity_threshold(self, mock_get_db, mock_context_builder_cls):
        """build_context passes similarity_threshold to ContextConfig."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        mock_builder = MagicMock()
        mock_context_builder_cls.return_value = mock_builder
        mock_response = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )
        mock_builder.build_context.return_value = mock_response

        engine = MemoryEngine()
        engine.build_context(
            query="Test",
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            similarity_threshold=0.7,
        )

        build_call_kwargs = mock_builder.build_context.call_args.kwargs
        config = build_call_kwargs["config"]
        assert config.similarity_threshold == 0.7

    @patch("mongomem_core.engine.retrieval.ContextBuilder")
    @patch("mongomem_core.engine.base.get_database")
    def test_build_context_with_query_embedding(self, mock_get_db, mock_context_builder_cls):
        """build_context passes query_embedding to ContextBuilder."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        mock_builder = MagicMock()
        mock_context_builder_cls.return_value = mock_builder
        mock_response = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )
        mock_builder.build_context.return_value = mock_response

        embedding = [0.1] * 1536
        engine = MemoryEngine()
        engine.build_context(
            query="Test",
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            query_embedding=embedding,
        )

        build_call_kwargs = mock_builder.build_context.call_args.kwargs
        assert build_call_kwargs["query_embedding"] == embedding

    @patch("mongomem_core.engine.retrieval.ContextBuilder")
    @patch("mongomem_core.engine.base.get_database")
    def test_build_context_with_visibility_and_group(self, mock_get_db, mock_context_builder_cls):
        """build_context passes visibility and project_id to ContextBuilder."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        mock_builder = MagicMock()
        mock_context_builder_cls.return_value = mock_builder
        mock_response = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )
        mock_builder.build_context.return_value = mock_response

        engine = MemoryEngine()
        engine.build_context(
            query="Test",
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            visibility=ChunkVisibility.SHARED,
            project_id="team_engineering",
        )

        build_call_kwargs = mock_builder.build_context.call_args.kwargs
        assert build_call_kwargs["visibility"] == ChunkVisibility.SHARED
        assert build_call_kwargs["project_id"] == "team_engineering"

    @patch("mongomem_core.engine.retrieval.ContextBuilder")
    @patch("mongomem_core.engine.base.get_database")
    def test_build_context_with_prefetched_memories(self, mock_get_db, mock_context_builder_cls):
        """build_context passes pre-fetched memories to ContextBuilder."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        mock_builder = MagicMock()
        mock_context_builder_cls.return_value = mock_builder
        mock_response = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )
        mock_builder.build_context.return_value = mock_response

        # Create mock pre-fetched STM memories
        stm_memories = [
            ShortTermOut(
                id="stm_1",
                session_id="sess_123",
                role=MessageRole.USER,
                content="Hello",
                org_id="org_1",
                user_id="user_1",
                turn_seq=1,
                timestamp=datetime.now(timezone.utc),
            ),
        ]

        engine = MemoryEngine()
        engine.build_context(
            query="Test",
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            stm_memories=stm_memories,
        )

        build_call_kwargs = mock_builder.build_context.call_args.kwargs
        assert build_call_kwargs["stm_memories"] == stm_memories

    @patch("mongomem_core.engine.retrieval.ContextBuilder")
    @patch("mongomem_core.engine.base.get_database")
    def test_build_context_with_top_k(self, mock_get_db, mock_context_builder_cls):
        """build_context passes top_k to ContextBuilder."""
        mock_db = MagicMock()
        mock_get_db.return_value = mock_db

        mock_builder = MagicMock()
        mock_context_builder_cls.return_value = mock_builder
        mock_response = ContextResponse(
            formatted_context="",
            metadata=ContextMetadata(),
        )
        mock_builder.build_context.return_value = mock_response

        engine = MemoryEngine()
        engine.build_context(
            query="Test",
            session_id="sess_123",
            org_id="org_1",
            user_id="user_1",
            top_k=100,
        )

        build_call_kwargs = mock_builder.build_context.call_args.kwargs
        assert build_call_kwargs["top_k"] == 100


class TestBuildContextConfig:
    """Tests for ContextConfig.from_params factory method."""

    def test_build_context_config_defaults(self):
        """ContextConfig.from_params uses defaults when no custom values provided."""
        config = ContextConfig.from_params(
            model_type=ModelType.OPENAI,
            max_tokens=None,
            similarity_threshold=0.0,
            enabled_sources=None,
        )

        assert config.model_type == ModelType.OPENAI
        assert config.max_tokens == 16000  # default
        assert config.similarity_threshold == 0.0
        # Default enabled_sources includes EPISODIC and SEMANTIC (not STM)
        assert config.enabled_sources == {
            MemorySource.EPISODIC,
            MemorySource.SEMANTIC,
        }

    def test_build_context_config_custom_values(self):
        """ContextConfig.from_params applies custom values correctly."""
        config = ContextConfig.from_params(
            model_type="anthropic",
            max_tokens=4000,
            similarity_threshold=0.5,
            enabled_sources={"stm"},
        )

        assert config.model_type == ModelType.ANTHROPIC
        assert config.max_tokens == 4000
        assert config.similarity_threshold == 0.5
        assert config.enabled_sources == {MemorySource.STM}

    def test_build_context_config_mixed_sources(self):
        """ContextConfig.from_params handles mixed string/enum sources."""
        config = ContextConfig.from_params(
            model_type=ModelType.OPENAI,
            max_tokens=None,
            similarity_threshold=0.0,
            enabled_sources={"stm", MemorySource.EPISODIC},
        )

        assert config.enabled_sources == {MemorySource.STM, MemorySource.EPISODIC}


class TestEngineFetchEpisodicMemories:
    """Tests for MemoryEngine.fetch_episodic_memories method."""

    @pytest.fixture
    def mock_db(self):
        """Create a mock MongoDB database."""
        return MagicMock()

    @pytest.fixture
    def mock_embedder(self):
        """Create a mock embedder."""
        embedder = MagicMock()
        embedder.embed.return_value = [0.1] * 1024
        return embedder

    @pytest.fixture
    def engine(self, mock_db, mock_embedder):
        """Create a MemoryEngine instance with mocked dependencies."""
        with patch("mongomem_core.engine.base.get_database", return_value=mock_db):
            engine = MemoryEngine()
            engine._embedder = mock_embedder
            return engine

    @pytest.fixture
    def sample_episodic(self):
        """Create a sample episodic memory."""
        return EpisodicOut(
            _id="ep_1",
            session_id="sess_123",
            title="Test Episode",
            snapshot_ref_id="snap_1",
            content="Episode content",
            summary_text="Episode summary",
            summary_type="llm",
            source_agent="user",
            participants=[],
            tags=[],
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
            score=0.85,
        )

    def test_fetch_episodic_with_text_query(self, engine, mock_embedder, sample_episodic):
        """fetch_episodic_memories uses engine embedder for text queries."""
        with patch(
            "mongomem_core.engine.episodic.fetch_episodic_memories",
            return_value=[MemoryChunk.from_episodic(sample_episodic)],
        ) as mock_fetch:
            result = engine.fetch_episodic_memories(
                query="test query",
                org_id="org_1",
            )

            assert len(result) == 1
            mock_fetch.assert_called_once()
            call_kwargs = mock_fetch.call_args.kwargs
            assert call_kwargs["query"] == "test query"
            assert call_kwargs["embedder"] == mock_embedder
            assert call_kwargs["db"] == engine._db

    def test_fetch_episodic_with_embedding_query(self, engine, sample_episodic):
        """fetch_episodic_memories accepts List[float] as query."""
        query_embedding = [0.1] * 1024
        with patch(
            "mongomem_core.engine.episodic.fetch_episodic_memories",
            return_value=[MemoryChunk.from_episodic(sample_episodic)],
        ) as mock_fetch:
            result = engine.fetch_episodic_memories(
                query=query_embedding,
                org_id="org_1",
            )

            assert len(result) == 1
            mock_fetch.assert_called_once()
            call_kwargs = mock_fetch.call_args.kwargs
            assert call_kwargs["query"] == query_embedding

    def test_fetch_episodic_converts_visibility_string(self, engine, sample_episodic):
        """fetch_episodic_memories converts visibility string to ChunkVisibility."""
        with patch(
            "mongomem_core.engine.episodic.fetch_episodic_memories",
            return_value=[MemoryChunk.from_episodic(sample_episodic)],
        ) as mock_fetch:
            engine.fetch_episodic_memories(
                query="test",
                org_id="org_1",
                visibility="shared",
            )

            call_kwargs = mock_fetch.call_args.kwargs
            assert call_kwargs["visibility"] == ChunkVisibility.SHARED

    def test_fetch_episodic_passes_all_parameters(self, engine, sample_episodic):
        """fetch_episodic_memories passes all parameters correctly."""
        with patch(
            "mongomem_core.engine.episodic.fetch_episodic_memories",
            return_value=[MemoryChunk.from_episodic(sample_episodic)],
        ) as mock_fetch:
            engine.fetch_episodic_memories(
                query="test",
                org_id="org_1",
                user_id="user_1",
                visibility="private",
                project_id="group_1",
                session_id="sess_123",
                top_k=20,
                similarity_threshold=0.7,
                dedup_threshold=0.6,
                deduplicate=False,
                rank=False,
            )

            call_kwargs = mock_fetch.call_args.kwargs
            assert call_kwargs["org_id"] == "org_1"
            assert call_kwargs["user_id"] == "user_1"
            assert call_kwargs["project_id"] == "group_1"
            assert call_kwargs["session_id"] == "sess_123"
            assert call_kwargs["top_k"] == 20
            assert call_kwargs["similarity_threshold"] == 0.7
            assert call_kwargs["dedup_threshold"] == 0.6
            assert call_kwargs["deduplicate"] is False
            assert call_kwargs["rank"] is False

    def test_fetch_episodic_with_prefetched(self, engine, sample_episodic):
        """fetch_episodic_memories passes prefetched memories."""
        with patch(
            "mongomem_core.engine.episodic.fetch_episodic_memories",
            return_value=[MemoryChunk.from_episodic(sample_episodic)],
        ) as mock_fetch:
            engine.fetch_episodic_memories(
                query="test",
                org_id="org_1",
                prefetched=[sample_episodic],
            )

            call_kwargs = mock_fetch.call_args.kwargs
            assert call_kwargs["prefetched"] == [sample_episodic]

    def test_fetch_episodic_defaults_rank_true(self, engine, sample_episodic):
        """fetch_episodic_memories defaults rank=True."""
        with patch(
            "mongomem_core.engine.episodic.fetch_episodic_memories",
            return_value=[MemoryChunk.from_episodic(sample_episodic)],
        ) as mock_fetch:
            engine.fetch_episodic_memories(
                query="test",
                org_id="org_1",
            )

            call_kwargs = mock_fetch.call_args.kwargs
            assert call_kwargs["rank"] is True

    def test_fetch_episodic_defaults_deduplicate_true(self, engine, sample_episodic):
        """fetch_episodic_memories defaults deduplicate=True."""
        with patch(
            "mongomem_core.engine.episodic.fetch_episodic_memories",
            return_value=[MemoryChunk.from_episodic(sample_episodic)],
        ) as mock_fetch:
            engine.fetch_episodic_memories(
                query="test",
                org_id="org_1",
            )

            call_kwargs = mock_fetch.call_args.kwargs
            assert call_kwargs["deduplicate"] is True

    def test_fetch_episodic_handles_embedding_error(self, engine, mock_embedder):
        """fetch_episodic_memories propagates EmbeddingGenerationError."""
        mock_embedder.embed.side_effect = EmbeddingGenerationError("Embedding failed", query="test")
        with pytest.raises(EmbeddingGenerationError):
            engine.fetch_episodic_memories(
                query="test",
                org_id="org_1",
            )


class TestEngineUpdateSemantic:
    """Tests for MemoryEngine.update_semantic method."""

    @pytest.fixture
    def mock_db(self):
        return MagicMock()

    @pytest.fixture
    def mock_embedder(self):
        embedder = MagicMock()
        embedder.dimension = 1024
        embedder.model_id = "test-embedder"
        embedder.embed.return_value = [0.2] * 1024
        return embedder

    @pytest.fixture
    def engine(self, mock_db, mock_embedder):
        settings = Settings(embedding_dimension=1024)
        with patch("mongomem_core.engine.base.get_database", return_value=mock_db):
            return MemoryEngine(settings=settings, embedder=mock_embedder)

    def test_update_semantic_embeds_updated_text(self, engine, mock_embedder):
        updated = MagicMock()
        with patch(
            "mongomem_core.engine.semantic.update_semantic",
            return_value=updated,
        ) as mock_update:
            result = engine.update_semantic(
                org_id="org_1",
                label="customer_name",
                text="Customer name: Jane Smith",
            )

        assert result is updated
        mock_embedder.embed.assert_called_once_with("Customer name: Jane Smith")
        update = mock_update.call_args.kwargs["update"]
        assert update.content == "Customer name: Jane Smith"
        assert update.embedding == [0.2] * 1024
        assert update.embedding_model_id == "test-embedder"
        assert _build_update_fields(update)["embedding_model_id"] == "test-embedder"

    def test_update_semantic_without_text_does_not_embed(self, engine, mock_embedder):
        with patch("mongomem_core.engine.semantic.update_semantic") as mock_update:
            engine.update_semantic(
                org_id="org_1",
                label="customer_name",
                contextual_metadata={"source": "profile"},
            )

        mock_embedder.embed.assert_not_called()
        update = mock_update.call_args.kwargs["update"]
        assert update.embedding is None
        assert update.embedding_model_id is None
        assert "embedding_model_id" not in _build_update_fields(update)


class TestEngineFetchSemanticMemories:
    """Tests for MemoryEngine.fetch_semantic_memories method."""

    @pytest.fixture
    def mock_db(self):
        """Create a mock MongoDB database."""
        return MagicMock()

    @pytest.fixture
    def mock_embedder(self):
        """Create a mock embedder."""
        embedder = MagicMock()
        embedder.embed.return_value = [0.1] * 1024
        return embedder

    @pytest.fixture
    def engine(self, mock_db, mock_embedder):
        """Create a MemoryEngine instance with mocked dependencies."""
        with patch("mongomem_core.engine.base.get_database", return_value=mock_db):
            engine = MemoryEngine()
            engine._embedder = mock_embedder
            return engine

    @pytest.fixture
    def sample_semantic(self):
        """Create a sample semantic memory."""
        return SemanticOut(
            _id="sem_1",
            label="Test Knowledge",
            content="Semantic content",
            org_id="org_1",
            user_id="user_1",
            timestamp=utcnow(),
            score=0.75,
        )

    def test_fetch_semantic_with_text_query(self, engine, mock_embedder, sample_semantic):
        """fetch_semantic_memories uses engine embedder for text queries."""
        with patch(
            "mongomem_core.engine.semantic.fetch_semantic_memories",
            return_value=[MemoryChunk.from_semantic(sample_semantic)],
        ) as mock_fetch:
            result = engine.fetch_semantic_memories(
                query="test query",
                org_id="org_1",
            )

            assert len(result) == 1
            mock_fetch.assert_called_once()
            call_kwargs = mock_fetch.call_args.kwargs
            assert call_kwargs["query"] == "test query"
            assert call_kwargs["embedder"] == mock_embedder
            assert call_kwargs["db"] == engine._db

    def test_fetch_semantic_with_embedding_query(self, engine, sample_semantic):
        """fetch_semantic_memories accepts List[float] as query."""
        query_embedding = [0.1] * 1024
        with patch(
            "mongomem_core.engine.semantic.fetch_semantic_memories",
            return_value=[MemoryChunk.from_semantic(sample_semantic)],
        ) as mock_fetch:
            result = engine.fetch_semantic_memories(
                query=query_embedding,
                org_id="org_1",
            )

            assert len(result) == 1
            mock_fetch.assert_called_once()
            call_kwargs = mock_fetch.call_args.kwargs
            assert call_kwargs["query"] == query_embedding

    def test_fetch_semantic_converts_visibility_string(self, engine, sample_semantic):
        """fetch_semantic_memories converts visibility string to ChunkVisibility."""
        with patch(
            "mongomem_core.engine.semantic.fetch_semantic_memories",
            return_value=[MemoryChunk.from_semantic(sample_semantic)],
        ) as mock_fetch:
            engine.fetch_semantic_memories(
                query="test",
                org_id="org_1",
                visibility="org",
            )

            call_kwargs = mock_fetch.call_args.kwargs
            assert call_kwargs["visibility"] == ChunkVisibility.ORG

    def test_fetch_semantic_passes_all_parameters(self, engine, sample_semantic):
        """fetch_semantic_memories passes all parameters correctly."""
        with patch(
            "mongomem_core.engine.semantic.fetch_semantic_memories",
            return_value=[MemoryChunk.from_semantic(sample_semantic)],
        ) as mock_fetch:
            engine.fetch_semantic_memories(
                query="test",
                org_id="org_1",
                user_id="user_1",
                visibility="shared",
                project_id="group_1",
                top_k=30,
                similarity_threshold=0.6,
                dedup_threshold=0.5,
                deduplicate=False,
                rank=False,
            )

            call_kwargs = mock_fetch.call_args.kwargs
            assert call_kwargs["org_id"] == "org_1"
            assert call_kwargs["user_id"] == "user_1"
            assert call_kwargs["project_id"] == "group_1"
            assert call_kwargs["top_k"] == 30
            assert call_kwargs["similarity_threshold"] == 0.6
            assert call_kwargs["dedup_threshold"] == 0.5
            assert call_kwargs["deduplicate"] is False
            assert call_kwargs["rank"] is False

    def test_fetch_semantic_with_prefetched(self, engine, sample_semantic):
        """fetch_semantic_memories passes prefetched memories."""
        with patch(
            "mongomem_core.engine.semantic.fetch_semantic_memories",
            return_value=[MemoryChunk.from_semantic(sample_semantic)],
        ) as mock_fetch:
            engine.fetch_semantic_memories(
                query="test",
                org_id="org_1",
                prefetched=[sample_semantic],
            )

            call_kwargs = mock_fetch.call_args.kwargs
            assert call_kwargs["prefetched"] == [sample_semantic]

    def test_fetch_semantic_defaults_rank_true(self, engine, sample_semantic):
        """fetch_semantic_memories defaults rank=True."""
        with patch(
            "mongomem_core.engine.semantic.fetch_semantic_memories",
            return_value=[MemoryChunk.from_semantic(sample_semantic)],
        ) as mock_fetch:
            engine.fetch_semantic_memories(
                query="test",
                org_id="org_1",
            )

            call_kwargs = mock_fetch.call_args.kwargs
            assert call_kwargs["rank"] is True

    def test_fetch_semantic_defaults_deduplicate_true(self, engine, sample_semantic):
        """fetch_semantic_memories defaults deduplicate=True."""
        with patch(
            "mongomem_core.engine.semantic.fetch_semantic_memories",
            return_value=[MemoryChunk.from_semantic(sample_semantic)],
        ) as mock_fetch:
            engine.fetch_semantic_memories(
                query="test",
                org_id="org_1",
            )

            call_kwargs = mock_fetch.call_args.kwargs
            assert call_kwargs["deduplicate"] is True

    def test_fetch_semantic_handles_embedding_error(self, engine, mock_embedder):
        """fetch_semantic_memories propagates EmbeddingGenerationError."""
        mock_embedder.embed.side_effect = EmbeddingGenerationError("Embedding failed", query="test")
        with pytest.raises(EmbeddingGenerationError):
            engine.fetch_semantic_memories(
                query="test",
                org_id="org_1",
            )
