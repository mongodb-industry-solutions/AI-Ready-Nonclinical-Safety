"""Unit tests for procedural extraction pipeline."""

from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import pytest
from mongomem_core.extraction.procedural import (
    ProceduralExtractor,
    ProceduralPipeline,
    create_procedural_pipeline,
)
from mongomem_core.extraction.procedural.config import (
    ProceduralExtractionConfig,
)
from mongomem_core.extraction.procedural.persistence import (
    generate_procedural_extraction_id,
)
from mongomem_core.extraction.types import ExtractedItem

# ═══════════════════════════════════════════════════════════════════════════════
# ProceduralExtractionConfig
# ═══════════════════════════════════════════════════════════════════════════════


class TestProceduralExtractionConfig:
    """Tests for ProceduralExtractionConfig."""

    def test_defaults(self):
        config = ProceduralExtractionConfig()
        assert config.enabled is True
        assert config.min_combined_score_threshold == 0.6
        assert config.citation_weight == 0.4
        assert config.confidence_weight == 0.6
        assert config.consolidation_top_k == 3
        assert config.consolidation_similarity_threshold == 0.80
        assert config.reinforcement_history_limit == 20
        assert config.max_procedures_per_snapshot == 5

    def test_frozen(self):
        config = ProceduralExtractionConfig()
        with pytest.raises(AttributeError):
            config.enabled = False  # type: ignore[misc]

    def test_implements_protocol(self):
        from mongomem_core.extraction.config import (
            ExtractionConfigProtocol,
        )

        config = ProceduralExtractionConfig()
        assert isinstance(config, ExtractionConfigProtocol)


# ═══════════════════════════════════════════════════════════════════════════════
# ProceduralExtractor
# ═══════════════════════════════════════════════════════════════════════════════


class TestProceduralExtractor:
    """Tests for ProceduralExtractor."""

    @pytest.fixture
    def mock_llm(self):
        llm = MagicMock()
        llm.complete_json.return_value = {
            "procedures": [
                {
                    "procedure": "deploy-app",
                    "description": "Deploy the app to production",
                    "content": "# Deploy\n\n1. Build image\n2. Push\n3. Deploy",
                    "steps": [
                        {
                            "step_type": "code",
                            "content": "docker build -t app .",
                            "description": "Build Docker image",
                            "language": "bash",
                        }
                    ],
                    "tags": ["deployment"],
                    "citations": [0, 1],
                    "confidence_score": 0.9,
                },
            ]
        }
        return llm

    @pytest.fixture
    def sample_messages(self):
        return [
            {"role": "user", "content": "Let me show you how to deploy the app."},
            {"role": "assistant", "content": "Sure, walk me through the steps."},
            {"role": "user", "content": "First build with docker build -t app ."},
        ]

    def test_extract_basic(self, mock_llm, sample_messages):
        extractor = ProceduralExtractor(mock_llm)
        result = extractor.extract(sample_messages)

        assert len(result) == 1
        assert result[0].content == "# Deploy\n\n1. Build image\n2. Push\n3. Deploy"
        assert result[0].citations == [0, 1]
        assert result[0].confidence == 0.9
        assert result[0].metadata["procedure"] == "deploy-app"
        assert result[0].metadata["description"] == "Deploy the app to production"
        assert result[0].metadata["steps"] is not None

    def test_extract_empty_messages(self, mock_llm):
        extractor = ProceduralExtractor(mock_llm)
        result = extractor.extract([])
        assert result == []
        mock_llm.complete_json.assert_not_called()

    def test_extract_no_procedures(self, mock_llm, sample_messages):
        mock_llm.complete_json.return_value = {"procedures": []}
        extractor = ProceduralExtractor(mock_llm)
        result = extractor.extract(sample_messages)
        assert result == []

    def test_extract_filters_invalid_names(self, mock_llm, sample_messages):
        mock_llm.complete_json.return_value = {
            "procedures": [
                {
                    "procedure": "valid-name",
                    "description": "Valid",
                    "content": "Content",
                    "confidence_score": 0.9,
                },
                {
                    "procedure": "Invalid Name",
                    "description": "Invalid",
                    "content": "Content",
                    "confidence_score": 0.9,
                },
                {
                    "procedure": "UPPERCASE",
                    "description": "Invalid",
                    "content": "Content",
                    "confidence_score": 0.9,
                },
            ]
        }
        extractor = ProceduralExtractor(mock_llm)
        result = extractor.extract(sample_messages)
        assert len(result) == 1
        assert result[0].metadata["procedure"] == "valid-name"

    def test_extract_filters_empty_content(self, mock_llm, sample_messages):
        mock_llm.complete_json.return_value = {
            "procedures": [
                {
                    "procedure": "has-content",
                    "description": "Valid",
                    "content": "Real content",
                    "confidence_score": 0.9,
                },
                {
                    "procedure": "no-content",
                    "description": "Invalid",
                    "content": "",
                    "confidence_score": 0.9,
                },
            ]
        }
        extractor = ProceduralExtractor(mock_llm)
        result = extractor.extract(sample_messages)
        assert len(result) == 1

    def test_extract_llm_failure(self, mock_llm, sample_messages):
        mock_llm.complete_json.side_effect = Exception("LLM error")
        extractor = ProceduralExtractor(mock_llm)
        result = extractor.extract(sample_messages)
        assert result == []

    def test_extraction_type(self, mock_llm):
        extractor = ProceduralExtractor(mock_llm)
        assert extractor.extraction_type == "procedural"

    def test_prompt_resolver(self, mock_llm, sample_messages):
        custom_prompt = "Custom procedural extraction prompt"
        resolver = MagicMock(return_value=custom_prompt)
        extractor = ProceduralExtractor(mock_llm, prompt_resolver=resolver)
        extractor.extract(sample_messages)
        resolver.assert_called_once()
        call_args = mock_llm.complete_json.call_args
        assert custom_prompt in call_args[1]["prompt"]

    def test_extract_preserves_tags(self, mock_llm, sample_messages):
        extractor = ProceduralExtractor(mock_llm)
        result = extractor.extract(sample_messages)
        assert result[0].metadata["tags"] == ["deployment"]


# ═══════════════════════════════════════════════════════════════════════════════
# Extraction ID Generation
# ═══════════════════════════════════════════════════════════════════════════════


class TestExtractionIdGeneration:
    """Tests for generate_procedural_extraction_id."""

    def test_deterministic(self):
        id1 = generate_procedural_extraction_id("snap_1", "deploy-app")
        id2 = generate_procedural_extraction_id("snap_1", "deploy-app")
        assert id1 == id2

    def test_different_inputs(self):
        id1 = generate_procedural_extraction_id("snap_1", "deploy-app")
        id2 = generate_procedural_extraction_id("snap_2", "deploy-app")
        id3 = generate_procedural_extraction_id("snap_1", "review-code")
        assert id1 != id2
        assert id1 != id3

    def test_idempotency_key(self):
        id1 = generate_procedural_extraction_id("snap_1", "deploy-app")
        id2 = generate_procedural_extraction_id("snap_1", "deploy-app", "key_1")
        assert id1 != id2


# ═══════════════════════════════════════════════════════════════════════════════
# ProceduralPipeline
# ═══════════════════════════════════════════════════════════════════════════════


class TestProceduralPipeline:
    """Tests for ProceduralPipeline."""

    @pytest.fixture
    def mock_extractor(self):
        extractor = MagicMock()
        extractor.extract.return_value = [
            ExtractedItem(
                content="# Deploy\n\nStep-by-step deployment",
                citations=[0],
                confidence=0.9,
                metadata={
                    "extraction_type": "procedural",
                    "procedure": "deploy-app",
                    "description": "Deploy to production",
                },
            )
        ]
        return extractor

    @pytest.fixture
    def mock_consolidator(self):
        from mongomem_core.extraction.types import (
            ConsolidationDecision,
            ScoredExtraction,
        )

        consolidator = MagicMock()
        extraction = ScoredExtraction(
            content="# Deploy\n\nStep-by-step deployment",
            citations=[0],
            confidence=0.9,
            citation_score=1.0,
            combined_score=0.96,
            is_valid=True,
            embedding=[0.1, 0.2, 0.3],
            metadata={
                "procedure": "deploy-app",
                "description": "Deploy to production",
            },
        )
        consolidator.process.return_value = [
            ConsolidationDecision(
                extraction=extraction,
                action="ADD",
                reason="new procedure",
            )
        ]
        return consolidator

    @pytest.fixture
    def mock_db(self):
        return MagicMock()

    @pytest.fixture
    def config(self):
        return ProceduralExtractionConfig()

    @pytest.fixture
    def sample_messages(self):
        return [
            {"role": "user", "content": "Here's how to deploy the app."},
        ]

    def test_run_basic(self, mock_extractor, mock_consolidator, mock_db, config, sample_messages):
        with patch("mongomem_core.extraction.procedural.apply_procedural_decisions") as mock_apply:
            from mongomem_core.extraction.types import (
                PersistenceResult,
            )

            mock_apply.return_value = PersistenceResult(
                added=1,
                created_ids=["id1"],
            )

            pipeline = ProceduralPipeline(
                extractor=mock_extractor,
                config=config,
                consolidator=mock_consolidator,
                db=mock_db,
                embedding_model_id="voyage-3",
            )

            result = pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

            assert result.success is True
            assert result.extracted_count == 1
            assert result.stored_count == 1
            assert "id1" in result.created_ids

    def test_run_disabled(self, mock_extractor, mock_consolidator, mock_db, sample_messages):
        config = ProceduralExtractionConfig(enabled=False)

        pipeline = ProceduralPipeline(
            extractor=mock_extractor,
            config=config,
            consolidator=mock_consolidator,
            db=mock_db,
            embedding_model_id="voyage-3",
        )

        result = pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

        assert result.success is True
        assert result.extracted_count == 0
        mock_extractor.extract.assert_not_called()

    def test_run_no_extractions(self, mock_consolidator, mock_db, config, sample_messages):
        mock_extractor = MagicMock()
        mock_extractor.extract.return_value = []

        pipeline = ProceduralPipeline(
            extractor=mock_extractor,
            config=config,
            consolidator=mock_consolidator,
            db=mock_db,
            embedding_model_id="voyage-3",
        )

        result = pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

        assert result.success is True
        assert result.extracted_count == 0
        mock_consolidator.process.assert_not_called()

    def test_run_error_handling(
        self, mock_extractor, mock_consolidator, mock_db, config, sample_messages
    ):
        mock_extractor.extract.side_effect = Exception("Extraction error")

        pipeline = ProceduralPipeline(
            extractor=mock_extractor,
            config=config,
            consolidator=mock_consolidator,
            db=mock_db,
            embedding_model_id="voyage-3",
        )

        result = pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

        assert result.success is False
        assert len(result.errors) == 1
        assert "Extraction error" in result.errors[0]

    def test_run_limits_extractions(self, mock_consolidator, mock_db, sample_messages):
        mock_extractor = MagicMock()
        mock_extractor.extract.return_value = [
            ExtractedItem(
                content=f"Procedure {i}",
                citations=[0],
                confidence=0.9,
                metadata={
                    "procedure": f"proc-{i}",
                    "description": f"Procedure {i}",
                },
            )
            for i in range(10)
        ]
        config = ProceduralExtractionConfig(max_procedures_per_snapshot=5)

        with patch("mongomem_core.extraction.procedural.enrich_citations"):
            with patch("mongomem_core.extraction.procedural.score_batch") as mock_score:
                mock_score.return_value = []

                pipeline = ProceduralPipeline(
                    extractor=mock_extractor,
                    config=config,
                    consolidator=mock_consolidator,
                    db=mock_db,
                    embedding_model_id="voyage-3",
                )

                pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

                call_args = mock_score.call_args
                assert len(call_args[0][0]) == 5

    def test_run_tracks_processing_time(
        self, mock_extractor, mock_consolidator, mock_db, config, sample_messages
    ):
        with patch("mongomem_core.extraction.procedural.apply_procedural_decisions") as mock_apply:
            from mongomem_core.extraction.types import (
                PersistenceResult,
            )

            mock_apply.return_value = PersistenceResult(added=1, created_ids=["id1"])

            pipeline = ProceduralPipeline(
                extractor=mock_extractor,
                config=config,
                consolidator=mock_consolidator,
                db=mock_db,
                embedding_model_id="voyage-3",
            )

            result = pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

            assert result.metadata is not None
            assert result.metadata.processing_time_ms >= 0
            assert result.metadata.extraction_timestamp is not None

    def test_sample_extractions(
        self, mock_extractor, mock_consolidator, mock_db, config, sample_messages
    ):
        with patch("mongomem_core.extraction.procedural.apply_procedural_decisions") as mock_apply:
            from mongomem_core.extraction.types import (
                PersistenceResult,
            )

            mock_apply.return_value = PersistenceResult(added=1, created_ids=["id1"])

            pipeline = ProceduralPipeline(
                extractor=mock_extractor,
                config=config,
                consolidator=mock_consolidator,
                db=mock_db,
                embedding_model_id="voyage-3",
            )

            result = pipeline.run(sample_messages, "org1", "user1", "snapshot_123")

            assert len(result.sample_extractions) == 1
            assert "procedure" in result.sample_extractions[0]
            assert result.sample_extractions[0]["procedure"] == "deploy-app"


# ═══════════════════════════════════════════════════════════════════════════════
# create_procedural_pipeline factory
# ═══════════════════════════════════════════════════════════════════════════════


class TestCreateProceduralPipeline:
    """Tests for create_procedural_pipeline factory."""

    def test_creates_pipeline(self):
        mock_llm = MagicMock()
        mock_embedder = MagicMock()
        mock_embedder.model_id = "voyage-3"
        mock_db = MagicMock()

        pipeline = create_procedural_pipeline(
            db=mock_db,
            llm=mock_llm,
            embedder=mock_embedder,
        )

        assert isinstance(pipeline, ProceduralPipeline)
        assert pipeline.config.enabled is True

    def test_creates_with_custom_config(self):
        mock_llm = MagicMock()
        mock_embedder = MagicMock()
        mock_embedder.model_id = "voyage-3"
        mock_db = MagicMock()

        config = ProceduralExtractionConfig(
            enabled=True,
            max_procedures_per_snapshot=10,
        )

        pipeline = create_procedural_pipeline(
            db=mock_db,
            llm=mock_llm,
            embedder=mock_embedder,
            config=config,
        )

        assert pipeline.config.max_procedures_per_snapshot == 10

    def test_creates_with_rule_based_consolidation(self):
        mock_llm = MagicMock()
        mock_embedder = MagicMock()
        mock_embedder.model_id = "voyage-3"
        mock_db = MagicMock()

        pipeline = create_procedural_pipeline(
            db=mock_db,
            llm=mock_llm,
            embedder=mock_embedder,
            use_llm_consolidation=False,
        )

        assert isinstance(pipeline, ProceduralPipeline)


# ═══════════════════════════════════════════════════════════════════════════════
# Reinforcement-Aware Ranking
# ═══════════════════════════════════════════════════════════════════════════════


class TestReinforcementImportance:
    """Tests for reinforcement-aware importance in MemoryChunk."""

    def test_no_reinforcement_returns_none(self):
        from mongomem_core.models.retrieval import (
            MemoryChunk,
        )

        mock_obj = MagicMock()
        mock_obj.reinforcement_count = 0
        mock_obj.last_reinforced_at = None

        result = MemoryChunk._compute_reinforcement_importance(mock_obj)
        assert result is None

    def test_reinforcement_count_only(self):
        from mongomem_core.models.retrieval import (
            MemoryChunk,
        )

        mock_obj = MagicMock()
        mock_obj.reinforcement_count = 10
        mock_obj.last_reinforced_at = None

        result = MemoryChunk._compute_reinforcement_importance(mock_obj)
        assert result is not None
        assert 0 < result <= 1.0

    def test_high_reinforcement_high_importance(self):
        from mongomem_core.models.retrieval import (
            MemoryChunk,
        )

        mock_obj_low = MagicMock()
        mock_obj_low.reinforcement_count = 1
        mock_obj_low.last_reinforced_at = datetime.now(timezone.utc)

        mock_obj_high = MagicMock()
        mock_obj_high.reinforcement_count = 50
        mock_obj_high.last_reinforced_at = datetime.now(timezone.utc)

        low = MemoryChunk._compute_reinforcement_importance(mock_obj_low)
        high = MemoryChunk._compute_reinforcement_importance(mock_obj_high)

        assert low is not None
        assert high is not None
        assert high > low

    def test_recency_decay(self):
        from mongomem_core.models.retrieval import (
            MemoryChunk,
        )

        mock_recent = MagicMock()
        mock_recent.reinforcement_count = 10
        mock_recent.last_reinforced_at = datetime.now(timezone.utc)

        mock_old = MagicMock()
        mock_old.reinforcement_count = 10
        mock_old.last_reinforced_at = datetime.now(timezone.utc) - timedelta(days=30)

        recent = MemoryChunk._compute_reinforcement_importance(mock_recent)
        old = MemoryChunk._compute_reinforcement_importance(mock_old)

        assert recent is not None
        assert old is not None
        assert recent > old

    def test_from_semantic_includes_importance(self):
        from mongomem_core.models.retrieval import (
            MemoryChunk,
        )

        mock_semantic = MagicMock()
        mock_semantic.id = "test-id"
        mock_semantic.content = "Test content"
        mock_semantic.label = "test"
        mock_semantic.version = 1
        mock_semantic.is_latest = True
        mock_semantic.org_id = "org_1"
        mock_semantic.timestamp = datetime.now(timezone.utc)
        mock_semantic.source = None
        mock_semantic.contextual_metadata = None
        mock_semantic.agent_id = None
        mock_semantic.extraction_source = None
        mock_semantic.memory_lineage_id = None
        mock_semantic.reinforcement_count = 25
        mock_semantic.last_reinforced_at = datetime.now(timezone.utc)

        mock_semantic.embedding = None
        mock_semantic.score = 0.9

        def embedding_present():
            return False

        mock_semantic.embedding_present = embedding_present

        chunk = MemoryChunk.from_semantic(mock_semantic)
        assert chunk.metadata is not None
        assert "importance" in chunk.metadata
        assert chunk.metadata["importance"] > 0

    def test_from_procedural_includes_importance(self):
        from mongomem_core.models.retrieval import (
            MemoryChunk,
        )

        mock_proc = MagicMock()
        mock_proc.id = "test-id"
        mock_proc.content = "Procedure content"
        mock_proc.procedure = "test-proc"
        mock_proc.description = "Test"
        mock_proc.version = 1
        mock_proc.is_latest = True
        mock_proc.org_id = "org_1"
        mock_proc.timestamp = datetime.now(timezone.utc)
        mock_proc.tags = None
        mock_proc.allowed_tools = None
        mock_proc.trigger_conditions = None
        mock_proc.agent_id = None
        mock_proc.extraction_source = None
        mock_proc.memory_lineage_id = None
        mock_proc.steps = None
        mock_proc.content_token_count = None
        mock_proc.reinforcement_count = 10
        mock_proc.last_reinforced_at = datetime.now(timezone.utc)

        mock_proc.embedding = None
        mock_proc.score = 0.85

        def embedding_present():
            return False

        mock_proc.embedding_present = embedding_present

        chunk = MemoryChunk.from_procedural(mock_proc)
        assert chunk.metadata is not None
        assert "importance" in chunk.metadata
        assert chunk.metadata["importance"] > 0

    def test_no_reinforcement_no_importance_key(self):
        from mongomem_core.models.retrieval import (
            MemoryChunk,
        )

        mock_proc = MagicMock()
        mock_proc.id = "test-id"
        mock_proc.content = "Procedure content"
        mock_proc.procedure = "test-proc"
        mock_proc.description = "Test"
        mock_proc.version = 1
        mock_proc.is_latest = True
        mock_proc.org_id = "org_1"
        mock_proc.timestamp = datetime.now(timezone.utc)
        mock_proc.tags = None
        mock_proc.allowed_tools = None
        mock_proc.trigger_conditions = None
        mock_proc.agent_id = None
        mock_proc.extraction_source = None
        mock_proc.memory_lineage_id = None
        mock_proc.steps = None
        mock_proc.content_token_count = None
        mock_proc.reinforcement_count = 0
        mock_proc.last_reinforced_at = None
        mock_proc.embedding = None
        mock_proc.score = None

        def embedding_present():
            return False

        mock_proc.embedding_present = embedding_present

        chunk = MemoryChunk.from_procedural(mock_proc)
        assert chunk.metadata is not None
        assert "importance" not in chunk.metadata

    def test_fifty_reinforcements_today_near_one(self):
        from mongomem_core.models.retrieval import (
            MemoryChunk,
        )

        mock_obj = MagicMock()
        mock_obj.reinforcement_count = 50
        mock_obj.last_reinforced_at = datetime.now(timezone.utc)

        result = MemoryChunk._compute_reinforcement_importance(mock_obj)
        assert result is not None
        assert result > 0.95

    def test_one_reinforcement_low_importance(self):
        from mongomem_core.models.retrieval import (
            MemoryChunk,
        )

        mock_obj = MagicMock()
        mock_obj.reinforcement_count = 1
        mock_obj.last_reinforced_at = datetime.now(timezone.utc)

        result = MemoryChunk._compute_reinforcement_importance(mock_obj)
        assert result is not None
        # log1p(1) / log1p(50) ≈ 0.177
        assert result < 0.25


# ═══════════════════════════════════════════════════════════════════════════════
# Discovery Mode
# ═══════════════════════════════════════════════════════════════════════════════


class TestDiscoveryMode:
    """Tests for return_format='discovery' in search_procedural."""

    def test_discovery_projection_excludes_content(self):
        """Verify that the discovery projection doesn't include content/steps/resources."""
        from mongomem_core.memory.procedural import (
            search_procedural,
        )

        mock_db = MagicMock()
        mock_col = MagicMock()
        mock_col.aggregate.return_value = [
            {
                "_id": "abc123",
                "procedure": "deploy-app",
                "description": "Deploy to prod",
                "version": 1,
                "memory_lineage_id": "abc123",
                "reinforcement_count": 5,
                "tags": ["deploy"],
                "score": 0.95,
            }
        ]
        mock_db.__getitem__ = MagicMock(return_value=mock_col)

        with patch("mongomem_core.memory.procedural.get_collection", return_value=mock_col):
            with patch(
                "mongomem_core.memory.procedural.execute_vector_search",
                return_value=[
                    {
                        "_id": "abc123",
                        "procedure": "deploy-app",
                        "description": "Deploy to prod",
                        "version": 1,
                        "memory_lineage_id": "abc123",
                        "reinforcement_count": 5,
                        "tags": ["deploy"],
                        "score": 0.95,
                    }
                ],
            ):
                results = search_procedural(
                    db=mock_db,
                    query_embedding=[0.1] * 1024,
                    org_id="org_1",
                    return_format="discovery",
                )

                assert len(results) == 1
                result = results[0]
                assert result["procedure"] == "deploy-app"
                assert result["description"] == "Deploy to prod"
                assert result["score"] == 0.95
                assert result["reinforcement_count"] == 5
                assert "content" not in result
                assert "steps" not in result
                assert "text" not in result
