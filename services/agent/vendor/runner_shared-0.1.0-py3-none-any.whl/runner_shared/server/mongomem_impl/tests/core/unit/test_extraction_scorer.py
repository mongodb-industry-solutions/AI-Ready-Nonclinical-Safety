"""Unit tests for extraction scorer module (pure functions)."""

import pytest
from mongomem_core.extraction.config import (
    SemanticExtractionConfig,
)
from mongomem_core.extraction.scorer import (
    calculate_combined_score,
    filter_valid,
    score_batch,
    score_extraction,
)
from mongomem_core.extraction.types import (
    ExtractedItem,
    ScoredExtraction,
)


class TestScoreExtraction:
    """Tests for score_extraction function."""

    @pytest.fixture
    def default_config(self):
        """Default scoring configuration."""
        return SemanticExtractionConfig()

    def test_empty_content_is_invalid(self, default_config):
        """Test that empty content results in invalid extraction."""
        item = ExtractedItem(content="", confidence=0.9)
        scored = score_extraction(item, default_config)

        assert scored.is_valid is False
        assert scored.combined_score == 0.0
        assert "validation_error" in scored.metadata

    def test_whitespace_only_is_invalid(self, default_config):
        """Test that whitespace-only content is invalid."""
        item = ExtractedItem(content="   \n\t  ", confidence=0.9)
        scored = score_extraction(item, default_config)

        assert scored.is_valid is False

    def test_with_citations_high_confidence(self, default_config):
        """Test scoring with citations and high confidence."""
        item = ExtractedItem(
            content="The user is a Data Scientist",
            citations=[0],
            confidence=0.95,
        )
        scored = score_extraction(item, default_config)

        # citation_score = 1.0 (has citations)
        # combined = 1.0 * 0.6 + 0.95 * 0.4 = 0.6 + 0.38 = 0.98
        assert scored.is_valid is True
        assert scored.citation_score == 1.0
        assert scored.confidence == 0.95
        assert abs(scored.combined_score - 0.98) < 0.01

    def test_without_citations_high_confidence(self, default_config):
        """Test scoring without citations but high confidence."""
        item = ExtractedItem(
            content="Some fact without citation",
            citations=[],
            confidence=0.9,
        )
        scored = score_extraction(item, default_config)

        # citation_score = 0.0 (no citations)
        # combined = 0.0 * 0.6 + 0.9 * 0.4 = 0.36
        assert scored.citation_score == 0.0
        assert abs(scored.combined_score - 0.36) < 0.01
        # 0.36 < 0.5 threshold, so invalid
        assert scored.is_valid is False

    def test_confidence_clamping(self, default_config):
        """Test that confidence is clamped to [0, 1]."""
        item = ExtractedItem(
            content="Some fact",
            citations=[0],
            confidence=1.5,  # Over 1.0
        )
        scored = score_extraction(item, default_config)

        assert scored.confidence == 1.0  # Clamped

        item2 = ExtractedItem(
            content="Some fact",
            citations=[0],
            confidence=-0.5,  # Under 0.0
        )
        scored2 = score_extraction(item2, default_config)

        assert scored2.confidence == 0.0  # Clamped

    def test_custom_weights(self):
        """Test scoring with custom weights."""
        config = SemanticExtractionConfig(
            citation_weight=0.3,
            confidence_weight=0.7,
        )
        item = ExtractedItem(
            content="Some fact",
            citations=[0],
            confidence=0.8,
        )
        scored = score_extraction(item, config)

        # combined = 1.0 * 0.3 + 0.8 * 0.7 = 0.3 + 0.56 = 0.86
        assert abs(scored.combined_score - 0.86) < 0.01

    def test_custom_threshold(self):
        """Test scoring with custom threshold."""
        config = SemanticExtractionConfig(
            min_combined_score_threshold=0.8,
        )
        item = ExtractedItem(
            content="Some fact",
            citations=[0],
            confidence=0.5,  # combined = 0.6 + 0.2 = 0.8
        )
        scored = score_extraction(item, config)

        # Exactly at threshold should pass
        assert scored.is_valid is True

    def test_metadata_preserved(self, default_config):
        """Test that input metadata is preserved in output."""
        item = ExtractedItem(
            content="Some fact",
            citations=[0],
            confidence=0.9,
            metadata={"source": "test", "index": 1},
        )
        scored = score_extraction(item, default_config)

        assert scored.metadata["source"] == "test"
        assert scored.metadata["index"] == 1
        assert "llm_confidence_score" in scored.metadata

    def test_cited_text_preserved(self, default_config):
        """Test that cited_text is preserved."""
        cited = [{"cited_idx": 0, "cited_text": {"role": "user", "content": "test"}}]
        item = ExtractedItem(
            content="Some fact",
            citations=[0],
            confidence=0.9,
            cited_text=cited,
        )
        scored = score_extraction(item, default_config)

        assert scored.cited_text == cited


class TestScoreBatch:
    """Tests for score_batch function."""

    def test_empty_list(self):
        """Test scoring empty list."""
        config = SemanticExtractionConfig()
        result = score_batch([], config)
        assert result == []

    def test_multiple_items(self):
        """Test scoring multiple items."""
        config = SemanticExtractionConfig()
        items = [
            ExtractedItem(content="Fact 1", citations=[0], confidence=0.9),
            ExtractedItem(content="Fact 2", citations=[], confidence=0.3),
            ExtractedItem(content="", confidence=0.9),  # Invalid
        ]

        results = score_batch(items, config)

        assert len(results) == 3
        assert results[0].is_valid is True
        assert results[1].is_valid is False  # Low score
        assert results[2].is_valid is False  # Empty content


class TestFilterValid:
    """Tests for filter_valid function."""

    def test_empty_list(self):
        """Test filtering empty list."""
        result = filter_valid([])
        assert result == []

    def test_all_valid(self):
        """Test filtering when all are valid."""
        items = [
            ScoredExtraction(
                content=f"Fact {i}",
                citations=[0],
                confidence=0.9,
                citation_score=1.0,
                combined_score=0.96,
                is_valid=True,
            )
            for i in range(3)
        ]

        result = filter_valid(items)
        assert len(result) == 3

    def test_all_invalid(self):
        """Test filtering when all are invalid."""
        items = [
            ScoredExtraction(
                content="",
                citations=[],
                confidence=0.1,
                citation_score=0.0,
                combined_score=0.04,
                is_valid=False,
            )
            for _ in range(3)
        ]

        result = filter_valid(items)
        assert result == []

    def test_mixed(self):
        """Test filtering mixed valid/invalid items."""
        items = [
            ScoredExtraction(
                content="Valid 1",
                citations=[0],
                confidence=0.9,
                citation_score=1.0,
                combined_score=0.96,
                is_valid=True,
            ),
            ScoredExtraction(
                content="Invalid",
                citations=[],
                confidence=0.1,
                citation_score=0.0,
                combined_score=0.04,
                is_valid=False,
            ),
            ScoredExtraction(
                content="Valid 2",
                citations=[1],
                confidence=0.8,
                citation_score=1.0,
                combined_score=0.92,
                is_valid=True,
            ),
        ]

        result = filter_valid(items)
        assert len(result) == 2
        assert all(r.is_valid for r in result)


class TestCalculateCombinedScore:
    """Tests for calculate_combined_score function."""

    def test_default_weights(self):
        """Test with default weights."""
        score = calculate_combined_score(
            citation_score=1.0,
            confidence_score=0.9,
        )
        # 1.0 * 0.6 + 0.9 * 0.4 = 0.96
        assert abs(score - 0.96) < 0.01

    def test_custom_weights(self):
        """Test with custom weights."""
        score = calculate_combined_score(
            citation_score=1.0,
            confidence_score=0.8,
            citation_weight=0.5,
            confidence_weight=0.5,
        )
        # 1.0 * 0.5 + 0.8 * 0.5 = 0.9
        assert abs(score - 0.9) < 0.01

    def test_zero_citation(self):
        """Test with zero citation score."""
        score = calculate_combined_score(
            citation_score=0.0,
            confidence_score=1.0,
        )
        # 0.0 * 0.6 + 1.0 * 0.4 = 0.4
        assert abs(score - 0.4) < 0.01
