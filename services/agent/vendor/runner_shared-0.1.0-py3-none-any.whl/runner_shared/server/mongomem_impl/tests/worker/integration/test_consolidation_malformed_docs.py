"""
Integration tests for DLQ behaviour when STM docs fail SnapshotMessage schema validation.

Invalid docs are:
- Excluded from the snapshot
- Marked promoted=True with a promotion_error field (so the scanner doesn't re-enqueue)
Valid docs are promoted and included in the snapshot as normal.

Requirements:
  - Local MongoDB at TEST_MONGO_URI (default: mongodb://localhost:27017)
  - No real LLM or embedder needed — MockLLM and MockEmbedder are used
"""

from __future__ import annotations

import os

import pytest
from mongomem_core import MemoryEngine
from mongomem_core.config import Settings
from mongomem_core.models.config.snapshot_config import (
    SnapshotConfig,
)
from pymongo import MongoClient

from runner_shared.server.mongomem_impl.src.mongomem_worker.config import WorkerSettings
from runner_shared.server.mongomem_impl.src.mongomem_worker.queue import enqueue_task

from ..conftest import MockEmbedder, MockLLM, random_db_name

TEST_MONGO_URI = os.environ.get("TEST_MONGO_URI", "mongodb://localhost:27017")

_MAX_DRAIN = 50


async def _drain(worker, max_iterations: int = _MAX_DRAIN) -> int:
    """Drain the task queue synchronously — mirrors POST /api/v1/worker/processTasks."""
    total = 0
    for _ in range(max_iterations):
        processed = await worker.process_batch()
        if processed == 0:
            break
        total += processed
    return total


class TestSTMDLQOnSchemaFailure:
    """
    Tests for the DLQ behaviour when STM docs fail SnapshotMessage schema validation.

    Invalid docs are:
    - Excluded from the snapshot
    - Marked promoted=True with a promotion_error field (so the scanner doesn't re-enqueue)
    Valid docs are promoted and included in the snapshot as normal.
    """

    def setup_method(self):
        self.db_name = random_db_name()
        self.client = MongoClient(TEST_MONGO_URI)
        self.db = self.client[self.db_name]

    def teardown_method(self):
        self.client.drop_database(self.db_name)
        self.client.close()

    def _seed_stm_docs(self, session_id: str, org_id: str, user_id: str, docs: list) -> list:
        """Insert pre-built STM docs directly."""
        if docs:
            self.db.memory_short_term.insert_many(docs)
        return docs

    def _make_valid_doc(self, session_id, org_id, user_id, turn_seq, role="user", content=None):
        from datetime import datetime, timezone

        from bson import ObjectId

        return {
            "_id": ObjectId(),
            "session_id": session_id,
            "org_id": org_id,
            "user_id": user_id,
            "role": role,
            "content": content or f"Message {turn_seq}",
            "visibility": "private",
            "promoted": False,
            "turn_seq": turn_seq,
            "timestamp": datetime.now(timezone.utc),
        }

    def _make_invalid_doc(self, session_id, org_id, user_id, turn_seq):
        """STM doc with an invalid role value — fails SnapshotMessage validation."""
        from datetime import datetime, timezone

        from bson import ObjectId

        return {
            "_id": ObjectId(),
            "session_id": session_id,
            "org_id": org_id,
            "user_id": user_id,
            "role": "invalid_role",  # not in MessageRole enum
            "content": "This doc has a bad role",
            "visibility": "private",
            "promoted": False,
            "turn_seq": turn_seq,
            "timestamp": datetime.now(timezone.utc),
        }

    def _make_engine_and_worker(self):
        embedder = MockEmbedder()
        llm = MockLLM()
        llm.set_json_response("", {"memories": [], "events": []})

        settings = Settings(
            mongo_uri=TEST_MONGO_URI,
            db_name=self.db_name,
            embedding_dimension=embedder.dimension,
        )
        engine = MemoryEngine(settings, embedder=embedder, llm=llm)
        engine.bootstrap(ensure_search_indexes=False)

        os.environ["MONGOMEM_WORKER_ENABLE_CHANGE_STREAMS"] = "false"

        from runner_shared.server.mongomem_impl.src.mongomem_worker.worker import MongoMemWorker

        worker = MongoMemWorker(
            engine=engine,
            scaling_mode="distributed",
            auto_extract_on_snapshot=True,
            snapshot_config=SnapshotConfig(
                strategy="auto",
                embedding_strategy="generate",
                max_messages=5,
                delete_promoted=False,
            ),
            extraction_config={
                "semantic": {"enabled": True},
                "episodic": {"enabled": True},
            },
        )
        worker.initialize()
        return worker

    @pytest.mark.asyncio
    async def test_one_invalid_doc_is_dlqd_valid_docs_promoted_normally(self):
        """
        Session has 4 valid docs + 1 doc with invalid role (above max_messages=5).
        Expected: snapshot created with 4 messages, invalid doc marked promoted
        with promotion_error, 4 valid docs marked promoted without promotion_error.
        """
        session_id = "dlq-session-001"
        org_id = "test-org"
        user_id = "test-user"

        docs = [self._make_valid_doc(session_id, org_id, user_id, i) for i in range(4)]
        docs.append(self._make_invalid_doc(session_id, org_id, user_id, turn_seq=4))
        self._seed_stm_docs(session_id, org_id, user_id, docs)

        worker = self._make_engine_and_worker()
        settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=self.db_name)
        enqueue_task(
            "snapshot",
            {
                "snapshot_task_type": "check_promotion",
                "session_id": session_id,
                "org_id": org_id,
                "user_id": user_id,
                "reason": "message_count",
            },
            settings=settings,
        )

        total = await _drain(worker)
        assert total >= 1

        # Snapshot created with only the 4 valid messages
        snapshot = self.db.memory_snapshot.find_one({"session_id": session_id, "org_id": org_id})
        assert snapshot is not None, "Snapshot should be created from valid docs"
        assert len(snapshot.get("messages", [])) == 4, (
            f"Expected 4 messages in snapshot, got {len(snapshot.get('messages', []))}"
        )

        # Invalid doc is marked promoted=True with promotion_error
        invalid_doc_id = docs[4]["_id"]
        invalid_in_db = self.db.memory_short_term.find_one({"_id": invalid_doc_id})
        assert invalid_in_db is not None
        assert invalid_in_db.get("promoted") is True
        assert invalid_in_db.get("promotion_error") is not None, (
            "Invalid doc should have promotion_error set"
        )

        # Valid docs are marked promoted=True without promotion_error
        valid_ids = [d["_id"] for d in docs[:4]]
        valid_in_db = list(self.db.memory_short_term.find({"_id": {"$in": valid_ids}}))
        for doc in valid_in_db:
            assert doc.get("promoted") is True
            assert doc.get("promotion_error") is None, (
                f"Valid doc {doc['_id']} should not have promotion_error"
            )

    @pytest.mark.asyncio
    async def test_all_invalid_docs_no_snapshot_all_dlqd(self):
        """
        All 5 docs have invalid role. No snapshot should be created.
        All docs should be marked promoted=True with promotion_error.
        """
        session_id = "dlq-session-002"
        org_id = "test-org"
        user_id = "test-user"

        docs = [self._make_invalid_doc(session_id, org_id, user_id, turn_seq=i) for i in range(5)]
        self._seed_stm_docs(session_id, org_id, user_id, docs)

        worker = self._make_engine_and_worker()
        settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=self.db_name)
        enqueue_task(
            "snapshot",
            {
                "snapshot_task_type": "check_promotion",
                "session_id": session_id,
                "org_id": org_id,
                "user_id": user_id,
                "reason": "message_count",
            },
            settings=settings,
        )

        total = await _drain(worker)
        assert total >= 1

        # No snapshot created
        snapshot = self.db.memory_snapshot.find_one({"session_id": session_id, "org_id": org_id})
        assert snapshot is None, "No snapshot should be created when all docs are invalid"

        # All docs marked promoted=True with promotion_error
        all_in_db = list(self.db.memory_short_term.find({"session_id": session_id}))
        assert len(all_in_db) == 5
        for doc in all_in_db:
            assert doc.get("promoted") is True, f"Doc {doc['_id']} should be marked promoted"
            assert doc.get("promotion_error") is not None, (
                f"Doc {doc['_id']} should have promotion_error"
            )

    @pytest.mark.asyncio
    async def test_dlqd_docs_not_re_promoted_on_rescan(self):
        """
        After DLQ, all docs are promoted=True. A direct call to promote_stm_to_snapshot
        (simulating OE rescan) should find no unpromoted docs and be a no-op.
        """
        from mongomem_core.pipelines.stm_to_snapshot import (
            promote_stm_to_snapshot,
        )
        from pymongo import MongoClient as _MC

        session_id = "dlq-session-003"
        org_id = "test-org"
        user_id = "test-user"
        project_id = "test-project"

        # Seed 4 valid + 1 invalid (above threshold)
        docs = [self._make_valid_doc(session_id, org_id, user_id, i) for i in range(4)]
        docs.append(self._make_invalid_doc(session_id, org_id, user_id, turn_seq=4))
        self._seed_stm_docs(session_id, org_id, user_id, docs)

        worker = self._make_engine_and_worker()
        settings = WorkerSettings(mongo_uri=TEST_MONGO_URI, db_name=self.db_name)

        # First promotion
        enqueue_task(
            "snapshot",
            {
                "snapshot_task_type": "check_promotion",
                "session_id": session_id,
                "org_id": org_id,
                "user_id": user_id,
                "reason": "message_count",
            },
            settings=settings,
        )
        await _drain(worker)

        assert self.db.memory_snapshot.count_documents({"session_id": session_id}) == 1

        # Simulate OE rescan via direct promote call — all docs already promoted
        db = _MC(TEST_MONGO_URI)[self.db_name]
        result = promote_stm_to_snapshot(
            db,
            session_id,
            org_id,
            user_id,
            project_id,
            config=SnapshotConfig(max_messages=5, delete_promoted=False),
            force=True,
        )

        assert result is None, "Second promotion attempt should be a no-op (all docs promoted)"
        assert self.db.memory_snapshot.count_documents({"session_id": session_id}) == 1, (
            "Snapshot count should remain 1 after second attempt"
        )
