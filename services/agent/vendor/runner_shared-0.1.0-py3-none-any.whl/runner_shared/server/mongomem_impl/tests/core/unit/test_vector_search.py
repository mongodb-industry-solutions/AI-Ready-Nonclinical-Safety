"""
Unit tests for vector search functions.

These tests are pure unit tests that mock all MongoDB interactions. They do NOT:
- Require a database connection
- Make any network calls
- Depend on external services

All database operations are mocked using unittest.mock to ensure fast, isolated testing.
"""

from contextlib import nullcontext
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest
from bson import ObjectId
from mongomem_core.exceptions import (
    DatabaseOperationError,
    ValidationError,
)
from mongomem_core.memory.base import (
    _is_index_not_ready_error,
    execute_vector_search,
    merge_rbac_and_metadata_filter,
)
from mongomem_core.memory.episodic import (
    vector_search_episodic,
)
from mongomem_core.memory.semantic import search_semantic
from mongomem_core.models.filters import FieldFilter, FilterOperator, MetadataFilter
from mongomem_core.models.memory.base import ChunkVisibility
from pymongo.errors import OperationFailure


class TestIsIndexNotReadyError:
    """Tests for _is_index_not_ready_error function."""

    def test_detects_error_code_171(self):
        """Detects index not ready via error code 171."""
        exc = OperationFailure("Some error", code=171)
        assert _is_index_not_ready_error(exc) is True

    def test_detects_error_code_172(self):
        """Detects index not ready via error code 172."""
        exc = OperationFailure("Some error", code=172)
        assert _is_index_not_ready_error(exc) is True

    def test_detects_not_started_state(self):
        """Detects 'not_started' state in error message."""
        exc = OperationFailure("cannot query vector index not_started", code=1)
        assert _is_index_not_ready_error(exc) is True

    def test_detects_building_state(self):
        """Detects 'building' state in error message."""
        exc = OperationFailure("vector index building", code=1)
        assert _is_index_not_ready_error(exc) is True

    def test_detects_paused_state(self):
        """Detects 'paused' state in error message."""
        exc = OperationFailure("index paused", code=1)
        assert _is_index_not_ready_error(exc) is True

    def test_detects_not_ready_state(self):
        """Detects 'not ready' state in error message."""
        exc = OperationFailure("vector index not ready", code=1)
        assert _is_index_not_ready_error(exc) is True

    def test_does_not_detect_other_errors(self):
        """Does not detect non-index errors."""
        exc = OperationFailure("connection timeout", code=1)
        assert _is_index_not_ready_error(exc) is False

    def test_case_insensitive_matching(self):
        """Error message matching is case insensitive."""
        exc = OperationFailure("CANNOT QUERY VECTOR INDEX NOT_STARTED", code=1)
        assert _is_index_not_ready_error(exc) is True


class TestExecuteVectorSearch:
    """Tests for execute_vector_search function."""

    def test_raises_validation_error_for_empty_embedding(self):
        """Raises ValidationError when query_embedding is empty."""
        mock_col = MagicMock()
        rbac_filter = {"org_id": "org_1"}

        with pytest.raises(ValidationError) as exc_info:
            execute_vector_search(
                mock_col,
                index_name="test_index",
                query_embedding=[],
                rbac_filter=rbac_filter,
                collection_name="test_collection",
                org_id="org_1",
            )

        assert "query_embedding cannot be empty" in str(exc_info.value)
        assert exc_info.value.details["field"] == "query_embedding"

    def test_raises_validation_error_for_dimension_mismatch(self):
        """Raises ValidationError when embedding dimension doesn't match expected."""
        mock_col = MagicMock()
        rbac_filter = {"org_id": "org_1"}
        query_embedding = [0.1, 0.2, 0.3]  # 3 dimensions

        with pytest.raises(ValidationError) as exc_info:
            execute_vector_search(
                mock_col,
                index_name="test_index",
                query_embedding=query_embedding,
                rbac_filter=rbac_filter,
                collection_name="test_collection",
                org_id="org_1",
                expected_dimension=1536,
            )

        assert "dimension mismatch" in str(exc_info.value)
        assert "expected 1536, got 3" in str(exc_info.value)
        assert exc_info.value.details["field"] == "query_embedding"
        assert exc_info.value.details["value"] == "3"

    def test_passes_validation_with_correct_dimension(self):
        """Passes validation when dimension matches expected."""
        mock_col = MagicMock()
        mock_col.aggregate.return_value = []
        rbac_filter = {"org_id": "org_1"}
        query_embedding = [0.1] * 1536  # 1536 dimensions

        result = execute_vector_search(
            mock_col,
            index_name="test_index",
            query_embedding=query_embedding,
            rbac_filter=rbac_filter,
            collection_name="test_collection",
            org_id="org_1",
            expected_dimension=1536,
        )

        assert result == []
        mock_col.aggregate.assert_called_once()

    @patch("mongomem_core.memory.base.time.sleep")
    def test_successful_vector_search(self, mock_sleep):
        """Successfully executes vector search and returns results."""
        mock_col = MagicMock()
        rbac_filter = {"org_id": "org_1", "user_id": "user_1"}
        query_embedding = [0.1, 0.2, 0.3]

        mock_results = [
            {"_id": ObjectId(), "score": 0.95, "content": "result 1"},
            {"_id": ObjectId(), "score": 0.85, "content": "result 2"},
        ]
        mock_col.aggregate.return_value = mock_results

        result = execute_vector_search(
            mock_col,
            index_name="test_index",
            query_embedding=query_embedding,
            rbac_filter=rbac_filter,
            collection_name="test_collection",
            org_id="org_1",
            top_k=10,
        )

        assert len(result) == 2
        assert result[0]["score"] == 0.95
        assert result[1]["score"] == 0.85
        mock_col.aggregate.assert_called_once()

        # Verify pipeline structure
        call_args = mock_col.aggregate.call_args[0][0]
        assert call_args[0]["$vectorSearch"]["index"] == "test_index"
        assert call_args[0]["$vectorSearch"]["queryVector"] == query_embedding
        assert call_args[0]["$vectorSearch"]["filter"] == rbac_filter
        assert call_args[0]["$vectorSearch"]["limit"] == 10
        assert call_args[1]["$project"]["embedding"] == 0  # Exclude embedding

    @patch("mongomem_core.memory.base.time.sleep")
    def test_applies_similarity_threshold(self, mock_sleep):
        """Applies similarity threshold filter when threshold > 0."""
        mock_col = MagicMock()
        rbac_filter = {"org_id": "org_1"}
        query_embedding = [0.1, 0.2, 0.3]

        mock_results = [
            {"_id": ObjectId(), "score": 0.95},
            {"_id": ObjectId(), "score": 0.75},
            {"_id": ObjectId(), "score": 0.50},
        ]
        mock_col.aggregate.return_value = mock_results

        execute_vector_search(
            mock_col,
            index_name="test_index",
            query_embedding=query_embedding,
            rbac_filter=rbac_filter,
            collection_name="test_collection",
            org_id="org_1",
            similarity_threshold=0.7,
        )

        # Verify pipeline includes $match stage
        call_args = mock_col.aggregate.call_args[0][0]
        assert len(call_args) == 3  # $vectorSearch, $project, $match
        assert call_args[2]["$match"]["score"]["$gte"] == 0.7

    @pytest.mark.skip(reason="Flaky in local environment - sleep mock captures unrelated calls")
    @patch("mongomem_core.memory.base.time.sleep")
    @patch("mongomem_core.memory.base.handle_db_error")
    def test_retries_on_index_not_ready_error(self, mock_handle_db_error, mock_sleep):
        """Retries when index is not ready, then succeeds."""
        # Mock handle_db_error to pass through errors so retry logic can catch them
        mock_handle_db_error.return_value = nullcontext()

        mock_col = MagicMock()
        rbac_filter = {"org_id": "org_1"}
        query_embedding = [0.1, 0.2, 0.3]

        # First call fails with index not ready, second succeeds
        not_ready_error = OperationFailure("cannot query vector index not_started", code=171)
        mock_results = [{"_id": ObjectId(), "score": 0.95}]

        mock_col.aggregate.side_effect = [not_ready_error, mock_results]

        result = execute_vector_search(
            mock_col,
            index_name="test_index",
            query_embedding=query_embedding,
            rbac_filter=rbac_filter,
            collection_name="test_collection",
            org_id="org_1",
            max_retries=2,
            base_delay=0.01,  # Fast delay for testing
        )

        assert len(result) == 1
        assert mock_col.aggregate.call_count == 2
        assert mock_sleep.call_count == 1  # Should sleep once before retry

    @patch("mongomem_core.memory.base.time.sleep")
    @patch("mongomem_core.memory.base.handle_db_error")
    def test_raises_error_after_max_retries(self, mock_handle_db_error, mock_sleep):
        """Raises DatabaseOperationError after max retries exhausted."""
        # Mock handle_db_error to pass through errors so retry logic can catch them
        mock_handle_db_error.return_value = nullcontext()

        mock_col = MagicMock()
        rbac_filter = {"org_id": "org_1"}
        query_embedding = [0.1, 0.2, 0.3]

        not_ready_error = OperationFailure("cannot query vector index not_started", code=171)
        mock_col.aggregate.side_effect = not_ready_error

        with pytest.raises(DatabaseOperationError) as exc_info:
            execute_vector_search(
                mock_col,
                index_name="test_index",
                query_embedding=query_embedding,
                rbac_filter=rbac_filter,
                collection_name="test_collection",
                org_id="org_1",
                max_retries=2,
                base_delay=0.01,
            )

        assert "Vector index not ready after retries" in str(exc_info.value)
        assert mock_col.aggregate.call_count == 3  # Initial + 2 retries
        assert mock_sleep.call_count == 2  # Sleep before each retry

    @patch("mongomem_core.memory.base.time.sleep")
    @patch("mongomem_core.memory.base.handle_db_error")
    def test_raises_error_immediately_for_non_retryable_error(
        self, mock_handle_db_error, mock_sleep
    ):
        """Raises error immediately for non-retryable errors."""
        # Mock handle_db_error to pass through errors so retry logic can catch them
        mock_handle_db_error.return_value = nullcontext()

        mock_col = MagicMock()
        rbac_filter = {"org_id": "org_1"}
        query_embedding = [0.1, 0.2, 0.3]

        other_error = OperationFailure("connection timeout", code=1)
        mock_col.aggregate.side_effect = other_error

        with pytest.raises(OperationFailure):
            execute_vector_search(
                mock_col,
                index_name="test_index",
                query_embedding=query_embedding,
                rbac_filter=rbac_filter,
                collection_name="test_collection",
                org_id="org_1",
                max_retries=2,
            )

        assert mock_col.aggregate.call_count == 1  # No retries
        assert mock_sleep.call_count == 0  # No sleep

    @patch("mongomem_core.memory.base.time.sleep")
    def test_calculates_num_candidates_correctly(self, mock_sleep):
        """Calculates numCandidates as max(top_k * 2, 50)."""
        mock_col = MagicMock()
        rbac_filter = {"org_id": "org_1"}
        query_embedding = [0.1, 0.2, 0.3]
        mock_col.aggregate.return_value = []

        # Test with top_k < 25 (should use 50)
        execute_vector_search(
            mock_col,
            index_name="test_index",
            query_embedding=query_embedding,
            rbac_filter=rbac_filter,
            collection_name="test_collection",
            org_id="org_1",
            top_k=10,
        )

        call_args = mock_col.aggregate.call_args[0][0]
        assert call_args[0]["$vectorSearch"]["numCandidates"] == 50

        # Test with top_k > 25 (should use top_k * 2)
        mock_col.aggregate.reset_mock()
        execute_vector_search(
            mock_col,
            index_name="test_index",
            query_embedding=query_embedding,
            rbac_filter=rbac_filter,
            collection_name="test_collection",
            org_id="org_1",
            top_k=30,
        )

        call_args = mock_col.aggregate.call_args[0][0]
        assert call_args[0]["$vectorSearch"]["numCandidates"] == 60

    @patch("mongomem_core.memory.base.time.sleep")
    def test_metadata_filter_cannot_override_rbac(self, mock_sleep):
        """Caller-supplied metadata_filter must not clobber RBAC keys (tenant isolation).

        Regression for the RBAC-override-via-dict.update() privilege-escalation bug:
        a caller re-specifying ``org_id`` must NOT be able to read another org's data.
        """
        mock_col = MagicMock()
        mock_col.aggregate.return_value = []
        rbac_filter = {"org_id": "org_1", "user_id": "user_1"}
        query_embedding = [0.1, 0.2, 0.3]

        execute_vector_search(
            mock_col,
            index_name="test_index",
            query_embedding=query_embedding,
            rbac_filter=rbac_filter,
            collection_name="test_collection",
            org_id="org_1",
            metadata_filter=MetadataFilter(raw={"org_id": "org_2", "label": "python"}),
        )

        applied_filter = mock_col.aggregate.call_args[0][0][0]["$vectorSearch"]["filter"]
        assert applied_filter["org_id"] == "org_1"
        assert applied_filter["user_id"] == "user_1"
        assert applied_filter["label"] == "python"

    @patch("mongomem_core.memory.base.time.sleep")
    def test_metadata_filter_cannot_inject_omitted_rbac_key(self, mock_sleep):
        """Reserved RBAC keys are non-settable even when absent from rbac_filter.

        When a path omits ``user_id``/``visibility`` (e.g. a project-wide search),
        a caller must not be able to *inject* them via metadata_filter to narrow
        onto another principal's private data inside a shared store.
        """
        mock_col = MagicMock()
        mock_col.aggregate.return_value = []
        # Note: rbac_filter has NO user_id / visibility — they are omitted.
        rbac_filter = {"org_id": "org_1", "project_id": "p1"}
        query_embedding = [0.1, 0.2, 0.3]

        execute_vector_search(
            mock_col,
            index_name="test_index",
            query_embedding=query_embedding,
            rbac_filter=rbac_filter,
            collection_name="test_collection",
            org_id="org_1",
            metadata_filter=MetadataFilter(
                raw={"user_id": "victim", "visibility": "private", "label": "ok"}
            ),
        )

        applied_filter = mock_col.aggregate.call_args[0][0][0]["$vectorSearch"]["filter"]
        # Injected identity keys are dropped entirely (not present), not honored.
        assert "user_id" not in applied_filter
        assert "visibility" not in applied_filter
        # Legitimate non-reserved metadata still passes through.
        assert applied_filter["label"] == "ok"

    @patch("mongomem_core.memory.base.time.sleep")
    def test_metadata_filter_adds_non_rbac_keys(self, mock_sleep):
        """Non-reserved metadata keys are merged alongside the RBAC filter."""
        mock_col = MagicMock()
        mock_col.aggregate.return_value = []
        rbac_filter = {"org_id": "org_1"}
        query_embedding = [0.1, 0.2, 0.3]

        execute_vector_search(
            mock_col,
            index_name="test_index",
            query_embedding=query_embedding,
            rbac_filter=rbac_filter,
            collection_name="test_collection",
            org_id="org_1",
            metadata_filter=MetadataFilter(
                raw={"label": "python", "version": {"$gte": 2}, "agent_id": "data-analyst"}
            ),
        )

        applied_filter = mock_col.aggregate.call_args[0][0][0]["$vectorSearch"]["filter"]
        assert applied_filter["org_id"] == "org_1"
        assert applied_filter["label"] == "python"
        assert applied_filter["version"] == {"$gte": 2}
        # agent_id is a legitimate metadata field, not a reserved RBAC key.
        assert applied_filter["agent_id"] == "data-analyst"


class TestMergeRbacAndMetadataFilter:
    """Tests for the RBAC/metadata merge helper (tenant-isolation boundary)."""

    def test_none_metadata_returns_rbac_copy(self):
        """With no metadata filter, the result equals the RBAC filter (and is a copy)."""
        rbac_filter = {"org_id": "org_1", "user_id": "user_1"}
        result = merge_rbac_and_metadata_filter(rbac_filter, None)
        assert result == rbac_filter
        assert result is not rbac_filter

    def test_empty_metadata_returns_rbac_copy(self):
        """An empty metadata filter does not alter the RBAC filter."""
        rbac_filter = {"org_id": "org_1"}
        result = merge_rbac_and_metadata_filter(rbac_filter, MetadataFilter(raw={}))
        assert result == rbac_filter

    def test_present_rbac_keys_are_non_overridable(self):
        """RBAC keys present in the filter always win over colliding caller keys."""
        rbac_filter = {"org_id": "org_1", "visibility": "private"}
        metadata_filter = MetadataFilter(raw={"org_id": "org_2", "visibility": "shared"})
        result = merge_rbac_and_metadata_filter(rbac_filter, metadata_filter)
        assert result["org_id"] == "org_1"
        assert result["visibility"] == "private"

    def test_reserved_keys_non_injectable_when_absent(self):
        """Reserved keys absent from rbac_filter cannot be injected by the caller."""
        rbac_filter = {"org_id": "org_1"}
        metadata_filter = MetadataFilter(
            raw={"user_id": "victim", "project_id": "p2", "session_id": "s", "label": "ok"}
        )
        result = merge_rbac_and_metadata_filter(rbac_filter, metadata_filter)
        assert "user_id" not in result
        assert "project_id" not in result
        assert "session_id" not in result
        assert result["label"] == "ok"
        assert result["org_id"] == "org_1"

    def test_non_reserved_keys_pass_through(self):
        """Legitimate metadata (label, version, tags, agent_id) is preserved."""
        rbac_filter = {"org_id": "org_1"}
        metadata_filter = MetadataFilter(
            raw={"label": "x", "tags": {"$in": ["a"]}, "agent_id": "agent-1"}
        )
        result = merge_rbac_and_metadata_filter(rbac_filter, metadata_filter)
        assert result["label"] == "x"
        assert result["tags"] == {"$in": ["a"]}
        assert result["agent_id"] == "agent-1"

    def test_collision_is_logged(self, caplog):
        """Dropped reserved keys are surfaced via a warning for auditability."""
        rbac_filter = {"org_id": "org_1"}
        metadata_filter = MetadataFilter(raw={"org_id": "org_2"})
        with caplog.at_level("WARNING"):
            merge_rbac_and_metadata_filter(rbac_filter, metadata_filter)
        assert any("RBAC" in record.message for record in caplog.records)

    def test_structured_conditions_respect_reserved_keys(self):
        """Structured-mode metadata merges, but cannot set reserved keys."""
        rbac_filter = {"org_id": "org_1"}
        metadata_filter = MetadataFilter(
            conditions=[
                FieldFilter(field="label", value="python"),
                FieldFilter(field="org_id", value="org_2"),
                FieldFilter(field="user_id", value="victim"),
                FieldFilter(field="version", operator=FilterOperator.GTE, value=2),
            ]
        )
        result = merge_rbac_and_metadata_filter(rbac_filter, metadata_filter)
        assert result["org_id"] == "org_1"
        assert "user_id" not in result
        assert result["label"] == "python"
        assert result["version"] == {"$gte": 2}


class TestVectorSearchEpisodic:
    """Tests for vector_search_episodic function."""

    @patch("mongomem_core.memory.episodic.execute_vector_search")
    @patch("mongomem_core.memory.episodic.get_collection")
    def test_basic_vector_search(self, mock_get_collection, mock_execute_search):
        """Successfully performs vector search on episodic memory."""
        mock_db = MagicMock()
        mock_col = MagicMock()
        mock_get_collection.return_value = mock_col

        query_embedding = [0.1, 0.2, 0.3]
        mock_results = [
            {
                "_id": ObjectId(),
                "score": 0.95,
                "session_id": "session_1",
                "title": "Meeting",
                "snapshot_ref_id": "snap_1",
                "summary_text": "Summary",
                "org_id": "org_1",
                "user_id": "user_1",
                "timestamp": datetime.now(timezone.utc),
            }
        ]
        mock_execute_search.return_value = mock_results

        results = vector_search_episodic(
            mock_db,
            query_embedding=query_embedding,
            org_id="org_1",
            top_k=10,
        )

        assert len(results) == 1
        assert results[0].session_id == "session_1"
        assert results[0].title == "Meeting"
        mock_execute_search.assert_called_once()
        call_kwargs = mock_execute_search.call_args[1]
        assert call_kwargs["index_name"] == "epi_embedding_vector_index"
        assert call_kwargs["query_embedding"] == query_embedding
        assert call_kwargs["top_k"] == 10

    @patch("mongomem_core.memory.episodic.execute_vector_search")
    @patch("mongomem_core.memory.episodic.get_collection")
    def test_rbac_filtering(self, mock_get_collection, mock_execute_search):
        """Applies RBAC filtering correctly."""
        mock_db = MagicMock()
        mock_col = MagicMock()
        mock_get_collection.return_value = mock_col
        mock_execute_search.return_value = []

        query_embedding = [0.1, 0.2, 0.3]

        vector_search_episodic(
            mock_db,
            query_embedding=query_embedding,
            org_id="org_1",
            user_id="user_1",
            visibility=ChunkVisibility.PRIVATE,
            project_id="group_1",
            session_id="session_1",
        )

        call_kwargs = mock_execute_search.call_args[1]
        rbac_filter = call_kwargs["rbac_filter"]
        assert rbac_filter["org_id"] == "org_1"
        assert rbac_filter["user_id"] == "user_1"
        assert rbac_filter["visibility"] == ChunkVisibility.PRIVATE
        assert rbac_filter["project_id"] == "group_1"
        assert rbac_filter["session_id"] == "session_1"

    @patch("mongomem_core.memory.episodic.execute_vector_search")
    @patch("mongomem_core.memory.episodic.get_collection")
    def test_similarity_threshold(self, mock_get_collection, mock_execute_search):
        """Applies similarity threshold correctly."""
        mock_db = MagicMock()
        mock_col = MagicMock()
        mock_get_collection.return_value = mock_col
        mock_execute_search.return_value = []

        query_embedding = [0.1, 0.2, 0.3]

        vector_search_episodic(
            mock_db,
            query_embedding=query_embedding,
            org_id="org_1",
            similarity_threshold=0.7,
        )

        call_kwargs = mock_execute_search.call_args[1]
        assert call_kwargs["similarity_threshold"] == 0.7

    @patch("mongomem_core.memory.episodic.execute_vector_search")
    @patch("mongomem_core.memory.episodic.get_collection")
    def test_validation_error_propagates(self, mock_get_collection, mock_execute_search):
        """Validation errors from execute_vector_search propagate correctly."""
        mock_db = MagicMock()
        mock_col = MagicMock()
        mock_get_collection.return_value = mock_col

        query_embedding = []  # Empty embedding
        mock_execute_search.side_effect = ValidationError(
            "query_embedding cannot be empty",
            field="query_embedding",
        )

        with pytest.raises(ValidationError) as exc_info:
            vector_search_episodic(
                mock_db,
                query_embedding=query_embedding,
                org_id="org_1",
            )

        assert "query_embedding cannot be empty" in str(exc_info.value)

    @patch("mongomem_core.memory.episodic.execute_vector_search")
    @patch("mongomem_core.memory.episodic.get_collection")
    def test_database_error_propagates(self, mock_get_collection, mock_execute_search):
        """Database errors from execute_vector_search propagate correctly."""
        mock_db = MagicMock()
        mock_col = MagicMock()
        mock_get_collection.return_value = mock_col

        query_embedding = [0.1, 0.2, 0.3]
        mock_execute_search.side_effect = DatabaseOperationError(
            "Vector search failed",
            operation="vector_search",
            collection="episodic_memory",
        )

        with pytest.raises(DatabaseOperationError) as exc_info:
            vector_search_episodic(
                mock_db,
                query_embedding=query_embedding,
                org_id="org_1",
            )

        assert "Vector search failed" in str(exc_info.value)


class TestVectorSearchSemantic:
    """Tests for search_semantic function."""

    @patch("mongomem_core.memory.semantic.execute_vector_search")
    @patch("mongomem_core.memory.semantic.get_collection")
    def test_basic_vector_search(self, mock_get_collection, mock_execute_search):
        """Successfully performs vector search on semantic memory."""
        mock_db = MagicMock()
        mock_col = MagicMock()
        mock_get_collection.return_value = mock_col

        query_embedding = [0.1, 0.2, 0.3]
        mock_results = [
            {
                "_id": ObjectId(),
                "score": 0.95,
                "content": "Knowledge chunk",
                "label": "fact",
                "org_id": "org_1",
                "user_id": "user_1",
                "timestamp": datetime.now(timezone.utc),
            }
        ]
        mock_execute_search.return_value = mock_results

        results = search_semantic(
            mock_db,
            query_embedding=query_embedding,
            org_id="org_1",
            top_k=10,
            return_format="model",
        )

        assert len(results) == 1
        assert results[0].content == "Knowledge chunk"
        assert results[0].label == "fact"
        mock_execute_search.assert_called_once()
        call_kwargs = mock_execute_search.call_args[1]
        assert call_kwargs["index_name"] == "sem_embedding_vector_index"
        assert call_kwargs["query_embedding"] == query_embedding
        assert call_kwargs["top_k"] == 10
        # Verify return_format="model" is used (default)
        assert isinstance(results[0].content, str)  # SemanticOut has content attribute

    @patch("mongomem_core.memory.semantic.execute_vector_search")
    @patch("mongomem_core.memory.semantic.get_collection")
    def test_rbac_filtering(self, mock_get_collection, mock_execute_search):
        """Applies RBAC filtering correctly."""
        mock_db = MagicMock()
        mock_col = MagicMock()
        mock_get_collection.return_value = mock_col
        mock_execute_search.return_value = []

        query_embedding = [0.1, 0.2, 0.3]

        search_semantic(
            mock_db,
            query_embedding=query_embedding,
            org_id="org_1",
            user_id="user_1",
            visibility=ChunkVisibility.SHARED,
            project_id="group_1",
            return_format="model",
        )

        call_kwargs = mock_execute_search.call_args[1]
        rbac_filter = call_kwargs["rbac_filter"]
        assert rbac_filter["org_id"] == "org_1"
        assert rbac_filter["user_id"] == "user_1"
        assert rbac_filter["visibility"] == ChunkVisibility.SHARED
        assert rbac_filter["project_id"] == "group_1"
        # Semantic doesn't have session_id
        assert "session_id" not in rbac_filter

    @patch("mongomem_core.memory.semantic.execute_vector_search")
    @patch("mongomem_core.memory.semantic.get_collection")
    def test_similarity_threshold(self, mock_get_collection, mock_execute_search):
        """Applies similarity threshold correctly."""
        mock_db = MagicMock()
        mock_col = MagicMock()
        mock_get_collection.return_value = mock_col
        mock_execute_search.return_value = []

        query_embedding = [0.1, 0.2, 0.3]

        search_semantic(
            mock_db,
            query_embedding=query_embedding,
            org_id="org_1",
            similarity_threshold=0.8,
            return_format="model",
        )

        call_kwargs = mock_execute_search.call_args[1]
        assert call_kwargs["similarity_threshold"] == 0.8

    @patch("mongomem_core.memory.semantic.execute_vector_search")
    @patch("mongomem_core.memory.semantic.get_collection")
    def test_validation_error_propagates(self, mock_get_collection, mock_execute_search):
        """Validation errors from execute_vector_search propagate correctly."""
        mock_db = MagicMock()
        mock_col = MagicMock()
        mock_get_collection.return_value = mock_col

        query_embedding = []  # Empty embedding
        mock_execute_search.side_effect = ValidationError(
            "query_embedding cannot be empty",
            field="query_embedding",
        )

        with pytest.raises(ValidationError) as exc_info:
            search_semantic(
                mock_db,
                query_embedding=query_embedding,
                org_id="org_1",
                return_format="model",
            )

        assert "query_embedding cannot be empty" in str(exc_info.value)

    @patch("mongomem_core.memory.semantic.execute_vector_search")
    @patch("mongomem_core.memory.semantic.get_collection")
    def test_database_error_propagates(self, mock_get_collection, mock_execute_search):
        """Database errors from execute_vector_search propagate correctly."""
        mock_db = MagicMock()
        mock_col = MagicMock()
        mock_get_collection.return_value = mock_col

        query_embedding = [0.1, 0.2, 0.3]
        mock_execute_search.side_effect = DatabaseOperationError(
            "Vector search failed",
            operation="vector_search",
            collection="semantic_memory",
        )

        with pytest.raises(DatabaseOperationError) as exc_info:
            search_semantic(
                mock_db,
                query_embedding=query_embedding,
                org_id="org_1",
                return_format="model",
            )

        assert "Vector search failed" in str(exc_info.value)

    @patch("mongomem_core.memory.semantic.execute_vector_search")
    @patch("mongomem_core.memory.semantic.get_collection")
    def test_dict_format_return(self, mock_get_collection, mock_execute_search):
        """Returns dict format when return_format='dict'."""
        mock_db = MagicMock()
        mock_col = MagicMock()
        mock_get_collection.return_value = mock_col

        query_embedding = [0.1, 0.2, 0.3]
        mock_results = [
            {
                "_id": ObjectId(),
                "score": 0.95,
                "content": "Knowledge chunk",
                "label": "fact",
                "version": 1,
                "memory_lineage_id": "lineage_1",
                "confidence_score": 0.9,
                "reinforcement_count": 5,
            }
        ]
        mock_execute_search.return_value = mock_results

        results = search_semantic(
            mock_db,
            query_embedding=query_embedding,
            org_id="org_1",
            user_id="user_1",
            return_format="dict",
        )

        assert len(results) == 1
        assert isinstance(results[0], dict)
        assert results[0]["text"] == "Knowledge chunk"
        assert results[0]["label"] == "fact"
        assert results[0]["score"] == 0.95
        assert results[0]["version"] == 1
        assert results[0]["memory_lineage_id"] == "lineage_1"
        assert results[0]["confidence_score"] == 0.9
        assert results[0]["reinforcement_count"] == 5
        mock_execute_search.assert_called_once()
        call_kwargs = mock_execute_search.call_args[1]
        assert call_kwargs["projection"] is not None
        assert "_id" in call_kwargs["projection"]
        assert "content" in call_kwargs["projection"]

    @patch("mongomem_core.memory.semantic.execute_vector_search")
    @patch("mongomem_core.memory.semantic.get_collection")
    def test_dict_format_requires_user_id(self, mock_get_collection, mock_execute_search):
        """Dict format requires user_id parameter."""
        mock_db = MagicMock()
        mock_col = MagicMock()
        mock_get_collection.return_value = mock_col

        query_embedding = [0.1, 0.2, 0.3]

        with pytest.raises(ValueError, match="user_id is required when return_format='dict'"):
            search_semantic(
                mock_db,
                query_embedding=query_embedding,
                org_id="org_1",
                return_format="dict",
            )

    @patch("mongomem_core.memory.semantic.execute_vector_search")
    @patch("mongomem_core.memory.semantic.get_collection")
    def test_is_latest_filter(self, mock_get_collection, mock_execute_search):
        """is_latest filter is applied correctly for dict format."""
        mock_db = MagicMock()
        mock_col = MagicMock()
        mock_get_collection.return_value = mock_col
        mock_execute_search.return_value = []

        query_embedding = [0.1, 0.2, 0.3]

        search_semantic(
            mock_db,
            query_embedding=query_embedding,
            org_id="org_1",
            user_id="user_1",
            return_format="dict",
            is_latest=True,
        )

        call_kwargs = mock_execute_search.call_args[1]
        rbac_filter = call_kwargs["rbac_filter"]
        assert rbac_filter.get("is_latest") is True

    @patch("mongomem_core.memory.semantic.execute_vector_search")
    @patch("mongomem_core.memory.semantic.get_collection")
    def test_include_deleted_filter(self, mock_get_collection, mock_execute_search):
        """include_deleted filter is applied correctly."""
        mock_db = MagicMock()
        mock_col = MagicMock()
        mock_get_collection.return_value = mock_col
        mock_execute_search.return_value = []

        query_embedding = [0.1, 0.2, 0.3]

        search_semantic(
            mock_db,
            query_embedding=query_embedding,
            org_id="org_1",
            user_id="user_1",
            return_format="dict",
            include_deleted=True,
        )

        call_kwargs = mock_execute_search.call_args[1]
        rbac_filter = call_kwargs["rbac_filter"]
        # When include_deleted=True, deleted filter should not be added
        assert "deleted" not in rbac_filter or rbac_filter.get("deleted") != {"$ne": True}
