import asyncio
import time

import pytest
from mongomem_core import MemoryEngine
from mongomem_core.config import Settings

from runner_shared.server.mongomem_impl.src.mongomem_worker import MongoMemWorker

from ..conftest import (
    TEST_MONGO_URI,
    MockEmbedder,
    MockLLM,
    RecordingMetrics,
    random_db_name,
)


class TestWorkerInitialization:
    def test_init_minimal_config(self, test_engine: MemoryEngine):
        worker = MongoMemWorker(engine=test_engine)
        assert worker is not None
        assert worker.engine is test_engine

    def test_init_with_split_databases(self, mock_embedder: MockEmbedder):
        settings = Settings(
            mongo_uri=TEST_MONGO_URI,
            db_name="core_db",
            embedding_dimension=mock_embedder.dimension,
        )
        engine = MemoryEngine(settings, embedder=mock_embedder)

        worker = MongoMemWorker(engine=engine, worker_db_name="worker_db")

        assert worker._config.effective_core_db == "core_db"
        assert worker._config.effective_worker_db == "worker_db"

    def test_init_with_tenant_id(self, test_engine: MemoryEngine):
        worker = MongoMemWorker(engine=test_engine, tenant_id="tenant-123")
        assert worker._tenant_id == "tenant-123"

    def test_init_distributed_mode(self, test_engine: MemoryEngine):
        worker = MongoMemWorker(engine=test_engine, scaling_mode="distributed")
        assert worker._scaling_mode == "distributed"

    def test_init_with_observability(
        self, test_engine: MemoryEngine, recording_metrics: RecordingMetrics
    ):
        """Worker should accept observability backend."""
        worker = MongoMemWorker(engine=test_engine, observability=recording_metrics)
        assert worker._obs._backend is recording_metrics

    def test_init_with_llm_enables_extractions(self, test_engine_with_llm: MemoryEngine):
        worker = MongoMemWorker(engine=test_engine_with_llm)
        assert worker._config.is_extraction_enabled("taxonomic") is True

    def test_init_no_embedder_raises(self):
        settings = Settings(mongo_uri=TEST_MONGO_URI, db_name="test_db")
        engine = MemoryEngine(settings)  # No embedder

        with pytest.raises(ValueError, match="must have an embedder"):
            MongoMemWorker(engine=engine)


class TestWorkerProperties:
    def test_is_running_initially_false(self, test_engine: MemoryEngine):
        worker = MongoMemWorker(engine=test_engine)
        assert worker.is_running is False

    def test_is_idle_returns_bool(self, test_engine: MemoryEngine):
        worker = MongoMemWorker(engine=test_engine)
        assert isinstance(worker.is_idle, bool)


class TestWorkerBackgroundStart:
    def test_start_background(self, test_engine: MemoryEngine):
        worker = MongoMemWorker(engine=test_engine)

        try:
            worker.start_background()
            time.sleep(0.5)
            assert worker.is_running is True
        finally:
            worker.stop()

    def test_start_background_idempotent(self, test_engine: MemoryEngine):
        worker = MongoMemWorker(engine=test_engine)

        try:
            worker.start_background()
            worker.start_background()
            time.sleep(0.5)
            assert worker.is_running is True
        finally:
            worker.stop()

    def test_stop_worker(self, test_engine: MemoryEngine):
        worker = MongoMemWorker(engine=test_engine)

        worker.start_background()
        time.sleep(0.5)
        assert worker.is_running is True

        worker.stop()
        worker.wait(timeout=2.0)
        assert worker.is_running is False

    def test_stop_idempotent(self, test_engine: MemoryEngine):
        worker = MongoMemWorker(engine=test_engine)

        worker.start_background()
        time.sleep(0.3)

        worker.stop()
        worker.stop()
        worker.wait(timeout=2.0)
        assert worker.is_running is False


class TestWorkerAsyncStart:
    @pytest.mark.asyncio
    async def test_run_async(self, test_engine: MemoryEngine):
        worker = MongoMemWorker(engine=test_engine)

        async def stop_after_delay():
            await asyncio.sleep(0.5)
            worker.stop()

        asyncio.create_task(stop_after_delay())

        await worker.run_async()
        assert worker.is_running is False


class TestWorkerCollectionInitialization:
    def test_worker_collections_created(self, test_engine: MemoryEngine, mongo_client):
        worker = MongoMemWorker(engine=test_engine)

        worker.start_background()
        time.sleep(1)
        worker.stop()

        db = mongo_client[test_engine.settings.db_name]
        collection_names = db.list_collection_names()

        assert "tasks" in collection_names
        assert "worker_state" in collection_names


class TestWorkerMetricsIntegration:
    def test_worker_emits_active_metric(
        self, test_engine: MemoryEngine, recording_metrics: RecordingMetrics
    ):
        """Worker should emit worker_active gauge during its lifecycle."""
        worker = MongoMemWorker(engine=test_engine, observability=recording_metrics)

        worker.start_background()
        time.sleep(1.0)  # Give worker time to start processing loop
        worker.stop()
        worker.wait(timeout=3.0)  # Wait for clean shutdown

        # Check any metrics were recorded (not just worker_active)
        total_metrics = len(recording_metrics.gauges) + len(recording_metrics.increments)
        assert total_metrics > 0, "Worker should emit at least some metrics"


class TestEngineWorkerEdgeCases:
    """Edge cases in engine-worker interaction."""

    def test_worker_works_without_engine_bootstrap(self, mock_embedder: MockEmbedder):
        """Worker should start even if engine.bootstrap() was not called."""
        db_name = random_db_name()
        settings = Settings(
            mongo_uri=TEST_MONGO_URI,
            db_name=db_name,
            embedding_dimension=mock_embedder.dimension,
        )
        engine = MemoryEngine(settings, embedder=mock_embedder)
        # Note: NOT calling engine.bootstrap()

        worker = MongoMemWorker(engine=engine)

        try:
            worker.start_background()
            time.sleep(0.5)
            assert worker.is_running is True
        finally:
            worker.stop()
            worker.wait(timeout=2.0)

    def test_multiple_workers_share_engine(self, mock_embedder: MockEmbedder):
        """Multiple workers can safely share the same engine instance."""
        db_name = random_db_name()
        settings = Settings(
            mongo_uri=TEST_MONGO_URI,
            db_name=db_name,
            embedding_dimension=mock_embedder.dimension,
        )
        engine = MemoryEngine(settings, embedder=mock_embedder)

        worker1 = MongoMemWorker(engine=engine, scaling_mode="distributed")
        worker2 = MongoMemWorker(engine=engine, scaling_mode="distributed")

        try:
            worker1.start_background()
            worker2.start_background()
            time.sleep(1.0)

            assert worker1.is_running is True
            assert worker2.is_running is True

            # Both workers share the same embedder
            assert worker1._embedder is worker2._embedder
        finally:
            worker1.stop()
            worker2.stop()
            worker1.wait(timeout=2.0)
            worker2.wait(timeout=2.0)

    def test_engine_dimension_mismatch_raises_at_engine_init(self, mock_embedder: MockEmbedder):
        """Dimension mismatch is caught at engine init, not worker init."""
        # MockEmbedder dimension is 1024, settings says 1536
        settings = Settings(
            mongo_uri=TEST_MONGO_URI,
            db_name="test_db",
            embedding_dimension=1536,  # Mismatch!
        )

        with pytest.raises(ValueError, match="Embedding dimension mismatch"):
            MemoryEngine(settings, embedder=mock_embedder)

    def test_worker_with_llm_but_extractions_disabled(
        self, mock_embedder: MockEmbedder, mock_llm: MockLLM
    ):
        """Worker with LLM but all extractions explicitly disabled."""
        db_name = random_db_name()
        settings = Settings(
            mongo_uri=TEST_MONGO_URI,
            db_name=db_name,
            embedding_dimension=mock_embedder.dimension,
        )
        engine = MemoryEngine(settings, embedder=mock_embedder, llm=mock_llm)

        worker = MongoMemWorker(
            engine=engine,
            extraction_config={
                "taxonomic": {"enabled": False},
                "episodic": {"enabled": False},
                "semantic": {"enabled": False},
                "entity": {"enabled": False},
            },
        )

        # No extraction handlers should be enabled
        assert worker._config.is_extraction_enabled("taxonomic") is False
        assert worker._config.is_extraction_enabled("entity") is False

    def test_worker_inherits_engine_settings(self, mock_embedder: MockEmbedder):
        """Worker correctly inherits all settings from engine."""
        db_name = random_db_name()
        settings = Settings(
            mongo_uri=TEST_MONGO_URI,
            db_name=db_name,
            embedding_dimension=mock_embedder.dimension,
        )
        engine = MemoryEngine(settings, embedder=mock_embedder)

        worker = MongoMemWorker(engine=engine)

        # Worker should use engine's settings
        assert worker._config.db_name == db_name
        assert worker._config.effective_core_db == db_name
        assert worker._embedder is mock_embedder
        assert worker._embedder.dimension == mock_embedder.dimension
