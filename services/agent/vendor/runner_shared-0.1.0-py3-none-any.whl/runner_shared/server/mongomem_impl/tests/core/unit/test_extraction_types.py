"""Unit tests for extraction types module."""

from datetime import datetime, timezone

from mongomem_core.extraction.types import (
    ConsolidationDecision,
    ConsolidationStats,
    ExtractedItem,
    ExtractionMetadata,
    ExtractionResult,
    PersistenceResult,
    ScoredExtraction,
    SimilarMatch,
)


class TestExtractedItem:
    """Tests for ExtractedItem dataclass."""

    def test_create_basic(self):
        """Test basic creation with required fields."""
        item = ExtractedItem(content="The user likes Python")
        assert item.content == "The user likes Python"
        assert item.citations == []
        assert item.confidence == 0.0
        assert item.cited_text == []
        assert item.metadata == {}

    def test_create_with_all_fields(self):
        """Test creation with all fields populated."""
        item = ExtractedItem(
            content="The user is a Data Scientist",
            citations=[0, 2],
            confidence=0.95,
            cited_text=[
                {"cited_idx": 0, "cited_text": {"role": "user", "content": "I work as..."}}
            ],
            metadata={"extraction_type": "semantic"},
        )
        assert item.content == "The user is a Data Scientist"
        assert item.citations == [0, 2]
        assert item.confidence == 0.95
        assert len(item.cited_text) == 1
        assert item.metadata["extraction_type"] == "semantic"


class TestScoredExtraction:
    """Tests for ScoredExtraction dataclass."""

    def test_create_valid_extraction(self):
        """Test creating a valid scored extraction."""
        scored = ScoredExtraction(
            content="The user prefers Python",
            citations=[0],
            confidence=0.9,
            citation_score=1.0,
            combined_score=0.94,
            is_valid=True,
            cited_text=[],
        )
        assert scored.is_valid is True
        assert scored.combined_score == 0.94

    def test_create_invalid_extraction(self):
        """Test creating an invalid scored extraction."""
        scored = ScoredExtraction(
            content="",
            citations=[],
            confidence=0.1,
            citation_score=0.0,
            combined_score=0.04,
            is_valid=False,
            metadata={"validation_error": "empty_content"},
        )
        assert scored.is_valid is False
        assert "validation_error" in scored.metadata


class TestSimilarMatch:
    """Tests for SimilarMatch dataclass."""

    def test_create(self):
        """Test creating a similar match."""
        match = SimilarMatch(
            id="507f1f77bcf86cd799439011",
            content="The user uses Python",
            score=0.92,
        )
        assert match.id == "507f1f77bcf86cd799439011"
        assert match.score == 0.92


class TestConsolidationDecision:
    """Tests for ConsolidationDecision dataclass."""

    def test_add_decision(self):
        """Test ADD decision creation."""
        extraction = ScoredExtraction(
            content="New fact",
            citations=[],
            confidence=0.9,
            citation_score=0.0,
            combined_score=0.36,
            is_valid=True,
        )
        decision = ConsolidationDecision(
            extraction=extraction,
            action="ADD",
            reason="no similar memories found",
        )
        assert decision.action == "ADD"
        assert decision.existing_id is None

    def test_update_decision(self):
        """Test UPDATE decision creation."""
        extraction = ScoredExtraction(
            content="Updated fact",
            citations=[0],
            confidence=0.95,
            citation_score=1.0,
            combined_score=0.98,
            is_valid=True,
        )
        decision = ConsolidationDecision(
            extraction=extraction,
            action="UPDATE",
            existing_id="507f1f77bcf86cd799439011",
            reason="supersedes existing memory",
        )
        assert decision.action == "UPDATE"
        assert decision.existing_id == "507f1f77bcf86cd799439011"

    def test_reinforce_decision(self):
        """Test REINFORCE decision creation."""
        extraction = ScoredExtraction(
            content="Same fact",
            citations=[0],
            confidence=0.9,
            citation_score=1.0,
            combined_score=0.96,
            is_valid=True,
        )
        decision = ConsolidationDecision(
            extraction=extraction,
            action="REINFORCE",
            existing_id="507f1f77bcf86cd799439011",
            reason="semantic duplicate",
        )
        assert decision.action == "REINFORCE"


class TestConsolidationStats:
    """Tests for ConsolidationStats dataclass."""

    def test_default_values(self):
        """Test default values are zero."""
        stats = ConsolidationStats()
        assert stats.add_count == 0
        assert stats.update_count == 0
        assert stats.reinforce_count == 0
        assert stats.duplicate_count == 0

    def test_with_values(self):
        """Test with provided values."""
        stats = ConsolidationStats(
            add_count=5,
            update_count=2,
            reinforce_count=3,
            duplicate_count=1,
        )
        assert stats.add_count == 5
        assert stats.update_count == 2
        assert stats.reinforce_count == 3
        assert stats.duplicate_count == 1


class TestExtractionMetadata:
    """Tests for ExtractionMetadata dataclass."""

    def test_default_values(self):
        """Test default values."""
        meta = ExtractionMetadata()
        assert meta.model_used is None
        assert meta.prompt_version == "1.0"
        assert meta.processing_time_ms == 0
        assert meta.input_hash == ""

    def test_with_values(self):
        """Test with provided values."""
        now = datetime.now(timezone.utc)
        meta = ExtractionMetadata(
            model_used="gpt-4",
            prompt_version="2.0",
            processing_time_ms=150,
            input_hash="abc123",
            extraction_timestamp=now,
        )
        assert meta.model_used == "gpt-4"
        assert meta.extraction_timestamp == now


class TestExtractionResult:
    """Tests for ExtractionResult dataclass."""

    def test_default_values(self):
        """Test default values."""
        result = ExtractionResult(source_reference="snapshot_123")
        assert result.source_reference == "snapshot_123"
        assert result.success is False
        assert result.extracted_count == 0
        assert result.stored_count == 0
        assert result.created_ids == []
        assert result.errors == []

    def test_successful_result(self):
        """Test successful result creation."""
        result = ExtractionResult(
            source_reference="snapshot_123",
            success=True,
            extracted_count=5,
            stored_count=3,
            validation_failures=2,
            created_ids=["id1", "id2", "id3"],
            consolidation_stats=ConsolidationStats(add_count=3),
        )
        assert result.success is True
        assert result.extracted_count == 5
        assert result.stored_count == 3
        assert len(result.created_ids) == 3


class TestPersistenceResult:
    """Tests for PersistenceResult dataclass."""

    def test_default_values(self):
        """Test default values are zero."""
        result = PersistenceResult()
        assert result.added == 0
        assert result.updated == 0
        assert result.reinforced == 0
        assert result.skipped == 0
        assert result.created_ids == []
        assert result.errors == []

    def test_with_results(self):
        """Test with operation results."""
        result = PersistenceResult(
            added=3,
            updated=1,
            reinforced=2,
            skipped=1,
            created_ids=["id1", "id2", "id3"],
            updated_new_version_ids=["id4"],
            updated_old_version_ids=["id5"],
            reinforced_ids=["id6", "id7"],
        )
        assert result.added == 3
        assert result.updated == 1
        assert result.reinforced == 2
        assert result.skipped == 1
        assert len(result.created_ids) == 3
        assert len(result.updated_new_version_ids) == 1
