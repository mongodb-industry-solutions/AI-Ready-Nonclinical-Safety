"""
Unit tests for approval workflow types.

Tests Pydantic models, serialization, and tagged union discriminator behavior.
"""

from datetime import datetime, timezone

import pytest
from mongomem_core.extraction.approval.types import (
    ApprovalResult,
    BatchApprovalResult,
    PendingDecisionPayload,
    PendingExtraction,
    PendingMemoryRefPayload,
    PendingPreferencesPayload,
    from_mongo_doc,
    to_mongo_doc,
)
from mongomem_core.models.memory.base import ChunkVisibility


class TestPendingDecisionPayload:
    """Tests for PendingDecisionPayload model."""

    def test_add_action_allows_none_existing_id(self):
        """ADD action should allow None existing_id."""
        payload = PendingDecisionPayload(
            action="ADD",
            content="Test content",
            confidence=0.9,
            existing_id=None,
        )
        assert payload.action == "ADD"
        assert payload.existing_id is None

    def test_update_action_requires_existing_id(self):
        """UPDATE action should require existing_id."""
        with pytest.raises(ValueError, match="existing_id is required"):
            PendingDecisionPayload(
                action="UPDATE",
                content="Test content",
                existing_id=None,
            )

    def test_reinforce_action_requires_existing_id(self):
        """REINFORCE action should require existing_id."""
        with pytest.raises(ValueError, match="existing_id is required"):
            PendingDecisionPayload(
                action="REINFORCE",
                content="Test content",
                existing_id=None,
            )

    def test_update_action_with_existing_id_succeeds(self):
        """UPDATE action with existing_id should succeed."""
        payload = PendingDecisionPayload(
            action="UPDATE",
            content="Test content",
            existing_id="abc123",
        )
        assert payload.action == "UPDATE"
        assert payload.existing_id == "abc123"

    def test_reinforce_action_with_existing_id_succeeds(self):
        """REINFORCE action with existing_id should succeed."""
        payload = PendingDecisionPayload(
            action="REINFORCE",
            content="Test content",
            existing_id="abc123",
        )
        assert payload.action == "REINFORCE"
        assert payload.existing_id == "abc123"

    def test_serialization_roundtrip(self):
        """Test serialization and deserialization of decision payload."""
        payload = PendingDecisionPayload(
            action="ADD",
            content="User likes Python",
            citations=[0, 1, 2],
            confidence=0.95,
            citation_score=0.8,
            combined_score=0.87,
            embedding=[0.1, 0.2, 0.3],
            cited_text=[{"text": "I love Python"}],
            metadata={"domain": "preferences"},
        )
        data = payload.model_dump()
        restored = PendingDecisionPayload.model_validate(data)
        assert restored.action == payload.action
        assert restored.content == payload.content
        assert restored.citations == payload.citations
        assert restored.embedding == payload.embedding

    def test_kind_discriminator(self):
        """Decision payload should have kind='decision'."""
        payload = PendingDecisionPayload(action="ADD", content="Test")
        assert payload.kind == "decision"


class TestPendingPreferencesPayload:
    """Tests for PendingPreferencesPayload model."""

    def test_serialization_roundtrip(self):
        """Test preferences payload serialization."""
        payload = PendingPreferencesPayload(
            session_id="session-123",
            tone="formal",
            style="concise",
            response_length="short",
            expertise_level="expert",
            preferred_format="bullet_points",
            language="en",
            custom_instructions="Be brief",
            confidence=0.85,
            evidence=[0, 1, 2],
        )
        data = payload.model_dump()
        restored = PendingPreferencesPayload.model_validate(data)
        assert restored.session_id == payload.session_id
        assert restored.tone == payload.tone
        assert restored.evidence == [0, 1, 2]

    def test_kind_discriminator(self):
        """Preferences payload should have kind='preferences'."""
        payload = PendingPreferencesPayload(session_id="sess-1")
        assert payload.kind == "preferences"

    def test_evidence_is_list_of_int(self):
        """Evidence field should be a list of integers (message indices)."""
        payload = PendingPreferencesPayload(
            session_id="sess-1",
            evidence=[0, 5, 10],
        )
        assert payload.evidence == [0, 5, 10]
        assert all(isinstance(e, int) for e in payload.evidence)


class TestPendingMemoryRefPayload:
    """Tests for PendingMemoryRefPayload model."""

    def test_serialization_roundtrip(self):
        """Test memory ref payload serialization."""
        payload = PendingMemoryRefPayload(
            memory_id="mem-abc123",
            memory_type="semantic",
            unpublished_reason="Incorrect information",
        )
        data = payload.model_dump()
        restored = PendingMemoryRefPayload.model_validate(data)
        assert restored.memory_id == payload.memory_id
        assert restored.memory_type == payload.memory_type
        assert restored.unpublished_reason == payload.unpublished_reason

    def test_kind_discriminator(self):
        """Memory ref payload should have kind='memory_ref'."""
        payload = PendingMemoryRefPayload(memory_id="m1", memory_type="semantic")
        assert payload.kind == "memory_ref"


class TestPendingExtraction:
    """Tests for PendingExtraction model."""

    def test_to_mongo_doc_excludes_none_id(self):
        """to_mongo_doc should exclude _id when None."""
        pending = PendingExtraction(
            org_id="org-1",
            user_id="user-1",
            source_id="src-1",
            extraction_type="semantic",
            payload=PendingDecisionPayload(action="ADD", content="Test"),
        )
        doc = to_mongo_doc(pending)
        assert "_id" not in doc
        assert doc["org_id"] == "org-1"
        assert doc["extraction_type"] == "semantic"

    def test_from_mongo_doc_converts_id(self):
        """from_mongo_doc should convert ObjectId to string."""
        from bson import ObjectId

        oid = ObjectId()
        doc = {
            "_id": oid,
            "org_id": "org-1",
            "user_id": "user-1",
            "source_id": "src-1",
            "extraction_type": "semantic",
            "payload": {"kind": "decision", "action": "ADD", "content": "Test"},
            "visibility": "private",
            "status": "pending",
            "created_at": datetime.now(timezone.utc),
        }
        pending = from_mongo_doc(doc)
        assert pending.id == str(oid)
        assert pending.org_id == "org-1"

    def test_roundtrip_with_decision_payload(self):
        """Test full roundtrip with decision payload."""
        pending = PendingExtraction(
            org_id="org-1",
            user_id="user-1",
            source_id="src-1",
            extraction_type="semantic",
            payload=PendingDecisionPayload(
                action="ADD",
                content="User likes Python",
                confidence=0.9,
            ),
            visibility=ChunkVisibility.SHARED,
            project_id="group-1",
        )
        doc = to_mongo_doc(pending)
        # Simulate MongoDB adding _id
        from bson import ObjectId

        doc["_id"] = ObjectId()
        restored = from_mongo_doc(doc)
        assert restored.extraction_type == "semantic"
        assert restored.payload.kind == "decision"
        assert restored.payload.content == "User likes Python"
        assert restored.visibility == ChunkVisibility.SHARED
        assert restored.project_id == "group-1"

    def test_tagged_union_discriminator_works(self):
        """Test that tagged union correctly discriminates payload types."""
        # Decision
        doc1 = {
            "org_id": "o1",
            "user_id": "u1",
            "source_id": "s1",
            "extraction_type": "semantic",
            "payload": {"kind": "decision", "action": "ADD", "content": "test"},
            "visibility": "private",
            "status": "pending",
            "created_at": datetime.now(timezone.utc),
        }
        p1 = PendingExtraction.model_validate(doc1)
        assert isinstance(p1.payload, PendingDecisionPayload)

        # Preferences
        doc2 = {
            "org_id": "o1",
            "user_id": "u1",
            "source_id": "s1",
            "extraction_type": "preferences",
            "payload": {"kind": "preferences", "session_id": "sess-1"},
            "visibility": "private",
            "status": "pending",
            "created_at": datetime.now(timezone.utc),
        }
        p2 = PendingExtraction.model_validate(doc2)
        assert isinstance(p2.payload, PendingPreferencesPayload)

        # Memory ref
        doc3 = {
            "org_id": "o1",
            "user_id": "u1",
            "source_id": "s1",
            "extraction_type": "semantic",
            "payload": {"kind": "memory_ref", "memory_id": "m1", "memory_type": "semantic"},
            "visibility": "private",
            "status": "pending",
            "created_at": datetime.now(timezone.utc),
        }
        p3 = PendingExtraction.model_validate(doc3)
        assert isinstance(p3.payload, PendingMemoryRefPayload)


class TestApprovalResult:
    """Tests for ApprovalResult model."""

    def test_success_result(self):
        """Test successful approval result."""
        result = ApprovalResult(
            success=True,
            memory_id="mem-123",
            pending_id="pending-456",
        )
        assert result.success is True
        assert result.memory_id == "mem-123"
        assert result.error is None

    def test_failure_result(self):
        """Test failed approval result."""
        result = ApprovalResult(
            success=False,
            error="Not found",
            pending_id="pending-456",
        )
        assert result.success is False
        assert result.error == "Not found"
        assert result.memory_id is None


class TestBatchApprovalResult:
    """Tests for BatchApprovalResult model."""

    def test_batch_counts(self):
        """Test batch approval result counts."""
        result = BatchApprovalResult(
            total=3,
            approved=2,
            failed=1,
            results=[
                ApprovalResult(success=True, memory_id="m1", pending_id="p1"),
                ApprovalResult(success=True, memory_id="m2", pending_id="p2"),
                ApprovalResult(success=False, error="Error", pending_id="p3"),
            ],
        )
        assert result.total == 3
        assert result.approved == 2
        assert result.failed == 1
        assert len(result.results) == 3
