"""Tests for circuit breaker implementation."""

from __future__ import annotations

import time
from unittest.mock import Mock

import pytest

from runner_shared.server.mongomem_impl.src.mongomem_worker.circuit_breaker import (
    CircuitBreaker,
    CircuitBreakerOpen,
    CircuitState,
    clear_all_circuit_breakers,
    get_all_circuit_breakers,
    get_circuit_breaker,
    reset_circuit_breaker,
)


@pytest.fixture(autouse=True)
def clean_circuit_breakers():
    """Clean up circuit breakers before and after each test."""
    clear_all_circuit_breakers()
    yield
    clear_all_circuit_breakers()


class TestCircuitBreakerStates:
    """Tests for circuit breaker state transitions."""

    def test_starts_closed(self):
        breaker = CircuitBreaker("test")
        assert breaker.state == CircuitState.CLOSED
        assert breaker.is_closed
        assert not breaker.is_open

    def test_opens_after_failure_threshold(self):
        breaker = CircuitBreaker("test", failure_threshold=3)

        for _ in range(3):
            try:
                breaker.call_sync(self._raise_error)
            except RuntimeError:
                pass

        assert breaker.state == CircuitState.OPEN
        assert breaker.is_open
        assert not breaker.is_closed

    def test_rejects_calls_when_open(self):
        breaker = CircuitBreaker("test", failure_threshold=1)

        # Trip the breaker
        with pytest.raises(RuntimeError):
            breaker.call_sync(self._raise_error)

        assert breaker.is_open

        # Next call should be rejected
        with pytest.raises(CircuitBreakerOpen) as exc_info:
            breaker.call_sync(lambda: "success")

        assert exc_info.value.name == "test"
        assert exc_info.value.retry_in_seconds >= 0

    def test_transitions_to_half_open_after_timeout(self):
        breaker = CircuitBreaker(
            "test",
            failure_threshold=1,
            timeout_seconds=0.1,
            success_threshold=1,  # Only need 1 success to close
        )

        # Trip the breaker
        with pytest.raises(RuntimeError):
            breaker.call_sync(self._raise_error)

        assert breaker.is_open

        # Wait for timeout
        time.sleep(0.15)

        # Next call attempt should transition to half-open and succeed
        result = breaker.call_sync(lambda: "success")
        assert result == "success"
        # After success in half-open (with success_threshold=1), it should go to closed
        assert breaker.is_closed

    def test_half_open_closes_after_success_threshold(self):
        breaker = CircuitBreaker(
            "test",
            failure_threshold=1,
            timeout_seconds=0.1,
            success_threshold=2,
        )

        # Trip the breaker
        with pytest.raises(RuntimeError):
            breaker.call_sync(self._raise_error)

        time.sleep(0.15)

        # First success in half-open
        breaker.call_sync(lambda: "success")
        # State should be half-open until success_threshold reached
        # Actually, after first success it may still be half-open
        # Let's call again
        breaker.call_sync(lambda: "success")

        # Now should be closed
        assert breaker.is_closed

    def test_half_open_reopens_on_failure(self):
        breaker = CircuitBreaker(
            "test",
            failure_threshold=1,
            timeout_seconds=0.1,
            success_threshold=2,
        )

        # Trip the breaker
        with pytest.raises(RuntimeError):
            breaker.call_sync(self._raise_error)

        time.sleep(0.15)

        # Fail in half-open
        with pytest.raises(RuntimeError):
            breaker.call_sync(self._raise_error)

        # Should be open again
        assert breaker.is_open

    @staticmethod
    def _raise_error():
        raise RuntimeError("test error")


class TestCircuitBreakerSync:
    """Tests for synchronous call handling."""

    def test_successful_call_passes_through(self):
        breaker = CircuitBreaker("test")
        result = breaker.call_sync(lambda: "result")
        assert result == "result"

    def test_successful_call_resets_failure_count(self):
        breaker = CircuitBreaker("test", failure_threshold=3)

        # Two failures
        for _ in range(2):
            with pytest.raises(RuntimeError):
                breaker.call_sync(lambda: (_ for _ in ()).throw(RuntimeError()))

        # Success should reset
        breaker.call_sync(lambda: "success")

        # Two more failures should not trip (count reset)
        for _ in range(2):
            with pytest.raises(RuntimeError):
                breaker.call_sync(lambda: (_ for _ in ()).throw(RuntimeError()))

        assert breaker.is_closed

    def test_exception_propagates(self):
        breaker = CircuitBreaker("test", failure_threshold=10)

        with pytest.raises(ValueError) as exc_info:
            breaker.call_sync(self._raise_value_error)

        assert str(exc_info.value) == "custom error"

    @staticmethod
    def _raise_value_error():
        raise ValueError("custom error")


class TestCircuitBreakerAsync:
    """Tests for async call handling."""

    @pytest.mark.asyncio
    async def test_successful_async_call(self):
        breaker = CircuitBreaker("test")

        async def async_success():
            return "async result"

        result = await breaker.call_async(async_success)
        assert result == "async result"

    @pytest.mark.asyncio
    async def test_async_failure_trips_breaker(self):
        breaker = CircuitBreaker("test", failure_threshold=2)

        async def async_fail():
            raise RuntimeError("async error")

        for _ in range(2):
            with pytest.raises(RuntimeError):
                await breaker.call_async(async_fail)

        assert breaker.is_open

    @pytest.mark.asyncio
    async def test_async_circuit_open_rejects(self):
        breaker = CircuitBreaker("test", failure_threshold=1)

        async def async_fail():
            raise RuntimeError("async error")

        with pytest.raises(RuntimeError):
            await breaker.call_async(async_fail)

        with pytest.raises(CircuitBreakerOpen):
            await breaker.call_async(async_fail)


class TestCircuitBreakerCallbacks:
    """Tests for state change callbacks."""

    def test_callback_called_on_state_change(self):
        callback = Mock()
        breaker = CircuitBreaker(
            "test",
            failure_threshold=1,
            on_state_change=callback,
        )

        with pytest.raises(RuntimeError):
            breaker.call_sync(lambda: (_ for _ in ()).throw(RuntimeError()))

        callback.assert_called_once_with("test", CircuitState.OPEN)

    def test_callback_exception_does_not_break_breaker(self):
        def bad_callback(name, state):
            raise Exception("callback error")

        breaker = CircuitBreaker(
            "test",
            failure_threshold=1,
            on_state_change=bad_callback,
        )

        # Should not raise despite callback failure
        with pytest.raises(RuntimeError):
            breaker.call_sync(lambda: (_ for _ in ()).throw(RuntimeError()))

        assert breaker.is_open


class TestCircuitBreakerReset:
    """Tests for manual reset functionality."""

    def test_reset_closes_circuit(self):
        breaker = CircuitBreaker("test", failure_threshold=1)

        with pytest.raises(RuntimeError):
            breaker.call_sync(lambda: (_ for _ in ()).throw(RuntimeError()))

        assert breaker.is_open

        breaker.reset()
        assert breaker.is_closed

    def test_reset_clears_counts(self):
        breaker = CircuitBreaker("test", failure_threshold=3)

        # Two failures
        for _ in range(2):
            with pytest.raises(RuntimeError):
                breaker.call_sync(lambda: (_ for _ in ()).throw(RuntimeError()))

        breaker.reset()

        # Should need 3 more failures to trip
        for _ in range(2):
            with pytest.raises(RuntimeError):
                breaker.call_sync(lambda: (_ for _ in ()).throw(RuntimeError()))

        assert breaker.is_closed


class TestCircuitBreakerRegistry:
    """Tests for global circuit breaker registry."""

    def test_get_circuit_breaker_creates_new(self):
        breaker = get_circuit_breaker("new_service")
        assert breaker.name == "new_service"
        assert breaker.is_closed

    def test_get_circuit_breaker_returns_same_instance(self):
        breaker1 = get_circuit_breaker("service")
        breaker2 = get_circuit_breaker("service")
        assert breaker1 is breaker2

    def test_get_circuit_breaker_different_names_different_instances(self):
        breaker1 = get_circuit_breaker("service1")
        breaker2 = get_circuit_breaker("service2")
        assert breaker1 is not breaker2

    def test_get_all_circuit_breakers(self):
        get_circuit_breaker("s1")
        get_circuit_breaker("s2")

        all_breakers = get_all_circuit_breakers()
        assert "s1" in all_breakers
        assert "s2" in all_breakers

    def test_reset_circuit_breaker_by_name(self):
        breaker = get_circuit_breaker("service", failure_threshold=1)

        with pytest.raises(RuntimeError):
            breaker.call_sync(lambda: (_ for _ in ()).throw(RuntimeError()))

        assert breaker.is_open

        result = reset_circuit_breaker("service")
        assert result is True
        assert breaker.is_closed

    def test_reset_nonexistent_breaker(self):
        result = reset_circuit_breaker("nonexistent")
        assert result is False

    def test_clear_all_circuit_breakers(self):
        get_circuit_breaker("s1")
        get_circuit_breaker("s2")

        clear_all_circuit_breakers()

        all_breakers = get_all_circuit_breakers()
        assert len(all_breakers) == 0


class TestCircuitBreakerOpenException:
    """Tests for CircuitBreakerOpen exception."""

    def test_exception_attributes(self):
        exc = CircuitBreakerOpen("test_service", 30)
        assert exc.name == "test_service"
        assert exc.retry_in_seconds == 30
        assert "test_service" in str(exc)
        assert "30" in str(exc)
