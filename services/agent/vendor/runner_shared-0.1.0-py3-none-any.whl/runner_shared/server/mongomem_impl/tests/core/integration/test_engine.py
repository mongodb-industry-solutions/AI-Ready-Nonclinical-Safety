"""
Integration tests for MemoryEngine.

These tests verify end-to-end behavior of the MemoryEngine including
write_turn operations and bootstrap functionality.
"""

import pytest
from mongomem_core.memory.short_term import (
    get_stm_by_id,
    get_stm_by_session,
)


class TestMemoryEngineWriteTurn:
    """Integration tests for MemoryEngine.write_turn."""

    def test_write_turn_user_message(self, bootstrapped_engine):
        """Test writing a user message turn."""
        engine = bootstrapped_engine
        session_id = "test-session-1"
        org_id = "test-org-1"
        user_id = "test-user-1"

        result = engine.write_turn(
            session_id=session_id,
            role="user",
            content="Hello, how are you?",
            org_id=org_id,
            user_id=user_id,
        )

        assert result.acknowledged is True
        assert result.session_id == session_id
        assert result.turn_seq == 1

        # Verify document was created
        stm = get_stm_by_id(engine.db, result.id, org_id)
        assert stm is not None
        assert stm.content == "Hello, how are you?"
        assert stm.role == "user"

    def test_write_turn_assistant_message(self, bootstrapped_engine):
        """Test writing an assistant message turn."""
        engine = bootstrapped_engine
        session_id = "test-session-2"
        org_id = "test-org-1"
        user_id = "test-user-1"

        # Write user message first
        engine.write_turn(
            session_id=session_id,
            role="user",
            content="What's the weather?",
            org_id=org_id,
            user_id=user_id,
        )

        # Write assistant response
        result = engine.write_turn(
            session_id=session_id,
            role="assistant",
            content="I'm doing well, thank you!",
            agent_id="agent-1",
            model_name="gpt-4",
            tokens=10,
            org_id=org_id,
            user_id="agent-1",
        )

        assert result.turn_seq == 2

        # Verify assistant message
        stm = get_stm_by_id(engine.db, result.id, org_id)
        assert stm.role == "assistant"
        assert stm.agent_id == "agent-1"
        assert stm.model_name == "gpt-4"
        assert stm.tokens == 10

    def test_write_turn_with_tool_calls(self, bootstrapped_engine):
        """Test writing an assistant message with tool calls."""
        engine = bootstrapped_engine
        session_id = "test-session-3"
        org_id = "test-org-1"
        user_id = "test-user-1"

        result = engine.write_turn(
            session_id=session_id,
            user_id=user_id,
            role="assistant",
            content=None,
            tool_calls=[
                {
                    "name": "get_weather",
                    "arguments": {"city": "NYC"},
                    "id": "call_1",
                }
            ],
            org_id=org_id,
        )

        assert result.acknowledged is True

        # Verify tool calls were stored
        stm = get_stm_by_id(engine.db, result.id, org_id)
        assert stm.tool_calls is not None
        assert len(stm.tool_calls) == 1
        assert stm.tool_calls[0].name == "get_weather"

    def test_write_turn_tool_result(self, bootstrapped_engine):
        """Test writing a tool result message."""
        engine = bootstrapped_engine
        session_id = "test-session-4"
        org_id = "test-org-1"
        user_id = "test-user-1"

        result = engine.write_turn(
            session_id=session_id,
            user_id=user_id,
            role="tool",
            content="Temperature is 72°F, sunny",
            tool_call_id="call_1",
            tool_name="get_weather",
            org_id=org_id,
        )

        assert result.acknowledged is True

        # Verify tool result was stored
        stm = get_stm_by_id(engine.db, result.id, org_id)
        assert stm.role == "tool"
        assert stm.tool_call_id == "call_1"
        assert stm.tool_name == "get_weather"
        assert stm.content == "Temperature is 72°F, sunny"

    def test_write_turn_with_embedding(self, bootstrapped_engine):
        """Test writing a turn with a pre-computed embedding."""
        engine = bootstrapped_engine
        session_id = "test-session-5"
        org_id = "test-org-1"
        user_id = "test-user-1"

        embedding = [0.1] * 1024  # 1024-dimensional embedding

        result = engine.write_turn(
            session_id=session_id,
            role="user",
            content="Test message with embedding",
            org_id=org_id,
            user_id=user_id,
            embedding=embedding,
            embedding_model_id="test-model-v1",
        )

        assert result.acknowledged is True

        # Verify embedding was stored
        stm = get_stm_by_id(engine.db, result.id, org_id)
        assert stm.has_embedding is True
        assert stm.embedding == embedding

        # Verify embedding_model_id is stored in database (not in output model)
        from bson import ObjectId

        doc = engine.db.memory_short_term.find_one({"_id": ObjectId(result.id), "org_id": org_id})
        assert doc is not None
        assert doc["embedding_model_id"] == "test-model-v1"

    def test_write_turn_with_idempotency_key(self, bootstrapped_engine):
        """Test writing a turn with idempotency key prevents duplicates."""
        engine = bootstrapped_engine
        session_id = "test-session-6"
        org_id = "test-org-1"
        user_id = "test-user-1"
        idempotency_key = "unique-request-123"

        # First write
        result1 = engine.write_turn(
            session_id=session_id,
            role="user",
            content="Idempotent message",
            org_id=org_id,
            user_id=user_id,
            idempotency_key=idempotency_key,
        )

        # Second write with same key should create same document
        result2 = engine.write_turn(
            session_id=session_id,
            role="user",
            content="Idempotent message",
            org_id=org_id,
            user_id=user_id,
            idempotency_key=idempotency_key,
        )

        # Should have same idempotency hash (stored in database, not in output model)
        from bson import ObjectId

        doc1 = engine.db.memory_short_term.find_one({"_id": ObjectId(result1.id), "org_id": org_id})
        doc2 = engine.db.memory_short_term.find_one({"_id": ObjectId(result2.id), "org_id": org_id})
        assert doc1 is not None
        assert doc2 is not None
        assert doc1["idempotency_hash"] == doc2["idempotency_hash"]

    def test_write_turn_conversation_flow(self, bootstrapped_engine):
        """Test writing a complete conversation flow."""
        engine = bootstrapped_engine
        session_id = "test-session-7"
        org_id = "test-org-1"
        user_id = "test-user-1"

        # User message
        user_result = engine.write_turn(
            session_id=session_id,
            role="user",
            content="What's the weather in NYC?",
            org_id=org_id,
            user_id=user_id,
        )

        # Assistant with tool call
        assistant_result = engine.write_turn(
            session_id=session_id,
            role="assistant",
            content=None,
            tool_calls=[{"name": "get_weather", "arguments": {"city": "NYC"}, "id": "call_1"}],
            org_id=org_id,
            user_id="agent-1",
        )

        # Tool result
        tool_result = engine.write_turn(
            session_id=session_id,
            role="tool",
            content="72°F, sunny",
            tool_call_id="call_1",
            tool_name="get_weather",
            org_id=org_id,
            user_id="system",
        )

        # Final assistant response
        final_result = engine.write_turn(
            session_id=session_id,
            role="assistant",
            content="The weather in NYC is 72°F and sunny.",
            org_id=org_id,
            user_id="agent-1",
        )

        # Verify all turns are in sequence
        assert user_result.turn_seq == 1
        assert assistant_result.turn_seq == 2
        assert tool_result.turn_seq == 3
        assert final_result.turn_seq == 4

        # Verify all turns are retrievable
        all_turns = get_stm_by_session(engine.db, session_id, org_id)
        assert len(all_turns) == 4


class TestMemoryEngineBootstrap:
    """Integration tests for MemoryEngine.bootstrap."""

    def test_bootstrap_creates_collections(self, test_engine):
        """Test that bootstrap creates all required collections."""
        engine = test_engine

        # Verify collections don't exist yet (or are empty)
        collections_before = set(engine.db.list_collection_names())

        # Bootstrap
        engine.bootstrap(ensure_search_indexes=False)

        # Verify collections exist
        collections_after = set(engine.db.list_collection_names())
        assert len(collections_after) >= len(collections_before)

        # Verify key collections exist
        expected_collections = [
            "memory_short_term",
            "memory_episodic",
            "memory_semantic",
            "memory_user_context",
        ]
        for col_name in expected_collections:
            assert col_name in collections_after

    def test_bootstrap_creates_indexes(self, test_engine):
        """Test that bootstrap creates required indexes."""
        engine = test_engine

        # Bootstrap
        engine.bootstrap(ensure_search_indexes=False)

        # Verify indexes exist on key collections
        stm_indexes = engine.db.memory_short_term.index_information()
        assert len(stm_indexes) > 1  # Should have at least _id_ and one custom index

        # Verify session_id index exists
        assert any("session_id" in str(index) for index in stm_indexes.values())

    def test_bootstrap_idempotent(self, test_engine):
        """Test that bootstrap can be called multiple times safely."""
        engine = test_engine

        # First bootstrap
        engine.bootstrap(ensure_search_indexes=False)
        collections_first = set(engine.db.list_collection_names())

        # Second bootstrap
        engine.bootstrap(ensure_search_indexes=False)
        collections_second = set(engine.db.list_collection_names())

        # Should be the same
        assert collections_first == collections_second

    def test_bootstrap_with_search_indexes(self, test_engine):
        """Test bootstrap with search indexes (may skip if not available)."""
        engine = test_engine

        # Bootstrap with search indexes
        # This may fail if MongoDB Atlas Search is not available, which is OK
        try:
            engine.bootstrap(ensure_search_indexes=True)
        except Exception:
            # Search indexes require Atlas, so failure is acceptable in local tests
            pytest.skip("Search indexes not available (requires Atlas)")
