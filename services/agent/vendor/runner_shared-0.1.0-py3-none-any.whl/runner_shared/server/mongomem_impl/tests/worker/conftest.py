import asyncio
import os
import random
import string
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Dict, Generator, List, Optional

import pytest
from mongomem_core import MemoryEngine
from mongomem_core.config import Settings
from pymongo import MongoClient
from pymongo.database import Database

# Test MongoDB URI - use local by default, can override with env var
TEST_MONGO_URI = os.environ.get("TEST_MONGO_URI", "mongodb://localhost:27017")


def random_db_name() -> str:
    """Generate a random database name for test isolation."""
    suffix = "".join(random.choices(string.ascii_lowercase, k=8))
    return f"test_mongomem_worker_{suffix}"


class MockEmbedder:
    """
    Mock embedder for testing.

    Returns deterministic embeddings based on text hash.
    """

    def __init__(self, dimension: int = 1024):
        self._dimension = dimension
        self._call_count = 0
        self._batch_call_count = 0

    def embed(self, text: str) -> List[float]:
        self._call_count += 1
        return self._generate_embedding(text)

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        self._batch_call_count += 1
        return [self._generate_embedding(t) for t in texts]

    @property
    def dimension(self) -> int:
        return self._dimension

    @property
    def model_id(self) -> str:
        return "mock-embedder-v1"

    def _generate_embedding(self, text: str) -> List[float]:
        """Generate deterministic embedding from text."""
        import hashlib

        h = hashlib.sha256(text.encode()).hexdigest()
        # Use hash to seed random generator for reproducibility
        rng = random.Random(h)
        return [rng.uniform(-1, 1) for _ in range(self._dimension)]

    @property
    def call_count(self) -> int:
        return self._call_count

    @property
    def batch_call_count(self) -> int:
        return self._batch_call_count

    def reset_counts(self) -> None:
        self._call_count = 0
        self._batch_call_count = 0


class MockLLM:
    """
    Mock LLM for testing extractions.

    Returns canned responses or can be configured with custom responses.
    """

    def __init__(self):
        self._call_count = 0
        self._responses: Dict[str, str] = {}
        self._json_responses: Dict[str, Dict] = {}
        self._default_response = "Mock LLM response"
        self._default_json = {"extracted": True, "entities": []}

    def complete(self, prompt: str, **kwargs) -> str:
        self._call_count += 1
        # Check for configured response
        for key, response in self._responses.items():
            if key in prompt:
                return response
        return self._default_response

    def complete_json(self, prompt: str, schema: Dict, **kwargs) -> Dict:
        self._call_count += 1
        # Check for configured JSON response
        for key, response in self._json_responses.items():
            if key in prompt:
                return response
        return self._default_json.copy()

    def set_response(self, key: str, response: str) -> None:
        """Configure response when prompt contains key."""
        self._responses[key] = response

    def set_json_response(self, key: str, response: Dict) -> None:
        """Configure JSON response when prompt contains key."""
        self._json_responses[key] = response

    @property
    def call_count(self) -> int:
        return self._call_count

    def reset(self) -> None:
        self._call_count = 0
        self._responses.clear()
        self._json_responses.clear()


class FailingEmbedder:
    """Embedder that fails after N successful calls."""

    def __init__(self, fail_after: int = 0, error_type: str = "transient"):
        self._dimension = 1024
        self._call_count = 0
        self._fail_after = fail_after
        self._error_type = error_type

    def embed(self, text: str) -> List[float]:
        self._call_count += 1
        if self._call_count > self._fail_after:
            if self._error_type == "transient":
                raise ConnectionError("Network timeout")
            else:
                raise ValueError("Invalid input")
        return [0.1] * self._dimension

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        return [self.embed(t) for t in texts]

    @property
    def dimension(self) -> int:
        return self._dimension

    @property
    def model_id(self) -> str:
        return "failing-embedder"


class RecordingMetrics:
    """
    Observability implementation that records all calls for assertions.

    Implements ObservabilityProtocol interface for testing.

    Example:
        def test_something(recording_metrics):
            metrics = WorkerMetrics(backend=recording_metrics)
            metrics.task_claimed("embedding")

            assert len(recording_metrics.get_increments("tasks_claimed")) == 1
            assert len(recording_metrics.get_events("mongomem.worker.task.claimed")) == 1
    """

    def __init__(self) -> None:
        self.increments: List[Dict[str, Any]] = []
        self.gauges: List[Dict[str, Any]] = []
        self.histograms: List[Dict[str, Any]] = []
        self.timings: List[Dict[str, Any]] = []
        self.spans: List[Dict[str, Any]] = []
        self.events: List[Dict[str, Any]] = []

    def increment(
        self, name: str, value: float = 1.0, tags: Optional[Dict[str, str]] = None
    ) -> None:
        self.increments.append({"name": name, "value": value, "tags": tags or {}})

    def gauge(self, name: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        self.gauges.append({"name": name, "value": value, "tags": tags or {}})

    def histogram(self, name: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        self.histograms.append({"name": name, "value": value, "tags": tags or {}})

    def timing(self, name: str, value_ms: float, tags: Optional[Dict[str, str]] = None) -> None:
        self.timings.append({"name": name, "value_ms": value_ms, "tags": tags or {}})

    @contextmanager
    def span(
        self,
        name: str,
        *,
        kind: str = "internal",
        attributes: Optional[Dict[str, Any]] = None,
    ) -> Generator[Dict[str, Any], None, None]:
        """Create a traced span (recorded for assertions)."""
        span_record = {
            "name": name,
            "kind": kind,
            "attributes": dict(attributes) if attributes else {},
            "completed": False,
        }
        self.spans.append(span_record)
        try:
            yield span_record["attributes"]
        finally:
            span_record["completed"] = True

    def event(
        self,
        name: str,
        *,
        attributes: Optional[Dict[str, Any]] = None,
        level: str = "info",
    ) -> None:
        """Emit a structured event (recorded for assertions)."""
        self.events.append({"name": name, "attributes": attributes or {}, "level": level})

    # Query helpers for assertions
    def get_increments(self, name: str) -> List[Dict[str, Any]]:
        """Get all increment calls matching the given metric name."""
        return [i for i in self.increments if i["name"] == name]

    def get_gauges(self, name: str) -> List[Dict[str, Any]]:
        """Get all gauge calls matching the given metric name."""
        return [g for g in self.gauges if g["name"] == name]

    def get_histograms(self, name: str) -> List[Dict[str, Any]]:
        """Get all histogram calls matching the given metric name."""
        return [h for h in self.histograms if h["name"] == name]

    def get_timings(self, name: str) -> List[Dict[str, Any]]:
        """Get all timing calls matching the given metric name."""
        return [t for t in self.timings if t["name"] == name]

    def get_spans(self, name: str) -> List[Dict[str, Any]]:
        """Get all spans matching the given span name."""
        return [s for s in self.spans if s["name"] == name]

    def get_events(self, name: str) -> List[Dict[str, Any]]:
        """Get all events matching the given event name."""
        return [e for e in self.events if e["name"] == name]

    def reset(self) -> None:
        """Clear all recorded data. Useful for multi-phase tests."""
        self.increments.clear()
        self.gauges.clear()
        self.histograms.clear()
        self.timings.clear()
        self.spans.clear()
        self.events.clear()

    # Alias for compatibility with older tests
    def clear(self) -> None:
        """Alias for reset()."""
        self.reset()


@pytest.fixture
def mock_embedder() -> MockEmbedder:
    return MockEmbedder()


@pytest.fixture
def mock_llm() -> MockLLM:
    return MockLLM()


@pytest.fixture
def recording_metrics() -> RecordingMetrics:
    return RecordingMetrics()


@pytest.fixture
def failing_embedder() -> FailingEmbedder:
    return FailingEmbedder(fail_after=0)


@pytest.fixture
def mongo_client() -> MongoClient:
    client = MongoClient(TEST_MONGO_URI)
    yield client
    client.close()


@pytest.fixture
def test_db(mongo_client: MongoClient) -> Database:
    db_name = random_db_name()
    db = mongo_client[db_name]
    yield db
    mongo_client.drop_database(db_name)


@pytest.fixture
def test_db_name() -> str:
    return random_db_name()


@pytest.fixture
def test_engine(test_db_name: str, mock_embedder: MockEmbedder) -> MemoryEngine:
    """Provide a MemoryEngine with test database and mock embedder."""
    settings = Settings(
        mongo_uri=TEST_MONGO_URI,
        db_name=test_db_name,
        embedding_dimension=mock_embedder.dimension,
    )
    return MemoryEngine(settings, embedder=mock_embedder)


@pytest.fixture
def test_engine_with_llm(
    test_db_name: str, mock_embedder: MockEmbedder, mock_llm: MockLLM
) -> MemoryEngine:
    """Provide a MemoryEngine with test database, mock embedder, and mock LLM."""
    settings = Settings(
        mongo_uri=TEST_MONGO_URI,
        db_name=test_db_name,
        embedding_dimension=mock_embedder.dimension,
    )
    return MemoryEngine(settings, embedder=mock_embedder, llm=mock_llm)


@pytest.fixture
def event_loop():
    """Create an event loop for async tests."""
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


def make_stm_document(
    session_id: str = "test-session",
    user_id: str = "test-user",
    org_id: str = "test-org",
    content: str = "Test message content",
    role: str = "user",
    **kwargs,
) -> Dict[str, Any]:
    """Create a test STM document."""
    from bson import ObjectId

    doc = {
        "_id": ObjectId(),  # Use ObjectId for compatibility with core functions
        "session_id": session_id,
        "user_id": user_id,
        "org_id": org_id,
        "content": content,
        "role": role,
        "visibility": kwargs.get("visibility", "private"),
        "created_at": datetime.now(timezone.utc),
        "updated_at": datetime.now(timezone.utc),
    }
    doc.update(kwargs)
    return doc


def make_task_document(
    task_type: str = "embedding",
    payload: Optional[Dict] = None,
    **kwargs,
) -> Dict[str, Any]:
    """Create a test task document."""
    from ulid import ULID

    doc = {
        "_id": f"task:{ULID()}",
        "task_type": task_type,
        "payload": payload or {"doc_id": "test-doc"},
        "status": kwargs.get("status", "queued"),
        "priority": kwargs.get("priority", 0),
        "created_at": datetime.now(timezone.utc),
        "updated_at": datetime.now(timezone.utc),
        "worker_id": kwargs.get("worker_id"),
        "lease_expires_at": kwargs.get("lease_expires_at"),
        "attempts": kwargs.get("attempts", 0),
        "max_retries": kwargs.get("max_retries", 3),
    }
    doc.update(kwargs)
    return doc


def make_semantic_document(
    label: str = "test-fact",
    content: str = "This is a test semantic memory.",
    user_id: str = "test-user",
    org_id: str = "test-org",
    has_embedding: bool = False,
    **kwargs,
) -> Dict[str, Any]:
    """Create a test semantic memory document."""
    from bson import ObjectId

    doc = {
        "_id": ObjectId(),
        "label": label,
        "content": content,
        "user_id": user_id,
        "org_id": org_id,
        "visibility": kwargs.get("visibility", "private"),
        "has_embedding": has_embedding,
        "timestamp": datetime.now(timezone.utc),
        "created_at": datetime.now(timezone.utc),
        "updated_at": datetime.now(timezone.utc),
    }
    doc.update(kwargs)
    return doc


def make_episodic_document(
    title: str = "Test Episode",
    content: str = "This is a test episodic memory.",
    user_id: str = "test-user",
    org_id: str = "test-org",
    has_embedding: bool = False,
    **kwargs,
) -> Dict[str, Any]:
    """Create a test episodic memory document."""
    from bson import ObjectId

    doc = {
        "_id": ObjectId(),
        "title": title,
        "content": content,
        "summary_text": kwargs.get("summary_text", content[:100]),
        "summary_type": kwargs.get("summary_type", "heuristic"),
        "user_id": user_id,
        "org_id": org_id,
        "visibility": kwargs.get("visibility", "private"),
        "has_embedding": has_embedding,
        "timestamp": datetime.now(timezone.utc),
        "created_at": datetime.now(timezone.utc),
        "updated_at": datetime.now(timezone.utc),
    }
    doc.update(kwargs)
    return doc
