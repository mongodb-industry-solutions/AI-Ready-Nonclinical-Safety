"""
Tests for document extractors.

Tests the PlainTextExtractor, PyMuPDFExtractor, PythonPPTXExtractor, and PythonDocxExtractor.
"""

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest


class TestPlainTextExtractor:
    """Tests for PlainTextExtractor."""

    def test_supported_extensions(self):
        """Test that .txt is supported."""
        from mongomem_core.ingest.extractors.text import (
            PlainTextExtractor,
        )

        extractor = PlainTextExtractor()
        assert ".txt" in extractor.supported_extensions

    def test_extract_simple_text(self, tmp_path: Path):
        """Test extracting text from a simple .txt file."""
        from mongomem_core.ingest.extractors.text import (
            PlainTextExtractor,
        )

        # Create a test file
        test_file = tmp_path / "test.txt"
        test_content = "Hello, World!\nThis is a test file."
        test_file.write_text(test_content)

        extractor = PlainTextExtractor()
        result = extractor.extract(test_file)

        assert result == test_content

    def test_extract_with_metadata(self, tmp_path: Path):
        """Test extracting text with metadata."""
        from mongomem_core.ingest.extractors.text import (
            PlainTextExtractor,
        )

        test_file = tmp_path / "test.txt"
        test_content = "Sample content for metadata test."
        test_file.write_text(test_content)

        extractor = PlainTextExtractor()
        result = extractor.extract_with_metadata(test_file)

        assert result["text"] == test_content
        assert result["metadata"]["source_type"] == "txt"
        assert result["metadata"]["char_count"] == len(test_content)

    def test_extract_unicode_content(self, tmp_path: Path):
        """Test extracting text with Unicode characters."""
        from mongomem_core.ingest.extractors.text import (
            PlainTextExtractor,
        )

        test_file = tmp_path / "unicode.txt"
        test_content = "Hello 世界! Привет мир! 🌍"
        test_file.write_text(test_content, encoding="utf-8")

        extractor = PlainTextExtractor()
        result = extractor.extract(test_file)

        assert result == test_content

    def test_extract_empty_file(self, tmp_path: Path):
        """Test extracting from an empty file."""
        from mongomem_core.ingest.extractors.text import (
            PlainTextExtractor,
        )

        test_file = tmp_path / "empty.txt"
        test_file.write_text("")

        extractor = PlainTextExtractor()
        result = extractor.extract(test_file)

        assert result == ""


class TestPyMuPDFExtractor:
    """Tests for PyMuPDFExtractor."""

    def test_supported_extensions(self):
        """Test that .pdf is supported."""
        from mongomem_core.ingest.extractors.pdf import (
            PyMuPDFExtractor,
        )

        extractor = PyMuPDFExtractor()
        assert ".pdf" in extractor.supported_extensions

    def test_extract_with_metadata_includes_page_boundaries(self, tmp_path: Path):
        """Test that PDF extraction includes page boundaries."""
        pdf_path = tmp_path / "test.pdf"
        repo_root = Path(__file__).resolve().parents[4]
        code = f"""
import json
from pathlib import Path

import fitz

from mongomem_core.ingest.extractors.pdf import PyMuPDFExtractor

pdf_path = Path(r\"{pdf_path}\")
doc = fitz.open()
page = doc.new_page()
page.insert_text((50, 50), \"Page 1 content\")
page2 = doc.new_page()
page2.insert_text((50, 50), \"Page 2 content\")
doc.save(str(pdf_path))
doc.close()

extractor = PyMuPDFExtractor()
result = extractor.extract_with_metadata(pdf_path)
print(json.dumps(result))
"""
        env = os.environ.copy()
        env["PYTHONWARNINGS"] = "ignore"
        env["PYTHONPATH"] = str(repo_root / "src")
        completed = subprocess.run(
            [sys.executable, "-c", code],
            cwd=repo_root,
            env=env,
            check=True,
            capture_output=True,
            text=True,
        )
        result = json.loads(completed.stdout.strip())

        assert "text" in result
        assert "Page 1 content" in result["text"]
        assert "Page 2 content" in result["text"]
        assert result["metadata"]["page_count"] == 2
        assert "page_boundaries" in result
        assert len(result["page_boundaries"]) == 2


class TestPythonPPTXExtractor:
    """Tests for PythonPPTXExtractor."""

    def test_supported_extensions(self):
        """Test that .pptx is supported."""
        from mongomem_core.ingest.extractors.pptx import (
            PythonPPTXExtractor,
        )

        extractor = PythonPPTXExtractor()
        assert ".pptx" in extractor.supported_extensions

    def test_extract_from_pptx(self, tmp_path: Path):
        """Test extracting text from a PPTX file."""
        from mongomem_core.ingest.extractors.pptx import (
            PythonPPTXExtractor,
        )
        from pptx import Presentation
        from pptx.util import Inches

        # Create a test PPTX
        pptx_path = tmp_path / "test.pptx"
        prs = Presentation()
        slide = prs.slides.add_slide(prs.slide_layouts[5])  # Blank layout
        # Add a text box
        left = top = Inches(1)
        width = height = Inches(2)
        txBox = slide.shapes.add_textbox(left, top, width, height)
        txBox.text_frame.text = "Slide 1 Content"
        prs.save(str(pptx_path))

        extractor = PythonPPTXExtractor()
        result = extractor.extract(pptx_path)

        assert "Slide 1 Content" in result

    def test_extract_with_metadata(self, tmp_path: Path):
        """Test extracting with metadata from PPTX."""
        from mongomem_core.ingest.extractors.pptx import (
            PythonPPTXExtractor,
        )
        from pptx import Presentation
        from pptx.util import Inches

        pptx_path = tmp_path / "test.pptx"
        prs = Presentation()
        # Add 2 slides
        for i in range(2):
            slide = prs.slides.add_slide(prs.slide_layouts[5])
            txBox = slide.shapes.add_textbox(Inches(1), Inches(1), Inches(2), Inches(1))
            txBox.text_frame.text = f"Slide {i + 1}"
        prs.save(str(pptx_path))

        extractor = PythonPPTXExtractor()
        result = extractor.extract_with_metadata(pptx_path)

        assert result["metadata"]["slide_count"] == 2
        assert result["metadata"]["source_type"] == "pptx"


class TestPythonDocxExtractor:
    """Tests for PythonDocxExtractor."""

    def test_supported_extensions(self):
        """Test that .docx is supported."""
        from mongomem_core.ingest.extractors.docx import (
            PythonDocxExtractor,
        )

        extractor = PythonDocxExtractor()
        assert ".docx" in extractor.supported_extensions

    def test_extract_from_docx(self, tmp_path: Path):
        """Test extracting text from a DOCX file."""
        from docx import Document
        from mongomem_core.ingest.extractors.docx import (
            PythonDocxExtractor,
        )

        # Create a test DOCX
        docx_path = tmp_path / "test.docx"
        doc = Document()
        doc.add_paragraph("First paragraph.")
        doc.add_paragraph("Second paragraph.")
        doc.save(str(docx_path))

        extractor = PythonDocxExtractor()
        result = extractor.extract(docx_path)

        assert "First paragraph." in result
        assert "Second paragraph." in result

    def test_extract_with_metadata(self, tmp_path: Path):
        """Test extracting with metadata from DOCX."""
        from docx import Document
        from mongomem_core.ingest.extractors.docx import (
            PythonDocxExtractor,
        )

        docx_path = tmp_path / "test.docx"
        doc = Document()
        doc.add_paragraph("Para 1")
        doc.add_paragraph("Para 2")
        doc.add_paragraph("Para 3")
        doc.save(str(docx_path))

        extractor = PythonDocxExtractor()
        result = extractor.extract_with_metadata(docx_path)

        assert result["metadata"]["source_type"] == "docx"
        # paragraph_count includes empty paragraphs, so check it exists
        assert "paragraph_count" in result["metadata"]


class TestExtractorRegistry:
    """Tests for the extractor registry/factory."""

    def test_get_extractor_for_txt(self, tmp_path: Path):
        """Test getting the correct extractor for .txt files."""
        from mongomem_core.ingest.models import ExtractorType
        from mongomem_core.ingest.pipeline import (
            get_extractor_for_file,
        )

        txt_file = tmp_path / "test.txt"
        txt_file.touch()

        extractor = get_extractor_for_file(txt_file, ExtractorType.SIMPLE)
        assert extractor.__class__.__name__ == "PlainTextExtractor"

    def test_get_extractor_for_pdf(self, tmp_path: Path):
        """Test getting the correct extractor for .pdf files."""
        from mongomem_core.ingest.models import ExtractorType
        from mongomem_core.ingest.pipeline import (
            get_extractor_for_file,
        )

        pdf_file = tmp_path / "test.pdf"
        pdf_file.touch()

        extractor = get_extractor_for_file(pdf_file, ExtractorType.SIMPLE)
        assert extractor.__class__.__name__ == "PyMuPDFExtractor"

    def test_get_extractor_for_unsupported(self, tmp_path: Path):
        """Test that unsupported extensions raise ValueError."""
        from mongomem_core.ingest.models import ExtractorType
        from mongomem_core.ingest.pipeline import (
            get_extractor_for_file,
        )

        xlsx_file = tmp_path / "test.xlsx"
        xlsx_file.touch()

        with pytest.raises(ValueError, match="Unsupported file type"):
            get_extractor_for_file(xlsx_file, ExtractorType.SIMPLE)
