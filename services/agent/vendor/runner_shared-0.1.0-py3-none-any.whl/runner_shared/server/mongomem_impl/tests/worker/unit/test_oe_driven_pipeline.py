"""
Tests for the OE-driven STM→Snapshot→[Semantic, Episodic] pipeline.

Covers:
- SnapshotHandler: on_snapshot_created callback wiring and error isolation
- SnapshotHandler: embed-before-promote behaviour (AP-2259)
- WorkerConfig: snapshot_config field
- MongoMemWorker: initialize(), snapshot_config + auto_extract_on_snapshot params
- /worker/processTasks endpoint: drain loop, no-worker case, iteration cap
- main.py: provider detection, LLM adapter, create_worker()
"""

from __future__ import annotations

from typing import Any, Dict
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_snapshot_doc(**kwargs) -> Dict[str, Any]:
    from bson import ObjectId

    return {
        "_id": ObjectId(),
        "org_id": "org-1",
        "user_id": "user-1",
        "session_id": "sess-1",
        "messages": [
            {"role": "user", "content": "Hello world"},
            {"role": "assistant", "content": "Hi there"},
        ],
        **kwargs,
    }


def _make_mock_snapshot(**kwargs):
    """Return a mock SnapshotDB-like object."""
    snap = MagicMock()
    snap.id = kwargs.get("id", "snap-123")
    snap.messages = kwargs.get(
        "messages",
        [MagicMock(role="user", content="Hello"), MagicMock(role="assistant", content="Hi")],
    )
    snap.model_dump = MagicMock(
        return_value={
            "_id": snap.id,
            "org_id": "org-1",
            "user_id": "user-1",
            "messages": [
                {"role": "user", "content": "Hello"},
                {"role": "assistant", "content": "Hi"},
            ],
        }
    )
    return snap


# ===========================================================================
# 1. SnapshotHandler – on_snapshot_created callback
# ===========================================================================


class TestSnapshotHandlerCallback:
    """Tests for on_snapshot_created wiring in SnapshotHandler."""

    def _make_handler(self, callback=None, embedding_handler=None):
        from runner_shared.server.mongomem_impl.src.mongomem_worker.handlers.snapshots import (
            SnapshotHandler,
        )

        mock_db = MagicMock()
        mock_embedder = MagicMock()
        mock_embedder.dimension = 1024
        mock_embedder.model_id = "mock-embedder"

        from mongomem_core.models.config.snapshot_config import (
            SnapshotConfig,
        )

        config = SnapshotConfig(strategy="auto", embedding_strategy="defer", max_messages=5)
        return SnapshotHandler(
            db=mock_db,
            embedder=mock_embedder,
            config=config,
            on_snapshot_created=callback,
            embedding_handler=embedding_handler,
        )

    def test_callback_stored_on_init(self):
        callback = MagicMock()
        handler = self._make_handler(callback)
        assert handler._on_snapshot_created is callback

    def test_no_callback_stored_when_none(self):
        handler = self._make_handler(None)
        assert handler._on_snapshot_created is None

    @pytest.mark.asyncio
    async def test_callback_fires_after_promotion(self):
        """Callback is called with snapshot.model_dump() after successful promotion."""
        callback = MagicMock()
        handler = self._make_handler(callback)
        mock_snapshot = _make_mock_snapshot()

        with (
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.promote_stm_to_snapshot",
                return_value=mock_snapshot,
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.memory.short_term.get_stm_raw_docs",
                return_value=[{"role": "user", "content": "hi"} for _ in range(5)],
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.should_promote",
                return_value=(True, "message_count"),
            ),
        ):
            await handler._check_and_promote(
                {"session_id": "sess-1", "org_id": "org-1", "user_id": "user-1"}
            )

        callback.assert_called_once()
        call_arg = callback.call_args[0][0]
        assert call_arg == mock_snapshot.model_dump.return_value
        mock_snapshot.model_dump.assert_called_once_with(mode="python", by_alias=True)

    @pytest.mark.asyncio
    async def test_callback_not_fired_when_no_promotion(self):
        """Callback is NOT called when threshold is not met."""
        callback = MagicMock()
        handler = self._make_handler(callback)

        with (
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.memory.short_term.get_stm_raw_docs",
                return_value=[{"role": "user", "content": "hi"}],
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.should_promote",
                return_value=(False, "none"),
            ),
        ):
            await handler._check_and_promote(
                {"session_id": "sess-1", "org_id": "org-1", "user_id": "user-1"}
            )

        callback.assert_not_called()

    @pytest.mark.asyncio
    async def test_callback_exception_does_not_propagate(self):
        """An exception in the callback is caught and does not raise from _check_and_promote."""
        callback = MagicMock(side_effect=RuntimeError("boom"))
        handler = self._make_handler(callback)
        mock_snapshot = _make_mock_snapshot()

        with (
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.promote_stm_to_snapshot",
                return_value=mock_snapshot,
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.memory.short_term.get_stm_raw_docs",
                return_value=[{"role": "user", "content": "hi"} for _ in range(5)],
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.should_promote",
                return_value=(True, "message_count"),
            ),
        ):
            # Must not raise
            await handler._check_and_promote(
                {"session_id": "sess-1", "org_id": "org-1", "user_id": "user-1"}
            )

        callback.assert_called_once()

    @pytest.mark.asyncio
    async def test_no_callback_when_promote_returns_none(self):
        """Callback is not called when promote_stm_to_snapshot returns None."""
        callback = MagicMock()
        handler = self._make_handler(callback)

        with (
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.promote_stm_to_snapshot",
                return_value=None,
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.memory.short_term.get_stm_raw_docs",
                return_value=[{"role": "user", "content": "hi"} for _ in range(5)],
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.should_promote",
                return_value=(True, "message_count"),
            ),
        ):
            await handler._check_and_promote(
                {"session_id": "sess-1", "org_id": "org-1", "user_id": "user-1"}
            )

        callback.assert_not_called()


# ===========================================================================
# 2. SnapshotHandler – embed-before-promote (AP-2259)
# ===========================================================================


class TestEmbedBeforePromote:
    """_check_and_promote embeds unembedded STM docs before evaluating thresholds."""

    def _make_handler(self, embedding_handler=None):
        from mongomem_core.models.config.snapshot_config import SnapshotConfig

        from runner_shared.server.mongomem_impl.src.mongomem_worker.handlers.snapshots import (
            SnapshotHandler,
        )

        mock_db = MagicMock()
        mock_embedder = MagicMock()
        mock_embedder.dimension = 1024
        mock_embedder.model_id = "mock-embedder"
        config = SnapshotConfig(strategy="auto", embedding_strategy="generate", max_messages=5)
        return SnapshotHandler(
            db=mock_db,
            embedder=mock_embedder,
            config=config,
            embedding_handler=embedding_handler,
        )

    @pytest.mark.asyncio
    async def test_embed_stm_called_before_threshold_check(self):
        """embed_stm_docs_for_session is called before should_promote when embedding_handler set."""
        call_order = []

        mock_embedding_handler = MagicMock()

        async def mock_embed(session_id, org_id, user_id=None, project_id=None):
            call_order.append("embed")
            return 2

        mock_embedding_handler.embed_stm_docs_for_session = mock_embed

        handler = self._make_handler(embedding_handler=mock_embedding_handler)
        mock_snapshot = _make_mock_snapshot()

        stm_docs = [{"role": "user", "content": "hi", "has_embedding": False} for _ in range(5)]

        with (
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.memory.short_term.get_stm_raw_docs",
                return_value=stm_docs,
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.should_promote",
                side_effect=lambda *a, **kw: (
                    call_order.append("should_promote"),
                    (True, "message_count"),
                )[1],
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.promote_stm_to_snapshot",
                return_value=mock_snapshot,
            ),
        ):
            await handler._check_and_promote(
                {"session_id": "sess-1", "org_id": "org-1", "user_id": "user-1"}
            )

        assert call_order == ["embed", "should_promote"]

    @pytest.mark.asyncio
    async def test_stm_docs_refetched_after_embedding(self):
        """STM docs are re-fetched after embedding so fresh embeddings reach should_promote."""
        fetch_calls = []

        mock_embedding_handler = MagicMock()
        mock_embedding_handler.embed_stm_docs_for_session = MagicMock(return_value=None)

        async def async_embed(session_id, org_id, user_id=None, project_id=None):
            return 1

        mock_embedding_handler.embed_stm_docs_for_session = async_embed

        handler = self._make_handler(embedding_handler=mock_embedding_handler)

        stm_docs_first = [{"role": "user", "content": "hi", "has_embedding": False}] * 5
        stm_docs_second = [
            {"role": "user", "content": "hi", "embedding": [0.1] * 4, "has_embedding": True}
        ] * 5

        def mock_get_stm(*args, **kwargs):
            fetch_calls.append(1)
            return stm_docs_first if len(fetch_calls) == 1 else stm_docs_second

        mock_snapshot = _make_mock_snapshot()

        with (
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.memory.short_term.get_stm_raw_docs",
                side_effect=mock_get_stm,
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.should_promote",
                return_value=(True, "message_count"),
            ) as mock_should_promote,
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.promote_stm_to_snapshot",
                return_value=mock_snapshot,
            ),
        ):
            await handler._check_and_promote(
                {"session_id": "sess-1", "org_id": "org-1", "user_id": "user-1"}
            )

        # should_promote received the second (re-fetched) docs
        assert fetch_calls == [1, 1]
        actual_docs = mock_should_promote.call_args[0][0]
        assert actual_docs == stm_docs_second

    @pytest.mark.asyncio
    async def test_no_embed_when_no_embedding_handler(self):
        """should_promote is called directly when no embedding_handler is set."""
        handler = self._make_handler(embedding_handler=None)
        mock_snapshot = _make_mock_snapshot()

        stm_docs = [{"role": "user", "content": "hi"} for _ in range(5)]

        with (
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.memory.short_term.get_stm_raw_docs",
                return_value=stm_docs,
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.should_promote",
                return_value=(True, "message_count"),
            ) as mock_should_promote,
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.promote_stm_to_snapshot",
                return_value=mock_snapshot,
            ),
        ):
            await handler._check_and_promote(
                {"session_id": "sess-1", "org_id": "org-1", "user_id": "user-1"}
            )

        mock_should_promote.assert_called_once()

    @pytest.mark.asyncio
    async def test_message_count_reason_evaluates_thresholds_locally(self):
        """OE reason=message_count still calls should_promote locally."""
        handler = self._make_handler(embedding_handler=None)
        mock_snapshot = _make_mock_snapshot()

        stm_docs = [{"role": "user", "content": "hi"} for _ in range(5)]

        with (
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.memory.short_term.get_stm_raw_docs",
                return_value=stm_docs,
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.should_promote",
                return_value=(True, "message_count"),
            ) as mock_should_promote,
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.promote_stm_to_snapshot",
                return_value=mock_snapshot,
            ),
        ):
            await handler._check_and_promote(
                {
                    "session_id": "sess-1",
                    "org_id": "org-1",
                    "user_id": "user-1",
                    "reason": "message_count",
                }
            )

        mock_should_promote.assert_called_once()

    @pytest.mark.asyncio
    async def test_idle_session_reason_bypasses_threshold(self):
        """OE reason=idle_session bypasses should_promote — time-based, worker cannot re-evaluate."""
        callback = MagicMock()
        handler = self._make_handler(embedding_handler=None)
        handler._on_snapshot_created = callback
        mock_snapshot = _make_mock_snapshot()

        # Only 2 docs — below any reasonable max_messages threshold
        stm_docs = [{"role": "user", "content": "hi"} for _ in range(2)]

        with (
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.memory.short_term.get_stm_raw_docs",
                return_value=stm_docs,
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.should_promote",
            ) as mock_should_promote,
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.promote_stm_to_snapshot",
                return_value=mock_snapshot,
            ),
        ):
            await handler._check_and_promote(
                {
                    "session_id": "sess-1",
                    "org_id": "org-1",
                    "user_id": "user-1",
                    "reason": "idle_session",
                }
            )

        # should_promote must NOT have been called — idle_session skips it
        mock_should_promote.assert_not_called()
        callback.assert_called_once()

    @pytest.mark.asyncio
    async def test_no_promotion_when_threshold_not_met_with_non_idle_oe_reason(self):
        """Promotion is skipped when should_promote returns False for non-idle OE reasons."""
        callback = MagicMock()
        handler = self._make_handler(embedding_handler=None)
        handler._on_snapshot_created = callback

        stm_docs = [{"role": "user", "content": "hi"} for _ in range(2)]

        with (
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.memory.short_term.get_stm_raw_docs",
                return_value=stm_docs,
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.should_promote",
                return_value=(False, "none"),
            ),
        ):
            await handler._check_and_promote(
                {
                    "session_id": "sess-1",
                    "org_id": "org-1",
                    "user_id": "user-1",
                    "reason": "message_count",
                }
            )

        callback.assert_not_called()

    @pytest.mark.asyncio
    async def test_embed_failure_does_not_abort_promotion(self):
        """If batch embedding raises, should_promote still runs with original docs."""
        mock_embedding_handler = MagicMock()

        async def failing_embed(*a, **kw):
            raise RuntimeError("Voyage API down")

        mock_embedding_handler.embed_stm_docs_for_session = failing_embed

        handler = self._make_handler(embedding_handler=mock_embedding_handler)
        mock_snapshot = _make_mock_snapshot()

        stm_docs = [{"role": "user", "content": "hi"} for _ in range(5)]

        with (
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.memory.short_term.get_stm_raw_docs",
                return_value=stm_docs,
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.should_promote",
                return_value=(True, "message_count"),
            ) as mock_should_promote,
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_core.pipelines.stm_to_snapshot.promote_stm_to_snapshot",
                return_value=mock_snapshot,
            ),
        ):
            # Must not raise
            await handler._check_and_promote(
                {"session_id": "sess-1", "org_id": "org-1", "user_id": "user-1"}
            )

        mock_should_promote.assert_called_once()

    @pytest.mark.asyncio
    async def test_snapshot_handler_receives_embedding_handler_when_flag_enabled(self):
        """SnapshotHandler._embedding_handler is set when embed_stm_before_promotion=True."""
        import os

        from mongomem_core.models.config.snapshot_config import SnapshotConfig

        from runner_shared.server.mongomem_impl.src.mongomem_worker.worker import MongoMemWorker

        mock_engine = MagicMock()
        mock_engine.embedder = MagicMock()
        mock_engine.embedder.dimension = 1024
        mock_engine.llm = MagicMock()
        mock_engine.settings.mongo_uri = "mongodb://localhost:27017"
        mock_engine.settings.db_name = "test_db"
        mock_engine.db = MagicMock()

        with (
            patch.dict(os.environ, {"MONGOMEM_WORKER_ENABLE_CHANGE_STREAMS": "false"}),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_worker.worker.ensure_worker_collections"
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_worker.worker.ensure_worker_indexes"
            ),
        ):
            worker = MongoMemWorker(
                engine=mock_engine,
                scaling_mode="distributed",
                embed_stm_before_promotion=True,
                snapshot_config=SnapshotConfig(
                    strategy="auto", embedding_strategy="generate", max_messages=5
                ),
            )
            worker.initialize()

        snapshot_handler = worker._handlers.get("snapshot")
        embedding_handler = worker._handlers.get("embedding")
        assert snapshot_handler is not None
        assert embedding_handler is not None
        assert snapshot_handler._embedding_handler is embedding_handler

    async def test_snapshot_handler_has_no_embedding_handler_when_flag_disabled(self):
        """SnapshotHandler._embedding_handler is None when embed_stm_before_promotion=False (default)."""
        import os

        from runner_shared.server.mongomem_impl.src.mongomem_worker.worker import MongoMemWorker

        mock_engine = MagicMock()
        mock_engine.embedder = MagicMock()
        mock_engine.embedder.dimension = 1024
        mock_engine.llm = MagicMock()
        mock_engine.settings.mongo_uri = "mongodb://localhost:27017"
        mock_engine.settings.db_name = "test_db"
        mock_engine.db = MagicMock()

        with (
            patch.dict(os.environ, {"MONGOMEM_WORKER_ENABLE_CHANGE_STREAMS": "false"}),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_worker.worker.ensure_worker_collections"
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_worker.worker.ensure_worker_indexes"
            ),
        ):
            worker = MongoMemWorker(
                engine=mock_engine,
                scaling_mode="distributed",
                # embed_stm_before_promotion defaults to False
            )
            worker.initialize()

        snapshot_handler = worker._handlers.get("snapshot")
        assert snapshot_handler is not None
        assert snapshot_handler._embedding_handler is None


# ===========================================================================
# 4. WorkerConfig – snapshot_config field
# ===========================================================================


class TestWorkerConfigSnapshotConfig:
    """snapshot_config field is accepted and stored on WorkerConfig."""

    def test_snapshot_config_defaults_to_none(self):
        from runner_shared.server.mongomem_impl.src.mongomem_worker.config import WorkerConfig

        config = WorkerConfig(mongo_uri="mongodb://localhost:27017", db_name="test_db")
        assert config.snapshot_config is None

    def test_snapshot_config_stored(self):
        from mongomem_core.models.config.snapshot_config import (
            SnapshotConfig,
        )

        from runner_shared.server.mongomem_impl.src.mongomem_worker.config import WorkerConfig

        snap_cfg = SnapshotConfig(strategy="auto", embedding_strategy="defer", max_messages=10)
        config = WorkerConfig(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            snapshot_config=snap_cfg,
        )
        assert config.snapshot_config is snap_cfg
        assert config.snapshot_config.embedding_strategy == "defer"
        assert config.snapshot_config.max_messages == 10


# ===========================================================================
# 5. MongoMemWorker – initialize(), snapshot_config, auto_extract_on_snapshot
# ===========================================================================


class TestMongoMemWorkerInitialize:
    """initialize() sets up handlers without starting the loop."""

    def _make_engine(self):
        mock_engine = MagicMock()
        mock_engine.embedder = MagicMock()
        mock_engine.embedder.dimension = 1024
        mock_engine.llm = MagicMock()
        mock_engine.settings.mongo_uri = "mongodb://localhost:27017"
        mock_engine.settings.db_name = "test_db"
        mock_engine.db = MagicMock()
        return mock_engine

    def _make_distributed_no_cs_worker(self, engine):
        """Create a distributed worker with change streams disabled."""
        import os
        from unittest.mock import patch

        from runner_shared.server.mongomem_impl.src.mongomem_worker.worker import MongoMemWorker

        with patch.dict(os.environ, {"MONGOMEM_WORKER_ENABLE_CHANGE_STREAMS": "false"}):
            return MongoMemWorker(engine=engine, scaling_mode="distributed")

    def test_initialize_calls_init_handlers(self):
        engine = self._make_engine()
        worker = self._make_distributed_no_cs_worker(engine)

        with patch.object(worker, "_init_handlers") as mock_init:
            worker.initialize()
            mock_init.assert_called_once()

    def test_initialize_does_not_create_executor_in_distributed_mode(self):
        """In distributed mode initialize() does not create a ThreadPoolExecutor."""
        engine = self._make_engine()
        worker = self._make_distributed_no_cs_worker(engine)
        assert worker._executor is None

        with patch.object(worker, "_init_handlers"):
            worker.initialize()

        assert worker._executor is None

    def test_initialize_raises_if_scaling_mode_is_single(self):
        """initialize() raises RuntimeError if scaling_mode='single'."""
        import os

        from runner_shared.server.mongomem_impl.src.mongomem_worker.worker import MongoMemWorker

        engine = self._make_engine()
        with patch.dict(os.environ, {"MONGOMEM_WORKER_ENABLE_CHANGE_STREAMS": "false"}):
            worker = MongoMemWorker(engine=engine, scaling_mode="single")

        with pytest.raises(RuntimeError, match="scaling_mode='distributed'"):
            worker.initialize()

    def test_initialize_raises_if_change_streams_enabled(self):
        """initialize() raises RuntimeError if enable_change_streams=True."""
        import os

        from runner_shared.server.mongomem_impl.src.mongomem_worker.worker import MongoMemWorker

        engine = self._make_engine()
        # change streams enabled by default
        with patch.dict(os.environ, {"MONGOMEM_WORKER_ENABLE_CHANGE_STREAMS": "true"}):
            worker = MongoMemWorker(engine=engine, scaling_mode="distributed")

        with pytest.raises(RuntimeError, match="enable_change_streams=False"):
            worker.initialize()

    def test_auto_extract_on_snapshot_stored_in_config(self):
        import os

        from runner_shared.server.mongomem_impl.src.mongomem_worker.worker import MongoMemWorker

        engine = self._make_engine()
        with patch.dict(os.environ, {"MONGOMEM_WORKER_ENABLE_CHANGE_STREAMS": "false"}):
            worker = MongoMemWorker(
                engine=engine,
                scaling_mode="distributed",
                auto_extract_on_snapshot=True,
            )
        assert worker._config.auto_extract_on_snapshot is True

    def test_snapshot_config_passed_to_config(self):
        import os

        from mongomem_core.models.config.snapshot_config import (
            SnapshotConfig,
        )

        from runner_shared.server.mongomem_impl.src.mongomem_worker.worker import MongoMemWorker

        engine = self._make_engine()
        snap_cfg = SnapshotConfig(strategy="auto", embedding_strategy="defer", max_messages=15)
        with patch.dict(os.environ, {"MONGOMEM_WORKER_ENABLE_CHANGE_STREAMS": "false"}):
            worker = MongoMemWorker(
                engine=engine,
                scaling_mode="distributed",
                snapshot_config=snap_cfg,
            )
        assert worker._config.snapshot_config is snap_cfg

    def test_snapshot_handler_receives_callback_when_auto_extract_enabled(self):
        """When auto_extract_on_snapshot=True, SnapshotHandler gets on_snapshot_created callback."""
        import os

        from mongomem_core.models.config.snapshot_config import (
            SnapshotConfig,
        )

        from runner_shared.server.mongomem_impl.src.mongomem_worker.worker import MongoMemWorker

        engine = self._make_engine()
        with (
            patch.dict(os.environ, {"MONGOMEM_WORKER_ENABLE_CHANGE_STREAMS": "false"}),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_worker.worker.ensure_worker_collections"
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_worker.worker.ensure_worker_indexes"
            ),
        ):
            worker = MongoMemWorker(
                engine=engine,
                scaling_mode="distributed",
                auto_extract_on_snapshot=True,
                snapshot_config=SnapshotConfig(
                    strategy="auto", embedding_strategy="defer", max_messages=5
                ),
                extraction_config={
                    "semantic": {"enabled": True},
                    "episodic": {"enabled": True},
                },
            )
            worker.initialize()

        snapshot_handler = worker._handlers.get("snapshot")
        assert snapshot_handler is not None
        assert snapshot_handler._on_snapshot_created is not None

    def test_snapshot_handler_has_no_callback_when_auto_extract_disabled(self):
        """When auto_extract_on_snapshot=False, SnapshotHandler gets no callback."""
        import os

        from runner_shared.server.mongomem_impl.src.mongomem_worker.worker import MongoMemWorker

        engine = self._make_engine()
        with (
            patch.dict(os.environ, {"MONGOMEM_WORKER_ENABLE_CHANGE_STREAMS": "false"}),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_worker.worker.ensure_worker_collections"
            ),
            patch(
                "runner_shared.server.mongomem_impl.src.mongomem_worker.worker.ensure_worker_indexes"
            ),
        ):
            worker = MongoMemWorker(
                engine=engine,
                scaling_mode="distributed",
                auto_extract_on_snapshot=False,
            )
            worker.initialize()

        snapshot_handler = worker._handlers.get("snapshot")
        assert snapshot_handler is not None
        assert snapshot_handler._on_snapshot_created is None


# ===========================================================================
# 6. /worker/processTasks endpoint
# ===========================================================================


class TestWorkerProcessEndpoint:
    """Tests for POST /api/v1/worker/processTasks drain endpoint."""

    def setup_method(self):
        """Reset _drain_active before each test to prevent state leakage."""
        from runner_shared.server.mongomem_impl.routes.v1 import worker as worker_module

        worker_module._drain_active = False

    def _make_app(self, worker=None):
        """Create a test FastAPI app with optional worker."""
        from fastapi.testclient import TestClient

        from runner_shared.server.mongomem_impl.app import create_app

        mock_engine = MagicMock()
        # We need to bypass lifespan for unit tests
        app = create_app(mock_engine, worker)
        # Override state directly to skip lifespan
        app.state.worker = worker
        return TestClient(app, raise_server_exceptions=True)

    def test_returns_204_when_worker_is_none(self):
        """Returns 204 No Content immediately when no worker is configured."""
        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        from runner_shared.server.mongomem_impl.routes.v1.worker import router

        app = FastAPI()
        app.include_router(router, prefix="/api/v1")
        app.state.worker = None

        client = TestClient(app)
        response = client.post("/api/v1/worker/processTasks")
        assert response.status_code == 204

    def test_returns_202_accepted_immediately(self):
        """Returns 202 Accepted immediately without waiting for drain to complete."""
        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        from runner_shared.server.mongomem_impl.routes.v1.worker import router

        mock_worker = MagicMock()

        async def mock_process_batch():
            return 0

        mock_worker.process_batch = mock_process_batch

        app = FastAPI()
        app.include_router(router, prefix="/api/v1")
        app.state.worker = mock_worker

        client = TestClient(app)
        response = client.post("/api/v1/worker/processTasks")
        assert response.status_code == 202

    def test_drain_runs_in_background_until_empty(self):
        """Background drain calls process_batch until it returns 0."""
        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        from runner_shared.server.mongomem_impl.routes.v1.worker import router

        mock_worker = MagicMock()
        call_count = 0

        async def mock_process_batch():
            nonlocal call_count
            call_count += 1
            return 1 if call_count <= 3 else 0

        mock_worker.process_batch = mock_process_batch

        app = FastAPI()
        app.include_router(router, prefix="/api/v1")
        app.state.worker = mock_worker

        client = TestClient(app)
        client.post("/api/v1/worker/processTasks")

        # TestClient runs background tasks synchronously before returning
        assert call_count == 4  # 3 with work + 1 returning 0

    def test_drain_stops_at_iteration_cap(self):
        """Background drain stops at _MAX_DRAIN_ITERATIONS even if queue never empties."""
        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        from runner_shared.server.mongomem_impl.routes.v1 import worker as worker_module
        from runner_shared.server.mongomem_impl.routes.v1.worker import router

        mock_worker = MagicMock()
        call_count = 0

        async def always_returns_one():
            nonlocal call_count
            call_count += 1
            return 1

        mock_worker.process_batch = always_returns_one

        app = FastAPI()
        app.include_router(router, prefix="/api/v1")
        app.state.worker = mock_worker

        with patch.object(worker_module, "_MAX_DRAIN_ITERATIONS", 5):
            client = TestClient(app)
            client.post("/api/v1/worker/processTasks")

        assert call_count == 5

    def test_second_call_skipped_when_drain_active(self):
        """Second POST while drain is active returns 202 without scheduling a new background task."""
        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        from runner_shared.server.mongomem_impl.routes.v1 import worker as worker_module
        from runner_shared.server.mongomem_impl.routes.v1.worker import router

        mock_worker = MagicMock()
        call_count = 0

        async def mock_process_batch():
            nonlocal call_count
            call_count += 1
            return 0

        mock_worker.process_batch = mock_process_batch

        app = FastAPI()
        app.include_router(router, prefix="/api/v1")
        app.state.worker = mock_worker

        # Simulate drain already active
        with patch.object(worker_module, "_drain_active", True):
            client = TestClient(app)
            response = client.post("/api/v1/worker/processTasks")

        assert response.status_code == 202
        # process_batch must not have been called — no new drain was scheduled
        assert call_count == 0


# ===========================================================================
# 7. main.py – provider detection, LLM adapter, create_worker
# ===========================================================================


class TestDetectLlmProvider:
    """_detect_llm_provider returns first provider with a key set."""

    def test_returns_none_when_no_keys(self, monkeypatch):
        for var in ["OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GEMINI_API_KEY", "CEREBRAS_API_KEY"]:
            monkeypatch.delenv(var, raising=False)

        from runner_shared.server.mongomem_impl.main import _detect_llm_provider

        assert _detect_llm_provider() is None

    def test_openai_detected_first(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        monkeypatch.setenv("ANTHROPIC_API_KEY", "ant-test")
        for var in ["GEMINI_API_KEY", "CEREBRAS_API_KEY"]:
            monkeypatch.delenv(var, raising=False)

        from runner_shared.server.mongomem_impl.main import _detect_llm_provider

        provider, key = _detect_llm_provider()
        assert provider == "openai"
        assert key == "sk-test"

    def test_anthropic_detected_when_no_openai(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.setenv("ANTHROPIC_API_KEY", "ant-test")
        for var in ["GEMINI_API_KEY", "CEREBRAS_API_KEY"]:
            monkeypatch.delenv(var, raising=False)

        from runner_shared.server.mongomem_impl.main import _detect_llm_provider

        provider, key = _detect_llm_provider()
        assert provider == "anthropic"
        assert key == "ant-test"

    def test_gemini_detected(self, monkeypatch):
        for var in ["OPENAI_API_KEY", "ANTHROPIC_API_KEY"]:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.setenv("GEMINI_API_KEY", "gem-test")
        monkeypatch.delenv("CEREBRAS_API_KEY", raising=False)

        from runner_shared.server.mongomem_impl.main import _detect_llm_provider

        provider, _ = _detect_llm_provider()
        assert provider == "gemini"

    def test_cerebras_detected(self, monkeypatch):
        for var in ["OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GEMINI_API_KEY"]:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.setenv("CEREBRAS_API_KEY", "cer-test")

        from runner_shared.server.mongomem_impl.main import _detect_llm_provider

        provider, _ = _detect_llm_provider()
        assert provider == "cerebras"


class TestBuildLlm:
    """_build_llm returns an LLMProtocol-compatible adapter."""

    def test_adapter_has_required_interface(self, monkeypatch):
        monkeypatch.delenv("OPENAI_BASE_URL", raising=False)
        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
        monkeypatch.delenv("MONGOMEM_LLM_MODEL", raising=False)

        from runner_shared.server.mongomem_impl.main import _build_llm

        with patch("litellm.completion") as mock_completion:
            mock_completion.return_value = MagicMock(
                choices=[MagicMock(message=MagicMock(content="response"))]
            )
            llm = _build_llm("openai", "sk-test")

        assert hasattr(llm, "complete")
        assert hasattr(llm, "complete_json")
        assert hasattr(llm, "model_id")

    def test_model_id_reflects_default(self, monkeypatch):
        monkeypatch.delenv("MONGOMEM_LLM_MODEL", raising=False)
        monkeypatch.delenv("OPENAI_BASE_URL", raising=False)

        from runner_shared.server.mongomem_impl.main import _build_llm

        llm = _build_llm("openai", "sk-test")
        assert llm.model_id == "gpt-4o-mini"

    def test_model_id_overridden_by_env(self, monkeypatch):
        monkeypatch.setenv("MONGOMEM_LLM_MODEL", "gpt-4o")
        monkeypatch.delenv("OPENAI_BASE_URL", raising=False)

        from runner_shared.server.mongomem_impl.main import _build_llm

        llm = _build_llm("openai", "sk-test")
        assert llm.model_id == "gpt-4o"

    def test_openai_base_url_forwarded(self, monkeypatch):
        monkeypatch.setenv("OPENAI_BASE_URL", "https://custom.endpoint.com/v1")
        monkeypatch.delenv("MONGOMEM_LLM_MODEL", raising=False)

        from runner_shared.server.mongomem_impl.main import _build_llm

        with patch("litellm.completion") as mock_completion:
            mock_completion.return_value = MagicMock(
                choices=[MagicMock(message=MagicMock(content="hi"))]
            )
            llm = _build_llm("openai", "sk-test")
            llm.complete("test prompt")

        call_kwargs = mock_completion.call_args[1]
        assert call_kwargs.get("base_url") == "https://custom.endpoint.com/v1"

    def test_grove_foundry_url_adds_api_key_header(self, monkeypatch):
        monkeypatch.setenv("OPENAI_BASE_URL", "https://grove-foundry.example.com/v1")
        monkeypatch.delenv("MONGOMEM_LLM_MODEL", raising=False)

        from runner_shared.server.mongomem_impl.main import _build_llm

        with patch("litellm.completion") as mock_completion:
            mock_completion.return_value = MagicMock(
                choices=[MagicMock(message=MagicMock(content="hi"))]
            )
            llm = _build_llm("openai", "sk-mykey")
            llm.complete("test prompt")

        call_kwargs = mock_completion.call_args[1]
        assert call_kwargs.get("extra_headers", {}).get("api-key") == "sk-mykey"

    def test_anthropic_base_url_forwarded(self, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_BASE_URL", "https://anthropic-proxy.internal")
        monkeypatch.delenv("MONGOMEM_LLM_MODEL", raising=False)

        from runner_shared.server.mongomem_impl.main import _build_llm

        with patch("litellm.completion") as mock_completion:
            mock_completion.return_value = MagicMock(
                choices=[MagicMock(message=MagicMock(content="hi"))]
            )
            llm = _build_llm("anthropic", "ant-test")
            llm.complete("test prompt")

        call_kwargs = mock_completion.call_args[1]
        assert call_kwargs.get("base_url") == "https://anthropic-proxy.internal"

    def test_complete_calls_litellm(self, monkeypatch):
        monkeypatch.delenv("OPENAI_BASE_URL", raising=False)
        monkeypatch.delenv("MONGOMEM_LLM_MODEL", raising=False)

        from runner_shared.server.mongomem_impl.main import _build_llm

        with patch("litellm.completion") as mock_completion:
            mock_completion.return_value = MagicMock(
                choices=[MagicMock(message=MagicMock(content="the answer"))]
            )
            llm = _build_llm("openai", "sk-test")
            result = llm.complete("what is 2+2?")

        assert result == "the answer"
        mock_completion.assert_called_once()
        assert mock_completion.call_args[1]["messages"][0]["content"] == "what is 2+2?"

    def test_complete_json_returns_dict(self, monkeypatch):
        import json

        monkeypatch.delenv("OPENAI_BASE_URL", raising=False)
        monkeypatch.delenv("MONGOMEM_LLM_MODEL", raising=False)

        from runner_shared.server.mongomem_impl.main import _build_llm

        expected = {"facts": ["user likes Python"]}
        with patch("litellm.completion") as mock_completion:
            mock_completion.return_value = MagicMock(
                choices=[MagicMock(message=MagicMock(content=json.dumps(expected)))]
            )
            llm = _build_llm("openai", "sk-test")
            result = llm.complete_json("extract facts", schema={})

        assert result == expected

    def test_complete_json_strips_markdown_fences(self, monkeypatch):
        monkeypatch.delenv("OPENAI_BASE_URL", raising=False)
        monkeypatch.delenv("MONGOMEM_LLM_MODEL", raising=False)

        from runner_shared.server.mongomem_impl.main import _build_llm

        with patch("litellm.completion") as mock_completion:
            mock_completion.return_value = MagicMock(
                choices=[MagicMock(message=MagicMock(content='```json\n{"key": "val"}\n```'))]
            )
            llm = _build_llm("openai", "sk-test")
            result = llm.complete_json("extract", schema={})

        assert result == {"key": "val"}


class TestCreateWorker:
    """create_worker() returns None without provider keys or embedder, worker otherwise."""

    def test_returns_none_when_no_embedder(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")

        from runner_shared.server.mongomem_impl.main import create_worker

        mock_engine = MagicMock()
        mock_engine.embedder = None  # no embedder
        result = create_worker(mock_engine)
        assert result is None

    def test_returns_none_when_no_llm_on_engine(self, monkeypatch):
        """Returns None when engine.llm is None (no LLM provider configured)."""
        from runner_shared.server.mongomem_impl.main import create_worker

        mock_engine = MagicMock()
        mock_engine.embedder = MagicMock()  # embedder present
        mock_engine.llm = None  # no LLM attached to engine
        result = create_worker(mock_engine)
        assert result is None

    def test_returns_worker_when_provider_key_present(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        for var in ["ANTHROPIC_API_KEY", "GEMINI_API_KEY", "CEREBRAS_API_KEY"]:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.delenv("OPENAI_BASE_URL", raising=False)
        monkeypatch.delenv("MONGOMEM_LLM_MODEL", raising=False)

        mock_engine = MagicMock()
        mock_engine.embedder = MagicMock()
        mock_engine.embedder.dimension = 1024
        mock_engine.llm = MagicMock()
        mock_engine.settings.mongo_uri = "mongodb://localhost:27017"
        mock_engine.settings.db_name = "test_db"
        mock_engine.db = MagicMock()

        from runner_shared.server.mongomem_impl.main import create_worker

        worker = create_worker(mock_engine)
        assert worker is not None

    def test_worker_has_auto_extract_enabled(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        for var in ["ANTHROPIC_API_KEY", "GEMINI_API_KEY", "CEREBRAS_API_KEY"]:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.delenv("OPENAI_BASE_URL", raising=False)
        monkeypatch.delenv("MONGOMEM_LLM_MODEL", raising=False)
        monkeypatch.delenv("MONGOMEM_WORKER_DB_NAME", raising=False)

        mock_engine = MagicMock()
        mock_engine.embedder = MagicMock()
        mock_engine.embedder.dimension = 1024
        mock_engine.llm = MagicMock()
        mock_engine.settings.mongo_uri = "mongodb://localhost:27017"
        mock_engine.settings.db_name = "test_db"
        mock_engine.db = MagicMock()

        from runner_shared.server.mongomem_impl.main import create_worker

        worker = create_worker(mock_engine)
        assert worker._config.auto_extract_on_snapshot is True

    def test_worker_snapshot_config_uses_defer_strategy(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        for var in ["ANTHROPIC_API_KEY", "GEMINI_API_KEY", "CEREBRAS_API_KEY"]:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.delenv("OPENAI_BASE_URL", raising=False)
        monkeypatch.delenv("MONGOMEM_LLM_MODEL", raising=False)
        monkeypatch.delenv("MONGOMEM_WORKER_DB_NAME", raising=False)
        monkeypatch.delenv("MONGOMEM_SNAPSHOT_MAX_MESSAGES", raising=False)
        monkeypatch.delenv("MONGOMEM_SNAPSHOT_STALE_MINUTES", raising=False)

        mock_engine = MagicMock()
        mock_engine.embedder = MagicMock()
        mock_engine.embedder.dimension = 1024
        mock_engine.llm = MagicMock()
        mock_engine.settings.mongo_uri = "mongodb://localhost:27017"
        mock_engine.settings.db_name = "test_db"
        mock_engine.db = MagicMock()

        from runner_shared.server.mongomem_impl.main import create_worker

        worker = create_worker(mock_engine)
        assert worker._config.snapshot_config.embedding_strategy == "generate"
        assert worker._config.snapshot_config.max_messages == 20  # default
        assert worker._config.snapshot_config.delete_promoted is False  # keep STM docs

    def test_worker_enabled_extractions_from_env(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        for var in ["ANTHROPIC_API_KEY", "GEMINI_API_KEY", "CEREBRAS_API_KEY"]:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.setenv("MONGOMEM_ENABLED_EXTRACTIONS", "semantic,episodic")
        monkeypatch.delenv("OPENAI_BASE_URL", raising=False)
        monkeypatch.delenv("MONGOMEM_LLM_MODEL", raising=False)
        monkeypatch.delenv("MONGOMEM_WORKER_DB_NAME", raising=False)

        mock_engine = MagicMock()
        mock_engine.embedder = MagicMock()
        mock_engine.embedder.dimension = 1024
        mock_engine.llm = MagicMock()
        mock_engine.settings.mongo_uri = "mongodb://localhost:27017"
        mock_engine.settings.db_name = "test_db"
        mock_engine.db = MagicMock()

        from runner_shared.server.mongomem_impl.main import create_worker

        worker = create_worker(mock_engine)
        assert worker._config.semantic.enabled is True
        assert worker._config.episodic.enabled is True
        assert worker._config.taxonomic.enabled is False

    def test_snapshot_max_messages_from_env(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        for var in ["ANTHROPIC_API_KEY", "GEMINI_API_KEY", "CEREBRAS_API_KEY"]:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.setenv("MONGOMEM_SNAPSHOT_MAX_MESSAGES", "42")
        monkeypatch.delenv("OPENAI_BASE_URL", raising=False)
        monkeypatch.delenv("MONGOMEM_LLM_MODEL", raising=False)
        monkeypatch.delenv("MONGOMEM_WORKER_DB_NAME", raising=False)
        monkeypatch.delenv("MONGOMEM_SNAPSHOT_STALE_MINUTES", raising=False)

        mock_engine = MagicMock()
        mock_engine.embedder = MagicMock()
        mock_engine.embedder.dimension = 1024
        mock_engine.llm = MagicMock()
        mock_engine.settings.mongo_uri = "mongodb://localhost:27017"
        mock_engine.settings.db_name = "test_db"
        mock_engine.db = MagicMock()

        from runner_shared.server.mongomem_impl.main import create_worker

        worker = create_worker(mock_engine)
        assert worker._config.snapshot_config.max_messages == 42


# ===========================================================================
# 8. Snapshot embedding strategy
# ===========================================================================


class TestSnapshotNeverEmbedded:
    """Snapshot is created with embedding_strategy=generate — embeds the concatenated messages."""

    def test_generate_strategy_config(self):
        from mongomem_core.models.config.snapshot_config import (
            SnapshotConfig,
        )

        config = SnapshotConfig(strategy="auto", embedding_strategy="generate", max_messages=5)
        assert config.embedding_strategy == "generate"

    def test_stm_embeddings_transferred_when_present(self):
        """transfer_embeddings preserves any existing STM embeddings."""
        from mongomem_core.pipelines.stm_to_snapshot import (
            transfer_embeddings,
        )

        stm_docs = [
            {"role": "user", "content": "hi", "embedding": [0.1] * 1024},
            {"role": "assistant", "content": "hello", "embedding": [0.2] * 1024},
        ]
        embedding, strategy = transfer_embeddings(stm_docs)
        assert embedding is not None
        assert strategy == "transfer"
        assert len(embedding) == 1024

    def test_transfer_embeddings_returns_none_when_no_embeddings(self):
        """transfer_embeddings returns None when STM docs have no embeddings."""
        from mongomem_core.pipelines.stm_to_snapshot import (
            transfer_embeddings,
        )

        stm_docs = [
            {"role": "user", "content": "hi", "embedding": None},
            {"role": "assistant", "content": "hello"},
        ]
        embedding, strategy = transfer_embeddings(stm_docs)
        assert embedding is None
        assert strategy is None
