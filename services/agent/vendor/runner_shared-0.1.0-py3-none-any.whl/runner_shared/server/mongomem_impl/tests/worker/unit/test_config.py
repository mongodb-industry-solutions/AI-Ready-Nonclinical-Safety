import pytest

from runner_shared.server.mongomem_impl.src.mongomem_worker.config import (
    ExtractionConfig,
    TaskTimeouts,
    WorkerConfig,
    WorkerSettings,
)

from ..conftest import MockLLM


class TestWorkerSettings:
    """Tests for environment-based settings."""

    def test_default_values(self):
        settings = WorkerSettings()
        assert settings.mongo_uri == "mongodb://localhost:27017"
        assert settings.db_name == "agentic_memory"
        assert settings.max_concurrent == 8
        assert settings.batch_size == 10

    def test_core_worker_db_defaults(self):
        settings = WorkerSettings()
        assert settings.core_db_name is None
        assert settings.worker_db_name is None


class TestTaskTimeouts:
    """Tests for task timeout configuration."""

    def test_default_timeouts(self):
        timeouts = TaskTimeouts()
        assert timeouts.embedding == 30.0
        assert timeouts.snapshot == 60.0
        assert timeouts.entity == 180.0
        assert timeouts.maintenance == 300.0

    def test_get_known_task_type(self):
        timeouts = TaskTimeouts()
        assert timeouts.get("embedding") == 30.0
        assert timeouts.get("entity") == 180.0

    def test_get_unknown_task_type_returns_default(self):
        timeouts = TaskTimeouts()
        assert timeouts.get("unknown_task") == timeouts.default

    def test_custom_timeouts(self):
        timeouts = TaskTimeouts(embedding=60.0, entity=300.0, default=120.0)
        assert timeouts.embedding == 60.0
        assert timeouts.entity == 300.0
        assert timeouts.default == 120.0


class TestExtractionConfig:
    """Tests for extraction configuration."""

    def test_default_values(self):
        config = ExtractionConfig()
        assert config.enabled is True
        assert config.prompt is None
        assert config.llm is None
        assert config.batch_size == 5

    def test_custom_values(self):
        llm = MockLLM()
        config = ExtractionConfig(
            enabled=False,
            prompt="Custom prompt",
            llm=llm,
            batch_size=10,
        )
        assert config.enabled is False
        assert config.prompt == "Custom prompt"
        assert config.llm is llm
        assert config.batch_size == 10

    def test_invalid_approval_mode_raises(self):
        with pytest.raises(ValueError):
            ExtractionConfig(approval_mode="invalid")  # type: ignore[arg-type]


class TestWorkerConfig:
    """Tests for worker configuration.

    Note: WorkerConfig no longer stores embedder - that comes from MemoryEngine.
    This avoids duplicate validation (engine already validates embedder).
    """

    def test_minimal_config(self):
        config = WorkerConfig(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
        )
        assert config.mongo_uri == "mongodb://localhost:27017"
        assert config.db_name == "test_db"
        assert config.concurrency == 5  # default

    def test_invalid_default_approval_mode_raises(self):
        with pytest.raises(ValueError):
            WorkerConfig(
                mongo_uri="mongodb://localhost:27017",
                db_name="test_db",
                default_approval_mode="invalid",  # type: ignore[arg-type]
            )

    def test_effective_db_names_default(self):
        config = WorkerConfig(
            mongo_uri="mongodb://localhost:27017",
            db_name="shared_db",
        )
        assert config.effective_core_db == "shared_db"
        assert config.effective_worker_db == "shared_db"

    def test_effective_db_names_split(self):
        config = WorkerConfig(
            mongo_uri="mongodb://localhost:27017",
            db_name="default_db",
            core_db_name="core_db",
            worker_db_name="worker_db",
        )
        assert config.effective_core_db == "core_db"
        assert config.effective_worker_db == "worker_db"

    def test_extraction_enabled_without_llm(self):
        config = WorkerConfig(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
        )
        # No LLM provided, extractions should not be enabled
        assert config.is_extraction_enabled("taxonomic") is False
        assert config.is_extraction_enabled("entity") is False

    def test_extraction_enabled_with_llm(self):
        llm = MockLLM()
        config = WorkerConfig(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            llm=llm,
        )
        # Default LLM provided, extractions should be enabled
        assert config.is_extraction_enabled("taxonomic") is True
        assert config.is_extraction_enabled("entity") is True

    def test_extraction_disabled_explicitly(self):
        llm = MockLLM()
        config = WorkerConfig(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            llm=llm,
            taxonomic=ExtractionConfig(enabled=False),
        )
        assert config.is_extraction_enabled("taxonomic") is False
        assert config.is_extraction_enabled("entity") is True

    def test_get_extraction_llm_fallback(self):
        default_llm = MockLLM()
        config = WorkerConfig(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            llm=default_llm,
        )
        assert config.get_extraction_llm("taxonomic") is default_llm

    def test_get_extraction_llm_specific(self):
        default_llm = MockLLM()
        specific_llm = MockLLM()
        config = WorkerConfig(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            llm=default_llm,
            entity=ExtractionConfig(llm=specific_llm),
        )
        assert config.get_extraction_llm("entity") is specific_llm
        assert config.get_extraction_llm("taxonomic") is default_llm

    def test_from_dict_factory(self):
        llm = MockLLM()
        config = WorkerConfig.from_dict(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            llm=llm,
            extraction_config={
                "taxonomic": {"enabled": True, "batch_size": 10},
                "entity": {"enabled": False},
            },
            task_timeouts={
                "embedding": 45.0,
                "entity": 240.0,
            },
        )
        assert config.taxonomic.batch_size == 10
        assert config.entity.enabled is False
        assert config.task_timeouts.embedding == 45.0
        assert config.task_timeouts.entity == 240.0

    def test_concurrency_settings(self):
        config = WorkerConfig(
            mongo_uri="mongodb://localhost:27017",
            db_name="test_db",
            concurrency=10,
            batch_size=20,
        )
        assert config.concurrency == 10
        assert config.batch_size == 20
