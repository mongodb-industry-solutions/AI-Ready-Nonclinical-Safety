"""
Unit tests for retrieval component observability.

These tests verify that retrieval components work correctly with observability:
- ContextBuilder accepts metrics and emits pipeline spans/metrics
- RetrievalHub accepts metrics and emits per-source metrics
- Failure metrics are emitted before exceptions propagate

Note: Unit tests for CoreObservability methods in isolation are in test_observability_protocol.py
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from mongomem_core.models.retrieval import MemorySource
from mongomem_core.observability import CoreObservability
from mongomem_core.retrieval.budgeting import Budgeter
from mongomem_core.retrieval.context_builder import (
    ContextBuilder,
)
from mongomem_core.retrieval.formatting import Formatter
from mongomem_core.retrieval.ranking import MemoryRanker
from mongomem_core.retrieval.sources import RetrievalHub

from ...conftest import RecordingObservability


@pytest.fixture
def mock_db() -> MagicMock:
    return MagicMock()


class TestContextBuilderObservability:
    """Tests for ContextBuilder observability."""

    def test_accepts_metrics_parameter(self, core_metrics: CoreObservability):
        """ContextBuilder can be constructed with metrics parameter."""
        builder = ContextBuilder(
            retrieval_hub=RetrievalHub(),
            ranker=MemoryRanker(),
            budgeter=Budgeter(),
            formatter=Formatter(),
            obs=core_metrics,
        )
        assert builder._obs is core_metrics

    def test_defaults_to_noop_metrics(self):
        """ContextBuilder defaults to CoreObservability with NoOpObservability."""
        builder = ContextBuilder(
            retrieval_hub=RetrievalHub(),
            ranker=MemoryRanker(),
            budgeter=Budgeter(),
            formatter=Formatter(),
        )
        assert builder._obs is not None
        assert isinstance(builder._obs, CoreObservability)

    @patch.object(RetrievalHub, "fetch_memories")
    def test_emits_all_pipeline_spans_and_metrics(
        self,
        mock_fetch: MagicMock,
        mock_db: MagicMock,
        recording_obs: RecordingObservability,
        core_metrics: CoreObservability,
    ):
        """build_context emits spans for all pipeline stages and overall metrics."""
        mock_fetch.return_value = []

        builder = ContextBuilder(
            retrieval_hub=RetrievalHub(),
            ranker=MemoryRanker(),
            budgeter=Budgeter(),
            formatter=Formatter(),
            obs=core_metrics,
        )

        builder.build_context(
            db=mock_db,
            session_id="sess_123",
            query="test query",
            org_id="org_1",
            query_embedding=[0.1] * 256,
            auto_fetch_user_context=False,
        )

        # Verify all 5 pipeline spans
        expected_spans = [
            "mongomem.context.embed_query",
            "mongomem.context.fetch_memories",
            "mongomem.context.rank",
            "mongomem.context.budget",
            "mongomem.context.format",
        ]
        for span_name in expected_spans:
            spans = recording_obs.get_spans(span_name)
            assert len(spans) == 1, f"Expected 1 span for {span_name}"
            assert spans[0]["completed"] is True

        # Verify overall context metrics
        assert len(recording_obs.get_timings("mongomem.context.latency")) == 1
        assert len(recording_obs.get_histograms("mongomem.context.memories.count")) == 1
        assert len(recording_obs.get_histograms("mongomem.context.tokens.used")) == 1

    @patch.object(RetrievalHub, "fetch_memories")
    def test_works_without_explicit_metrics(self, mock_fetch: MagicMock, mock_db: MagicMock):
        """build_context works correctly with default NoOp metrics."""
        mock_fetch.return_value = []

        builder = ContextBuilder(
            retrieval_hub=RetrievalHub(),
            ranker=MemoryRanker(),
            budgeter=Budgeter(),
            formatter=Formatter(),
        )

        response = builder.build_context(
            db=mock_db,
            session_id="sess_123",
            query="test query",
            org_id="org_1",
            query_embedding=[0.1] * 256,
            auto_fetch_user_context=False,
        )

        assert response is not None
        assert response.metadata is not None


class TestRetrievalHubObservability:
    """Tests for RetrievalHub observability."""

    def test_accepts_metrics_parameter(self, core_metrics: CoreObservability):
        """RetrievalHub can be constructed with metrics parameter."""
        hub = RetrievalHub(obs=core_metrics)
        assert hub._obs is core_metrics

    def test_defaults_to_noop_metrics(self):
        """RetrievalHub defaults to CoreObservability with NoOpObservability."""
        hub = RetrievalHub()
        assert hub._obs is not None
        assert isinstance(hub._obs, CoreObservability)

    @patch("mongomem_core.retrieval.sources.get_stm_by_session")
    def test_emits_per_source_metrics(
        self,
        mock_get_stm: MagicMock,
        mock_db: MagicMock,
        recording_obs: RecordingObservability,
        core_metrics: CoreObservability,
    ):
        """RetrievalHub emits latency and count metrics per source."""
        mock_get_stm.return_value = []

        hub = RetrievalHub(obs=core_metrics)
        hub.fetch_memories(
            db=mock_db,
            session_id="sess_123",
            query_embedding=[0.1] * 256,
            org_id="org_1",
            enabled_sources={MemorySource.STM},
        )

        timings = recording_obs.get_timings("mongomem.retrieval.source.latency")
        assert len(timings) == 1
        assert timings[0]["tags"]["source"] == "stm"

        histograms = recording_obs.get_histograms("mongomem.retrieval.source.count")
        assert len(histograms) == 1
        assert histograms[0]["tags"]["source"] == "stm"

    @patch("mongomem_core.retrieval.sources.get_stm_by_session")
    def test_works_without_explicit_metrics(self, mock_get_stm: MagicMock, mock_db: MagicMock):
        """RetrievalHub works correctly with default NoOp metrics."""
        mock_get_stm.return_value = []

        hub = RetrievalHub()
        result = hub.fetch_memories(
            db=mock_db,
            session_id="sess_123",
            query_embedding=[0.1] * 256,
            org_id="org_1",
            enabled_sources={MemorySource.STM},
        )

        assert result is not None
        assert isinstance(result, list)


class TestRetrievalHubFailureMetrics:
    """Tests for RetrievalHub failure metrics integration."""

    @patch("mongomem_core.retrieval.sources.get_stm_by_session")
    def test_emits_failed_metrics_on_required_source_exception(
        self,
        mock_get_stm: MagicMock,
        mock_db: MagicMock,
        recording_obs: RecordingObservability,
        core_metrics: CoreObservability,
    ):
        """RetrievalHub emits failed metrics when a required source raises an exception.

        STM is a required source, so failures propagate as DatabaseOperationError.
        The metrics should be emitted BEFORE the exception is raised.
        """
        from mongomem_core.exceptions import (
            DatabaseOperationError,
        )

        mock_get_stm.side_effect = Exception("Test error")

        hub = RetrievalHub(obs=core_metrics)

        # Should raise DatabaseOperationError because STM is a required source
        with pytest.raises(DatabaseOperationError) as exc_info:
            hub.fetch_memories(
                db=mock_db,
                session_id="sess_123",
                query_embedding=[0.1] * 256,
                org_id="org_1",
                enabled_sources={MemorySource.STM},
            )

        assert "stm" in str(exc_info.value).lower()

        # Verify failure metrics were emitted before the exception
        failed_increments = [
            inc
            for inc in recording_obs.increments
            if inc["name"] == "mongomem.retrieval.source.failed"
        ]
        assert len(failed_increments) == 1
        assert failed_increments[0]["tags"]["source"] == "stm"
        # STM errors raise DatabaseOperationError which is caught as database_error
        assert failed_increments[0]["tags"]["error_type"] == "database_error"
