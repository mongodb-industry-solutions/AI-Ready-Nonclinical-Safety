"""Unit tests for storage bootstrap helpers."""

from unittest.mock import MagicMock, patch

from mongomem_core.config import Settings
from mongomem_core.exceptions import DatabaseOperationError
from mongomem_core.storage.bootstrap import (
    _is_existing_search_index_error,
    ensure_engine_search_indexes,
)
from mongomem_core.storage.search_indexes import (
    SearchIndexDefinition,
)
from pymongo.errors import OperationFailure


class TestExistingSearchIndexError:
    """Tests for duplicate search index error classification."""

    def test_detects_duplicate_index_names_race(self):
        """Treat duplicate-name Atlas Search races as already existing."""
        exc = OperationFailure(
            "duplicate index names for the same collection: abc123",
            code=2,
            details={
                "code": 2,
                "codeName": "BadValue",
                "errmsg": "duplicate index names for the same collection: abc123",
            },
        )

        assert _is_existing_search_index_error(exc) is True

    def test_does_not_treat_generic_badvalue_as_duplicate_index(self):
        """BadValue alone is too broad without the duplicate-name errmsg."""
        exc = OperationFailure(
            "invalid analyzer configuration",
            code=2,
            details={
                "code": 2,
                "codeName": "BadValue",
                "errmsg": "invalid analyzer configuration",
            },
        )

        assert _is_existing_search_index_error(exc) is False

    def test_does_not_hide_unrelated_operation_failures(self):
        """Leave unrelated Atlas Search creation errors visible."""
        exc = OperationFailure(
            "authentication failed",
            code=18,
            details={
                "code": 18,
                "codeName": "AuthenticationFailed",
                "errmsg": "authentication failed",
            },
        )

        assert _is_existing_search_index_error(exc) is False


class TestEnsureEngineSearchIndexes:
    """Tests for ensure_engine_search_indexes."""

    @patch("mongomem_core.storage.bootstrap._iter_search_indexes")
    def test_ignores_duplicate_name_race_from_server(self, mock_iter_search_indexes):
        """Concurrent creators should not fail bootstrap when the server already won."""
        index_definition = SearchIndexDefinition(
            collection_name="memory_semantic",
            name="sem_text_search_index",
            index_type="search",
            definition={"mappings": {"dynamic": True}},
        )
        mock_iter_search_indexes.return_value = [index_definition]

        db = MagicMock()
        collection = MagicMock()
        collection.list_search_indexes.return_value = []
        collection.create_search_index.side_effect = OperationFailure(
            "duplicate index names for the same collection: abc123",
            code=2,
            details={
                "code": 2,
                "codeName": "BadValue",
                "errmsg": "duplicate index names for the same collection: abc123",
            },
        )
        db.__getitem__.return_value = collection

        ensure_engine_search_indexes(
            db,
            settings=Settings(embedding_dimension=1024),
            wait_for_ready=False,
        )

        collection.create_search_index.assert_called_once()

    @patch("mongomem_core.storage.bootstrap._iter_search_indexes")
    def test_raises_for_unrelated_create_errors(self, mock_iter_search_indexes):
        """Unexpected Atlas Search create failures should still raise."""
        index_definition = SearchIndexDefinition(
            collection_name="memory_semantic",
            name="sem_text_search_index",
            index_type="search",
            definition={"mappings": {"dynamic": True}},
        )
        mock_iter_search_indexes.return_value = [index_definition]

        db = MagicMock()
        collection = MagicMock()
        collection.list_search_indexes.return_value = []
        collection.create_search_index.side_effect = OperationFailure(
            "unauthorized to create search index",
            code=13,
        )
        db.__getitem__.return_value = collection

        try:
            ensure_engine_search_indexes(
                db,
                settings=Settings(embedding_dimension=1024),
                wait_for_ready=False,
            )
        except DatabaseOperationError as exc:
            failed_collections = exc.details["failed_collections"]
            assert failed_collections == [
                {
                    "collection": "memory_semantic",
                    "error": "unauthorized to create search index",
                }
            ]
        else:
            raise AssertionError("Expected DatabaseOperationError")
