"""Tests for WorkerObservability features.

These tests verify that WorkerObservability correctly:
1. Accepts ObservabilityProtocol as backend
2. Emits structured events for task lifecycle operations
3. Creates spans for task tracking
"""

from runner_shared.server.mongomem_impl.src.mongomem_worker.observability import WorkerObservability

from ..conftest import RecordingMetrics


class TestWorkerObservability:
    """Core tests for WorkerObservability integration."""

    def test_accepts_observability_backend(self, recording_metrics: RecordingMetrics):
        """WorkerObservability should accept ObservabilityProtocol backend."""
        obs = WorkerObservability(backend=recording_metrics, worker_id="w1")

        assert obs._backend is recording_metrics

    def test_task_lifecycle_emits_events(self, recording_metrics: RecordingMetrics):
        """Task methods should emit both metrics and structured events."""
        obs = WorkerObservability(backend=recording_metrics, worker_id="w1")

        # Test key task lifecycle methods
        obs.task_claimed("embedding", task_id="task-1")
        obs.task_completed("embedding", duration_ms=100.0, task_id="task-1")
        obs.task_failed("snapshot", "transient", "timeout", task_id="task-2")

        # Verify counters
        assert len(recording_metrics.get_increments("tasks_claimed")) == 1
        assert len(recording_metrics.get_increments("tasks_completed")) == 1
        assert len(recording_metrics.get_increments("tasks_failed")) == 1

        # Verify events
        claimed = recording_metrics.get_events("mongomem.worker.task.claimed")
        assert len(claimed) == 1
        assert claimed[0]["attributes"]["worker_id"] == "w1"
        assert claimed[0]["level"] == "info"

        completed = recording_metrics.get_events("mongomem.worker.task.completed")
        assert len(completed) == 1
        assert completed[0]["attributes"]["duration_ms"] == 100.0

        failed = recording_metrics.get_events("mongomem.worker.task.failed")
        assert len(failed) == 1
        assert failed[0]["level"] == "error"

    def test_track_task_creates_span_and_handles_success(self, recording_metrics: RecordingMetrics):
        """track_task should create span, emit events, and record duration."""
        obs = WorkerObservability(backend=recording_metrics, worker_id="w1")

        with obs.track_task("embedding", task_id="task-001") as ctx:
            ctx["result"] = "processed"

        # Span created with correct attributes
        spans = recording_metrics.get_spans("mongomem.worker.task.embedding")
        assert len(spans) == 1
        assert spans[0]["kind"] == "consumer"
        assert spans[0]["completed"] is True

        # Events emitted
        assert len(recording_metrics.get_events("mongomem.worker.task.claimed")) == 1
        assert len(recording_metrics.get_events("mongomem.worker.task.completed")) == 1

        # Duration recorded
        assert len(recording_metrics.get_timings("task_duration")) == 1

    def test_track_task_handles_failure(self, recording_metrics: RecordingMetrics):
        """track_task should emit failure event when error set in context."""
        obs = WorkerObservability(backend=recording_metrics)

        with obs.track_task("snapshot", task_id="task-002") as ctx:
            ctx["error"] = True
            ctx["error_type"] = "transient"

        # Failed event instead of completed
        assert len(recording_metrics.get_events("mongomem.worker.task.completed")) == 0
        assert len(recording_metrics.get_events("mongomem.worker.task.failed")) == 1


class TestWorkerObservabilityCoreIntegration:
    """Tests for integration with mongomem_core observability backends."""

    def test_works_with_noop_observability(self):
        """WorkerObservability should work with NoOpObservability backend."""
        from mongomem_core.observability import (
            NoOpObservability,
        )

        backend = NoOpObservability()
        obs = WorkerObservability(backend=backend, worker_id="w1")

        # Should not raise
        obs.task_claimed("test")
        with obs.track_task("test"):
            pass

    def test_works_with_logging_observability(self):
        """WorkerObservability should work with LoggingObservability backend."""
        from mongomem_core.observability import (
            LoggingObservability,
        )

        backend = LoggingObservability()
        obs = WorkerObservability(backend=backend, worker_id="w1")

        # Should not raise
        obs.task_claimed("test")
        with obs.track_task("test"):
            pass
