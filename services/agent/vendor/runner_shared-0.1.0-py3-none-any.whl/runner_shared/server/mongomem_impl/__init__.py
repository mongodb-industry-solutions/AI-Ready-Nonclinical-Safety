"""Mongomem HTTP Server Implementation.

This module provides HTTP REST API wrapper around mongomem_core engine.
"""

from runner_shared.server.mongomem_impl.app import create_app

__all__ = ["create_app"]
