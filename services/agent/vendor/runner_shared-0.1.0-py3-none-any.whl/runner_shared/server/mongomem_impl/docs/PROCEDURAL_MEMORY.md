# Procedural Memory

Procedural memory stores **reusable procedures (skills)** that agents can discover, retrieve, and follow. Think of it as a knowledge base of "how-to" instructions — from deployment runbooks to code review checklists — stored in MongoDB with vector search for semantic retrieval.

Designed for compatibility with Anthropic's SKILL.md format while being **model-agnostic** and adding MongoDB-native extensions (versioning, RBAC, reinforcement, vector search).

## Why Procedural Memory?

| Problem | Procedural Memory Solution |
|---------|---------------------------|
| Skills live as scattered `.md` files on disk | Durable, queryable MongoDB storage with vector search |
| No way to discover which skill applies | Embedding-based retrieval finds the right procedure for any query |
| Skills are tied to one LLM vendor (Claude) | Model-agnostic — works with any LLM |
| No version history or audit trail | Full versioning with `memory_lineage_id` |
| No feedback loop on skill quality | Reinforcement counting tracks which procedures are validated by repeated use |
| Manual sharing and access control | RBAC (private / shared / org) with publishing support |

## Architecture

```
┌──────────────────────────────────────────────────────────────────────────┐
│                       Procedural Memory Flow                            │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ENTRY POINTS                                                            │
│  ════════════                                                            │
│                                                                          │
│  ┌──────────────┐   ┌──────────────┐   ┌──────────────────────────────┐ │
│  │  Manual API  │   │  SKILL.md    │   │  Extraction Pipeline         │ │
│  │  create/     │   │  Migration   │   │  (conversations → procedures)│ │
│  │  update/     │   │  import/     │   │  extract → score →           │ │
│  │  delete      │   │  export      │   │  consolidate → persist       │ │
│  └──────┬───────┘   └──────┬───────┘   └──────────────┬───────────────┘ │
│         │                  │                           │                  │
│         ▼                  ▼                           ▼                  │
│  ┌──────────────────────────────────────────────────────────────────┐    │
│  │                    CRUD Layer (memory/procedural.py)              │    │
│  │  create · bulk_create · upsert · get · list · update · delete    │    │
│  │  search (vector) · update_embedding · soft_delete                │    │
│  └──────────────────────────┬───────────────────────────────────────┘    │
│                             │                                            │
│                             ▼                                            │
│  ┌──────────────────────────────────────────────────────────────────┐    │
│  │              MongoDB: memory_procedural collection                │    │
│  │                                                                    │    │
│  │  B-tree indexes: org+procedure (unique), lineage, tags, backlog   │    │
│  │  Vector index:   proc_embedding_vector_index (1024d)              │    │
│  │  Text index:     proc_text_search_index                           │    │
│  └──────────────────────────┬───────────────────────────────────────┘    │
│                             │                                            │
│                             ▼                                            │
│  RETRIEVAL                                                               │
│  ═════════                                                               │
│                                                                          │
│  ┌──────────────────────────────────────────────────────────────────┐    │
│  │  fetch_procedural_memories() / engine.fetch_procedural_memories() │    │
│  │      → vector search → deduplicate → rank → MemoryChunk[]        │    │
│  └──────────────────────────┬───────────────────────────────────────┘    │
│                             │                                            │
│                             ▼                                            │
│  ┌──────────────────────────────────────────────────────────────────┐    │
│  │  RetrievalHub (parallel multi-source fetch)                       │    │
│  │  STM + Episodic + Semantic + Taxonomic + PROCEDURAL               │    │
│  │      → ContextBuilder → ranked, budgeted context for LLM         │    │
│  └──────────────────────────────────────────────────────────────────┘    │
│                                                                          │
│  CONSUMPTION                                                             │
│  ═══════════                                                             │
│                                                                          │
│  Agent frameworks (LangGraph, CrewAI, custom) consume procedures:        │
│  • Discovery phase:  procedure name + description (~100 tokens)          │
│  • Activation phase: full content body (<5000 tokens)                    │
│  • Execution phase:  structured steps[] + resources[] (on demand)        │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘
```

## Progressive Disclosure Model

Procedural memory follows a 3-phase progressive disclosure model (compatible with SKILL.md):

| Phase | What's Returned | Token Budget | When |
|-------|----------------|--------------|------|
| **Discovery** | `procedure` + `description` | ~100 tokens | Agent is deciding which skills might apply |
| **Activation** | `content` (full markdown body) | <5000 tokens | Agent has selected this skill and needs full instructions |
| **Execution** | `steps[]` + `resources[]` | On demand | Framework is executing the procedure step-by-step |

This means vector search returns lightweight discovery data first. The agent (or framework) fetches the full content only when it decides to activate the skill.

## Data Model

### ProceduralIn (Input)

```python
ProceduralIn(
    # --- Discovery phase ---
    procedure="deploy-app",          # Unique kebab-case name (per org)
    description="Deploy the app to production using Docker",

    # --- Activation phase ---
    content="# Deploy\n\n1. Build image\n2. Push to registry\n3. ...",
    content_token_count=150,         # Optional, for budget-aware retrieval

    # --- Execution phase ---
    steps=[
        ProceduralStep(step_type="code", content="docker build -t app .",
                       description="Build Docker image", language="bash"),
        ProceduralStep(step_type="code", content="docker push registry/app",
                       description="Push to registry", language="bash"),
        ProceduralStep(step_type="validation", content="curl http://app/health",
                       description="Health check", expected_output="200 OK"),
    ],
    resources=[
        ProceduralResource(path="scripts/deploy.sh", resource_type="script",
                          language="bash", content="#!/bin/bash\n..."),
    ],

    # --- SKILL.md metadata ---
    allowed_tools=["Bash", "Read", "Write"],
    compatibility="linux, macOS",
    license="MIT",

    # --- mongomem extensions ---
    tags=["deployment", "docker", "production"],
    trigger_conditions=["user asks to deploy", "CI pipeline triggers"],
    visibility="org",                # private | shared | org
    source_format="skill.md",       # If migrated
    source_path="/skills/deploy/SKILL.md",
)
```

### Step Types

| Type | Purpose | Example |
|------|---------|---------|
| `instruction` | Prose instructions for the agent | "Review the PR description and check for breaking changes" |
| `code` | Executable code block | `docker build -t app .` |
| `validation` | Assertion or check | `curl http://app/health` with `expected_output="200 OK"` |
| `prompt` | Template to send to LLM | `"Summarize the following document: {doc}"` |
| `human_input` | Human approval gate | "Please review and approve the deployment" |

### Resource Types

| Type | Directory | Example |
|------|-----------|---------|
| `script` | `scripts/` | `scripts/deploy.sh`, `scripts/extract.py` |
| `reference` | `references/` | `references/api-docs.md` |
| `asset` | `assets/` | `assets/config.json`, `assets/template.yaml` |

## Lifecycle Flows

### Flow 1: Manual Creation

The simplest path. A developer or agent explicitly creates a procedure.

```python
from mongomem_core import MemoryEngine

engine = MemoryEngine.from_env(embedder=my_embedder)

result = engine.create_procedural(
    procedure="deploy-app",
    description="Deploy the application to production",
    content="# Deploy\n\n1. Build the Docker image\n2. Push to registry\n3. Update k8s",
    org_id="org_1",
    user_id="user_1",
    tags=["deployment", "docker"],
    steps=[
        {"step_type": "code", "content": "docker build -t app .",
         "description": "Build image", "language": "bash"},
        {"step_type": "code", "content": "kubectl apply -f deploy.yaml",
         "description": "Deploy to k8s", "language": "bash"},
    ],
)

print(f"Created: {result.id}, embedded: {result.has_embedding}")
```

### Flow 2: SKILL.md Migration

Import existing SKILL.md files from disk into MongoDB, or export procedures back to SKILL.md.

```python
from mongomem_core.migration import discover_skills, ingest_skills, export_skills

# Discover SKILL.md files
paths = discover_skills("/path/to/skills/")
# ["/path/to/skills/deploy/SKILL.md", "/path/to/skills/review/SKILL.md", ...]

# Batch import
result = ingest_skills(
    engine, paths,
    org_id="org_1", user_id="user_1",
    tags=["imported"],
    generate_embeddings=True,
)
print(f"Imported: {result['imported_count']}, Skipped: {result['skipped_count']}")

# Export back to SKILL.md
result = export_skills(engine, org_id="org_1", output_dir="/exported/skills/")
print(f"Exported: {result['exported_count']}")
```

#### SKILL.md Format

```markdown
---
name: deploy-app
description: Deploy the application to production
allowed-tools: Bash Read Write
compatibility: linux, macOS
license: MIT
---

# Deploy

1. Build the Docker image
2. Push to registry
3. Update Kubernetes deployment
4. Verify health check
```

### Flow 3: Update and Delete

```python
# Update by procedure name
engine.update_procedural(
    org_id="org_1",
    procedure="deploy-app",
    description="Deploy the app to production via Docker + K8s",
    tags=["deployment", "docker", "kubernetes"],
)

# Update by ID
engine.update_procedural(
    org_id="org_1",
    id="64a1b2c3...",
    content="Updated deployment instructions...",
    steps=[...],  # Replace steps entirely
)

# Soft delete (recoverable, auditable)
engine.delete_procedural(org_id="org_1", procedure="deploy-app", soft=True)

# Hard delete (permanent)
engine.delete_procedural(org_id="org_1", procedure="deploy-app", soft=False)
```

### Flow 4: Retrieval

Procedures participate in the unified retrieval pipeline alongside all other memory types.

```python
# Direct procedural fetch
chunks = engine.fetch_procedural_memories(
    query="how do I deploy the app?",
    org_id="org_1",
    top_k=5,
    similarity_threshold=0.7,
)

for chunk in chunks:
    print(f"{chunk.metadata['procedure']}: {chunk.metadata['description']}")
    print(f"  Score: {chunk.similarity_score:.3f}")

# Full context build (includes procedural alongside semantic, episodic, etc.)
from mongomem_core.models.retrieval import MemorySource

response = engine.build_context(
    query="How do I deploy the application?",
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    enabled_sources={MemorySource.SEMANTIC, MemorySource.PROCEDURAL},
)
```

### Flow 5: Extraction-Driven Creation

The extraction pipeline follows the same pattern as semantic, taxonomic, and episodic extraction:

```
Conversation → Snapshot → ProceduralExtractor → Scorer → Consolidator → Persist
```

```python
from mongomem_core.extraction.procedural import create_procedural_pipeline

pipeline = create_procedural_pipeline(
    db=engine._db,
    llm=my_llm,
    embedder=my_embedder,
)

result = pipeline.run(
    messages=conversation_messages,
    org_id="org_1",
    user_id="user_1",
    source_id="snapshot_abc",
)

print(f"Extracted: {result.extracted_count}")
print(f"Added: {result.consolidation_stats.add_count}")
print(f"Updated: {result.consolidation_stats.update_count}")
print(f"Reinforced: {result.consolidation_stats.reinforce_count}")
```

The consolidator makes one of four decisions per extraction:

| Decision | Condition | Effect |
|----------|-----------|--------|
| **ADD** | No similar procedure exists | Insert new document |
| **UPDATE** | Similar procedure (0.85–0.95 similarity) | New version, supersede old |
| **REINFORCE** | Near-identical procedure (≥0.95 similarity) | Increment `reinforcement_count` |
| **DUPLICATE** | Exact match already reinforced by this source | Skip |

#### Reinforcement

When the system keeps seeing the same procedure across conversations, reinforcement tracks that signal:

```
reinforcement_count: 7          # Seen 7 times
last_reinforced_at: 2026-03-10  # Most recent occurrence
reinforcement_history: [...]     # Timestamps (capped at 50)
```

Highly reinforced procedures are proven, validated skills. Retrieval can boost them during ranking.

## Versioning

Every procedure has a `memory_lineage_id` that links all versions together:

```
v1: deploy-app (is_latest=True,  memory_lineage_id="abc", version=1)
         │
         ▼  UPDATE decision
v2: deploy-app (is_latest=True,  memory_lineage_id="abc", version=2, previous_version_id="v1-id")
v1: deploy-app (is_latest=False, memory_lineage_id="abc", version=1)  ← superseded
```

- Vector search filters `is_latest=True` by default
- Both versions remain in the DB for full audit trail
- `previous_version_id` chains the history

## RBAC and Visibility

Procedural memory inherits the same visibility model as all other memory types:

```python
# Private — only the creator can see it
engine.create_procedural(..., visibility="private")

# Shared — specific group can see it
engine.create_procedural(..., visibility="shared", project_id="team_platform")

# Org-wide — everyone in the org
engine.create_procedural(..., visibility="org")
```

## Code Execution (ExecutorProtocol)

mongomem stores procedures and their code steps but **never executes code itself**. Execution is delegated to your sandbox via the `ExecutorProtocol` interface.

### The Protocol

```python
from mongomem_core.protocols import ExecutorProtocol
from mongomem_core.models.execution import ExecutionResult

class ExecutorProtocol(Protocol):
    def execute(self, code: str, language: str, *,
                timeout_ms: int = 30000,
                context: dict | None = None) -> ExecutionResult: ...

    @property
    def supported_languages(self) -> list[str]: ...

    @property
    def executor_id(self) -> str: ...
```

### ExecutionResult

```python
@dataclass
class ExecutionResult:
    success: bool        # Whether execution succeeded
    stdout: str          # Standard output
    stderr: str          # Standard error
    exit_code: int       # Process exit code
    duration_ms: int     # Execution time in milliseconds
    language: str        # Language that was executed
    executor_id: str     # Which executor ran this
```

### Implementing an Executor

Implement the protocol with any sandbox. mongomem doesn't care which one — E2B, Modal, Docker, subprocess, Jupyter, or your own.

**E2B example:**

```python
from e2b_code_interpreter import Sandbox
from mongomem_core.models.execution import ExecutionResult

class E2BExecutor:
    def __init__(self):
        self._sandbox = Sandbox()

    def execute(self, code: str, language: str, *,
                timeout_ms: int = 30000, context: dict | None = None) -> ExecutionResult:
        import time
        start = time.monotonic()
        result = self._sandbox.run_code(code, language=language,
                                         timeout=timeout_ms / 1000)
        elapsed = int((time.monotonic() - start) * 1000)

        return ExecutionResult(
            success=result.exit_code == 0,
            stdout=result.stdout,
            stderr=result.stderr,
            exit_code=result.exit_code,
            duration_ms=elapsed,
            language=language,
            executor_id=self.executor_id,
        )

    @property
    def supported_languages(self) -> list[str]:
        return ["python", "javascript", "bash"]

    @property
    def executor_id(self) -> str:
        return "e2b-sandbox"
```

**Docker example:**

```python
import docker
from mongomem_core.models.execution import ExecutionResult

class DockerExecutor:
    def __init__(self, image: str = "python:3.11-slim"):
        self._client = docker.from_env()
        self._image = image

    def execute(self, code: str, language: str, *,
                timeout_ms: int = 30000, context: dict | None = None) -> ExecutionResult:
        import time
        start = time.monotonic()
        try:
            output = self._client.containers.run(
                self._image,
                command=["python", "-c", code] if language == "python"
                        else ["bash", "-c", code],
                remove=True,
                timeout=timeout_ms // 1000,
                mem_limit="256m",
                network_mode="none",
            )
            elapsed = int((time.monotonic() - start) * 1000)
            return ExecutionResult(
                success=True, stdout=output.decode(), stderr="",
                exit_code=0, duration_ms=elapsed,
                language=language, executor_id=self.executor_id,
            )
        except docker.errors.ContainerError as e:
            elapsed = int((time.monotonic() - start) * 1000)
            return ExecutionResult(
                success=False, stdout="", stderr=str(e),
                exit_code=e.exit_status, duration_ms=elapsed,
                language=language, executor_id=self.executor_id,
            )

    @property
    def supported_languages(self) -> list[str]:
        return ["python", "bash"]

    @property
    def executor_id(self) -> str:
        return "docker-sandbox"
```

### Wiring into the Engine

Pass your executor when creating the engine:

```python
engine = MemoryEngine.from_env(
    embedder=my_embedder,
    executor=E2BExecutor(),       # or DockerExecutor(), or any implementation
)
```

### Executing Procedure Steps

> **Execution Boundary**: mongomem provides the *data contract* — the procedure, its steps, and their code. It does **not** orchestrate execution. There is no retry logic, rollback, dependency graph, or step state management in mongomem. Those are responsibilities of your agent framework (LangGraph, CrewAI, etc.) or your own orchestration layer. The `ExecutorProtocol` is a thin observation hook that your framework calls — mongomem never calls it automatically.

When your agent activates a procedure, iterate its steps and delegate code steps to the executor:

```python
proc = engine.get_procedural(org_id="org_1", procedure="deploy-app")

for step in proc.steps:
    if step.step_type == "code" and engine.executor:
        result = engine.executor.execute(
            code=step.content,
            language=step.language or "bash",
            timeout_ms=step.timeout_ms,
        )
        print(f"Step: {step.description}")
        print(f"  Success: {result.success}, Output: {result.stdout[:100]}")

        if not result.success:
            print(f"  Error: {result.stderr}")
            break  # Stop or handle failure

    elif step.step_type == "human_input":
        # Pause for human approval
        pass

    elif step.step_type == "instruction":
        # Send to LLM for interpretation
        pass
```

### Sandbox Options

| Sandbox | Type | Best For |
|---------|------|----------|
| [E2B](https://e2b.dev) | Cloud VM | Production, multi-language, fully isolated |
| [Modal](https://modal.com) | Serverless container | Heavy compute, GPU workloads |
| [Docker SDK](https://docker-py.readthedocs.io) | Local container | Self-hosted, air-gapped |
| [Daytona](https://daytona.io) | Dev environment | Full workspace sandboxes |
| [Jupyter kernels](https://jupyter.org) | Notebook | Data science, stateful sessions |
| `subprocess` | Raw process | Dev/testing only (not sandboxed) |

### Design Principle

The executor is intentionally a thin protocol — mongomem stores *what* to execute (the procedure's code steps), your sandbox decides *how* to execute it safely. You can swap sandboxes (Docker in dev, E2B in prod) without changing any procedures.

---

## Direct CRUD Access

For advanced use cases, import CRUD functions directly:

```python
from mongomem_core.memory.procedural import (
    create_procedural,
    bulk_create_procedural,
    upsert_procedural,
    get_procedural,
    list_procedural,
    update_procedural,
    update_procedural_embedding,
    soft_delete_procedural,
    delete_procedural,
    delete_procedural_by_ids,
    search_procedural,
)
```

## Relationship to Other Memory Types

| Memory Type | What It Stores | How Procedural Relates |
|-------------|---------------|----------------------|
| **Semantic** | Facts and knowledge | Procedures reference facts; semantic provides context for execution |
| **Episodic** | Event summaries | Extraction pipeline uses episodes as source material for procedure discovery |
| **Taxonomic** | Domain terms | Tags and trigger conditions can reference taxonomic terms |
| **STM / Snapshot** | Conversation turns | Raw material for extraction-driven procedure creation |
| **User Context** | Preferences | Procedures can be personalized based on user context |

## Next Steps

- **[Integration Guides](procedural-integrations.md)** — LangGraph, CrewAI, Agent Engine, basic usage
- **[Engine API Reference](engine-api.md)** — Full method documentation
- **[Memory Types Guide](MEMORY_TYPES.md)** — How all memory types work together
