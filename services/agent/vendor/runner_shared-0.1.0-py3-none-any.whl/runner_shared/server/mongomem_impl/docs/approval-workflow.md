# Approval Workflow for Memory Extractions

This guide explains how to use the **manual approval mode** for memory extractions, allowing users to review and approve/reject extractions before they are persisted to the database.

## Overview

By default, memory extractions are immediately persisted (`approval_mode="auto"`). With manual approval mode, extractions are **staged** in a pending collection for review before being committed to the memory database.

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│  Pipeline runs  │────▶│  Pending Store   │────▶│  User Reviews   │
│  (extraction)   │     │  (staged items)  │     │  (approve/reject)│
└─────────────────┘     └──────────────────┘     └────────┬────────┘
                                                          │
                        ┌──────────────────┐              │
                        │  Memory DB       │◀─────────────┘
                        │  (persisted)     │   (on approve)
                        └──────────────────┘
```

## Configuration

### Worker-Level Configuration

Set the default approval mode in your worker configuration:

```python
from mongomem_worker.config import WorkerConfig

config = WorkerConfig(
    mongo_uri="mongodb://localhost:27017",
    db_name="my_db",
    default_approval_mode="manual",  # "auto" (default) or "manual"
)
```

### Per-Pipeline Override

Override the default mode when calling a pipeline:

```python
from mongomem_core.models.memory.base import ChunkVisibility

result = semantic_pipeline.run(
    messages=messages,
    org_id="org_123",
    user_id="user_456",
    source_id="session_789",
    approval_mode="manual",
    visibility=ChunkVisibility.SHARED,
    project_id="team_alpha",
)
```

## Extraction Types

All extraction pipelines support the approval workflow:

| Pipeline | Payload Type | Description |
|----------|-------------|-------------|
| Semantic | `PendingDecisionPayload` | Facts and knowledge extracted from conversations |
| Episodic | `PendingDecisionPayload` | Event-based memories with temporal context |
| Taxonomic | `PendingDecisionPayload` | Hierarchical category/tag extractions |
| Preferences | `PendingPreferencesPayload` | User preferences and context |

## Usage

### 1. Run Extraction in Manual Mode

```python
from mongomem_core.extraction.semantic import SemanticPipeline

pipeline = SemanticPipeline(db=db, embedder=embedder, llm=llm)

result = pipeline.run(
    messages=[
        {"role": "user", "content": "I prefer dark mode and Python."},
        {"role": "assistant", "content": "Noted! I'll remember that."},
    ],
    org_id="org_123",
    user_id="user_456",
    source_id="session_789",
    approval_mode="manual",
)

# Result contains pending IDs instead of persisted memory IDs
print(result.pending_ids)      # ["6789abc...", "6789abd..."]
print(result.approval_mode)    # "manual"
print(result.total_extracted)  # 2
```

### 2. Retrieve Pending Items

```python
from mongomem_core.extraction.approval import PendingStore

store = PendingStore(db)

# Find all pending items for an org
pending = store.find(org_id="org_123", status="pending")

# Filter by user
pending = store.find(org_id="org_123", user_id="user_456", status="pending")

# Filter by extraction type
pending = store.find(org_id="org_123", extraction_type="semantic", status="pending")

# Get a specific pending item
item = store.get(pending_id="6789abc...")
```

### 3. Approve Extractions

Approving an extraction persists it to the memory database:

```python
from mongomem_core.extraction.approval import ApprovalOrchestrator
from mongomem_core.models.memory.base import ChunkVisibility

orchestrator = ApprovalOrchestrator(db=db, embedder=embedder)

# Approve a single item
result = await orchestrator.approve(
    pending_id="6789abc...",
    reviewed_by="admin@example.com",
)
print(result.memory_id)  # ID of the persisted memory

# Approve with visibility override (port to a group)
result = await orchestrator.approve(
    pending_id="6789abc...",
    reviewed_by="admin@example.com",
    visibility=ChunkVisibility.SHARED,
    project_id="team_beta",
)

# Batch approval
batch_result = await orchestrator.approve_batch(
    pending_ids=["id1", "id2", "id3"],
    reviewed_by="admin@example.com",
)
print(batch_result.approved)  # Number approved
print(batch_result.failed)    # Number failed
print(batch_result.errors)    # Dict of {id: error_message}
```

### 4. Reject Extractions

Rejecting marks the item as rejected (kept for audit) without persisting:

```python
result = await orchestrator.reject(
    pending_id="6789abc...",
    reviewed_by="admin@example.com",
    reason="Not relevant to user context",  # Optional
)
```

### 5. Unpublish (Soft-Delete with Optional Restage)

Remove a published memory and optionally restage it for re-review:

```python
result = await orchestrator.unpublish(
    memory_id="memory_abc123",
    memory_type="semantic",  # "semantic", "episodic", "taxonomic", "preferences"
    org_id="org_123",
    reason="Contains outdated information",
    restage=True,  # Creates a new pending item for re-approval
)

print(result.unpublished)   # True
print(result.restaged)      # True (if restage=True)
print(result.pending_id)    # New pending ID (if restaged)
```

## Visibility and Scoping

Extractions support three visibility levels:

| Visibility | Description | Requires |
|------------|-------------|----------|
| `PRIVATE` | Only visible to the user | Default |
| `SHARED` | Visible to a specific group | `project_id` required |
| `ORG` | Visible to entire organization | - |

### Setting Visibility at Extraction Time

```python
from mongomem_core.models.memory.base import ChunkVisibility

result = pipeline.run(
    messages=messages,
    org_id="org_123",
    user_id="user_456",
    source_id="session_789",
    approval_mode="manual",
    visibility=ChunkVisibility.SHARED,
    project_id="engineering_team",
)
```

### Changing Visibility at Approval Time

You can override visibility when approving:

```python
# Original extraction was PRIVATE, approve as SHARED
result = await orchestrator.approve(
    pending_id="6789abc...",
    reviewed_by="admin@example.com",
    visibility=ChunkVisibility.SHARED,
    project_id="new_team",
)
```

## TTL and Cleanup

Pending items have automatic expiration to prevent unbounded growth:

| Item State | Default TTL | Configuration |
|------------|-------------|---------------|
| Pending (unreviewed) | 72 hours | `pending_ttl_hours` |
| Approved/Rejected | 30 days | `audit_retention_days` |

### Custom TTL Configuration

```python
store = PendingStore(
    db=db,
    pending_ttl_hours=48,        # Pending items expire after 48 hours
    audit_retention_days=90,     # Keep audit trail for 90 days
)

orchestrator = ApprovalOrchestrator(
    db=db,
    embedder=embedder,
    pending_ttl_hours=48,
    audit_retention_days=90,
)
```

## Data Model

### PendingExtraction

The pending collection stores items with this structure:

```python
{
    "_id": ObjectId("..."),
    "org_id": "org_123",
    "user_id": "user_456",
    "source_id": "session_789",
    "extraction_type": "semantic",  # semantic, episodic, taxonomic, preferences
    "status": "pending",            # pending, approved, rejected
    "payload": {
        "kind": "decision",         # decision or preferences or memory_ref
        # ... type-specific fields
    },
    "visibility": "private",
    "project_id": null,
    "created_at": ISODate("..."),
    "expires_at": ISODate("..."),   # TTL index field
    "reviewed_by": null,
    "reviewed_at": null,
}
```

### Payload Types

**PendingDecisionPayload** (semantic/episodic/taxonomic):
```python
{
    "kind": "decision",
    "action": "ADD",  # ADD, UPDATE, REINFORCE
    "extraction": { ... },  # ScoredExtraction data
    "existing_id": null,    # Set for UPDATE/REINFORCE
    "embedding": [0.1, 0.2, ...],
    "embedding_model_id": "voyage-3",
}
```

**PendingPreferencesPayload** (preferences):
```python
{
    "kind": "preferences",
    "preferences": { ... },
    "evidence": [0, 1, 2],  # Message indices
    "session_id": "session_789",
}
```

**PendingMemoryRefPayload** (unpublish + restage):
```python
{
    "kind": "memory_ref",
    "memory_id": "memory_abc123",
    "memory_type": "semantic",
    "unpublish_reason": "Needs correction",
}
```

## Indexes

The `extraction_pending` collection has the following indexes:

| Index | Purpose |
|-------|---------|
| `org_id, status, created_at` | Query pending items by org |
| `org_id, user_id, status` | Query by user |
| `org_id, extraction_type, status` | Query by type |
| `expires_at` (TTL) | Automatic cleanup |

## Best Practices

1. **Use batch approval** for high-volume workflows to reduce round trips
2. **Set appropriate TTLs** based on your review SLA
3. **Include `reviewed_by`** for audit compliance
4. **Use visibility overrides** to port extractions between scopes during review
5. **Leverage `restage`** in unpublish for corrections rather than creating new extractions

## Error Handling

```python
from mongomem_core.extraction.approval.orchestrator import EmbedderRequiredError

try:
    result = await orchestrator.approve(pending_id="...")
except EmbedderRequiredError:
    # Embedder required for ADD operations
    pass
except ValueError as e:
    # Invalid pending_id, already processed, etc.
    print(e)
```
