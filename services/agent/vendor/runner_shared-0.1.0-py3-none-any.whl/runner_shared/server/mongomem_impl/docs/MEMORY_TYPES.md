# Memory Types Guide

Understanding mongomem's memory hierarchy is key to using it effectively.
This guide explains each memory type, when to use it, and how they work together.

## The Big Picture

The engine supports two operating paradigms:

### Traditional Mode (STM accumulation)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    TRADITIONAL MODE - Memory Hierarchy                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  CONVERSATIONS (temporal, session-based)                                     │
│  ═══════════════════════════════════════                                     │
│                                                                              │
│    write_turn()                                                              │
│        │                                                                     │
│        ▼                                                                     │
│    ┌────────┐     auto-promote      ┌──────────┐    summarize   ┌─────────┐ │
│    │  STM   │ ──────────────────►   │ Snapshot │ ────────────►  │Episodic │ │
│    │(turns) │   (20 msgs or         │ (chunks) │   (optional)   │(summary)│ │
│    └────────┘    30 min idle)       └──────────┘                └─────────┘ │
│                                           │                                  │
│                                           │ retrieve_conversation_thread()   │
│                                           ▼                                  │
│                                    "Resume conversation"                     │
│                                    "What did we discuss?"                    │
│                                                                              │
│  Context grows with conversation length (unbounded)                          │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### IWM Mode (Internal Working Memory)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      IWM MODE - Constant Context Size                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  AGENT STATE (overwritten each turn)                                         │
│  ════════════════════════════════════                                        │
│                                                                              │
│    update_internal_state()                                                   │
│        │                                                                     │
│        ▼                                                                     │
│    ┌────────────────────┐                                                    │
│    │  Internal State    │  ◄── Agent's self-authored belief state            │
│    │  (overwrites)      │      "User wants X. Working on Y. Key: Z."         │
│    │  ~500 tokens       │                                                    │
│    └────────────────────┘                                                    │
│              │                                                               │
│              ▼                                                               │
│    build_memory_context()  ──►  IS (guaranteed) + LTM (fills budget)         │
│                                                                              │
│  Context stays constant (~4000 tokens) regardless of conversation length     │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Common to Both Modes

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  KNOWLEDGE (persistent, queryable)                                           │
│  ═════════════════════════════════                                           │
│                                                                              │
│    create_semantic()  ──►  ┌──────────┐                                      │
│                            │ Semantic │  ◄── Facts, definitions, docs        │
│                            └──────────┘                                      │
│                                                                              │
│  PROCEDURES (reusable skills)                                                │
│  ════════════════════════════                                                │
│                                                                              │
│    create_procedural()  ──►  ┌────────────┐                                  │
│                              │ Procedural │  ◄── How-to, runbooks, skills    │
│                              └────────────┘                                  │
│                                                                              │
│  PREFERENCES (per-user configuration)                                        │
│  ════════════════════════════════════                                        │
│                                                                              │
│    create_user_context()  ──►  ┌─────────────┐                               │
│                                │User Context │  ◄── Tone, style, language    │
│                                └─────────────┘                               │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Memory Types Explained

### 1. Short-Term Memory (STM)

**What it is:** Individual conversation messages (turns).

**Use when:** Storing real-time chat messages.

**Lifecycle:** Temporary → auto-promoted to Snapshots.

```python
# Store a user message
engine.write_turn(
    session_id="chat_123",
    role="user",
    content="What's the weather?",
    org_id="org_1",
    user_id="user_1",
)

# Store assistant response
engine.write_turn(
    session_id="chat_123",
    role="assistant",
    content="It's sunny and 72°F.",
    org_id="org_1",
    user_id="user_1",
)
```

**Key points:**
- Each turn is one message in a conversation
- Automatically embedded if embedder is provided
- Auto-promoted to Snapshot when thresholds are met
- Supports tool calls and tool results
- **Not available in IWM mode** (use Internal State instead)

---

### 2. Internal State (IWM Mode)

**What it is:** The agent's self-authored belief state, overwritten each turn.

**Use when:** Long-horizon agents that need constant context size.

**Lifecycle:** Overwritten each turn (not accumulated).

```python
from mongomem_core import MemoryEngine, MemoryMode

engine = MemoryEngine(mode=MemoryMode.IWM)

# Agent writes its current understanding
result = engine.update_internal_state(
    session_id="chat_123",
    org_id="org_1",
    user_id="user_1",
    content="""
    User: Software engineer, prefers Python
    Current task: Debugging OAuth flow
    Key insight: Token expires after 1 hour
    Next step: Implement refresh logic
    """,
    model_id="gpt-4",
    update_reason="turn_end",
)

print(f"Version: {result.version}")  # 1, 2, 3, ... (increments each update)
```

**Key points:**
- One document per (session_id, org_id) — overwrites previous
- Version increments on every update
- Content hash (SHA256[:16]) for integrity
- Token count tracked (actual or estimated)
- **Only available in IWM and HYBRID modes**

**Why use IWM?**
- **Constant cost**: Token usage doesn't grow with conversation length
- **Better reasoning**: Agent focuses on current state, not 100+ messages
- **Scalable**: No memory pressure from long sessions

---

### 3. Snapshot Memory (Traditional Mode)

**What it is:** Consolidated chunks of conversation (multiple STM turns).

**Use when:** You need conversation context for retrieval.

**Lifecycle:** Created from STM → optionally promoted to Episodic.

```python
# Manual snapshot creation
from mongomem_core.models.memory import SnapshotIn, SnapshotMessage

snapshot = engine.create_snapshot(
    snapshot_in=SnapshotIn(
        session_id="chat_123",
        messages=[
            SnapshotMessage(role="user", content="...", timestamp=now),
            SnapshotMessage(role="assistant", content="...", timestamp=now),
        ],
        snapshot_reason="manual",
    ),
    org_id="org_1",
    user_id="user_1",
)

# Or auto-promote from STM
engine.promote_stm_to_snapshot("chat_123", "org_1", "user_1")

# Retrieve conversation threads
thread = engine.retrieve_conversation_thread("org_1", "MongoDB indexes")
```

**Key points:**
- Middle tier between STM and Episodic
- Enables semantic search over conversations
- Supports topic-based grouping
- Thread retrieval works on snapshots

---

### 4. Episodic Memory

**What it is:** Summaries of events, meetings, or conversation outcomes.

**Use when:** You want to remember WHAT happened, not every detail.

```python
result = engine.create_episodic(
    title="Project kickoff meeting",
    content="Full transcript here...",
    summary_text="Discussed Q1 goals. Agreed on MongoDB migration timeline.",
    summary_type="llm",  # or "manual", "heuristic"
    org_id="org_1",
    user_id="user_1",
    participants=["alice", "bob"],
    tags=["meeting", "planning"],
)
```

**Key points:**
- Higher-level than Snapshots
- Contains summaries, not raw messages
- Good for long-term knowledge extraction
- Can reference source snapshots

---

### 5. Semantic Memory

**What it is:** Facts, definitions, and knowledge.

**Use when:** Storing things that are TRUE, not conversations.

```python
# Store a fact
result = engine.create_semantic(
    label="mongodb-acid",  # Unique identifier
    text="MongoDB supports ACID transactions since version 4.0.",
    org_id="org_1",
    user_id="user_1",
    source="mongodb-docs",
)

# Retrieve by label
fact = engine.get_semantic(org_id="org_1", label="mongodb-acid")

# List all facts
facts = engine.list_semantic(org_id="org_1", limit=100)
```

**Key points:**
- Persistent knowledge base
- Supports vector search (with embedder)
- Use `label` for unique identification
- Great for RAG (Retrieval Augmented Generation)

---

### 6. Procedural Memory

**What it is:** Reusable procedures (skills) with structured steps.

**Use when:** Storing how-to instructions that agents can discover and follow.

**Lifecycle:** Permanent, versioned, with reinforcement tracking.

```python
# Store a procedure
result = engine.create_procedural(
    procedure="deploy-app",
    description="Deploy the application to production",
    content="# Deploy\n\n1. Build Docker image\n2. Push to registry\n3. Update k8s",
    org_id="org_1",
    user_id="user_1",
    tags=["deployment", "docker"],
    steps=[
        {"step_type": "code", "content": "docker build -t app .",
         "description": "Build image", "language": "bash"},
        {"step_type": "code", "content": "kubectl apply -f deploy.yaml",
         "description": "Deploy", "language": "bash"},
    ],
)

# Retrieve by name
proc = engine.get_procedural(org_id="org_1", procedure="deploy-app")

# Semantic search
chunks = engine.fetch_procedural_memories(
    query="how do I deploy?",
    org_id="org_1",
    top_k=5,
)

# List all procedures
procs = engine.list_procedural(org_id="org_1", tags=["deployment"])
```

**Key points:**
- SKILL.md compatible (import/export with `mongomem_core.migration`)
- Progressive disclosure: name+description → full content → structured steps
- Versioned with `memory_lineage_id` for full audit trail
- Reinforcement tracking for validated, proven procedures
- Supports vector search for semantic retrieval
- Model-agnostic — works with any LLM

See [Procedural Memory Guide](PROCEDURAL_MEMORY.md) for full documentation.

---

### 7. User Context

**What it is:** User preferences and communication style.

**Use when:** Personalizing agent responses.

```python
# Store preferences
result = engine.create_user_context(
    tone="friendly",
    style="concise",
    language="en",
    preferred_format="bullet_points",
    source="user_input",
    org_id="org_1",
    user_id="user_1",
)

# Get preferences
prefs = engine.get_user_context(org_id="org_1", user_id="user_1")
print(f"User prefers {prefs.tone} tone")
```

**Key points:**
- One per user (upsert behavior)
- Guides agent communication style
- Can be inferred or explicitly set

---

## When to Use What?

| Scenario | Memory Type | Example |
|----------|-------------|---------|
| Real-time chat message (Traditional) | **STM** | `write_turn()` |
| Agent belief state (IWM) | **Internal State** | `update_internal_state()` |
| Resume a conversation | **Snapshot** | `retrieve_conversation_thread()` |
| Store meeting summary | **Episodic** | `create_episodic()` |
| Store a fact/definition | **Semantic** | `create_semantic()` |
| Store a reusable procedure/skill | **Procedural** | `create_procedural()` |
| Remember user prefers formal tone | **User Context** | `create_user_context()` |
| Long-horizon agent (100+ turns) | **IWM mode** | `MemoryMode.IWM` |
| Standard chatbot | **Traditional mode** | `MemoryMode.TRADITIONAL` |

---

## The Promotion Pipeline

```
STM → Snapshot → Episodic
```

### STM → Snapshot (Automatic)

Triggered when:
- 20+ messages in session (default)
- 30+ minutes of inactivity
- Topic shift detected
- Manual trigger

```python
# Configure auto-promotion
from mongomem_core.models.config import SnapshotConfig

config = SnapshotConfig(
    strategy="auto",
    max_messages=20,        # Promote at 20 messages
    stale_minutes=30,       # Or 30 min idle
    embedding_strategy="transfer",  # Reuse STM embeddings
)
```

### Snapshot → Episodic (Optional)

Use when you want to:
- Compress conversation history
- Extract key takeaways
- Free up storage

```python
# Create episodic from snapshot
result = engine.create_episodic(
    title="Customer support session",
    summary_text="User asked about billing. Issue resolved.",
    snapshot_ref_id="snap_123",  # Reference to source
    org_id="org_1",
    user_id="user_1",
)
```

---

## Visibility & Sharing

All memory types support visibility control:

```python
# Private (default) - only creating user can see
visibility="private"

# Shared - specific group can see
visibility="shared"
project_id="team_engineering"

# Organization-wide
visibility="org"
```

---

## Summary Table

| Type | Purpose | Lifecycle | Vector Search | Mode |
|------|---------|-----------|---------------|------|
| **STM** | Chat messages | Temporary | Yes | Traditional, Hybrid |
| **Internal State** | Agent belief state | Overwritten each turn | No | IWM, Hybrid |
| **Snapshot** | Conversation chunks | Medium-term | Yes | Traditional, Hybrid |
| **Episodic** | Event summaries | Long-term | Yes | All |
| **Semantic** | Facts & knowledge | Permanent | Yes | All |
| **Procedural** | Skills & procedures | Permanent (versioned) | Yes | All |
| **User Context** | Preferences | Permanent | No | All |

---

## Next Steps

1. **[Quickstart](../examples/quickstart.py)** - Get running in 5 minutes
2. **[With Embeddings](../examples/with_embeddings.py)** - Enable vector search
3. **[Thread Retrieval](../examples/thread_retrieval.py)** - Resume conversations
4. **[IWM Mode Guide](IWM_MODE.md)** - Constant-size context for long-horizon agents
5. **[Procedural Memory Guide](PROCEDURAL_MEMORY.md)** - Skills, procedures, and SKILL.md migration
6. **[Integration Guides](procedural-integrations.md)** - LangGraph, CrewAI, Agent Engine
7. **[API Reference](engine-api.md)** - Full method documentation

