# Auto-RAG v1 — Design Document

## Overview

Add a document ingestion pipeline to `mongomem_core` that extracts text from documents, chunks it, and stores as semantic memories.

---

## Architecture Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| **Location** | `mongomem_core` (sync first) | Keep it headless, worker-optional later |
| **API Style** | `engine.ingest_documents(...)` | Matches existing pattern |
| **Deduplication** | User's responsibility | Keep v1 simple; user manages file paths |
| **Bulk Writes** | `bulk_create_semantic()` | ✅ Already implemented |
| **File Input** | Local paths | Start with local paths |
| **Retry Logic** | Configurable attempts + `on_failure` mode | `skip`, `raise`, or `collect` |

---

## Supported File Types

### Simple Extractor (v1)

| Extension | Library | Status |
|-----------|---------|--------|
| `.txt` | Built-in Python | ✅ Supported |
| `.pdf` | `pymupdf` | ✅ Supported |
| `.pptx` | `python-pptx` | ✅ Supported |
| `.docx` | `python-docx` | ✅ Supported |
| `.doc` | — | ❌ Not supported (legacy format) |

### Docling Extractor (Future)

| Extension | Status |
|-----------|--------|
| `.txt`, `.pdf`, `.pptx`, `.docx` | ✅ Supported |
| `.doc` | ✅ Supported |
| `.png`, `.jpg` (OCR) | ✅ Supported |

### File Validation

Unsupported files are **gracefully rejected** with clear error messages:

```python
# Behavior based on on_failure setting:
# - "skip": Log warning, continue with other files
# - "raise": Raise ValueError immediately
# - "collect": Collect errors, return in result
```

---

## Extractors

| Extractor | Dependencies | Use Case | Chunking Strategy |
|-----------|--------------|----------|-------------------|
| `"simple"` (default) | `pymupdf`, `python-pptx`, `python-docx` | Fast, text-based files | LangChain `RecursiveCharacterTextSplitter` |
| `"docling"` (future) | `docling` (optional) | Complex docs, OCR, tables | Docling's `HybridChunker` |

### Key Design Note

> Docling has **built-in chunking** — when using Docling, we use their chunkers 
> (HybridChunker/HierarchicalChunker) instead of LangChain. This preserves document structure.

---

## Chunking Configuration

```python
@dataclass
class ChunkConfig:
    """Configuration for text chunking."""
    
    # Size limits (in tokens)
    max_chunk_size: int = 400       # Maximum tokens per chunk
    min_chunk_size: int = 50        # Minimum tokens (filter small chunks)
    chunk_overlap: int = 50         # Overlap between chunks
    
    # Tokenizer
    encoding_name: str = "cl100k_base"  # OpenAI tokenizer
    
    # Behavior
    discard_small_chunks: bool = True   # Drop chunks below min_chunk_size
```

### Chunker Behavior

| Setting | Behavior |
|---------|----------|
| `max_chunk_size=400` | LangChain splits at ~400 tokens |
| `min_chunk_size=50` | Chunks < 50 tokens are discarded |
| `chunk_overlap=50` | 50 token overlap for context continuity |

---

## Chunk Metadata

Each chunk stored in semantic memory includes:

| Field | Description |
|-------|-------------|
| `source_file` | Original file path |
| `source_type` | `"txt"`, `"pdf"`, `"pptx"`, `"docx"` |
| `chunk_index` | Position in file (0-based) |
| `total_chunks` | Total chunks from this file |
| `title` | Document title (if available) |
| `author` | Document author (if available) |
| `page_count` / `slide_count` | Document length info |

---

## Directory Structure

```
src/mongomem_core/
├── ingest/                        # NEW: Document ingestion pipeline
│   ├── __init__.py
│   ├── models.py                  # IngestConfig, ChunkConfig, IngestResult
│   ├── extractors/
│   │   ├── __init__.py
│   │   ├── base.py               # DocumentExtractor protocol
│   │   ├── text.py               # PlainTextExtractor (.txt)
│   │   ├── pdf.py                # PyMuPDFExtractor (.pdf)
│   │   ├── pptx.py               # PythonPPTXExtractor (.pptx)
│   │   └── docx.py               # PythonDocxExtractor (.docx)
│   ├── chunkers/
│   │   ├── __init__.py
│   │   ├── base.py               # Chunker protocol
│   │   └── recursive.py          # LangChain RecursiveCharacterTextSplitter
│   └── pipeline.py               # Main ingest_documents() orchestrator
├── engine/
│   └── ingest.py                  # NEW: _IngestMixin for MemoryEngine
```

---

## Dependencies

```toml
# pyproject.toml

dependencies = [
    # ... existing ...
    "pymupdf>=1.24.0",                  # PDF extraction
    "python-pptx>=1.0.0",               # PPTX extraction
    "python-docx>=1.1.0",               # DOCX extraction
    "langchain-text-splitters>=0.3.0",  # Text chunking
]

[project.optional-dependencies]
docling = ["docling>=2.0.0"]            # Optional: advanced extraction
```

---

## Implementation Order

| Phase | Task | Status |
|-------|------|--------|
| **Phase 1: Core Sync Ingestion** | | |
| 1.1 | `bulk_create_semantic()` | ✅ Done |
| 1.2 | Create `ingest/models.py` | ✅ Done |
| 1.3 | Create `ingest/extractors/*.py` | ✅ Done |
| 1.4 | Create `ingest/chunkers/*.py` | ✅ Done |
| 1.5 | Create `ingest/pipeline.py` | ✅ Done |
| 1.6 | Create `engine/ingest.py` mixin | ✅ Done |
| 1.7 | Page/offset tracking metadata | ✅ Done |
| 1.8 | Update `pyproject.toml` dependencies | ✅ Done |
| **Phase 2: Worker Async Ingestion** | | |
| 2.1 | Create `IngestHandler` | ✅ Done |
| 2.2 | Add `queue_ingestion()` to engine | ✅ Done |
| 2.3 | Add `get_ingestion_status()` to engine | ✅ Done |
| 2.4 | Register handler in worker | ✅ Done |
| **Phase 3: Cloud Storage** | | |
| 3.1 | Create `StorageBackend` protocol | ✅ Done |
| 3.2 | Implement `LocalStorage` | ✅ Done |
| 3.3 | Implement `GCSStorage` | ✅ Done |
| 3.4 | Implement `S3Storage` | 🔜 Future |
| **Phase 4: Advanced Extractors** | | |
| 4.1 | Add Docling extractor | 🔜 Parked |
| 4.2 | Add Docling HybridChunker | 🔜 Parked |
| **Testing** | | |
| T1 | Add formal unit tests | ✅ Done |
| T2 | Add integration tests | ✅ Done |

---

## Usage Examples

### Simple Usage

```python
from mongomem_core import MemoryEngine

engine = MemoryEngine(embedder=my_embedder)
engine.bootstrap()

result = engine.ingest_documents(
    paths=["docs/report.pdf", "slides/deck.pptx", "notes.txt"],
    org_id="my-org",
    user_id="sakshi",
)

print(f"Ingested {result.total_chunks} chunks from {result.files_succeeded} files")
```

### Custom Configuration

```python
from mongomem_core.ingest import IngestConfig, ChunkConfig

config = IngestConfig(
    chunk_config=ChunkConfig(
        max_chunk_size=500,
        min_chunk_size=100,
        chunk_overlap=75,
    ),
    max_retries=3,
    on_failure="skip",  # Skip failed files, continue with others
)

result = engine.ingest_documents(
    paths=files,
    org_id="my-org",
    user_id="sakshi",
    config=config,
)

# Check results
for file_result in result.file_results:
    if file_result.success:
        print(f"✓ {file_result.path}: {file_result.chunks_created} chunks")
    else:
        print(f"✗ {file_result.path}: {file_result.error}")
```

### Handling Unsupported Files

```python
# If you pass unsupported files like .doc or .xlsx:

result = engine.ingest_documents(
    paths=["doc.pdf", "legacy.doc", "data.xlsx"],
    org_id="my-org",
    user_id="sakshi",
    config=IngestConfig(on_failure="skip"),
)

# Output:
# WARNING: Unsupported file type: .doc (legacy.doc). Supported: .txt, .pdf, .pptx, .docx
# WARNING: Unsupported file type: .xlsx (data.xlsx). Supported: .txt, .pdf, .pptx, .docx
# ✓ Processed 1 file, skipped 2
```

---

## Future: Docling Integration

When adding Docling support:

```python
from mongomem_core.ingest import IngestConfig, ExtractorType

config = IngestConfig(
    extractor=ExtractorType.DOCLING,
    # Chunker auto-selects Docling's HybridChunker
)

result = engine.ingest_documents(
    paths=["complex.pdf", "scanned.png"],  # OCR supported!
    org_id="my-org",
    user_id="sakshi",
    config=config,
)
```

---

## Error Handling

| `on_failure` | Behavior |
|--------------|----------|
| `"skip"` | Log warning, skip file, continue processing |
| `"raise"` | Raise exception immediately on first error |
| `"collect"` | Collect all errors, return in `IngestResult.file_results` |

---

## Phase 2: Worker Async Ingestion

For large file batches, queue ingestion jobs for background processing.

### Directory Structure (Worker)

```
src/mongomem_worker/
├── handlers/
│   └── ingest.py              # IngestHandler, job status models
```

### Job States

| State | Description |
|-------|-------------|
| `queued` | Job created, waiting for worker |
| `running` | Worker is processing |
| `completed` | All files processed successfully |
| `partial` | Some files succeeded, some failed |
| `failed` | All files failed or critical error |

### Usage

```python
# Queue a job (returns immediately)
job = engine.queue_ingestion(
    paths=["docs/large_report.pdf", "slides/deck.pptx"],
    org_id="my-org",
    user_id="sakshi",
)
print(f"Queued job: {job.job_id}")

# Check status later
status = engine.get_ingestion_status(job.job_id)
print(f"State: {status.state}")
print(f"Progress: {status.files_processed}/{status.total_files}")

if status.state == IngestJobState.COMPLETED:
    print(f"Done! Created {status.total_chunks} chunks")
elif status.state == IngestJobState.FAILED:
    print(f"Error: {status.error}")
```

### Job Tracking Collection

Jobs are tracked in `ingest_jobs` collection:

```javascript
{
  _id: ObjectId,
  state: "queued" | "running" | "completed" | "partial" | "failed",
  paths: ["file1.pdf", "file2.pptx"],
  org_id: "my-org",
  user_id: "sakshi",
  config: { ... },
  total_files: 2,
  files_processed: 2,
  files_succeeded: 2,
  files_failed: 0,
  total_chunks: 15,
  chunk_ids: ["id1", "id2", ...],
  file_results: [...],
  error: null,
  created_at: ISODate,
  started_at: ISODate,
  completed_at: ISODate
}
```

---

## Phase 3: Cloud Storage Connectors

### Supported Backends

| Backend | URI Prefix | Library | Status |
|---------|------------|---------|--------|
| Local | `/path/to/` | Built-in | ✅ Done |
| GCS | `gs://bucket/path` | `google-cloud-storage` | ✅ Done |
| S3 | `s3://bucket/path` | `boto3` | 🔜 Future |
| Azure | `https://*.blob.core.windows.net/` | `azure-storage-blob` | 🔜 Future |

### Storage Backend Files

```
src/mongomem_core/ingest/storage/
├── __init__.py       # Package exports, auto-detects available backends
├── base.py           # StorageBackend abstract base class
├── local.py          # LocalStorage - local filesystem (default)
└── gcs.py            # GCSStorage - Google Cloud Storage
```

### Storage Protocol

```python
class StorageBackend(ABC):
    def supports(self, uri: str) -> bool:
        """Check if this backend handles the URI."""
        ...
    
    def resolve(self, uri: str) -> Path:
        """Resolve URI to local path (download if remote)."""
        ...
    
    def list_files(self, uri: str, extensions: Set[str]) -> List[str]:
        """List files in directory/prefix matching extensions."""
        ...
    
    def cleanup(self, local_path: Path) -> None:
        """Cleanup temp files after processing."""
        ...
    
    def cleanup_all(self) -> None:
        """Cleanup all temp files created by this backend."""
        ...
```

### Usage

```python
from mongomem_core.ingest.storage import GCSStorage

# Single file from GCS
result = engine.ingest_documents(
    paths=["gs://my-bucket/reports/q1.pdf"],
    org_id="my-org",
    user_id="sakshi",
    storage_backend=GCSStorage(),
)

# All supported files from GCS directory (trailing slash)
result = engine.ingest_documents(
    paths=["gs://my-bucket/presentations/"],
    org_id="my-org",
    user_id="sakshi",
    storage_backend=GCSStorage(),
)

# With explicit credentials
gcs = GCSStorage(credentials_path="/path/to/service-account.json")
result = engine.ingest_documents(
    paths=["gs://my-bucket/file.pdf"],
    org_id="my-org",
    user_id="sakshi",
    storage_backend=gcs,
)
```

### Authentication

GCS authentication options (in order of precedence):
1. Explicit credentials: `GCSStorage(credentials_path="/path/to/key.json")`
2. Environment variable: `GOOGLE_APPLICATION_CREDENTIALS=/path/to/key.json`
3. Default credentials: `gcloud auth application-default login`

### Dependencies (Optional)

```toml
[project.optional-dependencies]
gcs = ["google-cloud-storage>=2.10.0"]
s3 = ["boto3>=1.28.0"]
azure = ["azure-storage-blob>=12.0.0"]
```

Install with: `pip install 'mongomem[gcs]'`

---

## Related Files

- `src/mongomem_core/memory/semantic.py` - `bulk_create_semantic()` function
- `src/mongomem_core/engine/semantic.py` - `engine.bulk_create_semantic()` method
- `src/mongomem_core/models/engine.py` - `BulkCreateSemanticResult` dataclass
- `src/mongomem_worker/handlers/ingest.py` - `IngestHandler`, job models
- `src/mongomem_core/engine/ingest.py` - `queue_ingestion()`, `get_ingestion_status()`
- `src/mongomem_core/ingest/storage/` - Storage backend implementations

