# MemoryEngine API Reference

The `MemoryEngine` is the primary interface for interacting with the ExoMemory system. It provides full CRUD operations for different memory types with optional embedding support.

## Quick Start

```python
from mongomem_core import MemoryEngine

# With embedder (required for worker, recommended for engine)
engine = MemoryEngine.from_env(embedder=my_embedder)

# Bootstrap database (creates collections and indexes)
engine.bootstrap()
```

---

## Initialization

### Constructor

```python
from mongomem_core import MemoryEngine, MemoryMode, ISGenerationConfig

engine = MemoryEngine(
    settings=Settings(...),    # Optional: Config (defaults from env vars)
    embedder=my_embedder,      # Optional: EmbedderProtocol for sync embedding
    llm=my_llm,                # Optional: LLMProtocol for extraction
    executor=my_executor,      # Optional: ExecutorProtocol for procedure code steps
    is_llm=my_cheap_llm,       # Optional: LLMProtocol for IS generation (IWM only)
    is_config=ISGenerationConfig(...),  # Optional: IS generation config (IWM only)
    db=my_database,            # Optional: MongoDB Database instance
    mode=MemoryMode.TRADITIONAL,  # Optional: Operating mode (TRADITIONAL, IWM, HYBRID)
    mode_resolver=None,        # Optional: Callable for per-org/session mode resolution
    snapshot_config=SnapshotConfig(...),  # Optional: Snapshot configuration
)
```

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `settings` | `Settings` | No | Configuration (mongo_uri, db_name, embedding_dimension). Defaults from env vars. |
| `embedder` | `EmbedderProtocol` | No* | Embedder for sync embedding. *Required if using worker. |
| `llm` | `LLMProtocol` | No | LLM for extraction features. |
| `is_llm` | `LLMProtocol` | No | Separate LLM for IS generation. If not provided, falls back to `llm`. Useful for cost optimization (cheaper model for summarization). |
| `is_config` | `ISGenerationConfig` | No | Configuration for `generate_is_from_turn()`. Only used in IWM/HYBRID modes. |
| `db` | `Database` | No | MongoDB Database instance. If not provided, created from settings. Useful for testing or custom connection management. |
| `mode` | `MemoryMode` | No | Operating mode: `TRADITIONAL` (default), `IWM`, or `HYBRID`. See [IWM Mode Guide](IWM_MODE.md). |
| `mode_resolver` | `Callable` | No | Optional function `(org_id, session_id) -> MemoryMode` for per-tenant mode resolution. |
| `snapshot_config` | `SnapshotConfig` | No | Snapshot configuration for auto-promotion thresholds and embedding strategy. Defaults to sensible defaults. |
| `executor` | `ExecutorProtocol` | No | Sandboxed code executor for running procedure code steps. See [ExecutorProtocol](#executorprotocol). |

### `MemoryEngine.from_env()`

Create an engine using environment variables for configuration.

```python
from mongomem_core import MemoryEngine, MemoryMode, ISGenerationConfig

engine = MemoryEngine.from_env(
    embedder=my_embedder,  # Required if using worker, optional for engine-only
    llm=my_llm,            # Optional: LLMProtocol for extraction
    executor=my_executor,  # Optional: ExecutorProtocol for procedure code steps
    mode=MemoryMode.IWM,   # Optional: Operating mode
    is_llm=my_cheap_llm,   # Optional: Separate LLM for IS generation
    is_config=ISGenerationConfig(
        update_policy="coalesce",
        coalesce_window_ms=5000,
    ),
)
```

**Environment Variables:**

| Variable | Description | Default |
|----------|-------------|---------|
| `MONGOMEM_MONGO_URI` | MongoDB connection string | `mongodb://localhost:27017` |
| `MONGOMEM_DB_NAME` | Database name | `agentic_memory` |
| `MONGOMEM_EMBEDDING_DIMENSION` | Embedding dimension | `1536` |

> **Note**: If you plan to use the `MemoryWorker`, the engine **must** have an embedder.
> The worker inherits the embedder from the engine and will raise `ValueError` if none is provided.

### `MemoryEngine.from_config()`

Create an engine with explicit settings.

```python
from mongomem_core.config import Settings

settings = Settings(
    mongo_uri="mongodb://localhost:27017",
    db_name="my_memory_db",
    embedding_dimension=1536,
)
engine = MemoryEngine.from_config(settings, embedder=my_embedder)
```

### Direct Database Injection

For testing or when you already have a database connection:

```python
# Testing with mock database
from unittest.mock import MagicMock
mock_db = MagicMock()
engine = MemoryEngine(db=mock_db)

# Inject existing database connection
engine = MemoryEngine(
    settings=my_settings,
    embedder=my_embedder,
    db=existing_db,
)
```

### `engine.bootstrap()`

Initialize database collections and indexes. Safe to call multiple times (idempotent).

```python
engine.bootstrap(ensure_search_indexes=True)
```

---

## Memory Types

| Type | Purpose | Use Cases |
|------|---------|-----------|
| **STM (Short-Term Memory)** | Conversation turns | Chat messages, tool calls, session history |
| **Internal State (IS)** | Agent belief state | IWM mode, constant-size context, self-summarization |
| **Snapshot** | Consolidated STM | Middle-tier memory, cross-session retrieval |
| **Semantic Memory** | Facts & knowledge | Definitions, documentation, learned facts |
| **Episodic Memory** | Events & experiences | Meeting summaries, conversation summaries |
| **User Context** | Preferences & style | Communication preferences, personalization |

---

## API Overview

| Memory Type | Create | Get | List | Update | Delete |
|-------------|--------|-----|------|--------|--------|
| **STM** | `write_turn`* | - | - | - | - |
| **Internal State** | `update_internal_state`** | `get_internal_state` | - | - | `clear_internal_state`** |
| **Snapshot** | `create_snapshot` | `get_snapshot` | `list_snapshots` | `update_snapshot` | `delete_snapshot` |
| **Semantic** | `create_semantic` | `get_semantic` | `list_semantic` | `update_semantic` | `delete_semantic` |
| **Episodic** | `create_episodic` | `get_episodic` | `list_episodic` | `update_episodic` | `delete_episodic` |
| **Procedural** | `create_procedural` | `get_procedural` | `list_procedural` | `update_procedural` | `delete_procedural` |
| **User Context** | `create_user_context` | `get_user_context` | `list_user_context` | `update_user_context` | `delete_user_context` |

*`write_turn` blocked in IWM mode | **`update/clear_internal_state` blocked in TRADITIONAL mode

**Additional Snapshot Methods:** `promote_stm_to_snapshot`, `check_snapshot_thresholds`, `search_snapshots`

**Additional Procedural Methods:** `bulk_create_procedural`, `fetch_procedural_memories`, `discover_procedures`

**Retrieval Methods:**
| Method | Description |
|--------|-------------|
| `build_context` | Full retrieval pipeline: fetch, rank, budget, format for LLM |
| `build_memory_context` | Mode-aware context building (returns `MemoryContext`) |
| `fetch_semantic_memories` | Fetch, deduplicate, and rank semantic memories |
| `fetch_episodic_memories` | Fetch, deduplicate, and rank episodic memories |
| `fetch_procedural_memories` | Fetch, deduplicate, and rank procedural memories |
| `discover_procedures` | Lightweight discovery-mode retrieval (summaries only, no full content) |

---

## Write Methods

### `engine.write_turn()` — Short-Term Memory

Write a conversation turn (message) to short-term memory.

```python
result = engine.write_turn(
    # Required
    session_id="sess_123",
    role="user",              # "user", "assistant", "system", "tool"
    org_id="org_1",
    user_id="user_1",
    
    # Content (required for user/system/tool roles)
    content="Hello, how can I help?",
    
    # Optional metadata
    tokens=15,
    model_name="gpt-4",
    stop_reason="stop",
    
    # Tool calls (for assistant role)
    tool_calls=[{
        "id": "call_1",
        "name": "get_weather",
        "arguments": {"city": "NYC"}
    }],
    
    # Tool result (for tool role)
    tool_call_id="call_1",
    tool_name="get_weather",
    is_error=False,
    
    # Visibility
    visibility="private",     # "private", "shared", "org"
    project_id=None,            # Required if visibility="shared"
    
    # Agent attribution
    agent_id="agent_1",
    share_learning_with_team=True,
    
    # Embedding (optional - auto-embeds if embedder provided)
    embedding=[0.1, 0.2, ...],
    embedding_model_id="text-embedding-3-small",
    
    # Idempotency
    idempotency_key="unique_key_123",
)

# Result
result.id           # Document ID
result.session_id   # Session ID
result.turn_seq     # Turn sequence number
```

---

## Internal State (IWM Mode)

Internal State is the agent's self-authored belief state used in IWM mode. It is overwritten each turn to maintain constant context size.

### `engine.generate_is_from_turn()` — Auto-Generate IS (Convenience)

Automatically generate IS content from turn events using an LLM. This is **optional sugar** on top of `update_internal_state()`.

```python
from mongomem_core import MemoryEngine, MemoryMode, ISGenerationConfig

# Setup with IS generation config
engine = MemoryEngine.from_env(
    mode=MemoryMode.IWM,
    embedder=my_embedder,
    llm=reasoning_llm,           # Main LLM for extraction
    is_llm=cheap_summarizer,     # Optional: cheaper model for IS generation
    is_config=ISGenerationConfig(
        update_policy="coalesce",    # "always" | "milestone" | "every_n" | "coalesce"
        coalesce_window_ms=5000,     # Batch events within 5s window
        max_tokens=500,              # Hard token limit (API-enforced)
        temperature=0.3,             # Deterministic output
    ),
)

# Auto-generate IS from turn events
result = engine.generate_is_from_turn(
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    inputs={
        "user_message": "How do I refresh tokens?",
        "assistant_response": "Use the refresh endpoint...",
        "tool_observations": ["Token expired", "Retry succeeded"],
        "intermediate_thoughts": "Need to check expiration logic",
    },
    milestone="task_complete",   # For "milestone" policy
    turn_index=5,                # For "every_n" policy
    force=False,                 # True to bypass policy
)

# Result
if result.updated:
    print(f"IS v{result.version}: {result.token_count} tokens")
    print(f"Hash: {result.content_hash}")
elif result.coalesced:
    print(f"Queued, next update at {result.next_update_at}")
elif result.was_noop:
    print("Content unchanged, skipped")
```

#### Update Policies

| Policy | Behavior | Use Case |
|--------|----------|----------|
| `"always"` | Generate on every call | Simple agents, short sessions |
| `"coalesce"` | Batch within time window | Tool loops, cost optimization |
| `"milestone"` | Only on specific triggers | Meaningful boundaries only |
| `"every_n"` | Every N turns | Predictable frequency |

#### ISGenerationConfig Reference

```python
from mongomem_core import ISGenerationConfig

config = ISGenerationConfig(
    # Update policy
    update_policy="coalesce",           # "always" | "milestone" | "every_n" | "coalesce"
    coalesce_window_ms=5000,            # For "coalesce": batch within window
    every_n_turns=3,                    # For "every_n": update frequency
    milestone_triggers=[                # For "milestone": valid triggers
        "task_complete",
        "error_resolved",
        "context_switch",
    ],
    
    # LLM generation
    max_tokens=500,                     # Hard limit (enforced by LLM API)
    temperature=0.3,                    # Lower = more deterministic
    stop_sequences=["</internal_state>"],  # Stop generation at patterns
    
    # Optimization
    skip_if_unchanged=True,             # Skip if content_hash matches
    
    # Security
    redact_patterns=[r"sk-[a-zA-Z0-9]+"],  # Regex patterns to redact
    sanitize_inputs=my_custom_func,     # Custom sanitization function
    
    # Custom prompt template
    prompt_template=None,               # Custom Jinja2 (None = default)
)
```

#### Aliases

```python
# These are equivalent
result = engine.generate_is_from_turn(...)
result = engine.update_is_from_events(...)  # Alias
```

---

### `engine.update_internal_state()` — Manual IS Update (Primitive)

**Mode-gated:** Only available in `IWM` and `HYBRID` modes. Raises `ModeError` in `TRADITIONAL` mode.

```python
from mongomem_core import MemoryEngine, MemoryMode

engine = MemoryEngine(mode=MemoryMode.IWM)

result = engine.update_internal_state(
    # Required
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    content="User prefers dark mode. Currently debugging login flow. Key insight: OAuth expires after 1hr.",
    
    # Optional
    token_count=87,                    # If None, estimated as len(content)//4
    token_count_estimated=False,       # True if token_count is an estimate
    model_id="gpt-4",                  # Model that generated this state
    agent_id="agent_1",                # Agent instance ID
    source_turn_id="turn_42",          # Turn that triggered this update
    update_reason="turn_end",          # "turn_end", "explicit", "periodic"
    metadata={"confidence": 0.95},     # Arbitrary metadata
)

# Result
result.session_id     # Session ID
result.version        # Version number (1 on first, increments on each update)
result.token_count    # Token count of content
result.content_hash   # SHA256[:16] of content
result.acknowledged   # True if successful
```

**Key behaviors:**
- **Atomic upsert**: Uses MongoDB `find_one_and_update` with `ReturnDocument.AFTER`
- **Version always increments**: First insert = v1, subsequent updates = v2, v3, ...
- **Content hash**: SHA256[:16] for integrity/deduplication
- **Overwrites previous**: Only one IS document per (session_id, org_id)

### `engine.get_internal_state()` — Read Belief State

**Allowed in ALL modes** for observability and debugging.

```python
# Works in any mode
state = engine.get_internal_state(
    session_id="sess_123",
    org_id="org_1",
)

if state:
    print(f"Version {state.version}: {state.content[:50]}...")
    print(f"Tokens: {state.token_count}")
    print(f"Updated: {state.updated_at}")
else:
    print("No internal state for this session")
```

### `engine.clear_internal_state()` — Delete Belief State

**Mode-gated:** Only available in `IWM` and `HYBRID` modes.

```python
deleted = engine.clear_internal_state(
    session_id="sess_123",
    org_id="org_1",
)
# True if deleted, False if no document existed
```

### Mode Errors

```python
from mongomem_core import MemoryEngine, MemoryMode, ModeError

# Traditional mode blocks IS writes
engine = MemoryEngine(mode=MemoryMode.TRADITIONAL)

try:
    engine.update_internal_state(...)
except ModeError as e:
    print(e.current_mode)      # MemoryMode.TRADITIONAL
    print(e.required_modes)    # [MemoryMode.IWM, MemoryMode.HYBRID]
    print(e.method)            # "update_internal_state"
    print(e.fix)               # Actionable fix message

# IWM mode blocks STM writes
engine = MemoryEngine(mode=MemoryMode.IWM)

try:
    engine.write_turn(...)
except ModeError as e:
    print(e.method)            # "write_turn"
```

---

## Context Building

### `engine.build_context()` — Full Retrieval Pipeline

### `engine.build_context()` — Build Retrieval Context

Build context from memories by querying MongoDB or using pre-fetched memories.

This method orchestrates the full retrieval pipeline:
1. **Generate query embedding** (if needed) using the engine's embedder
2. **Fetch memories** via RetrievalHub (from DB or pre-fetched lists)
3. **Rank memories** via MemoryRanker (multi-factor scoring)
4. **Select memories within budget** via Budgeter
5. **Format into final context** via Formatter

**Default Behavior (DB Mode):**
The engine fetches memories directly from MongoDB using:
- **STM**: Session-scoped queries (direct lookup by session_id, time-ordered)
- **Episodic**: Vector search using MongoDB $vectorSearch (requires query_embedding)
- **Semantic**: Vector search using MongoDB $vectorSearch (requires query_embedding)

**Pre-fetched Memories (Optional):**
If pre-fetched memories are provided (stm_memories, episodic_memories, semantic_memories), those sources skip DB queries and use the provided lists instead.

```python
from mongomem_core.models.retrieval import MemorySource, ModelType

# Basic usage
response = engine.build_context(
    query="What did we discuss?",
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
)

# Access results
response.formatted_context   # Formatted string or message list
response.metadata.token_count
response.metadata.memory_counts  # {'stm': 5, 'episodic': 3, 'semantic': 2}

# With options
response = engine.build_context(
    query="Team knowledge",
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    enabled_sources={MemorySource.STM, MemorySource.EPISODIC},
    max_tokens=8000,
    model_type=ModelType.CLAUDE,
    visibility="shared",
    project_id="team_engineering",
)

# With user context personalization
user_context = engine.get_user_context(org_id="org_1", user_id="user_1")
response = engine.build_context(
    query="What did we discuss?",
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    user_context=user_context,  # Includes tone, style, language preferences
)

# Using pre-computed query embedding
query_embedding = embedder.embed("What did we discuss?")
response = engine.build_context(
    query="What did we discuss?",  # Still required for logging/debugging
    query_embedding=query_embedding,  # Skips embedding generation
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
)

# Using pre-fetched memories (skip DB queries)
stm_list = [...]  # Pre-fetched STM memories
episodic_list = [...]  # Pre-fetched episodic memories
response = engine.build_context(
    query="What did we discuss?",
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    stm_memories=stm_list,  # Skip DB query for STM
    episodic_memories=episodic_list,  # Skip DB query for episodic
    # semantic_memories=...,  # Still queries DB for semantic
)

# With visibility and group filtering
response = engine.build_context(
    query="Team discussions",
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    visibility="shared",  # "private", "shared", "org"
    project_id="team_engineering",  # Required if visibility="shared"
)
```

#### Pipeline Stages

1. **Embedding Generation**: Generates query embedding if not provided (requires engine embedder)
2. **Memory Retrieval**: Fetches memories from enabled sources:
   - STM: Direct session lookup (time-ordered)
   - Episodic: Vector search with similarity threshold
   - Semantic: Vector search with similarity threshold
3. **Ranking**: Multi-factor scoring (relevance, recency, importance)
4. **Budgeting**: Selects memories within token budget (respects max_tokens and token_buffer)
5. **Formatting**: Formats selected memories into model-specific context format

#### Pre-fetched Memories Pattern

Use pre-fetched memories to:
- **Reduce database queries**: Skip DB lookups for sources you've already fetched
- **Custom filtering**: Apply your own filtering logic before context building
- **Performance optimization**: Batch fetch memories once, reuse for multiple context builds

```python
# Example: Fetch memories once, build multiple contexts
stm_memories = get_stm_by_session(db, session_id="sess_123", org_id="org_1")
episodic_memories = search_episodic(db, query_embedding=embedding, org_id="org_1", top_k=10)

# Build context for different queries using same memories
context1 = engine.build_context(
    query="What did we discuss?",
    query_embedding=embedding1,
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    stm_memories=stm_memories,
    episodic_memories=episodic_memories,
)

context2 = engine.build_context(
    query="Summarize the conversation",
    query_embedding=embedding2,
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    stm_memories=stm_memories,  # Reuse same memories
    episodic_memories=episodic_memories,
)
```

#### User Context Personalization

When `user_context` is provided, the formatter includes user preferences in the output:
- **Tone**: Adjusts formatting style (formal, casual, friendly)
- **Style**: Adjusts detail level (concise, detailed, technical)
- **Language**: Ensures proper language formatting
- **Preferred Format**: Uses user's preferred format (bullet_points, paragraphs, code)

```python
# Get user context
user_context = engine.get_user_context(org_id="org_1", user_id="user_1")

# Build personalized context
response = engine.build_context(
    query="What did we discuss?",
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    user_context=user_context,  # Personalizes output
)
```

### `engine.build_memory_context()` — Mode-Aware Context Building

Returns a `MemoryContext` dataclass with mode-specific invariants. This is the preferred method for IWM mode.

```python
from mongomem_core import MemoryEngine, MemoryMode

# IWM mode
engine = MemoryEngine(mode=MemoryMode.IWM, embedder=my_embedder)

context = engine.build_memory_context(
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    query="What's the project deadline?",
    
    # Budget control
    token_budget=4000,         # Total context budget
    is_token_budget=500,       # Max tokens for Internal State
    
    # LTM retrieval
    top_k=50,                  # Max memories to retrieve
    similarity_threshold=0.7,  # Min similarity for LTM
    
    # Optional pre-computed embedding
    query_embedding=None,      # If None, generated from query
)

# Access results
print(f"Source: {context.source}")  # "iwm", "traditional", or "hybrid"
print(f"IS: {context.internal_state[:50]}...")
print(f"IS tokens: {context.internal_state_tokens}")
print(f"IS version: {context.internal_state_version}")
print(f"IS truncated: {context.is_truncated}")
print(f"LTM tokens: {context.ltm_tokens}")
print(f"Total: {context.total_tokens}")
print(f"Remaining: {context.budget_remaining}")

# Invariants (mode-specific guarantees)
print(f"STM empty: {context.invariants.stm_empty}")      # True in IWM
print(f"IS present: {context.invariants.is_present}")    # True if IS exists
print(f"IS primary: {context.invariants.is_primary}")    # True in IWM

# Assert invariants (useful in tests)
context.assert_invariants()  # Raises AssertionError if violated
```

**Budget Allocation (IWM Mode):**

Priority packing ensures constant context size:
1. **IS guaranteed** — up to `is_token_budget` (truncated if over)
2. **LTM fills remaining** — semantic then episodic, by relevance score
3. **STM omitted** — not included in IWM mode

```python
# Example: 4000 token budget, 500 IS budget
# IS uses 450 tokens → 3550 remaining for LTM
# LTM packs: 2000 semantic + 1500 episodic = 3500 tokens
# Remaining: 50 tokens
```

**Traditional Mode:**

```python
engine = MemoryEngine(mode=MemoryMode.TRADITIONAL)

context = engine.build_memory_context(
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    query="What did we discuss?",
)

# In traditional mode:
# - context.internal_state is None
# - context.stm_turns contains conversation history
# - context.invariants.stm_empty is False (if turns exist)
```

---

## Fetching Individual Memory Types

Convenience methods for direct memory retrieval with deduplication and ranking—useful when you need control without the full `build_context` pipeline.

### `engine.fetch_semantic_memories()` / `engine.fetch_episodic_memories()`

Both methods share the same signature (episodic adds `session_id` filter):

```python
from mongomem_core.models import MetadataFilter

# Basic: query text → auto-generates embedding
memories = engine.fetch_semantic_memories(query="Python dictionaries", org_id="org_1")

# Pre-computed embedding
memories = engine.fetch_semantic_memories(query=[0.1, 0.2, ...], org_id="org_1")

# RBAC filtering
memories = engine.fetch_semantic_memories(
    query="Team docs",
    org_id="org_1",
    user_id="user_1",
    visibility="shared",
    project_id="team_engineering",
)

# Metadata pre-filtering (Atlas Vector Search)
memories = engine.fetch_semantic_memories(
    query="Python basics",
    org_id="org_1",
    metadata_filter=MetadataFilter(raw={"label": "python_basics"}),
)

# Episodic with session filter
memories = engine.fetch_episodic_memories(
    query="project updates",
    org_id="org_1",
    session_id="sess_123",
)
```
---

## Snapshot Memory

Snapshot memory consolidates STM messages into middle-tier conversational memory. Snapshots prevent context overflow, preserve coherence, and enable cross-session retrieval.

### Configuration

```python
from mongomem_core.models.config import SnapshotConfig

# Configure via SnapshotConfig
config = SnapshotConfig(
    strategy="auto",           # "manual" or "auto"
    max_messages=20,           # Trigger at N messages
    max_tokens=4000,           # Trigger at N tokens
    stale_minutes=30,          # Trigger if no activity
    embedding_strategy="transfer",  # "transfer", "generate", or "defer"
    topic_shift_enabled=False, # Enable topic detection
    topic_shift_threshold=0.35,# Similarity threshold
    preserve_pairs=True,       # Keep user-assistant pairs together
    ttl_days=30,              # Snapshot expiration
)

# Pass config when creating engine
engine = MemoryEngine(
    settings=settings,
    embedder=embedder,
    snapshot_config=config,
)
```

### Embedding Strategies

| Strategy | Description | When to Use |
|----------|-------------|-------------|
| `transfer` | Average STM embeddings | Fast, STM already has embeddings |
| `generate` | Call embedder synchronously | Need fresh embedding, latency OK |
| `defer` | Worker generates async | Minimize latency, background processing |

### `engine.create_snapshot()` — Manual Snapshot

Create a snapshot manually from messages.

```python
from mongomem_core.models.memory import SnapshotIn, SnapshotMessage

snapshot_in = SnapshotIn(
    session_id="sess_123",
    messages=[
        SnapshotMessage(role="user", content="What is MongoDB?"),
        SnapshotMessage(role="assistant", content="MongoDB is a document database..."),
    ],
    snapshot_reason="manual",
    ttl_days=30,
)

result = engine.create_snapshot(
    snapshot_in=snapshot_in,
    org_id="org_1",
    user_id="user_1",
)

# Result
result.id             # Document ID
result.session_id     # Session ID
result.snapshot_reason # Reason for snapshot
result.has_embedding  # Whether embedded
```

### `engine.promote_stm_to_snapshot()` — Automatic Promotion

Promote STM messages to a snapshot based on configuration thresholds.

```python
# Promote if thresholds met
snapshot = engine.promote_stm_to_snapshot(
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
)

# Force promotion regardless of thresholds
snapshot = engine.promote_stm_to_snapshot(
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    force=True,
)
```

### `engine.check_snapshot_thresholds()`

Check if STM should be promoted without actually promoting.

```python
should, reason = engine.check_snapshot_thresholds(
    session_id="sess_123",
    org_id="org_1",
)
# should: bool
# reason: str explaining why (or why not)
```

### `engine.get_snapshot()`

Retrieve a snapshot by ID.

```python
snapshot = engine.get_snapshot(
    snapshot_id="snap_abc123",
    org_id="org_1",
)

# Include soft-deleted
snapshot = engine.get_snapshot(
    snapshot_id="snap_abc123",
    org_id="org_1",
    include_deleted=True,
)
```

### `engine.list_snapshots()`

List snapshots with filters.

```python
snapshots = engine.list_snapshots(
    org_id="org_1",
    session_id="sess_123",  # Optional filter
    limit=10,
    skip=0,
)
```

### `engine.update_snapshot()`

Update a snapshot's metadata.

```python
from mongomem_core.models.memory import SnapshotUpdate

update = SnapshotUpdate(
    topic_title="MongoDB Discussion",
    metadata={"reviewed": True},
)

result = engine.update_snapshot(
    snapshot_id="snap_abc123",
    org_id="org_1",
    update=update,
)
```

### `engine.search_snapshots()`

Vector search across snapshots.

```python
results = engine.search_snapshots(
    query_embedding=[0.1, 0.2, ...],
    org_id="org_1",
    top_k=5,
    min_score=0.7,
    exclude_session_id="current_session",  # Optional: cross-session only
)
```

### `engine.delete_snapshot()`

Delete a snapshot (soft or hard).

```python
# Soft delete (default) - recoverable
result = engine.delete_snapshot(
    snapshot_id="snap_abc123",
    org_id="org_1",
    soft=True,
)

# Hard delete - permanent
result = engine.delete_snapshot(
    snapshot_id="snap_abc123",
    org_id="org_1",
    soft=False,
)
```

### Retrieval Source

Snapshots integrate with the retrieval pipeline:

```python
from mongomem_core.retrieval import SnapshotSource

source = SnapshotSource(db=engine._db)
results = source.retrieve(
    query_embedding=[0.1, 0.2, ...],
    org_id="org_1",
    top_k=5,
    min_score=0.7,
    exclude_session_id="current_session",  # Cross-session only
)
```

### Thread Retrieval (Conversation Resumption)

Retrieve coherent conversation threads instead of scattered top-k results.
Ideal for "conversation resumption" scenarios.

```python
from mongomem_core.models.config import ThreadRetrievalConfig, KNOWLEDGE_RETRIEVAL_CONFIG

# Basic usage - get relevant conversation thread
thread = engine.retrieve_conversation_thread("org_1", "MongoDB indexes")

# With custom config
config = ThreadRetrievalConfig(
    search_mode="hybrid",      # "vector", "text", or "hybrid"
    expansion="adaptive",      # "topic", "session", "similarity", "adaptive"
    max_tokens=8000,
    allow_cross_session=True,
)
thread = engine.retrieve_conversation_thread("org_1", query, config=config)

# Using presets
thread = engine.retrieve_conversation_thread(
    "org_1", "What do we know about X?",
    config=KNOWLEDGE_RETRIEVAL_CONFIG
)

# Convenience methods
thread = engine.retrieve_for_resumption("org_1", "where were we?")
thread = engine.retrieve_cross_session_knowledge("org_1", "MongoDB sharding")

# Work with the result
print(f"{len(thread.snapshots)} snapshots, {thread.total_tokens} tokens")
context = thread.to_context_string()  # For LLM context
messages = thread.to_messages()       # For chat API
```

**Expansion Strategies:**

| Strategy | Description |
|----------|-------------|
| `topic` | Follow `topic_id` links within session |
| `session` | Window before/after anchor in same session |
| `similarity` | Chase embedding similarity across sessions |
| `adaptive` | Smart combination (default): topic → session → cross-session |

**Preset Configs:**

| Preset | Use Case |
|--------|----------|
| `RESUME_SESSION_CONFIG` | Resume current conversation |
| `KNOWLEDGE_RETRIEVAL_CONFIG` | Cross-session knowledge lookup |
| `DEEP_CONTEXT_CONFIG` | Complex queries needing extensive context |
| `QUICK_CONTEXT_CONFIG` | Fast, minimal retrieval |

### Worker Auto-Promotion

When using the worker, snapshots can be auto-promoted via change streams:

```python
# Worker handles these snapshot task types:
# - "_check_and_promote": Main function used to check for promotion
```

---

### `engine.create_semantic()` — Semantic Memory

Create factual knowledge or documentation chunks.

```python
result = engine.create_semantic(
    # Required
    label="python-dict-def",              # Unique identifier
    text="A dictionary is a collection of key-value pairs.",
    org_id="org_1",
    user_id="user_1",
    
    # Optional
    source="python-docs",                 # Source reference
    contextual_metadata={                 # Additional context
        "chapter": "Data Structures",
        "confidence": 0.95,
    },
    
    # Visibility
    visibility="org",                     # "private", "shared", "org"
    project_id=None,
    
    # Agent attribution
    agent_id="agent_1",
    extraction_source="agent_mediated",   # "user_direct", "agent_mediated"
    
    # Embedding control
    embedding=[0.1, 0.2, ...],            # Pre-computed (skips auto-embed)
    skip_embedding=False,                 # True for bulk inserts (worker embeds later)
    upsert=False,                         # True to update an existing label
)

# Result
result.id             # Document ID
result.label          # Label
result.has_embedding  # Whether embedded
```

#### Bulk Insert Pattern

```python
# Fast bulk insert without blocking
for item in glossary_terms:
    engine.create_semantic(
        label=item.term,
        text=item.definition,
        org_id="org_1",
        user_id="user_1",
        skip_embedding=True,  # Insert unembedded
    )

# Worker embeds later
await handler.process_pending_semantic()
```

---

### `engine.create_episodic()` — Episodic Memory

Create events, experiences, or conversation summaries.

```python
result = engine.create_episodic(
    # Required
    title="Team standup meeting",
    org_id="org_1",
    user_id="user_1",
    
    # Content
    content="Full meeting transcript...",
    summary_text="Discussed Q4 deliverables and timeline.",
    summary_type="llm",                   # "heuristic", "llm", "manual"
    
    # Source tracking (optional)
    session_id="sess_123",                # Original session
    snapshot_ref_id="snapshot_456",       # Source snapshot
    
    # Metadata
    source_agent="gpt-4",
    participants=["user_1", "user_2"],
    tags=["meeting", "standup", "q4"],
    
    # Visibility
    visibility="shared",
    project_id="team_engineering",
    
    # Agent attribution
    agent_id="agent_1",
    extraction_source="agent_mediated",
    
    # Embedding control
    skip_embedding=False,
)

# Result
result.id             # Document ID
result.title          # Title
result.has_embedding  # Whether embedded
```

---

### `engine.create_procedural()` — Procedural Memory

Create a reusable procedure (skill) with optional structured steps and resources.

```python
result = engine.create_procedural(
    # Required
    procedure="deploy-app",              # Unique kebab-case name
    description="Deploy the app to production via Docker",
    content="# Deploy\n\n1. Build image...",
    org_id="org_1",
    user_id="user_1",

    # Optional - structured steps
    steps=[
        {"step_type": "code", "content": "docker build -t app .",
         "description": "Build image", "language": "bash"},
        {"step_type": "validation", "content": "curl http://app/health",
         "description": "Health check", "expected_output": "200 OK"},
    ],

    # Optional - associated resources
    resources=[
        {"path": "scripts/deploy.sh", "resource_type": "script",
         "language": "bash", "content": "#!/bin/bash\n..."},
    ],

    # Optional - SKILL.md metadata
    allowed_tools=["Bash", "Read"],
    compatibility="linux, macOS",
    license="MIT",

    # Optional - mongomem extensions
    tags=["deployment", "docker"],
    trigger_conditions=["user asks to deploy"],
    visibility="org",
    project_id=None,

    # Embedding control
    embedding=None,              # Pre-computed (skips auto-embed)
    skip_embedding=False,        # True to skip embedding entirely
)

# Result
result.id             # Document ID
result.procedure      # Procedure name
result.has_embedding  # Whether embedded
result.acknowledged   # True
```

### `engine.get_procedural()` — Get Procedure

```python
# By procedure name
proc = engine.get_procedural(org_id="org_1", procedure="deploy-app")

# By ID
proc = engine.get_procedural(org_id="org_1", id="64a1b2c3...")

# Include soft-deleted
proc = engine.get_procedural(org_id="org_1", procedure="deploy-app", include_deleted=True)
```

### `engine.list_procedural()` — List Procedures

```python
procs = engine.list_procedural(
    org_id="org_1",
    user_id="user_1",       # Optional filter
    tags=["deployment"],     # Optional tag filter
    visibility="org",        # Optional visibility filter
    limit=100,
    include_deleted=False,
)
```

### `engine.update_procedural()` — Update Procedure

```python
# By procedure name
updated = engine.update_procedural(
    org_id="org_1",
    procedure="deploy-app",
    description="Updated description",
    content="Updated instructions...",
    tags=["deployment", "v2"],
)

# By ID
updated = engine.update_procedural(
    org_id="org_1",
    id="64a1b2c3...",
    steps=[{"step_type": "code", "content": "new step", "description": "New"}],
)
```

### `engine.delete_procedural()` — Delete Procedure

```python
# Soft delete (default, recoverable)
result = engine.delete_procedural(org_id="org_1", procedure="deploy-app", soft=True)

# Hard delete (permanent)
result = engine.delete_procedural(org_id="org_1", procedure="deploy-app", soft=False)

# By ID
result = engine.delete_procedural(org_id="org_1", id="64a1b2c3...")
```

### `engine.bulk_create_procedural()` — Bulk Create

```python
result = engine.bulk_create_procedural(
    items=[
        {"procedure": "deploy-app", "description": "Deploy app",
         "content": "Instructions...", "tags": ["deploy"]},
        {"procedure": "run-tests", "description": "Run test suite",
         "content": "Instructions...", "tags": ["testing"]},
    ],
    org_id="org_1",
    user_id="user_1",
    generate_embeddings=True,
    skip_duplicates=True,
)

# result["created_count"], result["skipped_count"], result["created_ids"]
```

### `engine.fetch_procedural_memories()` — Retrieve Procedures

```python
# Basic query
memories = engine.fetch_procedural_memories(
    query="how do I deploy?",
    org_id="org_1",
    top_k=10,
    similarity_threshold=0.7,
)

# With RBAC filtering
memories = engine.fetch_procedural_memories(
    query="deployment process",
    org_id="org_1",
    user_id="user_1",
    visibility="org",
    tags=["deployment"],
)

# With pre-computed embedding
memories = engine.fetch_procedural_memories(
    query=[0.1, 0.2, ...],
    org_id="org_1",
)
```

### `engine.discover_procedures()` — Discovery Mode

Lightweight retrieval that returns procedure summaries (name, description, tags) without full content or steps. Use this as a pre-step to decide which procedures to activate.

```python
# Discover relevant procedures by query
summaries = engine.discover_procedures(
    query="deploy to staging",
    org_id="org_1",
    top_k=5,
)

for chunk in summaries:
    print(chunk.content, chunk.metadata.get("tags"))
```

### Extraction Pipeline

Use `create_procedural_pipeline()` to auto-discover procedures from conversations:

```python
from mongomem_core.extraction.procedural import create_procedural_pipeline

pipeline = create_procedural_pipeline(db=db, llm=llm, embedder=embedder)
result = pipeline.run(
    messages=messages,
    org_id="org_1",
    user_id="user_1",
    source_id="snapshot_abc",
)
```

See [Procedural Memory Guide](PROCEDURAL_MEMORY.md) and [Integration Guides](procedural-integrations.md) for detailed documentation.

---

### `engine.create_user_context()` — User Context

Create user communication preferences and style.

```python
result = engine.create_user_context(
    # Required - Communication preferences
    tone="casual",                        # "formal", "casual", "friendly"
    style="concise",                      # "concise", "detailed", "technical"
    language="en",                        # Language code
    preferred_format="bullet_points",     # "bullet_points", "paragraphs", "code"
    source="user_input",                  # "user_input", "inferred"
    org_id="org_1",
    user_id="user_1",
    
    # Optional
    demographic_tags=["developer", "python"],
    preferences={
        "code_style": "pep8",
        "include_examples": True,
    },
    
    # Visibility
    visibility="private",
    project_id=None,
    
    # Agent attribution
    agent_id="agent_1",
    extraction_source="user_direct",
)

# Result
result.id           # Document ID
result.context_key  # Composite key
```

---

## Get Methods

### `engine.get_semantic()`

Retrieve a semantic memory by ID or label.

```python
# By ID
memory = engine.get_semantic(org_id="org_1", id="64a1b2c3...")

# By label
memory = engine.get_semantic(org_id="org_1", label="python-dict-def")

# Include deleted
memory = engine.get_semantic(org_id="org_1", id="...", include_deleted=True)
```

### `engine.get_episodic()`

Retrieve an episodic memory by ID or session+snapshot.

```python
# By ID
memory = engine.get_episodic(org_id="org_1", id="64a1b2c3...")

# By session + snapshot
memory = engine.get_episodic(
    org_id="org_1",
    session_id="sess_123",
    snapshot_ref_id="snap_456",
)
```

---

## List Methods

### `engine.list_semantic()` / `engine.list_episodic()`

List memories with filters.

```python
# List user's semantic memories
memories = engine.list_semantic(
    org_id="org_1",
    user_id="user_1",
    visibility="private",
    limit=50,
)

# List session's episodic memories
memories = engine.list_episodic(
    org_id="org_1",
    session_id="sess_123",
    limit=10,
)
```

---

## Update Methods

### `engine.update_semantic()`

Update a semantic memory.

```python
# Update by ID
updated = engine.update_semantic(
    org_id="org_1",
    id="64a1b2c3...",
    text="Updated definition text",
    visibility="org",
)

# Update by label
updated = engine.update_semantic(
    org_id="org_1",
    label="python-dict-def",
    contextual_metadata={"version": 2},
)
```

### `engine.update_episodic()`

Update an episodic memory.

```python
updated = engine.update_episodic(
    org_id="org_1",
    id="64a1b2c3...",
    title="Updated meeting title",
    tags=["meeting", "updated"],
)
```

### `engine.update_user_context()`

Update a user context memory.

```python
updated = engine.update_user_context(
    org_id="org_1",
    user_id="user_1",
    tone="formal",
    style="detailed",
    language="en",
)
```

---

## Get Methods (User Context)

### `engine.get_user_context()`

Retrieve a user context by org_id and user_id.

```python
context = engine.get_user_context(org_id="org_1", user_id="user_1")
if context:
    print(context.tone, context.style, context.language)
```

### `engine.list_user_context()`

List user contexts with filters.

```python
# List all contexts in org
contexts = engine.list_user_context(org_id="org_1")

# Filter by visibility
contexts = engine.list_user_context(
    org_id="org_1",
    visibility="shared",
    limit=10,
)
```

---

## Delete Methods

### `engine.delete_semantic()`

Delete a semantic memory (soft or hard).

```python
# Soft delete (default) - sets deleted=True, recoverable
result = engine.delete_semantic(org_id="org_1", label="old-fact")
result = engine.delete_semantic(org_id="org_1", id="...", soft=True)

# Hard delete - permanent removal
result = engine.delete_semantic(org_id="org_1", label="old-fact", soft=False)

# Result
result.deleted_count  # Number of documents deleted
result.acknowledged   # True if operation succeeded
```

### `engine.delete_episodic()`

Delete an episodic memory (soft or hard).

```python
# Soft delete (default)
result = engine.delete_episodic(org_id="org_1", id="...")

# Hard delete
result = engine.delete_episodic(org_id="org_1", id="...", soft=False)

# By session + snapshot
result = engine.delete_episodic(
    org_id="org_1",
    session_id="sess_123",
    snapshot_ref_id="snap_456",
)
```

### `engine.delete_user_context()`

Delete a user context (hard delete only).

```python
result = engine.delete_user_context(org_id="org_1", user_id="user_1")
```

---

## Embedding Modes

The engine supports two embedding strategies:

### Sync Embedding (Default)

Embedding happens inline when creating. Best for single writes and interactive use.

```python
engine = MemoryEngine.from_env(embedder=my_embedder)

# Embedding generated immediately
result = engine.create_semantic(
    label="fact-1",
    text="The sky is blue.",
    org_id="org_1",
    user_id="user_1",
)
# result.has_embedding = True
```

### Async Embedding (Worker)

Insert without embedding, let worker process in background. Best for bulk inserts.

```python
# Engine with embedder (required for worker)
engine = MemoryEngine.from_env(embedder=my_embedder)

# Fast insert, skip sync embedding
result = engine.create_semantic(
    label="fact-1",
    text="The sky is blue.",
    org_id="org_1",
    user_id="user_1",
    skip_embedding=True,  # Don't embed now, worker handles later
)
# result.has_embedding = False

# Worker inherits embedder from engine and processes async
from mongomem_worker import MemoryWorker

worker = MemoryWorker.from_engine(engine)
await worker.process_pending_embeddings()
# Embeds: semantic ✓, episodic ✓

# Or use handler directly
from mongomem_worker.handlers import EmbeddingHandler

handler = EmbeddingHandler(engine.db, engine.embedder)
await handler.process_pending_all()
```

### Embedding Mode Summary

| Memory Type | Sync (Engine) | Async (Worker) |
|-------------|---------------|----------------|
| STM | ✅ Always | ⚠️ Opt-in (`enable_stm_async=True`) |
| Snapshot | ✅ `transfer` or `generate` | ✅ Via `embedding_strategy="defer"` |
| Semantic | ✅ Default | ✅ Via `skip_embedding=True` |
| Episodic | ✅ Default | ✅ Via `skip_embedding=True` |
| User Context | N/A | N/A |

---

## Properties

```python
engine.db              # MongoDB Database instance
engine.embedder        # EmbedderProtocol instance (or None)
engine.llm             # LLMProtocol instance (or None)
engine.executor        # ExecutorProtocol instance (or None)
engine.is_llm          # LLMProtocol for IS generation (or None, falls back to llm)
engine.is_config       # ISGenerationConfig instance (or None)
engine.settings        # Settings instance
engine.snapshot_config # SnapshotConfig instance
engine.mode            # Current MemoryMode (TRADITIONAL, IWM, HYBRID)
```

---

## ExecutorProtocol

Optional protocol for sandboxed code execution. mongomem stores procedure code steps but **never executes code itself** — execution is delegated to your sandbox.

### Interface

```python
from mongomem_core.protocols import ExecutorProtocol
from mongomem_core.models.execution import ExecutionResult

class ExecutorProtocol(Protocol):
    def execute(self, code: str, language: str, *,
                timeout_ms: int = 30000,
                context: dict | None = None) -> ExecutionResult: ...

    @property
    def supported_languages(self) -> list[str]: ...

    @property
    def executor_id(self) -> str: ...
```

### ExecutionResult

```python
@dataclass
class ExecutionResult:
    success: bool        # Whether execution succeeded
    stdout: str          # Standard output
    stderr: str          # Standard error
    exit_code: int       # Process exit code
    duration_ms: int     # Execution time in milliseconds
    language: str        # Language that was executed
    executor_id: str     # Which executor ran this
```

### Usage

```python
engine = MemoryEngine.from_env(embedder=embedder, executor=my_executor)

proc = engine.get_procedural(org_id="org_1", procedure="deploy-app")
for step in proc.steps:
    if step.step_type == "code" and engine.executor:
        result = engine.executor.execute(
            code=step.content,
            language=step.language or "bash",
            timeout_ms=step.timeout_ms,
        )
        if not result.success:
            print(f"Step failed: {result.stderr}")
            break
```

See [Procedural Memory — Code Execution](PROCEDURAL_MEMORY.md#code-execution-executorprotocol) for full implementation examples (E2B, Docker) and sandbox comparison.

---

## Error Handling

```python
from mongomem_core import (
    ValidationError,
    DatabaseOperationError,
    DuplicateDocumentError,
    DocumentNotFoundError,
)

try:
    result = engine.create_semantic(...)
except ValidationError as e:
    # Invalid input parameters
    print(e.details)
except DuplicateDocumentError as e:
    # Label already exists
    print(e.details)
except DatabaseOperationError as e:
    # MongoDB operation failed
    print(e.operation, e.original_error)
```

---

## Direct CRUD Access

For advanced use cases, you can import CRUD functions directly:

```python
from mongomem_core.memory.semantic import (
    create_semantic,
    get_semantic,
    list_semantic,
    update_semantic,
    delete_semantic,
    soft_delete_semantic,
)

from mongomem_core.memory.episodic import (
    create_episodic,
    get_episodic,
    list_episodic,
    update_episodic,
    delete_episodic,
    soft_delete_episodic,
)

from mongomem_core.memory.short_term import (
    create_stm,
    get_stm_by_id,
    get_stm_by_session,
    mark_stm_promoted,
    delete_stm_by_ids,
)

from mongomem_core.memory.snapshot import (
    create_snapshot,
    get_snapshot,
    get_latest_snapshot,
    list_snapshots,
    update_snapshot,
    delete_snapshot,
    soft_delete_snapshot,
    search_snapshots,
    count_snapshots,
    mark_snapshot_promoted,
    delete_snapshots_by_session,
)

from mongomem_core.memory.procedural import (
    create_procedural,
    bulk_create_procedural,
    upsert_procedural,
    get_procedural,
    list_procedural,
    update_procedural,
    update_procedural_embedding,
    soft_delete_procedural,
    delete_procedural,
    delete_procedural_by_ids,
    search_procedural,
)

from mongomem_core.memory.user_prefs import (
    create_user_context,
    get_user_context,
    update_user_context,
    delete_user_context,
)

# Promotion pipeline
from mongomem_core.pipelines import (
    promote_stm_to_snapshot,
    should_promote,
)

# Thread retrieval
from mongomem_core.retrieval import (
    retrieve_conversation_thread,
    ThreadRetrievalSource,
    SnapshotSearchBackend,
    MongoSnapshotBackend,
)
from mongomem_core.models.config import (
    ThreadRetrievalConfig,
    RESUME_SESSION_CONFIG,
    KNOWLEDGE_RETRIEVAL_CONFIG,
)
from mongomem_core.models.retrieval import ConversationThread

# IWM Mode
from mongomem_core import (
    MemoryMode,
    ModeError,
    ISGenerationConfig,
    ISGenerationResult,
    InternalStateResult,
)
```
