# Worker API Reference

The `mongomem_worker` provides background processing for memory embeddings and extractions. It watches for new memory content and processes it asynchronously.

## Quick Start

```python
from mongomem_core import MemoryEngine, Settings
from mongomem_worker import MongoMemWorker

# 1. Create engine with embedder
engine = MemoryEngine(
    Settings(
        mongo_uri="mongodb://localhost:27017",
        db_name="my_app",
        embedding_dimension=1024,
    ),
    embedder=MyEmbedder(),
)

# 2. Create and run worker
worker = MongoMemWorker(engine)
worker.run()
```

---

## Overview

The worker handles:

| Handler | Purpose | Requires |
|---------|---------|----------|
| **EmbeddingHandler** | Generate vector embeddings | `EmbedderProtocol` |
| **SemanticHandler** | Extract semantic facts/knowledge | `LLMProtocol`, `EmbedderProtocol` |
| **EpisodicHandler** | Extract events and experiences | `LLMProtocol` |
| **TaxonomicHandler** | Extract domain, category, tags | `LLMProtocol` |
| **EntityHandler** | Extract entities for TKG | `LLMProtocol` |
| **MaintenanceHandler** | Snapshot promotion, cleanup | - |

---

## Protocols

### EmbedderProtocol (Required)

```python
from mongomem_core import EmbedderProtocol

class MyEmbedder(EmbedderProtocol):
    def embed(self, text: str) -> list[float]:
        """Embed a single text string."""
        ...
    
    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Embed multiple texts (for efficiency)."""
        ...
    
    @property
    def dimension(self) -> int:
        """Embedding dimension (e.g., 1024 for voyage-3)."""
        ...
    
    @property
    def model_id(self) -> str:
        """Model identifier for provenance tracking."""
        ...
```

### LLMProtocol (Optional)

Required only for extraction features and IS generation.

```python
from mongomem_core import LLMProtocol
from typing import Optional, List

class MyLLM(LLMProtocol):
    def complete(self, prompt: str, **kwargs) -> str:
        """Generate a text completion."""
        ...
    
    def complete_json(self, prompt: str, schema: dict, **kwargs) -> dict:
        """Generate structured JSON output."""
        ...
    
    def generate(
        self,
        prompt: str,
        *,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        stop: Optional[List[str]] = None,
        **kwargs,
    ) -> str:
        """
        Generate text with explicit controls (preferred for IS generation).
        
        Args:
            prompt: The input prompt
            max_tokens: Hard limit on output tokens (API-enforced)
            temperature: Sampling temperature (lower = more deterministic)
            stop: Stop sequences to halt generation
        
        Returns:
            Generated text (bounded by max_tokens)
        """
        ...
    
    @property
    def model_id(self) -> str:
        """Model identifier for provenance tracking."""
        ...
```

**Example OpenAI Implementation:**

```python
import openai

class OpenAILLM(LLMProtocol):
    def __init__(self, model: str = "gpt-4"):
        self._model = model
        self._client = openai.OpenAI()
    
    def complete(self, prompt: str, **kwargs) -> str:
        response = self._client.chat.completions.create(
            model=self._model,
            messages=[{"role": "user", "content": prompt}],
            **kwargs,
        )
        return response.choices[0].message.content
    
    def complete_json(self, prompt: str, schema: dict, **kwargs) -> dict:
        response = self._client.chat.completions.create(
            model=self._model,
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object"},
            **kwargs,
        )
        import json
        return json.loads(response.choices[0].message.content)
    
    def generate(
        self,
        prompt: str,
        *,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        stop: Optional[List[str]] = None,
        **kwargs,
    ) -> str:
        params = {"model": self._model, "messages": [{"role": "user", "content": prompt}]}
        if max_tokens:
            params["max_tokens"] = max_tokens
        if temperature is not None:
            params["temperature"] = temperature
        if stop:
            params["stop"] = stop
        response = self._client.chat.completions.create(**params, **kwargs)
        return response.choices[0].message.content
    
    @property
    def model_id(self) -> str:
        return self._model
```

---

## MongoMemWorker

### Constructor

```python
worker = MongoMemWorker(
    engine,                           # Required: MemoryEngine with embedder
    extraction_config={...},          # Optional: Extraction settings
    concurrency=5,                    # Max concurrent tasks
    batch_size=10,                    # Batch size for processing
    poll_interval_seconds=1.0,        # Polling interval
    tenant_id="tenant_abc",           # Optional tenant identifier
    scaling_mode="single",            # "single" or "distributed"
    worker_db_name=None,              # Separate DB for task queue
    observability=None,               # Custom observability backend
)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `engine` | `MemoryEngine` | Required | Engine with embedder attached |
| `extraction_config` | `dict` | `{}` | Per-type extraction settings |
| `concurrency` | `int` | `5` | Max concurrent tasks |
| `batch_size` | `int` | `10` | Documents per batch |
| `poll_interval_seconds` | `float` | `1.0` | Seconds between polls |
| `tenant_id` | `str` | `None` | Tenant identifier for logging |
| `scaling_mode` | `str` | `"single"` | `"single"` or `"distributed"` |
| `worker_db_name` | `str` | `None` | Separate DB for worker collections |
| `observability` | `ObservabilityProtocol` | `None` | Custom observability backend |

### Methods

```python
# Blocking run (production)
worker.run()

# Async run
await worker.run_async()

# Background thread (Jupyter notebooks)
worker.start_background()
worker.stop()
worker.wait(timeout=5.0)

# Status
worker.is_running  # bool
worker.is_idle     # bool
worker.idle_seconds  # float
```

---

## Handlers

### EmbeddingHandler

Generates vector embeddings for memory content.

```python
from mongomem_worker.handlers import EmbeddingHandler

handler = EmbeddingHandler(
    db=engine.db,
    embedder=engine.embedder,
    batch_size=10,
    enable_stm_async=False,       # STM async disabled by default
    claim_timeout_seconds=300,    # 5 minutes
)

# Process all pending embeddings
await handler.process_pending_all()

# Process specific types
await handler.process_pending_semantic()
await handler.process_pending_episodic()
await handler.process_pending_stm()  # Only if enable_stm_async=True
```

**Multi-Instance Safe**: Uses atomic claiming to prevent duplicate work.

| Method | Description |
|--------|-------------|
| `process_pending_all()` | Process semantic + episodic (+ STM if enabled) |
| `process_pending_semantic()` | Embed unembedded semantic memories |
| `process_pending_episodic()` | Embed unembedded episodic memories |
| `process_pending_stm()` | Embed unembedded STM (opt-in) |

### Learning Extraction Handlers

Specialized handlers for extracting structured knowledge using LLM.

#### SemanticHandler

Extracts factual knowledge with full consolidation pipeline (ADD/UPDATE/REINFORCE).

```python
from mongomem_worker.handlers import SemanticHandler

handler = SemanticHandler(
    db=engine.db,
    llm=engine.llm,
    embedder=engine.embedder,  # Required for consolidation
    prompt=None,               # Custom prompt (optional)
    use_db_prompts=False,      # Enable database-driven prompts
)

# Process task (requires messages format)
await handler.handle_task({
    "messages": [
        {"role": "user", "content": "I work at MongoDB"},
        {"role": "assistant", "content": "Great! What do you do there?"},
    ],
    "org_id": "org_1",
    "user_id": "user_1",
    "source_id": "snap_456",
})
```

#### EpisodicHandler

Extracts events, actions, and experiences.

```python
from mongomem_worker.handlers import EpisodicHandler

handler = EpisodicHandler(
    db=engine.db,
    llm=engine.llm,
    prompt=None,
)

await handler.handle_task({
    "content": "Yesterday we had a meeting about the project",
    "org_id": "org_1",
    "user_id": "user_1",
    "source_id": "snap_456",
})
```

#### TaxonomicHandler

Extracts domain, category, and tags for knowledge organization.

```python
from mongomem_worker.handlers import TaxonomicHandler

handler = TaxonomicHandler(
    db=engine.db,
    llm=engine.llm,
    prompt=None,
)

await handler.handle_task({
    "content": "We use MongoDB for our NoSQL database needs",
    "org_id": "org_1",
    "user_id": "user_1",
    "source_id": "snap_456",
})
```

**Extraction Types Summary:**

| Handler | Extracts | Stores To | Requires Embedder |
|---------|----------|-----------|-------------------|
| `SemanticHandler` | Facts, knowledge items | `memory_semantic` | ✅ Yes |
| `EpisodicHandler` | Events, participants, outcomes | `memory_episodic` | No |
| `TaxonomicHandler` | Domain, category, tags | TKG (pending) | No |

---

## Extraction Config

### Static Prompts

```python
worker = MongoMemWorker(
    engine,
    extraction_config={
        "taxonomic": {"enabled": True, "prompt": "Custom prompt..."},
        "episodic": {"enabled": True},
        "semantic": {"enabled": False},
    },
)
```

### Database-Driven Prompts (Hot-Reload)

Enable per-scope prompt customization with version history.

```python
from mongomem_worker import ExtractionConfigStore

config = ExtractionConfigStore(db)

# Set system default
config.create(None, "taxonomic", "Default prompt: {content}", activate=True)

# Set org-level override
config.create("acme", "taxonomic", "Acme style: {content}", activate=True)

# Set group-level override
config.create("acme", "taxonomic", "Engineering: {content}", 
              project_id="engineering", activate=True)

# Set user-level override
config.create("acme", "taxonomic", "Alice's style: {content}",
              project_id="engineering", user_id="alice", activate=True)
```

**Resolution Order:**

```
User → Group → Org → System → Static Default
```

**Version Management:**

```python
# List versions
versions = config.list_versions("acme", "taxonomic", project_id="engineering")

# Rollback
config.rollback("acme", "taxonomic", project_id="engineering")

# Delete override
config.delete_scope("acme", "taxonomic", project_id="engineering", user_id="alice")

# Debug resolution chain
chain = config.get_resolution_chain(
    org_id="acme", extraction_type="taxonomic",
    project_id="engineering", user_id="alice"
)
```

---

## Scaling Modes

### Single Mode (Default)

One worker polls directly. Do not run multiple workers.

```python
worker = MongoMemWorker(engine, scaling_mode="single")
```

- Uses change streams if available (replica set)
- Falls back to polling (standalone MongoDB)

### Distributed Mode

Multiple workers pull from shared task queue with lease-based claiming.

```python
# Worker 1, 2, 3... (same config, different pods)
worker = MongoMemWorker(engine, scaling_mode="distributed", concurrency=5)
```

**Architecture:**

```
External Producer / Change Stream
        │
        ▼ enqueue_task()
┌─────────────────────────────┐
│     Task Queue (MongoDB)    │
│  • Atomic claiming          │
│  • Lease-based ownership    │
│  • Auto retry on failure    │
└─────────────────────────────┘
        │ claim_task()
   ┌────┼────┬────┐
   ▼    ▼    ▼    ▼
Worker1 Worker2 Worker3
```

**External Task Producer:**

```python
from mongomem_worker import enqueue_task

enqueue_task(
    task_type="embedding",
    payload={"doc_id": "...", "org_id": "..."},
    priority=0,       # Lower = higher priority
    max_retries=3,
)
```

---

## Split Database Architecture

Separate databases for core memory and worker collections.

```python
# Same database (default)
worker = MongoMemWorker(engine)

# Split databases
worker = MongoMemWorker(
    engine,
    worker_db_name="worker_shared",  # Task queue, worker state
)
```

**Use Cases:**

| Scenario | Core DB | Worker DB |
|----------|---------|-----------|
| Single-tenant | Same | Same |
| Multi-tenant SaaS | Per-tenant | Shared |
| Isolation | Production | Worker state |

---

## Observability

The worker uses `ObservabilityProtocol` from `mongomem_core.protocols` for metrics, spans, and events.

### ObservabilityProtocol

```python
from mongomem_core.protocols import ObservabilityProtocol

class ObservabilityProtocol:
    # Metrics
    def increment(self, name: str, value: float = 1.0, tags: dict = None): ...
    def gauge(self, name: str, value: float, tags: dict = None): ...
    def histogram(self, name: str, value: float, tags: dict = None): ...
    def timing(self, name: str, value_ms: float, tags: dict = None): ...
    
    # Tracing
    def span(self, name: str, *, kind: str = "internal", attributes: dict = None): ...
    
    # Events
    def event(self, name: str, *, attributes: dict = None, level: str = "info"): ...
```

### Built-in Implementations

| Implementation | Location | Description |
|----------------|----------|-------------|
| `LoggingObservability` | `mongomem_core.observability` | Logs to Python logger (default) |
| `NoOpObservability` | `mongomem_core.observability` | Zero overhead (testing/production) |
| `OpenTelemetryObservability` | `mongomem_core.observability` | Enterprise observability |

### Metrics Emitted

| Metric | Type | Description |
|--------|------|-------------|
| `tasks_claimed` | counter | Task claimed by worker |
| `tasks_completed` | counter | Task completed |
| `task_duration` | timing | Execution time (ms) |
| `tasks_failed` | counter | Task failed |
| `queue_depth` | gauge | Tasks in queue |
| `worker_active` | gauge | Worker running |

### Events Emitted

| Event | Level | Description |
|-------|-------|-------------|
| `mongomem.worker.task.claimed` | info | Task picked up |
| `mongomem.worker.task.completed` | info | Task finished |
| `mongomem.worker.task.failed` | error | Task failed |
| `mongomem.worker.task.timeout` | warning | Task timed out |

---

## Circuit Breaker

Protects external services from cascading failures.

```python
from mongomem_worker import get_circuit_breaker, CircuitBreakerOpen

breaker = get_circuit_breaker("my_service", failure_threshold=5)

try:
    result = await breaker.call_async(my_async_function, arg1, arg2)
except CircuitBreakerOpen as exc:
    print(f"Service unavailable, retry in {exc.retry_in_seconds}s")
```

**States:**

| State | Description | Behavior |
|-------|-------------|----------|
| CLOSED | Normal | Requests pass through |
| OPEN | Service down | Requests rejected immediately |
| HALF_OPEN | Testing | Limited requests allowed |

---

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `MONGOMEM_WORKER_MONGO_URI` | MongoDB connection | `mongodb://localhost:27017` |
| `MONGOMEM_WORKER_DB_NAME` | Database name | `agentic_memory` |
| `MONGOMEM_WORKER_MAX_CONCURRENT` | Max concurrent tasks | `8` |
| `MONGOMEM_WORKER_BATCH_SIZE` | Batch size | `10` |
| `MONGOMEM_WORKER_POLL_INTERVAL_SECONDS` | Poll interval | `1.0` |

---

## CLI

```bash
# Basic
mongomem-worker --embedder myapp.embedders.VoyageEmbedder

# With extractions
mongomem-worker \
    --embedder myapp.embedders.VoyageEmbedder \
    --llm myapp.llms.AnthropicLLM \
    --log-level DEBUG
```

---

## Example Implementations

### Voyage AI Embedder

```python
import voyageai
from mongomem_core import EmbedderProtocol

class VoyageEmbedder(EmbedderProtocol):
    def __init__(self, model: str = "voyage-3"):
        self.client = voyageai.Client()
        self._model = model
        self._dims = {"voyage-3": 1024, "voyage-3-lite": 512}
    
    def embed(self, text: str) -> list[float]:
        return self.client.embed([text], model=self._model).embeddings[0]
    
    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        return self.client.embed(texts, model=self._model).embeddings
    
    @property
    def dimension(self) -> int:
        return self._dims.get(self._model, 1024)
    
    @property
    def model_id(self) -> str:
        return self._model
```

### Anthropic LLM

```python
import json
import anthropic
from mongomem_core import LLMProtocol

class AnthropicLLM(LLMProtocol):
    def __init__(self, model: str = "claude-3-5-haiku-latest"):
        self.client = anthropic.Anthropic()
        self.model = model
    
    def complete(self, prompt: str, **kwargs) -> str:
        resp = self.client.messages.create(
            model=self.model,
            max_tokens=1024,
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.content[0].text
    
    def complete_json(self, prompt: str, schema: dict, **kwargs) -> dict:
        resp = self.client.messages.create(
            model=self.model,
            max_tokens=1024,
            messages=[{"role": "user", "content": f"{prompt}\n\nRespond with JSON only."}],
        )
        return json.loads(resp.content[0].text)
```

---

## Storage Collections

### Worker Collections

| Collection | Purpose |
|------------|---------|
| `tasks` | Task queue |
| `tasks_dlq` | Dead letter queue |
| `worker_state` | Health/stats tracking |
| `change_stream_state` | Resume tokens |
| `scheduled_tasks` | Scheduled jobs |

### Worker State Document

```javascript
{
    "worker_id": "hostname-pid",
    "status": "running",
    "last_heartbeat": ISODate("..."),
    "stats": {
        "embedding": {"success": 100, "failed": 2},
        "taxonomic": {"success": 50, "failed": 0}
    }
}
```

---

## Graceful Shutdown

```python
worker = MongoMemWorker(engine)

# Ctrl+C or kill signal triggers graceful shutdown
worker.run()

# Or manually:
worker.stop()
```

---

## Monitoring

```python
from mongomem_worker.storage import WorkerStateStore

state_store = WorkerStateStore(db)
workers = state_store.get_all_workers(active_only=True)

for w in workers:
    print(f"{w['worker_id']}: {w['status']}")
```

