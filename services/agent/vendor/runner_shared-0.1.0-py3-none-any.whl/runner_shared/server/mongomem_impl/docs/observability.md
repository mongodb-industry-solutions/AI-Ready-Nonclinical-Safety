# Observability

This document describes the observability layer for `mongomem_core` and `mongomem_worker`, including metrics, tracing, and structured events.

## Overview

The observability layer is built on a protocol-based design (`ObservabilityProtocol`) that allows you to connect to any backend:

- **OpenTelemetry** - For enterprise observability stacks
- **Logging** - For development and debugging
- **Custom backends** - Prometheus, Datadog, StatsD, etc.
- **NoOp** - Zero overhead when observability is not needed

## Quick Start

```python
from mongomem_core import MemoryEngine
from mongomem_core.observability import LoggingObservability

# Create an observability backend
obs = LoggingObservability()

# Pass to MemoryEngine
engine = MemoryEngine(observability=obs)

# All operations now emit metrics
engine.write_turn(org_id="acme", user_id="u1", turn=turn)
```

## Backend Implementations

### NoOpObservability (Default)

Zero-overhead implementation that does nothing. Used when no observability is configured.

```python
from mongomem_core.observability import NoOpObservability

obs = NoOpObservability()
engine = MemoryEngine(observability=obs)
```

### LoggingObservability

Logs all metrics, spans, and events to Python's logging system. Useful for development and debugging.

```python
from mongomem_core.observability import LoggingObservability

# Uses default logger "mongomem.observability"
obs = LoggingObservability()

# Or specify a custom logger name
obs = LoggingObservability(logger_name="my_app.memory")

engine = MemoryEngine(observability=obs)
```

Example output:

```
INFO:mongomem.observability:[increment] mongomem.engine.write_turn.count value=1.0 tags={'org_id': 'acme'}
INFO:mongomem.observability:[timing] mongomem.engine.write_turn.latency value_ms=45.2 tags={'org_id': 'acme'}
```

### OpenTelemetryObservability

Connects to OpenTelemetry for enterprise observability. Requires the optional `opentelemetry` dependency.

```bash
pip install mongomem[opentelemetry]
```

```python
from mongomem_core.observability import OTEL_AVAILABLE, OpenTelemetryObservability

if OTEL_AVAILABLE:
    obs = OpenTelemetryObservability()
    engine = MemoryEngine(observability=obs)
```

With custom tracer/meter:

```python
from opentelemetry import trace, metrics
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.metrics import MeterProvider

# Configure your exporters (OTLP, Jaeger, etc.)
trace.set_tracer_provider(TracerProvider())
metrics.set_meter_provider(MeterProvider())

# Create adapter with custom tracer/meter
tracer = trace.get_tracer("my-service")
meter = metrics.get_meter("my-service")
obs = OpenTelemetryObservability(tracer=tracer, meter=meter)
```

### Custom Backend

Implement `ObservabilityProtocol` to connect to any metrics/tracing system:

```python
from contextlib import contextmanager
from datadog import statsd
from mongomem_core import MemoryEngine

class DatadogObservability:
    """Forward metrics to Datadog StatsD."""

    def increment(self, name: str, value: float = 1.0, tags: dict = None):
        dd_tags = [f"{k}:{v}" for k, v in (tags or {}).items()]
        statsd.increment(name, value, tags=dd_tags)

    def gauge(self, name: str, value: float, tags: dict = None):
        dd_tags = [f"{k}:{v}" for k, v in (tags or {}).items()]
        statsd.gauge(name, value, tags=dd_tags)

    def histogram(self, name: str, value: float, tags: dict = None):
        dd_tags = [f"{k}:{v}" for k, v in (tags or {}).items()]
        statsd.histogram(name, value, tags=dd_tags)

    def timing(self, name: str, value_ms: float, tags: dict = None):
        dd_tags = [f"{k}:{v}" for k, v in (tags or {}).items()]
        statsd.timing(name, value_ms, tags=dd_tags)

    @contextmanager
    def span(self, name: str, *, kind: str = "internal", attributes: dict = None):
        # Optional: integrate with Datadog APM
        yield attributes or {}

    def event(self, name: str, *, attributes: dict = None, level: str = "info"):
        # Optional: send as Datadog event
        pass

obs = DatadogObservability()
engine = MemoryEngine(observability=obs)
```

## Available Metrics

All metrics are prefixed with `mongomem.` for consistent namespacing.

### Engine Metrics

| Metric | Type | Tags | Description |
|--------|------|------|-------------|
| `mongomem.engine.write_turn.count` | counter | `org_id`, `user_id` | Number of write_turn operations |
| `mongomem.engine.write_turn.latency` | timing | `org_id`, `user_id` | Write turn duration (ms) |
| `mongomem.engine.internal_state.latency` | timing | `org_id`, `user_id` | Internal state update duration (ms) |
| `mongomem.engine.internal_state.tokens` | histogram | `org_id`, `user_id` | Tokens in internal state |

### Context Building Metrics

| Metric | Type | Tags | Description |
|--------|------|------|-------------|
| `mongomem.context.latency` | timing | `org_id`, `user_id` | Context building duration (ms) |
| `mongomem.context.memories.count` | histogram | `org_id`, `user_id` | Number of memories in context |
| `mongomem.context.tokens.used` | histogram | `org_id`, `user_id` | Token count in formatted context |

### Retrieval Metrics

| Metric | Type | Tags | Description |
|--------|------|------|-------------|
| `mongomem.retrieval.source.latency` | timing | `source`, `status` | Per-source fetch duration (ms) |
| `mongomem.retrieval.source.count` | histogram | `source` | Memories fetched per source |
| `mongomem.retrieval.source.failed` | counter | `source`, `error_type` | Failed retrieval attempts |
| `mongomem.retrieval.dedup.removed` | histogram | - | Duplicates removed |

Sources: `stm`, `semantic`, `episodic`, `taxonomic`, `user_prefs`, `internal_state`

### Extraction Metrics

| Metric | Type | Tags | Description |
|--------|------|------|-------------|
| `mongomem.extraction.latency` | timing | `extraction_type` | Pipeline duration (ms) |
| `mongomem.extraction.items.extracted` | histogram | `extraction_type` | Items extracted |
| `mongomem.extraction.consolidation` | counter | `extraction_type`, `action` | Consolidation actions (add/update/reinforce/duplicate) |
| `mongomem.extraction.preferences.latency` | timing | - | Preferences extraction duration (ms) |
| `mongomem.extraction.preferences.fields_updated` | histogram | - | Fields updated in preferences |

Extraction types: `semantic`, `episodic`, `taxonomic`

### Approval Workflow Metrics

| Metric | Type | Tags | Description |
|--------|------|------|-------------|
| `mongomem.approval.staged` | counter | `extraction_type`, `action` | Items staged for review |
| `mongomem.approval.approved` | counter | - | Items approved |
| `mongomem.approval.rejected` | counter | - | Items rejected |
| `mongomem.approval.queue_time` | histogram | - | Time in pending queue (ms) |

### Document Ingestion Metrics

| Metric | Type | Tags | Description |
|--------|------|------|-------------|
| `mongomem.ingest.files.processed` | counter | `file_type` | Files successfully processed |
| `mongomem.ingest.files.failed` | counter | `file_type`, `error_type` | Files that failed processing |
| `mongomem.ingest.chunks.created` | histogram | - | Chunks created per batch |
| `mongomem.ingest.latency` | timing | - | Total ingestion duration (ms) |

### Embedding Metrics

| Metric | Type | Tags | Description |
|--------|------|------|-------------|
| `mongomem.embedding.generated` | counter | `dimension` | Single embeddings generated |
| `mongomem.embedding.latency` | timing | `dimension` | Embedding generation duration (ms) |
| `mongomem.embedding.text_length` | histogram | `dimension` | Input text length |
| `mongomem.embedding.batch.generated` | counter | `dimension` | Batch embedding calls |
| `mongomem.embedding.batch.size` | histogram | `dimension` | Batch sizes |
| `mongomem.embedding.batch.latency` | timing | `dimension` | Batch generation duration (ms) |

## Tracing (Spans)

Spans represent units of work and can be nested to form traces. The observability layer emits spans for key operations:

### Engine Spans

- `mongomem.engine.write_turn` - Write turn to STM
- `mongomem.engine.internal_state` - Update internal working memory
- `mongomem.engine.build_context` - Build context (parent span for context building stages)

### Context Building Spans

- `mongomem.context.embed_query` - Query embedding generation
- `mongomem.context.fetch_memories` - Memory retrieval from sources
- `mongomem.context.rank` - Memory ranking
- `mongomem.context.budget` - Token budgeting
- `mongomem.context.format` - Response formatting

### Extraction Spans

- `mongomem.extraction.semantic` - Semantic extraction pipeline
- `mongomem.extraction.episodic` - Episodic extraction pipeline
- `mongomem.extraction.taxonomic` - Taxonomic extraction pipeline
- `mongomem.extraction.preferences` - Preferences extraction pipeline

### Ingestion Spans

- `mongomem.ingest` - Document ingestion pipeline

### Span Kinds

| Kind | Description |
|------|-------------|
| `internal` | Internal operation (default) |
| `server` | Handling an incoming request |
| `client` | Making an outgoing request |
| `producer` | Creating a message for async processing |
| `consumer` | Processing a message |

### Using Spans in Custom Code

```python
with obs.span("my_operation", kind="internal", attributes={"key": "value"}) as span:
    result = do_work()
    span["result_count"] = len(result)  # Add attributes during execution
```

## Structured Events

Events are discrete occurrences logged for audit trails and debugging.

### Approval Workflow Events

| Event | Attributes | Description |
|-------|------------|-------------|
| `mongomem.approval.staged` | `extraction_type`, `action`, `source_id` | Item staged for review |
| `mongomem.approval.approved` | `memory_id`, `queue_time_ms`, `approved_by` | Item approved |
| `mongomem.approval.rejected` | `pending_id`, `rejection_reason`, `reviewed_by` | Item rejected |

### Error Events

| Event | Attributes | Level | Description |
|-------|------------|-------|-------------|
| `mongomem.extraction.failed` | `extraction_type`, `error_message`, `source_id` | error | Extraction pipeline failed |
| `mongomem.retrieval.source.failed` | `source`, `error_type`, `error_message` | warning | Retrieval source failed |
| `mongomem.ingest.file.failed` | `file_type`, `file_path`, `error_type`, `error_message` | warning | File ingestion failed |

### Event Levels

| Level | Description |
|-------|-------------|
| `debug` | Detailed diagnostic information |
| `info` | General operational events |
| `warning` | Potential issues |
| `error` | Error conditions |

### Emitting Custom Events

```python
obs.event(
    "my_custom_event",
    attributes={"user_id": "123", "action": "completed"},
    level="info",
)
```

## Integration with AI Agent Frameworks

When using mongomem with AI agent frameworks (LangChain, LlamaIndex, etc.), you can connect to the framework's tracing system.

### OpenTelemetry Integration

Most agent frameworks support OpenTelemetry. Configure your exporter once and all traces flow together:

```python
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

# Configure OTLP exporter (works with Jaeger, Grafana Tempo, etc.)
provider = TracerProvider()
provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter()))
trace.set_tracer_provider(provider)

# mongomem spans will appear in your agent traces
from mongomem_core.observability import OpenTelemetryObservability
obs = OpenTelemetryObservability()
engine = MemoryEngine(observability=obs)
```

### Parent Span Propagation

When called within an agent framework's traced operation, mongomem spans automatically become children of the active span:

```
[Agent Framework Span: handle_user_message]
  └── [mongomem: write_turn]
        ├── [mongomem: extraction.semantic]
        └── [mongomem: extraction.episodic]
```

## Worker Metrics

The `mongomem_worker` module includes additional metrics for background task processing:

| Metric | Type | Tags | Description |
|--------|------|------|-------------|
| `mongomem.worker.tasks.claimed` | counter | `task_type` | Tasks claimed |
| `mongomem.worker.tasks.completed` | counter | `task_type` | Tasks completed successfully |
| `mongomem.worker.tasks.failed` | counter | `task_type`, `error_type` | Tasks that failed |
| `mongomem.worker.tasks.retried` | counter | `task_type` | Tasks retried |
| `mongomem.worker.task.duration` | timing | `task_type` | Task processing duration (ms) |
| `mongomem.worker.circuit_breaker.opened` | counter | - | Circuit breaker opened |
| `mongomem.worker.circuit_breaker.rejected` | counter | - | Requests rejected by circuit breaker |
