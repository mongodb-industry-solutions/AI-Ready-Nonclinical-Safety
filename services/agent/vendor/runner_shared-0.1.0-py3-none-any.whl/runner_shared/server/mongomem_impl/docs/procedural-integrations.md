# Procedural Memory Integration Guides

This guide shows how to use mongomem procedural memory with different agent frameworks. The core principle: **mongomem stores the knowledge (procedures), the framework manages execution state and orchestration.**

## Basic Usage (No Framework)

The simplest integration — fetch procedures and pass them to your LLM.

### Setup

```python
from mongomem_core import MemoryEngine

engine = MemoryEngine.from_env(embedder=my_embedder)
engine.bootstrap()
```

### Store a Procedure

```python
engine.create_procedural(
    procedure="summarize-document",
    description="Summarize a document into key points",
    content="""# Summarize Document

1. Read the full document
2. Identify the 3-5 main themes
3. Write a 2-3 sentence summary per theme
4. Combine into a structured summary with bullet points
5. Include any action items at the end
""",
    org_id="org_1",
    user_id="user_1",
    tags=["summarization", "documents"],
    allowed_tools=["Read"],
)
```

### Retrieve and Use

```python
def handle_user_query(query: str, org_id: str, user_id: str):
    # 1. Fetch relevant procedures
    chunks = engine.fetch_procedural_memories(
        query=query,
        org_id=org_id,
        top_k=3,
        similarity_threshold=0.7,
    )

    # 2. Build system prompt with procedures
    procedure_context = ""
    for chunk in chunks:
        procedure_context += f"\n## Skill: {chunk.metadata['procedure']}\n"
        procedure_context += f"{chunk.content}\n"

    system_prompt = f"""You are a helpful assistant. When the user's request
matches one of the following procedures, follow the instructions precisely.

{procedure_context}
"""

    # 3. Call your LLM
    response = llm.chat(
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": query},
        ]
    )
    return response
```

### Retrieve with Full Context Pipeline

```python
from mongomem_core.models.retrieval import MemorySource

response = engine.build_context(
    query="How do I summarize this report?",
    session_id="sess_1",
    org_id="org_1",
    user_id="user_1",
    enabled_sources={MemorySource.SEMANTIC, MemorySource.PROCEDURAL},
    max_tokens=8000,
)

# response.formatted_context includes both facts and procedures
llm_response = llm.chat(
    messages=[
        {"role": "system", "content": response.formatted_context},
        {"role": "user", "content": user_query},
    ]
)
```

---

## LangGraph Integration

LangGraph manages agent state via checkpointers. mongomem provides the procedure knowledge that feeds into graph nodes.

### Pattern: Procedure-Driven Graph

```python
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.mongodb import MongoDBSaver
from typing import TypedDict, Annotated, List, Optional
from mongomem_core import MemoryEngine

engine = MemoryEngine.from_env(embedder=my_embedder)

# ── State ──────────────────────────────────────────────────────

class AgentState(TypedDict):
    messages: List[dict]
    current_procedure: Optional[dict]   # Active procedure from mongomem
    procedure_step_index: int           # Which step we're on
    step_results: List[dict]            # Results from executed steps
    org_id: str
    user_id: str

# ── Nodes ──────────────────────────────────────────────────────

def discover_procedure(state: AgentState) -> AgentState:
    """Fetch the most relevant procedure for the user's query."""
    last_message = state["messages"][-1]["content"]

    chunks = engine.fetch_procedural_memories(
        query=last_message,
        org_id=state["org_id"],
        top_k=1,
        similarity_threshold=0.75,
    )

    if chunks:
        # Fetch full procedure with steps
        proc = engine.get_procedural(
            org_id=state["org_id"],
            procedure=chunks[0].metadata["procedure"],
        )
        if proc:
            return {
                **state,
                "current_procedure": {
                    "procedure": proc.procedure,
                    "description": proc.description,
                    "content": proc.content,
                    "steps": [s.model_dump() for s in proc.steps] if proc.steps else [],
                },
                "procedure_step_index": 0,
                "step_results": [],
            }

    return {**state, "current_procedure": None}


def execute_step(state: AgentState) -> AgentState:
    """Execute the current step in the procedure."""
    proc = state["current_procedure"]
    idx = state["procedure_step_index"]
    steps = proc["steps"]

    if idx >= len(steps):
        return state

    step = steps[idx]

    # Route by step type
    if step["step_type"] == "instruction":
        result = llm.chat([
            {"role": "system", "content": f"Follow this instruction:\n{step['content']}"},
            *state["messages"],
        ])
        step_result = {"step": idx, "type": "instruction", "output": result}

    elif step["step_type"] == "code":
        # Delegate to your execution environment
        step_result = {"step": idx, "type": "code", "output": f"[executed: {step['content'][:50]}]"}

    elif step["step_type"] == "human_input":
        step_result = {"step": idx, "type": "human_input", "output": "awaiting_approval"}

    else:
        step_result = {"step": idx, "type": step["step_type"], "output": "completed"}

    return {
        **state,
        "procedure_step_index": idx + 1,
        "step_results": [*state["step_results"], step_result],
    }


def generate_response(state: AgentState) -> AgentState:
    """Generate final response based on procedure execution results."""
    proc = state["current_procedure"]

    if proc:
        context = f"You followed the '{proc['procedure']}' procedure.\n"
        context += f"Steps completed: {len(state['step_results'])}\n"
        for r in state["step_results"]:
            context += f"- Step {r['step']}: {r['output'][:100]}\n"
    else:
        context = "No matching procedure found. Respond based on your knowledge."

    response = llm.chat([
        {"role": "system", "content": context},
        *state["messages"],
    ])

    return {
        **state,
        "messages": [*state["messages"], {"role": "assistant", "content": response}],
    }

# ── Routing ────────────────────────────────────────────────────

def should_continue_steps(state: AgentState) -> str:
    proc = state["current_procedure"]
    if not proc or not proc["steps"]:
        return "respond"
    if state["procedure_step_index"] < len(proc["steps"]):
        return "execute"
    return "respond"

# ── Graph ──────────────────────────────────────────────────────

graph = StateGraph(AgentState)
graph.add_node("discover", discover_procedure)
graph.add_node("execute", execute_step)
graph.add_node("respond", generate_response)

graph.set_entry_point("discover")
graph.add_conditional_edges("discover", should_continue_steps,
                            {"execute": "execute", "respond": "respond"})
graph.add_conditional_edges("execute", should_continue_steps,
                            {"execute": "execute", "respond": "respond"})
graph.add_edge("respond", END)

# ── Checkpointer (MongoDB) ────────────────────────────────────

checkpointer = MongoDBSaver.from_conn_string(
    conn_string="mongodb://localhost:27017",
    db_name="agent_checkpoints",
)

app = graph.compile(checkpointer=checkpointer)
```

### Using the Graph

```python
result = app.invoke(
    {
        "messages": [{"role": "user", "content": "Deploy the app to production"}],
        "current_procedure": None,
        "procedure_step_index": 0,
        "step_results": [],
        "org_id": "org_1",
        "user_id": "user_1",
    },
    config={"configurable": {"thread_id": "session-123"}},
)
```

### Key Separation of Concerns

| Concern | Owned By |
|---------|----------|
| Procedure storage, retrieval, versioning | **mongomem** |
| Graph state, checkpointing, step routing | **LangGraph** |
| Code execution (if needed) | **Your sandbox / ExecutorProtocol** |
| LLM calls | **Your LLM provider** |

---

## CrewAI Integration

CrewAI organizes agents into crews with roles. mongomem procedures define the **tasks** those agents follow.

### Pattern: Procedure-Backed Tasks

```python
from crewai import Agent, Task, Crew
from mongomem_core import MemoryEngine

engine = MemoryEngine.from_env(embedder=my_embedder)


class ProceduralTaskBuilder:
    """Build CrewAI tasks from mongomem procedures."""

    def __init__(self, engine: MemoryEngine, org_id: str):
        self.engine = engine
        self.org_id = org_id

    def build_task(self, procedure_name: str, agent: Agent, **overrides) -> Task:
        """Fetch a procedure and convert it to a CrewAI task."""
        proc = self.engine.get_procedural(
            org_id=self.org_id,
            procedure=procedure_name,
        )
        if not proc:
            raise ValueError(f"Procedure not found: {procedure_name}")

        return Task(
            description=proc.content,
            expected_output=overrides.get("expected_output", proc.description),
            agent=agent,
            tools=overrides.get("tools", []),
        )

    def discover_tasks(self, query: str, agent: Agent, top_k: int = 3) -> list[Task]:
        """Discover relevant procedures and convert to tasks."""
        chunks = self.engine.fetch_procedural_memories(
            query=query,
            org_id=self.org_id,
            top_k=top_k,
            similarity_threshold=0.7,
        )

        tasks = []
        for chunk in chunks:
            proc = self.engine.get_procedural(
                org_id=self.org_id,
                procedure=chunk.metadata["procedure"],
            )
            if proc:
                tasks.append(Task(
                    description=proc.content,
                    expected_output=proc.description,
                    agent=agent,
                ))
        return tasks


# ── Usage ──────────────────────────────────────────────────────

builder = ProceduralTaskBuilder(engine, org_id="org_1")

reviewer = Agent(
    role="Code Reviewer",
    goal="Review code for quality and security issues",
    backstory="Senior engineer with expertise in code review",
    llm=my_llm,
)

deployer = Agent(
    role="Deployment Engineer",
    goal="Deploy applications safely to production",
    backstory="DevOps engineer specializing in containerized deployments",
    llm=my_llm,
)

# Build tasks from stored procedures
review_task = builder.build_task("code-review-checklist", reviewer)
deploy_task = builder.build_task("deploy-app", deployer)

crew = Crew(
    agents=[reviewer, deployer],
    tasks=[review_task, deploy_task],
    verbose=True,
)

result = crew.kickoff()
```

### Dynamic Crew Assembly

```python
def assemble_crew_for_query(query: str, org_id: str):
    """Dynamically assemble a crew based on relevant procedures."""
    chunks = engine.fetch_procedural_memories(
        query=query, org_id=org_id, top_k=5,
    )

    agents = []
    tasks = []
    for chunk in chunks:
        proc = engine.get_procedural(org_id=org_id, procedure=chunk.metadata["procedure"])
        if not proc:
            continue

        agent = Agent(
            role=f"{proc.procedure} specialist",
            goal=proc.description,
            backstory=f"Expert in: {proc.description}",
            llm=my_llm,
        )
        task = Task(description=proc.content, expected_output=proc.description, agent=agent)
        agents.append(agent)
        tasks.append(task)

    if not agents:
        return None

    return Crew(agents=agents, tasks=tasks, verbose=True)
```

---

## Google Agent Engine Integration

Agent Engine (Vertex AI) manages agent orchestration and checkpointing. mongomem provides the procedural knowledge layer.

### Pattern: Tool-Based Procedure Retrieval

```python
from mongomem_core import MemoryEngine

engine = MemoryEngine.from_env(embedder=my_embedder)


def get_procedure(procedure_name: str, org_id: str) -> dict:
    """Retrieve a procedure by name. Use this when you know which procedure to follow.

    Args:
        procedure_name: The kebab-case name of the procedure (e.g. "deploy-app")
        org_id: Organization ID

    Returns:
        Dict with procedure details including content and steps
    """
    proc = engine.get_procedural(org_id=org_id, procedure=procedure_name)
    if not proc:
        return {"error": f"Procedure '{procedure_name}' not found"}

    result = {
        "procedure": proc.procedure,
        "description": proc.description,
        "content": proc.content,
    }
    if proc.steps:
        result["steps"] = [
            {"type": s.step_type, "description": s.description, "content": s.content}
            for s in proc.steps
        ]
    if proc.allowed_tools:
        result["allowed_tools"] = proc.allowed_tools
    return result


def search_procedures(query: str, org_id: str, top_k: int = 5) -> list[dict]:
    """Search for procedures relevant to a query. Use this to find applicable
    procedures when you're unsure which one to follow.

    Args:
        query: Natural language description of what you need to do
        org_id: Organization ID
        top_k: Maximum number of results

    Returns:
        List of matching procedures with name, description, and relevance score
    """
    chunks = engine.fetch_procedural_memories(
        query=query, org_id=org_id, top_k=top_k, similarity_threshold=0.6,
    )
    return [
        {
            "procedure": c.metadata["procedure"],
            "description": c.metadata["description"],
            "score": round(c.similarity_score, 3) if c.similarity_score else None,
        }
        for c in chunks
    ]
```

### Register as Agent Engine Tools

```python
from vertexai.preview import extensions

# Register tools with Agent Engine
tools = [
    extensions.Tool(
        function_declarations=[
            extensions.FunctionDeclaration.from_func(get_procedure),
            extensions.FunctionDeclaration.from_func(search_procedures),
        ]
    )
]

# Agent Engine agent with procedural memory tools
agent = extensions.Agent(
    model="gemini-2.0-flash",
    tools=tools,
    system_instruction="""You are an operations assistant. When asked to perform
a task, first search for relevant procedures using search_procedures(). If a
matching procedure is found, retrieve it with get_procedure() and follow the
instructions precisely.""",
)
```

### Session-Scoped Procedure Cache

For multi-turn sessions, cache discovered procedures in the Agent Engine session state:

```python
def handle_session_turn(session, user_message: str, org_id: str):
    """Handle a turn with procedure caching across the session."""

    # Check if we already discovered procedures for this session
    cached = session.state.get("active_procedures", [])

    if not cached:
        # First turn: discover relevant procedures
        chunks = engine.fetch_procedural_memories(
            query=user_message, org_id=org_id, top_k=3,
        )
        cached = [c.metadata["procedure"] for c in chunks]
        session.state["active_procedures"] = cached

    # Build context with cached procedures
    procedure_context = []
    for proc_name in cached:
        proc = engine.get_procedural(org_id=org_id, procedure=proc_name)
        if proc:
            procedure_context.append(f"## {proc.procedure}\n{proc.content}")

    return agent.send_message(
        session=session,
        message=user_message,
        context="\n\n".join(procedure_context),
    )
```

---

## Common Patterns

### Bulk Import at Startup

```python
from mongomem_core.migration import discover_skills, ingest_skills

def bootstrap_procedures(engine, skills_dir: str, org_id: str, user_id: str):
    """Import all SKILL.md files on application startup."""
    engine.bootstrap()

    paths = discover_skills(skills_dir)
    if paths:
        result = ingest_skills(
            engine, paths,
            org_id=org_id, user_id=user_id,
            skip_duplicates=True,
            generate_embeddings=True,
        )
        print(f"Procedures: {result['imported_count']} imported, "
              f"{result['skipped_count']} skipped")
```

### Procedure Selection Pattern

When multiple procedures match, pick the best one:

```python
def select_best_procedure(query: str, org_id: str, min_score: float = 0.75):
    """Select the single best-matching procedure, or None."""
    chunks = engine.fetch_procedural_memories(
        query=query,
        org_id=org_id,
        top_k=3,
        similarity_threshold=min_score,
    )

    if not chunks:
        return None

    # Prefer highly reinforced procedures at similar scores
    best = max(chunks, key=lambda c: (
        c.similarity_score or 0,
        c.metadata.get("reinforcement_count", 0) * 0.01,
    ))

    return engine.get_procedural(
        org_id=org_id,
        procedure=best.metadata["procedure"],
    )
```

### Step Execution Loop

A framework-agnostic loop for executing procedure steps. Note: this loop runs in *your* code — mongomem provides the procedure data, your framework owns the execution lifecycle (retries, rollback, error handling):

```python
def execute_procedure(proc, llm, executor=None):
    """Execute a procedure's steps sequentially."""
    if not proc.steps:
        return llm.chat([{"role": "system", "content": proc.content}])

    results = []
    for i, step in enumerate(proc.steps):
        if step.step_type == "instruction":
            result = llm.chat([
                {"role": "system", "content": step.content},
            ])
            results.append({"step": i, "output": result})

        elif step.step_type == "code" and executor:
            result = executor.execute(
                code=step.content,
                language=step.language or "bash",
                timeout_ms=step.timeout_ms,
            )
            results.append({"step": i, "output": result.stdout, "success": result.success})

        elif step.step_type == "validation":
            # Run validation and check expected output
            pass

        elif step.step_type == "prompt":
            result = llm.chat([{"role": "user", "content": step.content}])
            results.append({"step": i, "output": result})

        elif step.step_type == "human_input":
            results.append({"step": i, "output": "awaiting_human", "blocked": True})
            break  # Pause execution until human responds

    return results
```

### Multi-Source Context with Procedures

Use procedures alongside other memory types in `build_context`:

```python
from mongomem_core.models.retrieval import MemorySource

response = engine.build_context(
    query=user_query,
    session_id=session_id,
    org_id=org_id,
    user_id=user_id,
    enabled_sources={
        MemorySource.SEMANTIC,      # Facts and knowledge
        MemorySource.PROCEDURAL,    # How-to procedures
        MemorySource.EPISODIC,      # Past experiences
    },
    max_tokens=12000,
)
```

---

## Separation of Concerns

| Layer | mongomem | Agent Framework |
|-------|----------|-----------------|
| **Storage** | Procedures, versions, embeddings in MongoDB | Agent state, checkpoints, session data |
| **Retrieval** | Vector search, RBAC filtering, deduplication | Query routing, tool selection |
| **Knowledge** | What to do (procedure content + steps) | How to orchestrate (graph, crew, pipeline) |
| **Execution** | `ExecutorProtocol` — a *thin observation hook* your framework calls. mongomem defines the interface but never invokes it automatically. No retry, rollback, or dependency management. | Actual runtime, sandbox, tool calls, step routing, error handling, retries |
| **State** | Reinforcement counts, version history | Conversation state, step progress, execution results |

mongomem is the **knowledge layer**. It tells your agent *what* to do. Your framework decides *when* and *how* to do it. The `ExecutorProtocol` exists so your framework has a standardized way to run code steps — mongomem stores the procedure, your framework orchestrates the execution.
