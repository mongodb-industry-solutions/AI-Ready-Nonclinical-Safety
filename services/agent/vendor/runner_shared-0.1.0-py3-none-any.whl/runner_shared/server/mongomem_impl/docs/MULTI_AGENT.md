# Multi-Agent Memory Support

This document describes how to use MongoDB Agentic Memory with multiple agents, including group chat scenarios, agent-specific working memory, and shared long-term memory.

---

## Overview

The memory system supports multi-agent architectures across all three modes:

| Mode | Use Case | Agent Isolation |
|------|----------|-----------------|
| **TRADITIONAL** | Group chat, shared conversation | STM shared, optional filtering |
| **IWM** | Agents with private working memory | IS per agent, LTM shared |
| **HYBRID** | Both private state + shared history | IS per agent, STM shared with filtering |

---

## Key Concepts

### Agent ID

Every agent in your system should have a unique `agent_id`. This ID is used for:

1. **Attribution**: Know which agent said what in STM turns
2. **IS Scoping**: Each agent can have its own Internal State (IWM/HYBRID)
3. **Filtering**: Retrieve only specific agents' contributions

```python
# Example agent IDs
PLANNER_AGENT = "planner"
EXECUTOR_AGENT = "executor"
REVIEWER_AGENT = "reviewer"
```

### Session ID

The `session_id` defines the collaboration boundary:

- **Same session**: Agents can see each other's STM turns
- **Different sessions**: Complete isolation (separate conversations)

```python
# Group chat: all agents share one session
GROUP_SESSION = "project_discussion_123"

# Isolated: each agent gets its own session
AGENT_A_SESSION = "agent_a_private_session"
AGENT_B_SESSION = "agent_b_private_session"
```

---

## Mode: TRADITIONAL

Best for: **Group chat**, **Multi-agent collaboration**, **Shared conversation history**

### How It Works

- All agents share STM (Short-Term Memory) in the same session
- Each turn is attributed via `agent_id` field
- LTM (semantic/episodic memories) is shared across the org
- No Internal State (IS) in this mode

### Writing Turns

```python
from mongomem_core import MemoryEngine, Settings
from mongomem_core.modes import MemoryMode

engine = MemoryEngine(
    Settings(mongo_uri="mongodb://localhost:27017", db_name="myapp"),
    mode=MemoryMode.TRADITIONAL,
)

# Planner agent writes a turn
engine.add_turn(
    session_id="group_chat_123",
    org_id="org_1",
    user_id="user_1",
    role="assistant",
    content="Let's break this project into three phases...",
    agent_id="planner",  # Attribution
)

# Executor agent writes a turn
engine.add_turn(
    session_id="group_chat_123",
    org_id="org_1",
    user_id="user_1",
    role="assistant",
    content="I'll start implementing phase 1...",
    agent_id="executor",  # Attribution
)

# Reviewer agent writes a turn
engine.add_turn(
    session_id="group_chat_123",
    org_id="org_1",
    user_id="user_1",
    role="assistant",
    content="I'll review the implementation when ready.",
    agent_id="reviewer",  # Attribution
)
```

### Reading Turns (All Agents)

```python
# Default: all agents see all turns (group chat behavior)
context = engine.build_memory_context(
    session_id="group_chat_123",
    org_id="org_1",
    user_id="user_1",
)

# context.stm_turns contains all turns from all agents
for turn in context.stm_turns:
    print(f"{turn.agent_id}: {turn.content}")
```

### Filtering by Agent

```python
# Only see planner's messages
context = engine.build_memory_context(
    session_id="group_chat_123",
    org_id="org_1",
    user_id="user_1",
    stm_agent_id="planner",  # Filter to single agent
)

# Exclude certain agents (e.g., hide internal reasoning agent)
context = engine.build_memory_context(
    session_id="group_chat_123",
    org_id="org_1",
    user_id="user_1",
    stm_exclude_agent_ids=["internal_reasoner", "debug_agent"],
)
```

### Direct STM Access

```python
from mongomem_core.memory.short_term import get_recent_stm, get_stm_by_session

# Get all turns in session
all_turns = get_stm_by_session(
    db=engine.db,
    session_id="group_chat_123",
    org_id="org_1",
)

# Get only executor's turns
executor_turns = get_stm_by_session(
    db=engine.db,
    session_id="group_chat_123",
    org_id="org_1",
    agent_id="executor",
)

# Get recent turns excluding reviewer
recent = get_recent_stm(
    db=engine.db,
    session_id="group_chat_123",
    org_id="org_1",
    exclude_agent_ids=["reviewer"],
    limit=20,
)
```

---

## Mode: IWM (Internal Working Memory)

Best for: **Agents with private working memory**, **Constant context size**, **Complex reasoning agents**

### How It Works

- Each agent has its own Internal State (IS) document
- IS is keyed by `(org_id, session_id, agent_id)`
- No STM in this mode (context size stays constant)
- LTM is shared across the org

### Writing Internal State

```python
engine = MemoryEngine(
    Settings(mongo_uri="mongodb://localhost:27017", db_name="myapp"),
    mode=MemoryMode.IWM,
)

# Planner agent updates its working memory
engine.update_internal_state(
    session_id="collaboration_123",
    org_id="org_1",
    user_id="user_1",
    agent_id="planner",  # Scopes IS to this agent
    content="""
    Current plan:
    - Phase 1: Data collection (assigned to executor)
    - Phase 2: Analysis (pending)
    - Phase 3: Report generation (pending)
    
    Blockers: None
    Next action: Wait for executor to complete phase 1
    """,
)

# Executor agent updates its own working memory (separate document!)
engine.update_internal_state(
    session_id="collaboration_123",
    org_id="org_1",
    user_id="user_1",
    agent_id="executor",  # Different agent = different IS document
    content="""
    Current task: Phase 1 - Data collection
    Progress: 60% complete
    Files processed: 45/75
    Estimated completion: 10 minutes
    
    Issues encountered: None
    """,
)
```

### Reading Internal State

```python
# Get planner's working memory
planner_state = engine.get_internal_state(
    session_id="collaboration_123",
    org_id="org_1",
    agent_id="planner",
)
print(f"Planner v{planner_state.version}: {planner_state.content}")

# Get executor's working memory
executor_state = engine.get_internal_state(
    session_id="collaboration_123",
    org_id="org_1",
    agent_id="executor",
)
print(f"Executor v{executor_state.version}: {executor_state.content}")
```

### Building Context

```python
# Build context for planner (gets planner's IS + shared LTM)
planner_context = engine.build_memory_context(
    session_id="collaboration_123",
    org_id="org_1",
    user_id="user_1",
    agent_id="planner",
)
# planner_context.internal_state = planner's IS content
# planner_context.semantic_memories = shared LTM

# Build context for executor (gets executor's IS + shared LTM)
executor_context = engine.build_memory_context(
    session_id="collaboration_123",
    org_id="org_1",
    user_id="user_1",
    agent_id="executor",
)
# executor_context.internal_state = executor's IS content
```

### Auto-Generating IS from Events

```python
# Optional: let the LLM generate IS content from turn events
result = engine.generate_is_from_turn(
    session_id="collaboration_123",
    org_id="org_1",
    user_id="user_1",
    agent_id="planner",
    user_message="Can you check on the executor's progress?",
    assistant_response="I'll check the current status...",
)
```

---

## Mode: HYBRID

Best for: **Full-featured multi-agent**, **Private state + shared history**, **Complex orchestration**

### How It Works

- Each agent has its own Internal State (IS)
- All agents share STM with optional filtering
- LTM is shared across the org
- Best of both worlds: private working memory + shared conversation

### Writing Data

```python
engine = MemoryEngine(
    Settings(mongo_uri="mongodb://localhost:27017", db_name="myapp"),
    mode=MemoryMode.HYBRID,
)

# Write shared STM turn (visible to all agents)
engine.add_turn(
    session_id="project_123",
    org_id="org_1",
    user_id="user_1",
    role="assistant",
    content="Project kickoff meeting notes...",
    agent_id="facilitator",
)

# Each agent maintains private working memory
engine.update_internal_state(
    session_id="project_123",
    org_id="org_1",
    user_id="user_1",
    agent_id="facilitator",
    content="Meeting concluded. Action items assigned. Follow up in 2 days.",
)

engine.update_internal_state(
    session_id="project_123",
    org_id="org_1",
    user_id="user_1",
    agent_id="developer",
    content="Assigned: implement auth module. Deadline: Friday. Dependencies: none.",
)
```

### Building Context

```python
# Facilitator sees: own IS + all STM + shared LTM
facilitator_context = engine.build_memory_context(
    session_id="project_123",
    org_id="org_1",
    user_id="user_1",
    agent_id="facilitator",  # IS scoped to facilitator
    # No STM filtering = sees all agents' turns
)

# Developer sees: own IS + filtered STM + shared LTM
developer_context = engine.build_memory_context(
    session_id="project_123",
    org_id="org_1",
    user_id="user_1",
    agent_id="developer",  # IS scoped to developer
    stm_exclude_agent_ids=["internal_planner"],  # Hide internal agent
)

# Context for reading only developer's history
dev_only_context = engine.build_memory_context(
    session_id="project_123",
    org_id="org_1",
    user_id="user_1",
    agent_id="developer",
    stm_agent_id="developer",  # Only developer's STM turns
)
```

---

## Long-Term Memory (All Modes)

LTM is **always shared** at the org level, regardless of mode:

```python
# Semantic memories (facts, knowledge) - shared across org
# Episodic memories (events, experiences) - shared across org

# Any agent can query LTM
context = engine.build_memory_context(
    session_id="any_session",
    org_id="org_1",
    user_id="user_1",
    query="What do we know about the auth module?",
)

# context.semantic_memories = relevant facts from any session
# context.episodic_memories = relevant events from any session
```

LTM is extracted by the worker from:
- STM turns (TRADITIONAL/HYBRID)
- Snapshots (consolidated STM)
- Direct uploads via API

---

## Snapshots and LTM Provenance

When STM is promoted to snapshots, multi-agent attribution is preserved:

### Snapshot Message Attribution

Each message in a snapshot includes its source `agent_id`:

```python
# Snapshot messages preserve which agent authored each turn
snapshot.messages = [
    SnapshotMessage(role="assistant", content="...", agent_id="planner"),
    SnapshotMessage(role="assistant", content="...", agent_id="executor"),
    SnapshotMessage(role="user", content="..."),  # No agent_id for user
]
```

### Contributing Agents

Snapshots track all agents that contributed:

```python
# Snapshot has a list of all contributing agent IDs
snapshot.contributing_agent_ids = ["planner", "executor", "reviewer"]
```

### LTM Extraction Provenance

When the worker extracts LTM (semantic/episodic memories) from snapshots:

1. The snapshot's `contributing_agent_ids` is included in the task payload
2. Each extracted message includes its `agent_id`
3. LTM `source` field links back to the snapshot for full provenance

```python
# LTM provenance chain
ltm_memory.source = "snapshot_abc123"  # Links to snapshot

# Query the snapshot to see contributing agents
snapshot = db.memory_snapshots.find_one({"_id": "snapshot_abc123"})
print(snapshot["contributing_agent_ids"])  # ["planner", "executor"]
```

This enables queries like "what facts were learned from conversations involving the planner agent?"

---

## Common Patterns

### Pattern 1: Orchestrator + Workers

```python
# Orchestrator has overview, workers have task-specific context
ORCHESTRATOR = "orchestrator"
WORKERS = ["worker_1", "worker_2", "worker_3"]

# Orchestrator sees all
orchestrator_ctx = engine.build_memory_context(
    session_id="task_123",
    org_id="org_1",
    user_id="user_1",
    agent_id=ORCHESTRATOR,
)

# Each worker sees only its own turns (focused context)
for worker in WORKERS:
    worker_ctx = engine.build_memory_context(
        session_id="task_123",
        org_id="org_1",
        user_id="user_1",
        agent_id=worker,
        stm_agent_id=worker,  # Only this worker's history
    )
```

### Pattern 2: Public + Private Agents

```python
# Some agents are "public" (visible), some are "internal" (hidden)
PUBLIC_AGENTS = ["assistant", "helper"]
INTERNAL_AGENTS = ["reasoner", "planner", "critic"]

# User-facing context excludes internal agents
user_context = engine.build_memory_context(
    session_id="chat_123",
    org_id="org_1",
    user_id="user_1",
    stm_exclude_agent_ids=INTERNAL_AGENTS,
)

# Internal agents see everything
internal_context = engine.build_memory_context(
    session_id="chat_123",
    org_id="org_1",
    user_id="user_1",
    agent_id="reasoner",
)
```

### Pattern 3: Debate/Discussion

```python
# Multiple agents discuss, each with own perspective
DEBATERS = ["pro_agent", "con_agent", "moderator"]

# All agents see the full discussion
for agent in DEBATERS:
    ctx = engine.build_memory_context(
        session_id="debate_123",
        org_id="org_1",
        user_id="user_1",
        agent_id=agent,  # Each has own IS for tracking their position
        # No STM filtering = full discussion visible
    )
```

---

## API Reference

### Engine Methods

| Method | Parameters | Description |
|--------|------------|-------------|
| `update_internal_state()` | `agent_id` | Write IS scoped to agent |
| `get_internal_state()` | `agent_id` | Read IS for specific agent |
| `clear_internal_state()` | `agent_id` | Delete IS for specific agent |
| `build_memory_context()` | `agent_id`, `stm_agent_id`, `stm_exclude_agent_ids` | Build context with filtering |
| `generate_is_from_turn()` | `agent_id` | Auto-generate IS for agent |

### STM Functions

| Function | Parameters | Description |
|----------|------------|-------------|
| `get_stm_by_session()` | `agent_id`, `exclude_agent_ids` | Get all session turns with filtering |
| `get_recent_stm()` | `agent_id`, `exclude_agent_ids` | Get recent turns with filtering |
| `get_stm_raw_docs()` | `agent_id`, `exclude_agent_ids` | Get raw docs with filtering |

### Default Behavior

- If `agent_id` is not provided for IS operations, uses `"__default__"` (backward compatible)
- If STM filtering params are not provided, returns all agents' turns (group chat default)

---

## Database Schema

### Internal State (IS) - Unique Key

```
(org_id, session_id, agent_id)
```

Each combination gets exactly one IS document, overwritten on updates.

### STM - Index for Agent Filtering

```
(org_id, session_id, agent_id, timestamp)
```

Enables efficient queries like "get executor's turns sorted by time".

### Snapshots

```
SnapshotMessage.agent_id: Optional[str]     # Per-message attribution
SnapshotIn.contributing_agent_ids: List[str] # All agents in snapshot
```

Preserves multi-agent provenance through snapshot consolidation.

---

## Migration Notes

### Existing Single-Agent Deployments

The multi-agent changes are **backward compatible**:

- If you don't pass `agent_id`, IS uses `"__default__"` 
- If you don't pass STM filtering params, all turns are returned
- Existing data continues to work without migration

### Upgrading to Multi-Agent

1. Start passing `agent_id` to IS operations
2. Ensure STM turns include `agent_id` field
3. Run index creation for the new `st_session_agent_time` index:

```python
from mongomem_core.storage import ensure_indexes
ensure_indexes(engine.db)
```
