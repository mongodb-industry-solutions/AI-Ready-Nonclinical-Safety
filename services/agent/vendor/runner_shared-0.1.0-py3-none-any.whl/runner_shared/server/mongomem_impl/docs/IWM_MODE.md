# Internal Working Memory (IWM) Mode

IWM mode enables **constant-size context** for long-horizon AI agents by replacing message accumulation with a model-authored belief state.

## The Problem IWM Solves

### Traditional Mode: Unbounded Growth

In traditional mode, every conversation turn appends to Short-Term Memory (STM):

```
Turn 1:   ~100 tokens
Turn 10:  ~1,000 tokens
Turn 50:  ~5,000 tokens
Turn 100: ~10,000 tokens  ← context overflow, degraded reasoning
```

This causes:
- **Rising inference costs** as context grows
- **Context window overflow** in long sessions
- **Reasoning degradation** from information overload

### IWM Mode: Constant Size

In IWM mode, the agent rewrites a single "belief state" each turn:

```
Turn 1:   ~500 tokens (IS) + ~3,500 tokens (LTM) = 4,000 tokens
Turn 10:  ~500 tokens (IS) + ~3,500 tokens (LTM) = 4,000 tokens
Turn 100: ~500 tokens (IS) + ~3,500 tokens (LTM) = 4,000 tokens
```

Benefits:
- **Constant inference cost** regardless of session length
- **No context overflow** — ever
- **Focused reasoning** on current state, not history

## Quick Start

```python
from mongomem_core import MemoryEngine, MemoryMode

# Create engine in IWM mode
engine = MemoryEngine.from_env(mode=MemoryMode.IWM)
engine.bootstrap()

# Agent updates its belief state each turn
result = engine.update_internal_state(
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    content="""
    User: Software engineer, prefers Python
    Current task: Debugging OAuth flow
    Key insight: Token expires after 1 hour
    Next step: Implement refresh logic
    Open questions: None
    """,
    model_id="gpt-4",
    update_reason="turn_end",
)
print(f"Version: {result.version}")  # 1 → 2 → 3 → ...

# Build context (IS + LTM, constant size)
context = engine.build_memory_context(
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    query="How do I refresh the token?",
    token_budget=4000,
    is_token_budget=500,
)

print(f"IS tokens: {context.internal_state_tokens}")  # ~500
print(f"LTM tokens: {context.ltm_tokens}")            # ~3500
print(f"STM turns: {len(context.stm_turns)}")         # Always 0 in IWM
```

## How It Works

### Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        IWM Mode Flow                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  User message                                                    │
│       │                                                          │
│       ▼                                                          │
│  ┌─────────────────┐                                             │
│  │  Agent (LLM)    │                                             │
│  │                 │                                             │
│  │  1. Process msg │                                             │
│  │  2. Generate    │                                             │
│  │     response    │                                             │
│  │  3. Update IS   │ ◄── "What do I need to remember?"           │
│  └────────┬────────┘                                             │
│           │                                                      │
│           ▼                                                      │
│  ┌─────────────────┐     ┌─────────────────┐                     │
│  │ Internal State  │     │  Long-Term      │                     │
│  │ (overwrites)    │     │  Memory (LTM)   │                     │
│  │                 │     │                 │                     │
│  │ ~500 tokens     │     │ Semantic facts  │                     │
│  │ version: N      │     │ Episodic events │                     │
│  └────────┬────────┘     └────────┬────────┘                     │
│           │                       │                              │
│           └───────────┬───────────┘                              │
│                       │                                          │
│                       ▼                                          │
│           ┌─────────────────────┐                                │
│           │  build_memory_context()                              │
│           │                     │                                │
│           │  IS (guaranteed)    │                                │
│           │  + LTM (by score)   │                                │
│           │  = ~4000 tokens     │                                │
│           └─────────────────────┘                                │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Budget Allocation

IWM uses **priority packing** to ensure constant context size:

1. **IS is guaranteed** — always included, up to `is_token_budget`
2. **LTM fills remaining** — semantic then episodic, ranked by relevance
3. **STM omitted** — not included in IWM mode

```python
# Example: 4000 token budget, 500 IS budget
#
# Step 1: IS allocated (guaranteed)
#   IS content: 450 tokens → remaining: 3550
#
# Step 2: Semantic memories (by relevance score)
#   fact_1: 200 tokens (score: 0.95) → included
#   fact_2: 300 tokens (score: 0.88) → included
#   fact_3: 500 tokens (score: 0.82) → included
#   ... until budget exhausted
#
# Step 3: Episodic memories (by relevance score)
#   episode_1: 400 tokens (score: 0.75) → included
#   ... until budget exhausted
#
# Result: IS (450) + Semantic (1500) + Episodic (1500) = 3450 tokens
# Remaining: 550 tokens
```

### Internal State Document

Each IS document contains:

```python
{
    "_id": ObjectId("..."),
    "session_id": "sess_123",
    "org_id": "org_1",
    "user_id": "user_1",
    "content": "User: Software engineer...",
    "content_hash": "a1b2c3d4e5f6g7h8",  # SHA256[:16]
    "token_count": 487,
    "token_count_estimated": False,
    "version": 42,  # Increments on every update
    "model_id": "gpt-4",
    "agent_id": "agent_1",
    "source_turn_id": "turn_99",
    "update_reason": "turn_end",
    "created_at": datetime(...),
    "updated_at": datetime(...),
    "last_promoted_at": None,
    "promotion_count": 0,
    "metadata": {},
}
```

Key properties:
- **One per session**: Unique index on `(session_id, org_id)`
- **Atomic upsert**: `find_one_and_update` with `ReturnDocument.AFTER`
- **Version always increments**: First insert = v1, updates = v2, v3, ...
- **Content hash**: SHA256[:16] for integrity/deduplication

## Memory Modes

The engine supports three modes:

| Mode | Context | Use Case |
|------|---------|----------|
| `TRADITIONAL` | STM + Snapshots + LTM | Standard chat, short sessions |
| `IWM` | Internal State + LTM | Long-horizon agents, constant cost |
| `HYBRID` | IS + STM + LTM | Migration, debugging, evals |

### Mode Selection

```python
from mongomem_core import MemoryEngine, MemoryMode

# At engine construction
engine = MemoryEngine(mode=MemoryMode.IWM)

# With custom resolver (per-tenant feature flags)
def resolve_mode(org_id: str, session_id: str) -> MemoryMode:
    if org_id in BETA_ORGS:
        return MemoryMode.IWM
    return MemoryMode.TRADITIONAL

engine = MemoryEngine(
    mode=MemoryMode.TRADITIONAL,  # Default
    mode_resolver=resolve_mode,   # Override per org/session
)
```

### Mode Gating

Methods are gated by mode:

| Method | TRADITIONAL | IWM | HYBRID |
|--------|-------------|-----|--------|
| `write_turn()` | ✅ | ❌ ModeError | ✅ |
| `update_internal_state()` | ❌ ModeError | ✅ | ✅ |
| `get_internal_state()` | ✅ (returns None) | ✅ | ✅ |
| `clear_internal_state()` | ❌ ModeError | ✅ | ✅ |

```python
from mongomem_core import ModeError

# IWM mode blocks write_turn
engine = MemoryEngine(mode=MemoryMode.IWM)

try:
    engine.write_turn(...)
except ModeError as e:
    print(e.method)         # "write_turn"
    print(e.current_mode)   # MemoryMode.IWM
    print(e.required_modes) # [MemoryMode.TRADITIONAL, MemoryMode.HYBRID]
    print(e.fix)            # Actionable fix message
```

## API Reference

### `engine.generate_is_from_turn()` — Auto-Generate IS (Convenience)

Automatically generate IS content from turn events. **Optional sugar** on top of `update_internal_state()`.

```python
from mongomem_core import MemoryEngine, MemoryMode, ISGenerationConfig

# Setup with IS generation config
engine = MemoryEngine.from_env(
    mode=MemoryMode.IWM,
    llm=reasoning_llm,           # Main LLM for extraction
    is_llm=cheap_summarizer,     # Optional: cheaper model for IS
    is_config=ISGenerationConfig(
        update_policy="coalesce",    # "always" | "milestone" | "every_n" | "coalesce"
        coalesce_window_ms=5000,     # Batch events within 5s window
        max_tokens=500,              # Hard token limit (API-enforced)
        temperature=0.3,             # Deterministic output
    ),
)

# Auto-generate IS from turn events
result = engine.generate_is_from_turn(
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    # Flexible inputs — all optional
    user_message="How do I refresh tokens?",
    assistant_response="Use the refresh endpoint...",
    tool_observations=["Token expired", "Retry succeeded"],
    intermediate_thoughts="Need to check expiration logic",
    # Policy controls
    milestone="task_complete",   # For "milestone" policy
    turn_index=5,                # For "every_n" policy
    force=False,                 # True to bypass policy
)

# Result
if result.updated:
    print(f"IS v{result.version}: {result.token_count} tokens")
    print(f"Hash: {result.content_hash}")
elif result.coalesced:
    print(f"Queued, next update at {result.next_update_at}")
elif result.was_noop:
    print("Content unchanged, skipped")
```

#### Update Policies

| Policy | Behavior | Use Case |
|--------|----------|----------|
| `"always"` | Generate on every call | Simple agents, short sessions |
| `"coalesce"` | Batch within time window | Tool loops, cost optimization |
| `"milestone"` | Only on specific triggers | Meaningful boundaries only |
| `"every_n"` | Every N turns | Predictable frequency |

#### ISGenerationConfig Reference

```python
ISGenerationConfig(
    # Update policy
    update_policy="coalesce",
    coalesce_window_ms=5000,
    every_n_turns=3,
    milestone_triggers=["task_complete", "error_resolved"],
    
    # LLM generation
    max_tokens=500,              # Hard limit (API-enforced)
    temperature=0.3,
    stop_sequences=["</internal_state>"],
    
    # Optimization
    skip_if_unchanged=True,      # Skip if hash matches
    
    # Security
    redact_patterns=[r"sk-[a-zA-Z0-9]+"],  # Redact API keys
    sanitize_inputs=my_func,     # Custom sanitizer
)
```

---

### `engine.update_internal_state()` — Manual IS Update (Primitive)

Update the agent's belief state. **IWM/HYBRID only.**

```python
result = engine.update_internal_state(
    # Required
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    content="Agent's current understanding...",
    
    # Optional
    token_count=None,              # If None, estimated as len//4
    token_count_estimated=True,    # True if token_count is estimate
    model_id="gpt-4",              # Model that generated this
    agent_id="agent_1",            # Agent instance ID
    source_turn_id="turn_42",      # Turn that triggered update
    update_reason="turn_end",      # "turn_end", "explicit", "periodic"
    metadata={"key": "value"},     # Arbitrary metadata
)

# Result
result.session_id     # str
result.version        # int (1, 2, 3, ...)
result.token_count    # int
result.content_hash   # str (SHA256[:16])
result.acknowledged   # bool
```

### `engine.get_internal_state()`

Read current belief state. **All modes** (observability).

```python
state = engine.get_internal_state(
    session_id="sess_123",
    org_id="org_1",
)

if state:
    print(state.content)
    print(state.version)
    print(state.token_count)
    print(state.updated_at)
```

### `engine.clear_internal_state()`

Delete belief state. **IWM/HYBRID only.**

```python
deleted = engine.clear_internal_state(
    session_id="sess_123",
    org_id="org_1",
)
# True if deleted, False if not found
```

### `engine.build_memory_context()`

Build mode-aware context.

```python
context = engine.build_memory_context(
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    query="What's the deadline?",
    
    # Budget
    token_budget=4000,
    is_token_budget=500,
    
    # LTM retrieval
    top_k=50,
    similarity_threshold=0.7,
    
    # Optional
    query_embedding=None,  # Auto-generated if None
)

# Access
context.source                    # "iwm" | "traditional" | "hybrid"
context.internal_state            # str or None
context.internal_state_tokens     # int
context.internal_state_version    # int
context.is_truncated              # bool
context.stm_turns                 # List[ShortTermOut] (empty in IWM)
context.semantic_memories         # List[SemanticOut]
context.episodic_memories         # List[EpisodicOut]
context.ltm_tokens                # int
context.total_tokens              # int
context.budget_remaining          # int

# Invariants
context.invariants.stm_empty      # True in IWM
context.invariants.is_present     # True if IS exists
context.invariants.is_primary     # True in IWM
context.assert_invariants()       # Raises if violated
```

## Writing Good Internal State

The quality of IS content determines IWM effectiveness. Guide your agent to write:

### Good IS Structure

```
User Profile:
- Role: Software engineer
- Preferences: Python, dark mode, concise responses

Current Context:
- Task: Debugging OAuth token refresh
- Progress: Identified expiration issue
- Blockers: None

Key Insights:
- Token expires after 1 hour (not configurable)
- Refresh endpoint requires client_secret

Next Steps:
- Implement refresh flow in auth.py
- Add retry logic with exponential backoff

Open Questions:
- Should we cache the refresh token?
```

### IS Prompting Tips

1. **Structure matters**: Use consistent sections
2. **Be selective**: Only include actionable information
3. **Update incrementally**: Preserve important context, drop stale info
4. **Stay within budget**: Target ~400-500 tokens

Example prompt addition:

```
After each response, update your internal state with:
- User profile and preferences
- Current task and progress
- Key insights and decisions
- Next steps
- Open questions

Keep it under 500 tokens. Focus on what you need to continue effectively.
```

## Migration Path

### From Traditional to IWM

1. **Start with HYBRID mode** for comparison:
   ```python
   engine = MemoryEngine(mode=MemoryMode.HYBRID)
   ```

2. **Log both contexts** to compare quality:
   ```python
   # Both available in HYBRID
   is_content = engine.get_internal_state(...)
   stm_turns = get_stm_by_session(...)
   ```

3. **Evaluate on evals** before switching:
   - Does IS capture important context?
   - Are long sessions more coherent?
   - Is reasoning quality maintained?

4. **Switch to IWM** when confident:
   ```python
   engine = MemoryEngine(mode=MemoryMode.IWM)
   ```

### Per-Org Rollout

```python
def resolve_mode(org_id: str, session_id: str) -> MemoryMode:
    if org_id in IWM_GA_ORGS:
        return MemoryMode.IWM
    if org_id in IWM_BETA_ORGS:
        return MemoryMode.HYBRID  # Comparison mode
    return MemoryMode.TRADITIONAL

engine = MemoryEngine(mode_resolver=resolve_mode)
```

## Best Practices

### 1. Set Appropriate Budgets

```python
# Conservative (more LTM)
is_token_budget=300
token_budget=4000  # 300 IS + 3700 LTM

# Balanced (default)
is_token_budget=500
token_budget=4000  # 500 IS + 3500 LTM

# IS-heavy (complex agents)
is_token_budget=800
token_budget=4000  # 800 IS + 3200 LTM
```

### 2. Update IS Every Turn

```python
# In your agent loop:
for turn in conversation:
    # 1. Build context
    context = engine.build_memory_context(...)
    
    # 2. Generate response
    response = llm.generate(context.internal_state, context.semantic_memories, ...)
    
    # 3. Update IS (critical!)
    engine.update_internal_state(
        content=response.updated_state,
        source_turn_id=turn.id,
        update_reason="turn_end",
        ...
    )
```

### 3. Monitor IS Quality

```python
# Log IS metrics
state = engine.get_internal_state(...)
logger.info(
    "IS update",
    version=state.version,
    tokens=state.token_count,
    hash=state.content_hash,
)

# Alert on anomalies
if state.token_count > is_token_budget * 1.5:
    logger.warning("IS exceeds budget, will be truncated")
```

### 4. Use HYBRID for Debugging

```python
# When investigating issues:
engine = MemoryEngine(mode=MemoryMode.HYBRID)

# Compare IS vs STM
is_state = engine.get_internal_state(...)
stm_turns = get_stm_by_session(...)

# Did IS miss something important?
```

## Troubleshooting

### IS Not Updating

```python
# Check mode
print(engine.mode)  # Should be IWM or HYBRID

# Check for ModeError
try:
    engine.update_internal_state(...)
except ModeError as e:
    print(e.fix)  # Follow the fix instructions
```

### Context Too Small

```python
# Check budget allocation
context = engine.build_memory_context(...)
print(f"IS: {context.internal_state_tokens}")
print(f"LTM: {context.ltm_tokens}")
print(f"Remaining: {context.budget_remaining}")

# Increase budgets if needed
context = engine.build_memory_context(
    token_budget=8000,  # Increase total
    is_token_budget=800,  # Increase IS
    ...
)
```

### IS Being Truncated

```python
# Check if truncated
if context.is_truncated:
    logger.warning("IS was truncated to fit budget")
    
# Solutions:
# 1. Increase is_token_budget
# 2. Have agent write more concise IS
# 3. Use structured format to pack more info
```

## Next Steps

- [API Reference](engine-api.md) — Full method documentation
- [Memory Types](MEMORY_TYPES.md) — All memory types explained
- [Examples](../examples/) — Working code samples

