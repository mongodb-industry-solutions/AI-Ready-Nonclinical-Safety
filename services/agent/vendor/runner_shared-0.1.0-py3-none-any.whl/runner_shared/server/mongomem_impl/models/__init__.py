"""Pydantic models for HTTP request/response."""
