"""FastAPI application factory for mongomem HTTP server."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Optional

from fastapi import FastAPI

if TYPE_CHECKING:
    from runner_shared.server.mongomem_impl.src.mongomem_core.engine import MemoryEngine
    from runner_shared.server.mongomem_impl.src.mongomem_worker.worker import MongoMemWorker

logger = logging.getLogger(__name__)


def create_app(engine: "MemoryEngine", worker: "Optional[MongoMemWorker]" = None) -> FastAPI:
    """
    Create FastAPI application for memory operations.

    Args:
        engine: Initialized MemoryEngine instance
        worker: Optional MongoMemWorker for on-demand pipeline processing

    Returns:
        FastAPI application with all routes registered
    """

    @asynccontextmanager
    async def lifespan(app: FastAPI):  # type: ignore[type-arg]
        if worker is not None:
            worker.initialize()
            logger.info("MongoMemWorker initialized (on-demand mode)")
        yield
        if worker is not None:
            worker.shutdown()
            logger.info("MongoMemWorker stopped")

    app = FastAPI(
        title="Mongomem Memory Server",
        description="HTTP REST API for agent memory operations",
        version="1.0.0",
        lifespan=lifespan,
    )

    # Store engine and worker in app state for route handlers
    app.state.engine = engine
    app.state.worker = worker

    # Register route modules
    from runner_shared.server.mongomem_impl.routes.v1 import (
        context,
        episodic,
        health,
        ingestion,
        procedural,
        retrieval,
        semantic,
        stm,
        taxonomic,
        user_context,
    )
    from runner_shared.server.mongomem_impl.routes.v1 import (
        worker as worker_routes,
    )

    app.include_router(health.router, prefix="/api/v1", tags=["health"])
    app.include_router(semantic.router, prefix="/api/v1", tags=["semantic"])
    app.include_router(episodic.router, prefix="/api/v1", tags=["episodic"])
    app.include_router(procedural.router, prefix="/api/v1", tags=["procedural"])
    app.include_router(stm.router, prefix="/api/v1", tags=["stm"])
    app.include_router(retrieval.router, prefix="/api/v1", tags=["retrieval"])
    app.include_router(context.router, prefix="/api/v1", tags=["context"])
    app.include_router(ingestion.router, prefix="/api/v1", tags=["ingestion"])
    app.include_router(user_context.router, prefix="/api/v1", tags=["user_context"])
    app.include_router(taxonomic.router, prefix="/api/v1", tags=["taxonomic"])
    app.include_router(worker_routes.router, prefix="/api/v1", tags=["worker"])

    logger.info("FastAPI app created with all routes registered")

    return app
