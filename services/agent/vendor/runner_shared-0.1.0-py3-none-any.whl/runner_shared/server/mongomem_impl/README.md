# MongoDB Agentic Memory Core

A headless, framework-agnostic memory engine for AI agents, extracted from the ExoMemory service. This package provides persistent memory storage, retrieval, and context management capabilities that can be embedded in any application or service.

This package now lives in the `agentic-platform` monorepo at
`client-libraries/packages/mongomem`.

## Overview

This project consists of two main components:

- **`mongomem_core`**: The headless memory engine providing domain logic for memory types (episodic, semantic, short-term, snapshot, taxonomic, procedural), Temporal Knowledge Graph (TKG), retrieval, extraction, and storage management.

- **`mongomem_worker`**: An async task worker for background processing (embeddings, entity extraction, learning, maintenance, snapshots) backed by MongoDB task queues.

Both components are **framework-agnostic** (no FastAPI, Celery, or other framework dependencies) and can be integrated into any Python application.

## Architecture

### Core Engine (`mongomem_core`)

The core engine is organized into several domains:

- **Storage**: Collection descriptors, index definitions, bootstrap helpers, and migrations
- **Memory**: Domain models and logic for different memory types
- **TKG**: Temporal Knowledge Graph for entity and fact storage
- **Retrieval**: Context building pipeline with multi-source retrieval (`RetrievalHub`), multi-factor ranking (`MemoryRanker`), token budgeting (`Budgeter`), and formatting (`Formatter`). Orchestrated by `ContextBuilder`.
- **Extraction**: LLM-based extraction pipelines
- **Pipelines**: High-level workflows (write memory, ingest events, maintenance)

### Worker (`mongomem_worker`)

The worker provides:

- **Task Queue**: MongoDB-backed task queue with DLQ support
- **Handlers**: Async handlers for embeddings, entity extraction, learning, maintenance, snapshots
- **Change Streams**: MongoDB change stream processing for real-time updates
- **Storage**: Worker-specific collections and indexes (tasks, DLQ, worker state, scheduled tasks)

## Memory Modes

The engine supports three operating modes:

| Mode | Context Formula | Use Case |
|------|-----------------|----------|
| **TRADITIONAL** | STM + Snapshots + LTM | Standard chat, short sessions |
| **IWM** | Internal State + LTM | Long-horizon agents, constant cost |
| **HYBRID** | IS + STM + LTM | Migration, debugging, evals |

```python
from mongomem_core import MemoryEngine, MemoryMode

# Traditional (default) - context grows with conversation
engine = MemoryEngine(mode=MemoryMode.TRADITIONAL)

# IWM - constant context size via agent-authored belief state
engine = MemoryEngine(mode=MemoryMode.IWM)

# Hybrid - both (for migration/debugging)
engine = MemoryEngine(mode=MemoryMode.HYBRID)
```

See [docs/IWM_MODE.md](docs/IWM_MODE.md) for detailed IWM guide.

## Extraction Approval Workflow (Manual Mode)

By default, extraction pipelines persist memories immediately (`approval_mode="auto"`). For review workflows, you can stage extractions for approval (`approval_mode="manual"`) and then approve/reject them later.

- **Guide**: See `docs/approval-workflow.md` for end-to-end usage (staging, querying pending items, approve/reject, unpublish, visibility/group scoping, TTLs).
- **Supported extraction types**: semantic, episodic, taxonomic, preferences, procedural.

## Observability

The engine supports pluggable observability via `ObservabilityProtocol`. Pass any backend to capture metrics, traces, and events:

```python
from mongomem_core import MemoryEngine
from mongomem_core.observability import LoggingObservability

# Metrics logged to Python logger (for dev/debugging)
engine = MemoryEngine(observability=LoggingObservability())
```

Available backends:
- `NoOpObservability` - Zero overhead (default)
- `LoggingObservability` - Logs to Python logger (development)
- `OpenTelemetryObservability` - Enterprise observability (requires `pip install mongomem[opentelemetry]`)
- Custom - implement `ObservabilityProtocol` for Datadog, Prometheus, etc.

See [docs/observability.md](docs/observability.md) for available metrics, tracing, and integration examples.

## Storage Layer

The storage layer provides a **headless** abstraction over MongoDB collections and indexes:

### Engine Collections

The engine manages 24 collections organized into three categories:

**Memory Collections** (11):
- `memory_short_term`, `memory_semantic`, `memory_episodic`, `memory_snapshot`
- `memory_taxonomic`, `memory_procedural`, `memory_user_context`
- `memory_sessions`, `memory_persona`, `memory_pooled_registry`
- `internal_state` (IWM mode)

**Entity/TKG Collections** (6):
- `entities`, `entity_profiles`, `entity_edges`, `facts`, `facts_archive`, `entity_search`

**Config/Control Collections** (7):
- `org_settings`, `user_settings`, `org_cohort_settings`, `org_quotas`
- `settings_audit`, `agent_profiles`, `session_counters`

### Worker Collections

The worker manages 5 collections:
- `tasks`, `tasks_dlq`, `worker_state`, `change_stream_state`, `scheduled_tasks`

### Indexes

- **B-tree indexes**: All collections have comprehensive B-tree indexes defined in `storage/indexes.py` (engine) and `mongomem_worker/storage/indexes.py` (worker)
- **Search/Vector indexes**: Atlas Search and vector indexes for semantic, episodic, snapshot, and taxonomic memory collections

## Installation

```bash
pip install mongomem
```

This installs both `mongomem_core` (the engine) and `mongomem_worker` (the async worker) in a single package.

**Optional Dependencies:**

```bash
# For Google Cloud Storage ingestion
pip install 'mongomem[gcs]'

# For Docling advanced extraction (future)
pip install 'mongomem[docling]'

# For development
pip install 'mongomem[dev,test]'
```

Or install from source:

```bash
git clone <repository-url>
cd agentic-platform/client-libraries/packages/mongomem
pip install -e .

# With GCS support
pip install -e '.[gcs]'
```

## Quick Start

### Basic Usage (Traditional Mode)

```python
from mongomem_core import MemoryEngine

# Create engine from environment variables (defaults to TRADITIONAL mode)
engine = MemoryEngine.from_env()

# Bootstrap storage (run once at startup)
# This ensures all collections and indexes exist (idempotent)
engine.bootstrap()
```

### IWM Mode (Internal Working Memory)

IWM mode maintains **constant context size** by having the agent rewrite a single belief state each turn, rather than accumulating messages.

```python
from mongomem_core import MemoryEngine, MemoryMode

# Create engine in IWM mode
engine = MemoryEngine.from_env(mode=MemoryMode.IWM)
engine.bootstrap()

# Agent updates its belief state each turn (overwrites previous)
result = engine.update_internal_state(
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    content="User prefers dark mode. Working on project X. Key insight: deadline is Friday.",
    model_id="gpt-4",
    update_reason="turn_end",
)
print(f"Version: {result.version}")  # Increments on each update

# Build context (IS + LTM, constant size)
context = engine.build_memory_context(
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    query="What's the deadline?",
    token_budget=4000,
    is_token_budget=500,
)
print(f"IS: {context.internal_state_tokens} tokens")
print(f"LTM: {context.ltm_tokens} tokens")
# context.stm_turns is always empty in IWM mode
```

**Auto-generate IS (optional convenience):**

```python
from mongomem_core import ISGenerationConfig

engine = MemoryEngine.from_env(
    mode=MemoryMode.IWM,
    llm=my_llm,
    is_config=ISGenerationConfig(
        update_policy="coalesce",  # Batch events within window
        coalesce_window_ms=5000,
        max_tokens=500,
    ),
)

# Engine generates IS automatically from turn events
result = engine.generate_is_from_turn(
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    user_message="Hello",
    assistant_response="Hi there!",
)
```

**When to use IWM:**
- Long-horizon agents (100+ turns)
- Cost-sensitive deployments (constant token usage)
- Agents that can self-summarize their state

See [docs/IWM_MODE.md](docs/IWM_MODE.md) for detailed guide.

### API Overview

| Memory Type | Create | Get | List | Update | Delete |
|-------------|--------|-----|------|--------|--------|
| **STM** | `write_turn`* | - | - | - | - |
| **Internal State** | `update_internal_state`** | `get_internal_state` | - | - | `clear_internal_state`** |
| **Semantic** | `create_semantic` | `get_semantic` | `list_semantic` | `update_semantic` | `delete_semantic` |
| **Episodic** | `create_episodic` | `get_episodic` | `list_episodic` | `update_episodic` | `delete_episodic` |
| **Procedural** | `create_procedural` | `get_procedural` | `list_procedural` | `update_procedural` | `delete_procedural` |
| **User Context** | `create_user_context` | `get_user_context` | `list_user_context` | `update_user_context` | `delete_user_context` |

*`write_turn` blocked in IWM mode | **`update/clear_internal_state` blocked in TRADITIONAL mode

**Bulk & Ingestion Methods:**
| Method | Description |
|--------|-------------|
| `bulk_create_semantic` | Efficiently insert multiple semantic memories |
| `ingest_documents` | Extract, chunk, and store documents (PDF, PPTX, DOCX, TXT) |
| `queue_ingestion` | Queue documents for async worker processing |
| `get_ingestion_status` | Check status of queued ingestion job |

**Retrieval Methods:**
| Method | Description |
|--------|-------------|
| `build_context` | Full retrieval pipeline: fetch, rank, budget, format for LLM |
| `build_memory_context` | Mode-aware context building (returns `MemoryContext`) |
| `fetch_semantic_memories` | Fetch, deduplicate, and rank semantic memories |
| `fetch_episodic_memories` | Fetch, deduplicate, and rank episodic memories |
| `fetch_procedural_memories` | Fetch, deduplicate, and rank procedural memories |

### Writing Conversation Turns (STM)

The `write_turn` method stores individual messages in short-term memory. These turns are later consolidated into snapshots during memory maintenance.

```python
# Write a user message
result = engine.write_turn(
    session_id="sess_123",
    role="user",
    content="What's the weather in NYC?",
    org_id="org_1",
    user_id="user_1",
)

# Write an assistant message with tool calls
result = engine.write_turn(
    session_id="sess_123",
    role="assistant",
    tool_calls=[
        {"name": "get_weather", "arguments": {"city": "NYC"}, "id": "call_1"}
    ],
    org_id="org_1",
    user_id="agent_1",
    model_name="gpt-4",
)

# Write a tool result
result = engine.write_turn(
    session_id="sess_123",
    role="tool",
    content='{"temperature": 72, "condition": "sunny"}',
    tool_call_id="call_1",
    tool_name="get_weather",
    org_id="org_1",
    user_id="agent_1",
)
```

### Creating Semantic Memory

Store factual knowledge, definitions, or documentation:

```python
result = engine.create_semantic(
    label="python-dict-def",
    text="A dictionary is a collection of key-value pairs.",
    org_id="org_1",
    user_id="user_1",
    source="python-docs",
)
# result.id, result.label, result.has_embedding

# Get, list, update, delete
memory = engine.get_semantic(org_id="org_1", label="python-dict-def")
memories = engine.list_semantic(org_id="org_1", user_id="user_1", limit=50)
updated = engine.update_semantic(org_id="org_1", label="python-dict-def", text="Updated text")
result = engine.delete_semantic(org_id="org_1", label="python-dict-def", soft=True)
```

### Bulk Semantic Insert

Efficiently insert multiple semantic memories at once:

```python
items = [
    {"label": "fact-1", "text": "Python was created by Guido van Rossum."},
    {"label": "fact-2", "text": "MongoDB is a document database."},
    {"label": "fact-3", "text": "Vector search enables semantic similarity."},
]

result = engine.bulk_create_semantic(
    items=items,
    org_id="org_1",
    user_id="user_1",
    generate_embeddings=True,  # Generate embeddings synchronously
    skip_duplicates=True,      # Skip items with duplicate labels
)
# result.created_count, result.created_ids, result.skipped_count
```

### Document Ingestion (Auto-RAG)

Ingest PDF, PPTX, DOCX, and TXT documents into semantic memory. Documents are extracted, chunked, and stored as searchable memories.

**Supported File Types:**
- `.txt` - Plain text
- `.pdf` - PDF documents (with page tracking)
- `.pptx` - PowerPoint presentations
- `.docx` - Word documents

**Basic Usage:**

```python
result = engine.ingest_documents(
    paths=["docs/report.pdf", "notes.txt", "slides/deck.pptx"],
    org_id="org_1",
    user_id="user_1",
)

print(f"Created {result.total_chunks} chunks from {result.files_succeeded} files")
for fr in result.file_results:
    print(f"  {fr.path}: {fr.chunks_created} chunks")
```

**With Custom Configuration:**

```python
from mongomem_core.ingest import IngestConfig, ChunkConfig

config = IngestConfig(
    chunk_config=ChunkConfig(
        max_chunk_size=500,   # Max tokens per chunk
        min_chunk_size=100,   # Discard chunks smaller than this
        chunk_overlap=75,     # Overlap between chunks
    ),
    max_retries=3,
    on_failure="skip",  # "skip", "raise", or "collect"
)

result = engine.ingest_documents(
    paths=["docs/report.pdf"],
    org_id="org_1",
    user_id="user_1",
    config=config,
    generate_embeddings=True,  # Generate embeddings synchronously
)
```

**Ingestion from Google Cloud Storage:**

```python
from mongomem_core.ingest.storage import GCSStorage

# Ingest a single file from GCS
result = engine.ingest_documents(
    paths=["gs://my-bucket/docs/report.pdf"],
    org_id="org_1",
    user_id="user_1",
    storage_backend=GCSStorage(),
)

# Ingest all supported files from a GCS directory
result = engine.ingest_documents(
    paths=["gs://my-bucket/docs/"],  # Trailing slash = directory
    org_id="org_1",
    user_id="user_1",
    storage_backend=GCSStorage(),
)
```

**Async Ingestion via Worker:**

For large batches, queue ingestion for background processing:

```python
from mongomem_worker.handlers.ingest import IngestJobState

# Queue the job
job = engine.queue_ingestion(
    paths=["gs://my-bucket/large-docs/"],
    org_id="org_1",
    user_id="user_1",
    generate_embeddings=True,
)
print(f"Queued job: {job.job_id}")

# Start worker in background (or run separately)
worker = MongoMemWorker(engine)
worker.start_background()

# Poll for completion
import time
while True:
    status = engine.get_ingestion_status(job.job_id)
    print(f"Status: {status.state}, Chunks: {status.total_chunks}")
    if status.state in (IngestJobState.COMPLETED, IngestJobState.FAILED):
        break
    time.sleep(2)
```

**Chunk Metadata:**

Each chunk includes rich metadata for retrieval:

```python
# Stored in contextual_metadata:
{
    "source_file": "report.pdf",
    "source_path": "gs://my-bucket/docs/report.pdf",
    "chunk_index": 0,
    "total_chunks": 15,
    "page_start": 1,    # For PDFs
    "page_end": 1,
    "start_char": 0,    # Character offsets
    "end_char": 512,
}
```

### Creating Procedural Memory (Skills)

Store reusable procedures that agents can discover via vector search and follow:

```python
# Create a procedure
result = engine.create_procedural(
    procedure="deploy-app",
    description="Deploy the application to production via Docker",
    content="# Deploy\n\n1. Build Docker image\n2. Push to registry\n3. Update k8s",
    org_id="org_1",
    user_id="user_1",
    tags=["deployment", "docker"],
    steps=[
        {"step_type": "code", "content": "docker build -t app .",
         "description": "Build image", "language": "bash"},
    ],
)

# Search for procedures
chunks = engine.fetch_procedural_memories(
    query="how do I deploy the app?",
    org_id="org_1",
    top_k=5,
)

# Get, list, update, delete
proc = engine.get_procedural(org_id="org_1", procedure="deploy-app")
procs = engine.list_procedural(org_id="org_1", tags=["deployment"])
engine.update_procedural(org_id="org_1", procedure="deploy-app", content="Updated...")
engine.delete_procedural(org_id="org_1", procedure="deploy-app", soft=True)
```

**SKILL.md Migration:**

Import existing Anthropic SKILL.md files or export procedures back:

```python
from mongomem_core.migration import discover_skills, ingest_skills, export_skills

# Import SKILL.md files
paths = discover_skills("/path/to/skills/")
result = ingest_skills(engine, paths, org_id="org_1", user_id="user_1")

# Export back to SKILL.md
export_skills(engine, org_id="org_1", output_dir="/exported/")
```

**Code Execution (Optional):**

Procedures can include code steps. mongomem stores them but never executes code — plug in your own sandbox via `ExecutorProtocol`:

```python
from mongomem_core.protocols import ExecutorProtocol

engine = MemoryEngine.from_env(
    embedder=my_embedder,
    executor=my_sandbox,  # E2B, Docker, Modal, etc.
)
```

**Extraction Pipeline:**

Procedures can also be auto-discovered from conversations via the extraction pipeline (runs as a worker background job, or invoke directly):

```python
from mongomem_core.extraction.procedural import create_procedural_pipeline

pipeline = create_procedural_pipeline(db=db, llm=llm, embedder=embedder)
result = pipeline.run(messages=messages, org_id="org_1", user_id="user_1", source_id="snap_1")
```

See [docs/PROCEDURAL_MEMORY.md](docs/PROCEDURAL_MEMORY.md) for full guide including [ExecutorProtocol details](docs/PROCEDURAL_MEMORY.md#code-execution-executorprotocol), and [docs/procedural-integrations.md](docs/procedural-integrations.md) for framework integration (LangGraph, CrewAI, Agent Engine).

### Creating Episodic Memory

Store events, experiences, or conversation summaries:

```python
result = engine.create_episodic(
    title="Team standup meeting",
    content="Full meeting transcript...",
    summary_text="Discussed Q4 deliverables.",
    org_id="org_1",
    user_id="user_1",
    session_id="sess_123",
    tags=["meeting", "standup"],
)
# result.id, result.title, result.has_embedding

# Get, list, update, delete
memory = engine.get_episodic(org_id="org_1", id="...")
memories = engine.list_episodic(org_id="org_1", session_id="sess_123")
updated = engine.update_episodic(org_id="org_1", id="...", title="Updated title")
result = engine.delete_episodic(org_id="org_1", id="...", soft=True)
```

### Creating User Context

Store user preferences and communication style:

```python
result = engine.create_user_context(
    tone="casual",
    style="concise",
    language="en",
    preferred_format="bullet_points",
    source="user_input",
    org_id="org_1",
    user_id="user_1",
)

# Get, list, update, delete
context = engine.get_user_context(org_id="org_1", user_id="user_1")
contexts = engine.list_user_context(org_id="org_1", limit=10)
updated = engine.update_user_context(org_id="org_1", user_id="user_1", tone="formal")
result = engine.delete_user_context(org_id="org_1", user_id="user_1")
```

### Building Context

The `build_context` method orchestrates a complete retrieval pipeline to build context from memories. It retrieves relevant memories from multiple sources (STM, episodic, semantic), ranks them by relevance, selects within a token budget, and formats them for your LLM.

**Pipeline Stages:**
1. **Embedding Generation**: Generates query embedding (if not provided) using the engine's embedder
2. **Retrieval**: Fetches memories from enabled sources (STM, episodic, semantic)
3. **Ranking**: Multi-factor scoring (similarity, recency, importance)
4. **Budgeting**: Selects memories within token budget using greedy algorithm
5. **Formatting**: Formats context for your target LLM (OpenAI, Claude, Jinja2)

**Basic Usage:**

```python
from mongomem_core import MemoryEngine

# Create engine with embedder (required for query embedding)
engine = MemoryEngine.from_env(embedder=my_embedder)

# Build context from query
response = engine.build_context(
    query="What did we discuss about the project timeline?",
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
)

# Access formatted context
print(response.formatted_context)  # Formatted string or list
print(response.metadata.token_count)  # Token count
print(response.metadata.memory_counts)  # Counts by source
print(response.metadata.timing)  # Performance timing
```

**With Configuration:**

```python
from mongomem_core.models.retrieval import ContextConfig, MemorySource

# Custom configuration
config = ContextConfig(
    max_tokens=8000,
    token_buffer=500,
    similarity_threshold=0.7,
    enabled_sources={MemorySource.EPISODIC, MemorySource.SEMANTIC},
    ranking_weights={"similarity": 0.7, "recency": 0.2, "importance": 0.1},
)

response = engine.build_context(
    query="Team knowledge base",
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    config=config,
    model_type="claude",  # Format for Claude
)
```

**With User Context Personalization:**

```python
# Fetch user context for personalization
user_context = engine.get_user_context(org_id="org_1", user_id="user_1")

response = engine.build_context(
    query="What should I know?",
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    user_context=user_context,  # Includes tone, style, language preferences
)
# Formatted context includes user preferences in system message
```

**With Pre-fetched Memories (Advanced):**

```python
# Optionally provide pre-fetched memories to skip DB queries
stm_memories = [...]  # List[ShortTermOut]
episodic_memories = [...]  # List[EpisodicOut]

response = engine.build_context(
    query="What did we discuss?",
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    stm_memories=stm_memories,  # Skip DB query for STM
    episodic_memories=episodic_memories,  # Skip DB query for episodic
    # semantic_memories still fetched from DB
)
```

**Format Styles:**

The engine supports multiple output formats:

- **OpenAI** (`format_style="openai"`): Returns `List[Dict]` with `role` and `content` keys
- **Claude** (`format_style="claude"`): Returns XML string with `<memory>` tags
- **Jinja2** (`format_style="jinja2"`): Returns structured markdown with grouped memories

The format is auto-detected from the LLM model type, or you can specify it explicitly:

```python
response = engine.build_context(
    query="Context please",
    session_id="sess_123",
    org_id="org_1",
    user_id="user_1",
    model_type="claude",  # Auto-formats as Claude XML
)
```

**Retrieval Components:**

The retrieval pipeline consists of several modular components:

- **`RetrievalHub`**: Multi-source memory retrieval with deduplication
  - Fetches from STM (session-scoped, time-ordered), episodic (vector search), and semantic (vector search)
  - Supports both database queries and pre-fetched memory lists
  - Automatic deduplication (ID, text, and similarity-based)
- **`MemoryRanker`**: Multi-factor ranking (similarity, recency, importance)
  - Configurable weights for similarity, recency decay, and importance scoring
- **`Budgeter`**: Token budget management with greedy selection
  - Model-specific token counting via LiteLLM
  - Global token budget with buffer for formatting overhead
- **`Formatter`**: Context formatting for different LLM formats
  - OpenAI message lists, Claude XML, or Jinja2 markdown templates
  - User context personalization (tone, style, language)
- **`ContextBuilder`**: Orchestrates the full pipeline
  - Handles query embedding generation, config merging, and timing metadata

### Fetching Individual Memory Types

The engine provides convenience methods for fetching, deduplicating, and ranking individual memory types. These are useful when you need direct control over memory retrieval without the full context-building pipeline.

**Fetching Semantic Memories:**

```python
from mongomem_core import MemoryEngine
from mongomem_core.models import MetadataFilter

engine = MemoryEngine.from_env(embedder=my_embedder)

# Basic usage with query text
memories = engine.fetch_semantic_memories(
    query="Python dictionaries",
    org_id="org_1",
    top_k=20,
)

# With pre-computed embedding
query_embedding = embedder.embed("Python dictionaries")
memories = engine.fetch_semantic_memories(
    query=query_embedding,  # Pass embedding directly
    org_id="org_1",
    top_k=20,
)

# With RBAC filtering
memories = engine.fetch_semantic_memories(
    query="Team knowledge",
    org_id="org_1",
    user_id="user_1",
    visibility="shared",
    project_id="team_engineering",
)

# With metadata filtering (Atlas Vector Search pre-filtering)
memories = engine.fetch_semantic_memories(
    query="Python basics",
    org_id="org_1",
    metadata_filter=MetadataFilter(raw={"label": "python_basics"}),
)

# Control deduplication and ranking
memories = engine.fetch_semantic_memories(
    query="Python dictionaries",
    org_id="org_1",
    deduplicate=True,        # Remove similar duplicates (default)
    dedup_threshold=0.5,     # Similarity threshold for dedup
    rank=True,               # Apply multi-factor ranking (default)
    similarity_threshold=0.7, # Minimum similarity score
)
```

**Fetching Episodic Memories:**

```python
# Basic usage with query text
memories = engine.fetch_episodic_memories(
    query="meeting about project timeline",
    org_id="org_1",
    top_k=20,
)

# Filter by session
memories = engine.fetch_episodic_memories(
    query="project updates",
    org_id="org_1",
    session_id="sess_123",
)

# With RBAC filtering
memories = engine.fetch_episodic_memories(
    query="team discussions",
    org_id="org_1",
    user_id="user_1",
    visibility="shared",
    project_id="team_engineering",
)

# With metadata filtering
memories = engine.fetch_episodic_memories(
    query="standup meetings",
    org_id="org_1",
    metadata_filter=MetadataFilter(raw={"tags": {"$in": ["standup"]}}),
)

# Skip deduplication for raw results
memories = engine.fetch_episodic_memories(
    query="all meetings",
    org_id="org_1",
    deduplicate=False,
    rank=False,
)
```

**Note:** These methods return empty lists on database errors to allow graceful degradation. This provides resilience when one memory source fails while others continue working.

**Vector Search:**

The engine uses MongoDB Atlas Vector Search for semantic and episodic memory retrieval:
- Automatic similarity score calculation via `$vectorSearch` aggregation
- RBAC filtering (org_id, user_id, visibility, project_id)
- Configurable similarity thresholds
- Retry logic for transient index states

You can also use these components directly for custom workflows:

```python
from mongomem_core.retrieval import (
    RetrievalHub,
    MemoryRanker,
    Budgeter,
    Formatter,
    ContextBuilder,
)

# Build custom pipeline
hub = RetrievalHub()
ranker = MemoryRanker()
budgeter = Budgeter()
formatter = Formatter()

builder = ContextBuilder(
    retrieval_hub=hub,
    ranker=ranker,
    budgeter=budgeter,
    formatter=formatter,
    embedder=my_embedder,
    llm=my_llm,
)

response = builder.build_context(
    db=engine._db,
    session_id="sess_123",
    query="Custom query",
    org_id="org_1",
    user_id="user_1",
)
```

#### Visibility and Sharing

Control who can access memories with the `visibility` parameter:

```python
# Private (default) - only the creating user
result = engine.write_turn(
    session_id="sess_123",
    role="user",
    content="My private note",
    org_id="org_1",
    user_id="user_1",
    visibility="private",
)

# Shared with a group
result = engine.write_turn(
    session_id="sess_123",
    role="user",
    content="Team discussion",
    org_id="org_1",
    user_id="user_1",
    visibility="shared",
    project_id="team_engineering",
)

# Organization-wide
result = engine.write_turn(
    session_id="sess_123",
    role="user",
    content="Company announcement",
    org_id="org_1",
    user_id="user_1",
    visibility="org",
)
```

### Configuration

Configure via environment variables:

```bash
export MONGODB_URI="mongodb://localhost:27017"
export MONGOMEM_DB_NAME="agentic_memory"
export MONGOMEM_EMBEDDING_DIMENSION=1536
```

Or programmatically:

```python
from mongomem_core.config import Settings
from mongomem_core import MemoryEngine

settings = Settings(
    mongo_uri="mongodb://localhost:27017",
    db_name="agentic_memory",
    embedding_dimension=1536
)
engine = MemoryEngine.from_config(settings)
```

### Worker Setup

The worker requires an embedder to generate vector embeddings:

```python
from mongomem_core import MemoryEngine, Settings
from mongomem_worker import MongoMemWorker

# 1. Implement your embedder
class MyEmbedder:
    def embed(self, text: str) -> list[float]:
        # Your embedding logic (e.g., Voyage AI, OpenAI)
        ...
    
    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        ...
    
    @property
    def dimension(self) -> int:
        return 1024  # Must match Settings.embedding_dimension
    
    @property
    def model_id(self) -> str:
        return "my-model"

# 2. Create engine with embedder attached
engine = MemoryEngine(
    Settings(embedding_dimension=1024),
    embedder=MyEmbedder(),
)

# 3. Run worker
worker = MongoMemWorker(engine)
worker.run()
```

Or use the CLI:

```bash
mongomem-worker --embedder myapp.embedders.VoyageEmbedder
```

See `src/mongomem_worker/README.md` for detailed worker documentation including:
- Scaling modes (single vs distributed)
- Extraction configuration
- Metrics integration
- Jupyter notebook usage

## Storage Bootstrap

### Engine Storage

The easiest way to bootstrap the engine storage is using the `MemoryEngine.bootstrap()` method:

```python
from mongomem_core import MemoryEngine

engine = MemoryEngine.from_env()
engine.bootstrap()  # Ensures all collections and indexes (idempotent)
```

You can also use the lower-level bootstrap helpers directly if you need more control:

```python
from mongomem_core.storage import (
    ensure_engine_collections,
    ensure_engine_indexes,
    ensure_engine_search_indexes
)
from mongomem_core.storage import get_database

db = get_database()

# Ensure collections exist (idempotent)
ensure_engine_collections(db)

# Ensure B-tree indexes exist (idempotent)
ensure_engine_indexes(db)

# Ensure Atlas Search/vector indexes exist (idempotent)
ensure_engine_search_indexes(db)
```

### Worker Storage

```python
from mongomem_worker.storage import ensure_worker_collections, ensure_worker_indexes
from mongomem_core.storage import get_database

db = get_database()
ensure_worker_collections(db)
ensure_worker_indexes(db)
```

### Migrations

Run engine-domain migrations (field renames, index dimension updates, etc.):

```python
from mongomem_core.storage.migrations import run_engine_migrations
from mongomem_core.storage import get_database

db = get_database()

# Run migrations (intended for explicit maintenance steps, not every startup)
run_engine_migrations(db, force_update_text_indexes=False)
```

## Project Structure

```
src/
├── mongomem_core/          # Core memory engine
│   ├── engine.py           # Main MemoryEngine class
│   ├── config.py           # Settings configuration
│   ├── protocols.py        # EmbedderProtocol, LLMProtocol
│   ├── storage/            # Storage layer
│   │   ├── collections.py  # Collection descriptors
│   │   ├── indexes.py      # B-tree index definitions
│   │   ├── search_indexes.py # Atlas Search/vector indexes
│   │   ├── connection.py   # MongoDB client management
│   │   ├── bootstrap.py    # Bootstrap helpers
│   │   ├── migrations.py   # Migration helpers
│   │   └── validation.py   # Validation helpers
│   ├── memory/             # Memory domain logic
│   ├── tkg/                # Temporal Knowledge Graph
│   ├── retrieval/          # Context building & retrieval
│   │   ├── context_builder.py # ContextBuilder orchestration
│   │   ├── sources.py      # RetrievalHub, multi-source retrieval
│   │   ├── ranking.py      # MemoryRanker, multi-factor scoring
│   │   ├── budgeting.py    # Budgeter, token budget management
│   │   ├── formatting.py   # Formatter, context formatting
│   │   └── models.py       # MemoryChunk, ContextConfig, ContextResponse
│   ├── ingest/             # Document ingestion (Auto-RAG)
│   │   ├── models.py       # IngestConfig, ChunkConfig, IngestResult
│   │   ├── pipeline.py     # ingest_documents() orchestrator
│   │   ├── extractors/     # PDF, PPTX, DOCX, TXT extractors
│   │   ├── chunkers/       # RecursiveCharacterTextSplitter
│   │   └── storage/        # Storage backends (Local, GCS, S3)
│   ├── extraction/         # LLM extraction pipelines
│   ├── migration/          # SKILL.md import/export utilities
│   └── pipelines/          # High-level workflows
│
└── mongomem_worker/        # Async task worker
    ├── worker.py           # MongoMemWorker class
    ├── config.py           # Worker configuration
    ├── constants.py        # Centralized constants
    ├── circuit_breaker.py  # Resilience pattern
    ├── metrics.py          # Metrics protocol & helpers
    ├── queue/              # Task queue
    │   ├── models.py       # EnqueuedTask, ClaimedTask
    │   ├── operations.py   # enqueue_task, claim_task, etc.
    │   └── processor.py    # TaskQueueProcessor
    ├── errors/             # Error handling
    │   ├── exceptions.py   # Worker-specific exceptions
    │   └── classifier.py   # Error classification
    ├── streams/            # Push notifications
    │   └── change_streams.py # MongoDB change stream watchers
    ├── handlers/           # Task handlers
    │   ├── embeddings.py   # EmbeddingHandler
    │   ├── learning.py     # SemanticHandler, EpisodicHandler, TaxonomicHandler, ProceduralHandler
    │   ├── entity.py       # EntityHandler
    │   ├── snapshots.py    # SnapshotHandler
    │   ├── maintenance.py  # MaintenanceHandler
    │   └── ingest.py       # IngestHandler (async document ingestion)
    ├── storage/            # Worker storage layer
    └── entrypoints/        # CLI entrypoints
```

## Design Principles

1. **Headless**: No framework dependencies; can be embedded anywhere
2. **Idempotent**: Bootstrap helpers are safe to run multiple times
3. **Separation of Concerns**: Engine storage vs worker storage vs auth/security
4. **Thread-Safe**: Global state (client, bootstrap flags) uses proper locking
5. **Performance**: Optimized to avoid N+1 queries (e.g., batch `list_search_indexes()` calls)

## Development

### Setup

```bash
# Install with dev dependencies using uv
uv sync --extra test --extra dev

# Or using pip (alternative)
pip install -e ".[dev,test]"

# Install pre-commit hooks (run once)
pre-commit install

# Run linting
uv run ruff check .

# Run tests
uv run pytest
```

### Code Quality

- **Linting**: Ruff (configured in `pyproject.toml`)
- **Type Checking**: mypy (optional, in dev dependencies)
- **Testing**: pytest with pytest-asyncio for async tests
- **Pre-commit**: Automated checks before every commit

## Migration from Legacy ExoMemory

This package is extracted from the ExoMemory service (`poc-aifac-exomemory`). Key differences:

- **Framework-agnostic**: No FastAPI, Celery, or other framework code
- **Headless storage**: Collections and indexes are defined structurally, not tied to initialization code
- **Explicit boundaries**: Engine vs worker vs auth/security collections are clearly separated
- **Thread-safe**: Proper locking for shared state

## Related Projects

- [poc-aifac-exomemory](https://github.com/mongodb-ps/poc-aifac-exomemory): Original ExoMemory service
- [aifac-mongodb-agentic-memory-sdks](https://github.com/mongodb-ps/aifac-mongodb-agentic-memory-sdks): SDKs and client libraries

## License

Proprietary

## Contributing

This is an internal MongoDB project. For questions or contributions, contact the MongoDB Agentic Memory Team.
