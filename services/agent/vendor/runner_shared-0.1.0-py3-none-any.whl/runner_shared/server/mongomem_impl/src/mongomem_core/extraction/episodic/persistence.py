"""
Persistence layer for episodic extraction results.

Provides:
- Atomic idempotent ADD using $setOnInsert (race-safe)
- Simple in-place UPDATE (no versioning - events are historical)
- Atomic REINFORCE with importance tracking (aggregation pipeline)
"""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from pymongo.database import Database

from bson import ObjectId
from mongomem_core.common.utils import handle_db_error, safe_object_id, utcnow
from mongomem_core.extraction.config import EpisodicExtractionConfig
from mongomem_core.extraction.types import ConsolidationDecision, PersistenceResult
from mongomem_core.extraction.utils import build_reinforce_pipeline
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.storage import get_collection
from mongomem_core.storage.collections import EpisodicMemoryCollection

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════════════════════

# Use canonical collection reference
_EPISODIC_COL = EpisodicMemoryCollection()

# Default truncation lengths (override via config when available)
_DEFAULT_TITLE_TRUNCATE_LENGTH = 100
_DEFAULT_LOG_TRUNCATE_LENGTH = 50


# ═══════════════════════════════════════════════════════════════════════════════
# Extraction ID Generation
# ═══════════════════════════════════════════════════════════════════════════════


def generate_episodic_extraction_id(
    source_id: str,
    content: str,
    idempotency_key: Optional[str] = None,
) -> str:
    """
    Generate SHA-256 hash for idempotent writes.

    The extraction_id uniquely identifies an extraction from a specific source
    and content combination, preventing duplicate inserts.

    Args:
        source_id: Source reference (e.g., snapshot ID)
        content: Extracted content text
        idempotency_key: Optional additional key for uniqueness

    Returns:
        SHA-256 hash string
    """
    data = f"{source_id}_{content}"
    if idempotency_key:
        data = f"{data}_{idempotency_key}"
    return hashlib.sha256(data.encode()).hexdigest()


def _validate_extraction_for_persistence(extraction: Any) -> bool:
    """
    Validate extraction has required fields for persistence.

    Args:
        extraction: ScoredExtraction to validate

    Returns:
        True if valid, False otherwise
    """
    if not extraction.content or not extraction.content.strip():
        logger.warning("Extraction missing content")
        return False
    if not extraction.embedding:
        logger.warning("Extraction missing embedding")
        return False
    return True


# ═══════════════════════════════════════════════════════════════════════════════
# Atomic Idempotent ADD
# ═══════════════════════════════════════════════════════════════════════════════


def perform_episodic_add(
    db: "Database",
    decision: ConsolidationDecision,
    org_id: str,
    user_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    embedding_model_id: str,
    visibility: ChunkVisibility = ChunkVisibility.PRIVATE,
    project_id: Optional[str] = None,
) -> Optional[str]:
    """
    Atomic idempotent ADD using $setOnInsert.

    Uses update_one with upsert and $setOnInsert for race-safety.
    If a document with the same extraction_id already exists, returns None
    (idempotent - no duplicate created).

    This is the same pattern as semantic persistence - fully race-safe.

    Args:
        db: MongoDB database instance
        decision: Consolidation decision with extraction
        org_id: Organization ID
        user_id: User ID
        source_id: Source reference (snapshot ID)
        extraction_timestamp: When extraction was performed
        embedding_model_id: Embedding model used

    Returns:
        Created document ID string, or None if duplicate detected
    """
    col = get_collection(_EPISODIC_COL, db)
    extraction = decision.extraction

    # Validate extraction before persistence
    if not _validate_extraction_for_persistence(extraction):
        logger.warning("Invalid extraction for ADD, skipping")
        return None

    extraction_id = generate_episodic_extraction_id(source_id, extraction.content)

    # Validate extraction_id before upsert
    if not extraction_id or not isinstance(extraction_id, str):
        logger.error("Invalid extraction_id: %s", extraction_id)
        return None

    # Extract episodic-specific metadata
    metadata = extraction.metadata
    title = metadata.get("title", extraction.content[:_DEFAULT_TITLE_TRUNCATE_LENGTH])
    participants = metadata.get("participants", [])
    timestamp_hint = metadata.get("timestamp_hint")
    outcome = metadata.get("outcome")

    # Build content with outcome if present
    content = extraction.content
    if outcome and outcome not in content:
        content = f"{content}\nOutcome: {outcome}"

    # Build contextual metadata with scoring info
    contextual_metadata = {
        "timestamp_hint": timestamp_hint,
        "outcome": outcome,
        "citation_score": extraction.citation_score,
        "llm_confidence_score": extraction.confidence,
        "combined_score": extraction.combined_score,
        "cited_text": extraction.cited_text,
        "reinforcement_sources": [],  # Track which snapshots reinforced this
    }

    # Build full document
    now = utcnow()
    doc = {
        "org_id": org_id,
        "user_id": user_id,
        "title": title,
        "content": content,
        "summary_text": extraction.content,
        "summary_type": "llm",
        "source_agent": "agent_mediated",
        "participants": participants,
        "extraction_source": "agent_mediated",
        "session_id": None,
        "snapshot_ref_id": source_id,
        "extraction_id": extraction_id,
        # Embedding fields
        "embedding": extraction.embedding,
        "summary_embedding_model_id": embedding_model_id,
        "has_embedding": True,
        # Reinforcement fields (initialized for tracking importance)
        "reinforcement_count": 0,
        "last_reinforced_at": None,
        "reinforcement_history": [],
        # Timestamps
        "timestamp": extraction_timestamp,
        "created_at": now,
        "updated_at": now,
        # Soft delete
        "deleted": False,
        "deleted_at": None,
        # Contextual metadata
        "metadata": contextual_metadata,
        # Visibility/scope
        "visibility": visibility.value,
        "project_id": project_id,
    }

    # Atomic idempotent upsert - only inserts if no document with extraction_id exists
    with handle_db_error(
        operation="update_one",
        collection=_EPISODIC_COL.name,
        log_message="Failed to perform idempotent ADD: extraction_id=%s org=%s",
        log_args_tuple=(extraction_id, org_id),
    ):
        result = col.update_one(
            {"extraction_id": extraction_id, "org_id": org_id},
            {"$setOnInsert": doc},
            upsert=True,
        )

        if result.upserted_id:
            logger.debug("Created new episodic memory: %s", result.upserted_id)
            return str(result.upserted_id)
        elif result.matched_count > 0:
            logger.info(
                "Duplicate episodic extraction detected, skipping (idempotent): extraction_id=%s",
                extraction_id,
            )
            return None

    return None


# ═══════════════════════════════════════════════════════════════════════════════
# Simple UPDATE (in-place enrichment, no versioning)
# ═══════════════════════════════════════════════════════════════════════════════


def perform_episodic_update(
    db: "Database",
    decision: ConsolidationDecision,
    org_id: str,
    user_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    embedding_model_id: str,
    visibility: ChunkVisibility = ChunkVisibility.PRIVATE,
    project_id: Optional[str] = None,
) -> Optional[str]:
    """
    In-place UPDATE for episodic memories.

    Unlike semantic, episodic doesn't use versioning because events are
    historical - they happened. What we're updating is our UNDERSTANDING
    of the event (adding outcomes, participants, etc.), not correcting it.

    Args:
        db: MongoDB database instance
        decision: Consolidation decision with extraction and existing_id
        org_id: Organization ID
        user_id: User ID
        source_id: Source reference (snapshot ID)
        extraction_timestamp: When extraction was performed
        embedding_model_id: Embedding model used

    Returns:
        Updated document ID string, or None if failed
    """
    col = get_collection(_EPISODIC_COL, db)
    extraction = decision.extraction
    existing_id = decision.existing_id

    if not existing_id:
        logger.warning("UPDATE decision missing existing_id")
        return None

    # Validate extraction before persistence
    if not _validate_extraction_for_persistence(extraction):
        logger.warning("Invalid extraction for UPDATE, skipping")
        return None

    # Convert existing_id to ObjectId
    try:
        query_id = ObjectId(existing_id)
    except Exception as e:
        logger.warning("Invalid ObjectId format: %s - %s", existing_id, e)
        return None

    # Extract episodic-specific metadata
    metadata = extraction.metadata
    outcome = metadata.get("outcome")
    participants = metadata.get("participants", [])
    timestamp_hint = metadata.get("timestamp_hint")

    # Build content with outcome if present
    content = extraction.content
    if outcome and outcome not in content:
        content = f"{content}\nOutcome: {outcome}"

    now = utcnow()

    # Build update with new information
    update_doc: Dict[str, Any] = {
        "summary_text": extraction.content,
        "content": content,
        "embedding": extraction.embedding,
        "summary_embedding_model_id": embedding_model_id,
        "has_embedding": True,
        "updated_at": now,
        # Update metadata with new info
        "metadata.outcome": outcome,
        "metadata.timestamp_hint": timestamp_hint,
        "metadata.last_updated_source": source_id,
        "metadata.last_updated_at": extraction_timestamp,
        "metadata.citation_score": extraction.citation_score,
        "metadata.llm_confidence_score": extraction.confidence,
        "metadata.combined_score": extraction.combined_score,
        # Visibility/scope
        "visibility": visibility.value,
        "project_id": project_id,
    }

    # Merge participants (add new ones without duplicating)
    with handle_db_error(
        operation="update_one",
        collection=_EPISODIC_COL.name,
        log_message="Failed to update episodic memory: id=%s org=%s",
        log_args_tuple=(existing_id, org_id),
    ):
        # Build update operation - only include $addToSet if participants non-empty
        update_op: Dict[str, Any] = {"$set": update_doc}
        if participants:
            update_op["$addToSet"] = {"participants": {"$each": participants}}

        result = col.update_one(
            {
                "_id": query_id,
                "org_id": org_id,
                "user_id": user_id,
                "deleted": {"$ne": True},
            },
            update_op,
        )

        if result.matched_count > 0:
            logger.info(
                "Updated episodic memory %s: source=%s",
                existing_id,
                source_id,
            )
            return existing_id
        else:
            logger.warning(
                "Episodic memory %s not found for update (org_id=%s, user_id=%s)",
                existing_id,
                org_id,
                user_id,
            )
            return None

    return None


# ═══════════════════════════════════════════════════════════════════════════════
# Atomic REINFORCE with Importance Tracking
# ═══════════════════════════════════════════════════════════════════════════════


def perform_episodic_reinforce(
    db: "Database",
    decision: ConsolidationDecision,
    org_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    reinforcement_history_limit: int = 20,
    user_id: Optional[str] = None,
) -> Optional[str]:
    """
    Atomic reinforcement using MongoDB aggregation pipeline.

    Tracks how many times an event is mentioned (importance signal):
    - reinforcement_count: Number of times this event was mentioned
    - last_reinforced_at: When it was last mentioned
    - reinforcement_history: Timestamps of mentions (capped)
    - metadata.reinforcement_sources: Which snapshots mentioned it

    This is valuable because events mentioned multiple times are more
    significant to the user than one-off mentions.

    All operations are atomic and idempotent (same source won't increment twice).

    Args:
        db: MongoDB database instance
        decision: Consolidation decision with existing_id
        org_id: Organization ID
        source_id: Source reference (snapshot ID)
        extraction_timestamp: When extraction was performed
        reinforcement_history_limit: Max history entries to keep
        user_id: Optional user ID for additional filtering

    Returns:
        Document ID if reinforced, or None if failed
    """
    col = get_collection(_EPISODIC_COL, db)
    existing_id = decision.existing_id

    # Use safe_object_id for cleaner validation
    query_id = safe_object_id(existing_id, "REINFORCE")
    if not query_id:
        return None

    # Build atomic reinforcement pipeline using shared utility
    # Episodic stores reinforcement_sources in metadata
    update_pipeline = build_reinforce_pipeline(
        source_id=source_id,
        timestamp=extraction_timestamp,
        sources_field="metadata.reinforcement_sources",
        history_field="reinforcement_history",
        count_field="reinforcement_count",
        last_reinforced_field="last_reinforced_at",
        history_limit=reinforcement_history_limit,
        extra_set_stages={
            # Episodic also updates updated_at unconditionally
            "updated_at": extraction_timestamp,
        },
    )

    # Build query filter
    query_filter: Dict[str, Any] = {
        "_id": query_id,
        "org_id": org_id,
        "deleted": {"$ne": True},
    }
    if user_id:
        query_filter["user_id"] = user_id

    try:
        result = col.update_one(query_filter, update_pipeline)
    except Exception as e:
        logger.error("Failed to reinforce episodic document %s: %s", existing_id, e)
        return None

    if result.matched_count > 0:
        if result.modified_count > 0:
            logger.info(
                "Reinforced episodic memory %s: source_snapshot=%s",
                existing_id,
                source_id,
            )
        else:
            logger.debug(
                "Episodic memory %s already reinforced by snapshot %s (idempotent)",
                existing_id,
                source_id,
            )
        return existing_id

    logger.warning(
        "Episodic memory %s not found for reinforcement (org_id=%s)",
        existing_id,
        org_id,
    )
    return None


# ═══════════════════════════════════════════════════════════════════════════════
# Main apply_decisions Function
# ═══════════════════════════════════════════════════════════════════════════════


def apply_episodic_decisions(
    db: "Database",
    decisions: List[ConsolidationDecision],
    org_id: str,
    user_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    embedding_model_id: str,
    config: EpisodicExtractionConfig,
    visibility: ChunkVisibility = ChunkVisibility.PRIVATE,
    project_id: Optional[str] = None,
) -> PersistenceResult:
    """
    Apply all consolidation decisions for episodic memories.

    Args:
        db: MongoDB database instance
        decisions: List of consolidation decisions
        org_id: Organization ID
        user_id: User ID
        source_id: Source reference (snapshot ID)
        extraction_timestamp: When extraction was performed
        embedding_model_id: Embedding model used
        config: Episodic extraction configuration

    Returns:
        PersistenceResult with counts and IDs of affected documents
    """
    result = PersistenceResult()

    for decision in decisions:
        try:
            if decision.action == "ADD":
                doc_id = perform_episodic_add(
                    db=db,
                    decision=decision,
                    org_id=org_id,
                    user_id=user_id,
                    source_id=source_id,
                    extraction_timestamp=extraction_timestamp,
                    embedding_model_id=embedding_model_id,
                    visibility=visibility,
                    project_id=project_id,
                )
                if doc_id:
                    result.added += 1
                    result.created_ids.append(doc_id)
                else:
                    result.skipped += 1  # Idempotent duplicate

            elif decision.action == "UPDATE":
                doc_id = perform_episodic_update(
                    db=db,
                    decision=decision,
                    org_id=org_id,
                    user_id=user_id,
                    source_id=source_id,
                    extraction_timestamp=extraction_timestamp,
                    embedding_model_id=embedding_model_id,
                    visibility=visibility,
                    project_id=project_id,
                )
                if doc_id:
                    result.updated += 1
                    result.updated_new_version_ids.append(doc_id)
                else:
                    result.skipped += 1

            elif decision.action == "REINFORCE":
                doc_id = perform_episodic_reinforce(
                    db=db,
                    decision=decision,
                    org_id=org_id,
                    source_id=source_id,
                    extraction_timestamp=extraction_timestamp,
                    reinforcement_history_limit=config.reinforcement_history_limit,
                    user_id=user_id,
                )
                if doc_id:
                    result.reinforced += 1
                    result.reinforced_ids.append(doc_id)
                else:
                    result.skipped += 1

            elif decision.action == "DUPLICATE":
                # Defensive: DUPLICATE is in ConsolidationAction type but current
                # strategies map to REINFORCE. Keep for type safety & future use.
                result.skipped += 1

        except Exception as e:
            logger.warning(
                "%s failed for episodic decision %s: %s",
                decision.action,
                decision.extraction.content[:_DEFAULT_LOG_TRUNCATE_LENGTH]
                if decision.extraction.content
                else "empty",
                e,
            )
            result.errors.append(f"{decision.action}: {e}")

    return result


__all__ = [
    "generate_episodic_extraction_id",
    "perform_episodic_add",
    "perform_episodic_update",
    "perform_episodic_reinforce",
    "apply_episodic_decisions",
]
