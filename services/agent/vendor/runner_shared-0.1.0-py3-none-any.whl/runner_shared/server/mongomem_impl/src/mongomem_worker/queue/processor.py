"""
Task queue processor for distributed worker processing.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Callable, Dict, Optional

from bson import ObjectId
from pymongo.database import Database

from ..errors import classify_error, get_error_taxonomy
from ..observability import WorkerObservability
from ..storage import get_tasks_collection
from ..utils import ensure_utc, generate_worker_id, utcnow
from .operations import (
    claim_task,
    complete_task,
    heartbeat_task,
)

logger = logging.getLogger(__name__)


class TaskQueueProcessor:
    """
    Multi-worker safe task queue processor.

    Multiple instances can run in parallel - they coordinate via
    atomic task claiming with leases.

    Features:
    - Per-task timeouts
    - Heartbeat support for long-running tasks
    - Error classification for smart retries
    - Pluggable observability
    """

    def __init__(
        self,
        db: Database,
        worker_id: Optional[str] = None,
        task_types: Optional[list[str]] = None,
        lease_seconds: int = 300,
        poll_interval: float = 1.0,
        task_timeouts: Optional[Dict[str, float]] = None,
        heartbeat_interval: float = 30.0,
        observability: Optional[WorkerObservability] = None,
    ):
        self._db = db
        self._worker_id = worker_id or generate_worker_id(include_thread=True)
        self._task_types = task_types
        self._lease_seconds = lease_seconds
        self._poll_interval = poll_interval
        self._coll = get_tasks_collection(db)
        self._handlers: Dict[str, Callable] = {}
        self._running = False
        # Import default timeouts from config to avoid duplication
        from ..config import DEFAULT_TASK_TIMEOUT, DEFAULT_TASK_TIMEOUTS

        self._task_timeouts = task_timeouts or DEFAULT_TASK_TIMEOUTS.copy()
        self._default_timeout = DEFAULT_TASK_TIMEOUT
        self._heartbeat_interval = heartbeat_interval
        self._obs = observability or WorkerObservability(worker_id=self._worker_id)

    @property
    def worker_id(self) -> str:
        return self._worker_id

    def register_handler(
        self,
        task_type: str,
        handler: Callable[[Dict[str, Any]], Any],
    ) -> None:
        """Register a handler for a task type."""
        self._handlers[task_type] = handler
        logger.debug("Registered handler for task type: %s", task_type)

    def get_timeout(self, task_type: str) -> float:
        """Get timeout for a task type."""
        return self._task_timeouts.get(task_type, self._default_timeout)

    async def _heartbeat_loop(self, task_id: ObjectId, stop_event: asyncio.Event):
        """Background loop to send heartbeats for a running task."""
        while not stop_event.is_set():
            try:
                await asyncio.sleep(self._heartbeat_interval)
                if stop_event.is_set():
                    break
                heartbeat_task(
                    self._coll,
                    task_id,
                    self._worker_id,
                    self._lease_seconds,
                )
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.warning("Heartbeat failed for task %s: %s", task_id, exc)

    async def process_one(self) -> bool:
        """
        Attempt to claim and process one task.

        Returns:
            True if a task was processed, False if no tasks available
        """
        task = claim_task(
            self._coll,
            self._worker_id,
            self._task_types,
            self._lease_seconds,
        )

        if not task:
            return False

        # Record task claimed
        self._obs.task_claimed(task.task_type)

        # Track queue wait time (handle timezone-naive datetimes from MongoDB)
        created_at = ensure_utc(task.created_at)
        queue_time_ms = (utcnow() - created_at).total_seconds() * 1000
        self._obs.queue_time(task.task_type, queue_time_ms)

        handler = self._handlers.get(task.task_type)
        if not handler:
            logger.warning("No handler for task type: %s", task.task_type)
            self._obs.task_failed(task.task_type, "permanent", "no_handler")
            complete_task(
                self._coll,
                task.id,
                self._worker_id,
                success=False,
                error=f"No handler registered for type: {task.task_type}",
                attempts=task.attempts,
                max_retries=task.remaining_retries + task.attempts,
            )
            return True

        # Get timeout for this task type
        timeout = self.get_timeout(task.task_type)

        # Start heartbeat loop for long-running tasks
        heartbeat_stop = asyncio.Event()
        heartbeat = asyncio.create_task(self._heartbeat_loop(task.id, heartbeat_stop))

        start_time = time.perf_counter()
        try:
            result = handler(task.payload)
            if hasattr(result, "__await__"):
                # Run with timeout
                result = await asyncio.wait_for(result, timeout=timeout)

            # Record success
            duration_ms = (time.perf_counter() - start_time) * 1000
            self._obs.task_completed(task.task_type, duration_ms)

            complete_task(
                self._coll,
                task.id,
                self._worker_id,
                success=True,
                result={"output": str(result)} if result else None,
                attempts=task.attempts,
                max_retries=task.remaining_retries + task.attempts,
            )
        except asyncio.TimeoutError:
            error_msg = f"Task exceeded timeout of {timeout}s"
            logger.error("Task %s timeout: %s", task.id, error_msg)
            self._obs.task_timeout(task.task_type, timeout)
            self._obs.task_failed(task.task_type, "transient", "timeout")
            complete_task(
                self._coll,
                task.id,
                self._worker_id,
                success=False,
                error=error_msg,
                attempts=task.attempts,
                max_retries=task.remaining_retries + task.attempts,
            )
        except Exception as exc:
            logger.exception("Task %s failed: %s", task.id, exc)
            error_type = classify_error(str(exc))
            error_taxonomy = get_error_taxonomy(str(exc))
            self._obs.task_failed(task.task_type, error_type.value, error_taxonomy.value)
            complete_task(
                self._coll,
                task.id,
                self._worker_id,
                success=False,
                error=str(exc),
                attempts=task.attempts,
                max_retries=task.remaining_retries + task.attempts,
            )
        finally:
            # Stop heartbeat loop
            heartbeat_stop.set()
            heartbeat.cancel()
            try:
                await heartbeat
            except asyncio.CancelledError:
                pass

        return True

    def stop(self) -> None:
        """Signal the processor to stop."""
        self._running = False


__all__ = ["TaskQueueProcessor"]
