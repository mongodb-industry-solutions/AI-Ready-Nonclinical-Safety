"""Retrieval operations for MemoryEngine.

Internal implementation - use MemoryEngine from mongomem_core.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, List, Optional, Set, Union

from mongomem_core.models.context import MemoryContext
from mongomem_core.models.filters import MetadataFilter
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.retrieval import (
    ContextConfig,
    ContextResponse,
    FormatStyle,
    MemorySource,
    ModelType,
)
from mongomem_core.modes import MemoryMode
from mongomem_core.retrieval import (
    Budgeter,
    ContextBuilder,
    Formatter,
    MemoryRanker,
    RetrievalHub,
)
from mongomem_core.retrieval.iwm_context import IWMContextBuilder

if TYPE_CHECKING:
    from mongomem_core.engine._protocol import EngineProtocol
    from mongomem_core.models.config.thread_retrieval import ThreadRetrievalConfig
    from mongomem_core.models.memory.episodic import EpisodicOut
    from mongomem_core.models.memory.semantic import SemanticOut
    from mongomem_core.models.memory.short_term import ShortTermOut
    from mongomem_core.models.memory.user_prefs import UserContextMemoryOut
    from mongomem_core.models.retrieval import ConversationThread

logger = logging.getLogger(__name__)


class _Retrieval:
    """Context building and thread retrieval operations."""

    def build_memory_context(
        self: "EngineProtocol",
        session_id: str,
        org_id: str,
        user_id: str,
        *,
        query: Optional[str] = None,
        query_embedding: Optional[List[float]] = None,
        token_budget: int = 4000,
        is_token_budget: int = 500,
        top_k: int = 50,
        visibility: Optional[ChunkVisibility] = None,
        project_id: Optional[str] = None,
        similarity_threshold: float = 0.0,
        agent_id: Optional[str] = None,
        stm_agent_id: Optional[str] = None,
        stm_exclude_agent_ids: Optional[List[str]] = None,
    ) -> MemoryContext:
        """
        Build context based on engine mode.

        This is the mode-aware context building method:
        - IWM mode: Returns IS + LTM (no STM)
        - TRADITIONAL mode: Returns STM + LTM (no IS)
        - HYBRID mode: Returns IS + STM + LTM

        Args:
            session_id: Session identifier
            org_id: Organization ID
            user_id: User ID
            query: Query text for LTM retrieval
            query_embedding: Pre-computed query embedding
            token_budget: Total token budget for context
            is_token_budget: Max tokens for Internal State (IWM/HYBRID)
            top_k: Maximum LTM memories to retrieve
            visibility: Optional visibility filter
            project_id: Optional group ID filter
            similarity_threshold: Minimum similarity for LTM
            agent_id: Agent identifier for IS scoping (IWM/HYBRID)
            stm_agent_id: Filter STM to only include turns from this agent
            stm_exclude_agent_ids: Filter STM to exclude turns from these agents

        Returns:
            MemoryContext with mode-appropriate content and invariants
        """
        # Resolve mode for this org/session
        effective_mode = self.resolve_mode(org_id=org_id, session_id=session_id)

        logger.debug(
            "Building memory context: session=%s org=%s agent=%s mode=%s",
            session_id,
            org_id,
            agent_id,
            effective_mode.value,
        )

        if effective_mode == MemoryMode.IWM:
            return self._build_context_iwm(
                session_id=session_id,
                org_id=org_id,
                user_id=user_id,
                query=query,
                query_embedding=query_embedding,
                token_budget=token_budget,
                is_token_budget=is_token_budget,
                top_k=top_k,
                visibility=visibility,
                project_id=project_id,
                similarity_threshold=similarity_threshold,
                agent_id=agent_id,
            )
        elif effective_mode == MemoryMode.HYBRID:
            return self._build_context_hybrid(
                session_id=session_id,
                org_id=org_id,
                user_id=user_id,
                query=query,
                query_embedding=query_embedding,
                token_budget=token_budget,
                is_token_budget=is_token_budget,
                top_k=top_k,
                visibility=visibility,
                project_id=project_id,
                similarity_threshold=similarity_threshold,
                agent_id=agent_id,
                stm_agent_id=stm_agent_id,
                stm_exclude_agent_ids=stm_exclude_agent_ids,
            )
        else:
            return self._build_context_traditional(
                session_id=session_id,
                org_id=org_id,
                user_id=user_id,
                query=query,
                query_embedding=query_embedding,
                token_budget=token_budget,
                top_k=top_k,
                visibility=visibility,
                project_id=project_id,
                similarity_threshold=similarity_threshold,
                stm_agent_id=stm_agent_id,
                stm_exclude_agent_ids=stm_exclude_agent_ids,
            )

    def _build_context_iwm(
        self: "EngineProtocol",
        session_id: str,
        org_id: str,
        user_id: str,
        *,
        query: Optional[str] = None,
        query_embedding: Optional[List[float]] = None,
        token_budget: int = 4000,
        is_token_budget: int = 500,
        top_k: int = 50,
        visibility: Optional[ChunkVisibility] = None,
        project_id: Optional[str] = None,
        similarity_threshold: float = 0.0,
        agent_id: Optional[str] = None,
    ) -> MemoryContext:
        """Build context for IWM mode using IWMContextBuilder."""
        builder = IWMContextBuilder(embedder=self._embedder)
        return builder.build_context(
            db=self._db,
            session_id=session_id,
            org_id=org_id,
            user_id=user_id,
            query=query,
            query_embedding=query_embedding,
            token_budget=token_budget,
            is_token_budget=is_token_budget,
            top_k=top_k,
            visibility=visibility,
            project_id=project_id,
            similarity_threshold=similarity_threshold,
            agent_id=agent_id,
        )

    def _build_context_traditional(
        self: "EngineProtocol",
        session_id: str,
        org_id: str,
        user_id: str,
        *,
        query: Optional[str] = None,
        query_embedding: Optional[List[float]] = None,
        token_budget: int = 4000,
        top_k: int = 50,
        visibility: Optional[ChunkVisibility] = None,
        project_id: Optional[str] = None,
        similarity_threshold: float = 0.0,
        stm_agent_id: Optional[str] = None,
        stm_exclude_agent_ids: Optional[List[str]] = None,
    ) -> MemoryContext:
        """
        Build context for TRADITIONAL mode.

        Wraps the existing ContextBuilder response into MemoryContext.

        Args:
            stm_agent_id: If provided, only include turns from this agent
            stm_exclude_agent_ids: If provided, exclude turns from these agents
        """
        from mongomem_core.memory.short_term import get_recent_stm

        # Fetch STM turns (with optional agent filtering for multi-agent scenarios)
        stm_turns = get_recent_stm(
            db=self._db,
            session_id=session_id,
            org_id=org_id,
            user_id=user_id,
            visibility=visibility,
            project_id=project_id,
            agent_id=stm_agent_id,
            exclude_agent_ids=stm_exclude_agent_ids,
            limit=top_k,
        )

        # Use the existing build_context for LTM
        # For now, return a basic MemoryContext
        # Full integration would involve using ContextBuilder
        return MemoryContext.for_traditional(
            session_id=session_id,
            org_id=org_id,
            user_id=user_id,
            stm_turns=stm_turns,
            stm_tokens=sum(t.tokens or 0 for t in stm_turns),
            semantic_memories=[],
            episodic_memories=[],
            ltm_tokens=0,
            total_tokens=sum(t.tokens or 0 for t in stm_turns),
            budget_remaining=token_budget - sum(t.tokens or 0 for t in stm_turns),
        )

    def _build_context_hybrid(
        self: "EngineProtocol",
        session_id: str,
        org_id: str,
        user_id: str,
        *,
        query: Optional[str] = None,
        query_embedding: Optional[List[float]] = None,
        token_budget: int = 4000,
        is_token_budget: int = 500,
        top_k: int = 50,
        visibility: Optional[ChunkVisibility] = None,
        project_id: Optional[str] = None,
        similarity_threshold: float = 0.0,
        agent_id: Optional[str] = None,
        stm_agent_id: Optional[str] = None,
        stm_exclude_agent_ids: Optional[List[str]] = None,
    ) -> MemoryContext:
        """
        Build context for HYBRID mode (IS + STM + LTM).

        Combines IS from IWM and STM from Traditional.

        Args:
            agent_id: Agent ID for IS scoping (each agent has own IS)
            stm_agent_id: If provided, only include STM turns from this agent
            stm_exclude_agent_ids: If provided, exclude STM turns from these agents
        """
        from mongomem_core.memory.internal_state import get_internal_state
        from mongomem_core.memory.short_term import get_recent_stm

        # Fetch IS (scoped to agent for multi-agent support)
        internal_state = get_internal_state(self._db, session_id, org_id, agent_id=agent_id)

        # Fetch STM (with optional agent filtering for multi-agent scenarios)
        stm_turns = get_recent_stm(
            db=self._db,
            session_id=session_id,
            org_id=org_id,
            user_id=user_id,
            visibility=visibility,
            project_id=project_id,
            agent_id=stm_agent_id,
            exclude_agent_ids=stm_exclude_agent_ids,
            limit=top_k,
        )

        is_content = internal_state.content if internal_state else None
        is_tokens = internal_state.token_count if internal_state else 0
        is_version = internal_state.version if internal_state else 0
        stm_tokens = sum(t.tokens or 0 for t in stm_turns)

        return MemoryContext.for_hybrid(
            session_id=session_id,
            org_id=org_id,
            user_id=user_id,
            internal_state=is_content,
            internal_state_tokens=is_tokens,
            internal_state_version=is_version,
            stm_turns=stm_turns,
            stm_tokens=stm_tokens,
            semantic_memories=[],
            episodic_memories=[],
            ltm_tokens=0,
            total_tokens=is_tokens + stm_tokens,
            budget_remaining=token_budget - is_tokens - stm_tokens,
        )

    def build_context(
        self: "EngineProtocol",
        query: str,
        session_id: str,
        org_id: str,
        user_id: str,
        *,
        visibility: Optional[ChunkVisibility] = None,
        project_id: Optional[str] = None,
        metadata_filter: Optional[MetadataFilter] = None,
        query_embedding: Optional[List[float]] = None,
        user_context: Optional["UserContextMemoryOut"] = None,
        model_type: Union[str, ModelType] = ModelType.OPENAI,
        max_tokens: Optional[int] = None,
        enabled_sources: Optional[Set[Union[str, MemorySource]]] = None,
        top_k: int = 50,
        similarity_threshold: float = 0.0,
        format_style: Optional[Union[str, FormatStyle]] = None,
        stm_memories: Optional[List["ShortTermOut"]] = None,
        episodic_memories: Optional[List["EpisodicOut"]] = None,
        semantic_memories: Optional[List["SemanticOut"]] = None,
        include_memories: bool = False,
    ) -> ContextResponse:
        """
        Build context from memories by querying MongoDB or using pre-fetched memories.

        This method orchestrates the full retrieval pipeline:
        1. Generate query embedding (if needed)
        2. Fetch memories via RetrievalHub
        3. Rank memories via MemoryRanker
        4. Select memories within budget via Budgeter
        5. Format into final context via Formatter

        Args:
            query: User query text for embedding generation
            session_id: Session identifier for STM retrieval
            org_id: Organization ID for multi-tenancy
            user_id: User ID for filtering
            visibility: Memory visibility scope
            project_id: Project ID for shared memories
            query_embedding: Pre-computed query embedding
            user_context: User context/preferences for personalization
            model_type: Target model format
            max_tokens: Token budget limit
            enabled_sources: Memory sources to use
            top_k: Maximum number of results per source
            similarity_threshold: Minimum similarity score
            format_style: Format style for context output (openai, claude, or jinja2)
            stm_memories: Optional pre-fetched STM memories
            episodic_memories: Optional pre-fetched episodic memories
            semantic_memories: Optional pre-fetched semantic memories
            include_memories: If True, attach selected MemoryChunks to ContextResponse.selected_memories

        Returns:
            ContextResponse with formatted context and metadata
        """
        logger.debug(
            "Building context: session=%s org=%s user=%s query_len=%d",
            session_id,
            org_id,
            user_id,
            len(query) if query else 0,
        )

        with self._obs.track_context_build() as ctx:
            config = ContextConfig.from_params(
                model_type=model_type,
                max_tokens=max_tokens,
                similarity_threshold=similarity_threshold,
                enabled_sources=enabled_sources,
                format_style=format_style,
                include_memories=include_memories,
            )

            retrieval_hub = RetrievalHub(obs=self._obs)
            ranker = MemoryRanker()
            budgeter = Budgeter()
            formatter = Formatter()

            builder = ContextBuilder(
                retrieval_hub=retrieval_hub,
                ranker=ranker,
                budgeter=budgeter,
                formatter=formatter,
                embedder=self._embedder,
                llm=self._llm,
                obs=self._obs,
            )

            response = builder.build_context(
                db=self._db,
                session_id=session_id,
                query=query,
                org_id=org_id,
                user_id=user_id,
                query_embedding=query_embedding,
                visibility=visibility,
                project_id=project_id,
                metadata_filter=metadata_filter,
                config=config,
                user_context=user_context,
                top_k=top_k,
                stm_memories=stm_memories,
                episodic_memories=episodic_memories,
                semantic_memories=semantic_memories,
            )

            # Set context for metrics
            ctx["memories_count"] = sum(response.metadata.memory_counts.values())
            ctx["tokens"] = response.metadata.token_count

            logger.info(
                "Context built: session=%s memories=%d tokens=%d",
                session_id,
                sum(response.metadata.memory_counts.values()),
                response.metadata.token_count,
            )

            return response

    def retrieve_conversation_thread(
        self: "EngineProtocol",
        org_id: str,
        query: str | list[float],
        *,
        config: Optional["ThreadRetrievalConfig"] = None,
        return_metrics: bool = False,
    ) -> "ConversationThread | tuple[ConversationThread, Any]":
        """
        Retrieve a coherent conversation thread relevant to the query.

        This implements "conversation resumption" - finding complete, coherent
        conversation threads rather than scattered top-k results.

        Args:
            org_id: Organization ID
            query: Text query (str) or pre-computed embedding (List[float])
            config: Optional ThreadRetrievalConfig to customize retrieval
            return_metrics: If True, also return ThreadRetrievalMetrics

        Returns:
            ConversationThread containing chronologically ordered snapshots.
            If return_metrics=True, returns (ConversationThread, ThreadRetrievalMetrics).
        """
        from mongomem_core.models.config.thread_retrieval import ThreadRetrievalConfig
        from mongomem_core.retrieval.backends import MongoSnapshotBackend
        from mongomem_core.retrieval.thread import retrieve_conversation_thread

        effective_config = config or ThreadRetrievalConfig()
        backend = MongoSnapshotBackend(self._db)

        return retrieve_conversation_thread(
            backend=backend,
            org_id=org_id,
            query=query,
            config=effective_config,
            embedder=self._embedder,
            return_metrics=return_metrics,
        )

    def retrieve_for_resumption(
        self: "EngineProtocol",
        org_id: str,
        query: str | list[float],
    ) -> "ConversationThread":
        """
        Retrieve conversation thread for session resumption.

        Convenience method using RESUME_SESSION_CONFIG preset which
        focuses on the current session only.

        Args:
            org_id: Organization ID
            query: Text query or embedding

        Returns:
            ConversationThread from the most relevant session
        """
        from mongomem_core.models.config.thread_retrieval import RESUME_SESSION_CONFIG

        result: ConversationThread = self.retrieve_conversation_thread(  # type: ignore[attr-defined]
            org_id=org_id,
            query=query,
            config=RESUME_SESSION_CONFIG,
        )
        return result

    def retrieve_cross_session_knowledge(
        self: "EngineProtocol",
        org_id: str,
        query: str | list[float],
    ) -> "ConversationThread":
        """
        Retrieve knowledge threads across all sessions.

        Convenience method using KNOWLEDGE_RETRIEVAL_CONFIG preset which
        searches across all sessions for related conversations.

        Args:
            org_id: Organization ID
            query: Text query or embedding

        Returns:
            ConversationThread potentially spanning multiple sessions
        """
        from mongomem_core.models.config.thread_retrieval import KNOWLEDGE_RETRIEVAL_CONFIG

        result: ConversationThread = self.retrieve_conversation_thread(  # type: ignore[attr-defined]
            org_id=org_id,
            query=query,
            config=KNOWLEDGE_RETRIEVAL_CONFIG,
        )
        return result
