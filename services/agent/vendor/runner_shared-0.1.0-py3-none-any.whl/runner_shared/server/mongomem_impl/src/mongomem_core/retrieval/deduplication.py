"""Deduplication logic for memory chunks."""

from __future__ import annotations

import logging
from collections import defaultdict
from typing import List, Set, Tuple, TypedDict

from mongomem_core.models.retrieval import MemoryChunk
from mongomem_core.retrieval.constants import LARGE_MEMORY_LIST_THRESHOLD

logger = logging.getLogger(__name__)


class CandidateScoreData(TypedDict):
    """Type definition for candidate score data in similarity detection."""

    overlap_count: int
    idx1_ngram_count: int
    idx2_ngram_count: int


def _create_candidate_score() -> CandidateScoreData:
    """
    Create a new candidate score data structure with default values.

    Returns:
        CandidateScoreData with overlap_count, idx1_ngram_count, and idx2_ngram_count set to 0
    """
    return {"overlap_count": 0, "idx1_ngram_count": 0, "idx2_ngram_count": 0}


def deduplicate_memory_chunks(
    memories: List[MemoryChunk],
    similarity_threshold: float = 0.5,
) -> List[MemoryChunk]:
    """
    Remove duplicate memories using multiple strategies.

    This is a public function that can be used independently for deduplicating
    memory chunks from any source (semantic, episodic, or mixed).

    Deduplication steps:
    1. Remove exact ID duplicates (keep first occurrence)
    2. Remove exact text duplicates (normalized, keep first occurrence)
    3. Remove high similarity duplicates (keep higher-scoring memory)

    Args:
        memories: List of memory chunks to deduplicate
        similarity_threshold: Threshold for similarity-based deduplication (default: 0.5)

    Returns:
        Deduplicated list of MemoryChunk objects
    """
    if not memories:
        return []

    seen_ids: Set[str] = set()
    seen_texts: Set[str] = set()
    unique_memories: List[MemoryChunk] = []

    for memory in memories:
        if memory.id in seen_ids:
            continue
        seen_ids.add(memory.id)

        normalized_text = _normalize_text(memory.content)
        if normalized_text in seen_texts:
            continue
        seen_texts.add(normalized_text)

        unique_memories.append(memory)

    if len(unique_memories) < 2:
        return unique_memories

    candidates = _find_similarity_candidates(unique_memories, similarity_threshold)
    if not candidates:
        return unique_memories

    to_remove: Set[int] = set()
    for idx1, idx2 in candidates:
        if idx1 in to_remove or idx2 in to_remove:
            continue

        old_memory = unique_memories[idx1]
        new_memory = unique_memories[idx2]

        if _should_keep_new_memory(old_memory, new_memory):
            to_remove.add(idx1)
        else:
            to_remove.add(idx2)

    result = [mem for idx, mem in enumerate(unique_memories) if idx not in to_remove]
    logger.debug(
        "Deduplication: %d input -> %d after exact -> %d after similarity"
        % (len(memories), len(unique_memories), len(result))
    )
    return result


def _normalize_text(text: str) -> str:
    """
    Normalize text for comparison.

    Converts to lowercase, strips whitespace, and removes extra spaces.

    Args:
        text: Input text to normalize

    Returns:
        Normalized text string
    """
    if not text:
        return ""
    return " ".join(text.lower().strip().split())


def _calculate_text_similarity(text1: str, text2: str, ngram_size: int = 3) -> float:
    """
    Calculate Jaccard similarity between two texts using n-grams.

    Uses Jaccard similarity on n-gram sets for efficient and accurate
    similarity calculation. More efficient than SequenceMatcher for
    this use case.

    Args:
        text1: First text string (will be normalized)
        text2: Second text string (will be normalized)
        ngram_size: Size of n-grams to use (default: 3)

    Returns:
        Similarity score between 0.0 and 1.0

    Formula:
        Jaccard = |ngrams1 ∩ ngrams2| / |ngrams1 ∪ ngrams2|
    """
    normalized1 = _normalize_text(text1)
    normalized2 = _normalize_text(text2)

    if not normalized1 and not normalized2:
        return 1.0
    if not normalized1 or not normalized2:
        return 0.0
    if normalized1 == normalized2:
        return 1.0

    ngrams1 = _generate_ngrams(normalized1, ngram_size)
    ngrams2 = _generate_ngrams(normalized2, ngram_size)

    if not ngrams1 and not ngrams2:
        return 1.0
    if not ngrams1 or not ngrams2:
        return 0.0

    intersection = len(ngrams1.intersection(ngrams2))
    union = len(ngrams1.union(ngrams2))

    return intersection / union if union > 0 else 0.0


def _generate_ngrams(text: str, n: int = 3) -> Set[str]:
    """
    Generate n-grams from normalized text.

    Args:
        text: Input text
        n: Size of n-grams (default: 3)

    Returns:
        Set of n-gram strings
    """
    normalized = _normalize_text(text)
    if len(normalized) < n:
        return {normalized} if normalized else set()
    ngrams = set()
    for i in range(len(normalized) - n + 1):
        ngrams.add(normalized[i : i + n])
    return ngrams


def _build_ngram_index(
    memories: List[MemoryChunk],
    ngram_size: int,
) -> Tuple[defaultdict[str, List[Tuple[int, int]]], List[Set[str]], List[int]]:
    """
    Build n-gram index for similarity candidate detection.

    Args:
        memories: List of memory chunks to index
        ngram_size: Size of n-grams to use

    Returns:
        Tuple of (ngram_index, text_ngrams_cache, ngram_counts)
        - ngram_index: Maps n-gram strings to list of (memory_index, ngram_count) tuples
        - text_ngrams_cache: List of n-gram sets for each memory
        - ngram_counts: List of n-gram counts for each memory
    """
    normalized_texts = [_normalize_text(m.content) for m in memories]
    ngram_index: defaultdict[str, List[Tuple[int, int]]] = defaultdict(list)
    text_ngrams_cache: List[Set[str]] = []

    for idx, text in enumerate(normalized_texts):
        if not text:
            text_ngrams_cache.append(set())
            continue
        ngrams = _generate_ngrams(text, ngram_size)
        ngram_count = len(ngrams)
        text_ngrams_cache.append(ngrams)
        for ngram in ngrams:
            ngram_index[ngram].append((idx, ngram_count))

    ngram_counts = [len(ngrams) for ngrams in text_ngrams_cache]
    return ngram_index, text_ngrams_cache, ngram_counts


def _calculate_candidate_overlaps(
    text_ngrams_cache: List[Set[str]],
    ngram_index: defaultdict[str, List[Tuple[int, int]]],
) -> defaultdict[Tuple[int, int], CandidateScoreData]:
    """
    Calculate n-gram overlaps between candidate pairs.

    Args:
        text_ngrams_cache: List of n-gram sets for each text
        ngram_index: Index mapping n-grams to memory indices and counts

    Returns:
        Dictionary mapping (idx1, idx2) to CandidateScoreData with overlap statistics
    """
    candidate_scores: defaultdict[Tuple[int, int], CandidateScoreData] = defaultdict(
        _create_candidate_score
    )

    for idx, text_ngrams in enumerate(text_ngrams_cache):
        if not text_ngrams:
            continue
        current_ngram_count = len(text_ngrams)
        for ngram in text_ngrams:
            if ngram in ngram_index:
                for other_idx, other_ngram_count in ngram_index[ngram]:
                    if other_idx == idx:
                        continue
                    pair_key = (min(idx, other_idx), max(idx, other_idx))
                    score_data = candidate_scores[pair_key]

                    if pair_key[0] == idx:
                        # idx is the first in the pair
                        if score_data["idx1_ngram_count"] == 0:
                            score_data["idx1_ngram_count"] = current_ngram_count
                        if score_data["idx2_ngram_count"] == 0:
                            score_data["idx2_ngram_count"] = other_ngram_count
                    else:
                        # idx is the second in the pair
                        if score_data["idx1_ngram_count"] == 0:
                            score_data["idx1_ngram_count"] = other_ngram_count
                        if score_data["idx2_ngram_count"] == 0:
                            score_data["idx2_ngram_count"] = current_ngram_count

                    score_data["overlap_count"] += 1
    return candidate_scores


def _find_similarity_candidates(
    memories: List[MemoryChunk],
    threshold: float = 0.5,
    similarity_filter_ratio: float = 0.7,
    ngram_size: int = 3,
) -> List[Tuple[int, int]]:
    """
    Find candidate pairs of memories that may be similar using optimized n-gram indexing.

    Uses n-gram indexing with upper-bound filtering to efficiently find potential
    similarity candidates. This optimization reduces comparisons from O(n²) to
    O(n log n) by filtering out items that cannot possibly meet the threshold.

    Args:
        memories: List of memory chunks to check for duplicates
        threshold: Similarity threshold for candidate filtering (default: 0.5)
        similarity_filter_ratio: Aggressiveness of filtering (0.5-0.9, default: 0.7)
        ngram_size: Size of n-grams to use (default: 3)

    Returns:
        List of tuples (index1, index2) representing candidate pairs

    Performance:
        Traditional: Compare against ALL pairs = O(n²)
        Optimized: Compare against filtered candidates = O(n log n)
    """
    if len(memories) < 2:
        return []

    if len(memories) > LARGE_MEMORY_LIST_THRESHOLD:
        logger.warning(
            "Large memory list detected (%d items). This may consume significant memory during similarity detection."
            % (len(memories),)
        )

    ngram_index, text_ngrams_cache, ngram_counts = _build_ngram_index(memories, ngram_size)
    candidate_scores = _calculate_candidate_overlaps(text_ngrams_cache, ngram_index)

    result = []
    for (idx1, idx2), score_data in candidate_scores.items():
        # Add defensive bounds checking
        if idx1 >= len(memories) or idx2 >= len(memories):
            logger.warning("Invalid indices in candidate pair: (%d, %d)" % (idx1, idx2))
            continue

        overlap = score_data["overlap_count"]
        idx1_count = score_data["idx1_ngram_count"]
        idx2_count = score_data["idx2_ngram_count"]

        # Use the tracked ngram counts from score_data, with fallback to ngram_counts
        # if they weren't set (shouldn't happen, but defensive)
        text1_count = idx1_count if idx1_count > 0 else ngram_counts[idx1]
        text2_count = idx2_count if idx2_count > 0 else ngram_counts[idx2]

        min_required_overlap = max(
            1,
            int(threshold * similarity_filter_ratio * min(text1_count, text2_count)),
        )

        if overlap < min_required_overlap:
            continue

        max_possible_similarity = (
            overlap / (text1_count + text2_count - overlap)
            if (text1_count + text2_count - overlap) > 0
            else 0.0
        )

        if max_possible_similarity >= (threshold * similarity_filter_ratio):
            similarity = _calculate_text_similarity(
                memories[idx1].content, memories[idx2].content, ngram_size
            )
            if similarity >= threshold:
                result.append((idx1, idx2))

    return result


def _should_keep_new_memory(old: MemoryChunk, new: MemoryChunk) -> bool:
    """
    Determine which duplicate memory to keep based on scores.

    Keeps the memory with the higher similarity score. If scores are equal,
    keeps the newer one (later timestamp).

    Args:
        old: Existing memory chunk
        new: New memory chunk to compare

    Returns:
        True if new memory should be kept, False if old should be kept
    """
    old_score = old.similarity_score or 0.0
    new_score = new.similarity_score or 0.0

    if new_score > old_score:
        return True
    if new_score < old_score:
        return False

    return new.timestamp > old.timestamp
