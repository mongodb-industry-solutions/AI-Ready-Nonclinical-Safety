"""
CRUD and invariants for short-term memory.

Short-term memory (STM) stores individual conversation turns before they are
consolidated into snapshots. This module provides lightweight database operations
without API/service layer overhead.

All functions operate synchronously against MongoDB and expect the caller to
provide necessary context (org_id, user_id, etc.).
"""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime
from types import SimpleNamespace
from typing import Any, Dict, List, Optional, Sequence

from bson import ObjectId
from mongomem_core.common.utils import (
    handle_db_error,
    handle_duplicate_key_error,
    to_object_id,
    utcnow,
)
from mongomem_core.exceptions import DatabaseOperationError
from mongomem_core.memory.base import (
    BaseDocumentBuilder,
    BaseQueryBuilder,
    BaseUpdateFieldBuilder,
    doc_to_output,
    handle_empty_sequence,
)
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.short_term import (
    ShortTermDB,
    ShortTermIn,
    ShortTermOut,
)
from mongomem_core.storage import get_collection
from mongomem_core.storage.collections import (
    SessionCountersCollection,
    ShortTermMemoryCollection,
)
from pymongo.database import Database
from pymongo.errors import DuplicateKeyError
from pymongo.results import DeleteResult, InsertOneResult, UpdateResult

logger = logging.getLogger(__name__)


_STM_COL = ShortTermMemoryCollection()
_SESSION_COUNTERS_COL = SessionCountersCollection()


def generate_turn_seq(
    db: Database,
    session_id: str,
    org_id: str,
) -> int:
    """
    Generate a monotonically increasing turn sequence number for a session.

    Uses MongoDB's findAndModify to atomically increment a counter per session.
    This ensures ordering even with concurrent writes.

    Args:
        db: MongoDB database instance
        session_id: Session identifier
        org_id: Organization identifier

    Returns:
        The next turn sequence number for this session

    Raises:
        DatabaseOperationError: If the counter update fails.
    """
    counters_col = get_collection(_SESSION_COUNTERS_COL, db)

    with handle_db_error(
        operation="find_one_and_update",
        collection="session_counters",
        log_message="Failed to generate turn sequence for session=%s org=%s",
        log_args_tuple=(session_id, org_id),
    ):
        result = counters_col.find_one_and_update(
            {"session_id": session_id, "org_id": org_id},
            {"$inc": {"turn_seq": 1}},
            upsert=True,
            return_document=True,
        )
        if result is None:
            raise DatabaseOperationError(
                "Counter update returned no document despite upsert=True",
                operation="find_one_and_update",
                collection="session_counters",
                details={"session_id": session_id, "org_id": org_id},
            )
        turn_seq: int = result["turn_seq"]
        logger.debug(
            "Generated turn_seq=%d for session=%s org=%s",
            turn_seq,
            session_id,
            org_id,
        )
        return turn_seq


def _build_stm_doc(
    turn_in: ShortTermIn,
    org_id: str,
    user_id: str,
    turn_seq: int,
    timestamp: datetime,
    *,
    idempotency_hash: Optional[str] = None,
    embedding: Optional[List[float]] = None,
    embedding_model_id: Optional[str] = None,
) -> ShortTermDB:
    """Build a ShortTermDB document from input.

    Args:
        turn_in: Input model with message data
        org_id: Organization ID
        user_id: User ID of the message author
        turn_seq: Monotonic sequence number for this turn
        timestamp: Timestamp for the document
        idempotency_hash: Pre-computed idempotency hash (if any)
        embedding: Pre-computed embedding vector (if any)
        embedding_model_id: Model used to generate embedding

    Returns:
        A ShortTermDB document (not yet persisted)
    """
    return BaseDocumentBuilder.build_memory_document(
        turn_in,
        ShortTermDB,
        org_id,
        user_id,
        timestamp,
        embedding=embedding,
        embedding_model_id=embedding_model_id,
        idempotency_hash=idempotency_hash,
        embedding_config={
            "model_id_field": "embedding_model_id",
            "embedded_at_field": "embedded_at",
            "log_context": f"session={turn_in.session_id}",
        },
        turn_seq=turn_seq,
    )


def create_stm(
    db: Database,
    turn_in: ShortTermIn,
    org_id: str,
    user_id: str,
    *,
    idempotency_key: Optional[str] = None,
    embedding: Optional[List[float]] = None,
    embedding_model_id: Optional[str] = None,
) -> ShortTermDB:
    """
    Create a short-term memory document.

    Args:
        db: MongoDB database instance
        turn_in: Input model with message data
        org_id: Organization ID
        user_id: User ID of the message author
        idempotency_key: Optional key for idempotency checks
        embedding: Pre-computed embedding vector (if any)
        embedding_model_id: Model used to generate embedding

    Returns:
        The created ShortTermDB document

    Raises:
        DuplicateDocumentError: If idempotency check fails (duplicate key).
        DatabaseOperationError: If the insert operation fails.

    Example:
        >>> from mongomem_core.storage import get_database
        >>> from mongomem_core.models.memory.short_term import ShortTermIn
        >>> db = get_database()
        >>> turn = ShortTermIn(
        ...     session_id="sess_123",
        ...     role="user",
        ...     content="Hello, how are you?"
        ... )
        >>> doc = create_stm(db, turn, org_id="org_1", user_id="user_1")
    """
    logger.debug(
        "Creating STM document: session=%s role=%s org=%s user=%s",
        turn_in.session_id,
        turn_in.role,
        org_id,
        user_id,
    )

    turn_seq = generate_turn_seq(db, turn_in.session_id, org_id)
    now = utcnow()

    idempotency_hash = None
    if idempotency_key:
        idempotency_hash = hashlib.sha256(
            f"{turn_in.session_id}:{org_id}:{idempotency_key}".encode()
        ).hexdigest()
        logger.debug("Generated idempotency hash for key=%s", idempotency_key)

    doc = _build_stm_doc(
        turn_in,
        org_id,
        user_id,
        turn_seq,
        now,
        idempotency_hash=idempotency_hash,
        embedding=embedding,
        embedding_model_id=embedding_model_id,
    )

    col = get_collection(_STM_COL, db)
    try:
        with handle_db_error(
            operation="insert_one",
            collection=_STM_COL.name,
            log_message="Failed to create STM document: session=%s org=%s",
            log_args_tuple=(turn_in.session_id, org_id),
        ):
            result: InsertOneResult = col.insert_one(doc.model_dump(by_alias=True))
            doc.id = result.inserted_id
            logger.debug(
                "Created STM document: id=%s session=%s turn_seq=%d",
                result.inserted_id,
                turn_in.session_id,
                turn_seq,
            )
            return doc
    except DuplicateKeyError as exc:
        handle_duplicate_key_error(
            exc,
            collection_name=_STM_COL.name,
            log_message="Duplicate STM document detected: session=%s idempotency_key=%s",
            log_args=(turn_in.session_id, idempotency_key),
            details={
                "session_id": turn_in.session_id,
                "idempotency_key": idempotency_key,
            },
        )


def get_stm_by_id(
    db: Database,
    stm_id: str | ObjectId,
    org_id: str,
) -> Optional[ShortTermOut]:
    """
    Fetch a single STM document by ID.

    Args:
        db: MongoDB database instance
        stm_id: Document ID (string or ObjectId)
        org_id: Organization ID (for access control)

    Returns:
        ShortTermOut if found, None otherwise.

    Raises:
        ValidationError: If stm_id is not a valid ObjectId format.
        DatabaseOperationError: If the query fails.
    """
    col = get_collection(_STM_COL, db)
    oid = to_object_id(stm_id)

    with handle_db_error(
        operation="find_one",
        collection=_STM_COL.name,
        log_message="Failed to retrieve STM document: id=%s org=%s",
        log_args_tuple=(str(stm_id), org_id),
    ):
        doc = col.find_one({"_id": oid, "org_id": org_id})
        if not doc:
            logger.debug("STM document not found: id=%s org=%s", stm_id, org_id)
            return None

        doc["_id"] = str(doc["_id"])
        logger.debug("Retrieved STM document: id=%s", stm_id)
        return ShortTermOut.model_validate(doc)


def get_stm_by_session(
    db: Database,
    session_id: str,
    org_id: str,
    *,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    agent_id: Optional[str] = None,
    exclude_agent_ids: Optional[List[str]] = None,
    sort_ascending: bool = True,
) -> List[ShortTermOut]:
    """
    Fetch all STM documents for a session.

    Args:
        db: MongoDB database instance
        session_id: Session identifier
        org_id: Organization ID
        user_id: Optional filter by user ID
        visibility: Optional filter by visibility scope
        project_id: Optional filter by group ID (for shared visibility)
        agent_id: Optional filter to a specific agent's turns only
        exclude_agent_ids: Optional list of agent IDs to exclude from results
        sort_ascending: If True, sort by timestamp ascending (oldest first)

    Returns:
        List of ShortTermOut documents, sorted by timestamp

    Raises:
        DatabaseOperationError: If the query fails.
    """
    col = get_collection(_STM_COL, db)
    q_filter = BaseQueryBuilder.build_base_filter(
        org_id,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        session_id=session_id,
    )

    # Agent filtering for multi-agent group chat scenarios
    if agent_id is not None:
        q_filter["agent_id"] = agent_id
    if exclude_agent_ids:
        q_filter["agent_id"] = {"$nin": exclude_agent_ids}

    sort_direction = 1 if sort_ascending else -1

    with handle_db_error(
        operation="find",
        collection=_STM_COL.name,
        log_message="Failed to retrieve STM documents for session=%s org=%s",
        log_args_tuple=(session_id, org_id),
    ):
        # Prefer deterministic ordering by turn sequence within a session.
        # Timestamps can collide at high write rates and cause unstable ordering.
        cursor = col.find(q_filter).sort("turn_seq", sort_direction)
        results = [doc_to_output(d, ShortTermOut) for d in cursor]
        logger.debug(
            "Retrieved %d STM documents for session=%s org=%s agent_filter=%s",
            len(results),
            session_id,
            org_id,
            agent_id or exclude_agent_ids or "none",
        )
        return results


def get_recent_stm(
    db: Database,
    session_id: str,
    org_id: str,
    *,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    agent_id: Optional[str] = None,
    exclude_agent_ids: Optional[List[str]] = None,
    before: Optional[datetime] = None,
    limit: int = 10,
    exclude_promoted: bool = False,
) -> List[ShortTermOut]:
    """
    Fetch recent STM documents for a session with pagination.

    Returns documents in chronological order (oldest first in the returned list),
    but fetches the most recent `limit` documents before the `before` timestamp.

    Args:
        db: MongoDB database instance
        session_id: Session identifier
        org_id: Organization ID
        user_id: Optional filter by user ID
        visibility: Optional filter by visibility scope
        project_id: Optional filter by group ID
        agent_id: Optional filter to a specific agent's turns only
        exclude_agent_ids: Optional list of agent IDs to exclude from results
        before: Optional cursor - fetch documents before this timestamp
        limit: Maximum number of documents to return.
        exclude_promoted: If True, exclude documents that have been promoted to snapshot

    Returns:
        List of ShortTermOut documents in chronological order.

    Raises:
        DatabaseOperationError: If the query fails.
    """
    col = get_collection(_STM_COL, db)
    q_filter = BaseQueryBuilder.build_base_filter(
        org_id,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        session_id=session_id,
    )

    # Agent filtering for multi-agent group chat scenarios
    if agent_id is not None:
        q_filter["agent_id"] = agent_id
    if exclude_agent_ids:
        q_filter["agent_id"] = {"$nin": exclude_agent_ids}

    BaseQueryBuilder.add_timestamp_filters(q_filter, before=before, timestamp_field="timestamp")

    if exclude_promoted:
        q_filter["promoted"] = {"$ne": True}

    with handle_db_error(
        operation="find",
        collection=_STM_COL.name,
        log_message="Failed to retrieve recent STM documents for session=%s org=%s",
        log_args_tuple=(session_id, org_id),
    ):
        # Deterministic: sort by timestamp and then _id to break ties without requiring
        # an extra compound index (timestamp collisions are possible under high write rate).
        cursor = col.find(q_filter).sort([("timestamp", -1), ("_id", -1)]).limit(limit)
        turns = [doc_to_output(d, ShortTermOut) for d in cursor]
        logger.debug(
            "Retrieved %d recent STM documents for session=%s org=%s agent_filter=%s",
            len(turns),
            session_id,
            org_id,
            agent_id or exclude_agent_ids or "none",
        )
        return list(reversed(turns))


def get_stm_raw_docs(
    db: Database,
    session_id: str,
    org_id: str,
    *,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    agent_id: Optional[str] = None,
    exclude_agent_ids: Optional[List[str]] = None,
    exclude_promoted: bool = False,
) -> List[Dict[str, Any]]:
    """
    Fetch raw STM documents (as dicts) for a session.

    Useful when you need the raw MongoDB documents for further processing
    (e.g., bulk promotion to snapshots).

    Args:
        db: MongoDB database instance
        session_id: Session identifier
        org_id: Organization ID
        user_id: Optional filter by user ID
        visibility: Optional filter by visibility scope
        project_id: Optional filter by group ID
        agent_id: Optional filter to a specific agent's turns only
        exclude_agent_ids: Optional list of agent IDs to exclude from results

    Returns:
        List of raw document dicts

    Raises:
        DatabaseOperationError: If the query fails.
    """
    col = get_collection(_STM_COL, db)
    q_filter = BaseQueryBuilder.build_base_filter(
        org_id,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        session_id=session_id,  # STM-specific: always required
    )

    # Agent filtering for multi-agent group chat scenarios
    if agent_id is not None:
        q_filter["agent_id"] = agent_id
    if exclude_agent_ids:
        q_filter["agent_id"] = {"$nin": exclude_agent_ids}
    if exclude_promoted:
        q_filter["promoted"] = {"$ne": True}

    with handle_db_error(
        operation="find",
        collection=_STM_COL.name,
        log_message="Failed to retrieve raw STM documents for session=%s org=%s",
        log_args_tuple=(session_id, org_id),
    ):
        results = list(col.find(q_filter).sort("timestamp", 1))
        logger.debug(
            "Retrieved %d raw STM documents for session=%s org=%s agent_filter=%s",
            len(results),
            session_id,
            org_id,
            agent_id or exclude_agent_ids or "none",
        )
        return results


def mark_stm_promoted(
    db: Database,
    stm_ids: Sequence[str | ObjectId],
    org_id: str,
) -> UpdateResult:
    """
    Mark STM documents as promoted to snapshot.

    Args:
        db: MongoDB database instance
        stm_ids: List of document IDs to mark as promoted
        org_id: Organization ID (for access control)

    Returns:
        UpdateResult from MongoDB. If an empty sequence is provided, returns a
        result with modified_count=0 (idempotent operation - no database call is made).

    Raises:
        ValidationError: If any stm_id is not a valid ObjectId format.
        DatabaseOperationError: If the update operation fails.

    Note:
        Empty sequences are handled idempotently: the function returns immediately
        with an UpdateResult indicating 0 modifications, matching MongoDB's behavior
        for update_many operations with empty $in arrays.
    """
    early_return = handle_empty_sequence(stm_ids, "mark_stm_promoted", UpdateResult)
    if early_return is not None:
        return early_return  # type: ignore[return-value]

    col = get_collection(_STM_COL, db)
    oids = [to_object_id(sid) for sid in stm_ids]

    with handle_db_error(
        operation="update_many",
        collection=_STM_COL.name,
        log_message="Failed to mark STM documents as promoted: count=%d org=%s",
        log_args_tuple=(len(stm_ids), org_id),
    ):
        result = col.update_many(
            {"_id": {"$in": oids}, "org_id": org_id},
            {"$set": {"promoted": True}},
        )
        logger.info(
            "Marked %d STM documents as promoted (requested=%d, org=%s)",
            result.modified_count,
            len(stm_ids),
            org_id,
        )
        return result


def update_stm_embedding(
    db: Database,
    stm_id: str | ObjectId,
    org_id: str,
    embedding: List[float],
    embedding_model_id: Optional[str] = None,
) -> UpdateResult:
    """
    Update the embedding on an existing STM document.

    Args:
        db: MongoDB database instance
        stm_id: Document ID
        org_id: Organization ID
        embedding: The embedding vector
        embedding_model_id: Optional model identifier

    Returns:
        UpdateResult from MongoDB

    Raises:
        ValidationError: If stm_id is not a valid ObjectId format.
        DatabaseOperationError: If the update operation fails.
    """
    col = get_collection(_STM_COL, db)
    oid = to_object_id(stm_id)

    embedding_update = SimpleNamespace(embedding=embedding)
    update_fields = BaseUpdateFieldBuilder.build_embedding_update_fields(embedding_update)

    update_fields["embedded_at"] = utcnow()
    if embedding_model_id:
        update_fields["embedding_model_id"] = embedding_model_id

    with handle_db_error(
        operation="update_one",
        collection=_STM_COL.name,
        log_message="Failed to update embedding for STM document: id=%s org=%s",
        log_args_tuple=(str(stm_id), org_id),
    ):
        result = col.update_one(
            {"_id": oid, "org_id": org_id},
            {"$set": update_fields},
        )
        if result.modified_count > 0:
            logger.debug(
                "Updated embedding for STM document: id=%s model=%s",
                stm_id,
                embedding_model_id,
            )
        else:
            logger.warning(
                "No STM document modified for embedding update: id=%s org=%s",
                stm_id,
                org_id,
            )
        return result


def mark_stm_promotion_failed(
    db: Database,
    id_to_error: Dict[str | ObjectId, str],
    org_id: str,
) -> int:
    """
    Mark STM documents as promoted but with a per-doc promotion_error field.

    Uses bulkWrite so each document gets its own error string in a single
    round-trip, avoiding the cross-contamination that would occur with a
    single update_many sharing one error string across docs with different
    failures.

    Args:
        db: MongoDB database instance
        id_to_error: Mapping of STM document ID → validation error string
        org_id: Organization ID (for access control)

    Returns:
        Number of documents modified.
    """
    from pymongo import UpdateOne

    if not id_to_error:
        return 0

    col = get_collection(_STM_COL, db)

    _MAX_ERROR_LEN = 1000
    ops = [
        UpdateOne(
            {"_id": to_object_id(doc_id), "org_id": org_id},
            {"$set": {"promoted": True, "promotion_error": error[:_MAX_ERROR_LEN]}},
        )
        for doc_id, error in id_to_error.items()
    ]

    with handle_db_error(
        operation="bulk_write",
        collection=_STM_COL.name,
        log_message="Failed to mark STM documents as promotion-failed: count=%d org=%s",
        log_args_tuple=(len(ops), org_id),
    ):
        result = col.bulk_write(ops, ordered=False)
        modified = result.modified_count
        logger.warning(
            "Marked %d STM documents as promotion-failed (requested=%d, org=%s)",
            modified,
            len(ops),
            org_id,
        )
        return modified


def delete_stm_by_ids(
    db: Database,
    stm_ids: Sequence[str | ObjectId],
    org_id: str,
) -> DeleteResult:
    """
    Delete specific STM documents by ID.

    Args:
        db: MongoDB database instance
        stm_ids: List of document IDs to delete
        org_id: Organization ID (for access control)

    Returns:
        DeleteResult from MongoDB. If an empty sequence is provided, returns a
        result with deleted_count=0 (idempotent operation - no database call is made).

    Raises:
        ValidationError: If any stm_id is not a valid ObjectId format.
        DatabaseOperationError: If the delete operation fails.

    Note:
        Empty sequences are handled idempotently: the function returns immediately
        with a DeleteResult indicating 0 deletions, matching MongoDB's behavior
        for delete_many operations with empty $in arrays.
    """
    early_return = handle_empty_sequence(stm_ids, "delete_stm_by_ids", DeleteResult)
    if early_return is not None:
        return early_return  # type: ignore[return-value]

    col = get_collection(_STM_COL, db)
    oids = [to_object_id(sid) for sid in stm_ids]

    with handle_db_error(
        operation="delete_many",
        collection=_STM_COL.name,
        log_message="Failed to delete STM documents: count=%d org=%s",
        log_args_tuple=(len(stm_ids), org_id),
    ):
        result = col.delete_many({"_id": {"$in": oids}, "org_id": org_id})
        logger.info(
            "Deleted %d STM documents (requested=%d, org=%s)",
            result.deleted_count,
            len(stm_ids),
            org_id,
        )
        return result


def delete_session_stm(
    db: Database,
    session_id: str,
    org_id: str,
    *,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
) -> DeleteResult:
    """
    Delete all STM documents for a session.

    Args:
        db: MongoDB database instance
        session_id: Session identifier
        org_id: Organization ID
        user_id: Optional filter by user ID
        visibility: Optional filter by visibility

    Returns:
        DeleteResult from MongoDB

    Raises:
        DatabaseOperationError: If the delete operation fails.
    """
    col = get_collection(_STM_COL, db)
    q_filter = BaseQueryBuilder.build_base_filter(
        org_id,
        user_id=user_id,
        visibility=visibility,
        session_id=session_id,  # STM-specific: always required
    )

    with handle_db_error(
        operation="delete_many",
        collection=_STM_COL.name,
        log_message="Failed to delete STM documents for session=%s org=%s",
        log_args_tuple=(session_id, org_id),
    ):
        result = col.delete_many(q_filter)
        logger.info(
            "Deleted %d STM documents for session=%s org=%s",
            result.deleted_count,
            session_id,
            org_id,
        )
        return result
