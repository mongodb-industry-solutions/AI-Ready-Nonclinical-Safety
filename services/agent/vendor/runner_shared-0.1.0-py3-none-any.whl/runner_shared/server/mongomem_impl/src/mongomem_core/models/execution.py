"""
Execution result model for procedural memory code execution.

Used as the return type for ExecutorProtocol.execute(). This is a pure
data contract -- mongomem stores these for feedback loops but does not
manage execution state or orchestration.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ExecutionResult:
    """Result of executing code in a sandbox via ExecutorProtocol."""

    success: bool
    stdout: str
    stderr: str
    exit_code: int
    duration_ms: int
    language: str
    executor_id: str


__all__ = ["ExecutionResult"]
