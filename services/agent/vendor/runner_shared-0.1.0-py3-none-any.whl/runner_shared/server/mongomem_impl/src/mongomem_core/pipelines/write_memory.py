"""Orchestrated writes across memory types and TKG."""
