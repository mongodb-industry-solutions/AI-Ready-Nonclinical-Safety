"""
Base class and protocol for task handlers.

Custom tasks can inherit from TaskHandler to integrate with the worker.

Example:
    class MyCustomHandler(TaskHandler):
        task_type = "my_custom_task"
        timeout_seconds = 300

        def __init__(self, db, my_param):
            self._db = db
            self._my_param = my_param

        async def handle_task(self, payload: Dict[str, Any]) -> None:
            # Process the task
            doc_id = payload.get("doc_id")
            await self._do_work(doc_id)

    # Register with worker
    worker.register_task(MyCustomHandler(db=engine.db, my_param="value"))
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict


class TaskHandler(ABC):
    """
    Abstract base class for task handlers.

    Subclass this to create custom tasks that integrate with MongoMemWorker.

    Required:
        task_type: Unique identifier for this task type
        handle_task: Async method to process a single task

    Optional:
        timeout_seconds: Task timeout (default: 300)
        process_pending: For polling mode - process pending work
        shutdown: Cleanup resources
    """

    # Override these in subclasses
    task_type: str = ""
    timeout_seconds: int = 300

    @abstractmethod
    async def handle_task(self, payload: Dict[str, Any]) -> None:
        """
        Process a single task.

        Args:
            payload: Task payload dict (contents depend on task type)
        """
        ...

    async def process_pending(self) -> int:
        """
        Process pending work (for polling mode).

        Override this if your handler supports batch processing
        of pending items without explicit task payloads.

        Returns:
            Number of items processed
        """
        return 0

    def shutdown(self) -> None:
        """
        Cleanup resources (thread pools, connections, etc.).

        Override if your handler needs cleanup on worker shutdown.
        """
        pass


__all__ = ["TaskHandler"]
