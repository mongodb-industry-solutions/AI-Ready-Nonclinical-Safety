"""
Learning extraction handlers for semantic, episodic, taxonomic, and preferences memory.

Provides specialized handlers for each extraction type, all inheriting from
a common base class with shared functionality.
"""

from __future__ import annotations

import asyncio
import logging
from abc import abstractmethod
from functools import partial
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

from pymongo.database import Database

from ...mongomem_core.extraction import DEFAULT_EXTRACTION_PROMPTS, ExtractionType
from ...mongomem_core.extraction.episodic import EpisodicPipeline, create_episodic_pipeline
from ...mongomem_core.extraction.preferences import (
    PreferencesPipeline,
    create_preferences_pipeline,
)
from ...mongomem_core.extraction.procedural import ProceduralPipeline, create_procedural_pipeline
from ...mongomem_core.extraction.semantic import SemanticPipeline, create_semantic_pipeline
from ...mongomem_core.extraction.taxonomic import TaxonomicPipeline, create_taxonomic_pipeline
from ...mongomem_core.extraction.types import ApprovalMode
from ...mongomem_core.models.memory.base import ChunkVisibility
from ..circuit_breaker import get_circuit_breaker
from ..constants import CIRCUIT_BREAKER_LLM
from ..storage.extraction_config import ExtractionConfigStore
from .base import TaskHandler

if TYPE_CHECKING:
    from ...mongomem_core.protocols import EmbedderProtocol, LLMProtocol

logger = logging.getLogger(__name__)


# =============================================================================
# Base Learning Handler
# =============================================================================


class BaseLearningHandler(TaskHandler):
    """
    Base class for learning extraction handlers.

    Provides shared functionality for prompt resolution, LLM calls,
    and database storage patterns.

    Subclasses must define:
        - task_type: Class-level extraction type identifier
        - _extraction_type: The ExtractionType value

    Subclasses should override:
        - handle_task: Main task processing logic
    """

    # Default timeout for LLM-based extractions
    timeout_seconds = 600

    # Subclasses must override this
    _extraction_type: ExtractionType

    def __init__(
        self,
        db: Database,
        llm: Optional["LLMProtocol"],
        *,
        prompt: Optional[str] = None,
        use_db_prompts: bool = False,
        embedder: Optional["EmbedderProtocol"] = None,
    ) -> None:
        """
        Initialize base learning handler.

        Args:
            db: MongoDB database instance
            llm: LLM protocol implementation for extraction
            prompt: Optional custom prompt (overrides default)
            use_db_prompts: If True, fetch prompts from DB (enables hot-reload)
            embedder: Optional embedder for handlers that need it
        """
        self._db = db
        self._llm = llm
        self._prompt = prompt or DEFAULT_EXTRACTION_PROMPTS.get(self._extraction_type, "")
        self._use_db_prompts = use_db_prompts
        self._config_store: Optional[ExtractionConfigStore] = (
            ExtractionConfigStore(db) if use_db_prompts else None
        )
        self._embedder = embedder

    def _get_prompt(
        self,
        org_id: Optional[str] = None,
        project_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> str:
        """
        Get prompt with hierarchical resolution.

        Resolution order (if use_db_prompts enabled):
        1. User-specific (org_id + project_id + user_id)
        2. Group-specific (org_id + project_id)
        3. Org-specific (org_id)
        4. System default
        5. Static prompt (final fallback)
        """
        if not self._use_db_prompts or not self._config_store:
            return self._prompt

        # Use hierarchical ExtractionConfigStore
        db_prompt = self._config_store.get_active(
            org_id=org_id,
            extraction_type=self._extraction_type,
            project_id=project_id,
            user_id=user_id,
        )

        # Final fallback to static prompt if nothing in DB
        return db_prompt or self._prompt

    def _make_prompt_resolver(
        self,
        extraction_type: str,
    ) -> Optional[Callable[[], Optional[str]]]:
        """
        Create a prompt resolver function for hot-reload support in pipelines.

        If use_db_prompts is enabled, returns a callable that fetches the active
        prompt from the ExtractionConfigStore. Otherwise returns None (use defaults).

        This enables DB-stored prompts to be hot-swapped without restarting the worker.

        Args:
            extraction_type: The extraction type ("semantic", "episodic", "taxonomic")

        Returns:
            Callable that returns Optional[str], or None if DB prompts disabled
        """
        if not self._use_db_prompts or not self._config_store:
            return None

        config_store = self._config_store

        def resolver() -> Optional[str]:
            # Note: org_id/user_id context not available here - uses system/org default
            # For per-user prompts, the handler's _get_prompt() method should be used
            return config_store.get_active(
                org_id=None,  # System default for pipeline
                extraction_type=extraction_type,  # type: ignore[arg-type]
            )

        return resolver

    async def _extract_with_llm(
        self,
        content: str,
        org_id: Optional[str] = None,
        project_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Extract information using LLM with circuit breaker protection.

        Args:
            content: Content to extract from
            org_id: Organization ID for prompt resolution
            project_id: Project ID for prompt resolution
            user_id: User ID for prompt resolution

        Returns:
            Extracted data as dictionary
        """
        if self._llm is None:
            return {}

        breaker = get_circuit_breaker(CIRCUIT_BREAKER_LLM)
        prompt_template = self._get_prompt(org_id, project_id, user_id)
        prompt = prompt_template.format(content=content)
        loop = asyncio.get_running_loop()

        # Circuit breaker protects LLM service calls
        result = await breaker.call_async(
            loop.run_in_executor,
            None,
            partial(self._llm.complete_json, prompt=prompt, schema={}),
        )
        return result if isinstance(result, dict) else {}

    @abstractmethod
    async def handle_task(self, payload: Dict[str, Any]) -> None:
        """Process an extraction task. Must be implemented by subclasses."""
        ...


# =============================================================================
# Semantic Handler
# =============================================================================


class SemanticHandler(BaseLearningHandler):
    """
    Handler for semantic memory extraction.

    Extracts factual knowledge about users from conversations using
    the full SemanticPipeline with consolidation (ADD/UPDATE/REINFORCE).

    Requires both LLM and embedder for the consolidation flow.
    """

    task_type = "semantic"
    _extraction_type: ExtractionType = "semantic"

    def __init__(
        self,
        db: Database,
        llm: Optional["LLMProtocol"],
        embedder: Optional["EmbedderProtocol"],
        *,
        prompt: Optional[str] = None,
        use_db_prompts: bool = False,
    ) -> None:
        """
        Initialize semantic handler.

        Args:
            db: MongoDB database instance
            llm: LLM protocol implementation for extraction
            embedder: Embedder for similarity search (required for consolidation)
            prompt: Optional custom prompt (overrides default)
            use_db_prompts: If True, fetch prompts from DB (enables hot-reload)
        """
        super().__init__(
            db=db,
            llm=llm,
            prompt=prompt,
            use_db_prompts=use_db_prompts,
            embedder=embedder,
        )

        # Pre-create semantic pipeline if dependencies available
        self._semantic_pipeline: Optional[SemanticPipeline] = None
        if llm and embedder:
            self._semantic_pipeline = create_semantic_pipeline(
                db=db,
                llm=llm,
                embedder=embedder,
                extraction_prompt_resolver=self._make_prompt_resolver("semantic"),
            )

    async def handle_task(self, payload: Dict[str, Any]) -> None:
        """
        Process a semantic extraction task.

        Expected payload:
            - messages: List of conversation messages
            - org_id: Organization ID
            - user_id: User ID
            - source_id: Source reference (e.g., snapshot ID)
            - project_id: (Optional) Project ID for prompt resolution
        """
        if self._llm is None:
            logger.warning("LLM not configured for semantic extraction")
            return

        org_id = payload.get("org_id")
        user_id = payload.get("user_id")
        project_id = payload.get("project_id")
        source_id = payload.get("source_id")
        messages = payload.get("messages")

        if self._embedder is None:
            raise ValueError(
                "Semantic extraction requires an embedder. "
                "Pass embedder to MongoMemWorker or use WorkerConfig.auto_extraction()."
            )

        if not messages or not org_id or not user_id or not source_id:
            raise ValueError(
                "Missing required fields in semantic extraction task. "
                f"Required: messages, org_id, user_id, source_id. "
                f"Got: messages={bool(messages)}, org_id={org_id}, "
                f"user_id={user_id}, source_id={source_id}"
            )

        # Get approval mode and visibility from payload
        approval_mode: ApprovalMode = payload.get("approval_mode", "auto")
        visibility_str = payload.get("visibility", "private")
        visibility = ChunkVisibility(visibility_str) if visibility_str else ChunkVisibility.PRIVATE

        try:
            await self._run_semantic_pipeline(
                messages=messages,
                org_id=org_id,
                user_id=user_id,
                project_id=project_id,
                source_id=source_id,
                approval_mode=approval_mode,
                visibility=visibility,
            )
        except Exception as exc:
            from ...mongomem_core.common import ExtractionError

            raise ExtractionError(
                f"Semantic extraction failed for source {source_id}",
                extraction_type="semantic",
                source_id=source_id,
                original_error=exc,
            ) from exc

    async def _run_semantic_pipeline(
        self,
        messages: List[Dict[str, Any]],
        org_id: str,
        user_id: str,
        source_id: str,
        project_id: Optional[str] = None,
        approval_mode: ApprovalMode = "auto",
        visibility: ChunkVisibility = ChunkVisibility.PRIVATE,
    ) -> None:
        """Run the full semantic extraction pipeline on messages."""
        if not self._semantic_pipeline:
            # Create pipeline on-demand if not pre-created
            if not self._llm or not self._embedder:
                raise ValueError("Semantic pipeline requires LLM and embedder")
            self._semantic_pipeline = create_semantic_pipeline(
                db=self._db,
                llm=self._llm,
                embedder=self._embedder,
                extraction_prompt_resolver=self._make_prompt_resolver("semantic"),
            )

        loop = asyncio.get_running_loop()

        # Run the sync pipeline in an executor
        result = await loop.run_in_executor(
            None,
            partial(
                self._semantic_pipeline.run,
                messages=messages,
                org_id=org_id,
                user_id=user_id,
                source_id=source_id,
                approval_mode=approval_mode,
                visibility=visibility,
                project_id=project_id,
            ),
        )

        stats = result.consolidation_stats
        if result.approval_mode == "manual":
            logger.info(
                "Semantic pipeline staged for source=%s org=%s user=%s: "
                "extracted=%d, pending_ids=%d",
                source_id,
                org_id,
                user_id,
                result.extracted_count,
                len(result.pending_ids),
            )
        else:
            logger.info(
                "Semantic pipeline completed for source=%s org=%s user=%s: "
                "extracted=%d, added=%d, updated=%d, reinforced=%d, duplicates=%d",
                source_id,
                org_id,
                user_id,
                result.extracted_count,
                stats.add_count,
                stats.update_count,
                stats.reinforce_count,
                stats.duplicate_count,
            )


# =============================================================================
# Episodic Handler
# =============================================================================


class EpisodicHandler(BaseLearningHandler):
    """
    Handler for episodic memory extraction.

    Extracts events, actions, and experiences from conversations using
    the full EpisodicPipeline with consolidation (ADD/UPDATE/REINFORCE).

    Requires both LLM and embedder for the consolidation flow.
    """

    task_type = "episodic"
    _extraction_type: ExtractionType = "episodic"

    def __init__(
        self,
        db: Database,
        llm: Optional["LLMProtocol"],
        embedder: Optional["EmbedderProtocol"],
        *,
        prompt: Optional[str] = None,
        use_db_prompts: bool = False,
    ) -> None:
        """
        Initialize episodic handler.

        Args:
            db: MongoDB database instance
            llm: LLM protocol implementation for extraction
            embedder: Embedder for similarity search (required for consolidation)
            prompt: Optional custom prompt (overrides default)
            use_db_prompts: If True, fetch prompts from DB (enables hot-reload)
        """
        super().__init__(
            db=db,
            llm=llm,
            prompt=prompt,
            use_db_prompts=use_db_prompts,
            embedder=embedder,
        )

        # Pre-create episodic pipeline if dependencies available
        self._episodic_pipeline: Optional[EpisodicPipeline] = None
        if llm and embedder:
            self._episodic_pipeline = create_episodic_pipeline(
                db=db,
                llm=llm,
                embedder=embedder,
                extraction_prompt_resolver=self._make_prompt_resolver("episodic"),
            )

    async def handle_task(self, payload: Dict[str, Any]) -> None:
        """
        Process an episodic extraction task.

        Expected payload:
            - messages: List of conversation messages (preferred)
            - content: Text content to extract from (legacy, backward-compat)
            - org_id: Organization ID
            - user_id: User ID
            - source_id: Source reference (e.g., snapshot ID)
            - project_id: (Optional) Project ID for prompt resolution
        """
        if self._llm is None:
            logger.warning("LLM not configured for episodic extraction")
            return

        org_id = payload.get("org_id")
        user_id = payload.get("user_id")
        project_id = payload.get("project_id")
        source_id = payload.get("source_id")

        # Support both messages (new) and content (legacy) formats
        messages = payload.get("messages")
        content = payload.get("content")

        if self._embedder is None:
            raise ValueError(
                "Episodic extraction requires an embedder. "
                "Pass embedder to MongoMemWorker or use WorkerConfig.auto_extraction()."
            )

        # Validate required fields
        if not org_id or not user_id or not source_id:
            raise ValueError(
                "Missing required fields in episodic extraction task. "
                f"Required: org_id, user_id, source_id. "
                f"Got: org_id={org_id}, user_id={user_id}, source_id={source_id}"
            )

        # Handle messages vs content (backward compatibility)
        if not messages:
            if content:
                # Legacy format: convert content to single message
                messages = [{"role": "user", "content": content}]
            else:
                raise ValueError(
                    "Missing required field: 'messages' or 'content'. "
                    "Provide either a list of messages or text content."
                )

        # Get approval mode and visibility from payload
        approval_mode: ApprovalMode = payload.get("approval_mode", "auto")
        visibility_str = payload.get("visibility", "private")
        visibility = ChunkVisibility(visibility_str) if visibility_str else ChunkVisibility.PRIVATE

        try:
            await self._run_episodic_pipeline(
                messages=messages,
                org_id=org_id,
                user_id=user_id,
                project_id=project_id,
                source_id=source_id,
                approval_mode=approval_mode,
                visibility=visibility,
            )
        except Exception as exc:
            from ...mongomem_core.common import ExtractionError

            raise ExtractionError(
                f"Episodic extraction failed for source {source_id}",
                extraction_type="episodic",
                source_id=source_id,
                original_error=exc,
            ) from exc

    async def _run_episodic_pipeline(
        self,
        messages: List[Dict[str, Any]],
        org_id: str,
        user_id: str,
        source_id: str,
        project_id: Optional[str] = None,
        approval_mode: ApprovalMode = "auto",
        visibility: ChunkVisibility = ChunkVisibility.PRIVATE,
    ) -> None:
        """Run the full episodic extraction pipeline on messages."""
        if not self._episodic_pipeline:
            # Create pipeline on-demand if not pre-created
            if not self._llm or not self._embedder:
                raise ValueError("Episodic pipeline requires LLM and embedder")
            self._episodic_pipeline = create_episodic_pipeline(
                db=self._db,
                llm=self._llm,
                embedder=self._embedder,
                extraction_prompt_resolver=self._make_prompt_resolver("episodic"),
            )

        loop = asyncio.get_running_loop()

        # Run the sync pipeline in an executor
        result = await loop.run_in_executor(
            None,
            partial(
                self._episodic_pipeline.run,
                messages=messages,
                org_id=org_id,
                user_id=user_id,
                source_id=source_id,
                approval_mode=approval_mode,
                visibility=visibility,
                project_id=project_id,
            ),
        )

        stats = result.consolidation_stats
        if result.approval_mode == "manual":
            logger.info(
                "Episodic pipeline staged for source=%s org=%s user=%s: "
                "extracted=%d, pending_ids=%d",
                source_id,
                org_id,
                user_id,
                result.extracted_count,
                len(result.pending_ids),
            )
        else:
            logger.info(
                "Episodic pipeline completed for source=%s org=%s user=%s: "
                "extracted=%d, added=%d, updated=%d, reinforced=%d, duplicates=%d",
                source_id,
                org_id,
                user_id,
                result.extracted_count,
                stats.add_count,
                stats.update_count,
                stats.reinforce_count,
                stats.duplicate_count,
            )


# =============================================================================
# Taxonomic Handler
# =============================================================================


class TaxonomicHandler(BaseLearningHandler):
    """
    Handler for taxonomic memory extraction.

    Extracts domain-specific terms and definitions from conversations using
    the full TaxonomicPipeline with consolidation (ADD/UPDATE/REINFORCE).

    Requires both LLM and embedder for the consolidation flow.

    Note: Unlike semantic/episodic, taxonomic extraction uses domain+term as
    the natural dedup key. REINFORCE operations merge additional evidence
    spans and related terms into existing terms rather than incrementing counts.
    """

    task_type = "taxonomic"
    _extraction_type: ExtractionType = "taxonomic"

    def __init__(
        self,
        db: Database,
        llm: Optional["LLMProtocol"],
        embedder: Optional["EmbedderProtocol"],
        *,
        prompt: Optional[str] = None,
        use_db_prompts: bool = False,
    ) -> None:
        """
        Initialize taxonomic handler.

        Args:
            db: MongoDB database instance
            llm: LLM protocol implementation for extraction
            embedder: Embedder for similarity search (required for consolidation)
            prompt: Optional custom prompt (overrides default)
            use_db_prompts: If True, fetch prompts from DB (enables hot-reload)
        """
        super().__init__(
            db=db,
            llm=llm,
            prompt=prompt,
            use_db_prompts=use_db_prompts,
            embedder=embedder,
        )

        # Pre-create taxonomic pipeline if dependencies available
        self._taxonomic_pipeline: Optional[TaxonomicPipeline] = None
        if llm and embedder:
            self._taxonomic_pipeline = create_taxonomic_pipeline(
                db=db,
                llm=llm,
                embedder=embedder,
                extraction_prompt_resolver=self._make_prompt_resolver("taxonomic"),
            )

    async def handle_task(self, payload: Dict[str, Any]) -> None:
        """
        Process a taxonomic extraction task.

        Expected payload:
            - messages: List of conversation messages (preferred)
            - content: Text content to extract from (legacy, backward-compat)
            - org_id: Organization ID
            - user_id: User ID
            - source_id: Source reference (e.g., snapshot ID)
            - project_id: (Optional) Project ID for prompt resolution
        """
        if self._llm is None:
            logger.warning("LLM not configured for taxonomic extraction")
            return

        org_id = payload.get("org_id")
        user_id = payload.get("user_id")
        project_id = payload.get("project_id")
        source_id = payload.get("source_id")

        # Support both messages (new) and content (legacy) formats
        messages = payload.get("messages")
        content = payload.get("content")

        if self._embedder is None:
            raise ValueError(
                "Taxonomic extraction requires an embedder. "
                "Pass embedder to MongoMemWorker or use WorkerConfig.auto_extraction()."
            )

        # Validate required fields
        if not org_id or not user_id or not source_id:
            raise ValueError(
                "Missing required fields in taxonomic extraction task. "
                f"Required: org_id, user_id, source_id. "
                f"Got: org_id={org_id}, user_id={user_id}, source_id={source_id}"
            )

        # Handle messages vs content (backward compatibility)
        if not messages:
            if content:
                # Legacy format: convert content to single message
                messages = [{"role": "user", "content": content}]
            else:
                raise ValueError(
                    "Missing required field: 'messages' or 'content'. "
                    "Provide either a list of messages or text content."
                )

        # Get approval mode and visibility from payload
        approval_mode: ApprovalMode = payload.get("approval_mode", "auto")
        visibility_str = payload.get("visibility", "org")  # Taxonomic defaults to ORG
        visibility = ChunkVisibility(visibility_str) if visibility_str else ChunkVisibility.ORG

        try:
            await self._run_taxonomic_pipeline(
                messages=messages,
                org_id=org_id,
                user_id=user_id,
                project_id=project_id,
                source_id=source_id,
                approval_mode=approval_mode,
                visibility=visibility,
            )
        except Exception as exc:
            from ...mongomem_core.common import ExtractionError

            raise ExtractionError(
                f"Taxonomic extraction failed for source {source_id}",
                extraction_type="taxonomic",
                source_id=source_id,
                original_error=exc,
            ) from exc

    async def _run_taxonomic_pipeline(
        self,
        messages: List[Dict[str, Any]],
        org_id: str,
        user_id: str,
        source_id: str,
        project_id: Optional[str] = None,
        approval_mode: ApprovalMode = "auto",
        visibility: ChunkVisibility = ChunkVisibility.ORG,
    ) -> None:
        """Run the full taxonomic extraction pipeline on messages."""
        if not self._taxonomic_pipeline:
            # Create pipeline on-demand if not pre-created
            if not self._llm or not self._embedder:
                raise ValueError("Taxonomic pipeline requires LLM and embedder")
            self._taxonomic_pipeline = create_taxonomic_pipeline(
                db=self._db,
                llm=self._llm,
                embedder=self._embedder,
                extraction_prompt_resolver=self._make_prompt_resolver("taxonomic"),
            )

        loop = asyncio.get_running_loop()

        # Run the sync pipeline in an executor
        result = await loop.run_in_executor(
            None,
            partial(
                self._taxonomic_pipeline.run,
                messages=messages,
                org_id=org_id,
                user_id=user_id,
                source_id=source_id,
                approval_mode=approval_mode,
                visibility=visibility,
                project_id=project_id,
            ),
        )

        stats = result.consolidation_stats
        if result.approval_mode == "manual":
            logger.info(
                "Taxonomic pipeline staged for source=%s org=%s user=%s: "
                "extracted=%d, pending_ids=%d",
                source_id,
                org_id,
                user_id,
                result.extracted_count,
                len(result.pending_ids),
            )
        else:
            logger.info(
                "Taxonomic pipeline completed for source=%s org=%s user=%s: "
                "extracted=%d, added=%d, updated=%d, reinforced=%d, duplicates=%d",
                source_id,
                org_id,
                user_id,
                result.extracted_count,
                stats.add_count,
                stats.update_count,
                stats.reinforce_count,
                stats.duplicate_count,
            )


# =============================================================================
# Preferences Handler
# =============================================================================


class PreferencesHandler(BaseLearningHandler):
    """
    Handler for user preferences extraction.

    Extracts communication preferences from conversations and stores them
    as session-scoped preferences. Simpler than semantic/episodic handlers
    because it doesn't require embeddings or consolidation.

    Preferences include:
    - tone: formal, casual, professional, etc.
    - style: concise, detailed, step_by_step
    - expertise_level: beginner, intermediate, advanced, expert
    - preferred_format: bullet_points, paragraphs, code_heavy
    - language: en, es, fr, etc.
    - custom_instructions: free-form user requests

    Persistence uses merge-based upsert - new extractions merge with
    existing session preferences, respecting user manual overrides.
    """

    task_type = "preferences"
    _extraction_type: ExtractionType = "preferences"  # type: ignore[assignment]

    def __init__(
        self,
        db: Database,
        llm: Optional["LLMProtocol"],
        *,
        prompt: Optional[str] = None,
        use_db_prompts: bool = False,
    ) -> None:
        """
        Initialize preferences handler.

        Args:
            db: MongoDB database instance
            llm: LLM protocol implementation for extraction
            prompt: Optional custom prompt (overrides default)
            use_db_prompts: If True, fetch prompts from DB (enables hot-reload)
        """
        super().__init__(
            db=db,
            llm=llm,
            prompt=prompt,
            use_db_prompts=use_db_prompts,
            embedder=None,  # Preferences don't need embeddings
        )

        # Pre-create pipeline if LLM available
        self._preferences_pipeline: Optional[PreferencesPipeline] = None
        if llm:
            self._preferences_pipeline = create_preferences_pipeline(
                db=db,
                llm=llm,
                prompt_resolver=self._make_prompt_resolver("preferences"),
            )

    def _make_prompt_resolver(self, extraction_type: str) -> Optional[Callable[[], Optional[str]]]:
        """Create a prompt resolver for hot-reload support."""
        if not self._use_db_prompts or not self._config_store:
            return None

        config_store = self._config_store  # Capture for closure

        def resolver() -> Optional[str]:
            return config_store.get_active(
                org_id=None,
                extraction_type=extraction_type,  # type: ignore[arg-type]
            )

        return resolver

    async def handle_task(self, payload: Dict[str, Any]) -> None:
        """
        Process a preferences extraction task.

        Expected payload:
            - messages: List of conversation messages
            - org_id: Organization ID
            - user_id: User ID
            - source_id: Source reference (e.g., snapshot ID)
            - session_id: (Optional) Session ID. Defaults to source_id if not provided.
        """
        if self._llm is None:
            logger.warning("LLM not configured for preferences extraction")
            return

        org_id = payload.get("org_id")
        user_id = payload.get("user_id")
        source_id = payload.get("source_id")
        messages = payload.get("messages")

        # Session ID defaults to source_id (snapshot ID) if not provided
        session_id = payload.get("session_id") or source_id

        if not messages or not org_id or not user_id or not source_id or not session_id:
            raise ValueError(
                "Missing required fields in preferences extraction task. "
                f"Required: messages, org_id, user_id, source_id. "
                f"Got: messages={bool(messages)}, org_id={org_id}, "
                f"user_id={user_id}, source_id={source_id}"
            )

        # Get approval mode from payload
        approval_mode: ApprovalMode = payload.get("approval_mode", "auto")

        try:
            await self._run_preferences_pipeline(
                messages=messages,
                org_id=str(org_id),
                user_id=str(user_id),
                session_id=str(session_id),
                source_id=str(source_id),
                approval_mode=approval_mode,
            )
        except Exception as exc:
            from ...mongomem_core.common import ExtractionError

            raise ExtractionError(
                f"Preferences extraction failed for session {session_id}",
                extraction_type="preferences",
                source_id=source_id,
                original_error=exc,
            ) from exc

    async def _run_preferences_pipeline(
        self,
        messages: List[Dict[str, Any]],
        org_id: str,
        user_id: str,
        session_id: str,
        source_id: str,
        approval_mode: ApprovalMode = "auto",
    ) -> None:
        """Run the preferences extraction pipeline on messages."""
        if not self._preferences_pipeline:
            # Create pipeline on-demand if not pre-created
            if not self._llm:
                raise ValueError("Preferences pipeline requires LLM")
            self._preferences_pipeline = create_preferences_pipeline(
                db=self._db,
                llm=self._llm,
            )

        loop = asyncio.get_running_loop()

        # Run the sync pipeline in an executor
        result = await loop.run_in_executor(
            None,
            partial(
                self._preferences_pipeline.run,
                messages=messages,
                org_id=org_id,
                user_id=user_id,
                session_id=session_id,
                source_id=source_id,
                approval_mode=approval_mode,
            ),
        )

        if result.approval_mode == "manual":
            logger.info(
                "Preferences pipeline staged for session=%s org=%s user=%s: pending_id=%s",
                session_id,
                org_id,
                user_id,
                result.pending_id,
            )
        else:
            logger.info(
                "Preferences pipeline completed for session=%s org=%s user=%s: "
                "action=%s, fields_updated=%d, duration=%.2fms",
                session_id,
                org_id,
                user_id,
                result.action,
                result.fields_updated,
                result.duration_ms,
            )

        if not result.success:
            logger.error(
                "Preferences extraction had errors for session=%s: %s",
                session_id,
                result.errors,
            )


# =============================================================================
# Procedural Handler
# =============================================================================


class ProceduralHandler(BaseLearningHandler):
    """Handler for procedural memory extraction.

    Extracts reusable procedures (skills/workflows) from conversations using
    the full ProceduralPipeline with consolidation (ADD/UPDATE/REINFORCE).

    Requires both LLM and embedder for the consolidation flow.
    """

    task_type = "procedural"
    _extraction_type: ExtractionType = "procedural"  # type: ignore[assignment]

    def __init__(
        self,
        db: Database,
        llm: Optional["LLMProtocol"],
        embedder: Optional["EmbedderProtocol"],
        *,
        prompt: Optional[str] = None,
        use_db_prompts: bool = False,
    ) -> None:
        super().__init__(
            db=db,
            llm=llm,
            prompt=prompt,
            use_db_prompts=use_db_prompts,
            embedder=embedder,
        )

        self._procedural_pipeline: Optional[ProceduralPipeline] = None
        if llm and embedder:
            self._procedural_pipeline = create_procedural_pipeline(
                db=db,
                llm=llm,
                embedder=embedder,
                extraction_prompt_resolver=self._make_prompt_resolver("procedural"),
            )

    async def handle_task(self, payload: Dict[str, Any]) -> None:
        """Process a procedural extraction task.

        Expected payload:
            - messages: List of conversation messages
            - org_id: Organization ID
            - user_id: User ID
            - source_id: Source reference (e.g., snapshot ID)
            - project_id: (Optional) Project ID for prompt resolution
        """
        if self._llm is None:
            logger.warning("LLM not configured for procedural extraction")
            return

        org_id = payload.get("org_id")
        user_id = payload.get("user_id")
        project_id = payload.get("project_id")
        source_id = payload.get("source_id")
        messages = payload.get("messages")
        content = payload.get("content")

        if self._embedder is None:
            raise ValueError(
                "Procedural extraction requires an embedder. "
                "Pass embedder to MongoMemWorker or use WorkerConfig.auto_extraction()."
            )

        if not org_id or not user_id or not source_id:
            raise ValueError(
                "Missing required fields in procedural extraction task. "
                f"Required: org_id, user_id, source_id. "
                f"Got: org_id={org_id}, user_id={user_id}, source_id={source_id}"
            )

        if not messages:
            if content:
                messages = [{"role": "user", "content": content}]
            else:
                raise ValueError(
                    "Missing required field: 'messages' or 'content'. "
                    "Provide either a list of messages or text content."
                )

        approval_mode: ApprovalMode = payload.get("approval_mode", "auto")
        visibility_str = payload.get("visibility", "private")
        visibility = ChunkVisibility(visibility_str) if visibility_str else ChunkVisibility.PRIVATE

        try:
            await self._run_procedural_pipeline(
                messages=messages,
                org_id=org_id,
                user_id=user_id,
                project_id=project_id,
                source_id=source_id,
                approval_mode=approval_mode,
                visibility=visibility,
            )
        except Exception as exc:
            from ...mongomem_core.common import ExtractionError

            raise ExtractionError(
                f"Procedural extraction failed for source {source_id}",
                extraction_type="procedural",
                source_id=source_id,
                original_error=exc,
            ) from exc

    async def _run_procedural_pipeline(
        self,
        messages: List[Dict[str, Any]],
        org_id: str,
        user_id: str,
        source_id: str,
        project_id: Optional[str] = None,
        approval_mode: ApprovalMode = "auto",
        visibility: ChunkVisibility = ChunkVisibility.PRIVATE,
    ) -> None:
        """Run the full procedural extraction pipeline on messages."""
        if not self._procedural_pipeline:
            if not self._llm or not self._embedder:
                raise ValueError("Procedural pipeline requires LLM and embedder")
            self._procedural_pipeline = create_procedural_pipeline(
                db=self._db,
                llm=self._llm,
                embedder=self._embedder,
                extraction_prompt_resolver=self._make_prompt_resolver("procedural"),
            )

        loop = asyncio.get_running_loop()

        result = await loop.run_in_executor(
            None,
            partial(
                self._procedural_pipeline.run,
                messages=messages,
                org_id=org_id,
                user_id=user_id,
                source_id=source_id,
                approval_mode=approval_mode,
                visibility=visibility,
                project_id=project_id,
            ),
        )

        stats = result.consolidation_stats
        if result.approval_mode == "manual":
            logger.info(
                "Procedural pipeline staged for source=%s org=%s user=%s: "
                "extracted=%d, pending_ids=%d",
                source_id,
                org_id,
                user_id,
                result.extracted_count,
                len(result.pending_ids),
            )
        else:
            logger.info(
                "Procedural pipeline completed for source=%s org=%s user=%s: "
                "extracted=%d, added=%d, updated=%d, reinforced=%d, duplicates=%d",
                source_id,
                org_id,
                user_id,
                result.extracted_count,
                stats.add_count,
                stats.update_count,
                stats.reinforce_count,
                stats.duplicate_count,
            )


__all__ = [
    "BaseLearningHandler",
    "SemanticHandler",
    "EpisodicHandler",
    "TaxonomicHandler",
    "PreferencesHandler",
    "ProceduralHandler",
    "ExtractionType",
]
