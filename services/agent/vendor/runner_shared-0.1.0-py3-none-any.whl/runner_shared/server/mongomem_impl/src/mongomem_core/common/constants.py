"""Common constants for mongomem_core."""

from __future__ import annotations

# =============================================================================
# LLM Default Models (for token counting and format detection)
# =============================================================================
DEFAULT_MODEL_NAME = "gpt-4"
DEFAULT_CLAUDE_MODEL = "claude-3-opus"
DEFAULT_GEMINI_MODEL = "gemini-pro"
DEFAULT_OPENAI_MODEL = "gpt-4"

# =============================================================================
# Memory Management Defaults
# =============================================================================
# Snapshot promotion thresholds
DEFAULT_MAX_MESSAGES = 20
DEFAULT_STALE_THRESHOLD_MINUTES = 30

# Vector search settings
# Note: MongoDB Atlas recommends 10x for best results, but we use 2x with min 50
# for balance between quality and performance. See execute_vector_search().
VECTOR_SEARCH_CANDIDATE_MULTIPLIER = 2
VECTOR_SEARCH_MIN_CANDIDATES = 50  # Minimum candidate pool for quality
DEFAULT_SIMILARITY_THRESHOLD = 0.0
DEFAULT_TOP_K = 50

# Deduplication threshold for retrieval
# Memories with similarity >= this threshold are considered duplicates
DEFAULT_DEDUP_THRESHOLD = 0.5

# =============================================================================
# Retrieval Defaults (moved from retrieval/constants.py for single source)
# =============================================================================
# Required memory sources for retrieval validation
REQUIRED_SOURCES: set[str] = {"stm", "episodic"}

# Threshold for considering a memory list "large"
LARGE_MEMORY_LIST_THRESHOLD: int = 1000

# Fetch timeout in seconds
FETCH_TIMEOUT_SECONDS: int = 30

# Default fallback for max_tokens when invalid value provided
DEFAULT_MAX_TOKENS: int = 16000


__all__ = [
    # LLM defaults
    "DEFAULT_MODEL_NAME",
    "DEFAULT_CLAUDE_MODEL",
    "DEFAULT_GEMINI_MODEL",
    "DEFAULT_OPENAI_MODEL",
    # Memory management
    "DEFAULT_MAX_MESSAGES",
    "DEFAULT_STALE_THRESHOLD_MINUTES",
    # Vector search
    "VECTOR_SEARCH_CANDIDATE_MULTIPLIER",
    "VECTOR_SEARCH_MIN_CANDIDATES",
    "DEFAULT_SIMILARITY_THRESHOLD",
    "DEFAULT_TOP_K",
    "DEFAULT_DEDUP_THRESHOLD",
    # Retrieval
    "REQUIRED_SOURCES",
    "LARGE_MEMORY_LIST_THRESHOLD",
    "FETCH_TIMEOUT_SECONDS",
    "DEFAULT_MAX_TOKENS",
]
