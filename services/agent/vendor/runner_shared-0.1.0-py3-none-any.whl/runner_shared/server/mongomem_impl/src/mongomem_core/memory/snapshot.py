"""CRUD and invariants for snapshot memory.

Snapshots consolidate short-term memory turns into coherent conversation
segments. They serve as middle-tier conversational memory in the hierarchy:
STM -> Snapshot -> Episodic.

Key Features:
- STM embedding transfer for efficient vector search
- Cross-session retrieval support
- Topic-aware segmentation
- Soft delete support
- Integration with promotion pipeline

All functions operate synchronously against MongoDB and expect the caller to
provide necessary context (org_id, user_id, etc.).
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional, Sequence, Tuple

from bson import ObjectId
from mongomem_core.common.utils import (
    format_document_identifier,
    handle_db_error,
    handle_duplicate_key_error,
    to_object_id,
    utcnow,
)
from mongomem_core.exceptions import (
    DatabaseOperationError,
    DocumentNotFoundError,
)
from mongomem_core.memory.base import (
    VECTOR_SEARCH_CANDIDATE_MULTIPLIER,
    BaseDocumentBuilder,
    BaseQueryBuilder,
    BaseUpdateFieldBuilder,
    doc_to_output,
    handle_empty_sequence,
    merge_rbac_and_metadata_filter,
)
from mongomem_core.models.filters import MetadataFilter
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.snapshot import (
    SnapshotDB,
    SnapshotIn,
    SnapshotOut,
    SnapshotUpdate,
)
from mongomem_core.storage import get_collection
from mongomem_core.storage.collections import SnapshotMemoryCollection
from pymongo import DESCENDING, ReturnDocument
from pymongo.database import Database
from pymongo.errors import DuplicateKeyError
from pymongo.results import DeleteResult, InsertOneResult, UpdateResult

logger = logging.getLogger(__name__)

_SNAPSHOT_COL = SnapshotMemoryCollection()


def _build_snapshot_query_filter(
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    session_id: Optional[str] = None,
    boundary_turn_seq: Optional[int] = None,
    include_deleted: bool = False,
) -> Tuple[Dict[str, Any], str]:
    """
    Build a MongoDB query filter and identifier string for snapshot lookups.

    Supports lookup by ID or by composite key (session_id, boundary_turn_seq).

    Args:
        org_id: Organization ID
        id: Document ID (string or ObjectId) - mutually exclusive with session_id/boundary_turn_seq
        session_id: Session ID - can be used alone or with boundary_turn_seq
        boundary_turn_seq: Turn sequence boundary - must be provided with session_id
        include_deleted: If True, include soft-deleted documents

    Returns:
        Tuple of (query_filter_dict, identifier_string)

    Raises:
        ValueError: If neither id nor session_id is provided.
    """
    if id is not None:
        if session_id is not None or boundary_turn_seq is not None:
            raise ValueError("Cannot provide both 'id' and ('session_id', 'boundary_turn_seq')")
        q_filter, identifier = BaseQueryBuilder.build_id_filter(
            org_id, id, include_deleted=include_deleted
        )
    elif session_id is not None:
        q_filter = BaseQueryBuilder.build_base_filter(
            org_id,
            include_deleted=include_deleted,
            session_id=session_id,
        )
        if boundary_turn_seq is not None:
            q_filter["boundary_turn_seq"] = boundary_turn_seq
            identifier = format_document_identifier(
                session_id=session_id, boundary_turn_seq=boundary_turn_seq
            )
        else:
            identifier = format_document_identifier(session_id=session_id)
    else:
        raise ValueError("Must provide either 'id' or 'session_id'")

    return q_filter, identifier


def _build_snapshot_doc(
    snapshot_in: SnapshotIn,
    org_id: str,
    user_id: str,
    timestamp: datetime,
    *,
    embedding: Optional[List[float]] = None,
    embedding_model_id: Optional[str] = None,
    embedding_strategy: Optional[str] = None,
) -> SnapshotDB:
    """Build a SnapshotDB document from input.

    Args:
        snapshot_in: Input model with snapshot data
        org_id: Organization ID
        user_id: User ID of the creator
        timestamp: Timestamp for the document
        embedding: Pre-computed embedding vector (if any)
        embedding_model_id: Model used to generate embedding
        embedding_strategy: Strategy used ('transfer', 'generate', 'defer')

    Returns:
        A SnapshotDB document (not yet persisted)
    """
    doc = BaseDocumentBuilder.build_memory_document(
        snapshot_in,
        SnapshotDB,
        org_id,
        user_id,
        timestamp,
        embedding_config={
            "model_id_field": "embedding_model_id",
            "log_context": f"session={snapshot_in.session_id}",
        },
    )

    # Manually apply embedding since SnapshotIn doesn't have embedding_present()
    if embedding is not None and len(embedding) > 0:
        doc.embedding = embedding
        doc.has_embedding = True
        if embedding_model_id:
            doc.embedding_model_id = embedding_model_id
        doc.embedding_dimension = len(embedding)

    # Set embedding strategy if provided
    if embedding_strategy:
        doc.embedding_strategy = embedding_strategy

    return doc


def create_snapshot(
    db: Database,
    snapshot_in: SnapshotIn,
    org_id: str,
    user_id: str,
    *,
    embedding: Optional[List[float]] = None,
    embedding_model_id: Optional[str] = None,
    embedding_strategy: Optional[str] = None,
) -> SnapshotDB:
    """
    Create a snapshot memory document.

    Args:
        db: MongoDB database instance
        snapshot_in: Input model with snapshot data
        org_id: Organization ID
        user_id: User ID of the creator
        embedding: Pre-computed embedding vector (if any)
        embedding_model_id: Model used to generate embedding
        embedding_strategy: Strategy used ('transfer', 'generate', 'defer')

    Returns:
        The created SnapshotDB document

    Raises:
        DuplicateDocumentError: If (session_id, boundary_turn_seq) already exists.
        DatabaseOperationError: If the insert operation fails.

    Example:
        >>> from mongomem_core.storage import get_database
        >>> from mongomem_core.models.memory.snapshot import SnapshotIn, SnapshotMessage
        >>> db = get_database()
        >>> messages = [SnapshotMessage(role="user", content="Hello", timestamp=utcnow())]
        >>> snapshot = SnapshotIn(
        ...     session_id="session_1",
        ...     messages=messages,
        ...     snapshot_reason="manual"
        ... )
        >>> doc = create_snapshot(db, snapshot, org_id="org_1", user_id="user_1")
    """
    logger.debug(
        "Creating snapshot document: session=%s reason=%s org=%s user=%s",
        snapshot_in.session_id,
        snapshot_in.snapshot_reason,
        org_id,
        user_id,
    )

    now = utcnow()
    doc = _build_snapshot_doc(
        snapshot_in,
        org_id,
        user_id,
        now,
        embedding=embedding,
        embedding_model_id=embedding_model_id,
        embedding_strategy=embedding_strategy,
    )

    col = get_collection(_SNAPSHOT_COL, db)
    try:
        result: InsertOneResult = col.insert_one(doc.model_dump(by_alias=True))
        doc.id = result.inserted_id

        logger.debug(
            "Created snapshot document: id=%s session=%s org=%s",
            result.inserted_id,
            snapshot_in.session_id,
            org_id,
        )
        return doc
    except DuplicateKeyError as exc:
        handle_duplicate_key_error(
            exc,
            collection_name=_SNAPSHOT_COL.name,
            log_message="Duplicate snapshot document detected: session=%s boundary=%s org=%s",
            log_args=(snapshot_in.session_id, snapshot_in.boundary_turn_seq, org_id),
            details={
                "session_id": snapshot_in.session_id,
                "boundary_turn_seq": snapshot_in.boundary_turn_seq,
                "org_id": org_id,
            },
        )
    except Exception as exc:
        logger.error(
            "Failed to create snapshot document: session=%s org=%s error=%s",
            snapshot_in.session_id,
            org_id,
            exc,
        )
        raise DatabaseOperationError(
            f"Failed to create snapshot: {exc}",
            operation="insert_one",
            collection=_SNAPSHOT_COL.name,
            original_error=exc,
        ) from exc


def get_snapshot(
    db: Database,
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    session_id: Optional[str] = None,
    boundary_turn_seq: Optional[int] = None,
    include_deleted: bool = False,
) -> Optional[SnapshotOut]:
    """
    Fetch a single snapshot document by ID or (session_id, boundary_turn_seq).

    Either `id` or `session_id` must be provided.

    Args:
        db: MongoDB database instance
        org_id: Organization ID (for access control)
        id: Document ID (string or ObjectId) - mutually exclusive with session_id
        session_id: Session ID
        boundary_turn_seq: Turn sequence boundary (optional, used with session_id)
        include_deleted: If True, include soft-deleted documents

    Returns:
        SnapshotOut if found, None otherwise.

    Raises:
        ValueError: If neither id nor session_id is provided.
        ValidationError: If id is not a valid ObjectId format.
        DatabaseOperationError: If the query fails.

    Example:
        >>> # Get by ID
        >>> doc = get_snapshot(db, org_id="org_1", id="507f1f77bcf86cd799439011")
        >>> # Get by session and boundary
        >>> doc = get_snapshot(db, org_id="org_1", session_id="session_1", boundary_turn_seq=20)
    """
    q_filter, identifier = _build_snapshot_query_filter(
        org_id,
        id=id,
        session_id=session_id,
        boundary_turn_seq=boundary_turn_seq,
        include_deleted=include_deleted,
    )

    col = get_collection(_SNAPSHOT_COL, db)
    with handle_db_error(
        operation="find_one",
        collection=_SNAPSHOT_COL.name,
        log_message="Failed to retrieve snapshot document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        doc = col.find_one(q_filter)
        if not doc:
            logger.debug("Snapshot document not found: %s org=%s", identifier, org_id)
            return None

        doc["_id"] = str(doc["_id"])
        logger.debug("Retrieved snapshot document: %s", identifier)
        return SnapshotOut.model_validate(doc)


def get_latest_snapshot(
    db: Database,
    session_id: str,
    org_id: str,
    *,
    include_deleted: bool = False,
) -> Optional[SnapshotOut]:
    """
    Get the most recent snapshot for a session.

    Args:
        db: MongoDB database instance
        session_id: Session ID
        org_id: Organization ID
        include_deleted: If True, include soft-deleted documents

    Returns:
        SnapshotOut if found, None otherwise.

    Raises:
        DatabaseOperationError: If the query fails.
    """
    col = get_collection(_SNAPSHOT_COL, db)

    q_filter = BaseQueryBuilder.build_base_filter(
        org_id,
        include_deleted=include_deleted,
        session_id=session_id,
    )

    with handle_db_error(
        operation="find_one",
        collection=_SNAPSHOT_COL.name,
        log_message="Failed to retrieve latest snapshot: session=%s org=%s",
        log_args_tuple=(session_id, org_id),
    ):
        doc = col.find_one(q_filter, sort=[("timestamp", DESCENDING)])
        if not doc:
            logger.debug("No snapshot found for session=%s org=%s", session_id, org_id)
            return None

        doc["_id"] = str(doc["_id"])
        logger.debug(
            "Retrieved latest snapshot for session=%s: id=%s",
            session_id,
            doc["_id"],
        )
        return SnapshotOut.model_validate(doc)


def list_snapshots(
    db: Database,
    org_id: str,
    *,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    promoted: Optional[bool] = None,
    has_embedding: Optional[bool] = None,
    from_timestamp: Optional[datetime] = None,
    before: Optional[datetime] = None,
    include_deleted: bool = False,
    limit: int = 50,
    sort_descending: bool = True,
) -> List[SnapshotOut]:
    """
    List snapshot documents for an organization with optional filters and pagination.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        user_id: Optional filter by user ID
        session_id: Optional filter by session ID
        visibility: Optional filter by visibility scope
        project_id: Optional filter by group ID (for shared visibility)
        promoted: Optional filter by promotion status
        has_embedding: Optional filter by embedding presence
        from_timestamp: Optional filter - fetch documents from this timestamp onwards
        before: Optional cursor - fetch documents before this timestamp (for pagination)
        include_deleted: If True, include soft-deleted documents
        limit: Maximum number of results (default: 50)
        sort_descending: If True, sort by timestamp descending (newest first)

    Returns:
        List of SnapshotOut documents

    Raises:
        DatabaseOperationError: If the query fails.

    Example:
        >>> # Get all snapshots for org
        >>> docs = list_snapshots(db, org_id="org_1")
        >>> # Get snapshots for session
        >>> docs = list_snapshots(db, org_id="org_1", session_id="session_1")
        >>> # Get unpromoted snapshots
        >>> docs = list_snapshots(db, org_id="org_1", promoted=False)
    """
    col = get_collection(_SNAPSHOT_COL, db)

    q_filter = BaseQueryBuilder.build_list_filter(
        org_id,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        from_timestamp=from_timestamp,
        before=before,
        include_deleted=include_deleted,
        timestamp_field="timestamp",
    )

    if session_id:
        q_filter["session_id"] = session_id
    if promoted is not None:
        q_filter["promoted"] = promoted
    if has_embedding is not None:
        q_filter["has_embedding"] = has_embedding

    sort_direction = DESCENDING if sort_descending else 1

    with handle_db_error(
        operation="find",
        collection=_SNAPSHOT_COL.name,
        log_message="Failed to retrieve snapshot documents for org=%s",
        log_args_tuple=(org_id,),
    ):
        cursor = col.find(q_filter).sort("timestamp", sort_direction)
        if limit > 0:
            cursor = cursor.limit(limit)
        results = [doc_to_output(d, SnapshotOut) for d in cursor]
        logger.debug(
            "Retrieved %d snapshot documents for org=%s",
            len(results),
            org_id,
        )
        return results


def _build_update_fields(update: SnapshotUpdate) -> Dict[str, Any]:
    """Build MongoDB update fields from SnapshotUpdate model."""
    custom_fields: Dict[str, Any] = {}

    # Topic metadata
    if update.topic_id is not None:
        custom_fields["topic_id"] = update.topic_id
    if update.topic_title is not None:
        custom_fields["topic_title"] = update.topic_title

    # Promotion status
    if update.promoted is not None:
        custom_fields["promoted"] = update.promoted

    # Embedding updates
    if update.embedding_model_id is not None:
        custom_fields["embedding_model_id"] = update.embedding_model_id
    if update.embedding_dimension is not None:
        custom_fields["embedding_dimension"] = update.embedding_dimension

    # Metadata
    if update.metadata is not None:
        custom_fields["metadata"] = update.metadata

    return BaseUpdateFieldBuilder.build_update_fields(
        update,
        field_mappings={},
        include_visibility=True,
        include_publishing=False,
        include_agent_attribution=False,
        include_embedding=True,
        custom_fields=custom_fields if custom_fields else None,
    )


def update_snapshot(
    db: Database,
    org_id: str,
    update: SnapshotUpdate,
    *,
    id: Optional[str | ObjectId] = None,
    session_id: Optional[str] = None,
    boundary_turn_seq: Optional[int] = None,
) -> SnapshotOut:
    """
    Update a snapshot document by ID or (session_id, boundary_turn_seq).

    Either `id` or `session_id` must be provided.

    Args:
        db: MongoDB database instance
        org_id: Organization ID (for access control)
        update: Update model with fields to modify
        id: Document ID (string or ObjectId) - mutually exclusive with session_id
        session_id: Session ID
        boundary_turn_seq: Turn sequence boundary (optional, used with session_id)

    Returns:
        Updated SnapshotOut document

    Raises:
        ValueError: If neither id nor session_id is provided.
        ValidationError: If id is not a valid ObjectId format.
        DocumentNotFoundError: If the document doesn't exist.
        DatabaseOperationError: If the update operation fails.

    Example:
        >>> update = SnapshotUpdate(promoted=True)
        >>> doc = update_snapshot(db, org_id="org_1", update=update, id="507f1f77bcf86cd799439011")
    """
    update_fields = _build_update_fields(update)

    if not update_fields:
        doc = get_snapshot(
            db,
            org_id,
            id=id,
            session_id=session_id,
            boundary_turn_seq=boundary_turn_seq,
        )
        if not doc:
            _, identifier = _build_snapshot_query_filter(
                org_id,
                id=id,
                session_id=session_id,
                boundary_turn_seq=boundary_turn_seq,
                include_deleted=True,
            )
            raise DocumentNotFoundError(
                "Snapshot document not found",
                collection=_SNAPSHOT_COL.name,
                document_id=str(id) if id else None,
                details={"org_id": org_id, "identifier": identifier},
            )
        return doc

    q_filter, identifier = _build_snapshot_query_filter(
        org_id,
        id=id,
        session_id=session_id,
        boundary_turn_seq=boundary_turn_seq,
        include_deleted=False,
    )

    col = get_collection(_SNAPSHOT_COL, db)
    with handle_db_error(
        operation="find_one_and_update",
        collection=_SNAPSHOT_COL.name,
        log_message="Failed to update snapshot document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result_doc = col.find_one_and_update(
            q_filter,
            {"$set": update_fields},
            return_document=ReturnDocument.AFTER,
        )

        if not result_doc:
            raise DocumentNotFoundError(
                "Snapshot document not found or is deleted",
                collection=_SNAPSHOT_COL.name,
                document_id=str(id) if id else None,
                details={"org_id": org_id, "identifier": identifier},
            )

        logger.debug("Updated snapshot document: %s org=%s", identifier, org_id)
        return SnapshotOut.model_validate({**result_doc, "_id": str(result_doc["_id"])})


def update_snapshot_embedding(
    db: Database,
    org_id: str,
    embedding: List[float],
    *,
    id: Optional[str | ObjectId] = None,
    session_id: Optional[str] = None,
    boundary_turn_seq: Optional[int] = None,
    embedding_model_id: Optional[str] = None,
    embedding_strategy: Optional[str] = None,
) -> UpdateResult:
    """
    Update the embedding on an existing snapshot document.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        embedding: The embedding vector
        id: Document ID (string or ObjectId) - mutually exclusive with session_id
        session_id: Session ID
        boundary_turn_seq: Turn sequence boundary (optional)
        embedding_model_id: Optional model identifier
        embedding_strategy: Optional strategy used ('transfer', 'generate', 'defer')

    Returns:
        UpdateResult from MongoDB

    Raises:
        ValueError: If neither id nor session_id is provided.
        ValidationError: If id is not a valid ObjectId format.
        DatabaseOperationError: If the update operation fails.

    Example:
        >>> result = update_snapshot_embedding(
        ...     db, org_id="org_1", embedding=[0.1, 0.2, ...],
        ...     id="507f1f77bcf86cd799439011", embedding_strategy="generate"
        ... )
    """
    q_filter, identifier = _build_snapshot_query_filter(
        org_id,
        id=id,
        session_id=session_id,
        boundary_turn_seq=boundary_turn_seq,
        include_deleted=False,
    )

    update_fields: Dict[str, Any] = {
        "embedding": embedding,
        "has_embedding": True,
        "embedding_dimension": len(embedding) if embedding else None,
    }
    if embedding_model_id:
        update_fields["embedding_model_id"] = embedding_model_id
    if embedding_strategy:
        update_fields["embedding_strategy"] = embedding_strategy

    col = get_collection(_SNAPSHOT_COL, db)
    with handle_db_error(
        operation="update_one",
        collection=_SNAPSHOT_COL.name,
        log_message="Failed to update embedding for snapshot document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result = col.update_one(q_filter, {"$set": update_fields})
        if result.modified_count > 0:
            logger.debug(
                "Updated embedding for snapshot document: %s strategy=%s",
                identifier,
                embedding_strategy,
            )
        else:
            logger.warning(
                "No snapshot document modified for embedding update: %s org=%s",
                identifier,
                org_id,
            )
        return result


def soft_delete_snapshot(
    db: Database,
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    session_id: Optional[str] = None,
    boundary_turn_seq: Optional[int] = None,
) -> UpdateResult:
    """
    Soft delete a snapshot document by ID or (session_id, boundary_turn_seq).

    Sets the deleted flag and deleted_at timestamp without removing the document.

    Args:
        db: MongoDB database instance
        org_id: Organization ID (for access control)
        id: Document ID (string or ObjectId) - mutually exclusive with session_id
        session_id: Session ID
        boundary_turn_seq: Turn sequence boundary (optional)

    Returns:
        UpdateResult from MongoDB

    Raises:
        ValueError: If neither id nor session_id is provided.
        ValidationError: If id is not a valid ObjectId format.
        DatabaseOperationError: If the update operation fails.

    Example:
        >>> result = soft_delete_snapshot(db, org_id="org_1", id="507f1f77bcf86cd799439011")
    """
    q_filter, identifier = _build_snapshot_query_filter(
        org_id,
        id=id,
        session_id=session_id,
        boundary_turn_seq=boundary_turn_seq,
        include_deleted=True,
    )
    q_filter.pop("deleted", None)

    col = get_collection(_SNAPSHOT_COL, db)
    now = utcnow()
    with handle_db_error(
        operation="update_one",
        collection=_SNAPSHOT_COL.name,
        log_message="Failed to soft delete snapshot document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result = col.update_one(
            q_filter,
            {"$set": {"deleted": True, "deleted_at": now}},
        )
        if result.modified_count > 0:
            logger.debug("Soft deleted snapshot document: %s org=%s", identifier, org_id)
        else:
            logger.warning(
                "No snapshot document modified for soft delete: %s org=%s",
                identifier,
                org_id,
            )
        return result


def delete_snapshot(
    db: Database,
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    session_id: Optional[str] = None,
    boundary_turn_seq: Optional[int] = None,
    soft: bool = True,
) -> DeleteResult | UpdateResult:
    """
    Delete a snapshot document by ID or (session_id, boundary_turn_seq).

    By default, performs a soft delete. Set soft=False for hard delete.

    Args:
        db: MongoDB database instance
        org_id: Organization ID (for access control)
        id: Document ID (string or ObjectId) - mutually exclusive with session_id
        session_id: Session ID
        boundary_turn_seq: Turn sequence boundary (optional)
        soft: If True (default), perform soft delete; if False, hard delete

    Returns:
        DeleteResult or UpdateResult from MongoDB

    Raises:
        ValueError: If neither id nor session_id is provided.
        ValidationError: If id is not a valid ObjectId format.
        DatabaseOperationError: If the delete operation fails.

    Example:
        >>> # Soft delete (default)
        >>> result = delete_snapshot(db, org_id="org_1", id="507f1f77bcf86cd799439011")
        >>> # Hard delete
        >>> result = delete_snapshot(db, org_id="org_1", id="...", soft=False)
    """
    if soft:
        return soft_delete_snapshot(
            db,
            org_id,
            id=id,
            session_id=session_id,
            boundary_turn_seq=boundary_turn_seq,
        )

    # Hard delete
    q_filter, identifier = _build_snapshot_query_filter(
        org_id,
        id=id,
        session_id=session_id,
        boundary_turn_seq=boundary_turn_seq,
        include_deleted=True,
    )
    q_filter.pop("deleted", None)

    col = get_collection(_SNAPSHOT_COL, db)
    with handle_db_error(
        operation="delete_one",
        collection=_SNAPSHOT_COL.name,
        log_message="Failed to delete snapshot document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result = col.delete_one(q_filter)
        logger.debug(
            "Deleted snapshot document: %s org=%s (deleted_count=%d)",
            identifier,
            org_id,
            result.deleted_count,
        )
        return result


def delete_snapshots_by_ids(
    db: Database,
    snapshot_ids: Sequence[str | ObjectId],
    org_id: str,
    *,
    soft: bool = True,
) -> DeleteResult | UpdateResult:
    """
    Delete multiple snapshot documents by ID.

    Args:
        db: MongoDB database instance
        snapshot_ids: List of document IDs to delete
        org_id: Organization ID (for access control)
        soft: If True (default), perform soft delete; if False, hard delete

    Returns:
        DeleteResult or UpdateResult from MongoDB. If an empty sequence is provided,
        returns a result with count=0 (idempotent operation - no database call is made).

    Raises:
        ValidationError: If any snapshot_id is not a valid ObjectId format.
        DatabaseOperationError: If the delete operation fails.
    """
    result_type = UpdateResult if soft else DeleteResult
    early_return = handle_empty_sequence(snapshot_ids, "delete_snapshots_by_ids", result_type)
    if early_return is not None:
        return early_return

    col = get_collection(_SNAPSHOT_COL, db)
    oids = [to_object_id(sid) for sid in snapshot_ids]
    q_filter = {"_id": {"$in": oids}, "org_id": org_id}

    if soft:
        now = utcnow()
        with handle_db_error(
            operation="update_many",
            collection=_SNAPSHOT_COL.name,
            log_message="Failed to soft delete snapshot documents: count=%d org=%s",
            log_args_tuple=(len(snapshot_ids), org_id),
        ):
            update_result = col.update_many(
                q_filter,
                {"$set": {"deleted": True, "deleted_at": now}},
            )
            logger.info(
                "Soft deleted %d snapshot documents (requested=%d, org=%s)",
                update_result.modified_count,
                len(snapshot_ids),
                org_id,
            )
            return update_result
    else:
        with handle_db_error(
            operation="delete_many",
            collection=_SNAPSHOT_COL.name,
            log_message="Failed to delete snapshot documents: count=%d org=%s",
            log_args_tuple=(len(snapshot_ids), org_id),
        ):
            delete_result = col.delete_many(q_filter)
            logger.info(
                "Deleted %d snapshot documents (requested=%d, org=%s)",
                delete_result.deleted_count,
                len(snapshot_ids),
                org_id,
            )
            return delete_result


def delete_snapshots_by_session(
    db: Database,
    session_id: str,
    org_id: str,
    *,
    soft: bool = True,
) -> DeleteResult | UpdateResult:
    """
    Delete all snapshots for a session.

    Args:
        db: MongoDB database instance
        session_id: Session ID
        org_id: Organization ID (for access control)
        soft: If True (default), perform soft delete; if False, hard delete

    Returns:
        DeleteResult or UpdateResult from MongoDB

    Raises:
        DatabaseOperationError: If the delete operation fails.
    """
    col = get_collection(_SNAPSHOT_COL, db)
    q_filter = {"session_id": session_id, "org_id": org_id}

    if soft:
        now = utcnow()
        with handle_db_error(
            operation="update_many",
            collection=_SNAPSHOT_COL.name,
            log_message="Failed to soft delete snapshots for session=%s org=%s",
            log_args_tuple=(session_id, org_id),
        ):
            update_result = col.update_many(
                q_filter,
                {"$set": {"deleted": True, "deleted_at": now}},
            )
            logger.info(
                "Soft deleted %d snapshots for session=%s org=%s",
                update_result.modified_count,
                session_id,
                org_id,
            )
            return update_result
    else:
        with handle_db_error(
            operation="delete_many",
            collection=_SNAPSHOT_COL.name,
            log_message="Failed to delete snapshots for session=%s org=%s",
            log_args_tuple=(session_id, org_id),
        ):
            delete_result = col.delete_many(q_filter)
            logger.info(
                "Deleted %d snapshots for session=%s org=%s",
                delete_result.deleted_count,
                session_id,
                org_id,
            )
            return delete_result


def search_snapshots(
    db: Database,
    embedding: List[float],
    org_id: str,
    *,
    user_id: Optional[str] = None,
    exclude_session_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    top_k: int = 10,
    min_score: Optional[float] = None,
    index_name: str = "snap_embedding_vector_index",
    metadata_filter: Optional[MetadataFilter] = None,
) -> List[SnapshotOut]:
    """
    Vector search across snapshots using MongoDB Atlas Vector Search.

    Args:
        db: MongoDB database instance
        embedding: Query embedding vector
        org_id: Organization ID
        user_id: Optional filter by user ID
        exclude_session_id: Optional session to exclude (for cross-session retrieval)
        visibility: Optional filter by visibility scope
        top_k: Number of results to return (default: 10)
        min_score: Optional minimum similarity score threshold
        index_name: Name of the vector search index
        metadata_filter: Optional user-provided metadata filter for field-level filtering.
            Merged with RBAC filters; reserved RBAC keys are non-settable, so any
            colliding/injected caller keys are dropped to preserve tenant
            isolation. See MetadataFilter for usage.

    Returns:
        List of SnapshotOut documents sorted by similarity score

    Raises:
        DatabaseOperationError: If the search fails.

    Example:
        >>> from mongomem_core.models.filters import MetadataFilter
        >>> results = search_snapshots(
        ...     db, embedding=[0.1, 0.2, ...],
        ...     org_id="org_1", exclude_session_id="current_session"
        ... )
        >>>
        >>> # With metadata filter
        >>> results = search_snapshots(
        ...     db, embedding=[0.1, 0.2, ...],
        ...     org_id="org_1",
        ...     metadata_filter=MetadataFilter(raw={"promoted": True})
        ... )
    """
    col = get_collection(_SNAPSHOT_COL, db)

    # Build pre-filter (RBAC and base constraints)
    pre_filter: Dict[str, Any] = {
        "org_id": org_id,
        "has_embedding": True,
        "deleted": {"$ne": True},
    }
    if user_id:
        pre_filter["user_id"] = user_id
    if exclude_session_id:
        pre_filter["session_id"] = {"$ne": exclude_session_id}
    if visibility:
        pre_filter["visibility"] = visibility

    # Merge user metadata while keeping RBAC keys non-overridable (tenant isolation).
    pre_filter = merge_rbac_and_metadata_filter(pre_filter, metadata_filter)

    pipeline: List[Dict[str, Any]] = [
        {
            "$vectorSearch": {
                "index": index_name,
                "path": "embedding",
                "queryVector": embedding,
                "numCandidates": top_k * VECTOR_SEARCH_CANDIDATE_MULTIPLIER,
                "limit": top_k,
                "filter": pre_filter,
            }
        },
        {"$set": {"score": {"$meta": "vectorSearchScore"}}},
    ]

    # Add min_score filter if specified
    if min_score is not None:
        pipeline.append({"$match": {"score": {"$gte": min_score}}})

    with handle_db_error(
        operation="aggregate",
        collection=_SNAPSHOT_COL.name,
        log_message="Failed to search snapshots for org=%s",
        log_args_tuple=(org_id,),
    ):
        cursor = col.aggregate(pipeline)
        results = []
        for doc in cursor:
            doc["_id"] = str(doc["_id"])
            results.append(SnapshotOut.model_validate(doc))

        logger.debug(
            "Vector search returned %d snapshots for org=%s (top_k=%d)",
            len(results),
            org_id,
            top_k,
        )
        return results


def count_snapshots(
    db: Database,
    org_id: str,
    *,
    session_id: Optional[str] = None,
    promoted: Optional[bool] = None,
    has_embedding: Optional[bool] = None,
    include_deleted: bool = False,
) -> int:
    """
    Count snapshot documents matching filters.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        session_id: Optional filter by session ID
        promoted: Optional filter by promotion status
        has_embedding: Optional filter by embedding presence
        include_deleted: If True, include soft-deleted documents

    Returns:
        Count of matching documents

    Raises:
        DatabaseOperationError: If the query fails.
    """
    col = get_collection(_SNAPSHOT_COL, db)

    q_filter = BaseQueryBuilder.build_base_filter(org_id, include_deleted=include_deleted)

    if session_id:
        q_filter["session_id"] = session_id
    if promoted is not None:
        q_filter["promoted"] = promoted
    if has_embedding is not None:
        q_filter["has_embedding"] = has_embedding

    with handle_db_error(
        operation="count_documents",
        collection=_SNAPSHOT_COL.name,
        log_message="Failed to count snapshots for org=%s",
        log_args_tuple=(org_id,),
    ):
        count = col.count_documents(q_filter)
        logger.debug("Counted %d snapshots for org=%s", count, org_id)
        return count


def mark_snapshot_promoted(
    db: Database,
    snapshot_id: str | ObjectId,
    org_id: str,
) -> UpdateResult:
    """
    Mark a snapshot as promoted to episodic memory.

    Args:
        db: MongoDB database instance
        snapshot_id: Snapshot document ID
        org_id: Organization ID

    Returns:
        UpdateResult from MongoDB

    Raises:
        DatabaseOperationError: If the update fails.
    """
    col = get_collection(_SNAPSHOT_COL, db)
    oid = to_object_id(snapshot_id)

    with handle_db_error(
        operation="update_one",
        collection=_SNAPSHOT_COL.name,
        log_message="Failed to mark snapshot as promoted: id=%s org=%s",
        log_args_tuple=(snapshot_id, org_id),
    ):
        result = col.update_one(
            {"_id": oid, "org_id": org_id, "deleted": {"$ne": True}},
            {"$set": {"promoted": True}},
        )
        if result.modified_count > 0:
            logger.debug("Marked snapshot as promoted: id=%s", snapshot_id)
        return result


def list_snapshots_needing_embedding(
    db: Database,
    org_id: str,
    *,
    limit: int = 100,
) -> List[SnapshotOut]:
    """
    List snapshots that need embedding generation (for deferred embedding strategy).

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        limit: Maximum number of results

    Returns:
        List of SnapshotOut documents without embeddings

    Raises:
        DatabaseOperationError: If the query fails.
    """
    return list_snapshots(
        db,
        org_id,
        has_embedding=False,
        include_deleted=False,
        limit=limit,
        sort_descending=False,  # Process oldest first
    )
