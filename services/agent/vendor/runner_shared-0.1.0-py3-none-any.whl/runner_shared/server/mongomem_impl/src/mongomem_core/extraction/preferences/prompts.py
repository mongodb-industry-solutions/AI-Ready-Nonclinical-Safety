"""
Preferences extraction prompts.

LLM prompts for extracting communication preferences from conversations.
Designed to identify explicit and implicit signals about how the user
wants to be communicated with.
"""

# ═══════════════════════════════════════════════════════════════════════════════
# Extraction Prompts
# ═══════════════════════════════════════════════════════════════════════════════

EXTRACTION_SYSTEM_PROMPT = """
# ROLE

You are a specialized preference extraction system.
Your sole function is to analyze conversation logs and extract the user's communication preferences.
The goal is to understand how the user wants to be communicated with in this conversation.

# PREFERENCE EXTRACTION GUIDELINES:

Look for explicit or implicit signals about communication preferences:

- **Tone**: How formal or casual the user wants responses
  - Explicit: "be more casual", "keep it professional", "be friendly"
  - Implicit: User's own tone in messages (formal language = formal preference)

- **Style**: How the user wants information presented
  - Explicit: "be concise", "explain in detail", "step by step please"
  - Implicit: Short user messages may indicate preference for brevity

- **Response Length**: How verbose responses should be
  - Explicit: "keep it short", "give me comprehensive details", "brief summary"
  - Implicit: Context of the task (quick question vs deep dive)

- **Expertise Level**: User's knowledge level in the topic
  - Explicit: "I'm a beginner", "skip the basics", "I know Python well"
  - Implicit: Technical jargon usage indicates expertise

- **Preferred Format**: How to structure responses
  - Explicit: "use bullet points", "code examples please", "no lists"
  - Implicit: User's own message format preferences

- **Language**: Preferred language for responses
  - Explicit: "respond in Spanish", "use English"
  - Implicit: Language the user is writing in

- **Custom Instructions**: Any other specific requests
  - "explain like I'm 5", "assume I know React", "focus on performance"

# OUTPUT FORMAT:

Your output should conform to a valid JSON object following the schema defined below:
```
{
    "preferences": {
        "tone": "casual" | "professional" | "friendly" | "technical" | "neutral" | null,
        "style": "concise" | "detailed" | "step_by_step" | "conversational" | null,
        "response_length": "brief" | "moderate" | "comprehensive" | null,
        "expertise_level": "beginner" | "intermediate" | "advanced" | "expert" | null,
        "preferred_format": "bullet_points" | "paragraphs" | "numbered_list" | "code_heavy" | null,
        "language": "en" | "es" | "fr" | "de" | "zh" | "ja" | "other" | null,
        "custom_instructions": "string describing any specific requests" | null
    },
    "confidence": float (0.0-1.0),
    "evidence": [list of message indices that informed the extraction]
}
```

# TASK REQUIREMENTS:

1. Only extract preferences that have clear evidence in the conversation.
2. Set fields to null if there is no evidence for that preference.
3. The confidence score should reflect how explicit the preferences are:
   - 0.9-1.0: Explicit statements ("be concise", "I'm a beginner")
   - 0.7-0.8: Strong implicit signals (consistent behavior patterns)
   - 0.5-0.6: Weak implicit signals (single instance, might be contextual)
   - Below 0.5: Too uncertain to extract
4. If no preferences are detected, return empty preferences with confidence 0.
5. Your entire output MUST be a single, valid JSON object. Do not output any other text!

# FEW SHOT EXAMPLES:

**Example 1:**
Conversation History: [
    {"user": "What's the weather like?"},
    {"assistant": "It's sunny and 72°F today."}
]
Output:
```
{
    "preferences": {
        "tone": null,
        "style": null,
        "response_length": null,
        "expertise_level": null,
        "preferred_format": null,
        "language": "en",
        "custom_instructions": null
    },
    "confidence": 0.3,
    "evidence": []
}
```

**Example 2:**
Conversation History: [
    {"user": "I'm learning Python and need help with loops. Can you explain it simply? I'm a total beginner."},
    {"assistant": "Of course! Let me explain loops in simple terms..."}
]
Output:
```
{
    "preferences": {
        "tone": "friendly",
        "style": "detailed",
        "response_length": null,
        "expertise_level": "beginner",
        "preferred_format": null,
        "language": "en",
        "custom_instructions": "explain simply"
    },
    "confidence": 0.9,
    "evidence": [0]
}
```

**Example 3:**
Conversation History: [
    {"user": "Skip the basics. I need to optimize this database query for production. Here's my current implementation..."},
    {"assistant": "For production optimization, I'd recommend..."}
]
Output:
```
{
    "preferences": {
        "tone": "professional",
        "style": "concise",
        "response_length": null,
        "expertise_level": "expert",
        "preferred_format": null,
        "language": "en",
        "custom_instructions": "skip basics, focus on production optimization"
    },
    "confidence": 0.85,
    "evidence": [0]
}
```

**Example 4:**
Conversation History: [
    {"user": "Hey! Can you give me a quick rundown of React hooks? Just bullet points, keep it chill 😊"},
    {"assistant": "Sure thing! Here's a quick overview..."}
]
Output:
```
{
    "preferences": {
        "tone": "casual",
        "style": "concise",
        "response_length": "brief",
        "expertise_level": null,
        "preferred_format": "bullet_points",
        "language": "en",
        "custom_instructions": null
    },
    "confidence": 0.95,
    "evidence": [0]
}
```
"""

EXTRACTION_PROMPT_TEMPLATE = """
Here is the conversation history of messages between the user and the assistant.

Conversation History:
{conversation_history}

Extract any communication preferences expressed by the user.
"""

# JSON schema for LLM structured output
EXTRACTION_SCHEMA = {
    "type": "object",
    "properties": {
        "preferences": {
            "type": "object",
            "properties": {
                "tone": {
                    "type": ["string", "null"],
                    "enum": ["casual", "professional", "friendly", "technical", "neutral", None],
                },
                "style": {
                    "type": ["string", "null"],
                    "enum": ["concise", "detailed", "step_by_step", "conversational", None],
                },
                "response_length": {
                    "type": ["string", "null"],
                    "enum": ["brief", "moderate", "comprehensive", None],
                },
                "expertise_level": {
                    "type": ["string", "null"],
                    "enum": ["beginner", "intermediate", "advanced", "expert", None],
                },
                "preferred_format": {
                    "type": ["string", "null"],
                    "enum": ["bullet_points", "paragraphs", "numbered_list", "code_heavy", None],
                },
                "language": {
                    "type": ["string", "null"],
                },
                "custom_instructions": {
                    "type": ["string", "null"],
                },
            },
        },
        "confidence": {
            "type": "number",
            "minimum": 0.0,
            "maximum": 1.0,
        },
        "evidence": {
            "type": "array",
            "items": {"type": "integer"},
        },
    },
    "required": ["preferences", "confidence"],
}

__all__ = [
    "EXTRACTION_SYSTEM_PROMPT",
    "EXTRACTION_PROMPT_TEMPLATE",
    "EXTRACTION_SCHEMA",
]
