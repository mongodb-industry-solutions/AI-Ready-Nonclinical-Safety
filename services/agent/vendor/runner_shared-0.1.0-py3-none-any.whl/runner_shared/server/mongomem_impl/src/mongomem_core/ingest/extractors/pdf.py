"""
PDF text extractor using PyMuPDF (fitz).

Handles .pdf files with text extraction from all pages.
Tracks page boundaries for accurate page number attribution.
"""

import logging
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple

logger = logging.getLogger(__name__)


class PyMuPDFExtractor:
    """PDF text extractor using PyMuPDF (fitz)."""

    @property
    def supported_extensions(self) -> Set[str]:
        return {".pdf"}

    def extract(self, file_path: Path) -> str:
        """Extract text from all pages of a PDF."""
        import fitz  # PyMuPDF

        text_parts = []
        with fitz.open(file_path) as doc:
            for page in doc:
                page_text = page.get_text()
                if page_text.strip():
                    text_parts.append(page_text)

        return "\n\n".join(text_parts)

    def extract_with_metadata(self, file_path: Path) -> Dict[str, Any]:
        """Extract text and metadata from a PDF, including page boundaries."""
        import fitz  # PyMuPDF

        text_parts = []
        page_boundaries: List[Tuple[int, int, int]] = []  # (page_num, start_char, end_char)
        current_pos = 0

        with fitz.open(file_path) as doc:
            metadata = doc.metadata or {}
            page_count = len(doc)

            for page_num, page in enumerate(doc, start=1):
                page_text = page.get_text()
                if page_text.strip():
                    start_pos = current_pos
                    text_parts.append(page_text)
                    # Account for the "\n\n" separator between pages
                    if current_pos > 0:
                        current_pos += 2  # For "\n\n"
                    end_pos = current_pos + len(page_text)
                    page_boundaries.append(
                        (page_num, start_pos if start_pos == 0 else start_pos + 2, end_pos)
                    )
                    current_pos = end_pos

        text = "\n\n".join(text_parts)

        return {
            "text": text,
            "metadata": {
                "source_type": "pdf",
                "page_count": page_count,
                "title": metadata.get("title") or None,
                "author": metadata.get("author") or None,
                "subject": metadata.get("subject") or None,
                "creator": metadata.get("creator") or None,
            },
            "page_boundaries": page_boundaries,  # For chunk page attribution
        }
