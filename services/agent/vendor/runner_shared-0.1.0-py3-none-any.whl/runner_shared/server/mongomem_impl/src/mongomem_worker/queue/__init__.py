"""
Task queue for distributed worker processing.

Provides:
- `enqueue_task`: Add tasks to the queue
- `TaskQueueProcessor`: Process tasks with lease-based claiming
- Error-aware retry logic with exponential backoff
"""

from .models import ClaimedTask, EnqueuedTask, TaskStatus
from .operations import (
    claim_task,
    complete_task,
    enqueue_task,
    extend_lease,
    heartbeat_task,
    move_to_dlq,
    requeue_stale_tasks,
)
from .processor import TaskQueueProcessor

__all__ = [
    # Models
    "EnqueuedTask",
    "ClaimedTask",
    "TaskStatus",
    # Operations
    "enqueue_task",
    "claim_task",
    "complete_task",
    "heartbeat_task",
    "extend_lease",
    "requeue_stale_tasks",
    "move_to_dlq",
    # Processor
    "TaskQueueProcessor",
]
