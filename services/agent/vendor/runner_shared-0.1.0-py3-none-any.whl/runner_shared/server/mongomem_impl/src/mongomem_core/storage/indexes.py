"""
Index definitions for ``mongomem_core`` collections.

This module provides a **structural** description of the indexes we expect on
each collection.  It does *not* talk to MongoDB directly – execution of these
definitions (e.g. calling ``create_index``) will live in startup helpers or
migration code.

The goal is to mirror the index surfaces from the existing ExoMemory
``init_collections`` module and ``app.db.connection`` constants for all
engine‑domain collections, while keeping the representation **data‑only** so
that it can be inspected and tested without a live database.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Sequence, Tuple

from pymongo import ASCENDING, DESCENDING

from .collections import (
    EntitiesCollection,
    EntityEdgesCollection,
    EntityProfilesCollection,
    EntitySearchCollection,
    EpisodicMemoryCollection,
    ExtractionPendingCollection,
    FactsArchiveCollection,
    FactsCollection,
    InternalStateCollection,
    MemoryPooledRegistryCollection,
    MemorySessionsCollection,
    MemoryUserContextCollection,
    PersonaMemoryCollection,
    ProceduralMemoryCollection,
    SemanticMemoryCollection,
    SessionCountersCollection,
    ShortTermMemoryCollection,
    SnapshotMemoryCollection,
    TaxonomicMemoryCollection,
)

IndexKey = Sequence[Tuple[str, int]]


@dataclass(frozen=True)
class IndexDefinition:
    """
    Structural description of a single MongoDB index.

    This intentionally mirrors the parameters to ``Collection.create_index``,
    but we keep it as simple value data so it can be inspected and tested
    without a live database.
    """

    keys: IndexKey
    name: str
    unique: bool = False
    sparse: bool = False
    ttl_seconds: int | None = None
    partial_filter: Mapping[str, Any] | None = None
    background: bool = False
    comment: str | None = None
    # Additional options (e.g. collation, weights, etc.) can be added later.

    def to_create_index_kwargs(self) -> Dict[str, Any]:
        """
        Render this definition into keyword arguments suitable for
        ``Collection.create_index``.
        """

        kwargs: MutableMapping[str, Any] = {"name": self.name}
        if self.unique:
            kwargs["unique"] = True
        if self.sparse:
            kwargs["sparse"] = True
        if self.ttl_seconds is not None:
            kwargs["expireAfterSeconds"] = self.ttl_seconds
        if self.partial_filter is not None:
            kwargs["partialFilterExpression"] = dict(self.partial_filter)
        if self.background:
            kwargs["background"] = True
        # Note: `comment` is for documentation only; MongoDB's createIndexes
        # command does not support `comment` as an index specification option
        return dict(kwargs)


@dataclass(frozen=True)
class CollectionIndexes:
    """
    All index definitions for a single collection.

    For now we only include a **minimal subset** of indexes that are clearly
    part of the headless engine (memory + TKG).  More can be added as we port
    behaviour from the legacy ``init_collections``.
    """

    collection_name: str
    indexes: List[IndexDefinition]


# ---------------------------------------------------------------------------
# Memory collections
# ---------------------------------------------------------------------------


MEMORY_SHORT_TERM_INDEXES = CollectionIndexes(
    collection_name=ShortTermMemoryCollection.name,
    indexes=[
        # Primary read path: recent turns in a session (get_recent_stm).
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("session_id", ASCENDING),
                ("timestamp", DESCENDING),
            ],
            name="st_session_time",
            comment="Primary session-scoped read (timestamp desc)",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("session_id", ASCENDING),
                ("user_id", ASCENDING),
                ("timestamp", ASCENDING),
            ],
            name="st_promotion_query",
            comment="Promotion/pair-preservation reads (timestamp asc)",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("session_id", ASCENDING),
                ("visibility", ASCENDING),
                ("user_id", ASCENDING),
                ("timestamp", DESCENDING),
            ],
            name="st_fetch_private_user",
            partial_filter={"visibility": "PRIVATE"},
            comment="Private session reads (timestamp desc)",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("session_id", ASCENDING),
                ("visibility", ASCENDING),
                ("project_id", ASCENDING),
                ("timestamp", DESCENDING),
            ],
            name="st_fetch_shared_group",
            partial_filter={"visibility": "SHARED"},
            comment="Shared-group session reads (timestamp desc)",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("session_id", ASCENDING),
                ("turn_seq", ASCENDING),
            ],
            name="st_turn_sequence_ordering",
            partial_filter={"turn_seq": {"$exists": True}},
            comment=("Partial index for STM entries with turn sequence (topic detection)"),
        ),
        # Multi-agent support: efficiently filter/exclude by agent_id in group chat scenarios.
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("session_id", ASCENDING),
                ("agent_id", ASCENDING),
                ("timestamp", DESCENDING),
            ],
            name="st_session_agent_time",
            comment="Agent-scoped session reads for multi-agent group chat filtering",
        ),
        # Worker polling fallback (standalone MongoDB): efficiently find backlog docs missing embeddings.
        IndexDefinition(
            keys=[("timestamp", ASCENDING), ("_embedding_claimed_at", ASCENDING)],
            name="st_embedding_backlog",
            partial_filter={"has_embedding": False},
            comment="Embedding backlog scan support (polling fallback)",
        ),
    ],
)

MEMORY_SEMANTIC_INDEXES = CollectionIndexes(
    collection_name=SemanticMemoryCollection.name,
    indexes=[
        IndexDefinition(
            keys=[("org_id", ASCENDING), ("label", ASCENDING)],
            name="sem_label_org",
            unique=True,
        ),
        # Idempotency: critical for worker/extraction flows.
        IndexDefinition(
            keys=[("extraction_id", ASCENDING), ("org_id", ASCENDING)],
            name="sem_extraction_idempotency",
            unique=True,
            partial_filter={"extraction_id": {"$type": "string"}},
            comment=(
                "Unique idempotency key for extraction writes (partial: only docs with extraction_id)"
            ),
        ),
        # Listing: align with code paths that sort by updated_at.
        IndexDefinition(
            keys=[("org_id", ASCENDING), ("updated_at", DESCENDING)],
            name="sem_org_updated_at",
            comment="Primary org-scoped listing index (sort by updated_at desc)",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("visibility", ASCENDING),
                ("user_id", ASCENDING),
                ("updated_at", DESCENDING),
            ],
            name="sem_private_user_updated",
            partial_filter={"visibility": "PRIVATE"},
            comment="Private semantic listing for a user (updated_at desc)",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("visibility", ASCENDING),
                ("project_id", ASCENDING),
                ("updated_at", DESCENDING),
            ],
            name="sem_shared_group_updated",
            partial_filter={"visibility": "SHARED"},
            comment="Shared semantic listing for a group (updated_at desc)",
        ),
        # Entity tagging: keep a single primary entity_ids index.
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("metadata.entity_ids", ASCENDING),
                ("visibility", ASCENDING),
                ("updated_at", DESCENDING),
            ],
            name="sem_entity_ids_rbac_time",
            partial_filter={"hasEntity": True},
            background=True,
            comment="Entity-filtered queries with RBAC + time ordering",
        ),
        # Publishing: important for cross-group knowledge sharing.
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("publishing.published", ASCENDING),
                ("publishing.revoked_at", ASCENDING),
                ("publishing.published_scope", ASCENDING),
                ("publishing.published_by_project", ASCENDING),
                ("publishing.published_at", DESCENDING),
            ],
            name="sem_publishing_compound",
            partial_filter={
                "publishing.published": True,
                "publishing.revoked_at": None,
            },
            comment="Published semantic knowledge queries with scope/project + recency",
        ),
        # Versioning correctness (keep if using is_latest semantics).
        IndexDefinition(
            keys=[
                ("memory_lineage_id", ASCENDING),
                ("is_latest", ASCENDING),
            ],
            name="sem_lineage_latest_unique",
            unique=True,
            partial_filter={"is_latest": True},
            comment="Ensures only one active version per memory lineage",
        ),
        # Worker polling fallback: claim-by-timestamp for missing embeddings.
        IndexDefinition(
            keys=[("timestamp", ASCENDING), ("_embedding_claimed_at", ASCENDING)],
            name="sem_embedding_backlog",
            partial_filter={"has_embedding": False},
            comment="Embedding backlog scan support (polling fallback)",
        ),
    ],
)

MEMORY_EPISODIC_INDEXES = CollectionIndexes(
    collection_name=EpisodicMemoryCollection.name,
    indexes=[
        # Listing: align with list_episodic(...) sort by timestamp.
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("visibility", ASCENDING),
                ("user_id", ASCENDING),
                ("timestamp", DESCENDING),
            ],
            name="epi_private_user_scope",
            partial_filter={"visibility": "PRIVATE"},
            comment="Private episodic listing for a user (timestamp desc)",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("visibility", ASCENDING),
                ("project_id", ASCENDING),
                ("timestamp", DESCENDING),
            ],
            name="epi_shared_group_scope",
            partial_filter={"visibility": "SHARED"},
            comment="Shared episodic listing for a group (timestamp desc)",
        ),
        IndexDefinition(
            keys=[("org_id", ASCENDING), ("timestamp", ASCENDING)],
            name="epi_org_temporal_base",
            comment=(
                "Base index for org-scoped temporal queries (covers session and tag "
                "queries as prefix)"
            ),
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("session_id", ASCENDING),
                ("timestamp", ASCENDING),
            ],
            name="epi_session_timestamp_range",
            comment="Specialized index for session-scoped temporal queries",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("session_id", ASCENDING),
                ("snapshot_ref_id", ASCENDING),
            ],
            name="epi_session_snapshot_unique",
            unique=True,
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("tags", ASCENDING),
                ("timestamp", DESCENDING),
            ],
            name="epi_tags_temporal",
            partial_filter={"tags": {"$exists": True}},
            comment="Partial index for episodic entries with tags",
        ),
        # Idempotency: critical for worker/extraction flows.
        IndexDefinition(
            keys=[("extraction_id", ASCENDING), ("org_id", ASCENDING)],
            name="epi_extraction_idempotency",
            unique=True,
            partial_filter={"extraction_id": {"$type": "string"}},
            comment=(
                "Unique idempotency key for extraction writes (partial: only docs with extraction_id)"
            ),
        ),
        # Entity tagging: keep a single primary entity_ids index.
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("metadata.entity_ids", ASCENDING),
                ("visibility", ASCENDING),
                ("timestamp", DESCENDING),
            ],
            name="epi_entity_ids_rbac_time",
            partial_filter={"hasEntity": True},
            background=True,
            comment="Entity-filtered queries with RBAC + time ordering",
        ),
        # Publishing: important for cross-group knowledge sharing.
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("publishing.published", ASCENDING),
                ("publishing.revoked_at", ASCENDING),
                ("publishing.published_scope", ASCENDING),
                ("publishing.published_by_project", ASCENDING),
                ("publishing.published_at", DESCENDING),
            ],
            name="epi_publishing_compound",
            partial_filter={
                "publishing.published": True,
                "publishing.revoked_at": None,
            },
            comment="Published episodic knowledge queries with scope/project + recency",
        ),
        # Worker polling fallback: claim-by-timestamp for missing embeddings.
        IndexDefinition(
            keys=[("timestamp", ASCENDING), ("_embedding_claimed_at", ASCENDING)],
            name="epi_embedding_backlog",
            partial_filter={"has_embedding": False},
            comment="Embedding backlog scan support (polling fallback)",
        ),
    ],
)

MEMORY_SNAPSHOT_INDEXES = CollectionIndexes(
    collection_name=SnapshotMemoryCollection.name,
    indexes=[
        IndexDefinition(
            keys=[("expires_at", ASCENDING)],
            name="snap_ttl",
            ttl_seconds=0,
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("session_id", ASCENDING),
                ("timestamp", DESCENDING),
            ],
            name="snap_session_org_time",
            comment="Primary session-scoped listing index (timestamp desc)",
        ),
        IndexDefinition(
            keys=[("promoted", ASCENDING), ("expires_at", ASCENDING)],
            name="snap_celery_cleanup",
            comment="Celery-specific cleanup index for unpromoted expired snapshots",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("session_id", ASCENDING),
                ("boundary_turn_seq", ASCENDING),
            ],
            name="snap_session_boundary_unique",
            unique=True,
            sparse=True,
            comment=("Unique index for async topic detection snapshot deduplication"),
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("has_embedding", ASCENDING),
                ("timestamp", ASCENDING),
            ],
            name="snap_deferred_embedding",
            partial_filter={"has_embedding": False},
            comment="Partial index for snapshots needing deferred embedding generation",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("user_id", ASCENDING),
                ("timestamp", DESCENDING),
            ],
            name="snap_org_user_time",
            comment="Index for user-scoped snapshot queries",
        ),
        # Worker polling fallback for deferred embeddings (standalone MongoDB).
        IndexDefinition(
            keys=[("embedding_strategy", ASCENDING), ("timestamp", ASCENDING)],
            name="snap_embedding_backlog",
            partial_filter={"has_embedding": False},
            comment="Snapshot embedding backlog scan support (polling fallback)",
        ),
    ],
)

MEMORY_TAXONOMIC_INDEXES = CollectionIndexes(
    collection_name=TaxonomicMemoryCollection.name,
    indexes=[
        # Multi-tenant lookup: most queries specify org_id.
        IndexDefinition(
            keys=[("org_id", ASCENDING), ("domain", ASCENDING), ("term", ASCENDING)],
            name="tax_domain_term_org",
            unique=True,
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("domain", ASCENDING),
                ("visibility", ASCENDING),
            ],
            name="tax_domain_scope_query",
        ),
        # Listing: aligns with list_taxonomic(...) default sort by updated_at.
        IndexDefinition(
            keys=[("org_id", ASCENDING), ("updated_at", DESCENDING)],
            name="tax_org_updated_at",
            comment="Primary org-scoped listing index (sort by updated_at desc)",
        ),
        # Idempotency: critical for worker/extraction flows.
        IndexDefinition(
            keys=[("extraction_id", ASCENDING), ("org_id", ASCENDING)],
            name="tax_extraction_idempotency",
            unique=True,
            partial_filter={"extraction_id": {"$type": "string"}},
            comment="Unique idempotency key for extraction writes (partial: only docs with extraction_id)",
        ),
        # Publishing: important for cross-group knowledge sharing.
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("publishing.published", ASCENDING),
                ("publishing.revoked_at", ASCENDING),
                ("publishing.published_scope", ASCENDING),
                ("publishing.published_by_project", ASCENDING),
                ("publishing.published_at", DESCENDING),
            ],
            name="tax_publishing_compound",
            partial_filter={
                "publishing.published": True,
                "publishing.revoked_at": None,
            },
            comment="Published taxonomic knowledge queries with scope/project + recency",
        ),
        # Worker polling fallback: claim-by-timestamp for missing embeddings.
        IndexDefinition(
            keys=[("timestamp", ASCENDING), ("_embedding_claimed_at", ASCENDING)],
            name="tax_embedding_backlog",
            partial_filter={"has_embedding": False},
            comment="Embedding backlog scan support (polling fallback)",
        ),
    ],
)

MEMORY_PROCEDURAL_INDEXES = CollectionIndexes(
    collection_name=ProceduralMemoryCollection.name,
    indexes=[
        IndexDefinition(
            keys=[("procedure", ASCENDING), ("org_id", ASCENDING)],
            name="proc_procedure_org",
            unique=True,
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("visibility", ASCENDING),
                ("updated_at", DESCENDING),
            ],
            name="proc_org_visibility_time",
            comment="Base index for procedural queries with RBAC and temporal ordering",
        ),
        IndexDefinition(
            keys=[
                ("user_id", ASCENDING),
                ("visibility", ASCENDING),
                ("updated_at", DESCENDING),
            ],
            name="proc_private_user_updated",
            partial_filter={"visibility": "PRIVATE"},
        ),
        IndexDefinition(
            keys=[
                ("project_id", ASCENDING),
                ("visibility", ASCENDING),
                ("updated_at", DESCENDING),
            ],
            name="proc_shared_group_updated",
            partial_filter={"visibility": "SHARED"},
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("publishing.published", ASCENDING),
                ("publishing.revoked_at", ASCENDING),
                ("publishing.published_scope", ASCENDING),
                ("publishing.published_by_project", ASCENDING),
                ("publishing.published_at", DESCENDING),
            ],
            name="proc_publishing_compound",
            partial_filter={
                "publishing.published": True,
                "publishing.revoked_at": None,
            },
            comment="Published procedural knowledge queries with scope/project + recency",
        ),
        IndexDefinition(
            keys=[("memory_lineage_id", ASCENDING)],
            name="proc_lineage_latest_unique",
            unique=True,
            partial_filter={
                "is_latest": True,
                "memory_lineage_id": {"$type": "string"},
            },
            comment="Ensures only one active version per memory lineage",
        ),
        IndexDefinition(
            keys=[("timestamp", ASCENDING), ("_embedding_claimed_at", ASCENDING)],
            name="proc_embedding_backlog",
            partial_filter={"has_embedding": False},
            comment="Embedding backlog scan support (polling fallback)",
        ),
        IndexDefinition(
            keys=[("org_id", ASCENDING), ("tags", ASCENDING)],
            name="proc_tags",
            comment="Tag-based filtering for procedural queries",
        ),
    ],
)

MEMORY_USER_CONTEXT_INDEXES = CollectionIndexes(
    collection_name=MemoryUserContextCollection.name,
    indexes=[
        IndexDefinition(
            keys=[("user_id", ASCENDING), ("org_id", ASCENDING)],
            name="mem_user_context_unique",
            unique=True,
        ),
        IndexDefinition(
            keys=[
                ("user_id", ASCENDING),
                ("org_id", ASCENDING),
                ("timestamp", DESCENDING),
            ],
            name="mem_user_context_user_org_ts",
        ),
        IndexDefinition(
            keys=[
                ("project_id", ASCENDING),
                ("org_id", ASCENDING),
                ("timestamp", DESCENDING),
            ],
            name="mem_user_context_group_org_ts",
        ),
    ],
)

MEMORY_SESSIONS_INDEXES = CollectionIndexes(
    collection_name=MemorySessionsCollection.name,
    indexes=[
        IndexDefinition(
            keys=[("session_id", ASCENDING), ("org_id", ASCENDING)],
            name="sessions_session_org_unique",
            unique=True,
            comment="Unique index for session identification within organization",
        ),
        IndexDefinition(
            keys=[
                ("user_id", ASCENDING),
                ("org_id", ASCENDING),
                ("last_activity", DESCENDING),
            ],
            name="sessions_user_org_activity",
            comment="Index for user's session list ordered by recent activity",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("status", ASCENDING),
                ("last_activity", DESCENDING),
            ],
            name="sessions_org_status_activity",
            comment="Index for organizational session queries with status filter",
        ),
        IndexDefinition(
            keys=[
                ("agent_id", ASCENDING),
                ("org_id", ASCENDING),
                ("last_activity", DESCENDING),
            ],
            name="sessions_agent_org_activity",
            sparse=True,
            comment="Sparse index for agent-specific session queries",
        ),
        IndexDefinition(
            keys=[
                ("visibility", ASCENDING),
                ("project_id", ASCENDING),
                ("org_id", ASCENDING),
                ("last_activity", DESCENDING),
            ],
            name="sessions_visibility_group_org_activity",
            comment="Index for group-based session queries",
        ),
        IndexDefinition(
            keys=[("org_id", ASCENDING), ("created_at", DESCENDING)],
            name="sessions_org_created",
            comment="Index for sessions sorted by creation date",
        ),
    ],
)

PERSONA_MEMORY_INDEXES = CollectionIndexes(
    collection_name=PersonaMemoryCollection.name,
    indexes=[
        IndexDefinition(
            keys=[("persona_id", ASCENDING), ("org_id", ASCENDING)],
            name="persona_id_org",
            unique=True,
        ),
        IndexDefinition(
            keys=[("org_id", ASCENDING), ("visibility", ASCENDING)],
            name="persona_org_visibility",
        ),
        IndexDefinition(
            keys=[("user_id", ASCENDING), ("org_id", ASCENDING)],
            name="persona_user_org",
        ),
    ],
)

MEMORY_POOLED_REGISTRY_INDEXES = CollectionIndexes(
    collection_name=MemoryPooledRegistryCollection.name,
    indexes=[
        IndexDefinition(
            keys=[("project_id", ASCENDING)],
            name="mp_group",
            unique=True,
        ),
        IndexDefinition(
            keys=[("members", ASCENDING)],
            name="mp_members",
        ),
        IndexDefinition(
            keys=[("linked_agent_id", ASCENDING), ("org_id", ASCENDING)],
            name="mp_linked_agent_org",
        ),
        IndexDefinition(
            keys=[("group_type", ASCENDING)],
            name="mp_group_type",
        ),
    ],
)


# ---------------------------------------------------------------------------
# Entity / TKG collections
# ---------------------------------------------------------------------------


ENTITIES_INDEXES = CollectionIndexes(
    collection_name=EntitiesCollection.name,
    indexes=[
        IndexDefinition(
            keys=[("org_id", ASCENDING)],
            name="shard_key",
            comment="Shard key for distribution",
        ),
        IndexDefinition(
            keys=[("org_id", ASCENDING), ("canonical_slug", ASCENDING)],
            name="org_slug_unique",
            unique=True,
            comment="Primary lookup by org and slug",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("keys_hash.email", ASCENDING),
            ],
            name="email_lookup",
            sparse=True,
            comment="Email-based entity lookup",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("visibility", ASCENDING),
                ("owner_id", ASCENDING),
            ],
            name="rbac_private",
            comment="RBAC filtering for private entities",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("visibility", ASCENDING),
                ("project_id", ASCENDING),
            ],
            name="rbac_shared",
            sparse=True,
            comment="RBAC filtering for shared entities",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("type", ASCENDING),
                ("updated_at", DESCENDING),
            ],
            name="type_recency",
            comment="Type-based filtering with recency",
        ),
        IndexDefinition(
            keys=[("org_id", ASCENDING), ("aliases", ASCENDING)],
            name="alias_lookup",
            comment="Alias-based entity resolution",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("is_active", ASCENDING),
                ("canonical_name", ASCENDING),
            ],
            name="gazetteer_warmup",
            comment=(
                "Query Understanding V1: Gazetteer warmup query (org_id + is_active "
                "filter + canonical_name sort)"
            ),
        ),
    ],
)

ENTITY_PROFILES_INDEXES = CollectionIndexes(
    collection_name=EntityProfilesCollection.name,
    indexes=[
        IndexDefinition(
            keys=[("org_id", ASCENDING)],
            name="shard_key",
            comment="Shard key for distribution",
        ),
        IndexDefinition(
            keys=[("org_id", ASCENDING), ("_id", ASCENDING)],
            name="primary_lookup",
            comment="Primary key lookup",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("current.works_at", ASCENDING),
            ],
            name="works_at_index",
            sparse=True,
            comment="Common predicate query optimization",
        ),
        IndexDefinition(
            keys=[("doc_size_bytes", DESCENDING)],
            name="size_monitor",
            sparse=True,
            comment="Monitor document growth",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("visibility", ASCENDING),
                ("updated_at", DESCENDING),
            ],
            name="rbac_recency",
            comment="RBAC filtering with recency",
        ),
    ],
)

ENTITY_EDGES_INDEXES = CollectionIndexes(
    collection_name=EntityEdgesCollection.name,
    indexes=[
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("from_entity_id", ASCENDING),
                ("predicate", ASCENDING),
            ],
            name="forward_traversal",
            comment="Forward graph traversal for $graphLookup",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("to_entity_id", ASCENDING),
                ("predicate", ASCENDING),
            ],
            name="backward_traversal",
            comment="Backward/inverse graph traversal",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("from_entity_id", ASCENDING),
                ("predicate", ASCENDING),
                ("to_entity_id", ASCENDING),
            ],
            name="edge_unique",
            unique=True,
            comment="Prevent duplicate edges",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("visibility", ASCENDING),
                ("confidence", DESCENDING),
            ],
            name="rbac_quality",
            comment="RBAC filtering with confidence ordering",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("predicate", ASCENDING),
                ("confidence", DESCENDING),
                ("updated_at", DESCENDING),
            ],
            name="predicate_quality",
            comment=("Predicate-specific queries with quality and recency"),
        ),
    ],
)

FACTS_INDEXES = CollectionIndexes(
    collection_name=FactsCollection.name,
    indexes=[
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("subject_id", ASCENDING),
                ("predicate", ASCENDING),
                ("valid_from", DESCENDING),
                ("valid_until", ASCENDING),
            ],
            name="hot_path_current_temporal",
            partial_filter={"valid_until": None},
            comment=("Optimized for current fact lookups (90% of queries)"),
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("visibility", ASCENDING),
                ("valid_from", DESCENDING),
                ("confidence", DESCENDING),
            ],
            name="rbac_temporal_confidence",
            comment="RBAC filtering with temporal ordering and confidence",
        ),
        IndexDefinition(
            keys=[("idempotency_key", ASCENDING)],
            name="idempotency",
            unique=True,
            sparse=True,
            comment="Prevents duplicate fact insertion",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("subject_id", ASCENDING),
                ("predicate", ASCENDING),
                ("is_conflict", ASCENDING),
            ],
            name="idx_conflicts_by_entity_predicate",
            partial_filter={"is_conflict": True},
            background=True,
            comment=("Optimized conflict queries (partial index for rare conflicts)"),
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("subject_id", ASCENDING),
                ("predicate", ASCENDING),
                ("valid_from", ASCENDING),
                ("valid_until", ASCENDING),
            ],
            name="idx_temporal_overlap_detection",
            background=True,
            comment=("Optimize temporal overlap detection for conflict marking"),
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("subject_id", ASCENDING),
                ("predicate", ASCENDING),
                ("is_current", ASCENDING),
            ],
            name="facts_current_lookup",
            comment="Fast lookup for current facts by predicate",
        ),
    ],
)

FACTS_ARCHIVE_INDEXES = CollectionIndexes(
    collection_name=FactsArchiveCollection.name,
    indexes=[
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("entity_id", ASCENDING),
                ("period", DESCENDING),
            ],
            name="bucket_lookup",
            comment="Time-series bucketing for archive retrieval",
        ),
        IndexDefinition(
            keys=[("period", DESCENDING)],
            name="retention_policy",
            ttl_seconds=365 * 24 * 60 * 60,
            comment="TTL index for 1 year retention",
        ),
    ],
)

ENTITY_SEARCH_INDEXES = CollectionIndexes(
    collection_name=EntitySearchCollection.name,
    indexes=[
        IndexDefinition(
            keys=[("org_id", ASCENDING), ("_id", ASCENDING)],
            name="primary",
            comment="Primary key lookup",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("visibility", ASCENDING),
                ("data_classification", ASCENDING),
            ],
            name="rbac_filter",
            comment=("RBAC filtering for Atlas Search compound filters"),
        ),
        IndexDefinition(
            keys=[("updated_at", DESCENDING)],
            name="freshness",
            comment="Monitor sync lag",
        ),
    ],
)


# ---------------------------------------------------------------------------
# Engine-level configuration / control collections
# ---------------------------------------------------------------------------


SESSION_COUNTERS_INDEXES = CollectionIndexes(
    collection_name=SessionCountersCollection.name,
    indexes=[
        IndexDefinition(
            keys=[("session_id", ASCENDING), ("org_id", ASCENDING)],
            name="session_counters_unique",
            unique=True,
            comment=("Unique index for atomic turn sequence generation per session and org"),
        ),
        IndexDefinition(
            keys=[("updated_at", ASCENDING)],
            name="session_counters_cleanup",
            comment="Index for periodic cleanup of old session counters",
        ),
    ],
)


# ---------------------------------------------------------------------------
# Internal Working Memory (IWM)
# ---------------------------------------------------------------------------


INTERNAL_STATE_INDEXES = CollectionIndexes(
    collection_name=InternalStateCollection.name,
    indexes=[
        IndexDefinition(
            keys=[
                ("session_id", ASCENDING),
                ("org_id", ASCENDING),
                ("agent_id", ASCENDING),
            ],
            name="session_org_agent_unique",
            unique=True,
            comment="Primary unique key: one IS document per (org_id, session_id, agent_id) for multi-agent support",
        ),
        IndexDefinition(
            keys=[("org_id", ASCENDING), ("updated_at", DESCENDING)],
            name="org_updated",
            comment="Org-scoped listing sorted by recency (for admin/debug UIs)",
        ),
        IndexDefinition(
            keys=[("updated_at", ASCENDING)],
            name="updated_at_asc",
            comment="Stale session cleanup queries (oldest first)",
        ),
        IndexDefinition(
            keys=[("org_id", ASCENDING), ("last_promoted_at", ASCENDING)],
            name="org_promotion_pending",
            partial_filter={"last_promoted_at": None},
            comment="Find sessions that have never been promoted to LTM",
        ),
    ],
)


# ---------------------------------------------------------------------------
# Extraction Approval
# ---------------------------------------------------------------------------


EXTRACTION_PENDING_INDEXES = CollectionIndexes(
    collection_name=ExtractionPendingCollection.name,
    indexes=[
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("status", ASCENDING),
                ("extraction_type", ASCENDING),
            ],
            name="org_status_type",
            comment="Primary query path: pending extractions by org/type",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("user_id", ASCENDING),
                ("status", ASCENDING),
            ],
            name="org_user_status",
            comment="User-scoped pending extraction queries",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("project_id", ASCENDING),
                ("status", ASCENDING),
            ],
            name="org_group_status",
            sparse=True,
            comment="Group-scoped pending extraction queries (sparse: project_id can be None)",
        ),
        IndexDefinition(
            keys=[("source_id", ASCENDING)],
            name="source_id",
            comment="Query by source snapshot reference",
        ),
        IndexDefinition(
            keys=[("expires_at", ASCENDING)],
            name="ttl_expires_at",
            ttl_seconds=0,
            comment="TTL index: documents expire at their expires_at timestamp",
        ),
    ],
)


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


ENGINE_INDEXES: Mapping[str, CollectionIndexes] = {
    ci.collection_name: ci
    for ci in [
        # Memory
        MEMORY_SHORT_TERM_INDEXES,
        MEMORY_SEMANTIC_INDEXES,
        MEMORY_EPISODIC_INDEXES,
        MEMORY_SNAPSHOT_INDEXES,
        MEMORY_TAXONOMIC_INDEXES,
        MEMORY_PROCEDURAL_INDEXES,
        MEMORY_USER_CONTEXT_INDEXES,
        MEMORY_SESSIONS_INDEXES,
        PERSONA_MEMORY_INDEXES,
        MEMORY_POOLED_REGISTRY_INDEXES,
        # Entity / TKG
        ENTITIES_INDEXES,
        ENTITY_PROFILES_INDEXES,
        ENTITY_EDGES_INDEXES,
        FACTS_INDEXES,
        FACTS_ARCHIVE_INDEXES,
        ENTITY_SEARCH_INDEXES,
        # Engine-level control
        SESSION_COUNTERS_INDEXES,
        # Internal Working Memory
        INTERNAL_STATE_INDEXES,
        # Extraction Approval
        EXTRACTION_PENDING_INDEXES,
    ]
}


def iter_engine_indexes() -> Iterable[CollectionIndexes]:
    """
    Iterate over all index groups for the headless engine.

    Startup / migration helpers can use this to ensure indexes exist for each
    collection without needing to know about individual index names.
    """

    return ENGINE_INDEXES.values()
