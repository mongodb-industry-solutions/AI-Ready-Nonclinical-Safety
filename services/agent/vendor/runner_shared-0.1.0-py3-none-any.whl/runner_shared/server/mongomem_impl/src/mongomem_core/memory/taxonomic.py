"""CRUD and invariants for taxonomic memory.

Taxonomic memory stores domain-specific terms with definitions and embeddings
for both vector and text search. Each document represents a concept within
a domain that can be retrieved for query expansion or context enrichment.

Key differences from semantic:
- Uses domain+term as the unique key (not label)
- Supports both vector and text search
- Includes query_expansion flag for retrieval control

All functions operate synchronously against MongoDB and expect the caller to
provide necessary context (org_id, user_id, etc.).
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Sequence, Tuple, Union, overload

from bson import ObjectId
from mongomem_core.common.utils import (
    format_document_identifier,
    handle_db_error,
    handle_duplicate_key_error,
    to_object_id,
    utcnow,
)
from mongomem_core.exceptions import (
    DatabaseOperationError,
    DocumentNotFoundError,
)
from mongomem_core.memory.base import (
    BaseDocumentBuilder,
    BaseQueryBuilder,
    BaseUpdateFieldBuilder,
    doc_to_output,
    execute_vector_search,
    handle_empty_sequence,
)
from mongomem_core.models.filters import MetadataFilter
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.taxonomic import (
    TaxonomicDB,
    TaxonomicIn,
    TaxonomicOut,
    TaxonomicUpdate,
)
from mongomem_core.storage import get_collection
from mongomem_core.storage.collections import TaxonomicMemoryCollection
from mongomem_core.storage.search_indexes import TAXONOMIC_VECTOR_INDEX
from pymongo import ReturnDocument
from pymongo.database import Database
from pymongo.errors import DuplicateKeyError
from pymongo.results import DeleteResult, InsertOneResult, UpdateResult
from pymongo.synchronous.collection import Collection

logger = logging.getLogger(__name__)

_TAXONOMIC_COL = TaxonomicMemoryCollection()


def _ensure_memory_lineage_id(
    col: Collection,
    doc_id: ObjectId,
    org_id: str,
    domain: str,
    term: str,
) -> str:
    """
    Atomically ensure memory_lineage_id is set on a taxonomic document.

    Uses a single atomic operation to set the field if it's None,
    preventing race conditions. If another process has already set it,
    fetches and returns the existing value.

    Args:
        col: MongoDB collection instance
        doc_id: Document ObjectId
        org_id: Organization ID (for logging)
        domain: Domain name (for logging)
        term: Term name (for logging)

    Returns:
        The memory_lineage_id value (either newly set or existing)
    """
    memory_lineage_id = str(doc_id)

    updated = col.find_one_and_update(
        {"_id": doc_id, "memory_lineage_id": None},
        {"$set": {"memory_lineage_id": memory_lineage_id}},
        return_document=ReturnDocument.AFTER,
    )

    if updated:
        return str(updated.get("memory_lineage_id", memory_lineage_id))

    # Another process set it concurrently - fetch actual value
    current = col.find_one({"_id": doc_id}, {"memory_lineage_id": 1})
    if current and current.get("memory_lineage_id"):
        return str(current["memory_lineage_id"])

    logger.warning(
        "Could not retrieve memory_lineage_id for document: id=%s domain=%s term=%s org=%s",
        doc_id,
        domain,
        term,
        org_id,
    )
    return memory_lineage_id


def _build_taxonomic_query_filter(
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    domain: Optional[str] = None,
    term: Optional[str] = None,
    user_id: Optional[str] = None,
    visibility: Optional[str] = None,
    project_id: Optional[str] = None,
    include_deleted: bool = False,
) -> Tuple[Dict[str, Any], str]:
    """
    Build a MongoDB query filter and identifier string for taxonomic lookups.

    Supports lookup by ID or by domain+term combination.

    Args:
        org_id: Organization ID
        id: Document ID (string or ObjectId) - mutually exclusive with domain+term
        domain: Domain name - used with term for lookup
        term: Term name - used with domain for lookup
        include_deleted: If True, include soft-deleted documents

    Returns:
        Tuple of (query_filter_dict, identifier_string)

    Raises:
        ValueError: If invalid combination of lookup parameters is provided.
    """
    if id is not None and (domain is not None or term is not None):
        raise ValueError("Cannot specify both 'id' and 'domain/term'")

    if id is not None:
        q_filter, identifier = BaseQueryBuilder.build_id_filter(
            org_id, id, include_deleted=include_deleted
        )
    elif domain is not None and term is not None:
        q_filter = {"domain": domain, "term": term, "org_id": org_id}
        identifier = format_document_identifier(domain=domain, term=term)
        if not include_deleted:
            q_filter["deleted"] = {"$ne": True}
    else:
        raise ValueError("Either 'id' or both 'domain' and 'term' must be provided")

    if user_id is not None:
        q_filter["user_id"] = user_id
    if visibility is not None:
        q_filter["visibility"] = visibility
    if project_id is not None:
        q_filter["project_id"] = project_id

    return q_filter, identifier


def _build_taxonomic_doc(
    taxonomic_in: TaxonomicIn,
    org_id: str,
    user_id: str,
    timestamp: datetime,
    *,
    embedding: Optional[List[float]] = None,
    embedding_model_id: Optional[str] = None,
    extraction_id: Optional[str] = None,
) -> TaxonomicDB:
    """Build a TaxonomicDB document from input.

    Args:
        taxonomic_in: Input model with taxonomic memory data
        org_id: Organization ID
        user_id: User ID of the creator
        timestamp: Timestamp for the document
        embedding: Pre-computed embedding vector (if any)
        embedding_model_id: Model used to generate embedding
        extraction_id: Optional extraction ID for idempotency

    Returns:
        A TaxonomicDB document (not yet persisted)
    """
    return BaseDocumentBuilder.build_memory_document(
        taxonomic_in,
        TaxonomicDB,
        org_id,
        user_id,
        timestamp,
        embedding=embedding,
        embedding_model_id=embedding_model_id,
        extraction_id=extraction_id,
        embedding_config={
            "model_id_field": "embedding_model_id",
            "log_context": f"domain={taxonomic_in.domain} term={taxonomic_in.term}",
        },
        updated_at=timestamp,
    )


def create_taxonomic(
    db: Database,
    taxonomic_in: TaxonomicIn,
    org_id: str,
    user_id: str,
    *,
    embedding: Optional[List[float]] = None,
    embedding_model_id: Optional[str] = None,
    extraction_id: Optional[str] = None,
) -> TaxonomicDB:
    """
    Create a taxonomic memory document.

    The document's memory_lineage_id will be set to the document ID after insertion
    to enable versioning and prevent unique index violations.

    Args:
        db: MongoDB database instance
        taxonomic_in: Input model with taxonomic memory data
        org_id: Organization ID
        user_id: User ID of the creator
        embedding: Pre-computed embedding vector (if any)
        embedding_model_id: Model used to generate embedding
        extraction_id: Optional extraction ID for idempotency (SHA-256 hash)

    Returns:
        The created TaxonomicDB document

    Raises:
        DuplicateDocumentError: If domain+term already exists in org (unique constraint).
        DatabaseOperationError: If the insert operation fails.

    Example:
        >>> from mongomem_core.storage import get_database
        >>> from mongomem_core.models.memory.taxonomic import TaxonomicIn
        >>> db = get_database()
        >>> taxonomic = TaxonomicIn(
        ...     domain="programming",
        ...     term="Python",
        ...     definition="A high-level programming language."
        ... )
        >>> doc = create_taxonomic(db, taxonomic, org_id="org_1", user_id="user_1")
    """
    logger.debug(
        "Creating taxonomic memory document: domain=%s term=%s org=%s user=%s",
        taxonomic_in.domain,
        taxonomic_in.term,
        org_id,
        user_id,
    )

    now = utcnow()
    doc = _build_taxonomic_doc(
        taxonomic_in,
        org_id,
        user_id,
        now,
        embedding=embedding,
        embedding_model_id=embedding_model_id,
        extraction_id=extraction_id,
    )

    col = get_collection(_TAXONOMIC_COL, db)
    try:
        with handle_db_error(
            operation="insert_one",
            collection=_TAXONOMIC_COL.name,
            log_message="Failed to create taxonomic document: domain=%s term=%s org=%s",
            log_args_tuple=(taxonomic_in.domain, taxonomic_in.term, org_id),
        ):
            result: InsertOneResult = col.insert_one(doc.model_dump(by_alias=True))
            doc.id = result.inserted_id

            memory_lineage_id = str(result.inserted_id)
            updated = col.find_one_and_update(
                {"_id": result.inserted_id, "memory_lineage_id": None},
                {"$set": {"memory_lineage_id": memory_lineage_id}},
                return_document=ReturnDocument.AFTER,
            )

            if updated:
                doc.memory_lineage_id = updated.get("memory_lineage_id", memory_lineage_id)
            else:
                current = col.find_one({"_id": result.inserted_id})
                if current:
                    doc.memory_lineage_id = current.get("memory_lineage_id", memory_lineage_id)
                else:
                    logger.error(
                        "Document disappeared after insert: id=%s domain=%s term=%s org=%s",
                        result.inserted_id,
                        taxonomic_in.domain,
                        taxonomic_in.term,
                        org_id,
                    )
                    doc.memory_lineage_id = memory_lineage_id

            logger.debug(
                "Created taxonomic document: id=%s domain=%s term=%s org=%s",
                result.inserted_id,
                taxonomic_in.domain,
                taxonomic_in.term,
                org_id,
            )
            return doc
    except DuplicateKeyError as exc:
        handle_duplicate_key_error(
            exc,
            collection_name=_TAXONOMIC_COL.name,
            log_message="Duplicate taxonomic document detected: domain=%s term=%s org=%s",
            log_args=(taxonomic_in.domain, taxonomic_in.term, org_id),
            details={
                "domain": taxonomic_in.domain,
                "term": taxonomic_in.term,
                "org_id": org_id,
            },
        )


def upsert_taxonomic(
    db: Database,
    taxonomic_in: TaxonomicIn,
    org_id: str,
    user_id: str,
    *,
    embedding: Optional[List[float]] = None,
    embedding_model_id: Optional[str] = None,
    extraction_id: Optional[str] = None,
) -> TaxonomicOut:
    """
    Create or update a taxonomic memory document by domain+term.

    If a document with the same domain+term exists in the organization, it will be updated.
    Otherwise, a new document will be created.

    Args:
        db: MongoDB database instance
        taxonomic_in: Input model with taxonomic memory data
        org_id: Organization ID
        user_id: User ID of the creator
        embedding: Pre-computed embedding vector (if any)
        embedding_model_id: Model used to generate embedding
        extraction_id: Optional extraction ID for idempotency (SHA-256 hash)

    Returns:
        The created or updated TaxonomicOut document

    Raises:
        DatabaseOperationError: If the upsert operation fails.

    Example:
        >>> from mongomem_core.storage import get_database
        >>> from mongomem_core.models.memory.taxonomic import TaxonomicIn
        >>> db = get_database()
        >>> taxonomic = TaxonomicIn(
        ...     domain="programming",
        ...     term="Python",
        ...     definition="A high-level programming language."
        ... )
        >>> doc = upsert_taxonomic(db, taxonomic, org_id="org_1", user_id="user_1")
    """
    logger.debug(
        "Upserting taxonomic memory document: domain=%s term=%s org=%s user=%s",
        taxonomic_in.domain,
        taxonomic_in.term,
        org_id,
        user_id,
    )

    col = get_collection(_TAXONOMIC_COL, db)
    now = utcnow()

    doc = _build_taxonomic_doc(
        taxonomic_in,
        org_id,
        user_id,
        now,
        embedding=embedding,
        embedding_model_id=embedding_model_id,
        extraction_id=extraction_id,
    )

    update_doc = doc.model_dump(
        by_alias=True, exclude={"id", "_id", "timestamp", "memory_lineage_id"}
    )
    update_doc["updated_at"] = now

    set_on_insert = {
        "timestamp": now,
    }

    with handle_db_error(
        operation="find_one_and_update",
        collection=_TAXONOMIC_COL.name,
        log_message="Failed to upsert taxonomic document: domain=%s term=%s org=%s",
        log_args_tuple=(taxonomic_in.domain, taxonomic_in.term, org_id),
    ):
        result = col.find_one_and_update(
            {
                "domain": taxonomic_in.domain,
                "term": taxonomic_in.term,
                "org_id": org_id,
                "deleted": {"$ne": True},
            },
            {
                "$set": update_doc,
                "$setOnInsert": set_on_insert,
            },
            upsert=True,
            return_document=ReturnDocument.AFTER,
        )

        if not result:
            logger.error(
                "Upsert returned None despite upsert=True: domain=%s term=%s org=%s",
                taxonomic_in.domain,
                taxonomic_in.term,
                org_id,
                exc_info=True,
            )
            raise DatabaseOperationError(
                "Upsert operation failed unexpectedly",
                operation="find_one_and_update",
                collection=_TAXONOMIC_COL.name,
                details={
                    "org_id": org_id,
                    "domain": taxonomic_in.domain,
                    "term": taxonomic_in.term,
                },
            )

        # If this was an insert, atomically set memory_lineage_id to the document ID
        if "memory_lineage_id" not in result or result.get("memory_lineage_id") is None:
            result["memory_lineage_id"] = _ensure_memory_lineage_id(
                col, result["_id"], org_id, taxonomic_in.domain, taxonomic_in.term
            )

        result["_id"] = str(result["_id"])
        logger.debug(
            "Upserted taxonomic document: id=%s domain=%s term=%s org=%s",
            result["_id"],
            taxonomic_in.domain,
            taxonomic_in.term,
            org_id,
        )
        return TaxonomicOut.model_validate(result)


def get_taxonomic(
    db: Database,
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    domain: Optional[str] = None,
    term: Optional[str] = None,
    user_id: Optional[str] = None,
    visibility: Optional[str] = None,
    project_id: Optional[str] = None,
    include_deleted: bool = False,
) -> Optional[TaxonomicOut]:
    """
    Fetch a single taxonomic memory document by ID or domain+term.

    Either `id` or (`domain` and `term`) must be provided, but not both.

    Args:
        db: MongoDB database instance
        org_id: Organization ID (for access control)
        id: Document ID (string or ObjectId) - mutually exclusive with domain+term
        domain: Domain name - used with term for lookup
        term: Term name - used with domain for lookup
        include_deleted: If True, include soft-deleted documents

    Returns:
        TaxonomicOut if found, None otherwise.

    Raises:
        ValueError: If invalid combination of lookup parameters is provided.
        ValidationError: If id is not a valid ObjectId format.
        DatabaseOperationError: If the query fails.

    Example:
        >>> # Get by ID
        >>> doc = get_taxonomic(db, org_id="org_1", id="507f1f77bcf86cd799439011")
        >>> # Get by domain+term
        >>> doc = get_taxonomic(db, org_id="org_1", domain="programming", term="Python")
    """
    q_filter, identifier = _build_taxonomic_query_filter(
        org_id,
        id=id,
        domain=domain,
        term=term,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        include_deleted=include_deleted,
    )

    col = get_collection(_TAXONOMIC_COL, db)

    with handle_db_error(
        operation="find_one",
        collection=_TAXONOMIC_COL.name,
        log_message="Failed to retrieve taxonomic document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        doc = col.find_one(q_filter)
        if not doc:
            logger.debug("Taxonomic document not found: %s org=%s", identifier, org_id)
            return None

        doc["_id"] = str(doc["_id"])
        logger.debug("Retrieved taxonomic document: %s", identifier)
        return TaxonomicOut.model_validate(doc)


def list_taxonomic(
    db: Database,
    org_id: str,
    *,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    domain: Optional[str] = None,
    query_expansion: Optional[bool] = None,
    include_deleted: bool = False,
    before: Optional[datetime] = None,
    limit: Optional[int] = None,
    sort_by: str = "updated_at",
    sort_descending: bool = True,
) -> List[TaxonomicOut]:
    """
    List taxonomic memory documents for an organization with optional filters and pagination.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        user_id: Optional filter by user ID
        visibility: Optional filter by visibility scope
        project_id: Optional filter by group ID (for shared visibility)
        domain: Optional filter by domain
        query_expansion: Optional filter by query_expansion flag
        include_deleted: If True, include soft-deleted documents
        before: Optional cursor - fetch documents before this timestamp (for pagination)
        limit: Optional limit on number of results
        sort_by: Field to sort by (default: "updated_at")
        sort_descending: If True, sort descending (newest first)

    Returns:
        List of TaxonomicOut documents

    Raises:
        DatabaseOperationError: If the query fails.

    Example:
        >>> # Get all documents for org
        >>> docs = list_taxonomic(db, org_id="org_1")
        >>> # Get terms in a specific domain
        >>> docs = list_taxonomic(db, org_id="org_1", domain="programming")
        >>> # Get only query expansion terms
        >>> docs = list_taxonomic(db, org_id="org_1", query_expansion=True)
    """
    col = get_collection(_TAXONOMIC_COL, db)

    # Build base filter
    additional_filters: Dict[str, Any] = {}
    if domain:
        additional_filters["domain"] = domain
    if query_expansion is not None:
        additional_filters["query_expansion"] = query_expansion

    q_filter = BaseQueryBuilder.build_list_filter(
        org_id,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        before=before,
        include_deleted=include_deleted,
        timestamp_field="updated_at",
        **additional_filters,
    )

    sort_direction = -1 if sort_descending else 1

    with handle_db_error(
        operation="find",
        collection=_TAXONOMIC_COL.name,
        log_message="Failed to retrieve taxonomic documents for org=%s",
        log_args_tuple=(org_id,),
    ):
        cursor = col.find(q_filter).sort(sort_by, sort_direction)
        if limit and limit > 0:
            cursor = cursor.limit(limit)
        results = [doc_to_output(d, TaxonomicOut) for d in cursor]
        logger.debug(
            "Retrieved %d taxonomic documents for org=%s",
            len(results),
            org_id,
        )
        return results


def list_taxonomic_by_domains(
    db: Database,
    org_id: str,
    domains: List[str],
    *,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    query_expansion: Optional[bool] = None,
    include_deleted: bool = False,
    limit: Optional[int] = None,
) -> List[TaxonomicOut]:
    """
    List taxonomic memory documents for multiple domains.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        domains: List of domains to filter by
        user_id: Optional filter by user ID
        visibility: Optional filter by visibility scope
        project_id: Optional filter by group ID (for shared visibility)
        query_expansion: Optional filter by query_expansion flag
        include_deleted: If True, include soft-deleted documents
        limit: Optional limit on number of results

    Returns:
        List of TaxonomicOut documents

    Raises:
        DatabaseOperationError: If the query fails.
    """
    if not domains:
        return []

    col = get_collection(_TAXONOMIC_COL, db)

    q_filter = BaseQueryBuilder.build_base_filter(
        org_id,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        include_deleted=include_deleted,
    )
    q_filter["domain"] = {"$in": domains}

    if query_expansion is not None:
        q_filter["query_expansion"] = query_expansion

    with handle_db_error(
        operation="find",
        collection=_TAXONOMIC_COL.name,
        log_message="Failed to retrieve taxonomic documents by domains for org=%s",
        log_args_tuple=(org_id,),
    ):
        cursor = col.find(q_filter).sort("term", 1)
        if limit and limit > 0:
            cursor = cursor.limit(limit)
        results = [doc_to_output(d, TaxonomicOut) for d in cursor]
        logger.debug(
            "Retrieved %d taxonomic documents for %d domains in org=%s",
            len(results),
            len(domains),
            org_id,
        )
        return results


def _build_update_fields(update: TaxonomicUpdate) -> Dict[str, Any]:
    """Build MongoDB update fields from TaxonomicUpdate model."""
    update_fields = BaseUpdateFieldBuilder.build_update_fields(
        update,
        field_mappings={
            "domain": "domain",
            "term": "term",
            "definition": "definition",
            "related_terms": "related_terms",
            "query_expansion": "query_expansion",
            "search_keywords": "search_keywords",
            "complexity_score": "complexity_score",
            "usage_frequency": "usage_frequency",
            "contextual_metadata": "contextual_metadata",
            "confidence_score": "confidence_score",
            "evidence_spans": "evidence_spans",
            "creation_method": "creation_method",
            "source_agent": "source_agent",
            "user_source": "user_source",
            "source_reference": "source_reference",
        },
    )
    return update_fields


def update_taxonomic(
    db: Database,
    org_id: str,
    update: TaxonomicUpdate,
    *,
    id: Optional[str | ObjectId] = None,
    domain: Optional[str] = None,
    term: Optional[str] = None,
) -> TaxonomicOut:
    """
    Update a taxonomic memory document by ID or domain+term.

    Either `id` or (`domain` and `term`) must be provided, but not both.

    Args:
        db: MongoDB database instance
        org_id: Organization ID (for access control)
        update: Update model with fields to modify
        id: Document ID (string or ObjectId) - mutually exclusive with domain+term
        domain: Domain name - used with term for lookup
        term: Term name - used with domain for lookup

    Returns:
        Updated TaxonomicOut document

    Raises:
        ValueError: If invalid combination of lookup parameters is provided.
        ValidationError: If id is not a valid ObjectId format.
        DocumentNotFoundError: If the document doesn't exist.
        DatabaseOperationError: If the update operation fails.

    Example:
        >>> # Update by ID
        >>> update = TaxonomicUpdate(definition="Updated definition")
        >>> doc = update_taxonomic(db, org_id="org_1", update=update, id="507f...")
        >>> # Update by domain+term
        >>> doc = update_taxonomic(db, org_id="org_1", update=update, domain="prog", term="Python")
    """
    col = get_collection(_TAXONOMIC_COL, db)

    update_fields = _build_update_fields(update)

    if not update_fields:
        doc = get_taxonomic(db, org_id, id=id, domain=domain, term=term)
        if not doc:
            _, identifier = _build_taxonomic_query_filter(
                org_id, id=id, domain=domain, term=term, include_deleted=True
            )
            raise DocumentNotFoundError(
                "Taxonomic document not found",
                collection=_TAXONOMIC_COL.name,
                document_id=str(id) if id else None,
                details={"org_id": org_id, "identifier": identifier},
            )
        return doc

    update_fields["updated_at"] = utcnow()

    q_filter, identifier = _build_taxonomic_query_filter(
        org_id,
        id=id,
        domain=domain,
        term=term,
        include_deleted=False,
    )

    with handle_db_error(
        operation="find_one_and_update",
        collection=_TAXONOMIC_COL.name,
        log_message="Failed to update taxonomic document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result_doc = col.find_one_and_update(
            q_filter,
            {"$set": update_fields},
            return_document=ReturnDocument.AFTER,
        )

        if not result_doc:
            raise DocumentNotFoundError(
                "Taxonomic document not found or is deleted",
                collection=_TAXONOMIC_COL.name,
                document_id=str(id) if id else None,
                details={"org_id": org_id, "identifier": identifier},
            )

        logger.debug("Updated taxonomic document: %s org=%s", identifier, org_id)
        return TaxonomicOut.model_validate({**result_doc, "_id": str(result_doc["_id"])})


def update_taxonomic_embedding(
    db: Database,
    taxonomic_id: str | ObjectId,
    org_id: str,
    embedding: List[float],
    embedding_model_id: Optional[str] = None,
) -> UpdateResult:
    """
    Update the embedding on an existing taxonomic memory document.

    Args:
        db: MongoDB database instance
        taxonomic_id: Document ID
        org_id: Organization ID
        embedding: The embedding vector
        embedding_model_id: Optional model identifier

    Returns:
        UpdateResult from MongoDB

    Raises:
        ValidationError: If taxonomic_id is not a valid ObjectId format.
        DatabaseOperationError: If the update operation fails.
    """
    col = get_collection(_TAXONOMIC_COL, db)
    oid = to_object_id(taxonomic_id)

    update_fields: Dict[str, Any] = {
        "embedding": embedding,
        "has_embedding": True,
        "updated_at": utcnow(),
    }
    if embedding_model_id:
        update_fields["embedding_model_id"] = embedding_model_id

    with handle_db_error(
        operation="update_one",
        collection=_TAXONOMIC_COL.name,
        log_message="Failed to update embedding for taxonomic document: id=%s org=%s",
        log_args_tuple=(str(taxonomic_id), org_id),
    ):
        result = col.update_one(
            {"_id": oid, "org_id": org_id, "deleted": {"$ne": True}},
            {"$set": update_fields},
        )
        if result.modified_count > 0:
            logger.debug(
                "Updated embedding for taxonomic document: id=%s model=%s",
                taxonomic_id,
                embedding_model_id,
            )
        else:
            logger.warning(
                "No taxonomic document modified for embedding update: id=%s org=%s",
                taxonomic_id,
                org_id,
            )
        return result


def soft_delete_taxonomic(
    db: Database,
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    domain: Optional[str] = None,
    term: Optional[str] = None,
) -> UpdateResult:
    """
    Soft delete a taxonomic memory document by ID or domain+term.

    Sets the deleted flag and deleted_at timestamp without removing the document.
    Either `id` or (`domain` and `term`) must be provided, but not both.

    Args:
        db: MongoDB database instance
        org_id: Organization ID (for access control)
        id: Document ID (string or ObjectId) - mutually exclusive with domain+term
        domain: Domain name - used with term for lookup
        term: Term name - used with domain for lookup

    Returns:
        UpdateResult from MongoDB

    Raises:
        ValueError: If invalid combination of lookup parameters is provided.
        ValidationError: If id is not a valid ObjectId format.
        DatabaseOperationError: If the update operation fails.

    Example:
        >>> # Soft delete by ID
        >>> result = soft_delete_taxonomic(db, org_id="org_1", id="507f...")
        >>> # Soft delete by domain+term
        >>> result = soft_delete_taxonomic(db, org_id="org_1", domain="prog", term="Python")
    """
    q_filter, identifier = _build_taxonomic_query_filter(
        org_id,
        id=id,
        domain=domain,
        term=term,
        include_deleted=True,
    )
    # Remove the deleted filter since we want to include deleted docs
    q_filter.pop("deleted", None)

    col = get_collection(_TAXONOMIC_COL, db)
    now = utcnow()
    with handle_db_error(
        operation="update_one",
        collection=_TAXONOMIC_COL.name,
        log_message="Failed to soft delete taxonomic document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result = col.update_one(
            q_filter,
            {"$set": {"deleted": True, "deleted_at": now, "updated_at": now}},
        )
        if result.modified_count > 0:
            logger.debug("Soft deleted taxonomic document: %s org=%s", identifier, org_id)
        else:
            logger.warning(
                "No taxonomic document modified for soft delete: %s org=%s",
                identifier,
                org_id,
            )
        return result


def delete_taxonomic(
    db: Database,
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    domain: Optional[str] = None,
    term: Optional[str] = None,
) -> DeleteResult:
    """
    Hard delete a taxonomic memory document by ID or domain+term.

    Permanently removes the document from the database.
    Either `id` or (`domain` and `term`) must be provided, but not both.

    Args:
        db: MongoDB database instance
        org_id: Organization ID (for access control)
        id: Document ID (string or ObjectId) - mutually exclusive with domain+term
        domain: Domain name - used with term for lookup
        term: Term name - used with domain for lookup

    Returns:
        DeleteResult from MongoDB

    Raises:
        ValueError: If invalid combination of lookup parameters is provided.
        ValidationError: If id is not a valid ObjectId format.
        DatabaseOperationError: If the delete operation fails.

    Example:
        >>> # Delete by ID
        >>> result = delete_taxonomic(db, org_id="org_1", id="507f...")
        >>> # Delete by domain+term
        >>> result = delete_taxonomic(db, org_id="org_1", domain="prog", term="Python")
    """
    q_filter, identifier = _build_taxonomic_query_filter(
        org_id,
        id=id,
        domain=domain,
        term=term,
        include_deleted=True,
    )
    # Remove the deleted filter for hard delete
    q_filter.pop("deleted", None)

    col = get_collection(_TAXONOMIC_COL, db)

    with handle_db_error(
        operation="delete_one",
        collection=_TAXONOMIC_COL.name,
        log_message="Failed to delete taxonomic document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result = col.delete_one(q_filter)
        logger.debug(
            "Deleted taxonomic document: %s org=%s (deleted_count=%d)",
            identifier,
            org_id,
            result.deleted_count,
        )
        return result


def delete_taxonomic_by_ids(
    db: Database,
    taxonomic_ids: Sequence[str | ObjectId],
    org_id: str,
) -> DeleteResult:
    """
    Hard delete multiple taxonomic memory documents by ID.

    Args:
        db: MongoDB database instance
        taxonomic_ids: List of document IDs to delete
        org_id: Organization ID (for access control)

    Returns:
        DeleteResult from MongoDB. If an empty sequence is provided, returns a
        result with deleted_count=0 (idempotent operation - no database call is made).

    Raises:
        ValidationError: If any taxonomic_id is not a valid ObjectId format.
        DatabaseOperationError: If the delete operation fails.

    Note:
        Empty sequences are handled idempotently: the function returns immediately
        with a DeleteResult indicating 0 deletions, matching MongoDB's behavior
        for delete_many operations with empty $in arrays.
    """
    early_return = handle_empty_sequence(taxonomic_ids, "delete_taxonomic_by_ids", DeleteResult)
    if early_return is not None:
        return early_return  # type: ignore[return-value]

    col = get_collection(_TAXONOMIC_COL, db)
    oids = [to_object_id(tid) for tid in taxonomic_ids]

    with handle_db_error(
        operation="delete_many",
        collection=_TAXONOMIC_COL.name,
        log_message="Failed to delete taxonomic documents: count=%d org=%s",
        log_args_tuple=(len(taxonomic_ids), org_id),
    ):
        result = col.delete_many({"_id": {"$in": oids}, "org_id": org_id})
        logger.info(
            "Deleted %d taxonomic documents (requested=%d, org=%s)",
            result.deleted_count,
            len(taxonomic_ids),
            org_id,
        )
        return result


@overload
def search_taxonomic(
    db: Database,
    query_embedding: List[float],
    org_id: str,
    *,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    domain: Optional[str] = None,
    domains: Optional[List[str]] = None,
    query_expansion: Optional[bool] = None,
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    return_format: Literal["model"] = "model",
    include_deleted: bool = False,
    index_name: Optional[str] = None,
    is_latest: Optional[bool] = None,
    metadata_filter: Optional[MetadataFilter] = None,
) -> List[TaxonomicOut]: ...


@overload
def search_taxonomic(
    db: Database,
    query_embedding: List[float],
    org_id: str,
    *,
    user_id: str,  # Required for dict format
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    domain: Optional[str] = None,
    domains: Optional[List[str]] = None,
    query_expansion: Optional[bool] = None,
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    return_format: Literal["dict"],
    include_deleted: bool = False,
    index_name: Optional[str] = None,
    is_latest: Optional[bool] = True,
    metadata_filter: Optional[MetadataFilter] = None,
) -> List[Dict[str, Any]]: ...


def search_taxonomic(
    db: Database,
    query_embedding: List[float],
    org_id: str,
    *,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    domain: Optional[str] = None,
    domains: Optional[List[str]] = None,
    query_expansion: Optional[bool] = None,
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    return_format: Literal["model", "dict"] = "model",
    include_deleted: bool = False,
    index_name: Optional[str] = None,
    is_latest: Optional[bool] = None,
    metadata_filter: Optional[MetadataFilter] = None,
) -> Union[List[TaxonomicOut], List[Dict[str, Any]]]:
    """
    Unified vector search for taxonomic memories.

    Uses the index defined by ``TAXONOMIC_VECTOR_INDEX`` by default, or a custom
    index name if provided. Includes retry logic for when the vector index is not ready yet.

    Args:
        db: MongoDB database instance
        query_embedding: Query embedding vector for similarity search
        org_id: Organization ID (required)
        user_id: Optional filter by user ID. Required when return_format="dict"
        visibility: Optional filter by visibility scope
        project_id: Optional filter by group ID (for shared visibility)
        domain: Optional filter by single domain
        domains: Optional filter by multiple domains
        query_expansion: Optional filter by query_expansion flag
        top_k: Maximum number of results to return (default: 50)
        similarity_threshold: Minimum similarity score threshold (default: 0.0)
        return_format: Output format - "model" returns TaxonomicOut objects,
            "dict" returns dictionaries with extraction-specific fields (default: "model")
        include_deleted: If True, include soft-deleted documents (default: False)
        index_name: Optional custom index name. Defaults to TAXONOMIC_VECTOR_INDEX.name
        is_latest: Optional filter for latest versions only. Defaults to True when
            return_format="dict", None otherwise (no filter)
        metadata_filter: Optional metadata filter for Atlas Vector Search pre-filtering

    Returns:
        List of TaxonomicOut documents (return_format="model") or List of dicts
        with id, domain, term, definition, score, etc. (return_format="dict")

    Raises:
        ValueError: If return_format="dict" but user_id is not provided, or if org_id is empty
        DatabaseOperationError: If the vector search operation fails after retries

    Example:
        >>> from mongomem_core.storage import get_database
        >>> db = get_database()
        >>> query_emb = [0.1, 0.2, ...]  # 1536-dimensional vector
        >>>
        >>> # Basic search
        >>> results = search_taxonomic(
        ...     db, query_embedding=query_emb, org_id="org_1",
        ...     top_k=10, similarity_threshold=0.3
        ... )
        >>>
        >>> # Filter by domain
        >>> results = search_taxonomic(
        ...     db, query_embedding=query_emb, org_id="org_1",
        ...     domain="programming"
        ... )
    """
    if not org_id:
        raise ValueError("org_id is required")

    col = get_collection(_TAXONOMIC_COL, db)

    # Determine index name
    effective_index_name = index_name or TAXONOMIC_VECTOR_INDEX.name

    # Build base RBAC filter
    rbac_filter = BaseQueryBuilder.build_base_filter(
        org_id,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        include_deleted=include_deleted,
    )

    # Add domain filter
    if domain:
        rbac_filter["domain"] = domain
    elif domains:
        rbac_filter["domain"] = {"$in": domains}

    # Add query_expansion filter
    if query_expansion is not None:
        rbac_filter["query_expansion"] = query_expansion

    # Add is_latest filter
    if return_format == "dict":
        if user_id is None:
            raise ValueError("user_id is required when return_format='dict'")

        if is_latest is not None:
            rbac_filter["is_latest"] = is_latest
        else:
            rbac_filter["is_latest"] = True
    elif is_latest is not None:
        rbac_filter["is_latest"] = is_latest

    # Build projection based on return format
    projection: Optional[Dict[str, Any]] = None
    if return_format == "dict":
        projection = {
            "_id": 1,
            "domain": 1,
            "term": 1,
            "definition": 1,
            "related_terms": 1,
            "version": 1,
            "memory_lineage_id": 1,
            "confidence_score": 1,
            "reinforcement_count": 1,
            "query_expansion": 1,
            "score": {"$meta": "vectorSearchScore"},
        }

    # Execute vector search
    results = execute_vector_search(
        col,
        index_name=effective_index_name,
        query_embedding=query_embedding,
        rbac_filter=rbac_filter,
        collection_name=_TAXONOMIC_COL.name,
        org_id=org_id,
        top_k=top_k,
        similarity_threshold=similarity_threshold,
        metadata_filter=metadata_filter,
        projection=projection,
    )

    # Parse results based on return format
    if return_format == "dict":
        normalized = []
        for doc in results:
            normalized.append(
                {
                    "id": str(doc["_id"]),
                    "domain": doc.get("domain", ""),
                    "term": doc.get("term", ""),
                    "definition": doc.get("definition", ""),
                    "related_terms": doc.get("related_terms", []),
                    "score": doc.get("score", 0.0),
                    "version": doc.get("version", 1),
                    "memory_lineage_id": doc.get("memory_lineage_id"),
                    "confidence_score": doc.get("confidence_score"),
                    "reinforcement_count": doc.get("reinforcement_count", 0),
                    "query_expansion": doc.get("query_expansion", True),
                }
            )
        logger.debug(
            "Vector search returned %d taxonomic results (dict format) for org=%s user=%s",
            len(normalized),
            org_id,
            user_id,
        )
        return normalized
    else:
        parsed = [doc_to_output(d, TaxonomicOut) for d in results if d]
        logger.debug(
            "Vector search returned %d taxonomic results (model format) for org=%s",
            len(parsed),
            org_id,
        )
        return parsed


def get_distinct_domains(
    db: Database,
    org_id: str,
    *,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    include_deleted: bool = False,
) -> List[str]:
    """
    Get distinct domains for an organization.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        visibility: Optional filter by visibility scope
        project_id: Optional filter by group ID
        include_deleted: If True, include soft-deleted documents

    Returns:
        List of distinct domain names, sorted alphabetically

    Raises:
        DatabaseOperationError: If the query fails.
    """
    col = get_collection(_TAXONOMIC_COL, db)

    q_filter = BaseQueryBuilder.build_base_filter(
        org_id,
        visibility=visibility,
        project_id=project_id,
        include_deleted=include_deleted,
    )

    with handle_db_error(
        operation="distinct",
        collection=_TAXONOMIC_COL.name,
        log_message="Failed to get distinct domains for org=%s",
        log_args_tuple=(org_id,),
    ):
        domains = col.distinct("domain", q_filter)
        domains.sort()
        logger.debug(
            "Retrieved %d distinct domains for org=%s",
            len(domains),
            org_id,
        )
        return domains


def bulk_create_taxonomic(
    db: Database,
    terms: List[TaxonomicIn],
    org_id: str,
    user_id: str,
    *,
    embeddings: Optional[List[List[float]]] = None,
    embedding_model_id: Optional[str] = None,
    skip_duplicates: bool = True,
) -> List[TaxonomicDB]:
    """
    Bulk create multiple taxonomic memory documents.

    Efficiently creates multiple terms in a single operation. Handles duplicates
    gracefully by skipping them when skip_duplicates=True.

    Args:
        db: MongoDB database instance
        terms: List of TaxonomicIn models to create
        org_id: Organization ID
        user_id: User ID of the creator
        embeddings: Optional list of pre-computed embeddings (one per term)
        embedding_model_id: Model used to generate embeddings
        skip_duplicates: If True, skip duplicate domain+term entries instead of failing

    Returns:
        List of created TaxonomicDB documents (excludes skipped duplicates)

    Raises:
        DatabaseOperationError: If the bulk insert operation fails.

    Example:
        >>> terms = [
        ...     TaxonomicIn(domain="prog", term="Python", definition="A language"),
        ...     TaxonomicIn(domain="prog", term="Rust", definition="A fast language"),
        ... ]
        >>> docs = bulk_create_taxonomic(db, terms, org_id="org_1", user_id="user_1")
    """
    if not terms:
        return []

    logger.debug(
        "Bulk creating %d taxonomic documents for org=%s user=%s",
        len(terms),
        org_id,
        user_id,
    )

    col = get_collection(_TAXONOMIC_COL, db)
    now = utcnow()
    created_docs: List[TaxonomicDB] = []

    # Build documents
    docs_to_insert = []
    for i, term_in in enumerate(terms):
        embedding = embeddings[i] if embeddings and i < len(embeddings) else None
        doc = _build_taxonomic_doc(
            term_in,
            org_id,
            user_id,
            now,
            embedding=embedding,
            embedding_model_id=embedding_model_id,
        )
        docs_to_insert.append((doc, term_in))

    # Insert documents one by one to handle duplicates gracefully
    for doc, term_in in docs_to_insert:
        try:
            with handle_db_error(
                operation="insert_one",
                collection=_TAXONOMIC_COL.name,
                log_message="Failed to create taxonomic document: domain=%s term=%s org=%s",
                log_args_tuple=(term_in.domain, term_in.term, org_id),
            ):
                result = col.insert_one(doc.model_dump(by_alias=True))
                doc.id = result.inserted_id

                # Set memory_lineage_id
                memory_lineage_id = str(result.inserted_id)
                col.update_one(
                    {"_id": result.inserted_id, "memory_lineage_id": None},
                    {"$set": {"memory_lineage_id": memory_lineage_id}},
                )
                doc.memory_lineage_id = memory_lineage_id

                created_docs.append(doc)
        except DuplicateKeyError:
            if skip_duplicates:
                logger.debug(
                    "Skipping duplicate taxonomic term: domain=%s term=%s org=%s",
                    term_in.domain,
                    term_in.term,
                    org_id,
                )
            else:
                raise

    logger.info(
        "Bulk created %d/%d taxonomic documents for org=%s",
        len(created_docs),
        len(terms),
        org_id,
    )
    return created_docs


def count_taxonomic(
    db: Database,
    org_id: str,
    *,
    domain: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    include_deleted: bool = False,
) -> int:
    """
    Count taxonomic memory documents matching criteria.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        domain: Optional filter by domain
        visibility: Optional filter by visibility scope
        project_id: Optional filter by group ID
        include_deleted: If True, include soft-deleted documents

    Returns:
        Count of matching documents

    Raises:
        DatabaseOperationError: If the count operation fails.
    """
    col = get_collection(_TAXONOMIC_COL, db)

    q_filter = BaseQueryBuilder.build_base_filter(
        org_id,
        visibility=visibility,
        project_id=project_id,
        include_deleted=include_deleted,
    )
    if domain:
        q_filter["domain"] = domain

    with handle_db_error(
        operation="count_documents",
        collection=_TAXONOMIC_COL.name,
        log_message="Failed to count taxonomic documents for org=%s",
        log_args_tuple=(org_id,),
    ):
        count = col.count_documents(q_filter)
        logger.debug("Counted %d taxonomic documents for org=%s", count, org_id)
        return count


__all__ = [
    "create_taxonomic",
    "upsert_taxonomic",
    "get_taxonomic",
    "list_taxonomic",
    "list_taxonomic_by_domains",
    "update_taxonomic",
    "update_taxonomic_embedding",
    "soft_delete_taxonomic",
    "delete_taxonomic",
    "delete_taxonomic_by_ids",
    "search_taxonomic",
    "get_distinct_domains",
    "bulk_create_taxonomic",
    "count_taxonomic",
]
