"""
OpenTelemetry adapter for ObservabilityProtocol.

This adapter connects mongomem's observability protocol to OpenTelemetry,
enabling integration with any OpenTelemetry-compatible backend (Jaeger, Zipkin,
OTLP collectors, Datadog, etc.).

Requirements:
    pip install opentelemetry-api opentelemetry-sdk

Example usage:

    from opentelemetry import trace, metrics
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.metrics import MeterProvider
    from mongomem_core.observability.adapters.opentelemetry import OpenTelemetryObservability

    # Set up OpenTelemetry providers (users configure their own exporters)
    trace.set_tracer_provider(TracerProvider())
    metrics.set_meter_provider(MeterProvider())

    # Create the adapter
    obs = OpenTelemetryObservability()

    # Or use custom tracer/meter
    tracer = trace.get_tracer("my-service")
    meter = metrics.get_meter("my-service")
    obs = OpenTelemetryObservability(tracer=tracer, meter=meter)

    # Use with MemoryEngine
    engine = MemoryEngine(observability=obs)
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, Dict, Generator, Optional

try:
    from opentelemetry import metrics as otel_metrics
    from opentelemetry import trace as otel_trace
    from opentelemetry.trace import SpanKind, Status, StatusCode

    OTEL_AVAILABLE = True
except ImportError:
    OTEL_AVAILABLE = False

if TYPE_CHECKING:
    from opentelemetry.metrics import Counter, Histogram, Meter, UpDownCounter
    from opentelemetry.trace import Tracer

from mongomem_core.protocols import ObservabilityProtocol

logger = logging.getLogger(__name__)


# Map our span kinds to OpenTelemetry SpanKind
_SPAN_KIND_MAP: Dict[str, "SpanKind"] = {}
if OTEL_AVAILABLE:
    _SPAN_KIND_MAP = {
        "internal": SpanKind.INTERNAL,
        "server": SpanKind.SERVER,
        "client": SpanKind.CLIENT,
        "producer": SpanKind.PRODUCER,
        "consumer": SpanKind.CONSUMER,
    }

# Map event levels to log severity for span events
_LEVEL_MAP = {
    "debug": "DEBUG",
    "info": "INFO",
    "warning": "WARNING",
    "error": "ERROR",
}


class OpenTelemetryObservability(ObservabilityProtocol):
    """
    OpenTelemetry implementation of ObservabilityProtocol.

    Connects mongomem's metrics, spans, and events to OpenTelemetry APIs.

    Metrics are mapped as follows:
    - increment() -> Counter
    - gauge() -> UpDownCounter (set via add/subtract to reach target value)
    - histogram() -> Histogram
    - timing() -> Histogram with "ms" unit

    Spans are mapped directly to OpenTelemetry spans with proper kind mapping.

    Events are emitted as span events if there's an active span, otherwise logged.

    Args:
        tracer: OpenTelemetry Tracer instance. If not provided, creates one
            with name "mongomem".
        meter: OpenTelemetry Meter instance. If not provided, creates one
            with name "mongomem".
        service_name: Service name for span/metric attributes (default: "mongomem")
    """

    def __init__(
        self,
        tracer: Optional["Tracer"] = None,
        meter: Optional["Meter"] = None,
        service_name: str = "mongomem",
    ) -> None:
        if not OTEL_AVAILABLE:
            raise ImportError(
                "OpenTelemetry packages not installed. "
                "Install with: pip install opentelemetry-api opentelemetry-sdk"
            )

        self._service_name = service_name
        self._tracer = tracer or otel_trace.get_tracer(service_name)
        self._meter = meter or otel_metrics.get_meter(service_name)

        # Caches for instruments (created lazily)
        self._counters: Dict[str, "Counter"] = {}
        self._gauges: Dict[str, "UpDownCounter"] = {}
        # Track current gauge values.
        self._gauge_values: Dict[tuple[str, tuple[tuple[str, str], ...]], float] = {}
        self._histograms: Dict[str, "Histogram"] = {}
        self._timing_histograms: Dict[str, "Histogram"] = {}

    def _get_counter(self, name: str) -> "Counter":
        """Get or create a counter instrument."""
        if name not in self._counters:
            self._counters[name] = self._meter.create_counter(
                name=name,
                description=f"Counter for {name}",
            )
        return self._counters[name]

    def _get_gauge(self, name: str) -> "UpDownCounter":
        """Get or create an up-down counter for gauge semantics."""
        if name not in self._gauges:
            self._gauges[name] = self._meter.create_up_down_counter(
                name=name,
                description=f"Gauge for {name}",
            )
        return self._gauges[name]

    def _get_histogram(self, name: str, unit: str = "") -> "Histogram":
        """Get or create a histogram instrument."""
        cache = self._timing_histograms if unit == "ms" else self._histograms
        if name not in cache:
            cache[name] = self._meter.create_histogram(
                name=name,
                description=f"Histogram for {name}",
                unit=unit,
            )
        return cache[name]

    def _convert_tags(self, tags: Optional[Dict[str, str]]) -> Dict[str, str]:
        """Convert tags dict to OTel attributes format."""
        if not tags:
            return {}
        # OTel expects attribute values - tags are already strings
        return dict(tags)

    # -------------------------------------------------------------------------
    # Metrics
    # -------------------------------------------------------------------------

    def increment(
        self,
        name: str,
        value: float = 1.0,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """Increment a counter metric using OTel Counter."""
        counter = self._get_counter(name)
        attributes = self._convert_tags(tags)
        # OTel counters expect non-negative values
        counter.add(max(0, value), attributes)

    def gauge(
        self,
        name: str,
        value: float,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        Set a gauge metric using OTel UpDownCounter.

        Note: OpenTelemetry doesn't have a direct "set" gauge. We use
        UpDownCounter and track the delta from the last value.
        """
        gauge = self._get_gauge(name)
        attributes = self._convert_tags(tags)

        # Calculate delta to reach target value
        # Note: This is per-name, doesn't account for different tag combinations
        # For more precise gauge behavior, users may need custom implementation
        attr_key = tuple(sorted(attributes.items())) if attributes else ()
        gauge_key = (name, attr_key)
        current = self._gauge_values.get(gauge_key, 0.0)
        delta = value - current
        self._gauge_values[gauge_key] = value

        gauge.add(delta, attributes)

    def histogram(
        self,
        name: str,
        value: float,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """Record a value in a histogram/distribution."""
        histogram = self._get_histogram(name)
        attributes = self._convert_tags(tags)
        histogram.record(value, attributes)

    def timing(
        self,
        name: str,
        value_ms: float,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """Record a timing metric in milliseconds using OTel Histogram."""
        histogram = self._get_histogram(name, unit="ms")
        attributes = self._convert_tags(tags)
        histogram.record(value_ms, attributes)

    # -------------------------------------------------------------------------
    # Tracing (Spans)
    # -------------------------------------------------------------------------

    @contextmanager
    def span(
        self,
        name: str,
        *,
        kind: str = "internal",
        attributes: Optional[Dict[str, Any]] = None,
    ) -> Generator[Dict[str, Any], None, None]:
        """
        Create a tracing span using OpenTelemetry.

        The span is automatically ended when the context manager exits.
        The yielded dictionary can be used to add attributes during execution.
        """
        # Validate and map span kind
        span_kind = _SPAN_KIND_MAP.get(kind, SpanKind.INTERNAL)

        # Create mutable attributes dict
        span_attrs: Dict[str, Any] = dict(attributes) if attributes else {}

        # Start the span
        with self._tracer.start_as_current_span(
            name=name,
            kind=span_kind,
            attributes=span_attrs if span_attrs else None,
        ) as otel_span:
            try:
                yield span_attrs
                # Update span with any attributes added during execution
                for key, val in span_attrs.items():
                    if val is not None:
                        otel_span.set_attribute(key, self._normalize_attribute(val))
                otel_span.set_status(Status(StatusCode.OK))
            except Exception as e:
                # Record exception and set error status
                otel_span.record_exception(e)
                otel_span.set_status(Status(StatusCode.ERROR, str(e)))
                raise

    def _normalize_attribute(self, value: Any) -> Any:
        """Normalize attribute values for OpenTelemetry compatibility."""
        if isinstance(value, (str, int, float, bool)):
            return value
        if isinstance(value, (list, tuple)):
            # OTel supports homogeneous arrays
            return [self._normalize_attribute(v) for v in value]
        # Convert other types to string
        return str(value)

    # -------------------------------------------------------------------------
    # Structured Events
    # -------------------------------------------------------------------------

    def event(
        self,
        name: str,
        *,
        attributes: Optional[Dict[str, Any]] = None,
        level: str = "info",
    ) -> None:
        """
        Emit a structured event.

        If there's an active span, adds the event to that span.
        Otherwise, logs the event using Python logging.
        """
        event_attrs = dict(attributes) if attributes else {}
        event_attrs["level"] = _LEVEL_MAP.get(level, "INFO")

        # Normalize attributes for OTel
        normalized_attrs = {k: self._normalize_attribute(v) for k, v in event_attrs.items()}

        # Try to add to current span
        current_span = otel_trace.get_current_span()
        if current_span and current_span.is_recording():
            current_span.add_event(name, attributes=normalized_attrs)
        else:
            # No active span, log the event
            log_level = getattr(logging, _LEVEL_MAP.get(level, "INFO"))
            logger.log(log_level, "[event] %s attributes=%s", name, normalized_attrs)


__all__ = ["OpenTelemetryObservability", "OTEL_AVAILABLE"]
