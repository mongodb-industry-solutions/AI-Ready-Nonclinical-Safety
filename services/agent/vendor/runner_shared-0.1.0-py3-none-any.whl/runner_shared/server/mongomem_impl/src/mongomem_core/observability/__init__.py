"""
Observability module for mongomem_core.

This module provides pluggable observability via ObservabilityProtocol.
Pass any backend to MemoryEngine to capture metrics, traces, and events.

Example usage:

    from mongomem_core import MemoryEngine
    from mongomem_core.observability import LoggingObservability

    # Use LoggingObservability for development/debugging
    engine = MemoryEngine(observability=LoggingObservability())

    # Use NoOpObservability for production with zero overhead (default)
    engine = MemoryEngine()  # No observability = NoOpObservability

    # Use OpenTelemetry for enterprise observability
    # (requires: pip install mongomem[opentelemetry])
    from mongomem_core.observability import OpenTelemetryObservability
    engine = MemoryEngine(observability=OpenTelemetryObservability())

    # Implement ObservabilityProtocol for custom backends (Datadog, Prometheus, etc.)
"""

from __future__ import annotations

from mongomem_core.observability.core_observability import CoreObservability
from mongomem_core.observability.defaults import LoggingObservability, NoOpObservability
from mongomem_core.protocols import EVENT_LEVELS, SPAN_KINDS, ObservabilityProtocol

# Optional OpenTelemetry adapter (requires opentelemetry packages)
try:
    from mongomem_core.observability.adapters import OTEL_AVAILABLE, OpenTelemetryObservability
except Exception:
    OTEL_AVAILABLE = False
    OpenTelemetryObservability = None  # type: ignore[assignment, misc]

__all__ = [
    # Protocol (implement this for custom backends)
    "ObservabilityProtocol",
    # Provided backends
    "NoOpObservability",
    "LoggingObservability",
    "OpenTelemetryObservability",
    "OTEL_AVAILABLE",
    # Internal (used by engine, not for user code)
    "CoreObservability",
    # Constants
    "SPAN_KINDS",
    "EVENT_LEVELS",
]
