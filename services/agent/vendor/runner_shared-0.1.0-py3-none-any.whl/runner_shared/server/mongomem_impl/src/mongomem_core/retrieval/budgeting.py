"""Token/size budgeting across retrieval sources."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, List, Optional

from mongomem_core.common.token_counting import (
    TokenCounter,
    get_token_counter,
    resolve_model_name,
)
from mongomem_core.models.retrieval import ContextConfig, MemoryChunk
from mongomem_core.protocols import LLMProtocol
from mongomem_core.retrieval.constants import DEFAULT_MAX_TOKENS

if TYPE_CHECKING:
    from mongomem_core.models.memory.episodic import EpisodicOut
    from mongomem_core.models.memory.internal_state import InternalStateOut
    from mongomem_core.models.memory.semantic import SemanticOut

logger = logging.getLogger(__name__)


class Budgeter:
    """
    Token budget management for memory selection.

    Implements a greedy selection algorithm that selects memories based on
    their ranking scores while respecting token budget constraints. Uses
    shared TokenCounter for model-specific token counting.
    """

    def __init__(self, token_counter: Optional[TokenCounter] = None) -> None:
        """
        Initialize Budgeter.

        Args:
            token_counter: Optional TokenCounter instance. If not provided,
                uses the shared singleton for cache efficiency.
        """
        self._token_counter = token_counter or get_token_counter()

    def select_memories(
        self,
        memories: List[MemoryChunk],
        config: ContextConfig,
        llm: Optional[LLMProtocol] = None,
    ) -> List[MemoryChunk]:
        """
        Select memories that fit within the token budget using greedy selection.

        Implements global token budgeting:
        - Token buffer: Reserves tokens for formatting overhead (system prompts, metadata)
        - Greedy selection: Selects highest-ranked memories first until budget exhausted

        Memories are expected to be pre-sorted by final_score (descending)
        from the ranking step. The algorithm iterates through memories in
        priority order and includes them if they fit within the available budget.

        Args:
            memories: Ranked list of memory chunks (sorted by final_score descending)
            config: ContextConfig with max_tokens, token_buffer, and model_type
            llm: Optional LLMProtocol instance (preferred source for model name)

        Returns:
            List of selected memory chunks in priority order (maintains ranking order)

        Raises:
            ValueError: If model name cannot be determined and no default available
        """
        if not memories:
            logger.debug("No memories provided for budgeting")
            return []

        model_name = resolve_model_name(llm, config)
        max_tokens = config.max_tokens

        if max_tokens <= 0:
            logger.warning(
                "Invalid max_tokens=%d in config, defaulting to %d",
                max_tokens,
                DEFAULT_MAX_TOKENS,
            )
            max_tokens = DEFAULT_MAX_TOKENS

        # Apply token buffer: reserve tokens for formatting overhead
        token_buffer = max(0, config.token_buffer)
        available_tokens = max_tokens - token_buffer

        if available_tokens <= 0:
            logger.warning(
                "Token buffer (%d) exceeds or equals max_tokens (%d), no tokens available for memories",
                token_buffer,
                max_tokens,
            )
            return []

        logger.debug(
            "Selecting memories with max_tokens=%d, token_buffer=%d, available=%d, model=%s",
            max_tokens,
            token_buffer,
            available_tokens,
            model_name,
        )

        selected: List[MemoryChunk] = []
        current_tokens = 0

        for memory in memories:
            if not memory.content:
                logger.debug("Skipping memory id=%s with empty/None content", memory.id)
                continue

            memory_tokens = self._token_counter.count(memory.content, model_name)

            if memory_tokens == 0:
                logger.debug("Skipping memory id=%s with zero tokens", memory.id)
                continue

            # Check if adding this memory would exceed the available budget
            if current_tokens + memory_tokens > available_tokens:
                logger.debug(
                    "Memory id=%s (%d tokens) exceeds remaining budget (%d tokens), skipping",
                    memory.id,
                    memory_tokens,
                    available_tokens - current_tokens,
                )
                continue

            # Add memory
            selected.append(memory)
            current_tokens += memory_tokens
            logger.debug(
                "Added memory id=%s (%d tokens, total=%d/%d)",
                memory.id,
                memory_tokens,
                current_tokens,
                available_tokens,
            )

        logger.info(
            "Selected %d/%d memories using %d/%d available tokens "
            "(%d reserved for formatting, %d total budget)",
            len(selected),
            len(memories),
            current_tokens,
            available_tokens,
            token_buffer,
            max_tokens,
        )

        return selected


# =============================================================================
# IWM Budget Allocation
# =============================================================================


@dataclass
class BudgetAllocation:
    """
    Result of IWM budget allocation.

    Tracks what was included, what was dropped, and token accounting.
    """

    # Internal State
    internal_state_content: Optional[str] = None
    """IS content to include (may be truncated)"""

    internal_state_tokens: int = 0
    """Token count of included IS"""

    internal_state_truncated: bool = False
    """True if IS was truncated to fit is_budget"""

    internal_state_version: int = 0
    """Version of the IS document"""

    # LTM - Semantic
    semantic_memories: List["SemanticOut"] = field(default_factory=list)
    """Semantic memories included within budget"""

    semantic_tokens: int = 0
    """Token count of included semantic memories"""

    semantic_dropped: int = 0
    """Count of semantic memories dropped due to budget"""

    # LTM - Episodic
    episodic_memories: List["EpisodicOut"] = field(default_factory=list)
    """Episodic memories included within budget"""

    episodic_tokens: int = 0
    """Token count of included episodic memories"""

    episodic_dropped: int = 0
    """Count of episodic memories dropped due to budget"""

    # Budget tracking
    total_tokens: int = 0
    """Total tokens used across all sections"""

    budget_remaining: int = 0
    """Tokens remaining after packing"""

    @property
    def ltm_tokens(self) -> int:
        """Total LTM tokens (semantic + episodic)."""
        return self.semantic_tokens + self.episodic_tokens


def _estimate_tokens_simple(content: str) -> int:
    """Simple token estimation (4 chars per token). Use for quick estimates."""
    return max(1, len(content) // 4)


def allocate_iwm_budget(
    *,
    token_budget: int,
    is_token_budget: int,
    internal_state: Optional["InternalStateOut"],
    semantic_candidates: List["SemanticOut"],
    episodic_candidates: List["EpisodicOut"],
    token_counter: Optional[TokenCounter] = None,
    model_name: str = "gpt-4",
) -> BudgetAllocation:
    """
    Allocate tokens for IWM mode context building.

    Priority packing order:
    1. IS (guaranteed, capped at is_token_budget)
    2. Semantic memories (ranked by score, fills remaining)
    3. Episodic memories (ranked by score, fills remaining)

    Args:
        token_budget: Total token budget for context
        is_token_budget: Maximum tokens for Internal State
        internal_state: Current IS document (or None)
        semantic_candidates: Semantic memories to consider (pre-ranked by score)
        episodic_candidates: Episodic memories to consider (pre-ranked by score)
        token_counter: Optional TokenCounter for accurate counting
        model_name: Model name for tokenization

    Returns:
        BudgetAllocation with included content and token accounting

    Example:
        >>> allocation = allocate_iwm_budget(
        ...     token_budget=4000,
        ...     is_token_budget=500,
        ...     internal_state=is_doc,
        ...     semantic_candidates=semantic_list,
        ...     episodic_candidates=episodic_list,
        ... )
        >>> print(f"IS: {allocation.internal_state_tokens} tokens")
        >>> print(f"LTM: {allocation.ltm_tokens} tokens")
    """
    allocation = BudgetAllocation()
    counter = token_counter or get_token_counter()

    # Track remaining budget
    remaining = token_budget

    # === Step 1: Allocate IS (guaranteed, capped) ===
    if internal_state and internal_state.content:
        is_content = internal_state.content

        # Count tokens
        if counter:
            is_tokens = counter.count(is_content, model_name)
        else:
            is_tokens = internal_state.token_count or _estimate_tokens_simple(is_content)

        # Cap at is_token_budget
        if is_tokens > is_token_budget:
            # Truncate content - simple approach: cut at char estimate
            chars_per_token = len(is_content) / max(1, is_tokens)
            max_chars = int(is_token_budget * chars_per_token)
            is_content = is_content[:max_chars].rsplit(" ", 1)[0] + "..."
            is_tokens = is_token_budget
            allocation.internal_state_truncated = True
            logger.warning(
                "IS content truncated from %d to %d tokens for session=%s",
                internal_state.token_count,
                is_tokens,
                internal_state.session_id,
            )

        allocation.internal_state_content = is_content
        allocation.internal_state_tokens = is_tokens
        allocation.internal_state_version = internal_state.version
        remaining -= is_tokens

        logger.debug(
            "IS allocated: %d tokens (budget=%d, remaining=%d)",
            is_tokens,
            is_token_budget,
            remaining,
        )

    # === Step 2: Pack semantic memories ===
    for mem in semantic_candidates:
        if remaining <= 0:
            allocation.semantic_dropped += 1
            continue

        content = mem.content or ""
        if not content:
            continue

        if counter:
            mem_tokens = counter.count(content, model_name)
        else:
            mem_tokens = _estimate_tokens_simple(content)

        if mem_tokens <= remaining:
            allocation.semantic_memories.append(mem)
            allocation.semantic_tokens += mem_tokens
            remaining -= mem_tokens
        else:
            allocation.semantic_dropped += 1

    logger.debug(
        "Semantic allocated: %d memories, %d tokens, %d dropped",
        len(allocation.semantic_memories),
        allocation.semantic_tokens,
        allocation.semantic_dropped,
    )

    # === Step 3: Pack episodic memories ===
    for ep_mem in episodic_candidates:
        if remaining <= 0:
            allocation.episodic_dropped += 1
            continue

        # Prefer summary_text, fall back to content
        content = ep_mem.summary_text or ep_mem.content or ""
        if not content:
            continue

        if counter:
            ep_tokens = counter.count(content, model_name)
        else:
            ep_tokens = _estimate_tokens_simple(content)

        if ep_tokens <= remaining:
            allocation.episodic_memories.append(ep_mem)
            allocation.episodic_tokens += ep_tokens
            remaining -= ep_tokens
        else:
            allocation.episodic_dropped += 1

    logger.debug(
        "Episodic allocated: %d memories, %d tokens, %d dropped",
        len(allocation.episodic_memories),
        allocation.episodic_tokens,
        allocation.episodic_dropped,
    )

    # Final accounting
    allocation.total_tokens = (
        allocation.internal_state_tokens + allocation.semantic_tokens + allocation.episodic_tokens
    )
    allocation.budget_remaining = remaining

    logger.info(
        "IWM budget allocation complete: IS=%d, semantic=%d, episodic=%d, total=%d/%d, remaining=%d",
        allocation.internal_state_tokens,
        allocation.semantic_tokens,
        allocation.episodic_tokens,
        allocation.total_tokens,
        token_budget,
        remaining,
    )

    return allocation
