from __future__ import annotations

from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, Dict, Generator, List, Optional, Protocol, runtime_checkable

if TYPE_CHECKING:
    from mongomem_core.models.execution import ExecutionResult


@runtime_checkable
class EmbedderProtocol(Protocol):
    """Protocol for embedding providers."""

    def embed(self, text: str) -> List[float]: ...

    def embed_batch(self, texts: List[str]) -> List[List[float]]: ...

    @property
    def dimension(self) -> int: ...

    @property
    def model_id(self) -> str: ...


@runtime_checkable
class LLMProtocol(Protocol):
    """
    Protocol for LLM providers used in extractions and IS generation.

    Implementations should support:
    - complete(): Basic text completion (legacy)
    - complete_json(): Structured output
    - generate(): Text generation with explicit controls (preferred for IS)
    """

    def complete(self, prompt: str, **kwargs: Any) -> str: ...

    def complete_json(
        self, prompt: str, schema: Dict[str, Any], **kwargs: Any
    ) -> Dict[str, Any]: ...

    def generate(
        self,
        prompt: str,
        *,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        stop: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> str:
        """
        Generate text with explicit token/temperature/stop controls.

        Preferred method for IS generation where bounded output is critical.

        Args:
            prompt: The input prompt
            max_tokens: Hard limit on output tokens (enforced by API)
            temperature: Sampling temperature (lower = more deterministic)
            stop: Stop sequences to halt generation
            **kwargs: Additional provider-specific parameters

        Returns:
            Generated text (guaranteed to be within max_tokens if provided)
        """
        # Default implementation falls back to complete()
        # Implementers should override for proper token limiting
        return self.complete(prompt, **kwargs)

    @property
    def model_id(self) -> str:
        """Return the model identifier (e.g., 'gpt-4', 'claude-3-opus')."""
        ...


@runtime_checkable
class ObservabilityProtocol(Protocol):
    """
    Protocol for observability providers.

    This protocol defines a unified interface for:
    - Metrics: counters, gauges, histograms, timing
    - Tracing: spans with context propagation
    - Events: structured event emission

    Users implement this to connect to their preferred observability backend:
    - OpenTelemetry
    - Datadog
    - Prometheus + Jaeger
    - Custom logging
    - etc.

    Example usage:

        # Metrics
        observability.increment("requests_total", tags={"endpoint": "/api/v1"})
        observability.timing("request_latency", 150.5, tags={"status": "200"})

        # Spans
        with observability.span("process_request", kind="server") as span:
            span["user_id"] = user_id  # Add attributes
            result = do_work()

        # Events
        observability.event("user_login", attributes={"user_id": "123"})
    """

    # -------------------------------------------------------------------------
    # Metrics
    # -------------------------------------------------------------------------

    def increment(
        self,
        name: str,
        value: float = 1.0,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        Increment a counter metric.

        Args:
            name: Metric name (e.g., "mongomem.engine.write_turn.count")
            value: Amount to increment by (default 1.0)
            tags: Optional key-value tags for metric dimensions
        """
        ...

    def gauge(
        self,
        name: str,
        value: float,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        Set a gauge metric to a specific value.

        Args:
            name: Metric name (e.g., "mongomem.engine.active_sessions")
            value: Current value
            tags: Optional key-value tags for metric dimensions
        """
        ...

    def histogram(
        self,
        name: str,
        value: float,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        Record a value in a histogram/distribution.

        Args:
            name: Metric name (e.g., "mongomem.context.memories.count")
            value: Value to record
            tags: Optional key-value tags for metric dimensions
        """
        ...

    def timing(
        self,
        name: str,
        value_ms: float,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        Record a timing/duration metric in milliseconds.

        Args:
            name: Metric name (e.g., "mongomem.retrieval.latency")
            value_ms: Duration in milliseconds
            tags: Optional key-value tags for metric dimensions
        """
        ...

    # -------------------------------------------------------------------------
    # Tracing (Spans)
    # -------------------------------------------------------------------------

    @contextmanager
    def span(
        self,
        name: str,
        *,
        kind: str = "internal",
        attributes: Optional[Dict[str, Any]] = None,
    ) -> Generator[Dict[str, Any], None, None]:
        """
        Create a tracing span as a context manager.

        Spans represent units of work and can be nested to form traces.
        The yielded dictionary can be used to add attributes during execution.

        Args:
            name: Span name (e.g., "mongomem.context.embed_query")
            kind: Span kind - one of:
                - "internal": Internal operation (default)
                - "server": Handling an incoming request
                - "client": Making an outgoing request
                - "producer": Creating a message for async processing
                - "consumer": Processing a message
            attributes: Initial span attributes

        Yields:
            A mutable dictionary for adding span attributes during execution.
            Implementations should capture these when the span ends.

        Example:
            with observability.span("fetch_memories", kind="client") as span:
                span["memory_type"] = "semantic"
                span["query_length"] = len(query)
                memories = await fetch(query)
                span["result_count"] = len(memories)
        """
        ...

    # -------------------------------------------------------------------------
    # Structured Events
    # -------------------------------------------------------------------------

    def event(
        self,
        name: str,
        *,
        attributes: Optional[Dict[str, Any]] = None,
        level: str = "info",
    ) -> None:
        """
        Emit a structured event.

        Events are discrete occurrences that should be logged/recorded,
        typically for audit trails, debugging, or business metrics.

        Args:
            name: Event name (e.g., "mongomem.approval.staged")
            attributes: Event attributes/payload
            level: Event level - one of "debug", "info", "warning", "error"

        Example:
            observability.event(
                "mongomem.memory.written",
                attributes={
                    "memory_type": "semantic",
                    "user_id": user_id,
                    "memory_id": str(memory_id),
                },
                level="info",
            )
        """
        ...


@runtime_checkable
class ExecutorProtocol(Protocol):
    """Protocol for sandboxed code execution providers.

    This is a thin contract for running code in an isolated environment.
    Agent frameworks (LangGraph, CrewAI, etc.) call through this when a
    procedural step requires code execution. mongomem does NOT manage
    the execution graph -- that is the framework's responsibility.

    Concrete implementations (Docker, E2B, subprocess) are Phase 2.
    """

    def execute(
        self,
        code: str,
        language: str,
        *,
        timeout_ms: int = 30000,
        context: dict | None = None,
    ) -> "ExecutionResult":
        """Execute code in a sandbox and return the result."""
        ...

    @property
    def supported_languages(self) -> list[str]:
        """Languages this executor can run."""
        ...

    @property
    def executor_id(self) -> str:
        """Unique identifier for this executor instance."""
        ...


# Valid span kinds for documentation and validation
SPAN_KINDS = frozenset({"internal", "server", "client", "producer", "consumer"})

# Valid event levels for documentation and validation
EVENT_LEVELS = frozenset({"debug", "info", "warning", "error"})


__all__ = [
    "EmbedderProtocol",
    "LLMProtocol",
    "ObservabilityProtocol",
    "ExecutorProtocol",
    "SPAN_KINDS",
    "EVENT_LEVELS",
]
