"""
Taxonomic memory extractor.

Extracts domain-specific terminology and definitions from conversation messages
using LLM-based extraction with configurable prompts.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

if TYPE_CHECKING:
    from mongomem_core.protocols import LLMProtocol

from mongomem_core.extraction.base import BaseExtractor
from mongomem_core.extraction.taxonomic.prompts import (
    EXTRACTION_PROMPT_TEMPLATE,
    EXTRACTION_SCHEMA,
    EXTRACTION_SYSTEM_PROMPT,
)
from mongomem_core.extraction.types import ExtractedItem

logger = logging.getLogger(__name__)


class TaxonomicExtractor(BaseExtractor):
    """
    Extract taxonomic memories from conversation messages.

    Uses LLM to identify domain-specific terms, concepts, and definitions
    that form the knowledge ontology.

    Supports hot-reload of prompts via optional prompt_resolver callable.
    """

    extraction_type = "taxonomic"

    def __init__(
        self,
        llm: "LLMProtocol",
        prompt_resolver: Optional[Callable[[], Optional[str]]] = None,
    ) -> None:
        """
        Initialize taxonomic extractor.

        Args:
            llm: LLM protocol implementation for extraction
            prompt_resolver: Optional callable that returns a custom extraction prompt.
                            If provided and returns non-None, uses that prompt
                            instead of the default. Enables hot-reload.
        """
        super().__init__(llm, prompt_resolver)

    def extract(self, messages: List[Dict[str, Any]]) -> List[ExtractedItem]:
        """
        Extract taxonomic memories from conversation messages.

        Args:
            messages: List of conversation messages with 'role' and 'content' keys

        Returns:
            List of extracted items with domain, term, definition, and evidence spans
        """
        if not messages:
            logger.debug("No messages to extract from")
            return []

        # Get prompt (supports hot-reload)
        system_prompt = self._get_prompt(EXTRACTION_SYSTEM_PROMPT)

        # Format conversation for prompt
        formatted_conversation = self._format_messages(messages)
        user_prompt = EXTRACTION_PROMPT_TEMPLATE.format(conversation_history=formatted_conversation)

        # Call LLM
        try:
            result = self._llm.complete_json(
                prompt=f"{system_prompt}\n\n{user_prompt}",
                schema=EXTRACTION_SCHEMA,
            )
        except Exception as e:
            logger.error("LLM extraction failed: %s", e)
            return []

        # Parse response
        terms = result.get("terms", [])
        if not terms:
            logger.debug("No taxonomic terms extracted from conversation")
            return []

        # Convert to ExtractedItem
        extracted = []
        for term_data in terms:
            domain = term_data.get("domain", "").strip()
            term = term_data.get("term", "").strip()
            definition = term_data.get("definition", "").strip()

            if not domain or not term or not definition:
                logger.debug("Skipping incomplete term: domain=%s term=%s", domain, term)
                continue

            # Normalize domain name (lowercase, underscores)
            domain = domain.lower().replace(" ", "_").replace("-", "_")

            # Build content as "domain/term: definition" for embedding
            content = f"{domain}/{term}: {definition}"

            # Get evidence spans for validation
            evidence_spans = term_data.get("evidence_spans", [])

            # Convert citations from evidence_spans
            citations = [
                span.get("message_idx", 0) for span in evidence_spans if "message_idx" in span
            ]

            extracted.append(
                ExtractedItem(
                    content=content,
                    citations=citations,
                    confidence=term_data.get("confidence_score", 0.5),
                    metadata={
                        "extraction_type": "taxonomic",
                        "domain": domain,
                        "term": term,
                        "definition": definition,
                        "related_terms": term_data.get("related_terms", []),
                        "evidence_spans": evidence_spans,
                    },
                )
            )

        logger.debug(
            "Extracted %d taxonomic terms from %d messages",
            len(extracted),
            len(messages),
        )
        return extracted


__all__ = ["TaxonomicExtractor"]
