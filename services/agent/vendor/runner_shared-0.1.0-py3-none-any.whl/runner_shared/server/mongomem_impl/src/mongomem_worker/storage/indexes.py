"""
Index definitions for ``mongomem_worker`` collections.

These descriptors mirror the B-tree indexes created in the legacy ExoMemory
``task_collections`` and ``init_collections`` helpers, but are kept as plain
data so they can be applied by startup code without re-reading the legacy
modules.
"""

from __future__ import annotations

from typing import Iterable, Mapping

from pymongo import ASCENDING, DESCENDING

from ...mongomem_core.storage.indexes import CollectionIndexes, IndexDefinition
from .collections import (
    ChangeStreamStateCollection,
    ExtractionConfigCollection,
    ScheduledTasksCollection,
    TasksCollection,
    TasksDlqCollection,
    WorkerStateCollection,
)

# ---------------------------------------------------------------------------
# Task queue collections
# ---------------------------------------------------------------------------


TASKS_INDEXES = CollectionIndexes(
    collection_name=TasksCollection().name,
    indexes=[
        IndexDefinition(
            keys=[
                ("status", ASCENDING),
                ("retry_at", ASCENDING),
                ("priority", ASCENDING),
                ("created_at", ASCENDING),
            ],
            name="idx_claim_ready",
        ),
        IndexDefinition(
            keys=[("status", ASCENDING), ("lease_expires_at", ASCENDING)],
            name="idx_reclaim_stale",
        ),
        IndexDefinition(
            keys=[("idempotency_key", ASCENDING)],
            name="idx_idempotency",
            unique=True,
            # Ensure true idempotency regardless of status (queued/running/succeeded/failed).
            # Partial filter keeps the index sparse: only tasks that declare an idempotency_key.
            partial_filter={"idempotency_key": {"$exists": True}},
        ),
        IndexDefinition(
            keys=[("expires_at", ASCENDING)],
            name="idx_task_expiry",
            ttl_seconds=0,
        ),
    ],
)


TASKS_DLQ_INDEXES = CollectionIndexes(
    collection_name=TasksDlqCollection().name,
    indexes=[
        IndexDefinition(
            keys=[("moved_at", DESCENDING)],
            name="idx_dlq_recent",
        ),
        IndexDefinition(
            keys=[
                ("original_task.task_type", ASCENDING),
                ("moved_at", DESCENDING),
            ],
            name="idx_dlq_by_type",
        ),
        IndexDefinition(
            keys=[
                ("requires_manual_review", ASCENDING),
                ("moved_at", DESCENDING),
            ],
            name="idx_dlq_review_queue",
        ),
        IndexDefinition(
            keys=[("moved_at", ASCENDING)],
            name="idx_dlq_ttl",
            ttl_seconds=60 * 60 * 24 * 60,
        ),
    ],
)


# ---------------------------------------------------------------------------
# Worker state collections
# ---------------------------------------------------------------------------


WORKER_STATE_INDEXES = CollectionIndexes(
    collection_name=WorkerStateCollection().name,
    indexes=[
        IndexDefinition(
            keys=[("worker_id", ASCENDING)],
            name="idx_worker_id",
        ),
    ],
)


CHANGE_STREAM_STATE_INDEXES = CollectionIndexes(
    collection_name=ChangeStreamStateCollection().name,
    indexes=[
        IndexDefinition(
            keys=[("collection", ASCENDING)],
            name="change_stream_state_collection_unique",
            unique=True,
            comment="Unique index for change stream state by collection name",
        ),
        IndexDefinition(
            keys=[("updated_at", ASCENDING)],
            name="change_stream_state_cleanup",
            comment="Index for periodic cleanup of old change stream state",
        ),
    ],
)


SCHEDULED_TASKS_INDEXES = CollectionIndexes(
    collection_name=ScheduledTasksCollection().name,
    indexes=[
        IndexDefinition(
            keys=[("status", ASCENDING), ("runAt", ASCENDING)],
            name="task_atomic_claim",
            comment=("Critical index for atomic task claiming with find_one_and_update"),
        ),
        IndexDefinition(
            keys=[
                ("task_name", ASCENDING),
                ("status", ASCENDING),
                ("created_at", DESCENDING),
            ],
            name="task_monitoring",
            comment="Index for task status monitoring and history",
        ),
    ],
)


EXTRACTION_CONFIG_INDEXES = CollectionIndexes(
    collection_name=ExtractionConfigCollection().name,
    indexes=[
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("project_id", ASCENDING),
                ("user_id", ASCENDING),
                ("extraction_type", ASCENDING),
                ("is_active", ASCENDING),
            ],
            name="idx_active_config",
            unique=True,
            partial_filter={"is_active": True},
            comment="Ensures only one active config per scope (org/group/user + type)",
        ),
        IndexDefinition(
            keys=[
                ("org_id", ASCENDING),
                ("project_id", ASCENDING),
                ("user_id", ASCENDING),
                ("extraction_type", ASCENDING),
                ("version", DESCENDING),
            ],
            name="idx_version_lookup",
            comment="Efficient version history queries at any scope",
        ),
    ],
)


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


WORKER_INDEXES: Mapping[str, CollectionIndexes] = {
    ci.collection_name: ci
    for ci in [
        TASKS_INDEXES,
        TASKS_DLQ_INDEXES,
        WORKER_STATE_INDEXES,
        CHANGE_STREAM_STATE_INDEXES,
        SCHEDULED_TASKS_INDEXES,
        EXTRACTION_CONFIG_INDEXES,
    ]
}


def iter_worker_indexes() -> Iterable[CollectionIndexes]:
    """Iterate over all worker-domain index groups."""

    return WORKER_INDEXES.values()
