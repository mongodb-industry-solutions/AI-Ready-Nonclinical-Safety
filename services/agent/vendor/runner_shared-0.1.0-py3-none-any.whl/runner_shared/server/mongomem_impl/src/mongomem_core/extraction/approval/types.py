"""
Pending extraction types for approval workflow.

Provides Pydantic v2 models with tagged union for different extraction payloads:
- PendingDecisionPayload: For semantic/episodic/taxonomic (ConsolidationDecision-based)
- PendingPreferencesPayload: For preferences (ExtractedPreferences-based)
- PendingMemoryRefPayload: For restaged memories (reference to existing memory doc)
"""

from __future__ import annotations

from datetime import datetime
from typing import Annotated, Any, Dict, List, Literal, Optional, Union

from mongomem_core.common.utils import utcnow
from mongomem_core.models.memory.base import ChunkVisibility
from pydantic import BaseModel, Field, model_validator

ExtractionType = Literal["semantic", "episodic", "taxonomic", "preferences", "procedural"]
PendingStatus = Literal["pending", "approved", "rejected"]


class PendingDecisionPayload(BaseModel):
    """Payload for semantic/episodic/taxonomic (ConsolidationDecision-based).

    Note: DUPLICATE actions should NOT be staged - pipelines filter them out.
    """

    kind: Literal["decision"] = "decision"
    action: Literal["ADD", "UPDATE", "REINFORCE"]
    content: str
    citations: List[int] = Field(default_factory=list)
    confidence: float = 0.0
    citation_score: float = 0.0
    combined_score: float = 0.0
    embedding: Optional[List[float]] = None
    embedding_model_id: Optional[str] = None
    cited_text: List[Dict[str, Any]] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    existing_id: Optional[str] = None
    reason: str = ""

    model_config = {"use_enum_values": True}

    @model_validator(mode="after")
    def _validate_existing_id(self) -> "PendingDecisionPayload":
        """Ensure existing_id is provided for UPDATE/REINFORCE actions."""
        if self.action in ("UPDATE", "REINFORCE") and not self.existing_id:
            raise ValueError(f"existing_id is required when action={self.action}")
        return self


class PendingPreferencesPayload(BaseModel):
    """Payload for preferences (ExtractedPreferences-based)."""

    kind: Literal["preferences"] = "preferences"
    session_id: str
    tone: Optional[str] = None
    style: Optional[str] = None
    response_length: Optional[str] = None
    expertise_level: Optional[str] = None
    preferred_format: Optional[str] = None
    language: Optional[str] = None
    custom_instructions: Optional[str] = None
    confidence: float = 0.0
    evidence: List[int] = Field(default_factory=list)

    model_config = {"use_enum_values": True}


class PendingMemoryRefPayload(BaseModel):
    """Payload for restaged memories (reference to existing memory doc)."""

    kind: Literal["memory_ref"] = "memory_ref"
    memory_id: str
    memory_type: ExtractionType
    unpublished_reason: Optional[str] = None

    model_config = {"use_enum_values": True}


PendingPayload = Annotated[
    Union[PendingDecisionPayload, PendingPreferencesPayload, PendingMemoryRefPayload],
    Field(discriminator="kind"),
]


class PendingExtraction(BaseModel):
    """Pending extraction awaiting approval. Stored in extraction_pending collection."""

    id: Optional[str] = Field(default=None, alias="_id")
    org_id: str
    user_id: str
    source_id: str
    extraction_type: ExtractionType

    payload: PendingPayload

    visibility: ChunkVisibility = ChunkVisibility.PRIVATE
    project_id: Optional[str] = None

    status: PendingStatus = "pending"
    created_at: datetime = Field(default_factory=utcnow)
    expires_at: Optional[datetime] = None
    reviewed_at: Optional[datetime] = None
    reviewed_by: Optional[str] = None
    rejection_reason: Optional[str] = None

    memory_id: Optional[str] = None

    model_config = {
        "populate_by_name": True,
        "use_enum_values": True,
    }


class ApprovalResult(BaseModel):
    """Result of a single approval operation."""

    success: bool
    memory_id: Optional[str] = None
    error: Optional[str] = None
    pending_id: Optional[str] = None


class BatchApprovalResult(BaseModel):
    """Result of batch approval operations."""

    total: int = 0
    approved: int = 0
    failed: int = 0
    results: List[ApprovalResult] = Field(default_factory=list)


def to_mongo_doc(pending: PendingExtraction) -> Dict[str, Any]:
    """Convert PendingExtraction to BSON-safe dict for MongoDB."""
    doc = pending.model_dump(by_alias=True, exclude_none=False)
    if doc.get("_id") is None:
        del doc["_id"]
    return doc


def from_mongo_doc(doc: Dict[str, Any]) -> PendingExtraction:
    """Reconstruct PendingExtraction from MongoDB document."""
    if "_id" in doc:
        doc["_id"] = str(doc["_id"])
    return PendingExtraction.model_validate(doc)


__all__ = [
    "ApprovalResult",
    "BatchApprovalResult",
    "ExtractionType",
    "PendingDecisionPayload",
    "PendingExtraction",
    "PendingMemoryRefPayload",
    "PendingPayload",
    "PendingPreferencesPayload",
    "PendingStatus",
    "from_mongo_doc",
    "to_mongo_doc",
]
