"""
Episodic memory extractor.

Extracts events, actions, and experiences from conversation messages
using LLM-based extraction with configurable prompts.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

if TYPE_CHECKING:
    from mongomem_core.protocols import LLMProtocol

from mongomem_core.extraction.base import BaseExtractor
from mongomem_core.extraction.episodic.prompts import (
    EXTRACTION_PROMPT_TEMPLATE,
    EXTRACTION_SCHEMA,
    EXTRACTION_SYSTEM_PROMPT,
)
from mongomem_core.extraction.types import ExtractedItem

logger = logging.getLogger(__name__)


class EpisodicExtractor(BaseExtractor):
    """
    Extract episodic memories (events) from conversation messages.

    Uses LLM to identify events, actions, decisions, meetings, and other
    temporal occurrences from conversations.

    Supports hot-reload of prompts via optional prompt_resolver callable.
    """

    extraction_type = "episodic"

    def __init__(
        self,
        llm: "LLMProtocol",
        prompt_resolver: Optional[Callable[[], Optional[str]]] = None,
    ) -> None:
        """
        Initialize episodic extractor.

        Args:
            llm: LLM protocol implementation for extraction
            prompt_resolver: Optional callable that returns a custom extraction prompt.
                            If provided and returns non-None, uses that prompt
                            instead of the default. Enables hot-reload.
        """
        super().__init__(llm, prompt_resolver)

    def extract(self, messages: List[Dict[str, Any]]) -> List[ExtractedItem]:
        """
        Extract episodic memories (events) from conversation messages.

        Args:
            messages: List of conversation messages with 'role' and 'content' keys

        Returns:
            List of extracted items with content, citations, and confidence scores
        """
        if not messages:
            logger.debug("No messages to extract from")
            return []

        # Get prompt (supports hot-reload)
        system_prompt = self._get_prompt(EXTRACTION_SYSTEM_PROMPT)

        # Format conversation for prompt
        formatted_conversation = self._format_messages(messages)
        user_prompt = EXTRACTION_PROMPT_TEMPLATE.format(conversation_history=formatted_conversation)

        # Call LLM
        try:
            result = self._llm.complete_json(
                prompt=f"{system_prompt}\n\n{user_prompt}",
                schema=EXTRACTION_SCHEMA,
            )
        except Exception as e:
            logger.error("LLM extraction failed: %s", e)
            return []

        # Parse response
        events = result.get("events", [])
        if not events:
            logger.debug("No events extracted from conversation")
            return []

        # Convert to ExtractedItem
        extracted = []
        for event in events:
            # Build content from event fields
            title = event.get("title", "").strip()
            event_text = event.get("event", "").strip()

            if not event_text:
                continue

            # Combine title and event for content
            # The title becomes the episodic memory title, event becomes summary_text
            content = event_text

            # Build metadata with episodic-specific fields
            metadata: Dict[str, Any] = {
                "extraction_type": "episodic",
                "title": title,
                "participants": event.get("participants", []),
                "timestamp_hint": event.get("timestamp_hint"),
                "outcome": event.get("outcome"),
            }

            extracted.append(
                ExtractedItem(
                    content=content,
                    citations=event.get("citations", []),
                    confidence=event.get("confidence_score", 0.5),
                    metadata=metadata,
                )
            )

        logger.debug(
            "Extracted %d episodic events from %d messages",
            len(extracted),
            len(messages),
        )
        return extracted


__all__ = ["EpisodicExtractor"]
