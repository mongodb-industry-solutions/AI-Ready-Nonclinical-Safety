"""
IWM-mode context builder.

Builds context for Internal Working Memory mode where:
- IS (Internal State) is guaranteed and capped
- LTM fills remaining budget
- STM is not included
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, List, Optional

from mongomem_core.exceptions import EmbeddingGenerationError
from mongomem_core.memory.episodic import vector_search_episodic
from mongomem_core.memory.internal_state import get_internal_state
from mongomem_core.memory.semantic import search_semantic
from mongomem_core.models.context import ContextInvariants, MemoryContext
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.episodic import EpisodicOut
from mongomem_core.models.memory.semantic import SemanticOut
from mongomem_core.retrieval.budgeting import allocate_iwm_budget
from pymongo.database import Database

if TYPE_CHECKING:
    from mongomem_core.protocols import EmbedderProtocol

logger = logging.getLogger(__name__)


class IWMContextBuilder:
    """
    Context builder for IWM (Internal Working Memory) mode.

    Builds context with guaranteed IS + LTM, no STM.
    Keeps context size stable across turns.

    Example:
        >>> builder = IWMContextBuilder(embedder=my_embedder)
        >>> context = builder.build_context(
        ...     db=db,
        ...     session_id="sess_123",
        ...     org_id="org_1",
        ...     user_id="user_1",
        ...     token_budget=4000,
        ...     is_token_budget=500,
        ... )
        >>> print(f"IS: {context.internal_state_tokens} tokens")
        >>> print(f"LTM: {context.ltm_tokens} tokens")
    """

    def __init__(
        self,
        embedder: Optional["EmbedderProtocol"] = None,
    ) -> None:
        """
        Initialize IWMContextBuilder.

        Args:
            embedder: Optional embedder for query embedding generation.
                Required if query_embedding is not provided to build_context().
        """
        self._embedder = embedder

    def build_context(
        self,
        db: Database,
        session_id: str,
        org_id: str,
        user_id: str,
        *,
        query: Optional[str] = None,
        query_embedding: Optional[List[float]] = None,
        token_budget: int = 4000,
        is_token_budget: int = 500,
        top_k: int = 50,
        visibility: Optional[ChunkVisibility] = None,
        project_id: Optional[str] = None,
        similarity_threshold: float = 0.0,
        agent_id: Optional[str] = None,
    ) -> MemoryContext:
        """
        Build IWM context with guaranteed IS + LTM.

        Pipeline:
        1. Fetch Internal State for session/agent
        2. Generate/use query embedding for LTM search
        3. Fetch semantic and episodic memories
        4. Allocate budget (IS guaranteed, LTM fills rest)
        5. Return MemoryContext

        Args:
            db: MongoDB database instance
            session_id: Session identifier
            org_id: Organization ID
            user_id: User ID
            query: Query text for LTM search (uses IS content if not provided)
            query_embedding: Pre-computed query embedding
            token_budget: Total token budget for context
            is_token_budget: Maximum tokens for Internal State
            top_k: Maximum LTM memories to retrieve
            visibility: Optional visibility filter
            project_id: Optional group ID filter
            similarity_threshold: Minimum similarity for LTM
            agent_id: Agent identifier for multi-agent support

        Returns:
            MemoryContext with IWM invariants

        Raises:
            EmbeddingGenerationError: If embedding generation fails
        """
        pipeline_start = time.perf_counter()

        # === Step 1: Fetch Internal State ===
        is_start = time.perf_counter()
        internal_state = get_internal_state(db, session_id, org_id, agent_id=agent_id)
        is_duration = time.perf_counter() - is_start

        if internal_state:
            logger.debug(
                "Fetched IS: session=%s version=%d tokens=%d (%.3fs)",
                session_id,
                internal_state.version,
                internal_state.token_count,
                is_duration,
            )
        else:
            logger.debug("No IS found for session=%s (%.3fs)", session_id, is_duration)

        # === Step 2: Resolve query embedding ===
        # Use query if provided, else use IS content, else skip LTM
        effective_query = query
        if not effective_query and internal_state:
            effective_query = internal_state.content[:500]  # Use IS prefix as query

        effective_embedding = query_embedding
        if effective_embedding is None and effective_query and self._embedder:
            embed_start = time.perf_counter()
            try:
                effective_embedding = self._embedder.embed(effective_query)
                embed_duration = time.perf_counter() - embed_start
                logger.debug(
                    "Generated query embedding: dim=%d (%.3fs)",
                    len(effective_embedding) if effective_embedding else 0,
                    embed_duration,
                )
            except Exception as e:
                logger.warning("Failed to generate embedding: %s", e)
                raise EmbeddingGenerationError(
                    f"Embedding generation failed: {e}",
                    query=effective_query,
                    original_error=e,
                ) from e

        # === Step 3: Fetch LTM (semantic + episodic) ===
        semantic_candidates: List[SemanticOut] = []
        episodic_candidates: List[EpisodicOut] = []

        if effective_embedding:
            ltm_start = time.perf_counter()

            # Fetch semantic memories
            semantic_candidates = search_semantic(
                db=db,
                query_embedding=effective_embedding,
                org_id=org_id,
                user_id=user_id,
                visibility=visibility,
                project_id=project_id,
                top_k=top_k,
                similarity_threshold=similarity_threshold,
            )

            # Fetch episodic memories
            episodic_candidates = vector_search_episodic(
                db=db,
                query_embedding=effective_embedding,
                org_id=org_id,
                user_id=user_id,
                visibility=visibility,
                project_id=project_id,
                top_k=top_k,
                similarity_threshold=similarity_threshold,
            )

            ltm_duration = time.perf_counter() - ltm_start
            logger.debug(
                "Fetched LTM: semantic=%d, episodic=%d (%.3fs)",
                len(semantic_candidates),
                len(episodic_candidates),
                ltm_duration,
            )
        else:
            logger.debug("Skipping LTM fetch: no query embedding available")

        # === Step 4: Allocate budget ===
        budget_start = time.perf_counter()
        allocation = allocate_iwm_budget(
            token_budget=token_budget,
            is_token_budget=is_token_budget,
            internal_state=internal_state,
            semantic_candidates=semantic_candidates,
            episodic_candidates=episodic_candidates,
        )
        budget_duration = time.perf_counter() - budget_start

        logger.debug(
            "Budget allocated: IS=%d, semantic=%d, episodic=%d, total=%d/%d (%.3fs)",
            allocation.internal_state_tokens,
            allocation.semantic_tokens,
            allocation.episodic_tokens,
            allocation.total_tokens,
            token_budget,
            budget_duration,
        )

        # === Step 5: Build MemoryContext ===
        context = MemoryContext(
            session_id=session_id,
            org_id=org_id,
            user_id=user_id,
            source="iwm",
            invariants=ContextInvariants(
                stm_empty=True,
                is_present=allocation.internal_state_content is not None,
                is_primary=True,
                budget_enforced=True,
            ),
            internal_state=allocation.internal_state_content,
            internal_state_tokens=allocation.internal_state_tokens,
            internal_state_version=allocation.internal_state_version,
            is_truncated=allocation.internal_state_truncated,
            stm_turns=[],
            stm_tokens=0,
            semantic_memories=allocation.semantic_memories,
            episodic_memories=allocation.episodic_memories,
            ltm_tokens=allocation.ltm_tokens,
            total_tokens=allocation.total_tokens,
            budget_remaining=allocation.budget_remaining,
        )

        pipeline_duration = time.perf_counter() - pipeline_start
        logger.info(
            "IWM context built: session=%s IS=%d tokens, LTM=%d tokens, total=%.3fs",
            session_id,
            context.internal_state_tokens,
            context.ltm_tokens,
            pipeline_duration,
        )

        return context


__all__ = ["IWMContextBuilder"]
