"""Models for extraction jobs and results."""
