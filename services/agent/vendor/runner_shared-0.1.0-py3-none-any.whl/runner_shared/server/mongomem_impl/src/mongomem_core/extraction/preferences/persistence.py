"""
Persistence layer for preferences extraction.

Provides merge-based upsert logic for extracted preferences.
Unlike semantic/episodic persistence, preferences use field-level
merge to combine new extractions with existing preferences.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from pymongo.database import Database

from mongomem_core.extraction.preferences.extractor import ExtractedPreferences
from mongomem_core.memory.user_prefs import (
    get_user_context,
    upsert_user_context,
)
from mongomem_core.models.memory.user_prefs import (
    UserContextMemoryIn,
    UserContextMemoryOut,
)

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════════════════════

# Preference fields that can be extracted and merged
PREFERENCE_FIELDS = (
    "tone",
    "style",
    "response_length",
    "expertise_level",
    "preferred_format",
    "language",
    "custom_instructions",
)


# ═══════════════════════════════════════════════════════════════════════════════
# Result Types
# ═══════════════════════════════════════════════════════════════════════════════


@dataclass
class PreferencesPersistenceResult:
    """Result of preferences persistence operation."""

    success: bool = True
    action: str = "none"  # "add", "merge", "skip"
    doc_id: Optional[str] = None
    fields_updated: int = 0
    error: Optional[str] = None


def upsert_extracted_preferences(
    db: "Database",
    org_id: str,
    user_id: str,
    session_id: str,
    extracted: ExtractedPreferences,
    source_id: str,
    *,
    min_confidence: float = 0.5,
    respect_user_overrides: bool = True,
) -> PreferencesPersistenceResult:
    """
    Upsert extracted preferences with field-level merge.

    Logic:
    - If no existing prefs for session: Create new with extracted fields
    - If existing prefs: Merge non-null extracted fields into existing
    - If existing field has source="user_input": Don't overwrite (user override)
    - Track extraction metadata (source_id, extraction count)

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        user_id: User ID
        session_id: Session ID for session-scoped preferences
        extracted: Extracted preferences from LLM
        source_id: Source reference (snapshot ID) for tracking
        min_confidence: Minimum confidence to persist (default: 0.5)
        respect_user_overrides: If True, don't overwrite user_input source fields

    Returns:
        PreferencesPersistenceResult with action taken and doc_id
    """
    # Check confidence threshold
    if extracted.confidence < min_confidence:
        logger.debug(
            "Skipping preferences with low confidence %.2f < %.2f",
            extracted.confidence,
            min_confidence,
        )
        return PreferencesPersistenceResult(
            success=True,
            action="skip",
            error=f"Confidence {extracted.confidence} below threshold {min_confidence}",
        )

    # Check if we have any preferences to persist
    if not extracted.has_any_preference():
        logger.debug("No preferences extracted to persist")
        return PreferencesPersistenceResult(success=True, action="skip")

    # Check for existing preferences
    existing = get_user_context(db, org_id, user_id, session_id=session_id)

    if existing:
        # Merge with existing preferences
        return _merge_preferences(
            db=db,
            org_id=org_id,
            user_id=user_id,
            session_id=session_id,
            existing=existing,
            extracted=extracted,
            source_id=source_id,
            respect_user_overrides=respect_user_overrides,
        )
    else:
        # Create new preferences
        return _create_preferences(
            db=db,
            org_id=org_id,
            user_id=user_id,
            session_id=session_id,
            extracted=extracted,
            source_id=source_id,
        )


def _create_preferences(
    db: "Database",
    org_id: str,
    user_id: str,
    session_id: str,
    extracted: ExtractedPreferences,
    source_id: str,
) -> PreferencesPersistenceResult:
    """Create new preferences document from extracted preferences."""
    try:
        # Build UserContextMemoryIn from extracted
        ctx_in = UserContextMemoryIn(
            session_id=session_id,
            tone=extracted.tone,
            style=extracted.style,
            response_length=extracted.response_length,
            expertise_level=extracted.expertise_level,
            preferred_format=extracted.preferred_format,
            language=extracted.language,
            custom_instructions=extracted.custom_instructions,
            source="extracted",
            extraction_source="agent_mediated",
            preferences={
                "extraction_confidence": extracted.confidence,
                "extraction_evidence": extracted.evidence,
                "last_extraction_source": source_id,
                "extraction_count": 1,
            },
        )

        doc = upsert_user_context(db, ctx_in, org_id, user_id, session_id=session_id)

        fields_updated = [f for f in PREFERENCE_FIELDS if getattr(extracted, f) is not None]

        logger.info(
            "Created session preferences: org=%s user=%s session=%s fields=%s",
            org_id,
            user_id,
            session_id,
            fields_updated,
        )

        return PreferencesPersistenceResult(
            success=True,
            action="add",
            doc_id=doc.id,
            fields_updated=len(fields_updated),
        )

    except Exception as e:
        logger.error(
            "Failed to create preferences: org=%s user=%s session=%s error=%s",
            org_id,
            user_id,
            session_id,
            e,
        )
        return PreferencesPersistenceResult(
            success=False,
            action="skip",
            error=str(e),
        )


def _merge_preferences(
    db: "Database",
    org_id: str,
    user_id: str,
    session_id: str,
    existing: UserContextMemoryOut,
    extracted: ExtractedPreferences,
    source_id: str,
    respect_user_overrides: bool,
) -> PreferencesPersistenceResult:
    """Merge extracted preferences into existing preferences."""
    try:
        # Use shared merge logic to determine which fields to update
        fields_to_update, fields_count = merge_preferences(existing, extracted)

        if not fields_to_update:
            logger.debug(
                "No fields to update for session=%s (all fields already set)",
                session_id,
            )
            return PreferencesPersistenceResult(
                success=True,
                action="skip",
                doc_id=existing.id,
            )

        # Update extraction metadata
        existing_prefs = existing.preferences or {}
        extraction_count = existing_prefs.get("extraction_count", 0) + 1

        fields_to_update["source"] = "extracted"
        fields_to_update["extraction_source"] = "agent_mediated"
        fields_to_update["preferences"] = {
            **existing_prefs,
            "extraction_confidence": extracted.confidence,
            "extraction_evidence": extracted.evidence,
            "last_extraction_source": source_id,
            "extraction_count": extraction_count,
        }

        # Build update input
        ctx_in = UserContextMemoryIn(
            session_id=session_id,
            **fields_to_update,
        )

        doc = upsert_user_context(db, ctx_in, org_id, user_id, session_id=session_id)

        logger.info(
            "Merged session preferences: org=%s user=%s session=%s fields=%s count=%d",
            org_id,
            user_id,
            session_id,
            list(fields_to_update.keys()),
            extraction_count,
        )

        return PreferencesPersistenceResult(
            success=True,
            action="merge",
            doc_id=doc.id,
            fields_updated=fields_count,
        )

    except Exception as e:
        logger.error(
            "Failed to merge preferences: org=%s user=%s session=%s error=%s",
            org_id,
            user_id,
            session_id,
            e,
        )
        return PreferencesPersistenceResult(
            success=False,
            action="skip",
            error=str(e),
        )


def should_update_field(
    existing_value: Any,
    new_value: Any,
    source: Optional[str],
) -> bool:
    """
    Determine whether a preference field should be updated.

    Update logic:
    - If ``new_value`` is None: do not update.
    - If ``existing_value`` is None: update (new field, regardless of source).
    - If ``source`` is "user_input": do not overwrite existing values.
    - If ``source`` is "extracted": update (refine extraction).
    - If ``source`` is None or any other value: update (new extraction wins).

    Args:
        existing_value: The current value stored in the database.
        new_value: The value from extraction to potentially apply.
        source: The source of existing preferences. Expected values are
            "user_input", "extracted", or None for unknown/new sources.

    Returns:
        True if the field should be updated, False otherwise.
    """
    if new_value is None:
        return False

    # New field - always allow population (regardless of source)
    if existing_value is None:
        return True

    # User explicitly set this field - don't overwrite
    if source == "user_input":
        return False

    # Extracted source - allow refinement
    if source == "extracted":
        return True

    # Default: allow update
    return True


def merge_preferences(
    existing: Optional["UserContextMemoryOut"],
    extracted: ExtractedPreferences,
) -> tuple[Dict[str, Any], int]:
    """
    Merge extracted preferences with existing preferences.

    Returns a tuple of (fields_to_update, count) based on merge logic.

    Args:
        existing: Existing preferences from DB (None for new preferences)
        extracted: Newly extracted preferences

    Returns:
        Tuple of (dict of field_name -> new_value, count of fields to update)
    """
    existing_source = existing.source if existing else None
    fields_to_update: Dict[str, Any] = {}

    for field_name in PREFERENCE_FIELDS:
        extracted_value = getattr(extracted, field_name)
        existing_value = getattr(existing, field_name, None) if existing else None
        if should_update_field(existing_value, extracted_value, existing_source):
            fields_to_update[field_name] = extracted_value

    return fields_to_update, len(fields_to_update)


__all__ = [
    "upsert_extracted_preferences",
    "PreferencesPersistenceResult",
    "should_update_field",
    "merge_preferences",
]
