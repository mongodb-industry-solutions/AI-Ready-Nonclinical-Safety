"""
ApprovalOrchestrator: Business logic for extraction approval workflow.

Handles:
- Approving pending extractions (single and batch)
- Rejecting pending extractions
- Unpublishing memories with optional restaging
- Type-specific dispatch to persistence functions
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from pymongo.database import Database

from mongomem_core.common.utils import safe_object_id, utcnow
from mongomem_core.extraction.approval.store import (
    DEFAULT_AUDIT_RETENTION_DAYS,
    DEFAULT_PENDING_TTL_HOURS,
    PendingStore,
)
from mongomem_core.extraction.approval.types import (
    ApprovalResult,
    BatchApprovalResult,
    ExtractionType,
    PendingDecisionPayload,
    PendingExtraction,
    PendingMemoryRefPayload,
    PendingPreferencesPayload,
)
from mongomem_core.extraction.types import ConsolidationDecision, ScoredExtraction
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.observability import CoreObservability
from mongomem_core.protocols import EmbedderProtocol

logger = logging.getLogger(__name__)


class EmbedderRequiredError(Exception):
    """Raised when embedder is required but not provided."""

    pass


class ApprovalOrchestrator:
    """Approval/rejection business logic. Delegates storage to PendingStore."""

    def __init__(
        self,
        db: "Database",
        embedder: Optional[EmbedderProtocol] = None,
        pending_ttl_hours: int = DEFAULT_PENDING_TTL_HOURS,
        audit_retention_days: int = DEFAULT_AUDIT_RETENTION_DAYS,
        obs: Optional[CoreObservability] = None,
    ):
        self._db = db
        self._store = PendingStore(db, pending_ttl_hours, audit_retention_days, obs=obs)
        self._embedder = embedder

    @property
    def store(self) -> PendingStore:
        """Access the underlying PendingStore for queries."""
        return self._store

    def approve(
        self,
        pending_id: str,
        reviewed_by: Optional[str] = None,
        target_visibility: Optional[ChunkVisibility] = None,
        target_project_id: Optional[str] = None,
    ) -> ApprovalResult:
        """
        Approve a pending extraction and persist to memory collection.

        Optionally override visibility/project_id for porting to a group.
        """
        pending = self._store.get(pending_id)
        if not pending:
            return ApprovalResult(success=False, error="Not found", pending_id=pending_id)
        return self._approve_loaded(
            pending_id=pending_id,
            pending=pending,
            reviewed_by=reviewed_by,
            target_visibility=target_visibility,
            target_project_id=target_project_id,
        )

    def approve_batch(
        self,
        pending_ids: List[str],
        reviewed_by: Optional[str] = None,
    ) -> BatchApprovalResult:
        """Approve multiple pending extractions."""
        result = BatchApprovalResult(total=len(pending_ids))
        pending_map = self._store.get_many(pending_ids)
        for pid in pending_ids:
            pending = pending_map.get(pid)
            if pending is None:
                r = ApprovalResult(success=False, error="Not found", pending_id=pid)
            else:
                r = self._approve_loaded(
                    pending_id=pid,
                    pending=pending,
                    reviewed_by=reviewed_by,
                )
            result.results.append(r)
            if r.success:
                result.approved += 1
            else:
                result.failed += 1
        return result

    def _approve_loaded(
        self,
        *,
        pending_id: str,
        pending: PendingExtraction,
        reviewed_by: Optional[str],
        target_visibility: Optional[ChunkVisibility] = None,
        target_project_id: Optional[str] = None,
    ) -> ApprovalResult:
        if pending.status != "pending":
            return ApprovalResult(
                success=False, error=f"Already {pending.status}", pending_id=pending_id
            )

        if pending.payload.kind == "decision" and pending.payload.action in ("ADD", "UPDATE"):
            missing_embedding = pending.payload.embedding is None
            missing_model_id = pending.payload.embedding_model_id is None
            if self._embedder is None and (missing_embedding or missing_model_id):
                missing = []
                if missing_embedding:
                    missing.append("embedding")
                if missing_model_id:
                    missing.append("embedding_model_id")
                return ApprovalResult(
                    success=False,
                    error=(
                        f"Embedder required to approve {pending.extraction_type} decision "
                        f"missing {', '.join(missing)}"
                    ),
                    pending_id=pending_id,
                )

        visibility = target_visibility or pending.visibility
        project_id = target_project_id or pending.project_id

        if visibility == ChunkVisibility.SHARED and not project_id:
            return ApprovalResult(
                success=False, error="SHARED visibility requires project_id", pending_id=pending_id
            )

        try:
            memory_id = self._persist(pending, visibility, project_id)
        except Exception as e:
            logger.exception("Failed to persist pending extraction %s", pending_id)
            return ApprovalResult(success=False, error=str(e), pending_id=pending_id)

        if memory_id:
            self._store.mark_approved(pending_id, memory_id, reviewed_by)
            return ApprovalResult(success=True, memory_id=memory_id, pending_id=pending_id)
        return ApprovalResult(
            success=False, error="Persistence returned None", pending_id=pending_id
        )

    def reject(
        self,
        pending_id: str,
        reason: Optional[str] = None,
        reviewed_by: Optional[str] = None,
    ) -> bool:
        """Reject a pending extraction."""
        return self._store.mark_rejected(pending_id, reason, reviewed_by)

    def reject_batch(
        self,
        pending_ids: List[str],
        reason: Optional[str] = None,
        reviewed_by: Optional[str] = None,
    ) -> int:
        """Reject multiple pending extractions. Returns count of rejections."""
        return sum(1 for pid in pending_ids if self.reject(pid, reason, reviewed_by))

    def unpublish(
        self,
        memory_id: str,
        memory_type: ExtractionType,
        org_id: str,
        user_id: str,
        unpublished_by: Optional[str] = None,
        reason: Optional[str] = None,
        restage: bool = False,
    ) -> Optional[str]:
        """
        Soft-delete a published memory.

        Uses existing deleted/deleted_at fields in memory models.

        If restage=True, creates a new pending extraction with kind="memory_ref"
        for re-review (rather than reconstructing a lossy ConsolidationDecision).

        Args:
            memory_id: ID of memory to unpublish
            memory_type: Type of memory (semantic, episodic, taxonomic)
            org_id: Organization ID
            user_id: User ID (for staging ownership)
            unpublished_by: Who is unpublishing
            reason: Reason for unpublishing
            restage: If True, create pending item for re-review

        Returns:
            pending_id if restaged, None otherwise
        """
        collection_config = {
            "semantic": ("memory_semantic", "contextual_metadata"),
            "episodic": ("memory_episodic", "metadata"),
            "taxonomic": ("memory_taxonomic", "contextual_metadata"),
        }
        config = collection_config.get(memory_type)
        if not config:
            raise ValueError(f"Cannot unpublish memory_type={memory_type}")

        col_name, metadata_field = config
        now = utcnow()

        oid = safe_object_id(memory_id, "unpublish")
        if oid is None:
            return None

        result = self._db[col_name].update_one(
            {"_id": oid, "org_id": org_id, "deleted": {"$ne": True}},
            {
                "$set": {
                    "deleted": True,
                    "deleted_at": now,
                    f"{metadata_field}.unpublished_by": unpublished_by,
                    f"{metadata_field}.unpublish_reason": reason,
                }
            },
        )

        if result.modified_count == 0:
            return None

        if restage:
            payload = PendingMemoryRefPayload(
                memory_id=memory_id,
                memory_type=memory_type,
                unpublished_reason=reason,
            )
            pending_id = self._store.stage(
                org_id=org_id,
                user_id=user_id,
                source_id=f"unpublish:{memory_id}",
                extraction_type=memory_type,
                payload=payload,
            )
            return pending_id

        return None

    def _persist(
        self,
        pending: PendingExtraction,
        visibility: ChunkVisibility,
        project_id: Optional[str],
    ) -> Optional[str]:
        """Dispatch to type-specific persistence."""
        payload = pending.payload
        now = utcnow()

        if payload.kind == "decision":
            return self._persist_decision(pending, payload, visibility, project_id, now)
        elif payload.kind == "preferences":
            return self._persist_preferences(pending, payload)
        elif payload.kind == "memory_ref":
            return self._persist_memory_ref(pending, payload, visibility, project_id)

        return None

    def _persist_decision(
        self,
        pending: PendingExtraction,
        payload: PendingDecisionPayload,
        visibility: ChunkVisibility,
        project_id: Optional[str],
        now: datetime,
    ) -> Optional[str]:
        """Persist a ConsolidationDecision-based extraction."""
        if payload.action in ("ADD", "UPDATE"):
            if payload.embedding is None:
                if self._embedder is None:
                    raise EmbedderRequiredError(
                        "Embedder required to approve decision without pre-computed embedding"
                    )
                payload.embedding = self._embedder.embed(payload.content)
                payload.embedding_model_id = self._embedder.model_id

            if payload.embedding_model_id is None:
                if self._embedder is None:
                    raise EmbedderRequiredError(
                        "Embedder required to approve decision without embedding_model_id"
                    )
                payload.embedding_model_id = self._embedder.model_id

            embedding_model_id = payload.embedding_model_id
        else:
            embedding_model_id = ""

        scored = ScoredExtraction(
            content=payload.content,
            citations=payload.citations,
            confidence=payload.confidence,
            citation_score=payload.citation_score,
            combined_score=payload.combined_score,
            is_valid=True,
            cited_text=payload.cited_text,
            embedding=payload.embedding,
            metadata=payload.metadata,
        )
        decision = ConsolidationDecision(
            extraction=scored,
            action=payload.action,
            existing_id=payload.existing_id,
            reason=payload.reason,
        )

        if pending.extraction_type == "semantic":
            from mongomem_core.extraction.persistence import (
                perform_add,
                perform_reinforce,
                perform_update,
            )

            if payload.action == "ADD":
                return perform_add(
                    self._db,
                    decision,
                    pending.org_id,
                    pending.user_id,
                    pending.source_id,
                    now,
                    embedding_model_id,
                    visibility,
                    project_id,
                )
            elif payload.action == "UPDATE":
                update_result = perform_update(
                    self._db,
                    decision,
                    pending.org_id,
                    pending.user_id,
                    pending.source_id,
                    now,
                    embedding_model_id,
                    visibility,
                    project_id,
                )
                return update_result[0] if update_result else None
            elif payload.action == "REINFORCE":
                result = perform_reinforce(
                    self._db,
                    decision,
                    pending.org_id,
                    pending.source_id,
                    now,
                    user_id=pending.user_id,
                )
                if result and (
                    visibility != pending.visibility or project_id != pending.project_id
                ):
                    self._update_memory_scope(
                        "memory_semantic",
                        payload.existing_id,
                        pending.org_id,
                        visibility,
                        project_id,
                    )
                return result

        elif pending.extraction_type == "episodic":
            from mongomem_core.extraction.episodic.persistence import (
                perform_episodic_add,
                perform_episodic_reinforce,
                perform_episodic_update,
            )

            if payload.action == "ADD":
                return perform_episodic_add(
                    self._db,
                    decision,
                    pending.org_id,
                    pending.user_id,
                    pending.source_id,
                    now,
                    embedding_model_id,
                    visibility,
                    project_id,
                )
            elif payload.action == "UPDATE":
                return perform_episodic_update(
                    self._db,
                    decision,
                    pending.org_id,
                    pending.user_id,
                    pending.source_id,
                    now,
                    embedding_model_id,
                    visibility,
                    project_id,
                )
            elif payload.action == "REINFORCE":
                result = perform_episodic_reinforce(
                    self._db,
                    decision,
                    pending.org_id,
                    pending.source_id,
                    now,
                )
                if result and (
                    visibility != pending.visibility or project_id != pending.project_id
                ):
                    self._update_memory_scope(
                        "memory_episodic",
                        payload.existing_id,
                        pending.org_id,
                        visibility,
                        project_id,
                    )
                return result

        elif pending.extraction_type == "taxonomic":
            from mongomem_core.extraction.taxonomic.persistence import (
                perform_taxonomic_add,
                perform_taxonomic_reinforce,
                perform_taxonomic_update,
            )

            if payload.action == "ADD":
                return perform_taxonomic_add(
                    self._db,
                    decision,
                    pending.org_id,
                    pending.user_id,
                    pending.source_id,
                    now,
                    embedding_model_id,
                    visibility,
                    project_id,
                )
            elif payload.action == "UPDATE":
                return perform_taxonomic_update(
                    self._db,
                    decision,
                    pending.org_id,
                    pending.user_id,
                    pending.source_id,
                    now,
                    embedding_model_id,
                    visibility,
                    project_id,
                )
            elif payload.action == "REINFORCE":
                result = perform_taxonomic_reinforce(
                    self._db,
                    decision,
                    pending.org_id,
                    pending.source_id,
                    now,
                )
                if result and (
                    visibility != pending.visibility or project_id != pending.project_id
                ):
                    self._update_memory_scope(
                        "memory_taxonomic",
                        payload.existing_id,
                        pending.org_id,
                        visibility,
                        project_id,
                    )
                return result

        elif pending.extraction_type == "procedural":
            from mongomem_core.extraction.procedural.persistence import (
                perform_procedural_add,
                perform_procedural_reinforce,
                perform_procedural_update,
            )

            if payload.action == "ADD":
                return perform_procedural_add(
                    self._db,
                    decision,
                    pending.org_id,
                    pending.user_id,
                    pending.source_id,
                    now,
                    embedding_model_id,
                    visibility,
                    project_id,
                )
            elif payload.action == "UPDATE":
                update_result = perform_procedural_update(
                    self._db,
                    decision,
                    pending.org_id,
                    pending.user_id,
                    pending.source_id,
                    now,
                    embedding_model_id,
                    visibility,
                    project_id,
                )
                return update_result[0] if update_result else None
            elif payload.action == "REINFORCE":
                result = perform_procedural_reinforce(
                    self._db,
                    decision,
                    pending.org_id,
                    pending.source_id,
                    now,
                )
                if result and (
                    visibility != pending.visibility or project_id != pending.project_id
                ):
                    self._update_memory_scope(
                        "memory_procedural",
                        payload.existing_id,
                        pending.org_id,
                        visibility,
                        project_id,
                    )
                return result

        return None

    def _persist_preferences(
        self,
        pending: PendingExtraction,
        payload: PendingPreferencesPayload,
    ) -> Optional[str]:
        """Persist a preferences extraction."""
        from mongomem_core.extraction.preferences.extractor import ExtractedPreferences
        from mongomem_core.extraction.preferences.persistence import upsert_extracted_preferences

        extracted = ExtractedPreferences(
            tone=payload.tone,
            style=payload.style,
            response_length=payload.response_length,
            expertise_level=payload.expertise_level,
            preferred_format=payload.preferred_format,
            language=payload.language,
            custom_instructions=payload.custom_instructions,
            confidence=payload.confidence,
            evidence=payload.evidence,
        )
        result = upsert_extracted_preferences(
            self._db,
            pending.org_id,
            pending.user_id,
            payload.session_id,
            extracted,
            pending.source_id,
        )
        return result.doc_id if result.success else None

    def _persist_memory_ref(
        self,
        pending: PendingExtraction,
        payload: PendingMemoryRefPayload,
        visibility: ChunkVisibility,
        project_id: Optional[str],
    ) -> Optional[str]:
        """Re-publish a previously unpublished memory."""
        collection_map = {
            "semantic": "memory_semantic",
            "episodic": "memory_episodic",
            "taxonomic": "memory_taxonomic",
        }
        col_name = collection_map.get(payload.memory_type)
        if not col_name:
            return None

        oid = safe_object_id(payload.memory_id, "persist_memory_ref")
        if oid is None:
            return None
        result = self._db[col_name].update_one(
            {"_id": oid, "org_id": pending.org_id},
            {
                "$set": {
                    "deleted": False,
                    "deleted_at": None,
                    "visibility": visibility.value,
                    "project_id": project_id,
                }
            },
        )
        return payload.memory_id if result.modified_count > 0 else None

    def _update_memory_scope(
        self,
        collection_name: str,
        memory_id: Optional[str],
        org_id: str,
        visibility: ChunkVisibility,
        project_id: Optional[str],
    ) -> bool:
        """Update visibility/project_id on an existing memory (for REINFORCE porting)."""
        if not memory_id:
            return False
        oid = safe_object_id(memory_id, "_update_memory_scope")
        if oid is None:
            return False
        result = self._db[collection_name].update_one(
            {"_id": oid, "org_id": org_id},
            {
                "$set": {
                    "visibility": visibility.value,
                    "project_id": project_id,
                }
            },
        )
        return result.modified_count > 0


__all__ = [
    "ApprovalOrchestrator",
    "EmbedderRequiredError",
]
