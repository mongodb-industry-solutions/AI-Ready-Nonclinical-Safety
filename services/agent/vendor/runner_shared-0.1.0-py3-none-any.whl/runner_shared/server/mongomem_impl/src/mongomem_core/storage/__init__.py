"""
Storage layer for ``mongomem_core``.

This package centralizes:

* MongoDB client creation and database selection (``connection``).
* Engine-domain collection descriptors (``collections``).
* Engine-domain B-tree index descriptors (``indexes``).
* Engine-domain search / vector index descriptors (``search_indexes``).
* Bootstrap helpers that apply those descriptors to a real database
  (``bootstrap``).

Auth / security and worker / task-queue concerns live outside this package.
"""

from .bootstrap import (
    ensure_engine_collections,
    ensure_engine_indexes,
    ensure_engine_search_indexes,
)
from .connection import get_client, get_collection, get_database

__all__ = [
    "get_client",
    "get_database",
    "get_collection",
    "ensure_engine_collections",
    "ensure_engine_indexes",
    "ensure_engine_search_indexes",
]
