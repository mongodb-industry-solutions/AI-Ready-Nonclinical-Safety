"""
CRUD operations for Internal Working Memory (IWM).

Internal State (IS) stores the agent's self-authored belief state that is
overwritten each turn to maintain constant prompt size. One document per
(org_id, session_id, agent_id) - enabling multi-agent collaboration in the
same session where each agent maintains its own working memory.

Correctness guarantees:
1. Atomic conditional version bump: version only increments when content_hash changes
2. Atomic optimistic concurrency: expected_version / if_match_hash enforced IN THE FILTER
   (not via separate read — that would be a race condition)
3. Hash: full SHA256 (64 hex chars, 256 bits) — no truncation
4. Canonicalization: newlines normalized to LF, trailing ws stripping CONFIGURABLE
5. Noop detection: was_noop=True when content unchanged (version stays same)

Uses MongoDB aggregation pipeline update for atomic conditional logic.
"""

from __future__ import annotations

import hashlib
import logging
import re
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from mongomem_core.common.utils import (
    handle_db_error,
    utcnow,
)
from mongomem_core.models.memory.internal_state import (
    InternalStateDB,
    InternalStateIn,
    InternalStateOut,
    UpsertResult,
    VersionConflictError,
)
from mongomem_core.storage import get_collection
from mongomem_core.storage.collections import InternalStateCollection
from pymongo import ReturnDocument
from pymongo.database import Database

logger = logging.getLogger(__name__)

_IS_COL = InternalStateCollection()

# Default agent_id for single-agent backward compatibility
# When agent_id is not specified, this value is used
DEFAULT_AGENT_ID = "__default__"


class NormalizeMode(str, Enum):
    """
    Content normalization modes for hashing.

    NEWLINES_ONLY: Only normalize line endings (CRLF/CR → LF).
                   Safe for code, YAML, Makefiles, etc.

    STRIP_TRAILING: Normalize line endings AND strip trailing whitespace per line.
                    Good for prose content. May alter meaning for structured formats.
    """

    NEWLINES_ONLY = "newlines_only"
    STRIP_TRAILING = "strip_trailing"


def _normalize_content(
    content: str,
    mode: NormalizeMode = NormalizeMode.NEWLINES_ONLY,
) -> str:
    """
    Normalize content for consistent hashing.

    Args:
        content: Raw content string
        mode: Normalization mode
            - NEWLINES_ONLY: Only normalize line endings (safe for code)
            - STRIP_TRAILING: Also strip trailing whitespace (for prose)

    Returns:
        Normalized content with:
        - Line endings normalized to LF (\\n)
        - Single trailing newline at end
        - If STRIP_TRAILING: trailing whitespace stripped per line
    """
    # Always normalize line endings: CRLF -> LF, CR -> LF
    normalized = re.sub(r"\r\n?", "\n", content)

    if mode == NormalizeMode.STRIP_TRAILING:
        # Strip trailing whitespace from each line (but keep leading)
        lines = [line.rstrip() for line in normalized.split("\n")]
        normalized = "\n".join(lines)

    # Ensure single trailing newline
    if normalized and not normalized.endswith("\n"):
        normalized += "\n"

    return normalized


def _compute_content_hash(
    content: str,
    normalize_mode: NormalizeMode = NormalizeMode.NEWLINES_ONLY,
) -> str:
    """
    Compute full SHA256 hash (64 hex chars, 256 bits) of normalized content.

    No truncation. Full 256-bit hash for collision resistance.

    Canonicalization:
    - UTF-8 encoding
    - Newlines normalized to LF
    - Trailing whitespace handling per normalize_mode
    - Single trailing newline

    Args:
        content: Raw content
        normalize_mode: How to normalize before hashing

    Returns:
        Full 64-character hex SHA256 hash
    """
    normalized = _normalize_content(content, normalize_mode)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def _estimate_tokens(content: str) -> int:
    """
    Estimate token count from content length.

    Uses rough heuristic of 4 characters per token. This is labeled as
    an estimate via token_count_estimated field in the document.

    For production accuracy, callers should provide actual token counts
    from their tokenizer.
    """
    return max(1, len(content) // 4)


def upsert_internal_state(
    db: Database,
    is_in: InternalStateIn,
    org_id: str,
    user_id: str,
    session_id: str,
    *,
    agent_id: Optional[str] = None,
) -> UpsertResult:
    """
    Atomically upsert internal state for a session/agent with conditional versioning.

    Guarantees:
    1. Version only bumps when content_hash changes (noop detection)
    2. Atomic optimistic concurrency: expected_version / if_match_hash
       enforced IN THE FILTER (no separate read = no race condition)
    3. Full SHA256 hash (256 bits, no truncation)
    4. Configurable canonicalization for different content types

    Strategy for atomic OCC:
    - If expected_version or if_match_hash provided:
      → Include in filter, use upsert=False
      → If no match → VersionConflictError (409)
    - If no OCC constraints:
      → Use upsert=True for insert-or-update

    Args:
        db: MongoDB database instance
        is_in: Input model with content, metadata, and normalize_mode
            (normalize_mode controls hashing: "newlines_only" or "strip_trailing")
        org_id: Organization ID
        user_id: User ID
        session_id: Session identifier
        agent_id: Agent identifier for multi-agent support (defaults to DEFAULT_AGENT_ID)

    Returns:
        UpsertResult with version info and was_noop flag

    Raises:
        VersionConflictError: If expected_version or if_match_hash doesn't match (409)
        DatabaseOperationError: If the upsert operation fails.

    Example:
        >>> db = get_database()
        >>> is_in = InternalStateIn(content="Agent believes X is true")
        >>> result = upsert_internal_state(db, is_in, "org_1", "user_1", "sess_1")
        >>> result.version  # 1 on first call
        >>> result.was_noop  # False (new content)
        >>>
        >>> # Same content again
        >>> result2 = upsert_internal_state(db, is_in, "org_1", "user_1", "sess_1")
        >>> result2.version  # Still 1 (unchanged)
        >>> result2.was_noop  # True (content unchanged)
    """
    col = get_collection(_IS_COL, db)
    now = utcnow()

    # Resolve agent_id: function param > model field > default
    # This provides backward compatibility: if agent_id was set via InternalStateIn,
    # it will be used when the function param is None
    effective_agent_id = (
        agent_id
        if agent_id is not None
        else (is_in.agent_id if is_in.agent_id is not None else DEFAULT_AGENT_ID)
    )

    # Resolve normalize mode from input
    norm_mode = (
        NormalizeMode(is_in.normalize_mode) if is_in.normalize_mode else NormalizeMode.NEWLINES_ONLY
    )

    # Normalize content and compute FULL hash (no truncation)
    normalized_content = _normalize_content(is_in.content, norm_mode)
    content_hash = _compute_content_hash(is_in.content, norm_mode)
    token_count = is_in.token_count or _estimate_tokens(normalized_content)
    token_count_estimated = is_in.token_count is None or is_in.token_count_estimated

    logger.debug(
        "Upserting internal state: session=%s org=%s agent=%s tokens=%d hash=%s",
        session_id,
        org_id,
        effective_agent_id,
        token_count,
        content_hash[:16],  # Log truncated for readability
    )

    # Determine if we have OCC constraints
    has_occ = is_in.expected_version is not None or is_in.if_match_hash is not None

    # Build filter — OCC constraints go IN the filter for atomicity
    # Include agent_id in filter for multi-agent support
    filter_doc: Dict[str, Any] = {
        "session_id": session_id,
        "org_id": org_id,
        "agent_id": effective_agent_id,
    }
    if is_in.expected_version is not None:
        filter_doc["version"] = is_in.expected_version
    if is_in.if_match_hash is not None:
        filter_doc["content_hash"] = is_in.if_match_hash

    # Aggregation pipeline for atomic conditional version bump
    # Use $literal for metadata so empty dicts are treated as values, not expressions.
    metadata_value = is_in.metadata or {}
    pipeline = [
        {
            "$set": {
                # Preserve or set created_at
                "created_at": {"$ifNull": ["$created_at", now]},
                # Always update these fields
                "user_id": user_id,
                "content": normalized_content,
                "content_hash": content_hash,
                "token_count": token_count,
                "token_count_estimated": token_count_estimated,
                "tokenizer_id": is_in.tokenizer_id,
                "model_id": is_in.model_id,
                "source_turn_id": is_in.source_turn_id,
                "update_reason": is_in.update_reason,
                "redaction_applied": is_in.redaction_applied,
                "redaction_policy_id": is_in.redaction_policy_id,
                "metadata": {"$literal": metadata_value},
                "updated_at": now,
                "org_id": org_id,
                "session_id": session_id,
                "agent_id": effective_agent_id,  # Uses resolved agent_id from param
                # Preserve promotion fields
                "promotion_count": {"$ifNull": ["$promotion_count", 0]},
                "last_promoted_at": {"$ifNull": ["$last_promoted_at", None]},
                "last_generated_at": {"$ifNull": ["$last_generated_at", None]},
                # Store previous version for result
                "_prev_version": "$version",
                "_prev_hash": "$content_hash",
                # Conditional version increment:
                # - If no existing doc (insert): version = 1
                # - If hash unchanged: keep current version
                # - If hash changed: increment version
                "version": {
                    "$cond": {
                        "if": {"$eq": [{"$type": "$version"}, "missing"]},
                        "then": 1,  # First insert
                        "else": {
                            "$cond": {
                                "if": {"$eq": ["$content_hash", content_hash]},
                                "then": "$version",  # Noop: keep version
                                "else": {"$add": ["$version", 1]},  # Bump version
                            }
                        },
                    }
                },
            }
        }
    ]

    with handle_db_error(
        operation="find_one_and_update",
        collection=_IS_COL.name,
        log_message="Failed to upsert internal state: session=%s org=%s agent=%s",
        log_args_tuple=(session_id, org_id, effective_agent_id),
    ):
        # ATOMIC OCC: If OCC constraints, use upsert=False
        # If filter doesn't match (wrong version/hash), result is None → 409
        result = col.find_one_and_update(
            filter_doc,
            pipeline,
            upsert=not has_occ,  # Only upsert if no OCC constraints
            return_document=ReturnDocument.AFTER,
        )

        # Handle OCC failure (filter didn't match)
        if result is None and has_occ:
            # Need to determine actual values for error message
            actual = col.find_one(
                {"session_id": session_id, "org_id": org_id, "agent_id": effective_agent_id},
                {"version": 1, "content_hash": 1},
            )
            if actual is None:
                # Document doesn't exist at all
                raise VersionConflictError(
                    f"Document not found for session={session_id}, org={org_id}, agent={effective_agent_id}. "
                    f"Cannot apply OCC constraints to non-existent document.",
                    expected_version=is_in.expected_version,
                    actual_version=None,
                    expected_hash=is_in.if_match_hash,
                    actual_hash=None,
                )
            elif (
                is_in.expected_version is not None
                and actual.get("version") != is_in.expected_version
            ):
                raise VersionConflictError(
                    f"Version mismatch: expected {is_in.expected_version}, "
                    f"got {actual.get('version')}",
                    expected_version=is_in.expected_version,
                    actual_version=actual.get("version"),
                )
            elif (
                is_in.if_match_hash is not None
                and actual.get("content_hash") != is_in.if_match_hash
            ):
                raise VersionConflictError(
                    f"Hash mismatch: expected {is_in.if_match_hash[:16]}..., "
                    f"got {actual.get('content_hash', '')[:16]}...",
                    expected_hash=is_in.if_match_hash,
                    actual_hash=actual.get("content_hash"),
                )
            else:
                # Shouldn't happen, but handle gracefully
                raise VersionConflictError(
                    f"OCC conflict for session={session_id}, org={org_id}, agent={effective_agent_id}",
                    expected_version=is_in.expected_version,
                    actual_version=actual.get("version"),
                    expected_hash=is_in.if_match_hash,
                    actual_hash=actual.get("content_hash"),
                )

        # Extract metadata from result
        prev_version = result.pop("_prev_version", None)
        prev_hash = result.pop("_prev_hash", None)

        # Determine if this was a noop (content unchanged)
        was_noop = prev_hash == content_hash and prev_version is not None
        was_insert = prev_version is None

        logger.debug(
            "Upserted internal state: session=%s org=%s version=%d hash=%s "
            "was_noop=%s was_insert=%s",
            session_id,
            org_id,
            result["version"],
            content_hash[:16],
            was_noop,
            was_insert,
        )

        return UpsertResult(
            session_id=session_id,
            org_id=org_id,
            version=result["version"],
            previous_version=prev_version,
            content_hash=content_hash,
            token_count=token_count,
            was_noop=was_noop,
            was_insert=was_insert,
            acknowledged=True,
        )


def get_internal_state(
    db: Database,
    session_id: str,
    org_id: str,
    *,
    agent_id: Optional[str] = None,
) -> Optional[InternalStateOut]:
    """
    Get current internal state for a session/agent.

    Args:
        db: MongoDB database instance
        session_id: Session identifier
        org_id: Organization ID
        agent_id: Agent identifier for multi-agent support (defaults to DEFAULT_AGENT_ID)

    Returns:
        InternalStateOut if found, None otherwise.

    Raises:
        DatabaseOperationError: If the query fails.
    """
    col = get_collection(_IS_COL, db)
    effective_agent_id = agent_id if agent_id is not None else DEFAULT_AGENT_ID

    with handle_db_error(
        operation="find_one",
        collection=_IS_COL.name,
        log_message="Failed to get internal state: session=%s org=%s agent=%s",
        log_args_tuple=(session_id, org_id, effective_agent_id),
    ):
        doc = col.find_one(
            {
                "session_id": session_id,
                "org_id": org_id,
                "agent_id": effective_agent_id,
            }
        )

        if not doc:
            logger.debug(
                "Internal state not found: session=%s org=%s agent=%s",
                session_id,
                org_id,
                effective_agent_id,
            )
            return None

        db_doc = InternalStateDB.model_validate(doc)
        logger.debug(
            "Retrieved internal state: session=%s org=%s agent=%s version=%d",
            session_id,
            org_id,
            effective_agent_id,
            db_doc.version,
        )
        return InternalStateOut.from_db(db_doc)


def delete_internal_state(
    db: Database,
    session_id: str,
    org_id: str,
    *,
    agent_id: Optional[str] = None,
) -> bool:
    """
    Delete internal state for a session/agent.

    Args:
        db: MongoDB database instance
        session_id: Session identifier
        org_id: Organization ID
        agent_id: Agent identifier for multi-agent support (defaults to DEFAULT_AGENT_ID)

    Returns:
        True if a document was deleted, False if no document existed.

    Raises:
        DatabaseOperationError: If the delete operation fails.
    """
    col = get_collection(_IS_COL, db)
    effective_agent_id = agent_id if agent_id is not None else DEFAULT_AGENT_ID

    with handle_db_error(
        operation="delete_one",
        collection=_IS_COL.name,
        log_message="Failed to delete internal state: session=%s org=%s agent=%s",
        log_args_tuple=(session_id, org_id, effective_agent_id),
    ):
        result = col.delete_one(
            {
                "session_id": session_id,
                "org_id": org_id,
                "agent_id": effective_agent_id,
            }
        )
        deleted = result.deleted_count > 0

        if deleted:
            logger.info(
                "Deleted internal state: session=%s org=%s agent=%s",
                session_id,
                org_id,
                effective_agent_id,
            )
        else:
            logger.debug(
                "No internal state to delete: session=%s org=%s agent=%s",
                session_id,
                org_id,
                effective_agent_id,
            )
        return deleted


def mark_promoted(
    db: Database,
    session_id: str,
    org_id: str,
    promotion_type: str = "full",
    *,
    agent_id: Optional[str] = None,
) -> bool:
    """
    Mark internal state as promoted to LTM.

    Updates last_promoted_at and increments promotion_count.
    This is used by the worker after extracting facts from IS.

    Args:
        db: MongoDB database instance
        session_id: Session identifier
        org_id: Organization ID
        promotion_type: Type of promotion (for logging/metadata)
        agent_id: Agent identifier for multi-agent support (defaults to DEFAULT_AGENT_ID)

    Returns:
        True if a document was updated, False if no document existed.

    Raises:
        DatabaseOperationError: If the update operation fails.
    """
    col = get_collection(_IS_COL, db)
    now = utcnow()
    effective_agent_id = agent_id if agent_id is not None else DEFAULT_AGENT_ID

    with handle_db_error(
        operation="update_one",
        collection=_IS_COL.name,
        log_message="Failed to mark internal state as promoted: session=%s org=%s agent=%s",
        log_args_tuple=(session_id, org_id, effective_agent_id),
    ):
        result = col.update_one(
            {
                "session_id": session_id,
                "org_id": org_id,
                "agent_id": effective_agent_id,
            },
            {
                "$set": {"last_promoted_at": now},
                "$inc": {"promotion_count": 1},
            },
        )
        updated = result.modified_count > 0

        if updated:
            logger.info(
                "Marked internal state as promoted: session=%s org=%s agent=%s type=%s",
                session_id,
                org_id,
                effective_agent_id,
                promotion_type,
            )
        else:
            logger.warning(
                "No internal state to mark as promoted: session=%s org=%s agent=%s",
                session_id,
                org_id,
                effective_agent_id,
            )
        return updated


def get_stale_sessions(
    db: Database,
    org_id: str,
    *,
    before: datetime,
    limit: int = 100,
) -> List[Dict[str, Any]]:
    """
    Find sessions with IS that hasn't been updated since a given time.

    Useful for cleanup or forced promotion of inactive sessions.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        before: Find sessions not updated since this time
        limit: Maximum number of sessions to return

    Returns:
        List of session info dicts with session_id, updated_at, version

    Raises:
        DatabaseOperationError: If the query fails.
    """
    col = get_collection(_IS_COL, db)

    with handle_db_error(
        operation="find",
        collection=_IS_COL.name,
        log_message="Failed to get stale sessions: org=%s before=%s",
        log_args_tuple=(org_id, before.isoformat()),
    ):
        cursor = (
            col.find(
                {"org_id": org_id, "updated_at": {"$lt": before}},
                {"session_id": 1, "updated_at": 1, "version": 1},
            )
            .sort("updated_at", 1)
            .limit(limit)
        )

        results = [
            {
                "session_id": doc["session_id"],
                "updated_at": doc["updated_at"],
                "version": doc.get("version", 0),
            }
            for doc in cursor
        ]

        logger.debug(
            "Found %d stale sessions for org=%s before=%s",
            len(results),
            org_id,
            before.isoformat(),
        )
        return results


def list_internal_states(
    db: Database,
    org_id: str,
    *,
    limit: int = 50,
    skip: int = 0,
) -> List[InternalStateOut]:
    """
    List internal states for an organization.

    Sorted by updated_at descending (most recent first).

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        limit: Maximum number of results
        skip: Number of results to skip (for pagination)

    Returns:
        List of InternalStateOut documents

    Raises:
        DatabaseOperationError: If the query fails.
    """
    col = get_collection(_IS_COL, db)

    with handle_db_error(
        operation="find",
        collection=_IS_COL.name,
        log_message="Failed to list internal states: org=%s",
        log_args_tuple=(org_id,),
    ):
        cursor = col.find({"org_id": org_id}).sort("updated_at", -1).skip(skip).limit(limit)

        results = []
        for doc in cursor:
            db_doc = InternalStateDB.model_validate(doc)
            results.append(InternalStateOut.from_db(db_doc))

        logger.debug(
            "Listed %d internal states for org=%s",
            len(results),
            org_id,
        )
        return results


__all__ = [
    "DEFAULT_AGENT_ID",
    "upsert_internal_state",
    "get_internal_state",
    "delete_internal_state",
    "mark_promoted",
    "get_stale_sessions",
    "list_internal_states",
]
