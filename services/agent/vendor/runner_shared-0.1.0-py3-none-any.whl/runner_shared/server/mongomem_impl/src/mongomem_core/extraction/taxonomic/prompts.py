"""
Taxonomic extraction prompts.

Prompts for extracting domain-specific terms and definitions from conversations.
Taxonomic memories form the ontology/glossary of concepts in a domain.
"""

# ═══════════════════════════════════════════════════════════════════════════════
# Extraction Prompts
# ═══════════════════════════════════════════════════════════════════════════════

EXTRACTION_SYSTEM_PROMPT = """
# ROLE

You are a specialized **Taxonomic Memory Extraction System**.
Your function is to analyze conversation logs and extract domain-specific terminology,
concepts, and definitions that form the knowledge ontology.

# TAXONOMIC MEMORY EXTRACTION GUIDELINES:

Extract domain-specific terms with their definitions. Taxonomic memories are:
- **Terms/Concepts**: Named entities, technical terms, jargon, acronyms, or domain vocabulary
- **Definitions**: Clear, concise explanations of what the term means in context
- **Domains**: The knowledge area the term belongs to (e.g., "programming", "finance", "medicine")

Focus on extracting:
- Technical terminology and jargon the user uses or discusses
- Acronyms and abbreviations with their expansions
- Domain-specific concepts with contextual definitions
- Named entities that have special meaning in the conversation context
- Process names, methodologies, or frameworks mentioned

# OUTPUT FORMAT:

Your output should conform to a valid JSON object following the schema defined below:
```
{
    "terms": [
        {
            "domain": str,           // Knowledge domain (e.g., "programming", "machine_learning")
            "term": str,             // The term or concept name
            "definition": str,       // Clear definition of the term
            "related_terms": [str],  // Related terms for semantic linking
            "evidence_spans": [      // Source evidence from conversation
                {
                    "start": int,    // Character start position in message
                    "end": int,      // Character end position in message
                    "message_idx": int,  // Index of source message
                    "text": str      // The exact text snippet
                }
            ],
            "confidence_score": float  // 0-1.0 confidence in extraction
        }
    ]
}
```

# TASK REQUIREMENTS:
- Extract domain terminology that has reusable knowledge value
- Each term should have a clear, standalone definition
- Definitions should be understandable without the original conversation context
- Include evidence_spans pointing to where in the conversation the term was discussed
- Group related concepts under appropriate domains
- Use consistent domain naming (lowercase, underscore_separated)
- Generate output in the same language as the conversation
- If no taxonomic terms are present, return an empty 'terms' list
- Do not extract common English words unless they have special domain meaning

# FEW SHOT EXAMPLES:

**Example 1:**
Conversation History: [
    {"user": "Can you explain what a transformer model is in NLP?"},
    {"assistant": "A transformer is a deep learning architecture that uses self-attention mechanisms. It was introduced in the 'Attention is All You Need' paper."}
]
Output:
```
{
    "terms": [
        {
            "domain": "machine_learning",
            "term": "transformer model",
            "definition": "A deep learning architecture that uses self-attention mechanisms for processing sequential data, particularly in NLP tasks.",
            "related_terms": ["attention mechanism", "NLP", "deep learning"],
            "evidence_spans": [
                {
                    "start": 0,
                    "end": 54,
                    "message_idx": 0,
                    "text": "Can you explain what a transformer model is in NLP?"
                }
            ],
            "confidence_score": 0.95
        }
    ]
}
```

**Example 2:**
Conversation History: [
    {"user": "I need to set up a CI/CD pipeline for our microservices."},
    {"assistant": "Sure! For CI/CD with microservices, you'll want to consider tools like Jenkins, GitLab CI, or GitHub Actions."}
]
Output:
```
{
    "terms": [
        {
            "domain": "devops",
            "term": "CI/CD pipeline",
            "definition": "Continuous Integration and Continuous Deployment/Delivery pipeline - an automated workflow for building, testing, and deploying software changes.",
            "related_terms": ["continuous integration", "continuous deployment", "automation"],
            "evidence_spans": [
                {
                    "start": 17,
                    "end": 33,
                    "message_idx": 0,
                    "text": "CI/CD pipeline"
                }
            ],
            "confidence_score": 0.90
        },
        {
            "domain": "software_architecture",
            "term": "microservices",
            "definition": "An architectural style that structures an application as a collection of loosely coupled, independently deployable services.",
            "related_terms": ["distributed systems", "service-oriented architecture"],
            "evidence_spans": [
                {
                    "start": 42,
                    "end": 55,
                    "message_idx": 0,
                    "text": "microservices"
                }
            ],
            "confidence_score": 0.85
        }
    ]
}
```

**Example 3:**
Conversation History: [
    {"user": "What's the weather like today?"},
    {"assistant": "It's sunny with a high of 75 degrees."}
]
Output:
```
{
    "terms": []
}
```
"""

EXTRACTION_PROMPT_TEMPLATE = """
Here is the conversation history between the user and the assistant.

Conversation History:
{conversation_history}
"""

# JSON schema for extraction response validation
EXTRACTION_SCHEMA = {
    "type": "object",
    "properties": {
        "terms": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "domain": {"type": "string"},
                    "term": {"type": "string"},
                    "definition": {"type": "string"},
                    "related_terms": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "evidence_spans": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "start": {"type": "integer"},
                                "end": {"type": "integer"},
                                "message_idx": {"type": "integer"},
                                "text": {"type": "string"},
                            },
                        },
                    },
                    "confidence_score": {
                        "type": "number",
                        "minimum": 0,
                        "maximum": 1,
                    },
                },
                "required": ["domain", "term", "definition"],
            },
        }
    },
    "required": ["terms"],
}


# ═══════════════════════════════════════════════════════════════════════════════
# Consolidation Prompts
# ═══════════════════════════════════════════════════════════════════════════════

CONSOLIDATION_SYSTEM_PROMPT = """
# ROLE
You are a **Taxonomy Curator** responsible for maintaining a clean, non-redundant ontology.
Your task is to analyze new terms against existing terms and determine the appropriate action.

## TASK
For each New Term, analyze it against Existing Terms in the same domain and output a directive:

1. **`ADD`**: The term is new to this domain - no equivalent term exists.
2. **`UPDATE`**: The term exists but the new definition is better, more complete, or more current.
3. **`NONE`**: The term is a duplicate (same or synonymous term with equivalent definition).

## KEY RULES

### `ADD` (New Term)
* Use when no equivalent term exists in the domain
* Different terms in the same domain should be added separately
* Synonyms should typically UPDATE an existing term, not ADD

### `UPDATE` (Better Definition)
* Use when the new definition improves upon an existing one
* Use when adding important related_terms to an existing entry
* The term doesn't need to match exactly - semantic equivalents count

### `NONE` (Duplicate)
* Use when the term and definition are semantically equivalent to an existing entry
* Minor wording differences don't warrant a new entry

## OUTPUT FORMAT
```
{
    "terms": [
        {
            "id": str,                    // The new term's temp ID
            "term": str,                  // The term text
            "domain": str,                // Domain of the term
            "action": str,                // "ADD", "UPDATE", or "NONE"
            "existing_term_id": str|null  // For UPDATE/NONE: existing term ID. For ADD: null
        }
    ]
}
```
"""

CONSOLIDATION_PROMPT_TEMPLATE = """
Here are the existing terms in the taxonomy for domain comparison:
{existing_terms}

Here are the new terms to evaluate:
{new_terms}

Output:
"""

# JSON schema for consolidation response validation
CONSOLIDATION_SCHEMA = {
    "type": "object",
    "properties": {
        "terms": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "term": {"type": "string"},
                    "domain": {"type": "string"},
                    "action": {"type": "string", "enum": ["ADD", "UPDATE", "NONE"]},
                    "existing_term_id": {"type": ["string", "null"]},
                },
                "required": ["id", "action"],
            },
        }
    },
    "required": ["terms"],
}


__all__ = [
    # Extraction
    "EXTRACTION_SYSTEM_PROMPT",
    "EXTRACTION_PROMPT_TEMPLATE",
    "EXTRACTION_SCHEMA",
    # Consolidation
    "CONSOLIDATION_SYSTEM_PROMPT",
    "CONSOLIDATION_PROMPT_TEMPLATE",
    "CONSOLIDATION_SCHEMA",
]
