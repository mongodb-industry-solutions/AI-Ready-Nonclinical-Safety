"""
Models for snapshot memory documents.

Snapshots consolidate short-term memory turns into coherent conversation
segments. They store the actual message history along with metadata about
when and why the snapshot was created.

Key Features:
- Middle-tier conversational memory (STM -> Snapshot -> Episodic)
- STM embedding transfer for efficient vector search
- Cross-session retrieval support
- Topic-aware segmentation
- Soft delete support
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Dict, List, Literal, Optional

from bson import ObjectId
from mongomem_core.common.utils import utcnow
from mongomem_core.models.memory.base import (
    BaseMemoryIn,
    ChunkVisibility,
    HasEmbeddings,
    MessageRole,
)
from mongomem_core.models.types import PyObjectId
from pydantic import (
    BaseModel,
    Field,
    field_serializer,
    model_validator,
)


class SnapshotFunctionCall(BaseModel):
    """Function call structure for snapshots (OpenAI-compatible format)."""

    name: str
    arguments: str


class SnapshotToolCall(BaseModel):
    """Tool call structure for snapshots (OpenAI-compatible format)."""

    id: str = Field(..., description="Unique identifier for this tool call")
    type: Literal["function"] = "function"
    function: SnapshotFunctionCall


class SnapshotMessage(BaseModel):
    """
    A message within a snapshot.

    This represents a single turn in the conversation that has been
    consolidated into a snapshot.
    """

    role: MessageRole = Field(..., description="Role of the message author")
    content: Optional[str] = Field(
        default=None, description="Message content (can be None for tool_calls)"
    )
    timestamp: datetime = Field(..., description="When the message was created")

    # Multi-agent attribution
    agent_id: Optional[str] = Field(
        default=None,
        description="ID of the agent that authored this message (for multi-agent sessions)",
    )

    # Tool call fields
    tool_calls: Optional[List[SnapshotToolCall]] = Field(
        default=None, description="Tool calls for assistant messages"
    )
    tool_call_id: Optional[str] = Field(
        default=None, description="Tool call ID for tool role messages"
    )

    # STM embedding transferred during snapshot creation (user messages only)
    stm_embedding: Optional[List[float]] = Field(
        default=None,
        description="Original STM embedding transferred during snapshot creation",
    )

    @model_validator(mode="after")
    def validate_message_content(self) -> "SnapshotMessage":
        if self.role == MessageRole.TOOL:
            if not self.tool_call_id:
                raise ValueError("tool role messages must have tool_call_id")
            if not self.content:
                raise ValueError("tool role messages must have content")
        elif self.role == MessageRole.ASSISTANT:
            if not self.content and not self.tool_calls:
                raise ValueError("assistant messages must have either content or tool_calls")
        else:
            if not self.content:
                raise ValueError(f"{self.role} messages must have content")
        return self


class SnapshotIn(BaseMemoryIn):
    """
    Input model for creating a snapshot.

    Snapshots consolidate short-term memory turns into coherent
    conversation segments.
    """

    # Management fields
    session_id: str = Field(..., description="Session this snapshot belongs to")
    share_learning_with_team: bool = Field(
        default=True,
        description="Whether to share learning extractions with agent's team cohort",
    )

    # Payload fields
    messages: List[SnapshotMessage] = Field(..., description="List of messages in this snapshot")
    snapshot_reason: Literal["auto", "manual", "idle", "disconnect", "scheduled", "topic_shift"] = (
        Field(..., description="Reason why this snapshot was created")
    )
    ttl_days: Optional[int] = Field(
        default=None, description="Time-to-live in days (for expires_at calculation)"
    )

    # Topic Detection Fields
    topic_id: Optional[str] = Field(
        default=None,
        description="UUID identifier for topic grouping when snapshot triggered by topic shift",
    )
    topic_shift_score: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Cosine similarity score that triggered the topic shift",
    )
    topic_title: Optional[str] = Field(
        default=None,
        max_length=500,
        description="Generated or inferred title for the topic",
    )

    # Async Topic Detection Fields.
    boundary_turn_seq: Optional[int] = Field(
        default=None,
        description="STM turn sequence boundary for snapshot deduplication and ordering",
    )
    trigger_source: Literal["topic_shift", "message_count", "token_count", "manual"] = Field(
        default="manual",
        description="Source that triggered snapshot creation for deduplication logic",
    )

    # Multi-agent attribution
    contributing_agent_ids: List[str] = Field(
        default_factory=list,
        description="List of agent IDs that contributed messages to this snapshot",
    )


class SnapshotUpdate(BaseModel):
    """
    Model for partial updates to snapshot memory.

    Supports updating visibility, topic metadata, and promotion status.
    """

    # Visibility and access control
    visibility: Optional[ChunkVisibility] = Field(
        default=None, description="Visibility scope for RBAC"
    )
    project_id: Optional[str] = Field(default=None, description="Project ID for shared visibility")

    # Topic metadata updates
    topic_id: Optional[str] = Field(default=None, description="Topic grouping identifier")
    topic_title: Optional[str] = Field(default=None, max_length=500, description="Topic title")

    # Promotion tracking
    promoted: Optional[bool] = Field(
        default=None, description="Whether snapshot has been promoted to episodic memory"
    )

    # Embedding updates (for deferred embedding strategy)
    embedding: Optional[List[float]] = Field(default=None, description="Embedding vector")
    embedding_model_id: Optional[str] = Field(
        default=None, description="Model used to generate embedding"
    )
    embedding_dimension: Optional[int] = Field(
        default=None, description="Dimension of embedding vector"
    )

    # Metadata
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="Additional metadata")


class SnapshotBase(SnapshotIn, HasEmbeddings):
    """Base model with org/user context and embedding metadata."""

    # Management fields
    org_id: str = Field(..., description="Organization/tenant ID")
    user_id: str = Field(..., description="User ID who owns this snapshot")
    timestamp: datetime = Field(
        default_factory=utcnow, description="When this snapshot was created"
    )
    expires_at: Optional[datetime] = Field(
        default=None,
        description="When this snapshot should expire (TTL, auto-calculated if not provided)",
    )
    promoted: bool = Field(
        default=False, description="Whether this snapshot has been promoted to LTM"
    )

    # Embedding metadata
    embedding_model_id: Optional[str] = Field(
        default=None,
        description="Model identifier used to generate the embedding",
    )
    embedding_dimension: Optional[int] = Field(
        default=None,
        description="Dimension of the embedding vector",
    )
    embedding_strategy: Optional[str] = Field(
        default=None,
        description="Strategy used to create the embedding (e.g., 'transfer', 'generate', 'defer')",
    )

    # Soft delete support
    deleted: bool = Field(default=False, description="Soft delete flag")
    deleted_at: Optional[datetime] = Field(default=None, description="Timestamp when soft deleted")

    @model_validator(mode="after")
    def set_expires_at_from_ttl(self) -> "SnapshotBase":
        """Calculate expires_at from ttl_days if not explicitly set."""
        if self.expires_at is None:
            ttl_days = self.ttl_days or 30
            self.expires_at = utcnow() + timedelta(days=ttl_days)
        return self

    model_config = {
        "arbitrary_types_allowed": True,
        "from_attributes": True,
        "populate_by_name": True,
        "use_enum_values": True,
    }


class SnapshotDB(SnapshotBase):
    """Database model with MongoDB _id."""

    id: PyObjectId = Field(default_factory=PyObjectId, alias="_id")

    @field_serializer("id", when_used="json")
    def _serialize_id(self, v: ObjectId) -> str:
        return str(v)


class SnapshotOut(SnapshotBase):
    """Output model for API responses."""

    id: str = Field(..., alias="_id")
    # Excluded from API serialization output.
    ttl_days: Optional[int] = Field(default=None, exclude=True)

    # Transient field from MongoDB $vectorSearch (not persisted to DB).
    score: Optional[float] = Field(
        default=None,
        description="Vector search similarity score from MongoDB Atlas (query-specific, not stored)",
        exclude=True,
    )
