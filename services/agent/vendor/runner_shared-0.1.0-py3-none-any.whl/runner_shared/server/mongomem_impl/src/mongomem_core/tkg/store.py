"""Low-level storage operations for TKG entities and edges."""
