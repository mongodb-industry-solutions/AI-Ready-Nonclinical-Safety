"""
Models for retrieval blocks, scores, and results.

This module provides unified data structures for the retrieval pipeline,
including memory chunk representations, context configuration, response models,
and thread retrieval results.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Union

from mongomem_core.models.memory.base import MessageRole
from mongomem_core.models.memory.episodic import EpisodicOut
from mongomem_core.models.memory.procedural import ProceduralOut
from mongomem_core.models.memory.semantic import SemanticOut
from mongomem_core.models.memory.short_term import ShortTermOut, ToolCall
from mongomem_core.models.memory.snapshot import SnapshotOut
from mongomem_core.models.memory.taxonomic import TaxonomicOut
from pydantic import BaseModel, Field, field_validator, model_validator


class MemorySource(str, Enum):
    """Source type for memory chunks."""

    STM = "stm"
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    TAXONOMIC = "taxonomic"
    PROCEDURAL = "procedural"


class FormatStyle(str, Enum):
    """Format style for context output."""

    OPENAI = "openai"
    CLAUDE = "claude"
    JINJA2 = "jinja2"


class ModelType(str, Enum):
    """Model type for context formatting."""

    OPENAI = "openai"
    CLAUDE = "claude"
    ANTHROPIC = "anthropic"  # Alias for claude
    GEMINI = "gemini"
    GENERIC = "generic"


class MemoryChunk(BaseModel):
    """
    Unified representation of memory from any source (STM, episodic, semantic).

    This model provides a common interface for memory chunks retrieved from
    different memory types, enabling uniform processing in the retrieval pipeline.
    """

    id: str = Field(..., description="Memory document ID")
    content: str = Field(..., description="Text content of the memory chunk")
    source: MemorySource = Field(..., description="Source type: stm, episodic, or semantic")
    timestamp: datetime = Field(..., description="Timestamp when the memory was created")
    embedding: Optional[List[float]] = Field(
        default=None, description="Vector embedding for the memory chunk"
    )
    similarity_score: Optional[float] = Field(
        default=None, description="Similarity score from vector search (0.0-1.0)"
    )
    metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Additional metadata about the memory chunk",
    )

    model_config = {
        "arbitrary_types_allowed": True,
        "use_enum_values": True,
    }

    @property
    def org_id(self) -> Optional[str]:
        """Get org_id from metadata if available."""
        if self.metadata:
            return self.metadata.get("org_id")
        return None

    @staticmethod
    def _extract_embedding(
        obj: Union[ShortTermOut, EpisodicOut, SemanticOut, TaxonomicOut, ProceduralOut],
    ) -> Optional[List[float]]:
        """
        Extract embedding if present, otherwise None.

        Args:
            obj: Memory output document with potential embedding

        Returns:
            Embedding vector or None
        """
        if hasattr(obj, "embedding_present") and obj.embedding_present():
            return obj.embedding
        return None

    @staticmethod
    def _extract_similarity_score(
        obj: Union[ShortTermOut, EpisodicOut, SemanticOut, TaxonomicOut, ProceduralOut],
        provided_score: Optional[float],
    ) -> Optional[float]:
        """
        Extract similarity score from object or use provided.

        Args:
            obj: Memory output document with potential score attribute
            provided_score: Optional explicitly provided similarity score

        Returns:
            Similarity score or None
        """
        if provided_score is not None:
            return provided_score
        if hasattr(obj, "score") and isinstance(obj.score, (int, float)):
            return float(obj.score)
        return None

    @staticmethod
    def _compute_reinforcement_importance(
        obj: Any,
    ) -> Optional[float]:
        """Compute importance score from reinforcement data.

        Uses log-scale reinforcement with recency decay:
        - 50 reinforcements today -> ~1.0
        - 50 reinforcements 2 weeks ago -> ~0.5
        - 1 reinforcement -> ~0.14
        - 0 reinforcements -> None (no importance signal)
        """
        reinforcement_count = getattr(obj, "reinforcement_count", 0) or 0
        if reinforcement_count <= 0:
            return None

        last_reinforced_at = getattr(obj, "last_reinforced_at", None)
        base_importance = min(1.0, math.log1p(reinforcement_count) / math.log1p(50))

        if last_reinforced_at:
            now = datetime.now(timezone.utc)
            if last_reinforced_at.tzinfo is None:
                last_reinforced_at = last_reinforced_at.replace(tzinfo=timezone.utc)
            days_since = max(0.0, (now - last_reinforced_at).total_seconds() / 86400)
            recency_factor = math.exp(-0.05 * days_since)
            return base_importance * recency_factor

        return base_importance

    @staticmethod
    def _extract_role_value(role: Union[MessageRole, str]) -> str:
        """
        Extract role as string value.

        Args:
            role: Role value (MessageRole enum or string)

        Returns:
            Role as string
        """
        if hasattr(role, "value"):
            return str(role.value)
        return str(role)

    @staticmethod
    def _extract_tool_calls_summary(
        tool_calls: Optional[List[ToolCall]],
    ) -> Optional[Dict[str, Any]]:
        """
        Extract lightweight summary of tool calls for metadata.

        Stores only essential information (count, names) instead of full
        serialization to avoid memory overhead with large tool_calls lists.

        Args:
            tool_calls: List of tool calls or None

        Returns:
            Dictionary with tool_calls_count and tool_names, or None if empty
        """
        if not tool_calls:
            return None

        return {
            "tool_calls_count": len(tool_calls),
            "tool_names": [tc.name for tc in tool_calls],
            # Optionally include IDs if needed for correlation
            "tool_call_ids": [tc.id for tc in tool_calls if tc.id],
        }

    @classmethod
    def from_short_term(
        cls,
        stm: ShortTermOut,
        similarity_score: Optional[float] = None,
    ) -> MemoryChunk:
        """
        Create a MemoryChunk from a ShortTermOut document.

        Args:
            stm: Short-term memory output document
            similarity_score: Optional similarity score from vector search

        Returns:
            MemoryChunk instance
        """
        # Extract text content - use content field, or construct from tool calls if needed
        text = stm.content or ""
        if stm.tool_calls and not text:
            tool_texts = [f"{tc.name}({tc.get_arguments_json()})" for tc in (stm.tool_calls or [])]
            text = "; ".join(tool_texts)
        if not text.strip():
            raise ValueError(
                f"Cannot create MemoryChunk from ShortTermOut {stm.id}: "
                "both content and tool_calls are empty/None"
            )
        metadata: Dict[str, Any] = {
            "session_id": stm.session_id,
            "role": cls._extract_role_value(stm.role),
            "turn_seq": stm.turn_seq,
            "promoted": stm.promoted,
        }
        if stm.agent_id:
            metadata["agent_id"] = stm.agent_id
        if stm.model_name:
            metadata["model_name"] = stm.model_name
        if stm.tokens is not None:
            metadata["tokens"] = stm.tokens
        # Store lightweight summary instead of full serialization to avoid memory overhead
        tool_calls_summary = cls._extract_tool_calls_summary(stm.tool_calls)
        if tool_calls_summary:
            metadata["tool_calls"] = tool_calls_summary

        return cls(
            id=stm.id,
            content=text,
            source=MemorySource.STM,
            timestamp=stm.timestamp,
            embedding=cls._extract_embedding(stm),
            similarity_score=cls._extract_similarity_score(stm, similarity_score),
            metadata=metadata,
        )

    @classmethod
    def from_episodic(
        cls, episodic: EpisodicOut, similarity_score: Optional[float] = None
    ) -> MemoryChunk:
        """
        Create a MemoryChunk from an EpisodicOut document.

        Args:
            episodic: Episodic memory output document
            similarity_score: Optional similarity score from vector search

        Returns:
            MemoryChunk instance
        """
        # Prefer summary_text, fall back to content
        text = episodic.summary_text or episodic.content or ""

        metadata: Dict[str, Any] = {
            "session_id": episodic.session_id,
            "title": episodic.title,
            "summary_type": episodic.summary_type,
            "source_agent": episodic.source_agent,
            "participants": episodic.participants,
            "tags": episodic.tags,
            "org_id": episodic.org_id,
        }
        if episodic.snapshot_ref_id:
            metadata["snapshot_ref_id"] = episodic.snapshot_ref_id
        if episodic.agent_id:
            metadata["agent_id"] = episodic.agent_id
        if episodic.extraction_source:
            metadata["extraction_source"] = episodic.extraction_source

        importance = cls._compute_reinforcement_importance(episodic)
        if importance is not None:
            metadata["importance"] = importance

        return cls(
            id=episodic.id,
            content=text,
            source=MemorySource.EPISODIC,
            timestamp=episodic.timestamp,
            embedding=cls._extract_embedding(episodic),
            similarity_score=cls._extract_similarity_score(episodic, similarity_score),
            metadata=metadata,
        )

    @classmethod
    def from_semantic(
        cls, semantic: SemanticOut, similarity_score: Optional[float] = None
    ) -> MemoryChunk:
        """
        Create a MemoryChunk from a SemanticOut document.

        Args:
            semantic: Semantic memory output document
            similarity_score: Optional similarity score from vector search

        Returns:
            MemoryChunk instance
        """
        metadata: Dict[str, Any] = {
            "label": semantic.label,
            "version": semantic.version,
            "is_latest": semantic.is_latest,
            "org_id": semantic.org_id,
        }
        if semantic.source:
            metadata["source"] = semantic.source
        if semantic.contextual_metadata:
            metadata["contextual_metadata"] = semantic.contextual_metadata
        if semantic.agent_id:
            metadata["agent_id"] = semantic.agent_id
        if semantic.extraction_source:
            metadata["extraction_source"] = semantic.extraction_source
        if semantic.memory_lineage_id:
            metadata["memory_lineage_id"] = semantic.memory_lineage_id

        importance = cls._compute_reinforcement_importance(semantic)
        if importance is not None:
            metadata["importance"] = importance

        return cls(
            id=semantic.id,
            content=semantic.content,
            source=MemorySource.SEMANTIC,
            timestamp=semantic.timestamp,
            embedding=cls._extract_embedding(semantic),
            similarity_score=cls._extract_similarity_score(semantic, similarity_score),
            metadata=metadata,
        )

    @classmethod
    def from_taxonomic(
        cls, taxonomic: TaxonomicOut, similarity_score: Optional[float] = None
    ) -> MemoryChunk:
        """
        Create a MemoryChunk from a TaxonomicOut document.

        Args:
            taxonomic: Taxonomic memory output document
            similarity_score: Optional similarity score from vector search

        Returns:
            MemoryChunk instance
        """
        # Build content from domain, term, and definition
        content = f"{taxonomic.domain}/{taxonomic.term}: {taxonomic.definition}"

        metadata: Dict[str, Any] = {
            "domain": taxonomic.domain,
            "term": taxonomic.term,
            "version": taxonomic.version,
            "is_latest": taxonomic.is_latest,
            "org_id": taxonomic.org_id,
            "query_expansion": taxonomic.query_expansion,
        }
        if taxonomic.related_terms:
            metadata["related_terms"] = taxonomic.related_terms
        if taxonomic.contextual_metadata:
            metadata["contextual_metadata"] = taxonomic.contextual_metadata
        if taxonomic.agent_id:
            metadata["agent_id"] = taxonomic.agent_id
        if taxonomic.extraction_source:
            metadata["extraction_source"] = taxonomic.extraction_source
        if taxonomic.memory_lineage_id:
            metadata["memory_lineage_id"] = taxonomic.memory_lineage_id
        if taxonomic.confidence_score is not None:
            metadata["confidence_score"] = taxonomic.confidence_score
        if taxonomic.creation_method:
            if hasattr(taxonomic.creation_method, "value"):
                metadata["creation_method"] = str(taxonomic.creation_method.value)
            else:
                metadata["creation_method"] = str(taxonomic.creation_method)

        importance = cls._compute_reinforcement_importance(taxonomic)
        if importance is not None:
            metadata["importance"] = importance

        return cls(
            id=taxonomic.id,
            content=content,
            source=MemorySource.TAXONOMIC,
            timestamp=taxonomic.timestamp,
            embedding=cls._extract_embedding(taxonomic),
            similarity_score=cls._extract_similarity_score(taxonomic, similarity_score),
            metadata=metadata,
        )

    @classmethod
    def from_procedural(
        cls, procedural: ProceduralOut, similarity_score: Optional[float] = None
    ) -> MemoryChunk:
        """Create a MemoryChunk from a ProceduralOut document.

        Args:
            procedural: Procedural memory output document
            similarity_score: Optional similarity score from vector search

        Returns:
            MemoryChunk instance
        """
        metadata: Dict[str, Any] = {
            "procedure": procedural.procedure,
            "description": procedural.description,
            "version": procedural.version,
            "is_latest": procedural.is_latest,
            "org_id": procedural.org_id,
        }
        if procedural.tags:
            metadata["tags"] = procedural.tags
        if procedural.allowed_tools:
            metadata["allowed_tools"] = procedural.allowed_tools
        if procedural.trigger_conditions:
            metadata["trigger_conditions"] = procedural.trigger_conditions
        if procedural.agent_id:
            metadata["agent_id"] = procedural.agent_id
        if procedural.extraction_source:
            metadata["extraction_source"] = procedural.extraction_source
        if procedural.memory_lineage_id:
            metadata["memory_lineage_id"] = procedural.memory_lineage_id
        if procedural.steps:
            metadata["step_count"] = len(procedural.steps)
        if procedural.content_token_count is not None:
            metadata["content_token_count"] = procedural.content_token_count

        importance = cls._compute_reinforcement_importance(procedural)
        if importance is not None:
            metadata["importance"] = importance

        return cls(
            id=procedural.id,
            content=procedural.content,
            source=MemorySource.PROCEDURAL,
            timestamp=procedural.timestamp,
            embedding=cls._extract_embedding(procedural),
            similarity_score=cls._extract_similarity_score(procedural, similarity_score),
            metadata=metadata,
        )


class ContextConfig(BaseModel):
    """
    Configuration for context building.

    Controls how memories are retrieved, ranked, and formatted into context
    for LLM consumption.
    """

    max_tokens: int = Field(
        default=16000,
        ge=1,
        description="Maximum token budget for the context",
    )
    token_buffer: int = Field(
        default=500,
        ge=0,
        description="Reserve tokens for formatting overhead (system prompts, metadata, etc.)",
    )
    format_style: FormatStyle = Field(
        default=FormatStyle.OPENAI,
        description="Format style for context output: openai, claude, or jinja2",
    )
    model_type: ModelType = Field(
        default=ModelType.OPENAI,
        description="Model type for context formatting (affects tokenization and formatting)",
    )
    similarity_threshold: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
        description="Minimum similarity score threshold for including memories (0.0-1.0)",
    )
    ranking_weights: Dict[str, float] = Field(
        default_factory=dict,
        description="Weights for ranking factors (e.g., 'recency', 'relevance', 'importance')",
    )
    enabled_sources: Set[MemorySource] = Field(
        default_factory=lambda: {MemorySource.EPISODIC, MemorySource.SEMANTIC},
        description="Set of memory sources to include in context building",
    )
    include_memories: bool = Field(
        default=False,
        description="If True, attach selected MemoryChunks to ContextResponse.selected_memories",
    )

    @field_validator("model_type", mode="before")
    @classmethod
    def validate_model_type(cls, v: Any) -> Any:
        """Convert string to ModelType enum if needed."""
        if isinstance(v, str):
            return ModelType(v.lower())
        return v

    @field_validator("format_style", mode="before")
    @classmethod
    def validate_format_style(cls, v: Any) -> Any:
        """Convert string to FormatStyle enum if needed."""
        if isinstance(v, str):
            return FormatStyle(v.lower())
        return v

    @field_validator("enabled_sources", mode="before")
    @classmethod
    def validate_enabled_sources(cls, v: Any) -> Any:
        """Convert string literals to MemorySource enum values."""
        if isinstance(v, (list, set)):
            return {MemorySource(s) if isinstance(s, str) else s for s in v}
        return v

    @model_validator(mode="after")
    def validate_config(self) -> ContextConfig:
        """Validate configuration constraints."""
        if not self.enabled_sources:
            raise ValueError("enabled_sources cannot be empty")
        return self

    @classmethod
    def from_params(
        cls,
        model_type: Union[str, ModelType] = ModelType.OPENAI,
        max_tokens: Optional[int] = None,
        similarity_threshold: float = 0.0,
        enabled_sources: Optional[Set[Union[str, MemorySource]]] = None,
        include_memories: bool = False,
        **kwargs: Any,
    ) -> ContextConfig:
        """
        Create a ContextConfig from individual parameters with flexible types.

        This factory method handles conversion of string parameters to enums,
        making it convenient for API methods that accept flexible input types.

        Args:
            model_type: Target model type (string or ModelType enum)
            max_tokens: Token budget limit (None uses default)
            similarity_threshold: Minimum similarity score
            enabled_sources: Memory sources to enable (None uses all)
            **kwargs: Additional parameters to pass to ContextConfig

        Returns:
            ContextConfig instance with validated settings

        Example:
            >>> config = ContextConfig.from_params(
            ...     model_type="claude",
            ...     max_tokens=8000,
            ...     enabled_sources={"stm", "episodic"},
            ... )
        """
        config_kwargs: Dict[str, Any] = {
            "model_type": model_type,
            "similarity_threshold": similarity_threshold,
            "include_memories": include_memories,
            **kwargs,
        }
        if max_tokens is not None:
            config_kwargs["max_tokens"] = max_tokens
        if enabled_sources is not None:
            config_kwargs["enabled_sources"] = enabled_sources
        if config_kwargs.get("format_style") is None:
            config_kwargs.pop("format_style", None)

        return cls(**config_kwargs)

    model_config = {
        "use_enum_values": True,
    }


class ContextMetadata(BaseModel):
    """
    Metadata about the context building process.

    Provides information about token usage, memory counts, and timing
    for debugging and optimization.
    """

    token_count: int = Field(
        default=0,
        ge=0,
        description="Total token count in the formatted context",
    )
    memory_counts: Dict[str, int] = Field(
        default_factory=dict,
        description="Count of memories by source type (e.g., {'stm': 5, 'episodic': 3})",
    )
    timing: Dict[str, float] = Field(
        default_factory=dict,
        description="Timing information in seconds (e.g., {'retrieval': 0.15, 'formatting': 0.02})",
    )

    def add_timing(self, operation: str, duration_seconds: float) -> None:
        """Add timing information for an operation."""
        self.timing[operation] = duration_seconds

    def increment_memory_count(self, source: Union[MemorySource, str]) -> None:
        """Increment the count for a memory source."""
        source_str = source.value if isinstance(source, MemorySource) else source
        self.memory_counts[source_str] = self.memory_counts.get(source_str, 0) + 1


class ContextResponse(BaseModel):
    """
    Final response model for context building.

    Contains the formatted context and metadata about the retrieval process.
    """

    formatted_context: Union[str, List[Dict[str, Any]]] = Field(
        ...,
        description=(
            "Formatted context as a string (for simple formats) or list of dicts "
            "(for structured formats like OpenAI messages)"
        ),
    )
    metadata: ContextMetadata = Field(
        ...,
        description="Metadata about the context building process",
    )
    selected_memories: Optional[List[MemoryChunk]] = Field(
        default=None,
        description="Post-budget selected memory chunks. Only populated when include_memories=True.",
    )

    model_config = {
        "arbitrary_types_allowed": True,
    }


@dataclass
class ConversationThread:
    """
    Result of a thread retrieval operation.

    Contains a coherent sequence of snapshots representing a conversation
    thread, along with metadata about the retrieval.

    Attributes:
        snapshots: Chronologically ordered list of snapshots
        anchor: The primary anchor snapshot that started the retrieval
        anchor_score: Similarity score of the anchor snapshot
        total_tokens: Estimated total tokens across all snapshots
        sessions_included: Set of unique session IDs in the thread
        expansion_path: Debug info showing how thread was expanded

    Example:
        >>> thread = retrieve_conversation_thread(backend, org_id, query, config)
        >>> for snap in thread.snapshots:
        ...     print(f"[{snap.session_id}] {snap.topic_title}")
        >>> print(f"Total tokens: {thread.total_tokens}")
    """

    snapshots: List[SnapshotOut] = field(default_factory=list)
    anchor: Optional[SnapshotOut] = None
    anchor_score: float = 0.0
    total_tokens: int = 0
    sessions_included: List[str] = field(default_factory=list)
    expansion_path: List[str] = field(default_factory=list)

    @property
    def is_empty(self) -> bool:
        """Check if thread contains any snapshots."""
        return len(self.snapshots) == 0

    @property
    def is_cross_session(self) -> bool:
        """Check if thread spans multiple sessions."""
        return len(set(self.sessions_included)) > 1

    @property
    def message_count(self) -> int:
        """Total number of messages across all snapshots."""
        return sum(len(s.messages) for s in self.snapshots)

    @property
    def time_range(self) -> Optional[tuple[datetime, datetime]]:
        """Time range covered by the thread (earliest, latest)."""
        if not self.snapshots:
            return None
        timestamps = [s.timestamp for s in self.snapshots if s.timestamp]
        if not timestamps:
            return None
        return (min(timestamps), max(timestamps))

    def to_context_string(self, include_metadata: bool = False) -> str:
        """
        Convert thread to a single context string for LLM consumption.

        Args:
            include_metadata: Include session/timestamp info in output

        Returns:
            Formatted string of conversation history
        """
        parts = []
        for snap in self.snapshots:
            if include_metadata:
                parts.append(f"--- Session: {snap.session_id} | {snap.timestamp} ---")
            for msg in snap.messages:
                if msg.content:
                    parts.append(f"{msg.role.value}: {msg.content}")
        return "\n".join(parts)

    def to_messages(self) -> List[Dict[str, Any]]:
        """
        Convert thread to message list for LLM API.

        Returns:
            List of message dicts with 'role' and 'content'
        """
        messages = []
        for snap in self.snapshots:
            for msg in snap.messages:
                msg_dict: Dict[str, Any] = {"role": msg.role.value}
                if msg.content:
                    msg_dict["content"] = msg.content
                if msg.tool_calls:
                    msg_dict["tool_calls"] = [tc.model_dump() for tc in msg.tool_calls]
                if msg.tool_call_id:
                    msg_dict["tool_call_id"] = msg.tool_call_id
                messages.append(msg_dict)
        return messages


@dataclass
class ThreadRetrievalMetrics:
    """
    Metrics and diagnostics from a thread retrieval operation.

    Useful for debugging and optimizing retrieval configuration.
    """

    search_mode: str = ""
    expansion_strategy: str = ""
    anchors_considered: int = 0
    snapshots_evaluated: int = 0
    snapshots_included: int = 0
    snapshots_filtered_by_relevancy: int = 0
    snapshots_filtered_by_budget: int = 0
    tokens_used: int = 0
    tokens_budget: int = 0
    search_latency_ms: float = 0.0
    expansion_latency_ms: float = 0.0
    total_latency_ms: float = 0.0


# =============================================================================
# Exports
# =============================================================================


__all__ = [
    # Enums
    "MemorySource",
    "FormatStyle",
    "ModelType",
    # Memory chunk models
    "MemoryChunk",
    # Context configuration
    "ContextConfig",
    "ContextMetadata",
    "ContextResponse",
    # Thread retrieval
    "ConversationThread",
    "ThreadRetrievalMetrics",
]
