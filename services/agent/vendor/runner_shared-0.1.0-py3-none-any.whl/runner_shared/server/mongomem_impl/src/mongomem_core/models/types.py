"""
Common type helpers for MongoDB documents in `mongomem_core`.

Provides Pydantic-compatible wrappers for BSON types like ObjectId.
"""

from __future__ import annotations

from typing import Any

from bson import ObjectId
from pydantic import GetCoreSchemaHandler
from pydantic_core import core_schema
from pydantic_core.core_schema import CoreSchema


class PyObjectId(ObjectId):
    """
    PyObjectId wrapper for MongoDB ObjectId with proper Pydantic v2 validation.

    This allows ObjectId fields to be used seamlessly in Pydantic models while
    maintaining proper serialization for JSON responses.
    """

    @classmethod
    def __get_pydantic_core_schema__(
        cls, source_type: Any, handler: GetCoreSchemaHandler
    ) -> CoreSchema:
        return core_schema.no_info_wrap_validator_function(
            cls._validate,
            core_schema.is_instance_schema(ObjectId),
            serialization=core_schema.plain_serializer_function_ser_schema(
                lambda v: str(v),
                when_used="json",
            ),
        )

    @staticmethod
    def _validate(value: Any, _handler: Any) -> PyObjectId:
        """Validate and convert to PyObjectId, preserving ObjectId type."""
        if value is None:
            raise ValueError("ObjectId cannot be None")
        if isinstance(value, ObjectId):
            return value if isinstance(value, PyObjectId) else PyObjectId(str(value))
        if isinstance(value, str) and ObjectId.is_valid(value):
            return PyObjectId(value)
        raise ValueError(f"Invalid ObjectId: {value}")


__all__ = ["PyObjectId"]
