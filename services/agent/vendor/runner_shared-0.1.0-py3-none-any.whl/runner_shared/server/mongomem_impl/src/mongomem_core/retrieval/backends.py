"""
Backend protocols and implementations for snapshot search.

This module provides the abstraction layer between thread retrieval logic
and the underlying storage/search implementation. This allows the thread
retrieval algorithm to be storage-agnostic.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Protocol

from mongomem_core.common.constants import VECTOR_SEARCH_CANDIDATE_MULTIPLIER
from mongomem_core.models.memory.snapshot import SnapshotOut
from pymongo.database import Database

if TYPE_CHECKING:
    from mongomem_core.protocols import EmbedderProtocol

logger = logging.getLogger(__name__)

# Reciprocal Rank Fusion constant (standard value from research)
# Higher values give less weight to rank position
RRF_K = 60


class SnapshotSearchBackend(Protocol):
    """
    Protocol for snapshot search operations.

    Implement this to plug in different storage backends (MongoDB,
    Elasticsearch, Pinecone, etc.) while keeping the thread retrieval
    algorithm unchanged.

    Example:
        >>> class MyCustomBackend:
        ...     def vector_search(self, org_id, embedding, top_k):
        ...         return my_vector_db.search(embedding, top_k)
        ...     # ... implement other methods
        >>>
        >>> thread = retrieve_conversation_thread(MyCustomBackend(), org_id, query, config)
    """

    def vector_search(
        self,
        org_id: str,
        embedding: List[float],
        top_k: int,
        *,
        exclude_ids: Optional[set[str]] = None,
    ) -> List[SnapshotOut]:
        """
        Search snapshots by embedding similarity.

        Args:
            org_id: Organization ID
            embedding: Query embedding vector
            top_k: Number of results to return
            exclude_ids: Optional set of snapshot IDs to exclude

        Returns:
            List of SnapshotOut with score populated
        """
        ...

    def text_search(
        self,
        org_id: str,
        query: str,
        top_k: int,
    ) -> List[SnapshotOut]:
        """
        Full-text search across snapshot message content.

        Args:
            org_id: Organization ID
            query: Text query
            top_k: Number of results to return

        Returns:
            List of SnapshotOut with score populated
        """
        ...

    def hybrid_search(
        self,
        org_id: str,
        query: str,
        embedder: "EmbedderProtocol",
        top_k: int,
    ) -> List[SnapshotOut]:
        """
        Combined vector + text search.

        Args:
            org_id: Organization ID
            query: Text query (will be embedded)
            embedder: Embedder for query embedding
            top_k: Number of results to return

        Returns:
            List of SnapshotOut with combined score
        """
        ...

    def list_by_topic(
        self,
        org_id: str,
        session_id: str,
        topic_id: str,
    ) -> List[SnapshotOut]:
        """
        List all snapshots belonging to a topic within a session.

        Args:
            org_id: Organization ID
            session_id: Session ID
            topic_id: Topic ID

        Returns:
            List of SnapshotOut sorted by timestamp
        """
        ...

    def list_by_session(
        self,
        org_id: str,
        session_id: str,
        *,
        limit: int = 100,
    ) -> List[SnapshotOut]:
        """
        List all snapshots for a session.

        Args:
            org_id: Organization ID
            session_id: Session ID
            limit: Maximum number of results

        Returns:
            List of SnapshotOut sorted by timestamp ascending
        """
        ...


class MongoSnapshotBackend:
    """
    MongoDB implementation of SnapshotSearchBackend.

    Uses the existing mongomem_core snapshot CRUD operations and
    MongoDB Atlas Vector Search for similarity queries.
    """

    def __init__(
        self,
        db: Database,
        *,
        vector_index_name: str = "snap_embedding_vector_index",
        text_index_name: str = "snap_text_search_index",
    ) -> None:
        """
        Initialize MongoDB snapshot backend.

        Args:
            db: MongoDB database instance
            vector_index_name: Name of the vector search index
            text_index_name: Name of the text search index
        """
        self._db = db
        self._vector_index_name = vector_index_name
        self._text_index_name = text_index_name

    def vector_search(
        self,
        org_id: str,
        embedding: List[float],
        top_k: int,
        *,
        exclude_ids: Optional[set[str]] = None,
    ) -> List[SnapshotOut]:
        """Search snapshots by embedding similarity using Atlas Vector Search."""
        from mongomem_core.memory.snapshot import search_snapshots

        results = search_snapshots(
            db=self._db,
            embedding=embedding,
            org_id=org_id,
            top_k=top_k,
            index_name=self._vector_index_name,
        )

        # Filter out excluded IDs if provided
        if exclude_ids:
            results = [r for r in results if r.id not in exclude_ids]

        return results

    def text_search(
        self,
        org_id: str,
        query: str,
        top_k: int,
    ) -> List[SnapshotOut]:
        """
        Full-text search across snapshot message content.

        Uses MongoDB Atlas Search with text index on messages.content.
        """
        from mongomem_core.common.utils import handle_db_error
        from mongomem_core.storage import get_collection
        from mongomem_core.storage.collections import SnapshotMemoryCollection

        col = get_collection(SnapshotMemoryCollection(), self._db)

        # Build Atlas Search pipeline
        pipeline: List[Dict[str, Any]] = [
            {
                "$search": {
                    "index": self._text_index_name,
                    "compound": {
                        "must": [
                            {
                                "text": {
                                    "query": query,
                                    "path": "messages.content",
                                }
                            }
                        ],
                        "filter": [
                            {"equals": {"path": "org_id", "value": org_id}},
                            {"equals": {"path": "deleted", "value": False}},
                        ],
                    },
                }
            },
            {"$set": {"score": {"$meta": "searchScore"}}},
            {"$sort": {"score": -1}},
            {"$limit": top_k},
        ]

        with handle_db_error(
            operation="aggregate",
            collection="snapshot_memory",
            log_message="Text search failed for org=%s query=%s",
            log_args_tuple=(org_id, query[:50]),
        ):
            cursor = col.aggregate(pipeline)
            results = []
            for doc in cursor:
                doc["_id"] = str(doc["_id"])
                results.append(SnapshotOut.model_validate(doc))
            return results

    def hybrid_search(
        self,
        org_id: str,
        query: str,
        embedder: "EmbedderProtocol",
        top_k: int,
    ) -> List[SnapshotOut]:
        """
        Combined vector + text search with reciprocal rank fusion.

        Performs both searches in parallel and combines results using RRF.
        """
        # Get vector results
        query_embedding = embedder.embed(query)
        expanded_k = top_k * VECTOR_SEARCH_CANDIDATE_MULTIPLIER
        vector_results = self.vector_search(org_id, query_embedding, expanded_k)

        # Get text results
        text_results = self.text_search(org_id, query, expanded_k)

        # Reciprocal Rank Fusion
        rrf_scores: Dict[str, float] = {}
        id_to_snapshot: Dict[str, SnapshotOut] = {}
        k = 60  # RRF constant

        for rank, snap in enumerate(vector_results):
            rrf_scores[snap.id] = rrf_scores.get(snap.id, 0) + 1 / (k + rank + 1)
            id_to_snapshot[snap.id] = snap

        for rank, snap in enumerate(text_results):
            rrf_scores[snap.id] = rrf_scores.get(snap.id, 0) + 1 / (k + rank + 1)
            if snap.id not in id_to_snapshot:
                id_to_snapshot[snap.id] = snap

        # Sort by RRF score and return top_k
        sorted_ids = sorted(rrf_scores.keys(), key=lambda x: rrf_scores[x], reverse=True)

        results = []
        for snap_id in sorted_ids[:top_k]:
            snap = id_to_snapshot[snap_id]
            # Update score with RRF score
            snap_dict = snap.model_dump()
            snap_dict["score"] = rrf_scores[snap_id]
            results.append(SnapshotOut.model_validate(snap_dict))

        return results

    def list_by_topic(
        self,
        org_id: str,
        session_id: str,
        topic_id: str,
    ) -> List[SnapshotOut]:
        """List all snapshots belonging to a topic within a session."""
        from mongomem_core.common.utils import handle_db_error
        from mongomem_core.storage import get_collection
        from mongomem_core.storage.collections import SnapshotMemoryCollection

        col = get_collection(SnapshotMemoryCollection(), self._db)

        with handle_db_error(
            operation="find",
            collection="snapshot_memory",
            log_message="Failed to list snapshots by topic: org=%s session=%s topic=%s",
            log_args_tuple=(org_id, session_id, topic_id),
        ):
            cursor = col.find(
                {
                    "org_id": org_id,
                    "session_id": session_id,
                    "topic_id": topic_id,
                    "deleted": {"$ne": True},
                }
            ).sort("timestamp", 1)

            results = []
            for doc in cursor:
                doc["_id"] = str(doc["_id"])
                results.append(SnapshotOut.model_validate(doc))
            return results

    def list_by_session(
        self,
        org_id: str,
        session_id: str,
        *,
        limit: int = 100,
    ) -> List[SnapshotOut]:
        """List all snapshots for a session, sorted by timestamp."""
        from mongomem_core.memory.snapshot import list_snapshots

        return list_snapshots(
            db=self._db,
            org_id=org_id,
            session_id=session_id,
            limit=limit,
            sort_descending=False,  # Oldest first for chronological order
        )


__all__ = [
    "SnapshotSearchBackend",
    "MongoSnapshotBackend",
]
