"""Base engine class with core initialization and STM operations.

Internal implementation - use MemoryEngine from mongomem_core.
"""

from __future__ import annotations

import logging
import warnings
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

from mongomem_core.config import ISGenerationConfig, Settings
from mongomem_core.exceptions import (
    DatabaseOperationError,
    MongoMemError,
    ValidationError,
)
from mongomem_core.memory.short_term import create_stm
from mongomem_core.models.engine import WriteTurnResult
from mongomem_core.models.memory.base import ChunkVisibility, MessageRole
from mongomem_core.models.memory.short_term import ShortTermDB, ShortTermIn, ToolCall
from mongomem_core.modes import MemoryMode, require_mode
from mongomem_core.observability import CoreObservability, NoOpObservability
from mongomem_core.storage import (
    ensure_engine_collections,
    ensure_engine_indexes,
    ensure_engine_search_indexes,
    get_database,
)
from pydantic import ValidationError as PydanticValidationError

if TYPE_CHECKING:
    from mongomem_core.protocols import (
        EmbedderProtocol,
        ExecutorProtocol,
        LLMProtocol,
        ObservabilityProtocol,
    )

# Type alias for mode resolver callable
ModeResolver = Callable[[str, Optional[str]], MemoryMode]

logger = logging.getLogger(__name__)


class _EngineBase:
    """
    Core initialization and STM operations.

    Handles database connection, bootstrap, write_turn, and mode management.
    """

    def __init__(
        self,
        settings: Settings | None = None,
        *,
        embedder: Optional["EmbedderProtocol"] = None,
        llm: Optional["LLMProtocol"] = None,
        executor: Optional["ExecutorProtocol"] = None,
        is_llm: Optional["LLMProtocol"] = None,
        is_config: Optional[ISGenerationConfig] = None,
        db: Optional[Any] = None,
        mode: MemoryMode = MemoryMode.TRADITIONAL,
        mode_resolver: Optional[ModeResolver] = None,
        observability: Optional["ObservabilityProtocol"] = None,
    ) -> None:
        """
        Initialize MemoryEngine.

        Args:
            settings: Configuration settings. Defaults to Settings() from env vars.
            embedder: Optional embedder for sync embedding. Implements EmbedderProtocol.
            llm: Optional LLM for extraction. Implements LLMProtocol.
            is_llm: Optional separate LLM for IS generation. Falls back to llm if not set.
                Use a cheaper model for IS (e.g., gpt-3.5) while keeping expensive model for main tasks.
            is_config: Configuration for automatic IS generation via generate_is_from_turn().
                Controls update policy, coalescing, token limits, etc.
            db: Optional MongoDB Database instance. If not provided, created from settings.
                Useful for testing or custom connection management.
            mode: Memory operating mode (FIXED per engine instance).
                - TRADITIONAL: STM accumulation + LTM retrieval
                - IWM: Internal Working Memory (constant prompt size)
                - HYBRID: Both for migration/debugging
            mode_resolver: DEPRECATED. Accepted but ignored.
                Per-org/session mode resolution requires proper precedence
                rules, storage schema, and audit logging.
            observability: Optional observability provider for metrics/tracing.
                Implements ObservabilityProtocol. Defaults to NoOpObservability.
        """
        self.settings = settings or Settings()
        self._embedder = embedder
        self._llm = llm
        self._executor = executor
        self._is_llm = is_llm
        self._is_config = is_config
        self._mode = mode
        self._mode_resolver = mode_resolver

        # Deprecation warning for mode_resolver
        if mode_resolver is not None:
            warnings.warn(
                "mode_resolver is deprecated and will be ignored. "
                "Mode is fixed per engine instance.",
                DeprecationWarning,
                stacklevel=2,
            )

        # Initialize observability
        self._observability = observability or NoOpObservability()
        self._obs = CoreObservability(backend=self._observability)

        # Validate embedding dimension if embedder provided
        if embedder is not None:
            embedder_dim = embedder.dimension
            settings_dim = self.settings.embedding_dimension
            if embedder_dim != settings_dim:
                raise ValueError(
                    f"Embedding dimension mismatch: embedder.dimension={embedder_dim} "
                    f"but settings.embedding_dimension={settings_dim}. "
                    f"Either update Settings(embedding_dimension={embedder_dim}) "
                    f"or use an embedder with dimension={settings_dim}."
                )

        # Allow db injection for testing/custom connection management
        self._db = db if db is not None else get_database(self.settings)

        logger.debug(
            "MemoryEngine initialized: mode=%s, embedder=%s, llm=%s, is_llm=%s, observability=%s",
            mode.value,
            embedder is not None,
            llm is not None,
            is_llm is not None,
            type(self._observability).__name__,
        )

    @property
    def executor(self) -> Optional["ExecutorProtocol"]:
        return self._executor

    @property
    def embedder(self) -> Optional["EmbedderProtocol"]:
        return self._embedder

    @property
    def llm(self) -> Optional["LLMProtocol"]:
        return self._llm

    @property
    def is_llm(self) -> Optional["LLMProtocol"]:
        """LLM used for IS generation. Falls back to llm if not set."""
        return self._is_llm or self._llm

    @property
    def is_config(self) -> Optional[ISGenerationConfig]:
        """Configuration for automatic IS generation."""
        return self._is_config

    @property
    def db(self):
        return self._db

    @property
    def observability(self) -> "ObservabilityProtocol":
        """The engine's observability provider."""
        return self._observability

    @property
    def mode(self) -> MemoryMode:
        """The engine's default memory operating mode."""
        return self._mode

    def resolve_mode(
        self,
        *,
        org_id: str,
        session_id: Optional[str] = None,
    ) -> MemoryMode:
        """
        Resolve the effective mode for an org/session.

        Mode is FIXED per engine instance. This method always returns
        self._mode. The org_id/session_id parameters are accepted for
        API compatibility but are not used.

        This ensures:
        - No ambiguity about what mode is active
        - No hidden feature flag lookups
        - Auditable, deterministic behavior

        Args:
            org_id: Organization ID (accepted for API compatibility)
            session_id: Optional session ID (accepted for API compatibility)

        Returns:
            MemoryMode: Always returns self._mode (engine's fixed mode)
        """
        # Mode is fixed per engine instance. No dynamic resolution.
        return self._mode

    @classmethod
    def from_env(
        cls,
        *,
        embedder: Optional["EmbedderProtocol"] = None,
        llm: Optional["LLMProtocol"] = None,
        executor: Optional["ExecutorProtocol"] = None,
        mode: MemoryMode = MemoryMode.TRADITIONAL,
    ) -> "_EngineBase":
        return cls(Settings(), embedder=embedder, llm=llm, executor=executor, mode=mode)

    @classmethod
    def from_config(
        cls,
        settings: Settings,
        *,
        embedder: Optional["EmbedderProtocol"] = None,
        llm: Optional["LLMProtocol"] = None,
        executor: Optional["ExecutorProtocol"] = None,
        mode: MemoryMode = MemoryMode.TRADITIONAL,
    ) -> "_EngineBase":
        return cls(settings, embedder=embedder, llm=llm, executor=executor, mode=mode)

    def bootstrap(
        self,
        *,
        ensure_search_indexes: bool = True,
        wait_for_indexes_ready: bool = False,
    ) -> None:
        """
        Bootstrap the database: ensure collections and indexes exist.

        This is a convenience method that calls the storage bootstrap helpers.
        It's safe to call multiple times (idempotent).

        The bootstrap process is optimized for performance:
        - B-tree indexes are created in batches per collection
        - Existing indexes are checked in batch before creation
        - Search indexes are created first, then waited for in parallel (if requested)
        - This significantly reduces bootstrap time compared to sequential creation

        When to set `wait_for_indexes_ready=True`:
        - If you need to perform synchronous vector search immediately after bootstrap
        - In single-process deployments where worker and engine run together
        - For testing scenarios that require indexes to be ready immediately

        Args:
            ensure_search_indexes: If True, also ensure Atlas Search/vector indexes.
                Set to False if you want to manage search indexes separately or
                they're not available in your MongoDB deployment.
            wait_for_indexes_ready: If True, wait for newly created search indexes
                to be ready before returning. This ensures indexes are queryable
                immediately after bootstrap. Set to False for faster bootstrap
                (indexes will be created but may not be immediately queryable).
                Defaults to False for faster bootstrap and async worker architecture.

        Raises:
            DatabaseOperationError: If bootstrap operations fail.
            TimeoutError: If wait_for_indexes_ready is True and indexes don't
                become ready within the timeout period.

        Example:
            >>> engine = MemoryEngine.from_env()
            >>> engine.bootstrap()  # Fast bootstrap, indexes created but not waited for
            >>> # For immediate vector search availability:
            >>> engine.bootstrap(wait_for_indexes_ready=True)
        """
        logger.info(
            "Bootstrapping database (ensure_search_indexes=%s, wait_for_indexes_ready=%s)",
            ensure_search_indexes,
            wait_for_indexes_ready,
        )
        try:
            ensure_engine_collections(self._db)
            logger.debug("Engine collections ensured")

            ensure_engine_indexes(self._db)
            logger.debug("Engine indexes ensured")

            if ensure_search_indexes:
                ensure_engine_search_indexes(
                    self._db,
                    settings=self.settings,
                    wait_for_ready=wait_for_indexes_ready,
                )
                logger.debug("Engine search indexes ensured")

            logger.info("Database bootstrap completed successfully")
        except MongoMemError:
            raise
        except Exception as exc:
            logger.exception("Database bootstrap failed")
            raise DatabaseOperationError(
                "Failed to bootstrap database",
                operation="bootstrap",
                original_error=exc,
            ) from exc

    def write_turn(
        self,
        *,
        session_id: str,
        role: str,
        org_id: str,
        user_id: str,
        content: str | None = None,
        tokens: int | None = None,
        stop_reason: str | None = None,
        model_name: str | None = None,
        tool_calls: List[Dict[str, Any]] | None = None,
        tool_call_id: str | None = None,
        tool_name: str | None = None,
        is_error: bool = False,
        agent_id: str | None = None,
        share_learning_with_team: bool = True,
        visibility: str = "private",
        project_id: str | None = None,
        metadata: dict | None = None,
        embedding: list[float] | None = None,
        embedding_model_id: str | None = None,
        content_embedding_model_id: str | None = None,
        idempotency_key: str | None = None,
    ) -> WriteTurnResult:
        """
        Write a conversation turn to short-term memory.

        This stores individual messages in a conversation session. Turns are
        later consolidated into snapshots during memory maintenance.

        MODE-GATED: Only available in TRADITIONAL and HYBRID modes.
        In IWM mode, use update_internal_state() instead.

        Args:
            session_id: Conversation session/thread identifier
            role: Message role ("user", "assistant", "system", "tool")
            org_id: Organization ID for multi-tenancy
            user_id: User ID of the message author
            content: Message content (required for user/system/tool roles)
            tokens: Token count for this message
            stop_reason: LLM stop reason if applicable
            model_name: Model used to generate this message
            tool_calls: Tool calls for assistant messages. Each dict should have
                "name" (str), "arguments" (dict or JSON str), and optionally "id" (str)
            tool_call_id: Tool call ID this result corresponds to (for tool role)
            tool_name: Name of the tool that produced this result
            is_error: Whether this tool result represents an error
            agent_id: ID of the agent if applicable
            share_learning_with_team: Whether to share learnings with agent's team
            visibility: Visibility scope ("private", "shared", "org")
            project_id: Project ID (required when visibility="shared")
            metadata: Arbitrary key-value metadata
            embedding: Pre-computed embedding vector
            embedding_model_id: Model used to generate the embedding
            content_embedding_model_id: Model for full content embedding
            idempotency_key: Optional key for idempotency checks

        Returns:
            WriteTurnResult with the created document's ID and sequence number

        Raises:
            ModeError: If engine is in IWM mode (use update_internal_state instead).
            ValidationError: If the input parameters fail validation.
            DuplicateDocumentError: If idempotency check fails.
            DatabaseOperationError: If the database operation fails.

        Example:
            >>> engine = MemoryEngine.from_env()
            >>> result = engine.write_turn(
            ...     session_id="sess_123",
            ...     role="user",
            ...     content="Hello!",
            ...     org_id="org_1",
            ...     user_id="user_1",
            ... )

            # With tool calls:
            >>> result = engine.write_turn(
            ...     session_id="sess_123",
            ...     role="assistant",
            ...     tool_calls=[{"name": "get_weather", "arguments": {"city": "NYC"}, "id": "call_1"}],
            ...     org_id="org_1",
            ...     user_id="agent_1",
            ... )
        """
        # Mode gate: only TRADITIONAL and HYBRID modes can write turns
        require_mode(
            self._mode,
            [MemoryMode.TRADITIONAL, MemoryMode.HYBRID],
            "write_turn",
        )

        logger.debug(
            "Writing turn: session=%s role=%s org=%s user=%s",
            session_id,
            role,
            org_id,
            user_id,
        )

        with self._obs.track_write_turn():
            try:
                # Convert tool_calls dicts to ToolCall models if provided
                tool_call_models: Optional[List[ToolCall]] = None
                if tool_calls:
                    tool_call_models = [
                        ToolCall(
                            id=tc.get("id", ""),
                            name=tc["name"],
                            arguments=tc["arguments"],
                        )
                        for tc in tool_calls
                    ]

                turn_in = ShortTermIn(
                    session_id=session_id,
                    role=MessageRole(role),
                    content=content,
                    tokens=tokens,
                    stop_reason=stop_reason,
                    model_name=model_name,
                    tool_calls=tool_call_models,
                    tool_call_id=tool_call_id,
                    tool_name=tool_name,
                    is_error=is_error,
                    agent_id=agent_id,
                    share_learning_with_team=share_learning_with_team,
                    visibility=ChunkVisibility(visibility)
                    if visibility
                    else ChunkVisibility.PRIVATE,
                    project_id=project_id,
                    metadata=metadata,
                    content_embedding_model_id=content_embedding_model_id,
                )

                stm_doc: ShortTermDB = create_stm(
                    db=self._db,
                    turn_in=turn_in,
                    org_id=org_id,
                    user_id=user_id,
                    idempotency_key=idempotency_key,
                    embedding=embedding,
                    embedding_model_id=embedding_model_id,
                )

                logger.info(
                    "Turn written successfully: id=%s session=%s turn_seq=%d",
                    stm_doc.id,
                    stm_doc.session_id,
                    stm_doc.turn_seq,
                )

                return WriteTurnResult(
                    id=str(stm_doc.id),
                    session_id=stm_doc.session_id,
                    turn_seq=stm_doc.turn_seq,
                    acknowledged=True,
                )
            except PydanticValidationError as exc:
                logger.warning(
                    "Validation failed for write_turn: session=%s role=%s errors=%s",
                    session_id,
                    role,
                    exc.errors(),
                )
                raise ValidationError(
                    f"Invalid turn data: {exc}",
                    details={
                        "session_id": session_id,
                        "role": role,
                        "validation_errors": exc.errors(),
                    },
                ) from exc
