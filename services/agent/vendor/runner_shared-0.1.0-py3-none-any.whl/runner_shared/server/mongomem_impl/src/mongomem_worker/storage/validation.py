"""
Validation helpers for ``mongomem_worker`` storage.

These functions are the worker-side counterpart to
``mongomem_core.storage.validation`` and are intended to be used in CI or
diagnostic tooling rather than at hot-path startup.
"""

from __future__ import annotations

import logging
from typing import Iterable

from pymongo.synchronous.database import Database

from .collections import WORKER_COLLECTIONS
from .indexes import WORKER_INDEXES, CollectionIndexes

logger = logging.getLogger(__name__)


def validate_worker_storage(db: Database, *, strict: bool = True) -> None:
    """
    Validate that worker-domain collections and indexes are present in ``db``.

    Current behaviour:

    * Confirms that each collection in ``WORKER_COLLECTIONS`` exists.
    * Checks that every index name in ``WORKER_INDEXES`` is present on the
      corresponding collection.

    In ``strict`` mode, missing collections or indexes raise ``RuntimeError``.
    In non-strict mode they are logged at WARNING level only.
    """

    existing_collections = set(db.list_collection_names())

    def _fail(msg: str) -> None:
        if strict:
            raise RuntimeError(msg)
        logger.warning(msg)

    # Collections
    for name in WORKER_COLLECTIONS:
        if name not in existing_collections:
            _fail(f"Worker collection missing in database: {name}")

    # Indexes
    for ci in _iter_worker_index_groups():
        col = db[ci.collection_name]
        existing_indexes = set(col.index_information().keys())
        for index in ci.indexes:
            if index.name not in existing_indexes:
                _fail(f"Missing worker index {index.name} on collection {ci.collection_name}")


def _iter_worker_index_groups() -> Iterable[CollectionIndexes]:
    """Small indirection for tests."""

    return WORKER_INDEXES.values()


__all__ = ["validate_worker_storage"]
