"""
Semantic memory extractor.

Extracts user-related factual knowledge from conversation messages
using LLM-based extraction with configurable prompts.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

if TYPE_CHECKING:
    from mongomem_core.protocols import LLMProtocol

from mongomem_core.extraction.base import BaseExtractor
from mongomem_core.extraction.semantic.prompts import (
    EXTRACTION_PROMPT_TEMPLATE,
    EXTRACTION_SCHEMA,
    EXTRACTION_SYSTEM_PROMPT,
)
from mongomem_core.extraction.types import ExtractedItem

logger = logging.getLogger(__name__)


class SemanticExtractor(BaseExtractor):
    """
    Extract semantic memories from conversation messages.

    Uses LLM to identify user-related facts, preferences, skills, and other
    knowledge that has value beyond the current conversation.

    Supports hot-reload of prompts via optional prompt_resolver callable.
    """

    extraction_type = "semantic"

    def __init__(
        self,
        llm: "LLMProtocol",
        prompt_resolver: Optional[Callable[[], Optional[str]]] = None,
    ) -> None:
        """
        Initialize semantic extractor.

        Args:
            llm: LLM protocol implementation for extraction
            prompt_resolver: Optional callable that returns a custom extraction prompt.
                            If provided and returns non-None, uses that prompt
                            instead of the default. Enables hot-reload.
        """
        super().__init__(llm, prompt_resolver)

    def extract(self, messages: List[Dict[str, Any]]) -> List[ExtractedItem]:
        """
        Extract semantic memories from conversation messages.

        Args:
            messages: List of conversation messages with 'role' and 'content' keys

        Returns:
            List of extracted items with content, citations, and confidence scores
        """
        if not messages:
            logger.debug("No messages to extract from")
            return []

        # Get prompt (supports hot-reload)
        system_prompt = self._get_prompt(EXTRACTION_SYSTEM_PROMPT)

        # Format conversation for prompt
        formatted_conversation = self._format_messages(messages)
        user_prompt = EXTRACTION_PROMPT_TEMPLATE.format(conversation_history=formatted_conversation)

        # Call LLM
        try:
            result = self._llm.complete_json(
                prompt=f"{system_prompt}\n\n{user_prompt}",
                schema=EXTRACTION_SCHEMA,
            )
        except Exception as e:
            logger.error("LLM extraction failed: %s", e)
            return []

        # Parse response
        memories = result.get("memories", [])
        if not memories:
            logger.debug("No memories extracted from conversation")
            return []

        # Convert to ExtractedItem
        extracted = []
        for mem in memories:
            content = mem.get("content", "").strip()
            if not content:
                continue

            extracted.append(
                ExtractedItem(
                    content=content,
                    citations=mem.get("citations", []),
                    confidence=mem.get("confidence_score", 0.5),
                    metadata={
                        "extraction_type": "semantic",
                    },
                )
            )

        logger.debug(
            "Extracted %d semantic memories from %d messages", len(extracted), len(messages)
        )
        return extracted


__all__ = ["SemanticExtractor"]
