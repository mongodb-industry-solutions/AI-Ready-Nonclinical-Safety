"""Semantic memory operations for MemoryEngine.

Internal implementation - use MemoryEngine from mongomem_core.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Dict, List

from mongomem_core.exceptions import ValidationError
from mongomem_core.memory.semantic import (
    bulk_create_semantic,
    create_semantic,
    delete_semantic,
    get_semantic,
    list_semantic,
    soft_delete_semantic,
    update_semantic,
    upsert_semantic,
)
from mongomem_core.models.engine import BulkCreateSemanticResult, CreateSemanticResult, DeleteResult
from mongomem_core.models.filters import MetadataFilter
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.semantic import SemanticIn, SemanticOut, SemanticUpdate
from mongomem_core.models.retrieval import MemoryChunk
from mongomem_core.retrieval import fetch_semantic_memories
from pydantic import ValidationError as PydanticValidationError

if TYPE_CHECKING:
    from mongomem_core.engine._protocol import EngineProtocol

logger = logging.getLogger(__name__)


class _Semantic:
    """Semantic memory CRUD and retrieval operations."""

    def fetch_semantic_memories(
        self: "EngineProtocol",
        query: str | List[float],
        org_id: str,
        *,
        user_id: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        top_k: int = 50,
        similarity_threshold: float = 0.0,
        dedup_threshold: float = 0.5,
        prefetched: List[SemanticOut] | None = None,
        deduplicate: bool = True,
        rank: bool = True,
        metadata_filter: MetadataFilter | None = None,
    ) -> List[MemoryChunk]:
        """
        Fetch, deduplicate, and rank semantic memories.

        Args:
            query: Query text or pre-computed embedding vector
            org_id: Organization ID for multi-tenancy
            user_id: Optional user ID filter
            visibility: Optional visibility scope filter
            project_id: Optional group ID filter
            top_k: Maximum number of results from vector search
            similarity_threshold: Minimum similarity score
            dedup_threshold: Threshold for similarity-based deduplication
            prefetched: Optional pre-fetched semantic memories
            deduplicate: Whether to deduplicate results
            rank: Whether to rank results
            metadata_filter: Optional metadata filter for Atlas Vector Search pre-filtering

        Returns:
            List of MemoryChunk objects
        """
        vis = ChunkVisibility(visibility) if visibility else None

        return fetch_semantic_memories(
            db=self._db,
            org_id=org_id,
            query=query,
            embedder=self._embedder,
            user_id=user_id,
            visibility=vis,
            project_id=project_id,
            top_k=top_k,
            similarity_threshold=similarity_threshold,
            dedup_threshold=dedup_threshold,
            prefetched=prefetched,
            deduplicate=deduplicate,
            rank=rank,
            metadata_filter=metadata_filter,
        )

    def create_semantic(
        self: "EngineProtocol",
        *,
        label: str,
        text: str,
        org_id: str,
        user_id: str,
        source: str | None = None,
        visibility: str = "private",
        project_id: str | None = None,
        contextual_metadata: Dict[str, Any] | None = None,
        agent_id: str | None = None,
        extraction_source: str | None = None,
        embedding: list[float] | None = None,
        skip_embedding: bool = False,
        upsert: bool = False,
    ) -> CreateSemanticResult:
        """
        Create a semantic memory (fact/knowledge chunk).

        Args:
            label: Unique identifier/label for this knowledge chunk
            text: The actual content to store and embed
            org_id: Organization ID for multi-tenancy
            user_id: User ID who owns this memory
            source: Optional source reference
            visibility: Visibility scope
            project_id: Project ID (required when visibility="shared")
            contextual_metadata: Additional context
            agent_id: Agent ID if created via agent
            extraction_source: Source type
            embedding: Pre-computed embedding
            skip_embedding: If True, don't embed even if embedder available
            upsert: If True, update existing memory with the same label

        Returns:
            CreateSemanticResult with the created document's ID
        """
        logger.debug(
            "Creating semantic memory: label=%s org=%s user=%s skip_embedding=%s",
            label,
            org_id,
            user_id,
            skip_embedding,
        )

        final_embedding = embedding
        embedding_model_id = None
        if not skip_embedding and embedding is None and self._embedder is not None:
            logger.debug("Generating embedding for semantic memory: label=%s", label)
            final_embedding = self._embedder.embed(text)
            embedding_model_id = self._embedder.model_id

        try:
            semantic_in = SemanticIn(
                label=label,
                content=text,
                source=source,
                visibility=ChunkVisibility(visibility) if visibility else ChunkVisibility.PRIVATE,
                project_id=project_id,
                contextual_metadata=contextual_metadata,
                agent_id=agent_id,
                extraction_source=extraction_source,
            )
        except PydanticValidationError as exc:
            logger.warning(
                "Validation failed for create_semantic: label=%s errors=%s",
                label,
                exc.errors(),
            )
            raise ValidationError(
                f"Invalid semantic data: {exc}",
                details={"label": label, "validation_errors": exc.errors()},
            ) from exc

        write_semantic = upsert_semantic if upsert else create_semantic
        semantic_doc = write_semantic(
            db=self._db,
            semantic_in=semantic_in,
            org_id=org_id,
            user_id=user_id,
            embedding=final_embedding,
            embedding_model_id=embedding_model_id,
        )

        logger.info(
            "Semantic memory created: id=%s label=%s has_embedding=%s",
            semantic_doc.id,
            semantic_doc.label,
            semantic_doc.has_embedding,
        )

        return CreateSemanticResult(
            id=str(semantic_doc.id),
            label=semantic_doc.label,
            has_embedding=semantic_doc.has_embedding,
            acknowledged=True,
        )

    def bulk_create_semantic(
        self: "EngineProtocol",
        items: List[Dict[str, Any]],
        org_id: str,
        user_id: str,
        *,
        visibility: str = "private",
        project_id: str | None = None,
        generate_embeddings: bool = True,
        skip_duplicates: bool = True,
    ) -> BulkCreateSemanticResult:
        """
        Bulk create multiple semantic memories efficiently.

        Uses MongoDB's insert_many for single round-trip insertion.
        Optionally generates embeddings for all items in a batch.

        Args:
            items: List of dicts with keys: label, text, source (optional),
                   contextual_metadata (optional)
            org_id: Organization ID for multi-tenancy
            user_id: User ID who owns these memories
            visibility: Visibility scope for all items (default: "private")
            project_id: Project ID (required when visibility="shared")
            generate_embeddings: If True, generate embeddings for all items
            skip_duplicates: If True, skip duplicate labels instead of failing

        Returns:
            BulkCreateSemanticResult with counts and IDs

        Example:
            >>> result = engine.bulk_create_semantic(
            ...     items=[
            ...         {"label": "fact-1", "text": "Python is great"},
            ...         {"label": "fact-2", "text": "Rust is fast"},
            ...     ],
            ...     org_id="org_1",
            ...     user_id="user_1",
            ... )
            >>> print(f"Created {result.created_count} memories")
        """
        if not items:
            return BulkCreateSemanticResult(
                created_count=0,
                skipped_count=0,
                created_ids=[],
                skipped_labels=[],
                has_embeddings=False,
                acknowledged=True,
            )

        logger.debug(
            "Bulk creating %d semantic memories for org=%s user=%s",
            len(items),
            org_id,
            user_id,
        )

        # Build SemanticIn models
        semantic_inputs: List[SemanticIn] = []
        for item_data in items:
            try:
                semantic_in = SemanticIn(
                    label=item_data["label"],
                    content=item_data["content"],
                    source=item_data.get("source"),
                    visibility=ChunkVisibility(visibility)
                    if visibility
                    else ChunkVisibility.PRIVATE,
                    project_id=project_id if visibility == "shared" else None,
                    contextual_metadata=item_data.get("contextual_metadata"),
                    agent_id=item_data.get("agent_id"),
                    extraction_source=item_data.get("extraction_source"),
                )
                semantic_inputs.append(semantic_in)
            except (KeyError, PydanticValidationError) as exc:
                logger.warning(
                    "Skipping invalid item in bulk create: label=%s error=%s",
                    item_data.get("label", "unknown"),
                    exc,
                )
                continue

        if not semantic_inputs:
            return BulkCreateSemanticResult(
                created_count=0,
                skipped_count=0,
                created_ids=[],
                skipped_labels=[],
                has_embeddings=False,
                acknowledged=True,
            )

        # Generate embeddings if requested
        embeddings: List[List[float]] | None = None
        embedding_model_id: str | None = None

        if generate_embeddings and self._embedder is not None:
            texts = [s.content for s in semantic_inputs]
            try:
                logger.debug("Generating embeddings for %d items", len(texts))
                embeddings = self._embedder.embed_batch(texts)
                embedding_model_id = self._embedder.model_id
            except Exception as exc:
                logger.warning("Failed to generate embeddings for bulk create: %s", exc)

        # Bulk create
        created_docs, skipped_labels = bulk_create_semantic(
            db=self._db,
            items=semantic_inputs,
            org_id=org_id,
            user_id=user_id,
            embeddings=embeddings,
            embedding_model_id=embedding_model_id,
            skip_duplicates=skip_duplicates,
        )

        has_embeddings = bool(embeddings) and len(created_docs) > 0

        logger.info(
            "Bulk created %d/%d semantic memories for org=%s (skipped=%d)",
            len(created_docs),
            len(semantic_inputs),
            org_id,
            len(skipped_labels),
        )

        return BulkCreateSemanticResult(
            created_count=len(created_docs),
            skipped_count=len(skipped_labels),
            created_ids=[str(doc.id) for doc in created_docs],
            skipped_labels=skipped_labels,
            has_embeddings=has_embeddings,
            acknowledged=True,
        )

    def get_semantic(
        self: "EngineProtocol",
        org_id: str,
        *,
        id: str | None = None,
        label: str | None = None,
        project_id: str | None = None,
        user_id: str | None = None,
        visibility: str | None = None,
        include_deleted: bool = False,
    ) -> SemanticOut | None:
        """
        Retrieve a semantic memory by ID or label.

        Args:
            org_id: Organization ID
            id: Document ID (mutually exclusive with label)
            label: Label (mutually exclusive with id)
            project_id: Filter by project ID
            user_id: Optional user ID filter
            visibility: Optional visibility filter
            include_deleted: Include soft-deleted documents

        Returns:
            SemanticOut if found, None otherwise
        """
        return get_semantic(
            db=self._db,
            org_id=org_id,
            id=id,
            label=label,
            project_id=project_id,
            user_id=user_id,
            visibility=visibility,
            include_deleted=include_deleted,
        )

    def list_semantic(
        self: "EngineProtocol",
        org_id: str,
        *,
        user_id: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        limit: int = 100,
        include_deleted: bool = False,
    ) -> List[SemanticOut]:
        """
        List semantic memories with optional filters.

        Args:
            org_id: Organization ID
            user_id: Filter by user ID
            visibility: Filter by visibility
            project_id: Filter by group ID
            limit: Maximum number of results
            include_deleted: Include soft-deleted documents

        Returns:
            List of SemanticOut documents
        """
        return list_semantic(
            db=self._db,
            org_id=org_id,
            user_id=user_id,
            visibility=ChunkVisibility(visibility) if visibility else None,
            project_id=project_id,
            limit=limit,
            include_deleted=include_deleted,
        )

    def update_semantic(
        self: "EngineProtocol",
        org_id: str,
        *,
        id: str | None = None,
        label: str | None = None,
        text: str | None = None,
        source: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        contextual_metadata: Dict[str, Any] | None = None,
    ) -> SemanticOut | None:
        """
        Update a semantic memory.

        Args:
            org_id: Organization ID
            id: Document ID (mutually exclusive with label)
            label: Label (mutually exclusive with id)
            text: New text content
            source: New source reference
            visibility: New visibility
            project_id: New group ID
            contextual_metadata: New metadata

        Returns:
            Updated SemanticOut if found, None otherwise
        """
        embedding = None
        embedding_model_id = None
        if text is not None and self._embedder is not None:
            logger.debug(
                "Generating embedding for semantic memory update: label=%s id=%s",
                label,
                id,
            )
            embedding = self._embedder.embed(text)
            embedding_model_id = self._embedder.model_id

        update = SemanticUpdate(
            content=text,
            source=source,
            visibility=ChunkVisibility(visibility) if visibility else None,
            project_id=project_id,
            contextual_metadata=contextual_metadata,
            embedding=embedding,
            embedding_model_id=embedding_model_id,
        )

        return update_semantic(
            db=self._db,
            org_id=org_id,
            update=update,
            id=id,
            label=label,
        )

    def delete_semantic(
        self: "EngineProtocol",
        org_id: str,
        *,
        id: str | None = None,
        label: str | None = None,
        soft: bool = True,
    ) -> DeleteResult:
        """
        Delete a semantic memory.

        Args:
            org_id: Organization ID
            id: Document ID (mutually exclusive with label)
            label: Label (mutually exclusive with id)
            soft: If True (default), soft delete. If False, hard delete.

        Returns:
            DeleteResult with deleted_count
        """
        if soft:
            update_result = soft_delete_semantic(db=self._db, org_id=org_id, id=id, label=label)
            deleted_count = update_result.modified_count
        else:
            delete_result = delete_semantic(db=self._db, org_id=org_id, id=id, label=label)
            deleted_count = delete_result.deleted_count

        logger.info(
            "Deleted semantic memory: org=%s id=%s label=%s soft=%s count=%d",
            org_id,
            id,
            label,
            soft,
            deleted_count,
        )
        return DeleteResult(deleted_count=deleted_count, acknowledged=True)
