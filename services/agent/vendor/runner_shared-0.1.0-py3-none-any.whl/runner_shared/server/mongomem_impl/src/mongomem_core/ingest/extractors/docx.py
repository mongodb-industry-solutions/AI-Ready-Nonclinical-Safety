"""
Word document text extractor using python-docx.

Handles .docx files with text extraction from all paragraphs.
Note: Does NOT support legacy .doc files - use Docling for those.
"""

import logging
from pathlib import Path
from typing import Any, Dict, Set

logger = logging.getLogger(__name__)


class PythonDocxExtractor:
    """Word document text extractor using python-docx."""

    @property
    def supported_extensions(self) -> Set[str]:
        return {".docx"}

    def extract(self, file_path: Path) -> str:
        """Extract text from all paragraphs of a Word document."""
        from docx import Document

        doc = Document(str(file_path))  # type: ignore[arg-type]
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]

        return "\n\n".join(paragraphs)

    def extract_with_metadata(self, file_path: Path) -> Dict[str, Any]:
        """Extract text and metadata from a Word document."""
        from docx import Document

        doc = Document(str(file_path))  # type: ignore[arg-type]
        text = self.extract(file_path)

        # Get core properties if available
        props = doc.core_properties

        return {
            "text": text,
            "metadata": {
                "source_type": "docx",
                "paragraph_count": len(doc.paragraphs),
                "title": props.title or None,
                "author": props.author or None,
                "subject": props.subject or None,
            },
        }
