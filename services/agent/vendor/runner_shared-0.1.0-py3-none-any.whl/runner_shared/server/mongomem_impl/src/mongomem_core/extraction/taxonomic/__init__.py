"""
Taxonomic extraction pipeline.

Provides TaxonomicPipeline class and factory function for creating
complete taxonomic extraction pipelines.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

if TYPE_CHECKING:
    from mongomem_core.protocols import EmbedderProtocol, LLMProtocol
    from pymongo.database import Database

from mongomem_core.extraction.config import TaxonomicExtractionConfig
from mongomem_core.extraction.consolidator import (
    ConsolidationStrategy,
    Consolidator,
    LLMBasedStrategy,
    RuleBasedStrategy,
)
from mongomem_core.extraction.enrichment import enrich_citations
from mongomem_core.extraction.taxonomic.extractor import TaxonomicExtractor
from mongomem_core.extraction.taxonomic.persistence import apply_taxonomic_decisions
from mongomem_core.extraction.types import (
    ApprovalMode,
    ConsolidationStats,
    ExtractedItem,
    ExtractionMetadata,
    ExtractionResult,
    ScoredExtraction,
)
from mongomem_core.memory.taxonomic import search_taxonomic
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.observability import CoreObservability

logger = logging.getLogger(__name__)

# Type alias for semantic clarity - taxonomic terms are ExtractedItems
ExtractedTerm = ExtractedItem


@dataclass
class TaxonomicExtractionResult:
    """Result of taxonomic extraction pipeline."""

    success: bool = True
    source_reference: str = ""

    # Extraction stats
    terms_extracted: int = 0
    terms_added: int = 0
    terms_reinforced: int = 0
    terms_skipped: int = 0

    # Timing
    duration_ms: float = 0.0

    # Errors
    errors: List[str] = field(default_factory=list)


def score_taxonomic_extraction(
    extraction: ExtractedItem,
    config: TaxonomicExtractionConfig,
) -> ScoredExtraction:
    """
    Score a taxonomic extraction with evidence span validation.

    Args:
        extraction: Extracted item to score
        config: Taxonomic extraction configuration

    Returns:
        ScoredExtraction with combined score and validity flag
    """
    metadata = extraction.metadata or {}
    evidence_spans = metadata.get("evidence_spans", [])

    # Calculate evidence score based on presence and count of evidence spans
    evidence_score = 0.0
    if evidence_spans:
        # More evidence spans = higher score, capped at 1.0
        evidence_score = min(len(evidence_spans) / 3.0, 1.0)

    # Calculate citation score (evidence spans serve as citations for taxonomic)
    citation_score = evidence_score

    # Calculate combined score
    combined_score = (
        evidence_score * config.evidence_weight + extraction.confidence * config.confidence_weight
    )

    # Check validity
    is_valid = combined_score >= config.min_combined_score_threshold
    if config.evidence_span_required and len(evidence_spans) < config.min_evidence_spans:
        is_valid = False

    return ScoredExtraction(
        content=extraction.content,
        citations=extraction.citations,
        confidence=extraction.confidence,
        citation_score=citation_score,
        combined_score=combined_score,
        is_valid=is_valid,
        cited_text=extraction.cited_text,  # Pass through from enrichment
        embedding=None,  # Will be set during pipeline
        metadata=metadata,
    )


def score_taxonomic_batch(
    extractions: List[ExtractedItem],
    config: TaxonomicExtractionConfig,
) -> List[ScoredExtraction]:
    """
    Score a batch of taxonomic extractions.

    Args:
        extractions: List of extracted items
        config: Taxonomic extraction configuration

    Returns:
        List of ScoredExtraction objects
    """
    return [score_taxonomic_extraction(e, config) for e in extractions]


def filter_valid_taxonomic(scored: List[ScoredExtraction]) -> List[ScoredExtraction]:
    """
    Filter to only valid taxonomic extractions.

    Args:
        scored: List of scored extractions

    Returns:
        List of valid extractions
    """
    return [s for s in scored if s.is_valid]


class TaxonomicPipeline:
    """
    Full taxonomic extraction pipeline.

    Orchestrates:
    1. Extract - LLM-based extraction of domain terms
    2. Enrich - Add cited text from source messages
    3. Score - Validate and score with evidence spans
    4. Embed - Generate embeddings for valid extractions
    5. Consolidate - Search and decide (ADD/UPDATE/REINFORCE/SKIP)
    6. Persist - Idempotent database operations (domain+term based)

    Consolidation Actions:
    - ADD: New term not in knowledge base
    - UPDATE: Term exists but definition is semantically different
    - REINFORCE: Same term+definition, bolster with more context (evidence, related terms)
    - SKIP: Exact duplicate or jargon (noop)
    """

    def __init__(
        self,
        extractor: TaxonomicExtractor,
        config: TaxonomicExtractionConfig,
        consolidator: Consolidator,
        db: "Database",
        embedder: "EmbedderProtocol",
        embedding_model_id: str,
        obs: Optional[CoreObservability] = None,
    ) -> None:
        """
        Initialize taxonomic pipeline.

        Args:
            extractor: TaxonomicExtractor instance
            config: Extraction configuration
            consolidator: Consolidator instance
            db: MongoDB database instance
            embedder: Embedder for generating embeddings
            embedding_model_id: ID of embedding model used
            obs: Optional CoreObservability for observability (metrics/spans/events)
        """
        self.extractor = extractor
        self.config = config
        self.consolidator = consolidator
        self._db = db
        self._embedder = embedder
        self._embedding_model_id = embedding_model_id
        self._obs = obs or CoreObservability()

    def run(
        self,
        messages: List[Dict[str, Any]],
        org_id: str,
        user_id: str,
        source_id: str,
        approval_mode: ApprovalMode = "auto",
        visibility: ChunkVisibility = ChunkVisibility.ORG,
        project_id: Optional[str] = None,
    ) -> ExtractionResult:
        """
        Run full taxonomic extraction pipeline.

        Args:
            messages: Conversation messages to extract from
            org_id: Organization ID
            user_id: User ID
            source_id: Source reference (snapshot ID)
            approval_mode: "auto" persists immediately, "manual" stages for review
            visibility: Visibility scope for created memories (default: ORG for taxonomic)
            project_id: Project ID (required if visibility=SHARED)

        Returns:
            ExtractionResult with counts, IDs, and statistics
        """
        with self._obs.span_extraction("taxonomic") as span:
            return self._run_internal(
                messages=messages,
                org_id=org_id,
                user_id=user_id,
                source_id=source_id,
                approval_mode=approval_mode,
                visibility=visibility,
                project_id=project_id,
                span=span,
            )

    def _run_internal(
        self,
        messages: List[Dict[str, Any]],
        org_id: str,
        user_id: str,
        source_id: str,
        approval_mode: ApprovalMode,
        visibility: ChunkVisibility,
        project_id: Optional[str],
        span: Dict[str, Any],
    ) -> ExtractionResult:
        """Internal implementation of run() with span context."""
        result = ExtractionResult(source_reference=source_id, approval_mode=approval_mode)
        start_time = datetime.now(timezone.utc)
        raw: List[ExtractedItem] = []

        try:
            # Check if enabled
            if not self.config.enabled:
                logger.debug("Taxonomic extraction disabled")
                result.success = True
                return result

            # 1. Extract
            raw = self.extractor.extract(messages)
            result.extracted_count = len(raw)
            logger.debug("Extracted %d raw taxonomic terms", len(raw))

            if not raw:
                result.success = True
                return result

            # Limit extractions per snapshot
            if len(raw) > self.config.max_terms_per_snapshot:
                logger.info(
                    "Limiting taxonomic extractions from %d to %d",
                    len(raw),
                    self.config.max_terms_per_snapshot,
                )
                raw = raw[: self.config.max_terms_per_snapshot]

            # 2. Enrich citations (adds cited_text from source messages)
            enrich_citations(raw, messages)

            # 3. Score and filter
            scored = score_taxonomic_batch(raw, self.config)
            valid = filter_valid_taxonomic(scored)
            result.validation_failures = len(scored) - len(valid)
            logger.debug(
                "After scoring: %d/%d passed threshold",
                len(valid),
                len(scored),
            )

            if not valid:
                result.success = True
                return result

            # 4. Generate embeddings for valid extractions
            for scored_item in valid:
                if self._embedder:
                    try:
                        embedding = self._embedder.embed(scored_item.content)
                        scored_item.embedding = embedding
                    except Exception as e:
                        logger.warning(
                            "Failed to generate embedding for taxonomic term: %s",
                            e,
                        )

            # 5. Consolidate (search + decide)
            decisions = self.consolidator.process(valid, org_id, user_id)
            logger.debug("Consolidation returned %d decisions", len(decisions))

            # 6. Persist or Stage
            extraction_timestamp = datetime.now(timezone.utc)

            if approval_mode == "manual":
                from mongomem_core.extraction.approval.store import PendingStore
                from mongomem_core.extraction.approval.types import (
                    ExtractionType,
                    PendingDecisionPayload,
                    PendingPayload,
                )

                store = PendingStore(self._db, obs=self._obs)
                items: list[tuple[ExtractionType, PendingPayload]] = []
                for d in decisions:
                    if d.action == "DUPLICATE":
                        continue
                    payload = PendingDecisionPayload(
                        action=d.action,
                        content=d.extraction.content,
                        citations=d.extraction.citations,
                        confidence=d.extraction.confidence,
                        citation_score=d.extraction.citation_score,
                        combined_score=d.extraction.combined_score,
                        embedding=d.extraction.embedding,
                        embedding_model_id=self._embedding_model_id,
                        cited_text=d.extraction.cited_text,
                        metadata=d.extraction.metadata,
                        existing_id=d.existing_id,
                        reason=d.reason,
                    )
                    items.append(("taxonomic", payload))

                pending_ids = store.stage_batch(
                    items=items,
                    org_id=org_id,
                    user_id=user_id,
                    source_id=source_id,
                    visibility=visibility,
                    project_id=project_id,
                )
                result.pending_ids = pending_ids
                result.consolidation_stats = ConsolidationStats(
                    add_count=sum(1 for d in decisions if d.action == "ADD"),
                    update_count=sum(1 for d in decisions if d.action == "UPDATE"),
                    reinforce_count=sum(1 for d in decisions if d.action == "REINFORCE"),
                    duplicate_count=sum(1 for d in decisions if d.action == "DUPLICATE"),
                )
            else:
                persist_result = apply_taxonomic_decisions(
                    db=self._db,
                    decisions=decisions,
                    org_id=org_id,
                    user_id=user_id,
                    source_id=source_id,
                    extraction_timestamp=extraction_timestamp,
                    embedding_model_id=self._embedding_model_id,
                    config=self.config,
                    visibility=visibility,
                    project_id=project_id,
                )

                # Update result
                result.stored_count = persist_result.added + persist_result.updated
                result.created_ids = persist_result.created_ids
                result.updated_ids = persist_result.updated_new_version_ids
                result.reinforced_ids = persist_result.reinforced_ids
                result.consolidation_stats = ConsolidationStats(
                    add_count=persist_result.added,
                    update_count=persist_result.updated,
                    reinforce_count=persist_result.reinforced,
                    duplicate_count=persist_result.skipped,
                )
                result.errors = persist_result.errors

            # Add sample extractions for observability
            result.sample_extractions = [
                {
                    "domain": e.metadata.get("domain", "") if e.metadata else "",
                    "term": e.metadata.get("term", "") if e.metadata else "",
                    "definition": (e.metadata.get("definition", "") if e.metadata else "")[
                        : self.config.sample_text_truncate_length
                    ],
                    "confidence": e.confidence,
                }
                for e in raw[: self.config.max_sample_extractions]
            ]

            result.success = True

        except Exception as e:
            result.errors.append(str(e))
            logger.error("Taxonomic extraction failed: %s", e, exc_info=True)
            self._obs.extraction_failed("taxonomic", str(e), source_id)

        finally:
            # Calculate processing time and emit metrics (always runs)
            processing_time_ms = int(
                (datetime.now(timezone.utc) - start_time).total_seconds() * 1000
            )
            result.metadata = ExtractionMetadata(
                processing_time_ms=processing_time_ms,
                extraction_timestamp=start_time,
            )

            span["duration_ms"] = processing_time_ms
            span["extracted_count"] = result.extracted_count
            span["success"] = result.success

            # Emit all extraction metrics in one call
            stats = result.consolidation_stats
            self._obs.emit_extraction_result(
                extraction_type="taxonomic",
                extracted_count=result.extracted_count,
                duration_ms=processing_time_ms,
                add_count=stats.add_count if stats else 0,
                update_count=stats.update_count if stats else 0,
                reinforce_count=stats.reinforce_count if stats else 0,
                duplicate_count=stats.duplicate_count if stats else 0,
            )

        return result


def create_taxonomic_pipeline(
    db: "Database",
    llm: "LLMProtocol",
    embedder: "EmbedderProtocol",
    config: Optional[TaxonomicExtractionConfig] = None,
    extraction_prompt_resolver: Optional[Callable[[], Optional[str]]] = None,
    consolidation_prompt_resolver: Optional[Callable[[], Optional[str]]] = None,
    use_llm_consolidation: bool = True,
    obs: Optional[CoreObservability] = None,
) -> TaxonomicPipeline:
    """
    Factory function to create a taxonomic pipeline with hot-swap support.

    Args:
        db: MongoDB database instance
        llm: LLM protocol implementation
        embedder: Embedder protocol implementation
        config: Optional extraction configuration (uses defaults if not provided)
        extraction_prompt_resolver: Optional callable for hot-reload extraction prompts
        consolidation_prompt_resolver: Optional callable for hot-reload consolidation prompts
        use_llm_consolidation: If True, use LLM-based consolidation. Otherwise use rule-based.
        obs: Optional CoreObservability for observability (metrics/spans/events)

    Returns:
        Configured TaxonomicPipeline ready to run
    """
    config = config or TaxonomicExtractionConfig()

    # Create extractor with hot-reload support
    extractor = TaxonomicExtractor(llm, extraction_prompt_resolver)

    # Create consolidation strategy
    strategy: ConsolidationStrategy
    if use_llm_consolidation:
        strategy = LLMBasedStrategy(llm, consolidation_prompt_resolver)
    else:
        strategy = RuleBasedStrategy(
            reinforce_threshold=0.95,
            update_threshold=config.consolidation_similarity_threshold,
        )

    # Create consolidator using taxonomic search function
    consolidator = Consolidator(
        db=db,
        embedder=embedder,
        strategy=strategy,
        search_fn=search_taxonomic,
        config=config,  # type: ignore[arg-type]
    )

    # Defensive check - embedder is required but verify to give clear error
    if embedder is None:
        raise ValueError("embedder is required for TaxonomicPipeline")

    return TaxonomicPipeline(
        extractor=extractor,
        config=config,
        consolidator=consolidator,
        db=db,
        embedder=embedder,
        embedding_model_id=embedder.model_id,
        obs=obs,
    )


__all__ = [
    "ExtractedTerm",
    "TaxonomicPipeline",
    "TaxonomicExtractor",
    "TaxonomicExtractionResult",
    "create_taxonomic_pipeline",
    "score_taxonomic_extraction",
    "score_taxonomic_batch",
    "filter_valid_taxonomic",
]
