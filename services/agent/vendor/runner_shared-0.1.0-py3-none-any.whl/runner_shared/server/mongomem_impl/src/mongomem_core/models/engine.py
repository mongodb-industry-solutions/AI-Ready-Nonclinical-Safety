from __future__ import annotations

from dataclasses import dataclass


@dataclass
class WriteTurnResult:
    """Result of writing a conversation turn."""

    id: str
    session_id: str
    turn_seq: int
    acknowledged: bool = True


@dataclass
class CreateSemanticResult:
    """Result of creating a semantic memory."""

    id: str
    label: str
    has_embedding: bool
    acknowledged: bool = True


@dataclass
class CreateEpisodicResult:
    """Result of creating an episodic memory."""

    id: str
    title: str
    has_embedding: bool
    acknowledged: bool = True


@dataclass
class CreateTaxonomicResult:
    """Result of creating a taxonomic memory."""

    id: str
    domain: str
    term: str
    has_embedding: bool
    acknowledged: bool = True


@dataclass
class CreateUserContextResult:
    """Result of creating a user context memory."""

    id: str
    context_key: str
    acknowledged: bool = True


@dataclass
class CreateSnapshotResult:
    """Result of creating a snapshot memory."""

    id: str
    session_id: str
    message_count: int
    has_embedding: bool
    embedding_strategy: str | None = None
    snapshot_reason: str = "manual"
    acknowledged: bool = True


@dataclass
class PromoteSnapshotResult:
    """Result of promoting STM to snapshot."""

    snapshot_id: str | None  # None if no promotion occurred
    session_id: str
    promoted_count: int
    reason: str
    has_embedding: bool = False
    acknowledged: bool = True


@dataclass
class CreateProceduralResult:
    """Result of creating a procedural memory."""

    id: str
    procedure: str
    has_embedding: bool
    acknowledged: bool = True


@dataclass
class DeleteResult:
    """Result of a delete operation."""

    deleted_count: int
    acknowledged: bool = True


@dataclass
class BulkCreateSemanticResult:
    """Result of bulk creating semantic memories."""

    created_count: int
    skipped_count: int
    created_ids: list[str]
    skipped_labels: list[str]
    has_embeddings: bool
    acknowledged: bool = True


@dataclass
class InternalStateResult:
    """
    Result of updating internal state.

    Returns key information for verification:
    - session_id: Which session was updated
    - version: New version number (increments on each update)
    - token_count: Token count of the new content
    - content_hash: SHA256[:16] for integrity verification
    """

    session_id: str
    version: int
    token_count: int
    content_hash: str
    previous_version: int | None = None
    was_noop: bool = False  # True if content_hash unchanged
    acknowledged: bool = True


@dataclass
class ISGenerationResult:
    """
    Result of automatic IS generation via generate_is_from_turn().

    Tracks whether the update happened, was skipped, or coalesced.
    """

    # Whether IS was actually updated
    updated: bool
    """True if IS was generated and stored."""

    # Update details (if updated=True)
    version: int | None = None
    """New IS version number."""

    token_count: int | None = None
    """Token count of generated IS."""

    content_hash: str | None = None
    """SHA256[:16] of generated content."""

    previous_version: int | None = None
    """Version before this update (for diff tracking)."""

    was_noop: bool = False
    """True if content_hash unchanged (no actual update)."""

    # Coalescing details (if updated=False)
    coalesced: bool = False
    """True if update was queued due to coalesce policy."""

    skipped_reason: str | None = None
    """Why update was skipped (e.g., "within_coalesce_window", "no_milestone")."""

    next_update_at: str | None = None
    """ISO timestamp when coalesced update will be processed."""

    # Provenance
    model_id: str | None = None
    """Model used for IS generation."""

    events_hash: str | None = None
    """Hash of input events (for provenance)."""


__all__ = [
    "WriteTurnResult",
    "CreateSemanticResult",
    "BulkCreateSemanticResult",
    "CreateTaxonomicResult",
    "CreateEpisodicResult",
    "CreateProceduralResult",
    "CreateUserContextResult",
    "CreateSnapshotResult",
    "PromoteSnapshotResult",
    "DeleteResult",
    "InternalStateResult",
    "ISGenerationResult",
]
