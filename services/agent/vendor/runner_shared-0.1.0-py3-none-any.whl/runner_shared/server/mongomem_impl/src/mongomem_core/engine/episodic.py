"""Episodic memory operations for MemoryEngine.

Internal implementation - use MemoryEngine from mongomem_core.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, List

from mongomem_core.exceptions import ValidationError
from mongomem_core.memory.episodic import (
    create_episodic,
    delete_episodic,
    get_episodic,
    list_episodic,
    soft_delete_episodic,
    update_episodic,
)
from mongomem_core.models.engine import CreateEpisodicResult, DeleteResult
from mongomem_core.models.filters import MetadataFilter
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.episodic import EpisodicIn, EpisodicOut, EpisodicUpdate
from mongomem_core.models.retrieval import MemoryChunk
from mongomem_core.retrieval import fetch_episodic_memories
from pydantic import ValidationError as PydanticValidationError

if TYPE_CHECKING:
    from mongomem_core.engine._protocol import EngineProtocol

logger = logging.getLogger(__name__)


class _Episodic:
    """Episodic memory CRUD and retrieval operations."""

    def fetch_episodic_memories(
        self: "EngineProtocol",
        query: str | List[float],
        org_id: str,
        *,
        user_id: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        session_id: str | None = None,
        top_k: int = 50,
        similarity_threshold: float = 0.0,
        dedup_threshold: float = 0.5,
        prefetched: List[EpisodicOut] | None = None,
        deduplicate: bool = True,
        rank: bool = True,
        metadata_filter: MetadataFilter | None = None,
    ) -> List[MemoryChunk]:
        """
        Fetch, deduplicate, and rank episodic memories.

        Args:
            query: Query text or pre-computed embedding vector
            org_id: Organization ID for multi-tenancy
            user_id: Optional user ID filter
            visibility: Optional visibility scope filter
            project_id: Optional group ID filter
            session_id: Optional session ID filter
            top_k: Maximum number of results from vector search
            similarity_threshold: Minimum similarity score
            dedup_threshold: Threshold for similarity-based deduplication
            prefetched: Optional pre-fetched episodic memories
            deduplicate: Whether to deduplicate results
            rank: Whether to rank results
            metadata_filter: Optional metadata filter for Atlas Vector Search pre-filtering

        Returns:
            List of MemoryChunk objects
        """
        vis = ChunkVisibility(visibility) if visibility else None

        return fetch_episodic_memories(
            db=self._db,
            org_id=org_id,
            query=query,
            embedder=self._embedder,
            user_id=user_id,
            visibility=vis,
            project_id=project_id,
            session_id=session_id,
            top_k=top_k,
            similarity_threshold=similarity_threshold,
            dedup_threshold=dedup_threshold,
            prefetched=prefetched,
            deduplicate=deduplicate,
            rank=rank,
            metadata_filter=metadata_filter,
        )

    def create_episodic(
        self: "EngineProtocol",
        *,
        title: str,
        org_id: str,
        user_id: str,
        content: str = "",
        summary_text: str = "",
        session_id: str | None = None,
        snapshot_ref_id: str | None = None,
        summary_type: str = "manual",
        source_agent: str = "user",
        participants: List[str] | None = None,
        tags: List[str] | None = None,
        visibility: str = "private",
        project_id: str | None = None,
        agent_id: str | None = None,
        extraction_source: str | None = None,
        embedding: list[float] | None = None,
        skip_embedding: bool = False,
    ) -> CreateEpisodicResult:
        """
        Create an episodic memory (event/experience).

        Args:
            title: Title or label for this episode
            org_id: Organization ID for multi-tenancy
            user_id: User ID who owns this memory
            content: Full episodic content
            summary_text: Summarized text of the episode
            session_id: Session ID this episode originated from
            snapshot_ref_id: Reference to source snapshot
            summary_type: Method used ("heuristic", "llm", "manual")
            source_agent: Agent/model that created this episode
            participants: List of participant IDs
            tags: Tags for categorization
            visibility: Visibility scope
            project_id: Project ID (required when visibility="shared")
            agent_id: Agent ID if created via agent
            extraction_source: Source type
            embedding: Pre-computed embedding
            skip_embedding: If True, don't embed even if embedder available

        Returns:
            CreateEpisodicResult with the created document's ID
        """
        logger.debug(
            "Creating episodic memory: title=%s org=%s user=%s skip_embedding=%s",
            title[:50],
            org_id,
            user_id,
            skip_embedding,
        )

        embed_text = summary_text or content

        final_embedding = embedding
        embedding_model_id = None
        if not skip_embedding and embedding is None and self._embedder is not None and embed_text:
            logger.debug("Generating embedding for episodic memory: title=%s", title[:50])
            final_embedding = self._embedder.embed(embed_text)
            embedding_model_id = self._embedder.model_id

        try:
            episodic_in = EpisodicIn(
                title=title,
                content=content,
                summary_text=summary_text,
                session_id=session_id,
                snapshot_ref_id=snapshot_ref_id,
                summary_type=summary_type,  # type: ignore[arg-type]
                source_agent=source_agent,
                participants=participants or [],
                tags=tags or [],
                visibility=ChunkVisibility(visibility) if visibility else ChunkVisibility.PRIVATE,
                project_id=project_id,
                agent_id=agent_id,
                extraction_source=extraction_source,
            )
        except PydanticValidationError as exc:
            logger.warning(
                "Validation failed for create_episodic: title=%s errors=%s",
                title[:50],
                exc.errors(),
            )
            raise ValidationError(
                f"Invalid episodic data: {exc}",
                details={"title": title, "validation_errors": exc.errors()},
            ) from exc

        episodic_doc = create_episodic(
            db=self._db,
            episodic_in=episodic_in,
            org_id=org_id,
            user_id=user_id,
            embedding=final_embedding,
            embedding_model_id=embedding_model_id,
        )

        logger.info(
            "Episodic memory created: id=%s title=%s has_embedding=%s",
            episodic_doc.id,
            episodic_doc.title[:50],
            episodic_doc.has_embedding,
        )

        return CreateEpisodicResult(
            id=str(episodic_doc.id),
            title=episodic_doc.title,
            has_embedding=episodic_doc.has_embedding,
            acknowledged=True,
        )

    def get_episodic(
        self: "EngineProtocol",
        org_id: str,
        *,
        id: str | None = None,
        session_id: str | None = None,
        snapshot_ref_id: str | None = None,
        project_id: str | None = None,
        user_id: str | None = None,
        visibility: str | None = None,
        include_deleted: bool = False,
    ) -> EpisodicOut | None:
        """
        Retrieve an episodic memory by ID or session+snapshot.

        Args:
            org_id: Organization ID
            id: Document ID (mutually exclusive with session_id+snapshot_ref_id)
            session_id: Session ID (requires snapshot_ref_id)
            snapshot_ref_id: Snapshot reference ID (requires session_id)
            project_id: Filter by project ID
            include_deleted: Include soft-deleted documents

        Returns:
            EpisodicOut if found, None otherwise
        """
        return get_episodic(
            db=self._db,
            org_id=org_id,
            id=id,
            session_id=session_id,
            snapshot_ref_id=snapshot_ref_id,
            project_id=project_id,
            user_id=user_id,
            visibility=visibility,
            include_deleted=include_deleted,
        )

    def list_episodic(
        self: "EngineProtocol",
        org_id: str,
        *,
        user_id: str | None = None,
        session_id: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        limit: int = 100,
        include_deleted: bool = False,
    ) -> List[EpisodicOut]:
        """
        List episodic memories with optional filters.

        Args:
            org_id: Organization ID
            user_id: Filter by user ID
            session_id: Filter by session ID
            visibility: Filter by visibility
            project_id: Filter by group ID
            limit: Maximum number of results
            include_deleted: Include soft-deleted documents

        Returns:
            List of EpisodicOut documents
        """
        return list_episodic(
            db=self._db,
            org_id=org_id,
            user_id=user_id,
            session_id=session_id,
            visibility=ChunkVisibility(visibility) if visibility else None,
            project_id=project_id,
            limit=limit,
            include_deleted=include_deleted,
        )

    def update_episodic(
        self: "EngineProtocol",
        org_id: str,
        *,
        id: str | None = None,
        session_id: str | None = None,
        snapshot_ref_id: str | None = None,
        title: str | None = None,
        content: str | None = None,
        summary_text: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        tags: List[str] | None = None,
    ) -> EpisodicOut | None:
        """
        Update an episodic memory.

        Args:
            org_id: Organization ID
            id: Document ID (mutually exclusive with session_id+snapshot_ref_id)
            session_id: Session ID (requires snapshot_ref_id)
            snapshot_ref_id: Snapshot reference ID (requires session_id)
            title: New title
            content: New content
            summary_text: New summary
            visibility: New visibility
            project_id: New group ID
            tags: New tags

        Returns:
            Updated EpisodicOut if found, None otherwise
        """
        update = EpisodicUpdate(
            title=title,
            content=content,
            summary_text=summary_text,
            visibility=ChunkVisibility(visibility) if visibility else None,
            project_id=project_id,
            tags=tags,
        )

        return update_episodic(
            db=self._db,
            org_id=org_id,
            update=update,
            id=id,
            session_id=session_id,
            snapshot_ref_id=snapshot_ref_id,
        )

    def delete_episodic(
        self: "EngineProtocol",
        org_id: str,
        *,
        id: str | None = None,
        session_id: str | None = None,
        snapshot_ref_id: str | None = None,
        soft: bool = True,
    ) -> DeleteResult:
        """
        Delete an episodic memory.

        Args:
            org_id: Organization ID
            id: Document ID (mutually exclusive with session_id+snapshot_ref_id)
            session_id: Session ID (requires snapshot_ref_id)
            snapshot_ref_id: Snapshot reference ID (requires session_id)
            soft: If True (default), soft delete. If False, hard delete.

        Returns:
            DeleteResult with deleted_count
        """
        if soft:
            update_result = soft_delete_episodic(
                db=self._db,
                org_id=org_id,
                id=id,
                session_id=session_id,
                snapshot_ref_id=snapshot_ref_id,
            )
            deleted_count = update_result.modified_count
        else:
            delete_result = delete_episodic(
                db=self._db,
                org_id=org_id,
                id=id,
                session_id=session_id,
                snapshot_ref_id=snapshot_ref_id,
            )
            deleted_count = delete_result.deleted_count

        logger.info(
            "Deleted episodic memory: org=%s id=%s soft=%s count=%d",
            org_id,
            id,
            soft,
            deleted_count,
        )
        return DeleteResult(deleted_count=deleted_count, acknowledged=True)
