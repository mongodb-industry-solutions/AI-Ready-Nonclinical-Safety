"""
Base protocol for text chunkers.

All chunkers must implement this protocol to be used in the ingestion pipeline.
"""

from typing import List, Protocol, runtime_checkable

from mongomem_core.ingest.models import ChunkConfig


@runtime_checkable
class TextChunker(Protocol):
    """Protocol for text chunkers."""

    def __init__(self, config: ChunkConfig) -> None:
        """Initialize chunker with configuration."""
        ...

    def chunk(self, text: str) -> List[str]:
        """
        Split text into chunks.

        Args:
            text: Input text to split

        Returns:
            List of text chunks
        """
        ...
