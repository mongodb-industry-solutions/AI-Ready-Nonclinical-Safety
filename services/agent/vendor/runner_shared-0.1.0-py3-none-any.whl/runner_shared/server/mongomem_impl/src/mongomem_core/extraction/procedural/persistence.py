"""
Persistence layer for procedural extraction results.

Provides:
- Atomic idempotent ADD using $setOnInsert (race-safe)
- Version-aware UPDATE (creates new version, supersedes old — like semantic)
- Atomic REINFORCE with importance tracking (aggregation pipeline)
"""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

if TYPE_CHECKING:
    from pymongo.database import Database

from bson import ObjectId
from mongomem_core.common.utils import handle_db_error, safe_object_id, utcnow
from mongomem_core.extraction.procedural.config import ProceduralExtractionConfig
from mongomem_core.extraction.types import ConsolidationDecision, PersistenceResult
from mongomem_core.extraction.utils import build_reinforce_pipeline
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.storage import get_collection
from mongomem_core.storage.collections import ProceduralMemoryCollection

logger = logging.getLogger(__name__)

_PROCEDURAL_COL = ProceduralMemoryCollection()

_DEFAULT_LOG_TRUNCATE_LENGTH = 50


def generate_procedural_extraction_id(
    source_id: str,
    procedure_name: str,
    idempotency_key: Optional[str] = None,
) -> str:
    """Generate SHA-256 hash for idempotent procedural writes.

    Uses procedure name (not content) as the dedup key since procedures
    are identified by name within an org.
    """
    data = f"{source_id}_{procedure_name}"
    if idempotency_key:
        data = f"{data}_{idempotency_key}"
    return hashlib.sha256(data.encode()).hexdigest()


def _validate_extraction_for_persistence(extraction: Any) -> bool:
    """Validate extraction has required fields for persistence."""
    if not extraction.content or not extraction.content.strip():
        logger.warning("Extraction missing content")
        return False
    if not extraction.embedding:
        logger.warning("Extraction missing embedding")
        return False
    if not extraction.metadata.get("procedure"):
        logger.warning("Extraction missing procedure name")
        return False
    return True


def perform_procedural_add(
    db: "Database",
    decision: ConsolidationDecision,
    org_id: str,
    user_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    embedding_model_id: str,
    visibility: ChunkVisibility = ChunkVisibility.PRIVATE,
    project_id: Optional[str] = None,
) -> Optional[str]:
    """Atomic idempotent ADD for procedural memories.

    Uses update_one with upsert and $setOnInsert for race-safety.
    If a document with the same extraction_id already exists, returns None.

    Returns:
        Created document ID string, or None if duplicate detected
    """
    col = get_collection(_PROCEDURAL_COL, db)
    extraction = decision.extraction

    if not _validate_extraction_for_persistence(extraction):
        logger.warning("Invalid extraction for ADD, skipping")
        return None

    metadata = extraction.metadata
    procedure_name = metadata["procedure"]
    description = metadata.get("description", "")
    steps = metadata.get("steps", [])
    tags = metadata.get("tags", [])

    extraction_id = generate_procedural_extraction_id(source_id, procedure_name)

    if not extraction_id or not isinstance(extraction_id, str):
        logger.error("Invalid extraction_id: %s", extraction_id)
        return None

    now = utcnow()
    new_id = ObjectId()

    doc = {
        "_id": new_id,
        "org_id": org_id,
        "user_id": user_id,
        "procedure": procedure_name,
        "description": description,
        "content": extraction.content,
        "steps": steps,
        "tags": tags,
        "extraction_source": "agent_mediated",
        "extraction_id": extraction_id,
        "embedding": extraction.embedding,
        "embedding_model_id": embedding_model_id,
        "has_embedding": True,
        # Versioning
        "version": 1,
        "is_latest": True,
        "memory_lineage_id": str(new_id),
        "previous_version_id": None,
        # Reinforcement
        "reinforcement_count": 0,
        "last_reinforced_at": None,
        "reinforcement_history": [],
        # Timestamps
        "timestamp": extraction_timestamp,
        "created_at": now,
        "updated_at": now,
        # Soft delete
        "deleted": False,
        "deleted_at": None,
        # Scoring metadata
        "contextual_metadata": {
            "citation_score": extraction.citation_score,
            "llm_confidence_score": extraction.confidence,
            "combined_score": extraction.combined_score,
            "cited_text": extraction.cited_text,
            "reinforcement_sources": [],
        },
        # Visibility/scope
        "visibility": visibility.value,
        "project_id": project_id,
    }

    with handle_db_error(
        operation="update_one",
        collection=_PROCEDURAL_COL.name,
        log_message="Failed to perform idempotent ADD: extraction_id=%s org=%s",
        log_args_tuple=(extraction_id, org_id),
    ):
        result = col.update_one(
            {"extraction_id": extraction_id, "org_id": org_id},
            {"$setOnInsert": doc},
            upsert=True,
        )

        if result.upserted_id:
            logger.debug("Created new procedural memory: %s", result.upserted_id)
            return str(result.upserted_id)
        elif result.matched_count > 0:
            logger.info(
                "Duplicate procedural extraction detected, skipping (idempotent): extraction_id=%s",
                extraction_id,
            )
            return None

    return None


def perform_procedural_update(
    db: "Database",
    decision: ConsolidationDecision,
    org_id: str,
    user_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    embedding_model_id: str,
    visibility: ChunkVisibility = ChunkVisibility.PRIVATE,
    project_id: Optional[str] = None,
) -> Optional[Tuple[str, str]]:
    """Version-aware UPDATE for procedural memories.

    Creates a new version of the procedure, superseding the old one.
    Follows the semantic memory versioning pattern:
    1. Fetch existing doc (is_latest=True)
    2. Check idempotency
    3. Insert new version with is_latest=True
    4. Atomically mark old as is_latest=False

    Returns:
        Tuple of (new_doc_id, old_doc_id) if updated, or None if failed
    """
    col = get_collection(_PROCEDURAL_COL, db)
    extraction = decision.extraction
    existing_id = decision.existing_id

    if not existing_id:
        logger.warning("UPDATE decision missing existing_id")
        return None

    if not _validate_extraction_for_persistence(extraction):
        logger.warning("Invalid extraction for UPDATE, skipping")
        return None

    try:
        query_id = ObjectId(existing_id)
    except Exception as e:
        logger.warning("Invalid ObjectId format: %s - %s", existing_id, e)
        return None

    metadata = extraction.metadata
    procedure_name = metadata["procedure"]
    description = metadata.get("description", "")
    steps = metadata.get("steps", [])
    tags = metadata.get("tags", [])

    # Fetch existing
    try:
        existing = col.find_one(
            {
                "_id": query_id,
                "org_id": org_id,
                "user_id": user_id,
                "is_latest": True,
            }
        )
    except Exception as e:
        logger.error("Failed to fetch existing document %s: %s", existing_id, e)
        return None

    if not existing:
        logger.warning(
            "Existing procedural %s not found or not latest (org_id=%s, user_id=%s)",
            existing_id,
            org_id,
            user_id,
        )
        return None

    memory_lineage_id = existing.get("memory_lineage_id") or str(existing["_id"])
    new_version = existing.get("version", 1) + 1

    # Idempotency check
    extraction_id = generate_procedural_extraction_id(source_id, procedure_name)
    existing_with_extraction_id = col.find_one(
        {
            "extraction_id": extraction_id,
            "memory_lineage_id": memory_lineage_id,
            "org_id": org_id,
        },
        projection={"_id": 1, "version": 1},
    )

    if existing_with_extraction_id:
        logger.info(
            "UPDATE idempotency: Version %s with extraction_id %s already exists",
            existing_with_extraction_id["_id"],
            extraction_id,
        )
        return (str(existing_with_extraction_id["_id"]), existing_id)

    now = utcnow()

    new_doc = {
        "org_id": org_id,
        "user_id": user_id,
        "procedure": procedure_name,
        "description": description,
        "content": extraction.content,
        "steps": steps,
        "tags": tags,
        "extraction_source": "agent_mediated",
        "extraction_id": extraction_id,
        "embedding": extraction.embedding,
        "embedding_model_id": embedding_model_id,
        "has_embedding": True,
        # Versioning
        "version": new_version,
        "is_latest": True,
        "memory_lineage_id": memory_lineage_id,
        "previous_version_id": existing_id,
        # Carry over reinforcement
        "reinforcement_count": existing.get("reinforcement_count", 0),
        "last_reinforced_at": existing.get("last_reinforced_at"),
        "reinforcement_history": existing.get("reinforcement_history", []),
        # Timestamps
        "timestamp": extraction_timestamp,
        "created_at": existing.get("created_at", now),
        "updated_at": now,
        # Soft delete
        "deleted": False,
        "deleted_at": None,
        # Scoring metadata
        "contextual_metadata": {
            "citation_score": extraction.citation_score,
            "llm_confidence_score": extraction.confidence,
            "combined_score": extraction.combined_score,
            "cited_text": extraction.cited_text,
            **existing.get("contextual_metadata", {}),
        },
        # Visibility/scope
        "visibility": visibility.value,
        "project_id": project_id,
    }

    try:
        insert_result = col.insert_one(new_doc)
        new_doc_id = str(insert_result.inserted_id)
        logger.debug(
            "Inserted new procedural version %s for lineage %s (version=%d)",
            new_doc_id,
            memory_lineage_id,
            new_version,
        )
    except Exception as e:
        logger.error("Failed to insert new procedural version: %s", e)
        return None

    # Atomically mark old as superseded
    try:
        update_result = col.update_one(
            {
                "_id": query_id,
                "org_id": org_id,
                "is_latest": True,
            },
            {"$set": {"is_latest": False, "updated_at": now}},
        )

        if update_result.modified_count == 0:
            logger.warning(
                "Race condition detected: old procedural %s already superseded, "
                "rolling back new version %s",
                existing_id,
                new_doc_id,
            )
            col.update_one(
                {"_id": insert_result.inserted_id},
                {"$set": {"is_latest": False}},
            )
    except Exception as e:
        logger.error("Failed to mark old version as superseded: %s", e)
        col.update_one(
            {"_id": insert_result.inserted_id},
            {"$set": {"is_latest": False}},
        )

    return (new_doc_id, existing_id)


def perform_procedural_reinforce(
    db: "Database",
    decision: ConsolidationDecision,
    org_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    reinforcement_history_limit: int = 20,
    user_id: Optional[str] = None,
) -> Optional[str]:
    """Atomic reinforcement for procedural memories.

    Tracks how many times a procedure is referenced (importance signal).
    All operations are atomic and idempotent.

    Returns:
        Document ID if reinforced, or None if failed
    """
    col = get_collection(_PROCEDURAL_COL, db)
    existing_id = decision.existing_id

    query_id = safe_object_id(existing_id, "REINFORCE")
    if not query_id:
        return None

    update_pipeline = build_reinforce_pipeline(
        source_id=source_id,
        timestamp=extraction_timestamp,
        sources_field="contextual_metadata.reinforcement_sources",
        history_field="reinforcement_history",
        count_field="reinforcement_count",
        last_reinforced_field="last_reinforced_at",
        history_limit=reinforcement_history_limit,
        extra_set_stages={
            "updated_at": extraction_timestamp,
        },
    )

    query_filter: Dict[str, Any] = {
        "_id": query_id,
        "org_id": org_id,
        "deleted": {"$ne": True},
    }
    if user_id:
        query_filter["user_id"] = user_id

    try:
        result = col.update_one(query_filter, update_pipeline)
    except Exception as e:
        logger.error("Failed to reinforce procedural document %s: %s", existing_id, e)
        return None

    if result.matched_count > 0:
        if result.modified_count > 0:
            logger.info(
                "Reinforced procedural memory %s: source_snapshot=%s",
                existing_id,
                source_id,
            )
        else:
            logger.debug(
                "Procedural memory %s already reinforced by snapshot %s (idempotent)",
                existing_id,
                source_id,
            )
        return existing_id

    logger.warning(
        "Procedural memory %s not found for reinforcement (org_id=%s)",
        existing_id,
        org_id,
    )
    return None


def apply_procedural_decisions(
    db: "Database",
    decisions: List[ConsolidationDecision],
    org_id: str,
    user_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    embedding_model_id: str,
    config: ProceduralExtractionConfig,
    visibility: ChunkVisibility = ChunkVisibility.PRIVATE,
    project_id: Optional[str] = None,
) -> PersistenceResult:
    """Apply all consolidation decisions for procedural memories.

    Returns:
        PersistenceResult with counts and IDs of affected documents
    """
    result = PersistenceResult()

    for decision in decisions:
        try:
            if decision.action == "ADD":
                doc_id = perform_procedural_add(
                    db=db,
                    decision=decision,
                    org_id=org_id,
                    user_id=user_id,
                    source_id=source_id,
                    extraction_timestamp=extraction_timestamp,
                    embedding_model_id=embedding_model_id,
                    visibility=visibility,
                    project_id=project_id,
                )
                if doc_id:
                    result.added += 1
                    result.created_ids.append(doc_id)
                else:
                    result.skipped += 1

            elif decision.action == "UPDATE":
                ids = perform_procedural_update(
                    db=db,
                    decision=decision,
                    org_id=org_id,
                    user_id=user_id,
                    source_id=source_id,
                    extraction_timestamp=extraction_timestamp,
                    embedding_model_id=embedding_model_id,
                    visibility=visibility,
                    project_id=project_id,
                )
                if ids:
                    result.updated += 1
                    result.updated_new_version_ids.append(ids[0])
                else:
                    result.skipped += 1

            elif decision.action == "REINFORCE":
                doc_id = perform_procedural_reinforce(
                    db=db,
                    decision=decision,
                    org_id=org_id,
                    source_id=source_id,
                    extraction_timestamp=extraction_timestamp,
                    reinforcement_history_limit=config.reinforcement_history_limit,
                    user_id=user_id,
                )
                if doc_id:
                    result.reinforced += 1
                    result.reinforced_ids.append(doc_id)
                else:
                    result.skipped += 1

            elif decision.action == "DUPLICATE":
                result.skipped += 1

        except Exception as e:
            logger.warning(
                "%s failed for procedural decision %s: %s",
                decision.action,
                decision.extraction.content[:_DEFAULT_LOG_TRUNCATE_LENGTH]
                if decision.extraction.content
                else "empty",
                e,
            )
            result.errors.append(f"{decision.action}: {e}")

    return result


__all__ = [
    "generate_procedural_extraction_id",
    "perform_procedural_add",
    "perform_procedural_update",
    "perform_procedural_reinforce",
    "apply_procedural_decisions",
]
