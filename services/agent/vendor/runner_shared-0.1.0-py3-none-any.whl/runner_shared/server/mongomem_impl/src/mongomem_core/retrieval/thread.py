"""
Conversation thread retrieval pipeline.

This pipeline implements "conversation resumption" - retrieving coherent
sequences of snapshots that represent complete conversation threads,
rather than scattered top-k results.

The adaptive algorithm:
1. **Anchor Selection**: Find the most relevant snapshot(s) via search
2. **Expansion**: Grow the thread using topic/session/similarity strategies
3. **Termination**: Stop when budget exhausted or relevancy drops

Example:
    >>> from mongomem_core.retrieval import retrieve_conversation_thread
    >>> from mongomem_core.models.config import ThreadRetrievalConfig, KNOWLEDGE_RETRIEVAL_CONFIG
    >>>
    >>> # Simple usage with defaults
    >>> thread = retrieve_conversation_thread(backend, "org_1", "MongoDB indexes")
    >>>
    >>> # With custom config
    >>> config = ThreadRetrievalConfig(expansion="adaptive", max_tokens=8000)
    >>> thread = retrieve_conversation_thread(backend, "org_1", query_embedding, config)
    >>>
    >>> # Using preset
    >>> thread = retrieve_conversation_thread(backend, "org_1", "resume", RESUME_SESSION_CONFIG)
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Dict, List, Optional, Union

from mongomem_core.models.config.thread_retrieval import ThreadRetrievalConfig
from mongomem_core.models.memory.snapshot import SnapshotOut
from mongomem_core.models.retrieval import ConversationThread, ThreadRetrievalMetrics

if TYPE_CHECKING:
    from mongomem_core.protocols import EmbedderProtocol
    from mongomem_core.retrieval.backends import SnapshotSearchBackend

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Main Entry Point
# ─────────────────────────────────────────────────────────────────────────────


def retrieve_conversation_thread(
    backend: "SnapshotSearchBackend",
    org_id: str,
    query: Union[str, List[float]],
    config: Optional[ThreadRetrievalConfig] = None,
    *,
    embedder: Optional["EmbedderProtocol"] = None,
    return_metrics: bool = False,
) -> Union[ConversationThread, tuple[ConversationThread, ThreadRetrievalMetrics]]:
    """
    Retrieve a coherent conversation thread relevant to the query.

    This is the main entry point for thread retrieval. It finds an anchor
    snapshot, expands to related snapshots using the configured strategy,
    and returns a chronologically ordered thread.

    Args:
        backend: Snapshot search backend (MongoDB, etc.)
        org_id: Organization ID
        query: Either a text query (str) or pre-computed embedding (List[float])
        config: Retrieval configuration (defaults to sensible defaults)
        embedder: Required for text queries with vector/hybrid search
        return_metrics: If True, also return retrieval metrics

    Returns:
        ConversationThread containing the relevant snapshots.
        If return_metrics=True, returns (ConversationThread, ThreadRetrievalMetrics).

    Raises:
        ValueError: If embedder is required but not provided

    Example:
        >>> thread = retrieve_conversation_thread(backend, "org_1", "MongoDB indexes")
        >>> print(f"Found {len(thread.snapshots)} snapshots")
        >>> print(thread.to_context_string())
    """
    config = config or ThreadRetrievalConfig()
    metrics = ThreadRetrievalMetrics(
        search_mode=config.search_mode,
        expansion_strategy=config.expansion,
        tokens_budget=config.max_tokens,
    )

    start_time = time.time()

    # ─────────────────────────────────────────────────────────────────────
    # Step 1: Anchor Selection
    # ─────────────────────────────────────────────────────────────────────
    search_start = time.time()
    anchors = _select_anchors(
        backend=backend,
        org_id=org_id,
        query=query,
        config=config,
        embedder=embedder,
    )
    metrics.search_latency_ms = (time.time() - search_start) * 1000
    metrics.anchors_considered = len(anchors)

    if not anchors:
        logger.debug("No anchors found for query in org=%s", org_id)
        empty_thread = ConversationThread()
        if return_metrics:
            metrics.total_latency_ms = (time.time() - start_time) * 1000
            return empty_thread, metrics
        return empty_thread

    anchor = anchors[0]
    logger.debug(
        "Selected anchor: id=%s session=%s score=%.3f",
        anchor.id,
        anchor.session_id,
        anchor.score or 0,
    )

    # ─────────────────────────────────────────────────────────────────────
    # Step 2: Expansion
    # ─────────────────────────────────────────────────────────────────────
    expansion_start = time.time()

    if config.expansion == "topic" and anchor.topic_id:
        thread_snaps, expansion_path = _expand_by_topic(backend, org_id, anchor, config)
    elif config.expansion == "session":
        thread_snaps, expansion_path = _expand_by_session(backend, org_id, anchor, config)
    elif config.expansion == "similarity":
        thread_snaps, expansion_path = _expand_by_similarity(
            backend, org_id, anchor, config, embedder
        )
    else:  # adaptive (default)
        thread_snaps, expansion_path = _expand_adaptive(
            backend=backend,
            org_id=org_id,
            anchor=anchor,
            initial_anchors=anchors,
            config=config,
            embedder=embedder,
        )

    metrics.expansion_latency_ms = (time.time() - expansion_start) * 1000
    metrics.snapshots_evaluated = len(thread_snaps)

    # ─────────────────────────────────────────────────────────────────────
    # Step 3: Finalize (dedupe, sort, enforce budget)
    # ─────────────────────────────────────────────────────────────────────
    final_snaps, total_tokens, filtered_budget = _finalize_thread(thread_snaps, config)

    metrics.snapshots_included = len(final_snaps)
    metrics.snapshots_filtered_by_budget = filtered_budget
    metrics.tokens_used = total_tokens
    metrics.total_latency_ms = (time.time() - start_time) * 1000

    # Build result
    sessions = list({s.session_id for s in final_snaps})
    thread = ConversationThread(
        snapshots=final_snaps,
        anchor=anchor,
        anchor_score=anchor.score or 0.0,
        total_tokens=total_tokens,
        sessions_included=sessions,
        expansion_path=expansion_path,
    )

    logger.info(
        "Thread retrieval complete: %d snapshots, %d tokens, %d sessions, %.1fms",
        len(final_snaps),
        total_tokens,
        len(sessions),
        metrics.total_latency_ms,
    )

    if return_metrics:
        return thread, metrics
    return thread


# ─────────────────────────────────────────────────────────────────────────────
# Anchor Selection
# ─────────────────────────────────────────────────────────────────────────────


def _select_anchors(
    backend: "SnapshotSearchBackend",
    org_id: str,
    query: Union[str, List[float]],
    config: ThreadRetrievalConfig,
    embedder: Optional["EmbedderProtocol"],
) -> List[SnapshotOut]:
    """
    Select anchor snapshot(s) based on query and search mode.

    Args:
        backend: Snapshot search backend
        org_id: Organization ID
        query: Text query or embedding vector
        config: Retrieval configuration
        embedder: Optional embedder for text queries

    Returns:
        List of candidate anchor snapshots, sorted by relevance
    """
    # If query is already an embedding
    if isinstance(query, list):
        return backend.vector_search(org_id, query, top_k=config.anchor_top_k)

    # Text query - use configured search mode
    if config.search_mode == "text":
        return backend.text_search(org_id, query, top_k=config.anchor_top_k)

    if config.search_mode == "hybrid":
        if embedder is None:
            raise ValueError("embedder is required for hybrid search_mode")
        return backend.hybrid_search(org_id, query, embedder, top_k=config.anchor_top_k)

    # Default: vector mode
    if embedder is None:
        raise ValueError("embedder is required for vector search_mode with text query")
    embedding = embedder.embed(query)
    return backend.vector_search(org_id, embedding, top_k=config.anchor_top_k)


# ─────────────────────────────────────────────────────────────────────────────
# Expansion Strategies
# ─────────────────────────────────────────────────────────────────────────────


def _expand_by_topic(
    backend: "SnapshotSearchBackend",
    org_id: str,
    anchor: SnapshotOut,
    config: ThreadRetrievalConfig,
) -> tuple[List[SnapshotOut], List[str]]:
    """
    Expand thread by following topic_id within the anchor's session.

    Returns all snapshots that share the same topic_id.
    """
    expansion_path = ["topic"]

    if not anchor.topic_id:
        logger.debug("Anchor has no topic_id, returning anchor only")
        return [anchor], expansion_path

    snaps = backend.list_by_topic(
        org_id=org_id,
        session_id=anchor.session_id,
        topic_id=anchor.topic_id,
    )

    if not snaps:
        return [anchor], expansion_path

    logger.debug(
        "Topic expansion: found %d snapshots for topic=%s",
        len(snaps),
        anchor.topic_id,
    )
    return snaps, expansion_path


def _expand_by_session(
    backend: "SnapshotSearchBackend",
    org_id: str,
    anchor: SnapshotOut,
    config: ThreadRetrievalConfig,
) -> tuple[List[SnapshotOut], List[str]]:
    """
    Expand thread by getting snapshots before/after anchor in same session.

    Uses session_window_before and session_window_after from config.
    """
    expansion_path = ["session"]

    session_snaps = backend.list_by_session(
        org_id=org_id,
        session_id=anchor.session_id,
        limit=config.max_snapshots * 2,  # Get extra to allow windowing
    )

    if not session_snaps:
        return [anchor], expansion_path

    # Sort by timestamp and find anchor position
    session_snaps_sorted = sorted(session_snaps, key=lambda s: s.timestamp)

    try:
        anchor_idx = next(i for i, s in enumerate(session_snaps_sorted) if s.id == anchor.id)
    except StopIteration:
        # Anchor not in list (shouldn't happen), return anchor only
        logger.warning("Anchor not found in session snapshots, returning anchor only")
        return [anchor], expansion_path

    # Apply window
    start = max(0, anchor_idx - config.session_window_before)
    end = min(len(session_snaps_sorted), anchor_idx + config.session_window_after + 1)

    window_snaps = session_snaps_sorted[start:end]
    logger.debug(
        "Session expansion: window [%d:%d] = %d snapshots",
        start,
        end,
        len(window_snaps),
    )
    return window_snaps, expansion_path


def _expand_by_similarity(
    backend: "SnapshotSearchBackend",
    org_id: str,
    anchor: SnapshotOut,
    config: ThreadRetrievalConfig,
    embedder: Optional["EmbedderProtocol"],
) -> tuple[List[SnapshotOut], List[str]]:
    """
    Expand thread by chasing embedding similarity.

    Starts from anchor, finds similar snapshots, then follows their
    embeddings to discover connected ideas across sessions.
    """
    expansion_path = ["similarity"]

    # Get initial embedding
    if anchor.embedding:
        current_embedding = anchor.embedding
    elif embedder and anchor.messages:
        # Re-embed anchor content
        content = "\n".join(f"{m.role.value}: {m.content}" for m in anchor.messages if m.content)
        current_embedding = embedder.embed(content)
    else:
        logger.debug("No embedding available for similarity expansion")
        return [anchor], expansion_path

    results: Dict[str, SnapshotOut] = {anchor.id: anchor}
    seen_ids = {anchor.id}
    token_count = _estimate_tokens(anchor)

    cascade_depth = 0
    max_cascade = 5  # Prevent infinite loops

    while len(results) < config.max_snapshots and cascade_depth < max_cascade:
        cascade_depth += 1

        candidates = backend.vector_search(
            org_id=org_id,
            embedding=current_embedding,
            top_k=config.similarity_top_k,
            exclude_ids=seen_ids,
        )

        if not candidates:
            break

        best = candidates[0]
        seen_ids.add(best.id)

        # Check similarity threshold
        if best.score is not None and best.score < config.similarity_min_score:
            logger.debug(
                "Similarity cascade stopped: score %.3f < threshold %.3f",
                best.score,
                config.similarity_min_score,
            )
            break

        # Check token budget
        candidate_tokens = _estimate_tokens(best)
        if token_count + candidate_tokens > config.max_tokens:
            logger.debug("Similarity cascade stopped: token budget exceeded")
            break

        results[best.id] = best
        token_count += candidate_tokens
        expansion_path.append(f"cascade:{best.id[:8]}")

        # Chase the thread - use best's embedding for next iteration
        if best.embedding:
            current_embedding = best.embedding
        elif embedder and best.messages:
            content = "\n".join(f"{m.role.value}: {m.content}" for m in best.messages if m.content)
            current_embedding = embedder.embed(content)
        else:
            break

    logger.debug(
        "Similarity expansion: %d snapshots after %d cascades",
        len(results),
        cascade_depth,
    )
    return list(results.values()), expansion_path


def _expand_adaptive(
    backend: "SnapshotSearchBackend",
    org_id: str,
    anchor: SnapshotOut,
    initial_anchors: List[SnapshotOut],
    config: ThreadRetrievalConfig,
    embedder: Optional["EmbedderProtocol"],
) -> tuple[List[SnapshotOut], List[str]]:
    """
    Adaptive expansion combining topic, session, and cross-session strategies.

    Algorithm:
    1. If anchor has topic_id → pull entire topic within session
    2. Add local session window around anchor
    3. If cross-session allowed → pull windows around other high-scoring anchors
    4. Respect token + snapshot budgets throughout

    This is the most sophisticated strategy and the default.
    """
    expansion_path: List[str] = ["adaptive"]
    thread: Dict[str, SnapshotOut] = {}
    token_count = 0

    def maybe_add(snap: SnapshotOut) -> bool:
        """Try to add snapshot to thread, respecting budgets."""
        nonlocal token_count
        if snap.id in thread:
            return True  # Already have it

        snap_tokens = _estimate_tokens(snap)
        if len(thread) >= config.max_snapshots:
            return False
        if token_count + snap_tokens > config.max_tokens:
            return False

        thread[snap.id] = snap
        token_count += snap_tokens
        return True

    # ─────────────────────────────────────────────────────────────────────
    # Phase 1: Topic expansion (if anchor has topic_id)
    # ─────────────────────────────────────────────────────────────────────
    if anchor.topic_id:
        expansion_path.append("topic")
        topic_snaps = backend.list_by_topic(
            org_id=org_id,
            session_id=anchor.session_id,
            topic_id=anchor.topic_id,
        )
        for snap in topic_snaps:
            if not maybe_add(snap):
                break
        logger.debug("Phase 1 (topic): %d snapshots", len(thread))

    # Ensure anchor is always included
    maybe_add(anchor)

    # ─────────────────────────────────────────────────────────────────────
    # Phase 2: Session context window
    # ─────────────────────────────────────────────────────────────────────
    if len(thread) < config.max_snapshots:
        expansion_path.append("session")
        session_window, _ = _expand_by_session(backend, org_id, anchor, config)
        for snap in session_window:
            if not maybe_add(snap):
                break
        logger.debug("Phase 2 (session): %d snapshots", len(thread))

    # ─────────────────────────────────────────────────────────────────────
    # Phase 3: Cross-session (other high-scoring anchors)
    # ─────────────────────────────────────────────────────────────────────
    if config.allow_cross_session and len(thread) < config.max_snapshots:
        expansion_path.append("cross_session")

        for other_anchor in initial_anchors[1:]:  # Skip primary anchor
            if len(thread) >= config.max_snapshots:
                break

            # Check relevancy threshold
            if other_anchor.score is not None and other_anchor.score < config.min_relevancy:
                continue

            # Skip if same session (already covered)
            if other_anchor.session_id == anchor.session_id:
                continue

            # Get small window around this anchor
            narrow_config = config.with_overrides(
                session_window_before=1,
                session_window_after=1,
            )
            cross_window, _ = _expand_by_session(backend, org_id, other_anchor, narrow_config)

            for snap in cross_window:
                if not maybe_add(snap):
                    break

            expansion_path.append(f"cross:{other_anchor.session_id[:8]}")

        logger.debug("Phase 3 (cross-session): %d snapshots", len(thread))

    return list(thread.values()), expansion_path


# ─────────────────────────────────────────────────────────────────────────────
# Finalization
# ─────────────────────────────────────────────────────────────────────────────


def _finalize_thread(
    snapshots: List[SnapshotOut],
    config: ThreadRetrievalConfig,
) -> tuple[List[SnapshotOut], int, int]:
    """
    Finalize thread: deduplicate, sort chronologically, enforce budget.

    Returns:
        Tuple of (sorted_snapshots, total_tokens, filtered_by_budget_count)
    """
    # Sort by timestamp
    sorted_snaps = sorted(snapshots, key=lambda s: s.timestamp)

    final: List[SnapshotOut] = []
    total_tokens = 0
    seen_ids: set[str] = set()
    filtered_by_budget = 0

    for snap in sorted_snaps:
        if snap.id in seen_ids:
            continue

        snap_tokens = _estimate_tokens(snap)

        if len(final) >= config.max_snapshots:
            filtered_by_budget += 1
            continue

        if total_tokens + snap_tokens > config.max_tokens:
            filtered_by_budget += 1
            continue

        final.append(snap)
        seen_ids.add(snap.id)
        total_tokens += snap_tokens

    return final, total_tokens, filtered_by_budget


def _estimate_tokens(snapshot: SnapshotOut) -> int:
    """
    Estimate token count for a snapshot.

    Uses stored token count if available, otherwise estimates from content.
    """
    # Check for stored token count in metadata
    if snapshot.metadata and "token_count" in snapshot.metadata:
        return int(snapshot.metadata["token_count"])

    # Estimate from message content (rough: 4 chars ≈ 1 token)
    total_chars = sum(
        len(m.content or "") + len(m.role.value) + 2  # ": "
        for m in snapshot.messages
    )
    return max(1, total_chars // 4)


__all__ = [
    "retrieve_conversation_thread",
    "ThreadRetrievalConfig",
    "ConversationThread",
    "ThreadRetrievalMetrics",
]
