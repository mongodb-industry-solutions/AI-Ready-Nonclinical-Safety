"""
mongomem_worker - Background processor for memory embeddings and extractions.

Main entry points:
- MongoMemWorker: The main worker class
- enqueue_task: Add tasks to the distributed queue

Subpackages:
- queue/: Task queue (processor, operations, models)
- errors/: Exceptions and error classification
- streams/: Change stream watchers
- handlers/: Task handlers (embedding, learning, etc.)
- storage/: Database access layer
"""

from ..mongomem_core import EmbedderProtocol, LLMProtocol
from ..mongomem_core.observability import LoggingObservability, NoOpObservability
from ..mongomem_core.protocols import ObservabilityProtocol
from .circuit_breaker import (
    CircuitBreaker,
    CircuitBreakerOpen,
    CircuitState,
    clear_all_circuit_breakers,
    get_all_circuit_breakers,
    get_circuit_breaker,
    reset_circuit_breaker,
)
from .config import (
    ExtractionConfig,
    TaskTimeouts,
    WorkerConfig,
    WorkerSettings,
)
from .errors import (
    ConfigurationError,
    DatabaseError,
    DocumentMissingError,
    EmbedderConfigError,
    EmbeddingError,
    ErrorTaxonomy,
    ErrorType,
    HandlerNotFoundError,
    InvalidPayloadError,
    LeaseExpiredError,
    LLMError,
    RateLimitError,
    TimeoutError,
    TransientWorkerError,
    WorkerError,
    WorkerErrorSeverity,
    classify_error,
    classify_exception,
    wrap_handler_error,
)
from .handlers.base import TaskHandler
from .observability import WorkerObservability
from .queue import enqueue_task
from .storage.extraction_config import ExtractionConfigStore
from .worker import MongoMemWorker, ScalingMode

__all__ = [
    # Worker
    "MongoMemWorker",
    "ScalingMode",
    "TaskHandler",
    "WorkerConfig",
    "WorkerSettings",
    "ExtractionConfig",
    "TaskTimeouts",
    # Protocols (re-exported from core)
    "EmbedderProtocol",
    "LLMProtocol",
    # Circuit Breaker
    "CircuitBreaker",
    "CircuitBreakerOpen",
    "CircuitState",
    "get_circuit_breaker",
    "reset_circuit_breaker",
    "get_all_circuit_breakers",
    "clear_all_circuit_breakers",
    # Observability
    "ObservabilityProtocol",
    "LoggingObservability",
    "NoOpObservability",
    "WorkerObservability",
    # Task Queue
    "enqueue_task",
    # Extraction Configuration
    "ExtractionConfigStore",
    # Error Classification
    "ErrorType",
    "ErrorTaxonomy",
    "classify_error",
    # Exceptions
    "WorkerError",
    "WorkerErrorSeverity",
    "ConfigurationError",
    "EmbedderConfigError",
    "HandlerNotFoundError",
    "InvalidPayloadError",
    "DocumentMissingError",
    "TransientWorkerError",
    "EmbeddingError",
    "LLMError",
    "RateLimitError",
    "TimeoutError",
    "DatabaseError",
    "LeaseExpiredError",
    "classify_exception",
    "wrap_handler_error",
]
