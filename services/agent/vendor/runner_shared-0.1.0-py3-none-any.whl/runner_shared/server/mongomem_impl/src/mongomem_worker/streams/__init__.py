"""
Change stream watchers for push-based notifications.

Provides efficient, non-polling detection of new documents
that need processing (embeddings, etc.).
"""

from .change_streams import (
    AsyncChangeStreamWatcher,
    ChangeHandler,
    ChangeNotifier,
    MemoryChangeStreamManager,
)

__all__ = [
    "AsyncChangeStreamWatcher",
    "ChangeHandler",
    "ChangeNotifier",
    "MemoryChangeStreamManager",
]
