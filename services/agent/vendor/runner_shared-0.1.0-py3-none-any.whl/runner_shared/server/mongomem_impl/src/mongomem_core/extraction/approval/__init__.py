"""
Extraction approval workflow.

Provides approval/rejection workflow for memory extractions with:
- PendingStore: CRUD for pending extractions
- ApprovalOrchestrator: Business logic for approve/reject/unpublish
- Tagged union types for different extraction payloads
"""

from mongomem_core.extraction.approval.orchestrator import (
    ApprovalOrchestrator,
    EmbedderRequiredError,
)
from mongomem_core.extraction.approval.store import (
    DEFAULT_AUDIT_RETENTION_DAYS,
    DEFAULT_PENDING_TTL_HOURS,
    PendingStore,
)
from mongomem_core.extraction.approval.types import (
    ApprovalResult,
    BatchApprovalResult,
    ExtractionType,
    PendingDecisionPayload,
    PendingExtraction,
    PendingMemoryRefPayload,
    PendingPayload,
    PendingPreferencesPayload,
    PendingStatus,
    from_mongo_doc,
    to_mongo_doc,
)

__all__ = [
    # Orchestrator
    "ApprovalOrchestrator",
    "EmbedderRequiredError",
    # Store
    "DEFAULT_AUDIT_RETENTION_DAYS",
    "DEFAULT_PENDING_TTL_HOURS",
    "PendingStore",
    # Types
    "ApprovalResult",
    "BatchApprovalResult",
    "ExtractionType",
    "PendingDecisionPayload",
    "PendingExtraction",
    "PendingMemoryRefPayload",
    "PendingPayload",
    "PendingPreferencesPayload",
    "PendingStatus",
    "from_mongo_doc",
    "to_mongo_doc",
]
