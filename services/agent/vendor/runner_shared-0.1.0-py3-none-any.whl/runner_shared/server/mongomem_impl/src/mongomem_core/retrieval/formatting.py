"""Formatting of retrieval results into context blocks."""

from __future__ import annotations

import logging
from collections import defaultdict
from typing import Any, Dict, List, Optional, Union
from xml.sax.saxutils import escape as xml_escape

from jinja2 import Template
from mongomem_core.common.token_counting import (
    TokenCounter,
    get_token_counter,
    resolve_format_style,
    resolve_model_name,
)
from mongomem_core.models.memory.user_prefs import UserContextMemoryOut
from mongomem_core.models.retrieval import (
    ContextConfig,
    ContextMetadata,
    ContextResponse,
    FormatStyle,
    MemoryChunk,
)
from mongomem_core.protocols import LLMProtocol

logger = logging.getLogger(__name__)


JINJA2_CONTEXT_TEMPLATE = """\
## Relevant Context
{% if user_preferences %}

### User Preferences
{{ user_preferences }}
{% endif %}
{% for source_name, memories in grouped_memories.items() %}

### {{ source_display_names.get(source_name, source_name.replace('_', ' ').title()) }}
{% for memory in memories %}
- {{ memory.content }}
{% endfor %}
{% endfor %}
"""

SOURCE_DISPLAY_NAMES: Dict[str, str] = {
    "stm": "Short-Term Memory",
    "episodic": "Episodic Memory",
    "semantic": "Semantic Memory",
    "taxonomic": "Taxonomic Memory",
    "procedural": "Procedural Memory",
}


class Formatter:
    """
    Formatter for context blocks.

    Formats retrieved memories into context strings or message lists suitable
    for LLM consumption. Supports multiple format styles (OpenAI, Claude, Jinja2)
    and uses shared TokenCounter for model-specific token counting.
    """

    def __init__(self, token_counter: Optional[TokenCounter] = None) -> None:
        """
        Initialize Formatter.

        Args:
            token_counter: Optional TokenCounter instance. If not provided,
                uses the shared singleton for cache efficiency.
        """
        self._token_counter = token_counter or get_token_counter()

    def format_context(
        self,
        memories: List[MemoryChunk],
        config: ContextConfig,
        user_context: Optional["UserContextMemoryOut"] = None,
        llm: Optional[LLMProtocol] = None,
    ) -> ContextResponse:
        """
        Format memories into context for LLM consumption.

        The format style is automatically determined based on the LLM being used:
        - Claude models → Claude XML format
        - OpenAI/GPT models → OpenAI message list format
        - Gemini models → OpenAI-compatible format

        Priority for format style resolution:
        1. Infer from llm.model_id (if LLM provided)
        2. Infer from config.model_type
        3. Fall back to config.format_style

        Args:
            memories: List of memory chunks to format
            config: ContextConfig with format_style and model_type
            user_context: Optional user context for personalization
            llm: Optional LLMProtocol instance (from engine.llm) for model-specific
                 token counting AND format style detection

        Returns:
            ContextResponse with formatted context and metadata

        Raises:
            ValueError: If format_style is invalid or model name cannot be determined
        """
        format_style = resolve_format_style(llm, config)

        logger.debug(
            "Formatting %d memories with style=%s",
            len(memories),
            format_style.value if hasattr(format_style, "value") else format_style,
        )

        # Format the context based on resolved style
        formatted_context: Union[str, List[Dict[str, Any]]]
        if format_style == FormatStyle.OPENAI:
            formatted_context = self._format_openai(memories, user_context)
        elif format_style == FormatStyle.CLAUDE:
            formatted_context = self._format_claude(memories, user_context)
        elif format_style == FormatStyle.JINJA2:
            formatted_context = self._format_jinja2(memories, user_context)
        else:
            logger.warning(
                "Unknown format_style=%s, defaulting to Jinja2 format",
                format_style,
            )
            formatted_context = self._format_jinja2(memories, user_context)

        # Count tokens using shared TokenCounter
        model_name = resolve_model_name(llm, config)
        token_count = self._token_counter.count_formatted(formatted_context, model_name)

        # Build metadata
        metadata = ContextMetadata(token_count=token_count)
        for memory in memories:
            metadata.increment_memory_count(memory.source)

        logger.info(
            "Formatted context: style=%s, tokens=%d, memories=%d",
            format_style.value if hasattr(format_style, "value") else format_style,
            token_count,
            len(memories),
        )

        return ContextResponse(
            formatted_context=formatted_context,
            metadata=metadata,
            selected_memories=memories if config.include_memories else None,
        )

    def _format_openai(
        self,
        memories: List[MemoryChunk],
        user_context: Optional["UserContextMemoryOut"],
    ) -> List[Dict[str, Any]]:
        """
        Format memories as OpenAI message list.

        Each memory becomes a separate system message for granular control.

        Returns:
            List of message dicts with "role" and "content" keys
        """
        messages: List[Dict[str, Any]] = []

        # Add system message with user preferences if available
        if user_context:
            system_content = self._build_user_preferences_system_message(user_context)
            if system_content:
                messages.append({"role": "system", "content": system_content})

        # Add each memory block as a separate system message
        for memory in memories:
            if memory.content:
                messages.append({"role": "system", "content": memory.content})

        return messages

    def _format_claude(
        self,
        memories: List[MemoryChunk],
        user_context: Optional["UserContextMemoryOut"],
    ) -> str:
        """
        Format memories as Claude XML string.

        Returns:
            XML string with <memory> tags
        """
        parts: List[str] = []

        # Add user preferences if available
        if user_context:
            prefs = self._build_user_preferences_system_message(user_context)
            if prefs:
                parts.append(f"<user_preferences>{xml_escape(prefs)}</user_preferences>")

        # Add memory blocks
        for memory in memories:
            if memory.content:
                timestamp_attr = (
                    f' timestamp="{memory.timestamp.isoformat()}"' if memory.timestamp else ""
                )
                source_value = (
                    memory.source.value if hasattr(memory.source, "value") else memory.source
                )
                source_attr = f' source="{source_value}"'
                escaped_content = xml_escape(memory.content)
                parts.append(f"<memory{source_attr}{timestamp_attr}>{escaped_content}</memory>")

        return "\n".join(parts)

    def _format_jinja2(
        self,
        memories: List[MemoryChunk],
        user_context: Optional["UserContextMemoryOut"],
    ) -> str:
        """
        Format memories using Jinja2 template.

        Groups memories by source type and renders them with a structured
        markdown template. Includes user preferences if provided.

        Args:
            memories: List of memory chunks to format
            user_context: Optional user context for personalization

        Returns:
            Rendered template string with grouped memories
        """
        # Group memories by source
        grouped_memories: Dict[str, List[MemoryChunk]] = defaultdict(list)
        for memory in memories:
            source_key = (
                memory.source.value if hasattr(memory.source, "value") else str(memory.source)
            )
            if memory.content:
                grouped_memories[source_key].append(memory)

        # Build user preferences string if provided
        user_preferences = None
        if user_context:
            user_preferences = self._build_user_preferences_system_message(user_context)

        if not grouped_memories and not user_preferences:
            return ""

        # Render template
        template = Template(JINJA2_CONTEXT_TEMPLATE)
        rendered = template.render(
            grouped_memories=dict(grouped_memories),
            source_display_names=SOURCE_DISPLAY_NAMES,
            user_preferences=user_preferences,
        )

        return rendered.strip()

    def _build_user_preferences_system_message(self, user_context: "UserContextMemoryOut") -> str:
        """Build system message with user preferences."""
        parts: List[str] = []
        if user_context.tone:
            parts.append(f"Tone: {user_context.tone}")
        if user_context.style:
            parts.append(f"Style: {user_context.style}")
        if user_context.language:
            parts.append(f"Language: {user_context.language}")
        if user_context.preferred_format:
            parts.append(f"Preferred format: {user_context.preferred_format}")
        return "\n".join(parts) if parts else ""
