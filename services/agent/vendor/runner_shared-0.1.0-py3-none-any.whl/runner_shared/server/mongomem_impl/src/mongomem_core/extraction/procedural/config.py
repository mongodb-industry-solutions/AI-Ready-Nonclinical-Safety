"""
Configuration for procedural extraction pipeline.

Procedures are multi-step instructions extracted from conversations.
They require higher confidence than semantic facts since they represent
executable knowledge.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ProceduralExtractionConfig:
    """Full config for procedural extraction with safe defaults.

    Procedures are complex, multi-step instructions. They need higher
    precision than semantic facts because incorrect procedures can
    cause real harm when executed.

    Frozen for immutability and hashability.
    """

    enabled: bool = True

    # Scoring weights and thresholds (procedures need high confidence)
    min_combined_score_threshold: float = 0.6
    citation_weight: float = 0.4
    confidence_weight: float = 0.6

    # Consolidation settings (procedure names are the dedup key)
    consolidation_top_k: int = 3
    consolidation_similarity_threshold: float = 0.80
    reinforcement_history_limit: int = 20

    # Limits
    max_procedures_per_snapshot: int = 5

    # Observability / sampling
    max_sample_extractions: int = 3
    sample_text_truncate_length: int = 100


__all__ = ["ProceduralExtractionConfig"]
