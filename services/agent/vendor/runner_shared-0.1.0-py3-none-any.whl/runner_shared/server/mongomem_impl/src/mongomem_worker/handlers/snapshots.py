"""
Snapshot handler for worker-based processing.

Handles:
- Auto-promotion based on thresholds (when strategy="auto")
- Embedding generation for deferred snapshots
- Time-based (stale session) promotion
- Snapshot embedding for cross-session retrieval

Design Principles:
- write_turn stays fast - auto-promotion happens here in the worker
- Supports both sync and async embedding strategies
- Platform-ready - OE can trigger explicit tasks
"""

from __future__ import annotations

import asyncio
import logging
from concurrent.futures import ThreadPoolExecutor
from typing import TYPE_CHECKING, Any, Callable, Dict, Optional

from pymongo import ASCENDING
from pymongo.database import Database

from ..constants import (
    DEFAULT_EMBED_THREAD_POOL_SIZE,
)
from ..storage import get_snapshot_collection, get_stm_collection
from .base import TaskHandler

if TYPE_CHECKING:
    from ...mongomem_core.models.config.snapshot_config import SnapshotConfig
    from ...mongomem_core.protocols import EmbedderProtocol
    from .embeddings import EmbeddingHandler

logger = logging.getLogger(__name__)


class SnapshotHandler(TaskHandler):
    """
    Handler for snapshot processing.

    Handles:
    - Auto-promotion based on thresholds (check_promotion task)
    - Embedding generation for deferred snapshots
    - Time-based (stale session) promotion
    - Snapshot embedding for cross-session retrieval

    Uses a dedicated thread pool for embedding operations to avoid
    blocking the event loop.
    """

    task_type = "snapshot"
    timeout_seconds = 300

    # Default batch size for process_pending
    DEFAULT_BATCH_SIZE = 10

    def __init__(
        self,
        db: Database,
        embedder: "EmbedderProtocol",
        config: Optional["SnapshotConfig"] = None,
        embed_thread_pool_size: int = DEFAULT_EMBED_THREAD_POOL_SIZE,
        batch_size: int = DEFAULT_BATCH_SIZE,
        on_snapshot_created: Optional[Callable[[Dict[str, Any]], None]] = None,
        embedding_handler: Optional["EmbeddingHandler"] = None,
    ) -> None:
        """
        Initialize SnapshotHandler.

        Args:
            db: MongoDB database instance
            embedder: Embedder for generating embeddings
            config: Optional snapshot configuration (uses defaults if not provided)
            embed_thread_pool_size: Size of thread pool for embedding ops
            batch_size: Batch size for processing pending items
            on_snapshot_created: Optional callback invoked with the snapshot dict after
                a successful promotion. Used to enqueue downstream extraction tasks.
            embedding_handler: Optional EmbeddingHandler used to batch-embed unembedded
                STM docs before evaluating promotion thresholds in _check_and_promote.
        """
        self._db = db
        self._embedder = embedder
        self._embedding_handler = embedding_handler
        self._snapshot_col = get_snapshot_collection(db)
        self._stm_col = get_stm_collection(db)

        # Load config
        if config is None:
            from ...mongomem_core.models.config.snapshot_config import SnapshotConfig

            config = SnapshotConfig()
        self._config = config

        self._on_snapshot_created = on_snapshot_created

        # Dedicated thread pool for embedding operations
        self._embed_executor: Optional[ThreadPoolExecutor] = None
        self._embed_thread_pool_size = embed_thread_pool_size
        self._batch_size = batch_size

    def _get_executor(self) -> ThreadPoolExecutor:
        """Get or create the dedicated thread pool for embedding operations."""
        if self._embed_executor is None:
            self._embed_executor = ThreadPoolExecutor(
                max_workers=self._embed_thread_pool_size,
                thread_name_prefix="snapshot_embed",
            )
        return self._embed_executor

    def shutdown(self) -> None:
        """Shutdown the embedding thread pool."""
        if self._embed_executor is not None:
            self._embed_executor.shutdown(wait=True)
            self._embed_executor = None

    async def handle_task(self, payload: Dict[str, Any]) -> None:
        """
        Handle a snapshot processing task.

        Task types:
        - embed: Generate embedding for a snapshot
        - check_promotion: Check if session needs promotion and promote if so
        - embed_deferred: Process snapshots with deferred embedding strategy
        - summarize: Generate a summary for a snapshot (requires LLM)
        """
        task_type = payload.get("task_type") or payload.get("snapshot_task_type", "embed")

        if task_type == "embed":
            await self._embed_snapshot(payload)
        elif task_type == "check_promotion":
            await self._check_and_promote(payload)
        elif task_type == "embed_deferred":
            await self._embed_deferred_snapshots()
        elif task_type == "summarize":
            await self._summarize_snapshot(payload)
        else:
            logger.warning("Unknown snapshot task type: %s", task_type)

    async def _embed_snapshot(self, payload: Dict[str, Any]) -> None:
        """Generate embedding for a snapshot."""
        snapshot_id = payload.get("snapshot_id")
        org_id = payload.get("org_id")

        if not snapshot_id:
            raise ValueError("Missing snapshot_id in embed task payload")

        snapshot = self._snapshot_col.find_one({"_id": snapshot_id, "org_id": org_id})
        if not snapshot:
            logger.warning("Snapshot not found: %s", snapshot_id)
            return

        # Skip if already embedded
        if snapshot.get("has_embedding"):
            logger.debug("Snapshot %s already has embedding, skipping", snapshot_id)
            return

        # Build text for embedding from messages
        messages = snapshot.get("messages", [])
        text_parts = [
            f"{msg.get('role', 'unknown')}: {msg.get('content', '')}"
            for msg in messages
            if msg.get("content")
        ]
        combined_text = "\n".join(text_parts)

        if not combined_text.strip():
            logger.debug("Skipping empty snapshot %s", snapshot_id)
            return

        # Use run_in_executor to avoid blocking the event loop
        loop = asyncio.get_running_loop()
        executor = self._get_executor()
        embedding = await loop.run_in_executor(executor, self._embedder.embed, combined_text)

        self._snapshot_col.update_one(
            {"_id": snapshot_id},
            {
                "$set": {
                    "embedding": embedding,
                    "has_embedding": True,
                    "embedding_model_id": self._embedder.model_id,
                    "embedding_dimension": len(embedding),
                    "embedding_strategy": "generate",
                }
            },
        )

        logger.info(
            "Embedded snapshot %s (messages=%d, dim=%d)",
            snapshot_id,
            len(messages),
            len(embedding),
        )

    async def _check_and_promote(self, payload: Dict[str, Any]) -> None:
        """
        Check thresholds and promote if needed.

        This is triggered by change stream on STM collection.
        """
        session_id = payload.get("session_id")
        org_id = payload.get("org_id")
        user_id = payload.get("user_id")
        project_id = payload.get(
            "project_id"
        )  # kept as-is; None and "" are both valid absent-project signals

        if not session_id or not org_id:
            logger.warning("Missing session_id or org_id in check_promotion payload")
            return

        # Type narrow after validation
        session_id = str(session_id)
        org_id = str(org_id)

        # Skip if auto-promotion is disabled
        if not self._config.is_auto_promotion_enabled():
            logger.debug("Auto-promotion disabled, skipping check for session=%s", session_id)
            return

        # Import here to avoid circular imports
        from ...mongomem_core.memory.short_term import get_stm_raw_docs
        from ...mongomem_core.pipelines.stm_to_snapshot import (
            promote_stm_to_snapshot,
            should_promote,
        )

        # Fetch only unpromoted STM docs scoped to {org, session, user, project}.
        stm_docs = get_stm_raw_docs(
            self._db,
            session_id,
            org_id,
            user_id=user_id,
            project_id=project_id,
            exclude_promoted=True,
        )

        if not stm_docs:
            return

        from ...mongomem_core.pipelines.stm_to_snapshot import _reason_to_snapshot_reason

        # Resolve user_id early so embed_stm_docs_for_session can scope correctly.
        if not user_id:
            user_id = stm_docs[0].get("user_id")
        # Resolve project_id from docs if absent from payload (change-stream path).
        if project_id is None:
            project_id = stm_docs[0].get("project_id")

        # Batch-embed any unembedded STM docs before evaluating thresholds so that
        # topic-shift detection has embeddings available. No atomic claiming is needed
        # here because the task queue guarantees at-most-one active check_promotion
        # task per {org_id, session_id, user_id, project_id}.
        if self._embedding_handler is not None and user_id:
            try:
                embedded_count = await self._embedding_handler.embed_stm_docs_for_session(
                    session_id=session_id,
                    org_id=org_id,
                    user_id=str(user_id),
                    project_id=project_id,
                )
            except Exception as exc:
                logger.warning(
                    "STM batch embedding failed for session=%s, proceeding with existing embeddings: %s",
                    session_id,
                    exc,
                )
                embedded_count = 0

            if embedded_count > 0:
                # Re-fetch so stm_docs carries the fresh embeddings.
                stm_docs = get_stm_raw_docs(
                    self._db,
                    session_id,
                    org_id,
                    user_id=user_id,
                    project_id=project_id,
                    exclude_promoted=True,
                )
                if not stm_docs:
                    return

        oe_reason = payload.get("reason")

        # "idle_session" is a time-based trigger decided by the OE trust it
        # unconditionally. All other reasons (message_count, topic_shift, etc.)
        # are evaluated locally so the decision is based on current STM state with
        # fresh embeddings.
        if oe_reason == "idle_session":
            logger.debug(
                "OE-triggered idle promotion for session=%s — skipping local threshold checks",
                session_id,
            )
            snapshot_reason = _reason_to_snapshot_reason(oe_reason)
        else:
            if oe_reason:
                logger.debug(
                    "OE-triggered promotion for session=%s oe_reason=%s — evaluating thresholds locally",
                    session_id,
                    oe_reason,
                )
            should, local_reason = should_promote(stm_docs, self._config, embedder=self._embedder)
            if not should:
                logger.debug(
                    "Session %s does not meet snapshot threshold (count=%d)",
                    session_id,
                    len(stm_docs),
                )
                return
            snapshot_reason = _reason_to_snapshot_reason(local_reason)

        if not user_id:
            logger.error("Cannot determine user_id for promotion: session=%s", session_id)
            return

        # This is either an idle_session or has passed should_promote checks
        snapshot = promote_stm_to_snapshot(
            db=self._db,
            session_id=session_id,
            org_id=org_id,
            user_id=user_id,
            project_id=project_id,
            stm_docs=stm_docs,
            config=self._config,
            embedder=self._embedder,
            force=True,
            reason_override=snapshot_reason,
            delete_promoted=self._config.delete_promoted,
        )

        if snapshot:
            logger.info(
                "Auto-promoted session %s to snapshot %s (reason=%s, messages=%d)",
                session_id,
                snapshot.id,
                snapshot_reason,
                len(snapshot.messages),
            )
            if self._on_snapshot_created:
                try:
                    self._on_snapshot_created(snapshot.model_dump(mode="python", by_alias=True))
                except Exception as exc:
                    logger.error(
                        "Failed to enqueue extraction tasks for snapshot %s: %s",
                        snapshot.id,
                        exc,
                    )

    async def _embed_deferred_snapshots(self) -> None:
        """Generate embeddings for snapshots created with embedding_strategy='defer'."""
        processed = await self.process_deferred_embeddings()
        logger.info("Processed %d deferred snapshot embeddings", processed)

    async def _summarize_snapshot(self, payload: Dict[str, Any]) -> None:
        """Generate a summary for a snapshot (requires LLM).

        TODO: Import and use mongomem_core summarization once implemented.
        """
        logger.debug("Snapshot summarization not yet implemented")

    async def process_pending(self) -> int:
        """
        Process snapshots that need embedding.

        This is the main batch processing method for snapshots without embeddings.
        """
        docs = list(
            self._snapshot_col.find(
                {
                    "has_embedding": False,
                    "messages": {"$exists": True, "$ne": []},
                    "deleted": {"$ne": True},
                }
            )
            .sort("timestamp", ASCENDING)
            .limit(self._batch_size)
        )

        processed = 0
        for doc in docs:
            try:
                await self._embed_snapshot(
                    {
                        "snapshot_id": doc["_id"],
                        "org_id": doc.get("org_id"),
                    }
                )
                processed += 1
            except Exception as exc:
                logger.error("Failed to embed snapshot %s: %s", doc["_id"], exc)

        return processed

    async def process_deferred_embeddings(self) -> int:
        """
        Generate embeddings for snapshots with embedding_strategy='defer'.

        These are snapshots that were created quickly without embedding,
        and now need embedding generated asynchronously.
        """
        docs = list(
            self._snapshot_col.find(
                {
                    "has_embedding": False,
                    "embedding_strategy": "defer",
                    "deleted": {"$ne": True},
                }
            )
            .sort("timestamp", ASCENDING)
            .limit(self._batch_size)
        )

        processed = 0
        for doc in docs:
            try:
                await self._embed_snapshot(
                    {
                        "snapshot_id": doc["_id"],
                        "org_id": doc.get("org_id"),
                    }
                )
                processed += 1
            except Exception as exc:
                logger.error("Failed to embed deferred snapshot %s: %s", doc["_id"], exc)

        return processed


__all__ = ["SnapshotHandler"]
