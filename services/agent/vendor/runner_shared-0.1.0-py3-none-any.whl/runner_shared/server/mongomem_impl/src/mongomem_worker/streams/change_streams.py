"""
Change stream watchers for memory collections.

Provides push-based notifications when documents need processing,
reducing polling overhead in single-worker mode.
"""

from __future__ import annotations

import asyncio
import logging
import threading
from typing import Any, Callable, Dict, List, Optional, Protocol

from pymongo.database import Database

from ..constants import (
    CORE_EPISODIC_COLLECTION,
    CORE_SEMANTIC_COLLECTION,
    CORE_SNAPSHOT_COLLECTION,
    CORE_STM_COLLECTION,
    CORE_TAXONOMIC_COLLECTION,
)
from ..storage.cache import get_collection
from ..storage.resume_tokens import ResumeTokenStore

logger = logging.getLogger(__name__)

ChangeHandler = Callable[[Dict[str, Any]], None]
AsyncChangeHandler = Callable[[Dict[str, Any]], Any]  # Returns Coroutine


class ChangeNotifier(Protocol):
    """Protocol for change stream notification callbacks."""

    def __call__(self) -> None:
        """Called when a change is detected."""
        ...


class ChangeStreamWatcher:
    """
    Watches MongoDB change streams for memory-related events.

    Triggers handlers when new documents are inserted or updated
    that require processing (embedding, extraction, etc.).

    This is the synchronous (blocking) version for standalone usage.
    For async integration, use AsyncChangeStreamWatcher.
    """

    def __init__(
        self,
        db: Database,
        collection_name: str,
        stream_name: str,
        resume_store: Optional[ResumeTokenStore] = None,
    ) -> None:
        self._db = db
        self._collection = get_collection(db, collection_name)
        self._stream_name = stream_name
        self._resume_store = resume_store or ResumeTokenStore(db)
        self._handlers: List[ChangeHandler] = []
        self._running = False

    def add_handler(self, handler: ChangeHandler) -> None:
        """Add a handler to be called for each change event."""
        self._handlers.append(handler)

    def start(self) -> None:
        """Start watching the change stream (blocking)."""
        resume_token = self._resume_store.get_token(self._stream_name)

        pipeline = [{"$match": {"operationType": {"$in": ["insert", "update"]}}}]

        logger.info(
            "Starting change stream watcher for %s (resume=%s)",
            self._stream_name,
            "yes" if resume_token else "no",
        )

        self._running = True

        try:
            with self._collection.watch(
                pipeline=pipeline,
                resume_after=resume_token,
                full_document="updateLookup",
            ) as stream:
                for change in stream:
                    if not self._running:
                        break

                    self._process_change(change)
                    if stream.resume_token:
                        self._resume_store.save_token(
                            self._stream_name,
                            dict(stream.resume_token),
                        )
        except Exception as exc:
            logger.exception("Change stream error: %s", exc)
            raise
        finally:
            self._running = False

    def stop(self) -> None:
        """Signal the watcher to stop."""
        self._running = False

    def _process_change(self, change: Dict[str, Any]) -> None:
        """Process a single change event."""
        operation = change.get("operationType")
        doc = change.get("fullDocument")

        if not doc:
            logger.debug("Skipping change without full document")
            return

        logger.debug(
            "Processing %s on %s: %s",
            operation,
            self._stream_name,
            change.get("documentKey", {}).get("_id"),
        )

        for handler in self._handlers:
            try:
                handler(change)
            except Exception as exc:
                logger.error("Handler error: %s", exc)


class AsyncChangeStreamWatcher:
    """
    Async-compatible change stream watcher for integration with asyncio workers.

    Runs the blocking MongoDB change stream in a background thread and
    notifies the async event loop when changes are detected.

    This follows ExoMemory's ChangeStreamListener pattern but with cleaner
    async integration.
    """

    def __init__(
        self,
        db: Database,
        collection_name: str,
        stream_name: str,
        resume_store: Optional[ResumeTokenStore] = None,
    ) -> None:
        self._db = db
        self._collection = get_collection(db, collection_name)
        self._stream_name = stream_name
        self._resume_store = resume_store or ResumeTokenStore(db)

        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._on_change: Optional[ChangeNotifier] = None

        # Filter for documents that need processing
        self._filter: Optional[Dict[str, Any]] = None

    def set_filter(self, doc_filter: Dict[str, Any]) -> None:
        """
        Set a filter for documents to watch.

        Example:
            watcher.set_filter({"has_embedding": False})
        """
        self._filter = doc_filter

    async def start(self, on_change: Optional[ChangeNotifier] = None) -> bool:
        """
        Start watching in a background thread.

        Args:
            on_change: Callback invoked when a relevant change is detected.
                       Use this to wake up your processing loop.

        Returns:
            True if change streams are available, False otherwise.
        """
        if self._running:
            logger.warning("Change stream watcher already running")
            return True

        self._on_change = on_change
        self._loop = asyncio.get_running_loop()

        # Test if change streams are available (requires replica set)
        if not self._test_change_stream_available():
            logger.warning(
                "Change streams unavailable for %s (requires replica set)",
                self._stream_name,
            )
            return False

        self._running = True
        self._thread = threading.Thread(
            target=self._watch_loop,
            name=f"ChangeStream-{self._stream_name}",
            daemon=True,
        )
        self._thread.start()

        logger.info("Started async change stream watcher for %s", self._stream_name)
        return True

    def stop(self) -> None:
        """Signal the watcher to stop."""
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)

    def _test_change_stream_available(self) -> bool:
        """Test if change streams are supported (requires replica set)."""
        try:
            # Quick test with a short timeout
            with self._collection.watch(max_await_time_ms=100) as stream:
                # Try to get the first event (will timeout if no events)
                try:
                    stream.try_next()
                except StopIteration:
                    pass
            return True
        except Exception as exc:
            # "The $changeStream stage is only supported on replica sets"
            logger.debug("Change stream test failed: %s", exc)
            return False

    def _watch_loop(self) -> None:
        """Background thread: watch the change stream and notify the async loop."""
        resume_token = self._resume_store.get_token(self._stream_name)

        # Build pipeline with optional filter
        match_stage: Dict[str, Any] = {"operationType": {"$in": ["insert", "update"]}}
        if self._filter:
            # Apply filter to full document
            for key, value in self._filter.items():
                match_stage[f"fullDocument.{key}"] = value

        pipeline = [{"$match": match_stage}]

        logger.debug(
            "Change stream %s starting with pipeline: %s",
            self._stream_name,
            pipeline,
        )

        try:
            with self._collection.watch(
                pipeline=pipeline,
                resume_after=resume_token,
                full_document="updateLookup",
                max_await_time_ms=1000,  # Check for shutdown every second
            ) as stream:
                while self._running:
                    change = stream.try_next()
                    if change:
                        self._handle_change(change, stream.resume_token)
        except Exception as exc:
            if self._running:  # Only log if not shutting down
                logger.error("Change stream %s error: %s", self._stream_name, exc)
        finally:
            logger.debug("Change stream %s stopped", self._stream_name)

    def _handle_change(self, change: Dict[str, Any], resume_token: Any) -> None:
        """Handle a change event and notify the async loop."""
        doc = change.get("fullDocument")
        if not doc:
            return

        # Save resume token
        self._resume_store.save_token(self._stream_name, resume_token)

        doc_id = change.get("documentKey", {}).get("_id")
        logger.debug(
            "Change detected on %s: %s (%s)",
            self._stream_name,
            doc_id,
            change.get("operationType"),
        )

        # Notify the async loop
        if self._on_change and self._loop:
            self._loop.call_soon_threadsafe(self._on_change)


class _SnapshotExtractionWatcher(AsyncChangeStreamWatcher):
    """
    Specialized watcher that triggers extraction for new snapshots.

    Unlike the general async watcher, this one:
    - Only watches for INSERT operations (not updates)
    - Calls a custom handler with the full document
    - Does NOT filter by has_embedding (we want all new snapshots)
    """

    def __init__(
        self,
        db: Database,
        collection_name: str,
        stream_name: str,
        resume_store: Optional[ResumeTokenStore],
        on_snapshot_created: Callable[[Dict[str, Any]], None],
    ) -> None:
        super().__init__(db, collection_name, stream_name, resume_store)
        self._on_snapshot_created = on_snapshot_created

    def _watch_loop(self) -> None:
        """Background thread: watch for INSERT operations and call handler."""
        resume_token = self._resume_store.get_token(self._stream_name)

        # Only watch for INSERT operations
        pipeline = [{"$match": {"operationType": "insert"}}]

        logger.debug(
            "Snapshot extraction watcher %s starting (insert only)",
            self._stream_name,
        )

        try:
            with self._collection.watch(
                pipeline=pipeline,
                resume_after=resume_token,
                full_document="updateLookup",
                max_await_time_ms=1000,
            ) as stream:
                while self._running:
                    change = stream.try_next()
                    if change:
                        self._handle_insert(change, stream.resume_token)
        except Exception as exc:
            if self._running:
                logger.error("Snapshot extraction watcher error: %s", exc)
        finally:
            logger.debug("Snapshot extraction watcher stopped")

    def _handle_insert(self, change: Dict[str, Any], resume_token: Any) -> None:
        """Handle new snapshot insert - trigger extraction."""
        doc = change.get("fullDocument")
        if not doc:
            return

        # Save resume token
        self._resume_store.save_token(self._stream_name, resume_token)

        doc_id = change.get("documentKey", {}).get("_id")
        logger.debug("New snapshot detected: %s - triggering extraction", doc_id)

        # Call the extraction trigger (runs in the watcher thread)
        try:
            self._on_snapshot_created(doc)
        except Exception as exc:
            logger.error("Extraction trigger error for %s: %s", doc_id, exc)


class MemoryChangeStreamManager:
    """
    Manages change stream watchers for all memory collections.

    Creates watchers for:
    - Short-term memory (triggers embedding)
    - Snapshots (triggers embedding + extraction)
    """

    def __init__(self, db: Database) -> None:
        self._db = db
        self._watchers: Dict[str, AsyncChangeStreamWatcher] = {}
        self._resume_store = ResumeTokenStore(db)
        self._change_available = asyncio.Event()

    @property
    def change_available(self) -> asyncio.Event:
        """Event that's set when any watcher detects a change."""
        return self._change_available

    def _notify_change(self) -> None:
        """Called by watchers when a change is detected."""
        self._change_available.set()

    def create_stm_watcher(self) -> AsyncChangeStreamWatcher:
        """Create a watcher for short-term memory changes."""
        watcher = AsyncChangeStreamWatcher(
            db=self._db,
            collection_name=CORE_STM_COLLECTION,
            stream_name="stm_changes",
            resume_store=self._resume_store,
        )
        # Watch for documents without embeddings
        watcher.set_filter({"has_embedding": False})
        self._watchers["stm"] = watcher
        return watcher

    def create_snapshot_watcher(self) -> AsyncChangeStreamWatcher:
        """Create a watcher for snapshot changes."""
        watcher = AsyncChangeStreamWatcher(
            db=self._db,
            collection_name=CORE_SNAPSHOT_COLLECTION,
            stream_name="snapshot_changes",
            resume_store=self._resume_store,
        )
        # Watch for documents without embeddings
        watcher.set_filter({"has_embedding": False})
        self._watchers["snapshot"] = watcher
        return watcher

    def create_snapshot_extraction_watcher(
        self,
        on_snapshot_created: Callable[[Dict[str, Any]], None],
    ) -> AsyncChangeStreamWatcher:
        """
        Create a watcher for new snapshots to trigger extraction.

        Unlike the embedding watcher, this one watches for ALL new inserts
        (not filtered by has_embedding) and calls the provided handler
        with the full snapshot document.

        Args:
            on_snapshot_created: Callback with (snapshot_doc) when new snapshot is inserted.
                                Use this to enqueue semantic extraction.
        """
        watcher = _SnapshotExtractionWatcher(
            db=self._db,
            collection_name=CORE_SNAPSHOT_COLLECTION,
            stream_name="snapshot_extraction_trigger",
            resume_store=self._resume_store,
            on_snapshot_created=on_snapshot_created,
        )
        self._watchers["snapshot_extraction"] = watcher
        return watcher

    def create_semantic_watcher(self) -> AsyncChangeStreamWatcher:
        """Create a watcher for semantic memory changes.

        Detects inserts (from extraction) or updates that need embedding.
        """
        watcher = AsyncChangeStreamWatcher(
            db=self._db,
            collection_name=CORE_SEMANTIC_COLLECTION,
            stream_name="semantic_changes",
            resume_store=self._resume_store,
        )
        # Watch for documents without embeddings
        watcher.set_filter({"has_embedding": False})
        self._watchers["semantic"] = watcher
        return watcher

    def create_episodic_watcher(self) -> AsyncChangeStreamWatcher:
        """Create a watcher for episodic memory changes.

        Detects inserts (from extraction) or updates that need embedding.
        """
        watcher = AsyncChangeStreamWatcher(
            db=self._db,
            collection_name=CORE_EPISODIC_COLLECTION,
            stream_name="episodic_changes",
            resume_store=self._resume_store,
        )
        # Watch for documents without embeddings
        watcher.set_filter({"has_embedding": False})
        self._watchers["episodic"] = watcher
        return watcher

    def create_taxonomic_watcher(self) -> AsyncChangeStreamWatcher:
        """Create a watcher for taxonomic memory changes (embedding trigger)."""
        watcher = AsyncChangeStreamWatcher(
            db=self._db,
            collection_name=CORE_TAXONOMIC_COLLECTION,
            stream_name="taxonomic_changes",
            resume_store=self._resume_store,
        )
        watcher.set_filter({"has_embedding": False})
        self._watchers["taxonomic"] = watcher
        return watcher

    def enable_embedding_triggers(
        self, on_embedding_payload: Callable[[Dict[str, Any]], None]
    ) -> None:
        """
        Enable doc-level embedding triggers.

        When change streams are available, this lets the worker embed the exact new document
        (instead of relying on collection scans). The callback runs on the worker event loop.
        """

        class _EmbeddingTriggerWatcher(AsyncChangeStreamWatcher):
            def __init__(
                self,
                db: Database,
                collection_name: str,
                stream_name: str,
                resume_store: Optional[ResumeTokenStore],
                payload_builder: Callable[[Dict[str, Any]], Optional[Dict[str, Any]]],
            ) -> None:
                super().__init__(db, collection_name, stream_name, resume_store)
                self._payload_builder = payload_builder

            def _handle_change(self, change: Dict[str, Any], resume_token: Any) -> None:
                doc = change.get("fullDocument")
                if not doc:
                    return
                self._resume_store.save_token(self._stream_name, resume_token)
                payload = self._payload_builder(doc)
                if payload and self._loop:
                    self._loop.call_soon_threadsafe(on_embedding_payload, payload)
                if self._on_change and self._loop:
                    self._loop.call_soon_threadsafe(self._on_change)

        def build_stm_payload(doc: Dict[str, Any]) -> Optional[Dict[str, Any]]:
            if doc.get("has_embedding") is True:
                return None
            content = doc.get("content")
            if not content:
                return None
            return {
                "collection": CORE_STM_COLLECTION,
                "doc_id": doc.get("_id"),
                "org_id": doc.get("org_id"),
                "content": content,
            }

        def build_semantic_payload(doc: Dict[str, Any]) -> Optional[Dict[str, Any]]:
            if doc.get("has_embedding") is True:
                return None
            content = doc.get("content") or doc.get("text")
            if not content:
                return None
            return {
                "collection": CORE_SEMANTIC_COLLECTION,
                "doc_id": doc.get("_id"),
                "org_id": doc.get("org_id"),
                "content": content,
            }

        def build_episodic_payload(doc: Dict[str, Any]) -> Optional[Dict[str, Any]]:
            if doc.get("has_embedding") is True:
                return None
            content = doc.get("summary_text") or doc.get("content")
            if not content:
                return None
            return {
                "collection": CORE_EPISODIC_COLLECTION,
                "doc_id": doc.get("_id"),
                "org_id": doc.get("org_id"),
                "content": content,
            }

        def build_taxonomic_payload(doc: Dict[str, Any]) -> Optional[Dict[str, Any]]:
            if doc.get("has_embedding") is True:
                return None
            term = (doc.get("term") or "").strip()
            definition = (doc.get("definition") or "").strip()
            if not term or not definition:
                return None
            return {
                "collection": CORE_TAXONOMIC_COLLECTION,
                "doc_id": doc.get("_id"),
                "org_id": doc.get("org_id"),
                "content": f"{term}: {definition}",
            }

        # Replace the generic watchers with trigger-capable ones (same filters).
        self._watchers["stm"] = _EmbeddingTriggerWatcher(
            self._db,
            CORE_STM_COLLECTION,
            "stm_changes",
            self._resume_store,
            build_stm_payload,
        )
        self._watchers["semantic"] = _EmbeddingTriggerWatcher(
            self._db,
            CORE_SEMANTIC_COLLECTION,
            "semantic_changes",
            self._resume_store,
            build_semantic_payload,
        )
        self._watchers["episodic"] = _EmbeddingTriggerWatcher(
            self._db,
            CORE_EPISODIC_COLLECTION,
            "episodic_changes",
            self._resume_store,
            build_episodic_payload,
        )
        self._watchers["taxonomic"] = _EmbeddingTriggerWatcher(
            self._db,
            CORE_TAXONOMIC_COLLECTION,
            "taxonomic_changes",
            self._resume_store,
            build_taxonomic_payload,
        )

    async def start_all(self) -> bool:
        """
        Start all watchers.

        Returns:
            True if at least one watcher started successfully.
        """
        # If embedding triggers were enabled, watchers may already be constructed.
        stm_watcher = self._watchers.get("stm") or self.create_stm_watcher()
        snapshot_watcher = self._watchers.get("snapshot") or self.create_snapshot_watcher()
        semantic_watcher = self._watchers.get("semantic") or self.create_semantic_watcher()
        episodic_watcher = self._watchers.get("episodic") or self.create_episodic_watcher()
        taxonomic_watcher = self._watchers.get("taxonomic") or self.create_taxonomic_watcher()

        stm_ok = await stm_watcher.start(on_change=self._notify_change)
        snapshot_ok = await snapshot_watcher.start(on_change=self._notify_change)
        semantic_ok = await semantic_watcher.start(on_change=self._notify_change)
        episodic_ok = await episodic_watcher.start(on_change=self._notify_change)
        taxonomic_ok = await taxonomic_watcher.start(on_change=self._notify_change)

        started_count = sum([stm_ok, snapshot_ok, semantic_ok, episodic_ok, taxonomic_ok])
        if started_count > 0:
            logger.info(
                "Started %d change stream watchers (stm=%s, snapshot=%s, semantic=%s, episodic=%s, taxonomic=%s)",
                started_count,
                stm_ok,
                snapshot_ok,
                semantic_ok,
                episodic_ok,
                taxonomic_ok,
            )

        return started_count > 0

    def stop_all(self) -> None:
        """Stop all watchers."""
        for watcher in self._watchers.values():
            watcher.stop()

    async def wait_for_change(self, timeout: Optional[float] = None) -> bool:
        """
        Wait for a change event from any watcher.

        Args:
            timeout: Maximum time to wait (None = forever)

        Returns:
            True if a change was detected, False if timeout.
        """
        try:
            await asyncio.wait_for(self._change_available.wait(), timeout=timeout)
            self._change_available.clear()
            return True
        except asyncio.TimeoutError:
            return False


__all__ = [
    "ChangeStreamWatcher",
    "AsyncChangeStreamWatcher",
    "MemoryChangeStreamManager",
    "ChangeHandler",
    "ChangeNotifier",
]
