"""
Taxonomic extraction persistence.

Provides idempotent database operations for taxonomic memory persistence.
Taxonomic uses domain+term as the natural dedup key, unlike semantic's content hash.
"""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from pymongo.database import Database


from mongomem_core.common.utils import safe_object_id, utcnow
from mongomem_core.extraction.config import TaxonomicExtractionConfig
from mongomem_core.extraction.types import (
    ConsolidationDecision,
    PersistenceResult,
)
from mongomem_core.extraction.utils import build_array_merge_stage, build_reinforce_pipeline
from mongomem_core.memory.taxonomic import (
    get_taxonomic,
    update_taxonomic,
    upsert_taxonomic,
)
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.taxonomic import (
    CreationMethod,
    TaxonomicIn,
    TaxonomicUpdate,
)
from mongomem_core.storage import get_collection
from mongomem_core.storage.collections import TaxonomicMemoryCollection

logger = logging.getLogger(__name__)


def generate_taxonomic_extraction_id(org_id: str, domain: str, term: str) -> str:
    """
    Generate a SHA-256 extraction ID from org+domain+term (natural dedup key).

    Args:
        org_id: Organization ID
        domain: Domain of the term
        term: The term itself

    Returns:
        SHA-256 hex digest for idempotency
    """
    normalized_term = term.lower().strip()
    normalized_domain = domain.lower().strip()
    key = f"{org_id}_{normalized_domain}_{normalized_term}"
    return hashlib.sha256(key.encode()).hexdigest()


def perform_taxonomic_add(
    db: "Database",
    decision: ConsolidationDecision,
    org_id: str,
    user_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    embedding_model_id: str,
    visibility: ChunkVisibility = ChunkVisibility.ORG,
    project_id: Optional[str] = None,
) -> Optional[str]:
    """
    Perform an ADD operation for a new taxonomic term.

    Uses atomic upsert_taxonomic() with $setOnInsert for race-safety.
    If a term with the same domain+term already exists, returns existing ID.

    Args:
        db: MongoDB database instance
        decision: Consolidation decision with ADD action
        org_id: Organization ID
        user_id: User ID
        source_id: Source reference (snapshot ID)
        extraction_timestamp: Timestamp of extraction
        embedding_model_id: ID of embedding model used

    Returns:
        Created document ID if successful, None otherwise
    """
    extraction = decision.extraction
    metadata = extraction.metadata or {}
    domain = metadata.get("domain", "")
    term = metadata.get("term", "")
    definition = metadata.get("definition", "")

    if not domain or not term or not definition:
        logger.warning("Missing required fields for taxonomic ADD: domain=%s term=%s", domain, term)
        return None

    extraction_id = generate_taxonomic_extraction_id(org_id, domain, term)

    # Build contextual_metadata with scoring info (like semantic)
    contextual_metadata = {
        "citation_score": extraction.citation_score,
        "llm_confidence_score": extraction.confidence,
        "combined_score": extraction.combined_score,
        "cited_text": extraction.cited_text,
        "reinforcement_sources": [],
    }

    # Create taxonomic input
    taxonomic_in = TaxonomicIn(
        domain=domain,
        term=term,
        definition=definition,
        related_terms=metadata.get("related_terms", []),
        query_expansion=True,
        visibility=visibility,
        project_id=project_id,
        creation_method=CreationMethod.LLM_EXTRACTION,
        source_reference=source_id,
        source_agent="agent_mediated",
        user_source=user_id,
        evidence_spans=metadata.get("evidence_spans", []),
        confidence_score=extraction.confidence,
        embedding=extraction.embedding,  # type: ignore[call-arg]
        contextual_metadata=contextual_metadata,
    )

    try:
        # Use atomic upsert - $setOnInsert ensures race-safety
        # If domain+term already exists, returns existing doc (no duplicate)
        doc = upsert_taxonomic(
            db=db,
            taxonomic_in=taxonomic_in,
            org_id=org_id,
            user_id=user_id,
            embedding=extraction.embedding,
            embedding_model_id=embedding_model_id,
            extraction_id=extraction_id,
        )
        logger.debug(
            "Upserted taxonomic term: id=%s domain=%s term=%s",
            doc.id,
            domain,
            term,
        )
        return str(doc.id)
    except Exception as e:
        logger.error(
            "Failed to upsert taxonomic term: domain=%s term=%s error=%s",
            domain,
            term,
            e,
            exc_info=True,
        )
        return None


def perform_taxonomic_update(
    db: "Database",
    decision: ConsolidationDecision,
    org_id: str,
    user_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    embedding_model_id: str,
    visibility: ChunkVisibility = ChunkVisibility.ORG,
    project_id: Optional[str] = None,
) -> Optional[str]:
    """
    Perform an UPDATE operation for an existing taxonomic term.

    Updates the definition and merges related_terms.

    Args:
        db: MongoDB database instance
        decision: Consolidation decision with UPDATE action
        org_id: Organization ID
        user_id: User ID
        source_id: Source reference (snapshot ID)
        extraction_timestamp: Timestamp of extraction
        embedding_model_id: ID of embedding model used

    Returns:
        Updated document ID if successful, None otherwise
    """
    if not decision.existing_id:
        logger.warning("UPDATE decision missing existing_id")
        return None

    extraction = decision.extraction
    metadata = extraction.metadata or {}
    definition = metadata.get("definition", "")
    new_related_terms = metadata.get("related_terms", [])

    # Get existing to merge related_terms
    existing = get_taxonomic(db, org_id, id=decision.existing_id)
    if not existing:
        logger.warning(
            "Existing taxonomic term not found for UPDATE: id=%s",
            decision.existing_id,
        )
        return None

    # Merge related_terms (additive)
    merged_related_terms = list(set(existing.related_terms or []) | set(new_related_terms))

    update_data = TaxonomicUpdate(
        definition=definition,
        related_terms=merged_related_terms,
        evidence_spans=metadata.get("evidence_spans", []),
        confidence_score=extraction.confidence,
        embedding=extraction.embedding,
        embedding_model_id=embedding_model_id,
    )

    try:
        updated = update_taxonomic(
            db=db,
            org_id=org_id,
            update=update_data,
            id=decision.existing_id,
        )
        if updated:
            logger.debug(
                "Updated taxonomic term: id=%s domain=%s term=%s",
                updated.id,
                updated.domain,
                updated.term,
            )
            return str(updated.id)
        return None
    except Exception as e:
        logger.error(
            "Failed to update taxonomic term: id=%s error=%s",
            decision.existing_id,
            e,
            exc_info=True,
        )
        return None


def perform_taxonomic_reinforce(
    db: "Database",
    decision: ConsolidationDecision,
    org_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    reinforcement_history_limit: int = 10,
) -> Optional[str]:
    """
    Reinforce an existing taxonomic term with additional context.

    REINFORCE for taxonomic means:
    - Add new evidence spans (merge with existing)
    - Add new related terms (merge with existing)
    - Increment reinforcement count
    - Track which sources reinforced this term
    - Update last_reinforced_at timestamp

    Uses atomic MongoDB aggregation pipeline for race-safety and idempotency.

    Args:
        db: MongoDB database instance
        decision: Consolidation decision with REINFORCE action
        org_id: Organization ID
        source_id: Source reference (snapshot ID)
        extraction_timestamp: Timestamp of extraction
        reinforcement_history_limit: Max reinforcement history entries

    Returns:
        Document ID if reinforced, None otherwise
    """
    existing_id = decision.existing_id

    # Use safe_object_id for cleaner validation
    query_id = safe_object_id(existing_id, "REINFORCE")
    if not query_id:
        return None

    col = get_collection(TaxonomicMemoryCollection(), db)
    extraction = decision.extraction
    metadata = extraction.metadata or {}
    new_related_terms = metadata.get("related_terms", [])
    new_evidence_spans = metadata.get("evidence_spans", [])

    now = utcnow()

    # Build taxonomic-specific extra stages for array merging
    extra_stages = {
        # Always update updated_at
        "updated_at": now,
        # Merge related_terms (additive, deduplicated) - always merge even if re-reinforced
        "related_terms": build_array_merge_stage(
            "related_terms",
            new_related_terms,
            deduplicate=True,
            only_if_new_source=False,  # Always merge related terms
        ),
        # Merge evidence_spans (only if new source)
        "evidence_spans": build_array_merge_stage(
            "evidence_spans",
            new_evidence_spans,
            deduplicate=False,  # Evidence spans may have same text from different sources
            only_if_new_source=True,
        ),
    }

    # Build atomic reinforcement pipeline using shared utility
    # Taxonomic stores reinforcement_sources at root level (not in metadata)
    update_pipeline = build_reinforce_pipeline(
        source_id=source_id,
        timestamp=extraction_timestamp,
        sources_field="reinforcement_sources",
        history_field="reinforcement_history",
        count_field="reinforcement_count",
        last_reinforced_field="last_reinforced_at",
        history_limit=reinforcement_history_limit,
        extra_set_stages=extra_stages,
    )

    try:
        result = col.update_one(
            {"_id": query_id, "org_id": org_id},
            update_pipeline,
        )
    except Exception as e:
        logger.error("Failed to reinforce taxonomic term %s: %s", existing_id, e)
        return None

    if result.matched_count > 0:
        if result.modified_count > 0:
            logger.info(
                "Reinforced taxonomic term %s: source=%s, new_related=%d, new_evidence=%d",
                existing_id,
                source_id,
                len(new_related_terms),
                len(new_evidence_spans),
            )
        else:
            logger.debug(
                "Taxonomic term %s already reinforced by source %s (idempotent)",
                existing_id,
                source_id,
            )
        return existing_id

    logger.warning(
        "Taxonomic term %s not found for reinforcement (org_id=%s)",
        existing_id,
        org_id,
    )
    return None


def perform_taxonomic_upsert(
    db: "Database",
    decision: ConsolidationDecision,
    org_id: str,
    user_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    embedding_model_id: str,
) -> Optional[str]:
    """
    Perform an upsert operation for a taxonomic term.

    This is the main entry point that routes to ADD or UPDATE based on
    whether the term already exists.

    Args:
        db: MongoDB database instance
        decision: Consolidation decision
        org_id: Organization ID
        user_id: User ID
        source_id: Source reference (snapshot ID)
        extraction_timestamp: Timestamp of extraction
        embedding_model_id: ID of embedding model used

    Returns:
        Document ID if successful, None otherwise
    """
    extraction = decision.extraction
    metadata = extraction.metadata or {}
    domain = metadata.get("domain", "")
    term = metadata.get("term", "")

    # Check if term exists
    existing = get_taxonomic(db, org_id, domain=domain, term=term)

    if existing:
        # Update existing - add the existing_id to decision
        decision.existing_id = str(existing.id)
        return perform_taxonomic_update(
            db=db,
            decision=decision,
            org_id=org_id,
            user_id=user_id,
            source_id=source_id,
            extraction_timestamp=extraction_timestamp,
            embedding_model_id=embedding_model_id,
        )
    else:
        return perform_taxonomic_add(
            db=db,
            decision=decision,
            org_id=org_id,
            user_id=user_id,
            source_id=source_id,
            extraction_timestamp=extraction_timestamp,
            embedding_model_id=embedding_model_id,
        )


def apply_taxonomic_decisions(
    db: "Database",
    decisions: List[ConsolidationDecision],
    org_id: str,
    user_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    embedding_model_id: str,
    config: TaxonomicExtractionConfig,
    visibility: ChunkVisibility = ChunkVisibility.ORG,
    project_id: Optional[str] = None,
) -> PersistenceResult:
    """
    Process all taxonomic consolidation decisions.

    Supports:
    - ADD: Create new term
    - UPDATE: Change definition (when semantically different)
    - REINFORCE: Bolster with more context (evidence spans, related terms)
    - NONE/DUPLICATE: Skip (exact duplicate or jargon)

    Args:
        db: MongoDB database instance
        decisions: List of consolidation decisions
        org_id: Organization ID
        user_id: User ID
        source_id: Source reference (snapshot ID)
        extraction_timestamp: Timestamp of extraction
        embedding_model_id: ID of embedding model used
        config: Taxonomic extraction configuration

    Returns:
        PersistenceResult with counts and IDs
    """
    result = PersistenceResult()

    for decision in decisions:
        try:
            if decision.action == "ADD":
                doc_id = perform_taxonomic_add(
                    db=db,
                    decision=decision,
                    org_id=org_id,
                    user_id=user_id,
                    source_id=source_id,
                    extraction_timestamp=extraction_timestamp,
                    embedding_model_id=embedding_model_id,
                    visibility=visibility,
                    project_id=project_id,
                )
                if doc_id:
                    result.added += 1
                    result.created_ids.append(doc_id)

            elif decision.action == "UPDATE":
                doc_id = perform_taxonomic_update(
                    db=db,
                    decision=decision,
                    org_id=org_id,
                    user_id=user_id,
                    source_id=source_id,
                    extraction_timestamp=extraction_timestamp,
                    embedding_model_id=embedding_model_id,
                    visibility=visibility,
                    project_id=project_id,
                )
                if doc_id:
                    result.updated += 1
                    result.updated_new_version_ids.append(doc_id)

            elif decision.action == "REINFORCE":
                # Reinforce: bolster with more evidence and related terms
                doc_id = perform_taxonomic_reinforce(
                    db=db,
                    decision=decision,
                    org_id=org_id,
                    source_id=source_id,
                    extraction_timestamp=extraction_timestamp,
                    reinforcement_history_limit=config.reinforcement_history_limit,
                )
                if doc_id:
                    result.reinforced += 1
                    result.reinforced_ids.append(doc_id)
                else:
                    result.skipped += 1

            elif decision.action == "DUPLICATE":
                result.skipped += 1
                logger.debug("Skipping duplicate/jargon taxonomic term")

        except Exception as e:
            error_msg = f"Failed to process taxonomic decision: {e}"
            logger.error(error_msg, exc_info=True)
            result.errors.append(error_msg)

    logger.info(
        "Taxonomic persistence complete: added=%d updated=%d reinforced=%d skipped=%d errors=%d",
        result.added,
        result.updated,
        result.reinforced,
        result.skipped,
        len(result.errors),
    )

    return result


__all__ = [
    "generate_taxonomic_extraction_id",
    "perform_taxonomic_add",
    "perform_taxonomic_update",
    "perform_taxonomic_reinforce",
    "perform_taxonomic_upsert",
    "apply_taxonomic_decisions",
]
