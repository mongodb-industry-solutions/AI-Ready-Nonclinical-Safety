"""Token counting utilities for the retrieval pipeline.

This module provides shared token counting logic.
It centralizes model name resolution and LiteLLM token counting with caching.
"""

from __future__ import annotations

import hashlib
import logging
import re
import threading
from collections import OrderedDict
from functools import cache
from typing import Any, Dict, List, Optional, Union

from litellm import token_counter
from mongomem_core.common.constants import (
    DEFAULT_CLAUDE_MODEL,
    DEFAULT_GEMINI_MODEL,
    DEFAULT_MODEL_NAME,
    DEFAULT_OPENAI_MODEL,
)
from mongomem_core.models.retrieval import ContextConfig, FormatStyle, ModelType
from mongomem_core.protocols import LLMProtocol

logger = logging.getLogger(__name__)


MODEL_TYPE_TO_LITELLM: Dict[ModelType, str] = {
    ModelType.OPENAI: DEFAULT_OPENAI_MODEL,
    ModelType.CLAUDE: DEFAULT_CLAUDE_MODEL,
    ModelType.ANTHROPIC: DEFAULT_CLAUDE_MODEL,
    ModelType.GEMINI: DEFAULT_GEMINI_MODEL,
    ModelType.GENERIC: DEFAULT_MODEL_NAME,
}

MODEL_TYPE_TO_FORMAT: Dict[ModelType, FormatStyle] = {
    ModelType.OPENAI: FormatStyle.OPENAI,
    ModelType.CLAUDE: FormatStyle.CLAUDE,
    ModelType.ANTHROPIC: FormatStyle.CLAUDE,
    ModelType.GEMINI: FormatStyle.OPENAI,  # Gemini uses OpenAI-compatible format
    ModelType.GENERIC: FormatStyle.OPENAI,
}

_CLAUDE_PATTERN = re.compile(r"^(claude|anthropic/)", re.IGNORECASE)
_OPENAI_PATTERN = re.compile(r"^(gpt-|openai/|o1-|o3-)", re.IGNORECASE)
_GEMINI_PATTERN = re.compile(r"^(gemini|google/)", re.IGNORECASE)


def _get_llm_model_id(llm: Optional["LLMProtocol"]) -> Optional[str]:
    """Extract model_id from LLM if available."""
    if llm is not None:
        model_id = getattr(llm, "model_id", None)
        if model_id:
            return str(model_id)
    return None


def _get_model_type_enum(config: ContextConfig) -> Optional[ModelType]:
    """Extract ModelType enum from config, converting string if needed."""
    if not config.model_type:
        return None
    if isinstance(config.model_type, ModelType):
        return config.model_type
    return ModelType(config.model_type)


def _infer_format_from_model_name(model_name: str) -> Optional[FormatStyle]:
    """
    Infer format style from a model name string using prefix matching.

    Uses regex patterns to match known model name prefixes, avoiding
    false positives from substring matching (e.g., "my-custom-gpt-clone"
    would not match).

    Args:
        model_name: Model identifier (e.g., "gpt-4", "claude-3-opus")

    Returns:
        Inferred FormatStyle or None if cannot be determined
    """
    if _CLAUDE_PATTERN.match(model_name):
        return FormatStyle.CLAUDE
    elif _OPENAI_PATTERN.match(model_name):
        return FormatStyle.OPENAI
    elif _GEMINI_PATTERN.match(model_name):
        return FormatStyle.OPENAI  # Gemini uses OpenAI-compatible message format
    return None


def resolve_model_name(
    llm: Optional["LLMProtocol"],
    config: ContextConfig,
) -> str:
    """
    Resolve model name for token counting with priority fallback.

    Priority order:
    1. llm.model_id property (if llm provided and has model_id)
    2. config.model_type mapped to LiteLLM model name
    3. Default to "gpt-4"

    Args:
        llm: Optional LLMProtocol instance
        config: ContextConfig with model_type

    Returns:
        Model name compatible with LiteLLM (e.g., "gpt-4", "claude-3-opus")
    """
    # Priority 1: Use LLM model_id
    model_id = _get_llm_model_id(llm)
    if model_id:
        logger.debug("Using model_id from LLMProtocol: %s", model_id)
        return model_id

    # Priority 2: Map config.model_type to LiteLLM model name
    model_type_enum = _get_model_type_enum(config)
    if model_type_enum:
        model_name = MODEL_TYPE_TO_LITELLM.get(model_type_enum, DEFAULT_MODEL_NAME)
        logger.debug(
            "Mapped ModelType.%s to LiteLLM model: %s",
            model_type_enum.value,
            model_name,
        )
        return model_name

    # Priority 3: Default
    logger.warning(
        "No model name available from llm or config, defaulting to %s",
        DEFAULT_MODEL_NAME,
    )
    return DEFAULT_MODEL_NAME


def resolve_format_style(
    llm: Optional["LLMProtocol"],
    config: ContextConfig,
) -> FormatStyle:
    """
    Resolve format style with priority fallback based on LLM.

    This allows automatic format detection based on the LLM being used,
    ensuring the output format matches the LLM's expected input format.

    Priority order:
    1. Explicit config.format_style (if different from what model_type would infer)
    2. Infer from llm.model_id (if llm provided and has model_id)
    3. Infer from config.model_type
    4. Fall back to config.format_style default

    Args:
        llm: Optional LLMProtocol instance
        config: ContextConfig with model_type and format_style

    Returns:
        FormatStyle (OPENAI, CLAUDE, or JINJA2)

    Example:
        >>> # With Claude LLM, auto-detects Claude format
        >>> style = resolve_format_style(claude_llm, config)
        >>> # style == FormatStyle.CLAUDE

        >>> # With OpenAI LLM, auto-detects OpenAI format
        >>> style = resolve_format_style(openai_llm, config)
        >>> # style == FormatStyle.OPENAI

        >>> # Explicit format_style is always respected
        >>> config.format_style = FormatStyle.JINJA2
        >>> style = resolve_format_style(openai_llm, config)
        >>> # style == FormatStyle.JINJA2
    """
    # Normalize format_style to FormatStyle enum if it's a string
    format_style_enum = (
        FormatStyle(config.format_style.lower())
        if isinstance(config.format_style, str)
        else config.format_style
    )

    # Priority 1: Check if format_style is explicitly set (different from model_type inference)
    # This ensures user's explicit choice is honored
    model_type_enum = _get_model_type_enum(config)
    if model_type_enum:
        inferred_from_model_type = MODEL_TYPE_TO_FORMAT.get(model_type_enum)
        if inferred_from_model_type and format_style_enum != inferred_from_model_type:
            logger.debug(
                "Using explicit format_style=%s (differs from model_type inference=%s)",
                format_style_enum.value,
                inferred_from_model_type.value,
            )
            return format_style_enum

    if format_style_enum == FormatStyle.JINJA2:
        logger.debug(
            "Using explicit format_style=%s (JINJA2 is never auto-inferred)",
            FormatStyle.JINJA2.value,
        )
        return FormatStyle.JINJA2

    # Priority 2: Infer from LLM model_id (matches actual LLM)
    model_id = _get_llm_model_id(llm)
    if model_id:
        inferred_from_llm = _infer_format_from_model_name(model_id)
        if inferred_from_llm:
            logger.debug(
                "Inferred format_style=%s from llm.model_id=%s",
                inferred_from_llm.value,
                model_id,
            )
            return inferred_from_llm

    # Priority 3: Infer from config.model_type
    if model_type_enum:
        inferred_from_model_type = MODEL_TYPE_TO_FORMAT.get(model_type_enum)
        if inferred_from_model_type:
            logger.debug(
                "Inferred format_style=%s from config.model_type=%s",
                inferred_from_model_type.value,
                model_type_enum.value,
            )
            return inferred_from_model_type

    # Priority 4: Fall back to config.format_style
    logger.debug(
        "Using config.format_style=%s",
        format_style_enum.value,
    )
    return format_style_enum


class TokenCounter:
    """
    Thread-safe token counter with LRU caching for efficient token counting.

    Uses LiteLLM for model-specific token counting with a hash-based cache
    to avoid redundant calculations. The cache uses SHA-256 hashes of text
    content to prevent memory bloat from storing full text. Implements LRU
    eviction to prevent unbounded cache growth.

    Thread-safe: All cache operations are protected by a lock to prevent
    data corruption when accessed from multiple threads.

    Example:
        >>> counter = TokenCounter()
        >>> tokens = counter.count("Hello, world!", "gpt-4")
        >>> tokens = counter.count_messages([{"role": "user", "content": "Hi"}], "gpt-4")
    """

    DEFAULT_MAX_CACHE_SIZE = 10000

    def __init__(self, max_cache_size: int = DEFAULT_MAX_CACHE_SIZE) -> None:
        """
        Initialize TokenCounter with LRU cache and thread safety.

        Args:
            max_cache_size: Maximum number of entries in cache. When exceeded,
                oldest entries are evicted (LRU). Default: 10000.
        """
        self._cache: OrderedDict[str, int] = OrderedDict()
        self._max_cache_size = max_cache_size
        self._lock = threading.Lock()

    def count(self, text: str, model_name: str) -> int:
        """
        Count tokens for text content.

        Thread-safe: Cache operations are protected by a lock. Token counting
        (the expensive operation) is performed outside the lock to minimize contention.

        Args:
            text: Text content to count tokens for
            model_name: LiteLLM-compatible model name

        Returns:
            Number of tokens in the text
        """
        if not text:
            return 0

        cache_key = self._make_cache_key(text, model_name)

        with self._lock:
            if cache_key in self._cache:
                self._cache.move_to_end(cache_key)
                return self._cache[cache_key]

        try:
            messages = [{"role": "user", "content": text}]
            token_count = token_counter(model=model_name, messages=messages)
        except Exception as e:
            logger.error(
                "Failed to count tokens for model=%s: %s. Using character-based fallback.",
                model_name,
                e,
            )
            token_count = max(1, len(text) // 4)

        # Add to cache with lock protection
        with self._lock:
            self._add_to_cache(cache_key, token_count)

        return token_count

    def count_messages(
        self,
        messages: List[Dict[str, Any]],
        model_name: str,
    ) -> int:
        """
        Count tokens for a list of messages (OpenAI format).

        Thread-safe: Cache operations are protected by a lock. Token counting
        (the expensive operation) is performed outside the lock to minimize contention.

        Args:
            messages: List of message dicts with "role" and "content" keys
            model_name: LiteLLM-compatible model name

        Returns:
            Number of tokens in all messages
        """
        if not messages:
            return 0

        # Use string representation for cache key
        messages_str = str(messages)
        cache_key = self._make_cache_key(messages_str, model_name)

        # Check cache with lock protection
        with self._lock:
            if cache_key in self._cache:
                self._cache.move_to_end(cache_key)
                return self._cache[cache_key]

        try:
            token_count = token_counter(model=model_name, messages=messages)
        except Exception as e:
            logger.error(
                "Failed to count tokens for model=%s: %s. Using character-based fallback.",
                model_name,
                e,
            )
            # Fallback: sum character lengths and divide by 4
            total_chars = sum(len(str(m.get("content", ""))) for m in messages)
            token_count = max(1, total_chars // 4)

        # Add to cache with lock protection
        with self._lock:
            self._add_to_cache(cache_key, token_count)

        return token_count

    def count_formatted(
        self,
        formatted_context: Union[str, List[Dict[str, Any]]],
        model_name: str,
    ) -> int:
        """
        Count tokens for formatted context (string or message list).

        This is a convenience method that dispatches to count() or count_messages()
        based on the input type.

        Args:
            formatted_context: Formatted context as string or message list
            model_name: LiteLLM-compatible model name

        Returns:
            Number of tokens in the formatted context
        """
        if isinstance(formatted_context, list):
            return self.count_messages(formatted_context, model_name)
        return self.count(formatted_context, model_name)

    def _make_cache_key(self, content: str, model_name: str) -> str:
        """Create a cache key from content hash and model name."""
        content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
        return f"{model_name}:{content_hash}"

    def _add_to_cache(self, key: str, value: int) -> None:
        """
        Add to cache with LRU eviction.

        This method assumes the caller already holds the lock. It should only
        be called from within a `with self._lock:` block.

        If the cache is at capacity, removes the oldest entry (LRU).
        If the key already exists, moves it to the end (most recently used).

        Args:
            key: Cache key
            value: Token count value to cache
        """
        if key in self._cache:
            # Key exists, move to end (mark as recently used)
            self._cache.move_to_end(key)
        else:
            # New key, check if we need to evict
            if len(self._cache) >= self._max_cache_size:
                # Remove oldest entry (first item)
                self._cache.popitem(last=False)
        self._cache[key] = value

    def clear_cache(self) -> None:
        """Clear the token count cache. Thread-safe."""
        with self._lock:
            self._cache.clear()
        logger.debug("Token count cache cleared")

    @property
    def cache_size(self) -> int:
        """Return the number of cached token counts. Thread-safe."""
        with self._lock:
            return len(self._cache)


@cache
def get_token_counter() -> TokenCounter:
    """
    Get the default TokenCounter singleton.

    This allows Budgeter and Formatter to share a token cache,
    avoiding redundant token counting for the same content.

    The singleton instance is thread-safe. The TokenCounter class
    uses locks to protect cache operations, allowing safe concurrent access.

    Returns:
        The shared TokenCounter instance
    """
    return TokenCounter()


def reset_token_counter() -> None:
    """
    Reset the TokenCounter singleton. Primarily for testing.

    Clears the cached singleton so the next call to get_token_counter()
    creates a fresh instance. This prevents test pollution when tests
    modify or depend on the singleton state.

    Example:
        >>> # In a pytest fixture
        >>> @pytest.fixture(autouse=True)
        >>> def reset_token_counter_singleton():
        >>>     yield
        >>>     reset_token_counter()
    """
    get_token_counter.cache_clear()
    logger.debug("TokenCounter singleton reset")
