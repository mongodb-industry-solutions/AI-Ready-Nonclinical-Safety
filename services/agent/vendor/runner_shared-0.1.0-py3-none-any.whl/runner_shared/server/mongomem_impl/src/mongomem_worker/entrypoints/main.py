from __future__ import annotations

import argparse
import importlib
import logging
import sys
from typing import TYPE_CHECKING, Any, Literal

from ...mongomem_core import MemoryEngine
from ...mongomem_core.config import Settings
from ..config import WorkerSettings
from ..worker import MongoMemWorker

if TYPE_CHECKING:
    from ...mongomem_core.protocols import EmbedderProtocol, LLMProtocol

logger = logging.getLogger(__name__)


def load_class(path: str) -> Any:
    module_path, class_name = path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    return getattr(module, class_name)()


def run_worker(
    embedder_path: str,
    llm_path: str | None = None,
    log_level: str = "INFO",
    scaling_mode: Literal["single", "distributed"] = "single",
) -> None:
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    worker_settings = WorkerSettings()

    logger.info("Loading embedder from %s", embedder_path)
    embedder: EmbedderProtocol = load_class(embedder_path)

    llm: LLMProtocol | None = None
    if llm_path:
        logger.info("Loading LLM from %s", llm_path)
        llm = load_class(llm_path)

    core_settings = Settings(
        mongo_uri=worker_settings.mongo_uri,
        db_name=worker_settings.effective_core_db,
        embedding_dimension=embedder.dimension,
    )

    engine = MemoryEngine(core_settings, embedder=embedder, llm=llm)

    worker = MongoMemWorker(
        engine=engine,
        concurrency=worker_settings.max_concurrent,
        batch_size=worker_settings.batch_size,
        poll_interval_seconds=worker_settings.poll_interval_seconds,
        scaling_mode=scaling_mode,
        worker_db_name=worker_settings.effective_worker_db,
    )

    logger.info("Starting MongoMemWorker (mode=%s)...", scaling_mode)
    worker.run()


def cli() -> None:
    parser = argparse.ArgumentParser(
        description="MongoMem Worker - Background processor for memory embeddings",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  mongomem-worker --embedder myapp.embedders.VoyageEmbedder
  mongomem-worker --embedder myapp.embedders.VoyageEmbedder --llm myapp.llms.ClaudeLLM

Environment Variables:
  MONGOMEM_WORKER_MONGO_URI       MongoDB connection string
  MONGOMEM_WORKER_DB_NAME         Database name
  MONGOMEM_WORKER_MAX_CONCURRENT  Max concurrent tasks
        """,
    )

    parser.add_argument(
        "--embedder",
        required=True,
        help="Dotted path to embedder class (e.g., myapp.embedders.VoyageEmbedder)",
    )
    parser.add_argument(
        "--llm",
        required=False,
        help="Dotted path to LLM class for extractions (optional)",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging level (default: INFO)",
    )
    parser.add_argument(
        "--scaling-mode",
        default="single",
        choices=["single", "distributed"],
        help="Scaling mode (default: single)",
    )

    args = parser.parse_args()

    try:
        run_worker(
            embedder_path=args.embedder,
            llm_path=args.llm,
            log_level=args.log_level,
            scaling_mode=args.scaling_mode,
        )
    except KeyboardInterrupt:
        logger.info("Shutting down...")
        sys.exit(0)
    except Exception as exc:
        logger.exception("Worker failed: %s", exc)
        sys.exit(1)


if __name__ == "__main__":
    cli()
