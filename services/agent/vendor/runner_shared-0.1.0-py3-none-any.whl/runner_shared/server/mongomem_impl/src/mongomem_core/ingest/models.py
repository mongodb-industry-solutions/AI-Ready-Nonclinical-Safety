"""
Models for document ingestion pipeline.

Defines configuration and result types for extracting text from documents,
chunking, and storing as semantic memories.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class ExtractorType(str, Enum):
    """Available document extractors."""

    SIMPLE = "simple"  # PyMuPDF + python-pptx + python-docx
    DOCLING = "docling"  # Advanced extraction (future)


class ChunkerType(str, Enum):
    """Available text chunking strategies."""

    AUTO = "auto"  # Auto-select based on extractor
    RECURSIVE = "recursive"  # LangChain RecursiveCharacterTextSplitter
    HYBRID = "hybrid"  # Docling's HybridChunker (future)


# Supported file extensions for simple extractor
SUPPORTED_EXTENSIONS = {".txt", ".pdf", ".pptx", ".docx"}


@dataclass
class ChunkConfig:
    """Configuration for text chunking."""

    # Size limits (in tokens)
    max_chunk_size: int = 400  # Maximum tokens per chunk
    min_chunk_size: int = 50  # Minimum tokens (filter small chunks)
    chunk_overlap: int = 50  # Overlap between chunks

    # Tokenizer (OpenAI's cl100k_base is widely compatible)
    encoding_name: str = "cl100k_base"

    # Behavior
    discard_small_chunks: bool = True  # Drop chunks below min_chunk_size


@dataclass
class IngestConfig:
    """Configuration for document ingestion."""

    # Extractor and chunker selection
    extractor: ExtractorType = ExtractorType.SIMPLE
    chunker: ChunkerType = ChunkerType.AUTO
    chunk_config: ChunkConfig = field(default_factory=ChunkConfig)

    # Retry settings
    max_retries: int = 2
    on_failure: str = "skip"  # "skip", "raise", "collect"

    # Metadata to add to all chunks
    default_metadata: Dict[str, Any] = field(default_factory=dict)

    def get_effective_chunker(self) -> ChunkerType:
        """Get the effective chunker based on extractor type."""
        if self.chunker == ChunkerType.AUTO:
            if self.extractor == ExtractorType.DOCLING:
                return ChunkerType.HYBRID
            return ChunkerType.RECURSIVE
        return self.chunker


@dataclass
class FileResult:
    """Result for a single file ingestion."""

    path: str
    success: bool
    chunks_created: int = 0
    error: Optional[str] = None


@dataclass
class IngestResult:
    """Result of ingesting multiple documents."""

    files_processed: int
    files_succeeded: int
    files_failed: int
    total_chunks: int
    file_results: List[FileResult]
    chunk_ids: List[str]

    @property
    def has_failures(self) -> bool:
        """Check if any files failed to process."""
        return self.files_failed > 0


def validate_file_extension(file_path: str, extractor: ExtractorType) -> Optional[str]:
    """
    Validate that a file extension is supported.

    Args:
        file_path: Path to the file
        extractor: Extractor type to use

    Returns:
        None if valid, error message string if invalid
    """
    from pathlib import Path

    ext = Path(file_path).suffix.lower()

    if extractor == ExtractorType.SIMPLE:
        if ext not in SUPPORTED_EXTENSIONS:
            supported = ", ".join(sorted(SUPPORTED_EXTENSIONS))
            return (
                f"Unsupported file type: {ext}. "
                f"Supported extensions for 'simple' extractor: {supported}. "
                f"For .doc files, please convert to .docx or use extractor='docling'."
            )
    # Docling supports all formats including .doc and images (future)

    return None
