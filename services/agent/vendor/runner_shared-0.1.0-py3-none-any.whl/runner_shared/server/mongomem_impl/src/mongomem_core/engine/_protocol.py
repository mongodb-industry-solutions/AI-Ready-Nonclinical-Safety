"""Protocol for type-safe mixin composition.

This module defines a Protocol that mixins can use for type hints
when accessing attributes defined in MemoryEngineBase.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional, Protocol

if TYPE_CHECKING:
    from mongomem_core.config import ISGenerationConfig, Settings
    from mongomem_core.models.context import MemoryContext
    from mongomem_core.models.engine import InternalStateResult, ISGenerationResult
    from mongomem_core.models.memory.base import ChunkVisibility
    from mongomem_core.modes import MemoryMode
    from mongomem_core.observability import CoreObservability
    from mongomem_core.protocols import EmbedderProtocol, ExecutorProtocol, LLMProtocol
    from pymongo.database import Database


class EngineProtocol(Protocol):
    """
    Protocol defining the interface mixins expect from the base engine.

    This enables type-safe access to _db, _embedder, and _llm in mixin
    methods without requiring inheritance from the base class.

    Usage in mixins:
        def my_method(self: "EngineProtocol", ...) -> ...:
            return self._db.collection.find(...)
    """

    _db: "Database"
    _embedder: Optional["EmbedderProtocol"]
    _llm: Optional["LLMProtocol"]
    _executor: Optional["ExecutorProtocol"]
    _mode: "MemoryMode"
    _is_config: Optional["ISGenerationConfig"]
    _is_llm: Optional["LLMProtocol"]
    _obs: "CoreObservability"
    settings: "Settings"

    @property
    def db(self) -> "Database":
        """Public accessor for database."""
        ...

    def resolve_mode(
        self,
        *,
        org_id: str,
        session_id: Optional[str] = None,
    ) -> "MemoryMode":
        """Resolve the effective mode for an org/session."""
        ...

    def update_internal_state(
        self,
        *,
        session_id: str,
        org_id: str,
        user_id: str,
        content: str,
        token_count: Optional[int] = None,
        token_count_estimated: bool = True,
        tokenizer_id: Optional[str] = None,
        model_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        source_turn_id: Optional[str] = None,
        update_reason: str = "turn_end",
        metadata: Optional[Dict[str, Any]] = None,
        expected_version: Optional[int] = None,
        if_match_hash: Optional[str] = None,
        redaction_applied: bool = False,
        redaction_policy_id: Optional[str] = None,
    ) -> "InternalStateResult":
        """Update internal state for a session."""
        ...

    def _sanitize_is_inputs(
        self,
        config: "ISGenerationConfig",
        user_message: Optional[str],
        assistant_response: Optional[str],
        tool_observations: Optional[List[str]],
        intermediate_thoughts: Optional[str],
    ) -> Dict[str, Any]:
        """Sanitize inputs before IS generation."""
        ...

    def _check_is_update_policy(
        self,
        session_id: str,
        org_id: str,
        config: "ISGenerationConfig",
        milestone: Optional[str],
        turn_index: Optional[int],
        agent_id: Optional[str] = None,
    ) -> Optional["ISGenerationResult"]:
        """Check if IS update should be skipped based on policy."""
        ...

    def _build_events_section(self, inputs: Dict[str, Any]) -> str:
        """Build the events section for the IS prompt."""
        ...

    def _compute_events_hash(self, inputs: Dict[str, Any]) -> str:
        """Compute hash of all input events for provenance."""
        ...

    def _compute_derived_from(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Compute provenance hashes for each input."""
        ...

    def _update_coalesce_timestamp(
        self, session_id: str, org_id: str, agent_id: Optional[str] = None
    ) -> None:
        """Update last generation timestamp for coalescing."""
        ...

    def _get_turn_counter(self, session_id: str, org_id: str) -> int:
        """Get turn counter from session_counters collection."""
        ...

    def _get_last_is_generation_time(
        self, session_id: str, org_id: str, agent_id: Optional[str] = None
    ) -> Optional[Any]:
        """Get last IS generation timestamp from DB."""
        ...

    def _build_context_iwm(
        self,
        session_id: str,
        org_id: str,
        user_id: str,
        *,
        query: Optional[str] = None,
        query_embedding: Optional[List[float]] = None,
        token_budget: int = 4000,
        is_token_budget: int = 500,
        top_k: int = 50,
        visibility: Optional["ChunkVisibility"] = None,
        project_id: Optional[str] = None,
        similarity_threshold: float = 0.0,
        agent_id: Optional[str] = None,
    ) -> "MemoryContext":
        """Build context for IWM mode."""
        ...

    def _build_context_traditional(
        self,
        session_id: str,
        org_id: str,
        user_id: str,
        *,
        query: Optional[str] = None,
        query_embedding: Optional[List[float]] = None,
        token_budget: int = 4000,
        top_k: int = 50,
        visibility: Optional["ChunkVisibility"] = None,
        project_id: Optional[str] = None,
        similarity_threshold: float = 0.0,
        stm_agent_id: Optional[str] = None,
        stm_exclude_agent_ids: Optional[List[str]] = None,
    ) -> "MemoryContext":
        """Build context for TRADITIONAL mode."""
        ...

    def _build_context_hybrid(
        self,
        session_id: str,
        org_id: str,
        user_id: str,
        *,
        query: Optional[str] = None,
        query_embedding: Optional[List[float]] = None,
        token_budget: int = 4000,
        is_token_budget: int = 500,
        top_k: int = 50,
        visibility: Optional["ChunkVisibility"] = None,
        project_id: Optional[str] = None,
        similarity_threshold: float = 0.0,
        agent_id: Optional[str] = None,
        stm_agent_id: Optional[str] = None,
        stm_exclude_agent_ids: Optional[List[str]] = None,
    ) -> "MemoryContext":
        """Build context for HYBRID mode."""
        ...
