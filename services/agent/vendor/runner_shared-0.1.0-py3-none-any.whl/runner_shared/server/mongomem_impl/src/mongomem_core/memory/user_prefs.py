"""CRUD and invariants for user context/preferences memory.

User context memory stores user preferences, communication style,
and demographic information to personalize agent interactions.

Preferences can be scoped to:
- User-level (session_id=None): Default preferences across all sessions
- Session-level (session_id set): Preferences specific to a conversation

All functions operate synchronously against MongoDB and expect the caller to
provide necessary context (org_id, user_id, etc.).
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

from mongomem_core.common.utils import handle_db_error, handle_duplicate_key_error, utcnow
from mongomem_core.exceptions import (
    DatabaseOperationError,
    DocumentNotFoundError,
)
from mongomem_core.memory.base import (
    BaseDocumentBuilder,
    BaseQueryBuilder,
    BaseUpdateFieldBuilder,
    doc_to_output,
)
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.user_prefs import (
    UserContextMemoryDB,
    UserContextMemoryIn,
    UserContextMemoryOut,
    UserContextMemoryUpdate,
)
from mongomem_core.storage import get_collection
from mongomem_core.storage.collections import MemoryUserContextCollection
from pymongo import ReturnDocument
from pymongo.database import Database
from pymongo.errors import DuplicateKeyError
from pymongo.results import DeleteResult

logger = logging.getLogger(__name__)


_USER_CONTEXT_COL = MemoryUserContextCollection()


def _build_user_context_doc(
    ctx_in: UserContextMemoryIn,
    org_id: str,
    user_id: str,
    timestamp: datetime,
) -> UserContextMemoryDB:
    """Build a UserContextMemoryDB document from input.

    Args:
        ctx_in: Input model with user context memory data
        org_id: Organization ID
        user_id: User ID this context belongs to
        timestamp: Timestamp for the document

    Returns:
        A UserContextMemoryDB document (not yet persisted)
    """
    return BaseDocumentBuilder.build_memory_document(
        ctx_in,
        UserContextMemoryDB,
        org_id,
        user_id,
        timestamp,
        exclude_fields=["org_id", "user_id"],
        updated_at=timestamp,
    )


def create_user_context(
    db: Database,
    ctx_in: UserContextMemoryIn,
    org_id: str,
    user_id: str,
) -> UserContextMemoryDB:
    """
    Create a user context memory document.

    Args:
        db: MongoDB database instance
        ctx_in: Input model with user context memory data
        org_id: Organization ID
        user_id: User ID this context belongs to

    Returns:
        The created UserContextMemoryDB document

    Raises:
        DuplicateDocumentError: If a context already exists for this user+session (unique constraint).
        DatabaseOperationError: If the insert operation fails.

    Example:
        >>> from mongomem_core.storage import get_database
        >>> from mongomem_core.models.memory.user_prefs import UserContextMemoryIn
        >>> db = get_database()
        >>> # Session-scoped preferences
        >>> ctx = UserContextMemoryIn(
        ...     session_id="session_123",
        ...     tone="formal",
        ...     style="concise",
        ... )
        >>> doc = create_user_context(db, ctx, org_id="org_1", user_id="user_1")
    """
    logger.debug(
        "Creating user context memory document: org=%s user=%s session=%s",
        org_id,
        user_id,
        ctx_in.session_id,
    )

    now = utcnow()
    doc = _build_user_context_doc(ctx_in, org_id, user_id, now)

    col = get_collection(_USER_CONTEXT_COL, db)
    try:
        with handle_db_error(
            operation="insert_one",
            collection=_USER_CONTEXT_COL.name,
            log_message="Failed to create user context document: org=%s user=%s session=%s",
            log_args_tuple=(org_id, user_id, ctx_in.session_id),
        ):
            result = col.insert_one(doc.model_dump(by_alias=True))
            doc.id = result.inserted_id

            logger.debug(
                "Created user context document: id=%s org=%s user=%s session=%s",
                result.inserted_id,
                org_id,
                user_id,
                ctx_in.session_id,
            )
            return doc
    except DuplicateKeyError as exc:
        handle_duplicate_key_error(
            exc,
            collection_name=_USER_CONTEXT_COL.name,
            log_message="Duplicate user context document detected: org=%s user=%s session=%s",
            log_args=(org_id, user_id, ctx_in.session_id),
            details={
                "org_id": org_id,
                "user_id": user_id,
                "session_id": ctx_in.session_id,
            },
        )


def upsert_user_context(
    db: Database,
    ctx_in: UserContextMemoryIn,
    org_id: str,
    user_id: str,
    session_id: Optional[str] = None,
) -> UserContextMemoryOut:
    """
    Create or update a user context memory document.

    If a context exists for the user+session combo, it will be updated.
    Otherwise, a new document will be created.

    Args:
        db: MongoDB database instance
        ctx_in: Input model with user context memory data
        org_id: Organization ID
        user_id: User ID this context belongs to
        session_id: Optional session ID for session-scoped preferences.
                   If None, uses ctx_in.session_id or creates user-level preference.

    Returns:
        The created or updated UserContextMemoryOut document

    Raises:
        DatabaseOperationError: If the upsert operation fails.

    Example:
        >>> # Session-scoped preferences
        >>> ctx = UserContextMemoryIn(tone="casual", expertise_level="expert")
        >>> doc = upsert_user_context(db, ctx, org_id="org_1", user_id="user_1", session_id="sess_123")

        >>> # User-level default preferences
        >>> ctx = UserContextMemoryIn(tone="formal", style="detailed")
        >>> doc = upsert_user_context(db, ctx, org_id="org_1", user_id="user_1")
    """
    # Use explicit session_id param or fall back to ctx_in.session_id
    effective_session_id = session_id if session_id is not None else ctx_in.session_id

    logger.debug(
        "Upserting user context memory document: org=%s user=%s session=%s",
        org_id,
        user_id,
        effective_session_id,
    )

    col = get_collection(_USER_CONTEXT_COL, db)
    now = utcnow()

    update_doc = ctx_in.model_dump(exclude_unset=True)
    update_doc["org_id"] = org_id
    update_doc["user_id"] = user_id
    update_doc["session_id"] = effective_session_id
    update_doc["updated_at"] = now
    update_doc.pop("timestamp", None)

    # Build filter - session_id can be None for user-level preferences
    q_filter: Dict[str, Any] = {
        "org_id": org_id,
        "user_id": user_id,
        "session_id": effective_session_id,
    }

    with handle_db_error(
        operation="find_one_and_update",
        collection=_USER_CONTEXT_COL.name,
        log_message="Failed to upsert user context document: org=%s user=%s session=%s",
        log_args_tuple=(org_id, user_id, effective_session_id),
    ):
        result = col.find_one_and_update(
            q_filter,
            {"$set": update_doc, "$setOnInsert": {"timestamp": now}},
            upsert=True,
            return_document=ReturnDocument.AFTER,
        )

        if result:
            result["_id"] = str(result["_id"])
            logger.debug(
                "Upserted user context document: id=%s org=%s user=%s session=%s",
                result["_id"],
                org_id,
                user_id,
                effective_session_id,
            )
            return UserContextMemoryOut.model_validate(result)

        logger.error(
            "Upsert returned None despite upsert=True: user=%s org=%s session=%s",
            user_id,
            org_id,
            effective_session_id,
            exc_info=True,
        )
        raise DatabaseOperationError(
            "Upsert operation failed unexpectedly",
            operation="find_one_and_update",
            collection=_USER_CONTEXT_COL.name,
            details={"org_id": org_id, "user_id": user_id, "session_id": effective_session_id},
        )


def get_user_context(
    db: Database,
    org_id: str,
    user_id: str,
    session_id: Optional[str] = None,
) -> Optional[UserContextMemoryOut]:
    """
    Fetch a user context memory document by org_id, user_id, and optional session_id.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        user_id: User ID
        session_id: Optional session ID. If None, fetches user-level default preferences.

    Returns:
        UserContextMemoryOut if found, None otherwise.

    Raises:
        DatabaseOperationError: If the query fails.

    Example:
        >>> # Get session-specific preferences
        >>> doc = get_user_context(db, org_id="org_1", user_id="user_1", session_id="sess_123")

        >>> # Get user-level default preferences
        >>> doc = get_user_context(db, org_id="org_1", user_id="user_1")
    """
    col = get_collection(_USER_CONTEXT_COL, db)

    q_filter: Dict[str, Any] = {
        "org_id": org_id,
        "user_id": user_id,
        "session_id": session_id,
    }

    with handle_db_error(
        operation="find_one",
        collection=_USER_CONTEXT_COL.name,
        log_message="Failed to retrieve user context document: org=%s user=%s session=%s",
        log_args_tuple=(org_id, user_id, session_id),
    ):
        doc = col.find_one(q_filter)
        if not doc:
            logger.debug(
                "User context document not found: org=%s user=%s session=%s",
                org_id,
                user_id,
                session_id,
            )
            return None

        doc["_id"] = str(doc["_id"])
        logger.debug(
            "Retrieved user context document: org=%s user=%s session=%s",
            org_id,
            user_id,
            session_id,
        )
        return UserContextMemoryOut.model_validate(doc)


def get_session_preferences_with_fallback(
    db: Database,
    org_id: str,
    user_id: str,
    session_id: str,
) -> Optional[UserContextMemoryOut]:
    """
    Get session preferences with fallback to user-level defaults.

    First tries to fetch session-specific preferences. If not found,
    falls back to user-level default preferences (session_id=None).

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        user_id: User ID
        session_id: Session ID to check first

    Returns:
        Session preferences if found, else user defaults, else None.

    Example:
        >>> prefs = get_session_preferences_with_fallback(db, "org_1", "user_1", "sess_123")
        >>> # Returns session prefs if they exist, otherwise user defaults
    """
    # First try session-specific
    prefs = get_user_context(db, org_id, user_id, session_id=session_id)
    if prefs:
        return prefs

    # Fall back to user-level defaults
    return get_user_context(db, org_id, user_id, session_id=None)


def list_user_context(
    db: Database,
    org_id: str,
    *,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    include_user_defaults: bool = True,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    from_timestamp: Optional[datetime] = None,
    before: Optional[datetime] = None,
    limit: Optional[int] = None,
    sort_by: str = "timestamp",
    sort_descending: bool = False,
) -> List[UserContextMemoryOut]:
    """
    List user context memory documents for an organization with optional filters and pagination.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        user_id: Optional filter by user ID
        session_id: Optional filter by session ID
        include_user_defaults: If True and session_id is set, also include user-level defaults
        visibility: Optional filter by visibility scope
        project_id: Optional filter by group ID (for shared visibility)
        from_timestamp: Optional filter - fetch documents from this timestamp onwards
        before: Optional cursor - fetch documents before this timestamp (for pagination)
        limit: Optional limit on number of results
        sort_by: Field to sort by (default: "timestamp")
        sort_descending: If True, sort descending (newest first)

    Returns:
        List of UserContextMemoryOut documents

    Raises:
        DatabaseOperationError: If the query fails.

    Example:
        >>> # Get all contexts for org
        >>> docs = list_user_context(db, org_id="org_1")
        >>> # Get contexts for a specific session
        >>> docs = list_user_context(db, org_id="org_1", user_id="user_1", session_id="sess_123")
    """
    col = get_collection(_USER_CONTEXT_COL, db)

    q_filter = BaseQueryBuilder.build_list_filter(
        org_id,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        from_timestamp=from_timestamp,
        before=before,
        timestamp_field="timestamp",
    )

    # Add session filter if specified
    if session_id is not None:
        if include_user_defaults:
            # Include both session-specific and user defaults (session_id=None)
            q_filter["session_id"] = {"$in": [session_id, None]}
        else:
            q_filter["session_id"] = session_id

    sort_direction = -1 if sort_descending else 1

    with handle_db_error(
        operation="find",
        collection=_USER_CONTEXT_COL.name,
        log_message="Failed to retrieve user context documents for org=%s",
        log_args_tuple=(org_id,),
    ):
        cursor = col.find(q_filter).sort(sort_by, sort_direction)
        if limit and limit > 0:
            cursor = cursor.limit(limit)
        results = [doc_to_output(d, UserContextMemoryOut) for d in cursor]
        logger.debug(
            "Retrieved %d user context documents for org=%s",
            len(results),
            org_id,
        )
        return results


def _build_update_fields(update: UserContextMemoryUpdate) -> Dict[str, Any]:
    """Build MongoDB update fields from UserContextMemoryUpdate model."""
    return BaseUpdateFieldBuilder.build_update_fields(
        update,
        field_mappings={
            "tone": "tone",
            "style": "style",
            "response_length": "response_length",
            "preferred_format": "preferred_format",
            "language": "language",
            "expertise_level": "expertise_level",
            "custom_instructions": "custom_instructions",
            "demographic_tags": "demographic_tags",
            "preferences": "preferences",
            "source": "source",
            "timezone": "timezone",
        },
        include_publishing=False,
        include_embedding=False,
    )


def update_user_context(
    db: Database,
    org_id: str,
    user_id: str,
    update: UserContextMemoryUpdate,
    session_id: Optional[str] = None,
) -> UserContextMemoryOut:
    """
    Update a user context memory document.

    Supports partial updates - only non-None fields in the update model will be modified.
    All fields in UserContextMemoryUpdate are optional, allowing flexible partial updates.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        user_id: User ID
        update: Update model with fields to modify (only non-None fields are updated)
        session_id: Optional session ID. If None, updates user-level default preferences.

    Returns:
        Updated UserContextMemoryOut document

    Raises:
        DocumentNotFoundError: If the document doesn't exist.
        DatabaseOperationError: If the update operation fails.

    Example:
        >>> from mongomem_core.models.memory.user_prefs import UserContextMemoryUpdate
        >>> # Partial update - only update tone and expertise level
        >>> update = UserContextMemoryUpdate(tone="casual", expertise_level="expert")
        >>> doc = update_user_context(db, org_id="org_1", user_id="user_1", update=update, session_id="sess_123")
    """
    update_fields = _build_update_fields(update)

    if not update_fields:
        doc = get_user_context(db, org_id, user_id, session_id=session_id)
        if not doc:
            raise DocumentNotFoundError(
                "User context document not found",
                collection=_USER_CONTEXT_COL.name,
                document_id=None,
                details={"org_id": org_id, "user_id": user_id, "session_id": session_id},
            )
        return doc

    update_fields["updated_at"] = utcnow()

    col = get_collection(_USER_CONTEXT_COL, db)
    q_filter: Dict[str, Any] = {
        "org_id": org_id,
        "user_id": user_id,
        "session_id": session_id,
    }

    with handle_db_error(
        operation="find_one_and_update",
        collection=_USER_CONTEXT_COL.name,
        log_message="Failed to update user context document: org=%s user=%s session=%s",
        log_args_tuple=(org_id, user_id, session_id),
    ):
        result_doc = col.find_one_and_update(
            q_filter,
            {"$set": update_fields},
            return_document=ReturnDocument.AFTER,
        )

        if not result_doc:
            raise DocumentNotFoundError(
                "User context document not found",
                collection=_USER_CONTEXT_COL.name,
                document_id=None,
                details={"org_id": org_id, "user_id": user_id, "session_id": session_id},
            )

        logger.debug(
            "Updated user context document: org=%s user=%s session=%s",
            org_id,
            user_id,
            session_id,
        )
        return UserContextMemoryOut.model_validate({**result_doc, "_id": str(result_doc["_id"])})


def delete_user_context(
    db: Database,
    org_id: str,
    user_id: str,
    session_id: Optional[str] = None,
) -> DeleteResult:
    """
    Hard delete a user context memory document.

    Permanently removes the document from the database.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        user_id: User ID
        session_id: Optional session ID. If None, deletes user-level default preferences.

    Returns:
        DeleteResult from MongoDB

    Raises:
        DatabaseOperationError: If the delete operation fails.

    Example:
        >>> # Delete session preferences
        >>> result = delete_user_context(db, org_id="org_1", user_id="user_1", session_id="sess_123")
        >>> # Delete user-level defaults
        >>> result = delete_user_context(db, org_id="org_1", user_id="user_1")
    """
    col = get_collection(_USER_CONTEXT_COL, db)
    q_filter: Dict[str, Any] = {
        "org_id": org_id,
        "user_id": user_id,
        "session_id": session_id,
    }

    with handle_db_error(
        operation="delete_one",
        collection=_USER_CONTEXT_COL.name,
        log_message="Failed to delete user context document: org=%s user=%s session=%s",
        log_args_tuple=(org_id, user_id, session_id),
    ):
        result = col.delete_one(q_filter)
        logger.debug(
            "Deleted user context document: org=%s user=%s session=%s (deleted_count=%d)",
            org_id,
            user_id,
            session_id,
            result.deleted_count,
        )
        return result


def delete_session_preferences(
    db: Database,
    org_id: str,
    session_id: str,
) -> DeleteResult:
    """
    Delete all preferences for a specific session (across all users).

    Useful for cleanup when a session ends.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        session_id: Session ID

    Returns:
        DeleteResult from MongoDB

    Example:
        >>> result = delete_session_preferences(db, org_id="org_1", session_id="sess_123")
    """
    col = get_collection(_USER_CONTEXT_COL, db)
    q_filter: Dict[str, Any] = {
        "org_id": org_id,
        "session_id": session_id,
    }

    with handle_db_error(
        operation="delete_many",
        collection=_USER_CONTEXT_COL.name,
        log_message="Failed to delete session preferences: org=%s session=%s",
        log_args_tuple=(org_id, session_id),
    ):
        result = col.delete_many(q_filter)
        logger.debug(
            "Deleted session preferences: org=%s session=%s (deleted_count=%d)",
            org_id,
            session_id,
            result.deleted_count,
        )
        return result
