"""Core configuration for mongomem_core engine."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Literal, Optional


@dataclass
class Settings:
    """Core engine settings."""

    mongo_uri: str = "mongodb://localhost:27017"
    db_name: str = "agentic_memory"
    embedding_dimension: int = 1536

    @classmethod
    def from_env(cls) -> "Settings":
        """Create settings from environment variables."""
        return cls(
            mongo_uri=os.getenv("MONGODB_URI", "mongodb://localhost:27017"),
            db_name=os.getenv("MONGOMEM_DB_NAME", "agentic_memory"),
            embedding_dimension=int(os.getenv("MONGOMEM_EMBEDDING_DIMENSION", "1536")),
        )


# =============================================================================
# IS Generation Config
# =============================================================================


@dataclass
class ISGenerationConfig:
    """
    Configuration for automatic Internal State generation.

    Controls when and how IS is generated from turn events.
    This is for the optional `generate_is_from_turn()` convenience layer.
    """

    # Update policy
    update_policy: Literal["always", "milestone", "every_n", "coalesce"] = "always"
    """
    When to generate IS updates:
    - "always": Generate on every call (default)
    - "milestone": Only when a milestone trigger is provided
    - "every_n": Every N turns (requires turn_index or DB counter)
    - "coalesce": Batch events within coalesce_window_ms
    """

    # Coalescing settings
    coalesce_window_ms: int = 5000
    """Window for coalescing multiple events (ms). DB-backed for multi-pod safety."""

    every_n_turns: int = 3
    """Generate IS every N turns (for "every_n" policy)."""

    # Milestone triggers
    milestone_triggers: List[str] = field(
        default_factory=lambda: [
            "task_complete",
            "user_preference_learned",
            "error_resolved",
            "context_switch",
            "session_end",
        ]
    )
    """Milestones that trigger IS update (for "milestone" policy)."""

    # LLM generation settings
    max_tokens: int = 500
    """Hard token limit enforced via LLM API (not prompting)."""

    temperature: float = 0.3
    """Temperature for IS generation. Lower = more deterministic."""

    stop_sequences: List[str] = field(
        default_factory=lambda: [
            "\n\n---",
            "</internal_state>",
            "<user>",
            "<assistant>",
        ]
    )
    """Stop sequences to prevent spillover."""

    # Prompt template
    prompt_template: Optional[str] = None
    """Custom Jinja2/format template. None = use default sectioned prompt."""

    # Input sanitization
    redact_patterns: List[str] = field(default_factory=list)
    """Regex patterns to redact from inputs (e.g., API keys, PII)."""

    sanitize_inputs: Optional[Callable[[Dict], Dict]] = None
    """Optional hook to sanitize inputs before IS generation."""

    # Noop optimization
    skip_if_unchanged: bool = True
    """Skip update if content_hash unchanged (saves churn)."""


# Default sectioned IS prompt for gating + diff
DEFAULT_IS_PROMPT_TEMPLATE = """You are maintaining working memory for an AI agent.

Current internal state:
<internal_state>
{current_is}
</internal_state>

Events since last update:
{events_section}

Update the internal state. Use these exact sections:

## User Profile
Who the user is, their preferences, communication style.

## Current Task
What we're actively working on, current progress.

## Key Facts
Important information learned (objective, verifiable).

## Decisions Made
Choices and their rationale.

## Constraints
Limitations, requirements, or rules to follow.

## Open Questions
Unresolved items that need attention.

## Next Steps
Immediate actions to take.

Output ONLY the updated internal state with these sections. Be concise."""


__all__ = [
    "Settings",
    "ISGenerationConfig",
    "DEFAULT_IS_PROMPT_TEMPLATE",
]
