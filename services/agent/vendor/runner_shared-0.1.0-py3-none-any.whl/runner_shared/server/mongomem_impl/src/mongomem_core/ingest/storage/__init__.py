"""
Storage backends for document ingestion.

Provides pluggable storage backends for resolving file URIs:
- LocalStorage: Local filesystem (default)
- GCSStorage: Google Cloud Storage (gs:// URIs)

Example:
    from mongomem_core.ingest.storage import GCSStorage

    gcs = GCSStorage()
    result = engine.ingest_documents(
        paths=["gs://my-bucket/docs/report.pdf"],
        org_id="my-org",
        user_id="sakshi",
        storage_backend=gcs,
    )
"""

from mongomem_core.ingest.storage.base import StorageBackend, detect_backend
from mongomem_core.ingest.storage.local import LocalStorage

# GCS is optional - only import if google-cloud-storage is installed
try:
    from mongomem_core.ingest.storage.gcs import GCSStorage

    _HAS_GCS = True
except ImportError:
    GCSStorage = None  # type: ignore
    _HAS_GCS = False


def get_default_backends() -> "list[StorageBackend]":
    """
    Get list of available storage backends.

    Returns backends in priority order (GCS first if available, then local).
    """
    backends: "list[StorageBackend]" = []

    if _HAS_GCS and GCSStorage is not None:
        backends.append(GCSStorage())  # type: ignore[arg-type]

    backends.append(LocalStorage())  # type: ignore[arg-type]

    return backends


__all__ = [
    "StorageBackend",
    "LocalStorage",
    "GCSStorage",
    "detect_backend",
    "get_default_backends",
]
