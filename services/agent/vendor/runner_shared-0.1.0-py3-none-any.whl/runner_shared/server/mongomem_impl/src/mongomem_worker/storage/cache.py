"""
Collection caching for mongomem_worker.

Provides cached access to MongoDB collection objects, avoiding repeated
lookups and ensuring consistent collection references across the worker.
"""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING, Dict, Tuple

from pymongo.collection import Collection

from ..constants import (
    CHANGE_STREAM_STATE_COLLECTION,
    CORE_SNAPSHOT_COLLECTION,
    CORE_STM_COLLECTION,
    EXTRACTION_CONFIG_COLLECTION,
    RESUME_TOKENS_COLLECTION,
    TASKS_COLLECTION,
    TASKS_DLQ_COLLECTION,
    WORKER_STATE_COLLECTION,
)

if TYPE_CHECKING:
    from pymongo.database import Database

_cache_lock = threading.Lock()
_collection_cache: Dict[Tuple[str, str], Collection] = {}


def get_collection(db: "Database", collection_name: str) -> Collection:
    """
    Get a cached collection reference (thread-safe).

    Cache key is (db.name, collection_name) to handle split databases.
    """
    cache_key = (db.name, collection_name)
    with _cache_lock:
        if cache_key not in _collection_cache:
            _collection_cache[cache_key] = db[collection_name]
        return _collection_cache[cache_key]


def get_stm_collection(db: "Database") -> Collection:
    """Get cached short-term memory collection."""
    return get_collection(db, CORE_STM_COLLECTION)


def get_snapshot_collection(db: "Database") -> Collection:
    """Get cached snapshot collection."""
    return get_collection(db, CORE_SNAPSHOT_COLLECTION)


def get_tasks_collection(db: "Database") -> Collection:
    """Get cached tasks collection."""
    return get_collection(db, TASKS_COLLECTION)


def get_tasks_dlq_collection(db: "Database") -> Collection:
    """Get cached tasks DLQ collection."""
    return get_collection(db, TASKS_DLQ_COLLECTION)


def get_worker_state_collection(db: "Database") -> Collection:
    """Get cached worker state collection."""
    return get_collection(db, WORKER_STATE_COLLECTION)


def get_resume_tokens_collection(db: "Database") -> Collection:
    """Get cached resume tokens collection."""
    return get_collection(db, RESUME_TOKENS_COLLECTION)


def get_change_stream_state_collection(db: "Database") -> Collection:
    """Get cached change stream state collection."""
    return get_collection(db, CHANGE_STREAM_STATE_COLLECTION)


def get_extraction_config_collection(db: "Database") -> Collection:
    """Get cached extraction config collection."""
    return get_collection(db, EXTRACTION_CONFIG_COLLECTION)


def clear_cache() -> None:
    """Clear the collection cache (thread-safe). Useful for testing."""
    with _cache_lock:
        _collection_cache.clear()


__all__ = [
    "get_collection",
    "get_stm_collection",
    "get_snapshot_collection",
    "get_tasks_collection",
    "get_tasks_dlq_collection",
    "get_worker_state_collection",
    "get_resume_tokens_collection",
    "get_change_stream_state_collection",
    "get_extraction_config_collection",
    "clear_cache",
]
