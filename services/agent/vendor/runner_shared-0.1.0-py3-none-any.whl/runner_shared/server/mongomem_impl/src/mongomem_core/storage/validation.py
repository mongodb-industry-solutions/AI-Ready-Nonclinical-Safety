"""
Validation helpers for ``mongomem_core`` storage.

These helpers provide a **read-only** view over the live database schema and
the in-code descriptors so that we can detect drift between the two.  They are
intentionally lightweight for now and are expected to evolve alongside the
storage mapping.
"""

from __future__ import annotations

import logging
from typing import Iterable

from pymongo.synchronous.database import Database

from .collections import ENGINE_COLLECTIONS
from .indexes import ENGINE_INDEXES, CollectionIndexes

logger = logging.getLogger(__name__)


def validate_engine_storage(db: Database, *, strict: bool = True) -> None:
    """
    Validate that engine-domain collections and B-tree indexes roughly match
    the descriptors defined in code.

    Current behaviour:

    * Confirms that each collection in ``ENGINE_COLLECTIONS`` exists in
      ``db.list_collection_names()``.
    * Checks that every index name in ``ENGINE_INDEXES`` is present in the
      corresponding collection's ``index_information()``.

    In ``strict`` mode, missing collections or indexes raise ``RuntimeError``.
    In non-strict mode they are logged at WARNING level only.
    """

    existing_collections = set(db.list_collection_names())

    def _fail(msg: str) -> None:
        if strict:
            raise RuntimeError(msg)
        logger.warning(msg)

    # Collections
    for name in ENGINE_COLLECTIONS:
        if name not in existing_collections:
            _fail(f"Engine collection missing in database: {name}")

    # Indexes
    for ci in _iter_engine_index_groups():
        col = db[ci.collection_name]
        existing_indexes = set(col.index_information().keys())
        for index in ci.indexes:
            if index.name not in existing_indexes:
                _fail(f"Missing index {index.name} on collection {ci.collection_name}")


def _iter_engine_index_groups() -> Iterable[CollectionIndexes]:
    """Small indirection for tests."""

    return ENGINE_INDEXES.values()
