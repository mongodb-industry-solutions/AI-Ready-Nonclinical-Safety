"""
Plain text file extractor.

Handles .txt files using built-in Python file reading.
"""

import logging
from pathlib import Path
from typing import Any, Dict, Set

logger = logging.getLogger(__name__)


class PlainTextExtractor:
    """Plain text file extractor using built-in Python."""

    @property
    def supported_extensions(self) -> Set[str]:
        return {".txt"}

    def extract(self, file_path: Path) -> str:
        """Extract text from a plain text file."""
        try:
            return file_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            # Fallback to latin-1 for files with non-UTF8 encoding
            logger.warning(f"UTF-8 decode failed for {file_path}, trying latin-1")
            return file_path.read_text(encoding="latin-1")

    def extract_with_metadata(self, file_path: Path) -> Dict[str, Any]:
        """Extract text and metadata from a plain text file."""
        text = self.extract(file_path)
        stat = file_path.stat()

        return {
            "text": text,
            "metadata": {
                "source_type": "txt",
                "char_count": len(text),
                "line_count": text.count("\n") + 1,
                "file_size_bytes": stat.st_size,
            },
        }
