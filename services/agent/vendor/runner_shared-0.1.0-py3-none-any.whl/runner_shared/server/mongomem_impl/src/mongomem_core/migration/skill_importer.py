"""SKILL.md bidirectional migration utilities.

Import: Parse SKILL.md files into ProceduralIn models for ingestion.
Export: Render ProceduralOut documents back to SKILL.md format.
Discovery: Glob for SKILL.md files in a directory tree.
Batch: Ingest/export multiple skills in one call.

Round-trip is lossless for SKILL.md-native fields. mongomem extensions
(steps, tags, trigger_conditions, versioning, RBAC) are dropped on export
since they are our superset.
"""

from __future__ import annotations

import glob
import logging
import os
import re
from typing import Any, Dict, List, Literal, Optional, Tuple

import yaml
from mongomem_core.exceptions import DuplicateDocumentError
from mongomem_core.models.memory.procedural import (
    ProceduralIn,
    ProceduralOut,
    ProceduralResource,
)
from pymongo.errors import DuplicateKeyError

logger = logging.getLogger(__name__)

_FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)
_DEFAULT_SKILL_PATTERNS = ["**/SKILL.md", "**/.skill/SKILL.md"]


def parse_skill_md(path: str) -> ProceduralIn:
    """Parse a SKILL.md file into a ProceduralIn model.

    Maps SKILL.md fields to ProceduralIn:
      - name -> procedure
      - description -> description
      - body (markdown after frontmatter) -> content
      - allowed-tools (space-delimited string) -> allowed_tools (list)
      - compatibility -> compatibility
      - license -> license

    Also discovers scripts/, references/, assets/ directories relative to the
    SKILL.md file and creates ProceduralResource entries.

    Args:
        path: Path to the SKILL.md file

    Returns:
        ProceduralIn model ready for create/upsert

    Raises:
        FileNotFoundError: If the file does not exist
        ValueError: If the file cannot be parsed or is missing required fields
    """
    if not os.path.isfile(path):
        raise FileNotFoundError(f"SKILL.md not found: {path}")

    with open(path, "r", encoding="utf-8") as f:
        raw = f.read()

    frontmatter, body = _split_frontmatter(raw)
    if not frontmatter:
        raise ValueError(f"No YAML frontmatter found in {path}")

    name = frontmatter.get("name")
    if not name:
        raise ValueError(f"SKILL.md missing required 'name' field: {path}")

    description = frontmatter.get("description", "")
    if not description:
        raise ValueError(f"SKILL.md missing required 'description' field: {path}")

    allowed_tools_raw = frontmatter.get("allowed-tools")
    allowed_tools = None
    if allowed_tools_raw:
        if isinstance(allowed_tools_raw, str):
            allowed_tools = allowed_tools_raw.split()
        elif isinstance(allowed_tools_raw, list):
            allowed_tools = allowed_tools_raw

    resources = _discover_resources(os.path.dirname(path))

    return ProceduralIn(
        procedure=name,
        description=description,
        content=body.strip(),
        allowed_tools=allowed_tools,
        compatibility=frontmatter.get("compatibility"),
        license=frontmatter.get("license"),
        resources=resources if resources else None,
        source_format="skill.md",
        source_path=os.path.abspath(path),
    )


def to_skill_md(procedure: ProceduralOut) -> str:
    """Render a ProceduralOut document to SKILL.md format.

    Generates YAML frontmatter from procedure, description, license,
    compatibility, and allowed_tools. The body is the content field verbatim.

    mongomem extensions (steps, tags, trigger_conditions, versioning, RBAC)
    are dropped -- they are our superset over SKILL.md.

    Args:
        procedure: ProceduralOut document to export

    Returns:
        String in SKILL.md format (frontmatter + body)
    """
    frontmatter: Dict[str, Any] = {
        "name": procedure.procedure,
        "description": procedure.description,
    }

    if procedure.allowed_tools:
        frontmatter["allowed-tools"] = " ".join(procedure.allowed_tools)
    if procedure.compatibility:
        frontmatter["compatibility"] = procedure.compatibility
    if procedure.license:
        frontmatter["license"] = procedure.license

    yaml_str = yaml.dump(
        frontmatter,
        default_flow_style=False,
        sort_keys=False,
        allow_unicode=True,
    ).strip()

    return f"---\n{yaml_str}\n---\n\n{procedure.content}\n"


def discover_skills(
    root_dir: str,
    patterns: Optional[List[str]] = None,
) -> List[str]:
    """Find SKILL.md files in a directory tree.

    Args:
        root_dir: Root directory to search
        patterns: Glob patterns to match (default: ["**/SKILL.md", "**/.skill/SKILL.md"])

    Returns:
        List of absolute paths to discovered SKILL.md files
    """
    if patterns is None:
        patterns = _DEFAULT_SKILL_PATTERNS

    paths: List[str] = []
    for pattern in patterns:
        full_pattern = os.path.join(root_dir, pattern)
        paths.extend(glob.glob(full_pattern, recursive=True))

    unique = sorted(set(os.path.abspath(p) for p in paths))
    logger.info("Discovered %d SKILL.md files in %s", len(unique), root_dir)
    return unique


def ingest_skills(
    engine: Any,
    skill_paths: List[str],
    org_id: str,
    user_id: str,
    *,
    visibility: str = "private",
    project_id: Optional[str] = None,
    generate_embeddings: bool = True,
    skip_duplicates: bool = True,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Batch import SKILL.md files into procedural memory via the engine.

    Args:
        engine: MemoryEngine instance (with create_procedural method)
        skill_paths: List of paths to SKILL.md files
        org_id: Organization ID
        user_id: User ID
        visibility: Visibility scope for imported skills
        project_id: Project ID
        generate_embeddings: Whether to generate embeddings
        skip_duplicates: Whether to skip existing procedures
        tags: Optional tags to add to all imported procedures

    Returns:
        Dict with imported_count, skipped_count, errors, imported_procedures
    """
    imported = []
    skipped = []
    errors = []

    for path in skill_paths:
        try:
            procedural_in = parse_skill_md(path)

            extra_tags = list(tags) if tags else []
            if procedural_in.source_format:
                extra_tags.append(f"migrated:{procedural_in.source_format}")

            result = engine.create_procedural(
                procedure=procedural_in.procedure,
                description=procedural_in.description,
                content=procedural_in.content,
                org_id=org_id,
                user_id=user_id,
                allowed_tools=procedural_in.allowed_tools,
                compatibility=procedural_in.compatibility,
                license=procedural_in.license,
                tags=extra_tags if extra_tags else None,
                visibility=visibility,
                project_id=project_id,
                source_format=procedural_in.source_format,
                source_path=procedural_in.source_path,
                skip_embedding=not generate_embeddings,
                resources=[r.model_dump() for r in procedural_in.resources]
                if procedural_in.resources
                else None,
            )
            imported.append({"procedure": procedural_in.procedure, "id": result.id, "path": path})
            logger.info("Imported SKILL.md: %s -> %s", path, result.id)

        except (DuplicateDocumentError, DuplicateKeyError) as exc:
            if skip_duplicates:
                skipped.append({"path": path, "reason": str(exc)})
                logger.debug("Skipped duplicate SKILL.md: %s", path)
            else:
                errors.append({"path": path, "error": str(exc)})
                logger.warning("Failed to import SKILL.md: %s error=%s", path, exc)
        except Exception as exc:
            errors.append({"path": path, "error": str(exc)})
            logger.warning("Failed to import SKILL.md: %s error=%s", path, exc)

    logger.info(
        "SKILL.md ingestion complete: imported=%d skipped=%d errors=%d",
        len(imported),
        len(skipped),
        len(errors),
    )

    return {
        "imported_count": len(imported),
        "skipped_count": len(skipped),
        "error_count": len(errors),
        "imported_procedures": imported,
        "skipped": skipped,
        "errors": errors,
    }


def export_skills(
    engine: Any,
    org_id: str,
    output_dir: str,
    *,
    user_id: Optional[str] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Batch export procedural memories to SKILL.md files on disk.

    Args:
        engine: MemoryEngine instance
        org_id: Organization ID
        output_dir: Directory to write SKILL.md files
        user_id: Optional user ID filter
        tags: Optional tag filter

    Returns:
        Dict with exported_count, exported_procedures, errors
    """
    os.makedirs(output_dir, exist_ok=True)

    procedures = engine.list_procedural(org_id=org_id, user_id=user_id, tags=tags)
    exported = []
    errors = []

    for proc in procedures:
        try:
            skill_content = to_skill_md(proc)
            skill_dir = os.path.join(output_dir, proc.procedure)
            os.makedirs(skill_dir, exist_ok=True)

            skill_path = os.path.join(skill_dir, "SKILL.md")
            with open(skill_path, "w", encoding="utf-8") as f:
                f.write(skill_content)

            exported.append({"procedure": proc.procedure, "path": skill_path})
            logger.info("Exported procedure to SKILL.md: %s -> %s", proc.procedure, skill_path)
        except Exception as exc:
            errors.append({"procedure": proc.procedure, "error": str(exc)})
            logger.warning("Failed to export procedure: %s error=%s", proc.procedure, exc)

    logger.info(
        "SKILL.md export complete: exported=%d errors=%d",
        len(exported),
        len(errors),
    )

    return {
        "exported_count": len(exported),
        "exported_procedures": exported,
        "error_count": len(errors),
        "errors": errors,
    }


def _split_frontmatter(raw: str) -> Tuple[Optional[Dict[str, Any]], str]:
    """Split YAML frontmatter from markdown body.

    Returns:
        Tuple of (parsed_frontmatter_dict_or_None, body_string)
    """
    match = _FRONTMATTER_RE.match(raw)
    if not match:
        return None, raw

    yaml_str = match.group(1)
    body = raw[match.end() :]

    try:
        frontmatter = yaml.safe_load(yaml_str)
        if not isinstance(frontmatter, dict):
            return None, raw
        return frontmatter, body
    except yaml.YAMLError as exc:
        logger.warning("Failed to parse YAML frontmatter: %s", exc)
        return None, raw


def _discover_resources(skill_dir: str) -> List[ProceduralResource]:
    """Discover scripts/, references/, and assets/ relative to a SKILL.md file."""
    resources: List[ProceduralResource] = []

    ResourceType = Literal["script", "reference", "asset"]
    type_map: Dict[str, ResourceType] = {
        "scripts": "script",
        "references": "reference",
        "assets": "asset",
    }

    for dir_name, resource_type in type_map.items():
        dir_path = os.path.join(skill_dir, dir_name)
        if not os.path.isdir(dir_path):
            continue

        for root, _, files in os.walk(dir_path):
            for file_name in sorted(files):
                file_path = os.path.join(root, file_name)
                rel_path = os.path.relpath(file_path, skill_dir)

                ext = os.path.splitext(file_name)[1].lower()
                language = _ext_to_language(ext) if resource_type == "script" else None

                content = None
                try:
                    file_size = os.path.getsize(file_path)
                    if file_size < 50_000:
                        with open(file_path, "r", encoding="utf-8") as f:
                            content = f.read()
                except (OSError, UnicodeDecodeError):
                    pass

                resources.append(
                    ProceduralResource(
                        path=rel_path,
                        resource_type=resource_type,
                        content=content,
                        language=language,
                        description=f"{resource_type}: {file_name}",
                    )
                )

    return resources


def _ext_to_language(ext: str) -> Optional[str]:
    """Map file extension to programming language."""
    mapping = {
        ".py": "python",
        ".js": "javascript",
        ".ts": "typescript",
        ".sh": "bash",
        ".bash": "bash",
        ".sql": "sql",
        ".rb": "ruby",
        ".go": "go",
        ".rs": "rust",
        ".java": "java",
        ".r": "r",
    }
    return mapping.get(ext)
