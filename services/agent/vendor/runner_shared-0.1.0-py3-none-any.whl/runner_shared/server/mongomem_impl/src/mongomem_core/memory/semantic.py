"""CRUD and invariants for semantic memory.

Semantic memory stores user-provided knowledge chunks with embeddings for vector
search. Each document represents a labeled piece of knowledge that can be
retrieved based on semantic similarity.

All functions operate synchronously against MongoDB and expect the caller to
provide necessary context (org_id, user_id, etc.).
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Sequence, Tuple, Union, overload

from bson import ObjectId
from mongomem_core.common.utils import (
    format_document_identifier,
    handle_db_error,
    handle_duplicate_key_error,
    to_object_id,
    utcnow,
)
from mongomem_core.exceptions import (
    DatabaseOperationError,
    DocumentNotFoundError,
)
from mongomem_core.memory.base import (
    BaseDocumentBuilder,
    BaseQueryBuilder,
    BaseUpdateFieldBuilder,
    doc_to_output,
    execute_vector_search,
    handle_empty_sequence,
)
from mongomem_core.models.filters import MetadataFilter
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.semantic import (
    SemanticDB,
    SemanticIn,
    SemanticOut,
    SemanticUpdate,
)
from mongomem_core.models.types import PyObjectId
from mongomem_core.storage import get_collection
from mongomem_core.storage.collections import SemanticMemoryCollection
from mongomem_core.storage.search_indexes import SEMANTIC_VECTOR_INDEX
from pymongo import ReturnDocument
from pymongo.database import Database
from pymongo.errors import BulkWriteError, DuplicateKeyError
from pymongo.results import DeleteResult, InsertManyResult, UpdateResult

logger = logging.getLogger(__name__)

_SEMANTIC_COL = SemanticMemoryCollection()


def _build_semantic_query_filter(
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    label: Optional[str] = None,
    project_id: Optional[str] = None,
    user_id: Optional[str] = None,
    visibility: Optional[str] = None,
    include_deleted: bool = False,
) -> Tuple[Dict[str, Any], str]:
    """
    Build a MongoDB query filter and identifier string for semantic lookups.

    Supports lookup by ID or by label.

    Args:
        org_id: Organization ID
        id: Document ID (string or ObjectId) - mutually exclusive with label
        label: Label identifier (unique within org) - mutually exclusive with id
        project_id: Optional project ID to bind lookups to a project
        include_deleted: If True, include soft-deleted documents

    Returns:
        Tuple of (query_filter_dict, identifier_string)

    Raises:
        ValueError: If neither id nor label is provided, or both are provided.
    """
    if (id is None) == (label is None):
        raise ValueError("Exactly one of 'id' or 'label' must be provided")

    if id is not None:
        q_filter, identifier = BaseQueryBuilder.build_id_filter(
            org_id, id, include_deleted=include_deleted
        )
    else:
        q_filter = {"label": label, "org_id": org_id}
        identifier = format_document_identifier(label=label)
        if not include_deleted:
            q_filter["deleted"] = {"$ne": True}

    if project_id is not None:
        q_filter["project_id"] = project_id
    if user_id is not None:
        q_filter["user_id"] = user_id
    if visibility is not None:
        q_filter["visibility"] = visibility

    return q_filter, identifier


def _build_semantic_doc(
    semantic_in: SemanticIn,
    org_id: str,
    user_id: str,
    timestamp: datetime,
    *,
    embedding: Optional[List[float]] = None,
    embedding_model_id: Optional[str] = None,
    extraction_id: Optional[str] = None,
) -> SemanticDB:
    """Build a SemanticDB document from input.

    Args:
        semantic_in: Input model with semantic memory data
        org_id: Organization ID
        user_id: User ID of the creator
        timestamp: Timestamp for the document
        embedding: Pre-computed embedding vector (if any)
        embedding_model_id: Model used to generate embedding
        extraction_id: Optional extraction ID for idempotency

    Returns:
        A SemanticDB document (not yet persisted)
    """
    return BaseDocumentBuilder.build_memory_document(
        semantic_in,
        SemanticDB,
        org_id,
        user_id,
        timestamp,
        embedding=embedding,
        embedding_model_id=embedding_model_id,
        extraction_id=extraction_id,
        embedding_config={
            "model_id_field": "embedding_model_id",
            "log_context": f"label={semantic_in.label}",
        },
        updated_at=timestamp,
    )


def create_semantic(
    db: Database,
    semantic_in: SemanticIn,
    org_id: str,
    user_id: str,
    *,
    embedding: Optional[List[float]] = None,
    embedding_model_id: Optional[str] = None,
    extraction_id: Optional[str] = None,
) -> SemanticDB:
    """
    Create a semantic memory document.

    The document's memory_lineage_id is set to the document ID before insertion
    to enable versioning and prevent unique index violations.

    Args:
        db: MongoDB database instance
        semantic_in: Input model with semantic memory data
        org_id: Organization ID
        user_id: User ID of the creator
        embedding: Pre-computed embedding vector (if any)
        embedding_model_id: Model used to generate embedding
        extraction_id: Optional extraction ID for idempotency (SHA-256 hash)

    Returns:
        The created SemanticDB document

    Raises:
        DuplicateDocumentError: If label already exists in org (unique constraint).
        DatabaseOperationError: If the insert operation fails.

    Example:
        >>> from mongomem_core.storage import get_database
        >>> from mongomem_core.models.memory.semantic import SemanticIn
        >>> db = get_database()
        >>> semantic = SemanticIn(
        ...     label="python_basics",
        ...     content="Python is a high-level programming language."
        ... )
        >>> doc = create_semantic(db, semantic, org_id="org_1", user_id="user_1")
    """
    logger.debug(
        "Creating semantic memory document: label=%s org=%s user=%s",
        semantic_in.label,
        org_id,
        user_id,
    )

    now = utcnow()
    doc = _build_semantic_doc(
        semantic_in,
        org_id,
        user_id,
        now,
        embedding=embedding,
        embedding_model_id=embedding_model_id,
        extraction_id=extraction_id,
    )

    col = get_collection(_SEMANTIC_COL, db)
    doc.memory_lineage_id = str(doc.id)

    try:
        with handle_db_error(
            operation="insert_one",
            collection=_SEMANTIC_COL.name,
            log_message="Failed to create semantic document: label=%s org=%s",
            log_args_tuple=(semantic_in.label, org_id),
        ):
            col.insert_one(doc.model_dump(by_alias=True))

            logger.debug(
                "Created semantic document: id=%s label=%s org=%s",
                doc.id,
                semantic_in.label,
                org_id,
            )
            return doc
    except DuplicateKeyError as exc:
        handle_duplicate_key_error(
            exc,
            collection_name=_SEMANTIC_COL.name,
            log_message="Duplicate semantic document detected: label=%s org=%s",
            log_args=(semantic_in.label, org_id),
            details={
                "label": semantic_in.label,
                "org_id": org_id,
            },
        )


def bulk_create_semantic(
    db: Database,
    items: List[SemanticIn],
    org_id: str,
    user_id: str,
    *,
    embeddings: Optional[List[List[float]]] = None,
    embedding_model_id: Optional[str] = None,
    skip_duplicates: bool = True,
) -> Tuple[List[SemanticDB], List[str]]:
    """
    Bulk create multiple semantic memory documents using insert_many.

    Uses MongoDB's insert_many with ordered=False for efficient bulk insertion
    in a single round trip. Handles duplicate key errors gracefully.

    Args:
        db: MongoDB database instance
        items: List of SemanticIn models to create
        org_id: Organization ID
        user_id: User ID of the creator
        embeddings: Optional list of pre-computed embeddings (one per item)
        embedding_model_id: Model used to generate embeddings
        skip_duplicates: If True, skip duplicate labels instead of failing

    Returns:
        Tuple of (created_docs, skipped_labels):
        - created_docs: List of successfully created SemanticDB documents
        - skipped_labels: List of labels that were skipped due to duplicates

    Raises:
        DatabaseOperationError: If the bulk insert operation fails.
        DuplicateKeyError: If skip_duplicates=False and duplicates exist.

    Example:
        >>> items = [
        ...     SemanticIn(label="fact-1", content="Python is great"),
        ...     SemanticIn(label="fact-2", content="Rust is fast"),
        ... ]
        >>> created, skipped = bulk_create_semantic(
        ...     db, items, org_id="org_1", user_id="user_1"
        ... )
    """
    if not items:
        return [], []

    logger.debug(
        "Bulk creating %d semantic documents for org=%s user=%s",
        len(items),
        org_id,
        user_id,
    )

    col = get_collection(_SEMANTIC_COL, db)
    now = utcnow()

    # Build all documents with pre-generated ObjectIds
    # This is required because there's a unique index on (memory_lineage_id, is_latest)
    # and all docs would have memory_lineage_id=None initially, causing conflicts
    docs_to_insert: List[SemanticDB] = []
    label_to_doc: Dict[str, SemanticDB] = {}

    for i, item in enumerate(items):
        embedding = embeddings[i] if embeddings and i < len(embeddings) else None
        doc = _build_semantic_doc(
            item,
            org_id,
            user_id,
            now,
            embedding=embedding,
            embedding_model_id=embedding_model_id,
        )
        # Pre-generate ObjectId and set memory_lineage_id to avoid unique index conflicts
        doc.id = PyObjectId()
        doc.memory_lineage_id = str(doc.id)

        docs_to_insert.append(doc)
        label_to_doc[item.label] = doc

    # Convert to dicts for insert_many
    docs_dicts = [doc.model_dump(by_alias=True) for doc in docs_to_insert]

    created_docs: List[SemanticDB] = []
    skipped_labels: List[str] = []

    try:
        # ordered=False allows all non-duplicate inserts to succeed
        result: InsertManyResult = col.insert_many(docs_dicts, ordered=False)

        # Map inserted IDs back to docs
        for i, inserted_id in enumerate(result.inserted_ids):
            docs_to_insert[i].id = inserted_id
            created_docs.append(docs_to_insert[i])

    except BulkWriteError as bwe:
        if not skip_duplicates:
            # Re-raise as DatabaseOperationError for consistency
            raise DatabaseOperationError(
                f"Bulk insert failed with duplicates: {bwe}",
                operation="insert_many",
                collection=_SEMANTIC_COL.name,
                details={"org_id": org_id, "count": len(items)},
            ) from bwe

        # Extract successfully inserted docs
        write_errors = bwe.details.get("writeErrors", [])
        error_indices = {e["index"] for e in write_errors}

        # Collect skipped labels from errors (duplicate key errors have code 11000)
        for error in write_errors:
            if error.get("code") == 11000:  # Duplicate key error
                idx = error["index"]
                if idx < len(items):
                    skipped_labels.append(items[idx].label)
                    logger.debug(
                        "Skipping duplicate semantic document: label=%s org=%s",
                        items[idx].label,
                        org_id,
                    )

        # Collect successfully inserted docs (those not in error_indices)
        for i, doc in enumerate(docs_to_insert):
            if i not in error_indices:
                created_docs.append(doc)

    except Exception as exc:
        logger.error(
            "Failed to bulk create semantic documents: count=%d org=%s error=%s",
            len(items),
            org_id,
            exc,
        )
        raise DatabaseOperationError(
            f"Bulk insert failed: {exc}",
            operation="insert_many",
            collection=_SEMANTIC_COL.name,
            details={"org_id": org_id, "count": len(items)},
        ) from exc

    logger.info(
        "Bulk created %d/%d semantic documents for org=%s (skipped=%d duplicates)",
        len(created_docs),
        len(items),
        org_id,
        len(skipped_labels),
    )

    return created_docs, skipped_labels


def upsert_semantic(
    db: Database,
    semantic_in: SemanticIn,
    org_id: str,
    user_id: str,
    *,
    embedding: Optional[List[float]] = None,
    embedding_model_id: Optional[str] = None,
    extraction_id: Optional[str] = None,
) -> SemanticOut:
    """
    Create or update a semantic memory document by label.

    If a document with the same label exists in the organization, it will be updated.
    Otherwise, a new document will be created.

    Args:
        db: MongoDB database instance
        semantic_in: Input model with semantic memory data
        org_id: Organization ID
        user_id: User ID of the creator
        embedding: Pre-computed embedding vector (if any)
        embedding_model_id: Model used to generate embedding
        extraction_id: Optional extraction ID for idempotency (SHA-256 hash)

    Returns:
        The created or updated SemanticOut document

    Raises:
        DatabaseOperationError: If the upsert operation fails.

    Example:
        >>> from mongomem_core.storage import get_database
        >>> from mongomem_core.models.memory.semantic import SemanticIn
        >>> db = get_database()
        >>> semantic = SemanticIn(
        ...     label="python_basics",
        ...     content="Python is a high-level programming language."
        ... )
        >>> doc = upsert_semantic(db, semantic, org_id="org_1", user_id="user_1")
    """
    logger.debug(
        "Upserting semantic memory document: label=%s org=%s user=%s",
        semantic_in.label,
        org_id,
        user_id,
    )

    col = get_collection(_SEMANTIC_COL, db)
    now = utcnow()

    doc = _build_semantic_doc(
        semantic_in,
        org_id,
        user_id,
        now,
        embedding=embedding,
        embedding_model_id=embedding_model_id,
        extraction_id=extraction_id,
    )

    update_doc = doc.model_dump(
        by_alias=True, exclude={"id", "_id", "timestamp", "memory_lineage_id"}
    )
    update_doc["updated_at"] = now

    new_id = doc.id
    set_on_insert = {
        "_id": new_id,
        "memory_lineage_id": str(new_id),
        "timestamp": now,
    }

    with handle_db_error(
        operation="find_one_and_update",
        collection=_SEMANTIC_COL.name,
        log_message="Failed to upsert semantic document: label=%s org=%s",
        log_args_tuple=(semantic_in.label, org_id),
    ):
        result = col.find_one_and_update(
            {"label": semantic_in.label, "org_id": org_id, "deleted": {"$ne": True}},
            {
                "$set": update_doc,
                "$setOnInsert": set_on_insert,
            },
            upsert=True,
            return_document=ReturnDocument.AFTER,
        )

        if not result:
            logger.error(
                "Upsert returned None despite upsert=True: label=%s org=%s",
                semantic_in.label,
                org_id,
                exc_info=True,
            )
            raise DatabaseOperationError(
                "Upsert operation failed unexpectedly",
                operation="find_one_and_update",
                collection=_SEMANTIC_COL.name,
                details={"org_id": org_id, "label": semantic_in.label},
            )

        result["_id"] = str(result["_id"])
        logger.debug(
            "Upserted semantic document: id=%s label=%s org=%s",
            result["_id"],
            semantic_in.label,
            org_id,
        )
        return SemanticOut.model_validate(result)


def get_semantic(
    db: Database,
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    label: Optional[str] = None,
    project_id: Optional[str] = None,
    user_id: Optional[str] = None,
    visibility: Optional[str] = None,
    include_deleted: bool = False,
) -> Optional[SemanticOut]:
    """
    Fetch a single semantic memory document by ID or label.

    Either `id` or `label` must be provided, but not both.

    Args:
        db: MongoDB database instance
        org_id: Organization ID (for access control)
        id: Document ID (string or ObjectId) - mutually exclusive with label
        label: Label identifier (unique within org) - mutually exclusive with id
        project_id: Optional project ID to bind lookups to a project
        include_deleted: If True, include soft-deleted documents

    Returns:
        SemanticOut if found, None otherwise.

    Raises:
        ValueError: If neither id nor label is provided, or both are provided.
        ValidationError: If id is not a valid ObjectId format.
        DatabaseOperationError: If the query fails.

    Example:
        >>> # Get by ID
        >>> doc = get_semantic(db, org_id="org_1", id="507f1f77bcf86cd799439011")
        >>> # Get by label
        >>> doc = get_semantic(db, org_id="org_1", label="python_basics")
    """
    q_filter, identifier = _build_semantic_query_filter(
        org_id,
        id=id,
        label=label,
        project_id=project_id,
        user_id=user_id,
        visibility=visibility,
        include_deleted=include_deleted,
    )

    col = get_collection(_SEMANTIC_COL, db)

    with handle_db_error(
        operation="find_one",
        collection=_SEMANTIC_COL.name,
        log_message="Failed to retrieve semantic document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        doc = col.find_one(q_filter)
        if not doc:
            logger.debug("Semantic document not found: %s org=%s", identifier, org_id)
            return None

        doc["_id"] = str(doc["_id"])
        logger.debug("Retrieved semantic document: %s", identifier)
        return SemanticOut.model_validate(doc)


def list_semantic(
    db: Database,
    org_id: str,
    *,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    include_deleted: bool = False,
    before: Optional[datetime] = None,
    limit: Optional[int] = None,
    sort_by: str = "updated_at",
    sort_descending: bool = True,
) -> List[SemanticOut]:
    """
    List semantic memory documents for an organization with optional filters and pagination.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        user_id: Optional filter by user ID
        visibility: Optional filter by visibility scope
        project_id: Optional filter by group ID (for shared visibility)
        include_deleted: If True, include soft-deleted documents
        before: Optional cursor - fetch documents before this timestamp (for pagination)
        limit: Optional limit on number of results
        sort_by: Field to sort by (default: "updated_at")
        sort_descending: If True, sort descending (newest first)

    Returns:
        List of SemanticOut documents

    Raises:
        DatabaseOperationError: If the query fails.

    Example:
        >>> # Get all documents for org
        >>> docs = list_semantic(db, org_id="org_1")
        >>> # Get latest 10 documents with pagination
        >>> docs = list_semantic(db, org_id="org_1", limit=10, before=some_timestamp)
        >>> # Filter by user and visibility
        >>> docs = list_semantic(db, org_id="org_1", user_id="user_1", visibility=ChunkVisibility.SHARED)
    """
    col = get_collection(_SEMANTIC_COL, db)

    q_filter = BaseQueryBuilder.build_list_filter(
        org_id,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        before=before,
        include_deleted=include_deleted,
        timestamp_field="updated_at",
    )

    sort_direction = -1 if sort_descending else 1

    with handle_db_error(
        operation="find",
        collection=_SEMANTIC_COL.name,
        log_message="Failed to retrieve semantic documents for org=%s",
        log_args_tuple=(org_id,),
    ):
        cursor = col.find(q_filter).sort(sort_by, sort_direction)
        if limit and limit > 0:
            cursor = cursor.limit(limit)
        results = [doc_to_output(d, SemanticOut) for d in cursor]
        logger.debug(
            "Retrieved %d semantic documents for org=%s",
            len(results),
            org_id,
        )
        return results


def _build_update_fields(update: SemanticUpdate) -> Dict[str, Any]:
    """Build MongoDB update fields from SemanticUpdate model."""
    return BaseUpdateFieldBuilder.build_update_fields(
        update,
        field_mappings={
            "content": "content",
            "source": "source",
            "contextual_metadata": "contextual_metadata",
            "embedding_model_id": "embedding_model_id",
        },
    )


def update_semantic(
    db: Database,
    org_id: str,
    update: SemanticUpdate,
    *,
    id: Optional[str | ObjectId] = None,
    label: Optional[str] = None,
) -> SemanticOut:
    """
    Update a semantic memory document by ID or label.

    Either `id` or `label` must be provided, but not both.

    Args:
        db: MongoDB database instance
        org_id: Organization ID (for access control)
        update: Update model with fields to modify
        id: Document ID (string or ObjectId) - mutually exclusive with label
        label: Label identifier (unique within org) - mutually exclusive with id

    Returns:
        Updated SemanticOut document

    Raises:
        ValueError: If neither id nor label is provided, or both are provided.
        ValidationError: If id is not a valid ObjectId format.
        DocumentNotFoundError: If the document doesn't exist.
        DatabaseOperationError: If the update operation fails.

    Example:
        >>> # Update by ID
        >>> update = SemanticUpdate(content="Updated text")
        >>> doc = update_semantic(db, org_id="org_1", update=update, id="507f1f77bcf86cd799439011")
        >>> # Update by label
        >>> doc = update_semantic(db, org_id="org_1", update=update, label="python_basics")
    """
    col = get_collection(_SEMANTIC_COL, db)

    update_fields = _build_update_fields(update)

    if not update_fields:
        if id is not None:
            doc = get_semantic(db, org_id, id=id)
        else:
            doc = get_semantic(db, org_id, label=label)
        if not doc:
            _, identifier = _build_semantic_query_filter(
                org_id, id=id, label=label, include_deleted=True
            )
            raise DocumentNotFoundError(
                "Semantic document not found",
                collection=_SEMANTIC_COL.name,
                document_id=str(id) if id else None,
                details={"org_id": org_id, "identifier": identifier},
            )
        return doc

    update_fields["updated_at"] = utcnow()

    q_filter, identifier = _build_semantic_query_filter(
        org_id,
        id=id,
        label=label,
        include_deleted=False,
    )

    with handle_db_error(
        operation="find_one_and_update",
        collection=_SEMANTIC_COL.name,
        log_message="Failed to update semantic document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result_doc = col.find_one_and_update(
            q_filter,
            {"$set": update_fields},
            return_document=ReturnDocument.AFTER,
        )

        if not result_doc:
            raise DocumentNotFoundError(
                "Semantic document not found or is deleted",
                collection=_SEMANTIC_COL.name,
                document_id=str(id) if id else None,
                details={"org_id": org_id, "identifier": identifier},
            )

        logger.debug("Updated semantic document: %s org=%s", identifier, org_id)
        return SemanticOut.model_validate({**result_doc, "_id": str(result_doc["_id"])})


def update_semantic_embedding(
    db: Database,
    semantic_id: str | ObjectId,
    org_id: str,
    embedding: List[float],
    embedding_model_id: Optional[str] = None,
) -> UpdateResult:
    """
    Update the embedding on an existing semantic memory document.

    Args:
        db: MongoDB database instance
        semantic_id: Document ID
        org_id: Organization ID
        embedding: The embedding vector
        embedding_model_id: Optional model identifier

    Returns:
        UpdateResult from MongoDB

    Raises:
        ValidationError: If semantic_id is not a valid ObjectId format.
        DatabaseOperationError: If the update operation fails.
    """
    col = get_collection(_SEMANTIC_COL, db)
    oid = to_object_id(semantic_id)

    update_fields: Dict[str, Any] = {
        "embedding": embedding,
        "has_embedding": True,
        "updated_at": utcnow(),
    }
    if embedding_model_id:
        update_fields["embedding_model_id"] = embedding_model_id

    with handle_db_error(
        operation="update_one",
        collection=_SEMANTIC_COL.name,
        log_message="Failed to update embedding for semantic document: id=%s org=%s",
        log_args_tuple=(str(semantic_id), org_id),
    ):
        result = col.update_one(
            {"_id": oid, "org_id": org_id, "deleted": {"$ne": True}},
            {"$set": update_fields},
        )
        if result.modified_count > 0:
            logger.debug(
                "Updated embedding for semantic document: id=%s model=%s",
                semantic_id,
                embedding_model_id,
            )
        else:
            logger.warning(
                "No semantic document modified for embedding update: id=%s org=%s",
                semantic_id,
                org_id,
            )
        return result


def soft_delete_semantic(
    db: Database,
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    label: Optional[str] = None,
) -> UpdateResult:
    """
    Soft delete a semantic memory document by ID or label.

    Sets the deleted flag and deleted_at timestamp without removing the document.
    Either `id` or `label` must be provided, but not both.

    Args:
        db: MongoDB database instance
        org_id: Organization ID (for access control)
        id: Document ID (string or ObjectId) - mutually exclusive with label
        label: Label identifier (unique within org) - mutually exclusive with id

    Returns:
        UpdateResult from MongoDB

    Raises:
        ValueError: If neither id nor label is provided, or both are provided.
        ValidationError: If id is not a valid ObjectId format.
        DatabaseOperationError: If the update operation fails.

    Example:
        >>> # Soft delete by ID
        >>> result = soft_delete_semantic(db, org_id="org_1", id="507f1f77bcf86cd799439011")
        >>> # Soft delete by label
        >>> result = soft_delete_semantic(db, org_id="org_1", label="python_basics")
    """
    q_filter, identifier = _build_semantic_query_filter(
        org_id,
        id=id,
        label=label,
        include_deleted=True,  # Allow re-deleting
    )
    # Remove the deleted filter since we want to include deleted docs
    q_filter.pop("deleted", None)

    col = get_collection(_SEMANTIC_COL, db)
    now = utcnow()
    with handle_db_error(
        operation="update_one",
        collection=_SEMANTIC_COL.name,
        log_message="Failed to soft delete semantic document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result = col.update_one(
            q_filter,
            {"$set": {"deleted": True, "deleted_at": now, "updated_at": now}},
        )
        if result.modified_count > 0:
            logger.debug("Soft deleted semantic document: %s org=%s", identifier, org_id)
        else:
            logger.warning(
                "No semantic document modified for soft delete: %s org=%s",
                identifier,
                org_id,
            )
        return result


def delete_semantic(
    db: Database,
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    label: Optional[str] = None,
) -> DeleteResult:
    """
    Hard delete a semantic memory document by ID or label.

    Permanently removes the document from the database.
    Either `id` or `label` must be provided, but not both.

    Args:
        db: MongoDB database instance
        org_id: Organization ID (for access control)
        id: Document ID (string or ObjectId) - mutually exclusive with label
        label: Label identifier (unique within org) - mutually exclusive with id

    Returns:
        DeleteResult from MongoDB

    Raises:
        ValueError: If neither id nor label is provided, or both are provided.
        ValidationError: If id is not a valid ObjectId format.
        DatabaseOperationError: If the delete operation fails.

    Example:
        >>> # Delete by ID
        >>> result = delete_semantic(db, org_id="org_1", id="507f1f77bcf86cd799439011")
        >>> # Delete by label
        >>> result = delete_semantic(db, org_id="org_1", label="python_basics")
    """
    q_filter, identifier = _build_semantic_query_filter(
        org_id,
        id=id,
        label=label,
        include_deleted=True,  # Don't filter by deleted status for hard delete
    )
    # Remove the deleted filter since we want to delete regardless of deleted status
    q_filter.pop("deleted", None)

    col = get_collection(_SEMANTIC_COL, db)

    with handle_db_error(
        operation="delete_one",
        collection=_SEMANTIC_COL.name,
        log_message="Failed to delete semantic document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result = col.delete_one(q_filter)
        logger.debug(
            "Deleted semantic document: %s org=%s (deleted_count=%d)",
            identifier,
            org_id,
            result.deleted_count,
        )
        return result


def delete_semantic_by_ids(
    db: Database,
    semantic_ids: Sequence[str | ObjectId],
    org_id: str,
) -> DeleteResult:
    """
    Hard delete multiple semantic memory documents by ID.

    Args:
        db: MongoDB database instance
        semantic_ids: List of document IDs to delete
        org_id: Organization ID (for access control)

    Returns:
        DeleteResult from MongoDB. If an empty sequence is provided, returns a
        result with deleted_count=0 (idempotent operation - no database call is made).

    Raises:
        ValidationError: If any semantic_id is not a valid ObjectId format.
        DatabaseOperationError: If the delete operation fails.

    Note:
        Empty sequences are handled idempotently: the function returns immediately
        with a DeleteResult indicating 0 deletions, matching MongoDB's behavior
        for delete_many operations with empty $in arrays.
    """
    early_return = handle_empty_sequence(semantic_ids, "delete_semantic_by_ids", DeleteResult)
    if early_return is not None:
        return early_return  # type: ignore[return-value]

    col = get_collection(_SEMANTIC_COL, db)
    oids = [to_object_id(sid) for sid in semantic_ids]

    with handle_db_error(
        operation="delete_many",
        collection=_SEMANTIC_COL.name,
        log_message="Failed to delete semantic documents: count=%d org=%s",
        log_args_tuple=(len(semantic_ids), org_id),
    ):
        result = col.delete_many({"_id": {"$in": oids}, "org_id": org_id})
        logger.info(
            "Deleted %d semantic documents (requested=%d, org=%s)",
            result.deleted_count,
            len(semantic_ids),
            org_id,
        )
        return result


@overload
def search_semantic(
    db: Database,
    query_embedding: List[float],
    org_id: str,
    *,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    return_format: Literal["model"] = "model",
    include_deleted: bool = False,
    index_name: Optional[str] = None,
    is_latest: Optional[bool] = None,
    metadata_filter: Optional[MetadataFilter] = None,
) -> List[SemanticOut]: ...


@overload
def search_semantic(
    db: Database,
    query_embedding: List[float],
    org_id: str,
    *,
    user_id: str,  # Required for dict format
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    return_format: Literal["dict"],
    include_deleted: bool = False,
    index_name: Optional[str] = None,
    is_latest: Optional[bool] = True,
    metadata_filter: Optional[MetadataFilter] = None,
) -> List[Dict[str, Any]]: ...


def search_semantic(
    db: Database,
    query_embedding: List[float],
    org_id: str,
    *,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    return_format: Literal["model", "dict"] = "model",
    include_deleted: bool = False,
    index_name: Optional[str] = None,
    is_latest: Optional[bool] = None,
    metadata_filter: Optional[MetadataFilter] = None,
) -> Union[List[SemanticOut], List[Dict[str, Any]]]:
    """
    Unified vector search for semantic memories.

    This function replaces both `vector_search_semantic` and the old `search_semantic`.
    It supports two return formats:
    - `"model"`: Returns `List[SemanticOut]` (default, for retrieval use cases)
    - `"dict"`: Returns `List[Dict[str, Any]]` (for extraction pipeline use cases)

    Uses the index defined by ``SEMANTIC_VECTOR_INDEX`` by default, or a custom
    index name if provided. Includes retry logic for when the vector index is not ready yet.

    Args:
        db: MongoDB database instance
        query_embedding: Query embedding vector for similarity search
        org_id: Organization ID (required)
        user_id: Optional filter by user ID. Required when return_format="dict"
        visibility: Optional filter by visibility scope
        project_id: Optional filter by group ID (for shared visibility)
        top_k: Maximum number of results to return (default: 50)
        similarity_threshold: Minimum similarity score threshold (default: 0.0)
        return_format: Output format - "model" returns SemanticOut objects,
            "dict" returns dictionaries with extraction-specific fields (default: "model")
        include_deleted: If True, include soft-deleted documents (default: False)
        index_name: Optional custom index name. Defaults to SEMANTIC_VECTOR_INDEX.name
        is_latest: Optional filter for latest versions only. Defaults to True when
            return_format="dict", None otherwise (no filter)
        metadata_filter: Optional user-provided metadata filter for field-level filtering.
            Applied after RBAC filters. See MetadataFilter for usage.

    Returns:
        List of SemanticOut documents (return_format="model") or List of dicts
        with id, text, label, score, version, memory_lineage_id, confidence_score,
        reinforcement_count fields (return_format="dict")

    Raises:
        ValueError: If return_format="dict" but user_id is not provided, or if org_id is empty
        DatabaseOperationError: If the vector search operation fails after retries

    Example:
        >>> from mongomem_core.storage import get_database
        >>> from mongomem_core.models.filters import MetadataFilter
        >>> db = get_database()
        >>> query_emb = [0.1, 0.2, ...]  # 1536-dimensional vector
        >>>
        >>> # Basic search
        >>> results = search_semantic(
        ...     db, query_embedding=query_emb, org_id="org_1",
        ...     top_k=10, similarity_threshold=0.3
        ... )
        >>>
        >>> # With metadata filter
        >>> results = search_semantic(
        ...     db, query_embedding=query_emb, org_id="org_1",
        ...     metadata_filter=MetadataFilter(raw={"label": "python_basics"})
        ... )
    """
    if not org_id:
        raise ValueError("org_id is required")

    col = get_collection(_SEMANTIC_COL, db)

    # Determine index name
    effective_index_name = index_name or SEMANTIC_VECTOR_INDEX.name

    # Build base RBAC filter
    rbac_filter = BaseQueryBuilder.build_base_filter(
        org_id,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        include_deleted=include_deleted,
    )

    # Add is_latest filter to rbac_filter (internal system filter)
    if return_format == "dict":
        if user_id is None:
            raise ValueError("user_id is required when return_format='dict'")

        if is_latest is not None:
            rbac_filter["is_latest"] = is_latest
        else:
            # Default to True for dict format
            rbac_filter["is_latest"] = True
    elif is_latest is not None:
        # Allow is_latest filter even in model format
        rbac_filter["is_latest"] = is_latest

    # Build projection based on return format
    projection: Optional[Dict[str, Any]] = None
    if return_format == "dict":
        # Extraction-specific projection
        projection = {
            "_id": 1,
            "content": 1,
            "label": 1,
            "version": 1,
            "memory_lineage_id": 1,
            "confidence_score": 1,
            "reinforcement_count": 1,
            "score": {"$meta": "vectorSearchScore"},
        }

    # Execute vector search
    results = execute_vector_search(
        col,
        index_name=effective_index_name,
        query_embedding=query_embedding,
        rbac_filter=rbac_filter,
        collection_name=_SEMANTIC_COL.name,
        org_id=org_id,
        top_k=top_k,
        similarity_threshold=similarity_threshold,
        metadata_filter=metadata_filter,
        projection=projection,
    )

    # Parse results based on return format
    if return_format == "dict":
        # Normalize to extraction-specific dict format
        normalized = []
        for doc in results:
            normalized.append(
                {
                    "id": str(doc["_id"]),
                    "text": doc.get("content", ""),
                    "label": doc.get("label"),
                    "score": doc.get("score", 0.0),
                    "version": doc.get("version", 1),
                    "memory_lineage_id": doc.get("memory_lineage_id"),
                    "confidence_score": doc.get("confidence_score"),
                    "reinforcement_count": doc.get("reinforcement_count", 0),
                }
            )
        logger.debug(
            "Vector search returned %d semantic results (dict format) for org=%s user=%s",
            len(normalized),
            org_id,
            user_id,
        )
        return normalized
    else:
        # Parse to SemanticOut models
        parsed = [doc_to_output(d, SemanticOut) for d in results if d]
        logger.debug(
            "Vector search returned %d semantic results (model format) for org=%s",
            len(parsed),
            org_id,
        )
        return parsed
