"""
Shared types for the extraction framework.

These dataclasses provide a clean interface between pipeline stages,
enabling composability and testability.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional


@dataclass
class ExtractedItem:
    """Output from LLM extraction step."""

    content: str
    citations: List[int] = field(default_factory=list)
    confidence: float = 0.0
    cited_text: List[Dict[str, Any]] = field(default_factory=list)  # Enriched
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ScoredExtraction:
    """Extraction with quality scores applied."""

    content: str
    citations: List[int]
    confidence: float
    citation_score: float
    combined_score: float
    is_valid: bool
    cited_text: List[Dict[str, Any]] = field(default_factory=list)
    embedding: Optional[List[float]] = None  # Added during consolidation
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SimilarMatch:
    """Existing memory similar to an extraction."""

    id: str
    content: str
    score: float


ConsolidationAction = Literal["ADD", "UPDATE", "REINFORCE", "DUPLICATE"]


@dataclass
class ConsolidationDecision:
    """Decision for what to do with an extraction."""

    extraction: ScoredExtraction
    action: ConsolidationAction
    existing_id: Optional[str] = None
    reason: str = ""


@dataclass
class ConsolidationStats:
    """Statistics from consolidation process."""

    add_count: int = 0
    update_count: int = 0
    reinforce_count: int = 0
    duplicate_count: int = 0


@dataclass
class ExtractionMetadata:
    """Metadata about the extraction process."""

    model_used: Optional[str] = None
    prompt_version: str = "1.0"
    processing_time_ms: int = 0
    input_hash: str = ""
    extraction_timestamp: Optional[datetime] = None


ApprovalMode = Literal["auto", "manual"]


@dataclass
class ExtractionResult:
    """Full result with observability."""

    source_reference: str
    success: bool = False
    extracted_count: int = 0
    stored_count: int = 0
    validation_failures: int = 0
    consolidation_stats: ConsolidationStats = field(default_factory=ConsolidationStats)
    metadata: ExtractionMetadata = field(default_factory=ExtractionMetadata)
    created_ids: List[str] = field(default_factory=list)
    updated_ids: List[str] = field(default_factory=list)
    reinforced_ids: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    sample_extractions: List[Dict[str, Any]] = field(default_factory=list)
    pending_ids: List[str] = field(default_factory=list)
    approval_mode: ApprovalMode = "auto"


@dataclass
class PersistenceResult:
    """Result of applying decisions to database."""

    added: int = 0
    updated: int = 0
    reinforced: int = 0
    skipped: int = 0
    created_ids: List[str] = field(default_factory=list)
    updated_new_version_ids: List[str] = field(default_factory=list)
    updated_old_version_ids: List[str] = field(default_factory=list)
    reinforced_ids: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


__all__ = [
    "ApprovalMode",
    "ConsolidationAction",
    "ConsolidationDecision",
    "ConsolidationStats",
    "ExtractedItem",
    "ExtractionMetadata",
    "ExtractionResult",
    "PersistenceResult",
    "ScoredExtraction",
    "SimilarMatch",
]
