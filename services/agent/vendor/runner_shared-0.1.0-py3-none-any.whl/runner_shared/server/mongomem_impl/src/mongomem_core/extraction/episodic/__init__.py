"""
Episodic extraction pipeline.

Provides EpisodicPipeline class and factory function for creating
complete episodic extraction pipelines with consolidation support.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

if TYPE_CHECKING:
    from mongomem_core.protocols import EmbedderProtocol, LLMProtocol
    from pymongo.database import Database

from mongomem_core.extraction.config import EpisodicExtractionConfig
from mongomem_core.extraction.consolidator import (
    ConsolidationStrategy,
    Consolidator,
    LLMBasedStrategy,
    RuleBasedStrategy,
)
from mongomem_core.extraction.enrichment import enrich_citations
from mongomem_core.extraction.episodic.extractor import EpisodicExtractor
from mongomem_core.extraction.episodic.persistence import apply_episodic_decisions
from mongomem_core.extraction.scorer import filter_valid, score_batch
from mongomem_core.extraction.types import (
    ApprovalMode,
    ConsolidationStats,
    ExtractionMetadata,
    ExtractionResult,
)
from mongomem_core.memory.episodic import vector_search_episodic
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.observability import CoreObservability

logger = logging.getLogger(__name__)


def _search_episodic_wrapper(
    db: "Database",
    query_embedding: List[float],
    org_id: str,
    user_id: str,
    top_k: int,
    similarity_threshold: float,
    return_format: str = "dict",
) -> List[Dict[str, Any]]:
    """
    Wrapper around vector_search_episodic to match Consolidator's expected interface.

    The Consolidator expects:
    - Results with 'id', 'text', 'score' fields
    - A return_format parameter (ignored, always returns list)

    EpisodicOut has:
    - id (from _id)
    - summary_text (not 'text')
    - score (from vector search)

    This wrapper adapts the EpisodicOut results to the expected format.
    """
    results = vector_search_episodic(
        db=db,
        query_embedding=query_embedding,
        org_id=org_id,
        user_id=user_id,
        top_k=top_k,
        similarity_threshold=similarity_threshold,
    )

    # Convert EpisodicOut to dict format expected by Consolidator
    # Consolidator uses: getattr(r, "id", r.get("_id", r.get("id", "")))
    return [
        {
            "id": r.id,
            "text": r.summary_text,
            "score": r.score or 0.0,
        }
        for r in results
    ]


class EpisodicPipeline:
    """
    Full episodic extraction pipeline with consolidation.

    Orchestrates:
    1. Extract - LLM-based extraction of events from messages
    2. Enrich - Add citation text from source messages
    3. Score - Validate and score extractions
    4. Search - Find similar existing episodic memories
    5. Decide - Consolidate with existing memories (ADD/UPDATE/REINFORCE)
    6. Persist - Apply decisions to database
    """

    def __init__(
        self,
        extractor: EpisodicExtractor,
        config: EpisodicExtractionConfig,
        consolidator: Consolidator,
        db: "Database",
        embedding_model_id: str,
        obs: Optional[CoreObservability] = None,
    ) -> None:
        """
        Initialize episodic pipeline.

        Args:
            extractor: EpisodicExtractor instance
            config: Episodic extraction configuration
            consolidator: Consolidator instance
            db: MongoDB database instance
            embedding_model_id: ID of embedding model used
            obs: Optional CoreObservability for observability (metrics/spans/events)
        """
        self.extractor = extractor
        self.config = config
        self.consolidator = consolidator
        self._db = db
        self._embedding_model_id = embedding_model_id
        self._obs = obs or CoreObservability()

    def run(
        self,
        messages: List[Dict[str, Any]],
        org_id: str,
        user_id: str,
        source_id: str,
        approval_mode: ApprovalMode = "auto",
        visibility: ChunkVisibility = ChunkVisibility.PRIVATE,
        project_id: Optional[str] = None,
    ) -> ExtractionResult:
        """
        Run full episodic extraction pipeline.

        Args:
            messages: Conversation messages to extract events from
            org_id: Organization ID
            user_id: User ID
            source_id: Source reference (snapshot ID)
            approval_mode: "auto" persists immediately, "manual" stages for review
            visibility: Visibility scope for created memories
            project_id: Project ID (required if visibility=SHARED)

        Returns:
            ExtractionResult with counts, IDs, and statistics
        """
        with self._obs.span_extraction("episodic") as span:
            return self._run_internal(
                messages=messages,
                org_id=org_id,
                user_id=user_id,
                source_id=source_id,
                approval_mode=approval_mode,
                visibility=visibility,
                project_id=project_id,
                span=span,
            )

    def _run_internal(
        self,
        messages: List[Dict[str, Any]],
        org_id: str,
        user_id: str,
        source_id: str,
        approval_mode: ApprovalMode,
        visibility: ChunkVisibility,
        project_id: Optional[str],
        span: Dict[str, Any],
    ) -> ExtractionResult:
        """Internal implementation of run() with span context."""
        result = ExtractionResult(source_reference=source_id, approval_mode=approval_mode)
        start_time = datetime.now(timezone.utc)
        raw: List[Any] = []

        try:
            # Check if enabled
            if not self.config.enabled:
                logger.debug("Episodic extraction disabled")
                result.success = True
                return result

            # 1. Extract events
            raw = self.extractor.extract(messages)
            result.extracted_count = len(raw)
            logger.debug("Extracted %d raw events", len(raw))

            if not raw:
                result.success = True
                return result

            # Limit extractions per snapshot
            if len(raw) > self.config.max_events_per_snapshot:
                logger.info(
                    "Limiting events from %d to %d",
                    len(raw),
                    self.config.max_events_per_snapshot,
                )
                raw = raw[: self.config.max_events_per_snapshot]

            # 2. Enrich citations
            enrich_citations(raw, messages)

            # 3. Score and filter
            scored = score_batch(raw, self.config)
            valid = filter_valid(scored)
            result.validation_failures = len(scored) - len(valid)
            logger.debug(
                "After scoring: %d/%d passed threshold",
                len(valid),
                len(scored),
            )

            if not valid:
                result.success = True
                return result

            # 4-5. Consolidate (search + decide)
            decisions = self.consolidator.process(valid, org_id, user_id)
            logger.debug("Consolidation returned %d decisions", len(decisions))

            # 6. Persist or Stage
            extraction_timestamp = datetime.now(timezone.utc)

            if approval_mode == "manual":
                from mongomem_core.extraction.approval.store import PendingStore
                from mongomem_core.extraction.approval.types import (
                    ExtractionType,
                    PendingDecisionPayload,
                    PendingPayload,
                )

                store = PendingStore(self._db, obs=self._obs)
                items: list[tuple[ExtractionType, PendingPayload]] = []
                for d in decisions:
                    if d.action == "DUPLICATE":
                        continue
                    payload = PendingDecisionPayload(
                        action=d.action,
                        content=d.extraction.content,
                        citations=d.extraction.citations,
                        confidence=d.extraction.confidence,
                        citation_score=d.extraction.citation_score,
                        combined_score=d.extraction.combined_score,
                        embedding=d.extraction.embedding,
                        embedding_model_id=self._embedding_model_id,
                        cited_text=d.extraction.cited_text,
                        metadata=d.extraction.metadata,
                        existing_id=d.existing_id,
                        reason=d.reason,
                    )
                    items.append(("episodic", payload))

                pending_ids = store.stage_batch(
                    items=items,
                    org_id=org_id,
                    user_id=user_id,
                    source_id=source_id,
                    visibility=visibility,
                    project_id=project_id,
                )
                result.pending_ids = pending_ids
                result.consolidation_stats = ConsolidationStats(
                    add_count=sum(1 for d in decisions if d.action == "ADD"),
                    update_count=sum(1 for d in decisions if d.action == "UPDATE"),
                    reinforce_count=sum(1 for d in decisions if d.action == "REINFORCE"),
                    duplicate_count=sum(1 for d in decisions if d.action == "DUPLICATE"),
                )
            else:
                persist_result = apply_episodic_decisions(
                    db=self._db,
                    decisions=decisions,
                    org_id=org_id,
                    user_id=user_id,
                    source_id=source_id,
                    extraction_timestamp=extraction_timestamp,
                    embedding_model_id=self._embedding_model_id,
                    config=self.config,
                    visibility=visibility,
                    project_id=project_id,
                )

                # Update result
                result.stored_count = persist_result.added + persist_result.updated
                result.created_ids = persist_result.created_ids
                result.updated_ids = persist_result.updated_new_version_ids
                result.reinforced_ids = persist_result.reinforced_ids
                result.consolidation_stats = ConsolidationStats(
                    add_count=persist_result.added,
                    update_count=persist_result.updated,
                    reinforce_count=persist_result.reinforced,
                    duplicate_count=persist_result.skipped,
                )
                result.errors = persist_result.errors

            # Add sample extractions for observability
            result.sample_extractions = [
                {
                    "content": e.content[: self.config.sample_text_truncate_length],
                    "confidence": e.confidence,
                    "citations": e.citations,
                    "title": e.metadata.get("title", ""),
                }
                for e in raw[: self.config.max_sample_extractions]
            ]

            result.success = True

        except Exception as e:
            result.errors.append(str(e))
            logger.error("Episodic extraction failed: %s", e, exc_info=True)
            self._obs.extraction_failed("episodic", str(e), source_id)

        finally:
            processing_time_ms = int(
                (datetime.now(timezone.utc) - start_time).total_seconds() * 1000
            )
            result.metadata = ExtractionMetadata(
                processing_time_ms=processing_time_ms,
                extraction_timestamp=start_time,
            )

            # Update span attributes
            span["duration_ms"] = processing_time_ms
            span["extracted_count"] = result.extracted_count
            span["success"] = result.success

            # Emit all extraction metrics in one call
            stats = result.consolidation_stats
            self._obs.emit_extraction_result(
                extraction_type="episodic",
                extracted_count=result.extracted_count,
                duration_ms=processing_time_ms,
                add_count=stats.add_count if stats else 0,
                update_count=stats.update_count if stats else 0,
                reinforce_count=stats.reinforce_count if stats else 0,
                duplicate_count=stats.duplicate_count if stats else 0,
            )

        return result


def create_episodic_pipeline(
    db: "Database",
    llm: "LLMProtocol",
    embedder: "EmbedderProtocol",
    config: Optional[EpisodicExtractionConfig] = None,
    extraction_prompt_resolver: Optional[Callable[[], Optional[str]]] = None,
    consolidation_prompt_resolver: Optional[Callable[[], Optional[str]]] = None,
    use_llm_consolidation: bool = True,
    obs: Optional[CoreObservability] = None,
) -> EpisodicPipeline:
    """
    Factory function to create an episodic pipeline with hot-swap support.

    Args:
        db: MongoDB database instance
        llm: LLM protocol implementation
        embedder: Embedder protocol implementation
        config: Optional extraction configuration (uses defaults if not provided)
        extraction_prompt_resolver: Optional callable for hot-reload extraction prompts
        consolidation_prompt_resolver: Optional callable for hot-reload consolidation prompts
        use_llm_consolidation: If True, use LLM-based consolidation. Otherwise use rule-based.
        obs: Optional CoreObservability for observability (metrics/spans/events)

    Returns:
        Configured EpisodicPipeline ready to run
    """
    config = config or EpisodicExtractionConfig()

    # Create extractor with hot-reload support
    extractor = EpisodicExtractor(llm, extraction_prompt_resolver)

    # Create consolidation strategy
    strategy: ConsolidationStrategy
    if use_llm_consolidation:
        strategy = LLMBasedStrategy(llm, consolidation_prompt_resolver)
    else:
        strategy = RuleBasedStrategy(
            reinforce_threshold=0.95,
            update_threshold=config.consolidation_similarity_threshold,
        )

    # Create consolidator with episodic search wrapper
    consolidator = Consolidator(
        db=db,
        embedder=embedder,
        strategy=strategy,
        search_fn=_search_episodic_wrapper,
        config=config,  # type: ignore[arg-type]
    )

    return EpisodicPipeline(
        extractor=extractor,
        config=config,
        consolidator=consolidator,
        db=db,
        embedding_model_id=embedder.model_id,
        obs=obs,
    )


__all__ = [
    "EpisodicPipeline",
    "EpisodicExtractor",
    "create_episodic_pipeline",
]
