from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from pymongo.database import Database

from ..constants import RESUME_TOKENS_COLLECTION
from .cache import get_resume_tokens_collection

logger = logging.getLogger(__name__)


class ResumeTokenStore:
    """
    Persistent storage for MongoDB change stream resume tokens.

    Ensures change stream processing can survive worker restarts
    without missing events.
    """

    def __init__(self, db: Database) -> None:
        self._db = db
        self._collection = get_resume_tokens_collection(db)

    def get_token(self, stream_name: str) -> Optional[Dict[str, Any]]:
        """
        Get the last persisted resume token for a stream.

        Args:
            stream_name: Identifier for the change stream (e.g., "stm_changes")

        Returns:
            Resume token dict if found, None otherwise
        """
        doc = self._collection.find_one({"stream_name": stream_name})
        if doc and "resume_token" in doc:
            logger.debug("Retrieved resume token for stream %s", stream_name)
            token = doc["resume_token"]
            return dict(token) if token else None
        return None

    def save_token(self, stream_name: str, resume_token: Dict[str, Any]) -> None:
        """
        Persist a resume token for a stream.

        Args:
            stream_name: Identifier for the change stream
            resume_token: The resume token from the change stream
        """
        self._collection.update_one(
            {"stream_name": stream_name},
            {
                "$set": {
                    "resume_token": resume_token,
                    "updated_at": datetime.now(timezone.utc),
                }
            },
            upsert=True,
        )
        logger.debug("Saved resume token for stream %s", stream_name)

    def delete_token(self, stream_name: str) -> None:
        """Delete the resume token for a stream (e.g., on invalidation)."""
        self._collection.delete_one({"stream_name": stream_name})
        logger.debug("Deleted resume token for stream %s", stream_name)


__all__ = ["ResumeTokenStore", "RESUME_TOKENS_COLLECTION"]
