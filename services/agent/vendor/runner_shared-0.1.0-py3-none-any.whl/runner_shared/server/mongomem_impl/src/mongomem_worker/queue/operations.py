"""
Task queue operations.

Standalone functions for queue manipulation that can be used
independently of the TaskQueueProcessor.
"""

from __future__ import annotations

import logging
import threading
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

from bson import ObjectId
from pymongo import ASCENDING, ReturnDocument
from pymongo.collection import Collection
from pymongo.errors import DuplicateKeyError

from ...mongomem_core.config import Settings
from ...mongomem_core.storage import get_database
from ..config import WorkerSettings
from ..errors import (
    ErrorType,
    classify_error,
    get_error_taxonomy,
    get_retry_delay,
    should_retry,
)
from ..storage import (
    ensure_worker_collections,
    ensure_worker_indexes,
    get_tasks_collection,
)
from .models import ClaimedTask, EnqueuedTask

logger = logging.getLogger(__name__)

_bootstrap_lock = threading.Lock()
_bootstrap_done = False


def _tasks_collection(settings: Optional[WorkerSettings] = None) -> Collection:
    """Return the worker tasks collection, bootstrapping on first use."""
    global _bootstrap_done

    core_settings: Optional[Settings]
    if settings is None:
        core_settings = None
    else:
        core_settings = Settings(
            mongo_uri=settings.mongo_uri,
            db_name=settings.db_name,
        )

    db = get_database(core_settings)
    if not _bootstrap_done:
        with _bootstrap_lock:
            if not _bootstrap_done:
                ensure_worker_collections(db)
                ensure_worker_indexes(db)
                _bootstrap_done = True
    return get_tasks_collection(db)


def enqueue_task(
    task_type: str,
    payload: dict[str, Any],
    *,
    priority: int = 0,
    max_retries: int = 3,
    idempotency_key: Optional[str] = None,
    ttl_days: int = 14,
    settings: Optional[WorkerSettings] = None,
) -> EnqueuedTask:
    """
    Enqueue a task for processing by workers.

    Multiple workers can safely pull from this queue - tasks are claimed
    with leases to prevent duplicate processing.
    """
    coll = _tasks_collection(settings)
    now = datetime.now(timezone.utc)
    doc: dict[str, Any] = {
        "task_type": task_type,
        "payload": payload,
        "priority": priority,
        "max_retries": max_retries,
        "remaining_retries": max_retries,
        "status": "queued",
        "created_at": now,
        "lease_expires_at": None,
        "worker_id": None,
        "run_after": now,
        "expires_at": now + timedelta(days=ttl_days),
    }
    if idempotency_key is not None:
        doc["idempotency_key"] = idempotency_key

    try:
        result = coll.insert_one(doc)
        logger.debug("Enqueued task %s: type=%s", result.inserted_id, task_type)
        return EnqueuedTask(id=result.inserted_id, status="queued")
    except DuplicateKeyError:
        # Idempotent enqueue: task already exists for this idempotency_key.
        if idempotency_key is None:
            raise
        existing = coll.find_one({"idempotency_key": idempotency_key}, {"_id": 1, "status": 1})
        if existing:
            logger.debug("Task already enqueued for idempotency_key=%s", idempotency_key)
            return EnqueuedTask(id=existing["_id"], status=existing.get("status", "queued"))
        raise


def claim_task(
    coll: Collection,
    worker_id: str,
    task_types: Optional[list[str]] = None,
    lease_seconds: int = 300,
) -> Optional[ClaimedTask]:
    """
    Atomically claim the next available task.

    Uses findAndModify to prevent race conditions between workers.
    Tasks with expired leases are also eligible for claiming (stale recovery).

    Args:
        coll: Tasks collection
        worker_id: Unique identifier for this worker
        task_types: Optional filter for specific task types
        lease_seconds: How long the lease is valid

    Returns:
        ClaimedTask if a task was claimed, None otherwise
    """
    now = datetime.now(timezone.utc)
    lease_expires = now + timedelta(seconds=lease_seconds)

    query: Dict[str, Any] = {
        "$and": [
            {"run_after": {"$lte": now}},
            {"expires_at": {"$gt": now}},
            {
                "$or": [
                    {"status": "queued"},
                    {
                        "status": "running",
                        "lease_expires_at": {"$lt": now},
                    },
                ]
            },
        ]
    }

    if task_types:
        query["task_type"] = {"$in": task_types}

    doc = coll.find_one_and_update(
        query,
        {
            "$set": {
                "status": "running",
                "worker_id": worker_id,
                "lease_expires_at": lease_expires,
                "started_at": now,
            }
        },
        sort=[("priority", ASCENDING), ("created_at", ASCENDING)],
        return_document=ReturnDocument.AFTER,
    )

    if not doc:
        return None

    logger.debug(
        "Worker %s claimed task %s (type=%s)",
        worker_id,
        doc["_id"],
        doc["task_type"],
    )

    return ClaimedTask(
        id=doc["_id"],
        task_type=doc["task_type"],
        payload=doc.get("payload", {}),
        priority=doc.get("priority", 0),
        remaining_retries=doc.get("remaining_retries", 0),
        attempts=doc.get("max_retries", 3) - doc.get("remaining_retries", 0),
        created_at=doc["created_at"],
        lease_expires_at=lease_expires,
    )


def complete_task(
    coll: Collection,
    task_id: ObjectId,
    worker_id: str,
    success: bool = True,
    error: Optional[str] = None,
    result: Optional[Dict[str, Any]] = None,
    attempts: int = 1,
    max_retries: int = 3,
) -> bool:
    """
    Mark a task as completed (success or failure).

    Uses error classification to determine retry behavior:
    - Permanent errors: Don't retry, move to failed
    - Transient errors: Retry with exponential backoff
    - Unknown errors: Retry with caution

    Only the worker that owns the lease can complete the task.

    Returns:
        True if task was updated, False if lease was lost
    """
    now = datetime.now(timezone.utc)

    if success:
        update_result = coll.update_one(
            {"_id": task_id, "worker_id": worker_id, "status": "running"},
            {
                "$set": {
                    "status": "succeeded",
                    "completed_at": now,
                    "result": result,
                }
            },
        )
    else:
        # Classify the error
        error_type = classify_error(error or "")
        error_taxonomy = get_error_taxonomy(error or "")

        # Determine if we should retry
        can_retry = should_retry(error or "", attempts, max_retries)

        if can_retry and error_type != ErrorType.PERMANENT:
            # Calculate retry delay based on error type
            retry_delay = get_retry_delay(error or "", attempts)
            run_after = now + timedelta(seconds=retry_delay)

            update_result = coll.update_one(
                {
                    "_id": task_id,
                    "worker_id": worker_id,
                    "status": "running",
                    "remaining_retries": {"$gt": 0},
                },
                {
                    "$set": {
                        "status": "queued",
                        "worker_id": None,
                        "lease_expires_at": None,
                        "last_error": error[:1000] if error else None,
                        "error_type": error_type.value,
                        "error_taxonomy": error_taxonomy.value,
                        "run_after": run_after,
                    },
                    "$inc": {"remaining_retries": -1},
                },
            )

            if update_result.modified_count > 0:
                logger.warning(
                    "Task %s failed (transient), retry in %.1fs: %s",
                    task_id,
                    retry_delay,
                    error[:100] if error else "unknown",
                )
        else:
            # No retry - mark as failed
            update_result = coll.update_one(
                {"_id": task_id, "worker_id": worker_id, "status": "running"},
                {
                    "$set": {
                        "status": "failed",
                        "completed_at": now,
                        "last_error": error[:1000] if error else None,
                        "error_type": error_type.value,
                        "error_taxonomy": error_taxonomy.value,
                    }
                },
            )

            if update_result.modified_count > 0:
                if error_type == ErrorType.PERMANENT:
                    logger.error(
                        "Task %s failed permanently: %s",
                        task_id,
                        error[:100] if error else "unknown",
                    )
                else:
                    logger.warning(
                        "Task %s exhausted retries: %s",
                        task_id,
                        error[:100] if error else "unknown",
                    )

    if update_result.modified_count > 0:
        logger.debug(
            "Task %s completed: success=%s, worker=%s",
            task_id,
            success,
            worker_id,
        )
        return True
    else:
        logger.warning(
            "Task %s completion failed - lease may have been lost (worker=%s)",
            task_id,
            worker_id,
        )
        return False


def heartbeat_task(
    coll: Collection,
    task_id: ObjectId,
    worker_id: str,
    lease_seconds: int = 300,
) -> bool:
    """
    Send heartbeat for a running task to extend its lease.

    Call this periodically for long-running tasks to prevent
    the task from being reclaimed by another worker.

    Returns:
        True if heartbeat succeeded, False if lease was lost
    """
    now = datetime.now(timezone.utc)
    new_expires = now + timedelta(seconds=lease_seconds)

    result = coll.update_one(
        {"_id": task_id, "worker_id": worker_id, "status": "running"},
        {
            "$set": {
                "lease_expires_at": new_expires,
                "heartbeat_at": now,
            }
        },
    )

    if result.modified_count > 0:
        logger.debug("Task %s heartbeat: lease extended to %s", task_id, new_expires)
        return True
    else:
        logger.warning("Task %s heartbeat failed - lease may have been lost", task_id)
        return False


def extend_lease(
    coll: Collection,
    task_id: ObjectId,
    worker_id: str,
    lease_seconds: int = 300,
) -> bool:
    """
    Extend the lease on a running task.

    Call this periodically for long-running tasks to prevent lease expiry.

    Returns:
        True if lease was extended, False if lease was lost
    """
    now = datetime.now(timezone.utc)
    new_expires = now + timedelta(seconds=lease_seconds)

    result = coll.update_one(
        {"_id": task_id, "worker_id": worker_id, "status": "running"},
        {"$set": {"lease_expires_at": new_expires}},
    )

    return result.modified_count > 0


def requeue_stale_tasks(coll: Collection, max_age_minutes: int = 30) -> int:
    """
    Requeue tasks that have been running too long (stale/dead workers).

    This is a maintenance operation that can be run periodically.
    Uses an aggregation pipeline to capture the stale worker_id before
    clearing it, creating a recovery log for debugging.

    Returns:
        Number of tasks requeued
    """
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(minutes=max_age_minutes)

    # Use aggregation pipeline to capture worker_id in recovery_log before nulling it
    result = coll.update_many(
        {
            "status": "running",
            "lease_expires_at": {"$lt": cutoff},
            "remaining_retries": {"$gt": 0},
        },
        [
            {
                "$set": {
                    "status": "queued",
                    "lease_expires_at": None,
                    # Append to recovery_log before clearing worker_id
                    "recovery_log": {
                        "$concatArrays": [
                            {"$ifNull": ["$recovery_log", []]},
                            [
                                {
                                    "recovered_at": now,
                                    "stale_worker_id": "$worker_id",
                                    "lease_expired_at": "$lease_expires_at",
                                }
                            ],
                        ]
                    },
                    "worker_id": None,
                }
            },
            {"$set": {"remaining_retries": {"$subtract": ["$remaining_retries", 1]}}},
        ],
    )

    if result.modified_count > 0:
        logger.warning("Requeued %d stale tasks (recovery logged)", result.modified_count)

    return result.modified_count


def move_to_dlq(coll: Collection, dlq_coll: Collection, task_id: ObjectId) -> bool:
    """
    Move a failed task to the dead letter queue.

    Returns:
        True if moved successfully
    """
    doc = coll.find_one_and_delete({"_id": task_id, "status": "failed"})
    if doc:
        doc["moved_to_dlq_at"] = datetime.now(timezone.utc)
        dlq_coll.insert_one(doc)
        logger.info("Moved task %s to DLQ", task_id)
        return True
    return False


__all__ = [
    "enqueue_task",
    "claim_task",
    "complete_task",
    "heartbeat_task",
    "extend_lease",
    "requeue_stale_tasks",
    "move_to_dlq",
]
