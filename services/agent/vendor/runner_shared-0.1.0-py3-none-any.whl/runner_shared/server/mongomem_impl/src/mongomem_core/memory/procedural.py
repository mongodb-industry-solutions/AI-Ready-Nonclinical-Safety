"""CRUD and invariants for procedural memory.

Procedural memory stores reusable procedures (skills) with embeddings for
vector search. Each document represents a named procedure that can be
retrieved based on semantic similarity and executed by agent frameworks.

All functions operate synchronously against MongoDB and expect the caller to
provide necessary context (org_id, user_id, etc.).
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Sequence, Tuple, Union, overload

from bson import ObjectId
from mongomem_core.common.utils import (
    format_document_identifier,
    handle_db_error,
    handle_duplicate_key_error,
    to_object_id,
    utcnow,
)
from mongomem_core.exceptions import (
    DatabaseOperationError,
    DocumentNotFoundError,
)
from mongomem_core.memory.base import (
    BaseDocumentBuilder,
    BaseQueryBuilder,
    BaseUpdateFieldBuilder,
    doc_to_output,
    execute_vector_search,
    handle_empty_sequence,
)
from mongomem_core.models.filters import MetadataFilter
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.procedural import (
    ProceduralDB,
    ProceduralIn,
    ProceduralOut,
    ProceduralUpdate,
)
from mongomem_core.models.types import PyObjectId
from mongomem_core.storage import get_collection
from mongomem_core.storage.collections import ProceduralMemoryCollection
from mongomem_core.storage.search_indexes import PROCEDURAL_VECTOR_INDEX
from pymongo import ReturnDocument
from pymongo.database import Database
from pymongo.errors import BulkWriteError, DuplicateKeyError
from pymongo.results import DeleteResult, InsertManyResult, InsertOneResult, UpdateResult

logger = logging.getLogger(__name__)

_PROCEDURAL_COL = ProceduralMemoryCollection()


def _build_procedural_query_filter(
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    procedure: Optional[str] = None,
    user_id: Optional[str] = None,
    visibility: Optional[str] = None,
    project_id: Optional[str] = None,
    include_deleted: bool = False,
    is_latest: Optional[bool] = True,
) -> Tuple[Dict[str, Any], str]:
    """Build a MongoDB query filter and identifier string for procedural lookups."""
    if (id is None) == (procedure is None):
        raise ValueError("Exactly one of 'id' or 'procedure' must be provided")

    q_filter: Dict[str, Any]
    if id is not None:
        q_filter, identifier = BaseQueryBuilder.build_id_filter(
            org_id, id, include_deleted=include_deleted
        )
    else:
        q_filter = {"procedure": procedure, "org_id": org_id}
        identifier = format_document_identifier(label=procedure)
        if not include_deleted:
            q_filter["deleted"] = {"$ne": True}
        if is_latest is not None:
            q_filter["is_latest"] = is_latest

    if user_id is not None:
        q_filter["user_id"] = user_id
    if visibility is not None:
        q_filter["visibility"] = visibility
    if project_id is not None:
        q_filter["project_id"] = project_id

    return q_filter, identifier


def _build_procedural_doc(
    procedural_in: ProceduralIn,
    org_id: str,
    user_id: str,
    timestamp: datetime,
    *,
    embedding: Optional[List[float]] = None,
    embedding_model_id: Optional[str] = None,
    extraction_id: Optional[str] = None,
) -> ProceduralDB:
    """Build a ProceduralDB document from input."""
    return BaseDocumentBuilder.build_memory_document(
        procedural_in,
        ProceduralDB,
        org_id,
        user_id,
        timestamp,
        embedding=embedding,
        embedding_model_id=embedding_model_id,
        extraction_id=extraction_id,
        embedding_config={
            "model_id_field": "embedding_model_id",
            "log_context": f"procedure={procedural_in.procedure}",
        },
        updated_at=timestamp,
    )


def create_procedural(
    db: Database,
    procedural_in: ProceduralIn,
    org_id: str,
    user_id: str,
    *,
    embedding: Optional[List[float]] = None,
    embedding_model_id: Optional[str] = None,
    extraction_id: Optional[str] = None,
) -> ProceduralDB:
    """Create a procedural memory document.

    Raises:
        DuplicateDocumentError: If procedure name already exists in org.
        DatabaseOperationError: If the insert operation fails.
    """
    logger.debug(
        "Creating procedural memory document: procedure=%s org=%s user=%s",
        procedural_in.procedure,
        org_id,
        user_id,
    )

    now = utcnow()
    doc = _build_procedural_doc(
        procedural_in,
        org_id,
        user_id,
        now,
        embedding=embedding,
        embedding_model_id=embedding_model_id,
        extraction_id=extraction_id,
    )

    col = get_collection(_PROCEDURAL_COL, db)

    if doc.memory_lineage_id is None:
        doc.id = PyObjectId()
        doc.memory_lineage_id = str(doc.id)

    try:
        with handle_db_error(
            operation="insert_one",
            collection=_PROCEDURAL_COL.name,
            log_message="Failed to create procedural document: procedure=%s org=%s",
            log_args_tuple=(procedural_in.procedure, org_id),
        ):
            result: InsertOneResult = col.insert_one(doc.model_dump(by_alias=True))
            doc.id = result.inserted_id

            logger.debug(
                "Created procedural document: id=%s procedure=%s org=%s",
                result.inserted_id,
                procedural_in.procedure,
                org_id,
            )
            return doc
    except DuplicateKeyError as exc:
        handle_duplicate_key_error(
            exc,
            collection_name=_PROCEDURAL_COL.name,
            log_message="Duplicate procedural document detected: procedure=%s org=%s",
            log_args=(procedural_in.procedure, org_id),
            details={
                "procedure": procedural_in.procedure,
                "org_id": org_id,
            },
        )


def bulk_create_procedural(
    db: Database,
    items: List[ProceduralIn],
    org_id: str,
    user_id: str,
    *,
    embeddings: Optional[List[List[float]]] = None,
    embedding_model_id: Optional[str] = None,
    skip_duplicates: bool = True,
) -> Tuple[List[ProceduralDB], List[str]]:
    """Bulk create multiple procedural memory documents.

    Returns:
        Tuple of (created_docs, skipped_procedures)
    """
    if not items:
        return [], []

    logger.debug(
        "Bulk creating %d procedural documents for org=%s user=%s",
        len(items),
        org_id,
        user_id,
    )

    col = get_collection(_PROCEDURAL_COL, db)
    now = utcnow()

    docs_to_insert: List[ProceduralDB] = []
    for i, item in enumerate(items):
        embedding = embeddings[i] if embeddings and i < len(embeddings) else None
        doc = _build_procedural_doc(
            item,
            org_id,
            user_id,
            now,
            embedding=embedding,
            embedding_model_id=embedding_model_id,
        )
        doc.id = PyObjectId()
        doc.memory_lineage_id = str(doc.id)
        docs_to_insert.append(doc)

    docs_dicts = [doc.model_dump(by_alias=True) for doc in docs_to_insert]

    created_docs: List[ProceduralDB] = []
    skipped_procedures: List[str] = []

    try:
        result: InsertManyResult = col.insert_many(docs_dicts, ordered=False)
        for i, inserted_id in enumerate(result.inserted_ids):
            docs_to_insert[i].id = inserted_id
            created_docs.append(docs_to_insert[i])

    except BulkWriteError as bwe:
        if not skip_duplicates:
            raise DatabaseOperationError(
                f"Bulk insert failed with duplicates: {bwe}",
                operation="insert_many",
                collection=_PROCEDURAL_COL.name,
                details={"org_id": org_id, "count": len(items)},
            ) from bwe

        write_errors = bwe.details.get("writeErrors", [])
        error_indices = {e["index"] for e in write_errors}

        for error in write_errors:
            if error.get("code") == 11000:
                idx = error["index"]
                if idx < len(items):
                    skipped_procedures.append(items[idx].procedure)
                    logger.debug(
                        "Skipping duplicate procedural document: procedure=%s org=%s",
                        items[idx].procedure,
                        org_id,
                    )

        for i, doc in enumerate(docs_to_insert):
            if i not in error_indices:
                created_docs.append(doc)

    except Exception as exc:
        logger.error(
            "Failed to bulk create procedural documents: count=%d org=%s error=%s",
            len(items),
            org_id,
            exc,
        )
        raise DatabaseOperationError(
            f"Bulk insert failed: {exc}",
            operation="insert_many",
            collection=_PROCEDURAL_COL.name,
            details={"org_id": org_id, "count": len(items)},
        ) from exc

    logger.info(
        "Bulk created %d/%d procedural documents for org=%s (skipped=%d duplicates)",
        len(created_docs),
        len(items),
        org_id,
        len(skipped_procedures),
    )
    return created_docs, skipped_procedures


def upsert_procedural(
    db: Database,
    procedural_in: ProceduralIn,
    org_id: str,
    user_id: str,
    *,
    embedding: Optional[List[float]] = None,
    embedding_model_id: Optional[str] = None,
    extraction_id: Optional[str] = None,
) -> ProceduralOut:
    """Create or update a procedural memory document by procedure name.

    Raises:
        DatabaseOperationError: If the upsert operation fails.
    """
    logger.debug(
        "Upserting procedural memory document: procedure=%s org=%s user=%s",
        procedural_in.procedure,
        org_id,
        user_id,
    )

    col = get_collection(_PROCEDURAL_COL, db)
    now = utcnow()

    doc = _build_procedural_doc(
        procedural_in,
        org_id,
        user_id,
        now,
        embedding=embedding,
        embedding_model_id=embedding_model_id,
        extraction_id=extraction_id,
    )

    update_doc = doc.model_dump(
        by_alias=True,
        exclude={"id", "_id", "timestamp", "memory_lineage_id", "org_id", "user_id"},
    )
    update_doc["updated_at"] = now

    new_id = ObjectId()
    set_on_insert: Dict[str, Any] = {
        "_id": new_id,
        "memory_lineage_id": str(new_id),
        "timestamp": now,
        "org_id": org_id,
        "user_id": user_id,
    }

    with handle_db_error(
        operation="find_one_and_update",
        collection=_PROCEDURAL_COL.name,
        log_message="Failed to upsert procedural document: procedure=%s org=%s",
        log_args_tuple=(procedural_in.procedure, org_id),
    ):
        result = col.find_one_and_update(
            {"procedure": procedural_in.procedure, "org_id": org_id, "deleted": {"$ne": True}},
            {
                "$set": update_doc,
                "$setOnInsert": set_on_insert,
            },
            upsert=True,
            return_document=ReturnDocument.AFTER,
        )

        if not result:
            raise DatabaseOperationError(
                "Upsert operation failed unexpectedly",
                operation="find_one_and_update",
                collection=_PROCEDURAL_COL.name,
                details={"org_id": org_id, "procedure": procedural_in.procedure},
            )

        result["_id"] = str(result["_id"])
        logger.debug(
            "Upserted procedural document: id=%s procedure=%s org=%s",
            result["_id"],
            procedural_in.procedure,
            org_id,
        )
        return ProceduralOut.model_validate(result)


def get_procedural(
    db: Database,
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    procedure: Optional[str] = None,
    user_id: Optional[str] = None,
    visibility: Optional[str] = None,
    project_id: Optional[str] = None,
    include_deleted: bool = False,
) -> Optional[ProceduralOut]:
    """Fetch a single procedural memory document by ID or procedure name.

    Raises:
        ValueError: If neither id nor procedure is provided, or both are.
    """
    q_filter, identifier = _build_procedural_query_filter(
        org_id,
        id=id,
        procedure=procedure,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        include_deleted=include_deleted,
    )

    col = get_collection(_PROCEDURAL_COL, db)

    with handle_db_error(
        operation="find_one",
        collection=_PROCEDURAL_COL.name,
        log_message="Failed to retrieve procedural document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        doc = col.find_one(q_filter)
        if not doc:
            logger.debug("Procedural document not found: %s org=%s", identifier, org_id)
            return None

        doc["_id"] = str(doc["_id"])
        logger.debug("Retrieved procedural document: %s", identifier)
        return ProceduralOut.model_validate(doc)


def list_procedural(
    db: Database,
    org_id: str,
    *,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    tags: Optional[List[str]] = None,
    include_deleted: bool = False,
    before: Optional[datetime] = None,
    limit: Optional[int] = None,
    sort_by: str = "updated_at",
    sort_descending: bool = True,
) -> List[ProceduralOut]:
    """List procedural memory documents with optional filters and pagination."""
    col = get_collection(_PROCEDURAL_COL, db)

    q_filter = BaseQueryBuilder.build_list_filter(
        org_id,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        before=before,
        include_deleted=include_deleted,
        timestamp_field="updated_at",
    )

    if tags:
        q_filter["tags"] = {"$all": tags}

    sort_direction = -1 if sort_descending else 1

    with handle_db_error(
        operation="find",
        collection=_PROCEDURAL_COL.name,
        log_message="Failed to retrieve procedural documents for org=%s",
        log_args_tuple=(org_id,),
    ):
        cursor = col.find(q_filter).sort(sort_by, sort_direction)
        if limit and limit > 0:
            cursor = cursor.limit(limit)
        results = [doc_to_output(d, ProceduralOut) for d in cursor]
        logger.debug(
            "Retrieved %d procedural documents for org=%s",
            len(results),
            org_id,
        )
        return results


def _build_update_fields(update: ProceduralUpdate) -> Dict[str, Any]:
    """Build MongoDB update fields from ProceduralUpdate model."""
    update_fields = BaseUpdateFieldBuilder.build_update_fields(
        update,
        field_mappings={
            "description": "description",
            "content": "content",
            "content_token_count": "content_token_count",
            "allowed_tools": "allowed_tools",
            "compatibility": "compatibility",
            "license": "license",
            "trigger_conditions": "trigger_conditions",
            "tags": "tags",
            "embedding_model_id": "embedding_model_id",
        },
    )

    if update.steps is not None:
        update_fields["steps"] = [s.model_dump() for s in update.steps]
    if update.resources is not None:
        update_fields["resources"] = [r.model_dump() for r in update.resources]

    return update_fields


def update_procedural(
    db: Database,
    org_id: str,
    update: ProceduralUpdate,
    *,
    id: Optional[str | ObjectId] = None,
    procedure: Optional[str] = None,
) -> ProceduralOut:
    """Update a procedural memory document by ID or procedure name.

    Raises:
        ValueError: If neither id nor procedure is provided, or both are.
        DocumentNotFoundError: If the document doesn't exist.
    """
    col = get_collection(_PROCEDURAL_COL, db)
    update_fields = _build_update_fields(update)

    if not update_fields:
        if id is not None:
            doc = get_procedural(db, org_id, id=id)
        else:
            doc = get_procedural(db, org_id, procedure=procedure)
        if not doc:
            _, identifier = _build_procedural_query_filter(
                org_id, id=id, procedure=procedure, include_deleted=True, is_latest=None
            )
            raise DocumentNotFoundError(
                "Procedural document not found",
                collection=_PROCEDURAL_COL.name,
                document_id=str(id) if id else None,
                details={"org_id": org_id, "identifier": identifier},
            )
        return doc

    update_fields["updated_at"] = utcnow()

    q_filter, identifier = _build_procedural_query_filter(
        org_id,
        id=id,
        procedure=procedure,
        include_deleted=False,
    )

    with handle_db_error(
        operation="find_one_and_update",
        collection=_PROCEDURAL_COL.name,
        log_message="Failed to update procedural document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result_doc = col.find_one_and_update(
            q_filter,
            {"$set": update_fields},
            return_document=ReturnDocument.AFTER,
        )

        if not result_doc:
            raise DocumentNotFoundError(
                "Procedural document not found or is deleted",
                collection=_PROCEDURAL_COL.name,
                document_id=str(id) if id else None,
                details={"org_id": org_id, "identifier": identifier},
            )

        logger.debug("Updated procedural document: %s org=%s", identifier, org_id)
        return ProceduralOut.model_validate({**result_doc, "_id": str(result_doc["_id"])})


def update_procedural_embedding(
    db: Database,
    procedural_id: str | ObjectId,
    org_id: str,
    embedding: List[float],
    embedding_model_id: Optional[str] = None,
) -> UpdateResult:
    """Update the embedding on an existing procedural memory document."""
    col = get_collection(_PROCEDURAL_COL, db)
    oid = to_object_id(procedural_id)

    update_fields: Dict[str, Any] = {
        "embedding": embedding,
        "has_embedding": True,
        "updated_at": utcnow(),
    }
    if embedding_model_id:
        update_fields["embedding_model_id"] = embedding_model_id

    with handle_db_error(
        operation="update_one",
        collection=_PROCEDURAL_COL.name,
        log_message="Failed to update embedding for procedural document: id=%s org=%s",
        log_args_tuple=(str(procedural_id), org_id),
    ):
        result = col.update_one(
            {"_id": oid, "org_id": org_id, "deleted": {"$ne": True}},
            {"$set": update_fields},
        )
        if result.modified_count > 0:
            logger.debug(
                "Updated embedding for procedural document: id=%s model=%s",
                procedural_id,
                embedding_model_id,
            )
        else:
            logger.warning(
                "No procedural document modified for embedding update: id=%s org=%s",
                procedural_id,
                org_id,
            )
        return result


def soft_delete_procedural(
    db: Database,
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    procedure: Optional[str] = None,
) -> UpdateResult:
    """Soft delete a procedural memory document by ID or procedure name."""
    q_filter, identifier = _build_procedural_query_filter(
        org_id,
        id=id,
        procedure=procedure,
        include_deleted=True,
        is_latest=None,
    )
    q_filter.pop("deleted", None)

    col = get_collection(_PROCEDURAL_COL, db)
    now = utcnow()
    with handle_db_error(
        operation="update_one",
        collection=_PROCEDURAL_COL.name,
        log_message="Failed to soft delete procedural document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result = col.update_one(
            q_filter,
            {"$set": {"deleted": True, "deleted_at": now, "updated_at": now, "is_latest": False}},
        )
        if result.modified_count > 0:
            logger.debug("Soft deleted procedural document: %s org=%s", identifier, org_id)
        else:
            logger.warning(
                "No procedural document modified for soft delete: %s org=%s",
                identifier,
                org_id,
            )
        return result


def delete_procedural(
    db: Database,
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    procedure: Optional[str] = None,
) -> DeleteResult:
    """Hard delete a procedural memory document by ID or procedure name."""
    q_filter, identifier = _build_procedural_query_filter(
        org_id,
        id=id,
        procedure=procedure,
        include_deleted=True,
        is_latest=None,
    )
    q_filter.pop("deleted", None)

    col = get_collection(_PROCEDURAL_COL, db)

    with handle_db_error(
        operation="delete_one",
        collection=_PROCEDURAL_COL.name,
        log_message="Failed to delete procedural document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result = col.delete_one(q_filter)
        logger.debug(
            "Deleted procedural document: %s org=%s (deleted_count=%d)",
            identifier,
            org_id,
            result.deleted_count,
        )
        return result


def delete_procedural_by_ids(
    db: Database,
    procedural_ids: Sequence[str | ObjectId],
    org_id: str,
) -> DeleteResult:
    """Hard delete multiple procedural memory documents by ID."""
    early_return = handle_empty_sequence(procedural_ids, "delete_procedural_by_ids", DeleteResult)
    if early_return is not None:
        return early_return  # type: ignore[return-value]

    col = get_collection(_PROCEDURAL_COL, db)
    oids = [to_object_id(pid) for pid in procedural_ids]

    with handle_db_error(
        operation="delete_many",
        collection=_PROCEDURAL_COL.name,
        log_message="Failed to delete procedural documents: count=%d org=%s",
        log_args_tuple=(len(procedural_ids), org_id),
    ):
        result = col.delete_many({"_id": {"$in": oids}, "org_id": org_id})
        logger.info(
            "Deleted %d procedural documents (requested=%d, org=%s)",
            result.deleted_count,
            len(procedural_ids),
            org_id,
        )
        return result


@overload
def search_procedural(
    db: Database,
    query_embedding: List[float],
    org_id: str,
    *,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    tags: Optional[List[str]] = None,
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    return_format: Literal["model"] = "model",
    include_deleted: bool = False,
    index_name: Optional[str] = None,
    is_latest: Optional[bool] = None,
    metadata_filter: Optional[MetadataFilter] = None,
) -> List[ProceduralOut]: ...


@overload
def search_procedural(
    db: Database,
    query_embedding: List[float],
    org_id: str,
    *,
    user_id: str,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    tags: Optional[List[str]] = None,
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    return_format: Literal["dict"],
    include_deleted: bool = False,
    index_name: Optional[str] = None,
    is_latest: Optional[bool] = True,
    metadata_filter: Optional[MetadataFilter] = None,
) -> List[Dict[str, Any]]: ...


@overload
def search_procedural(
    db: Database,
    query_embedding: List[float],
    org_id: str,
    *,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    tags: Optional[List[str]] = None,
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    return_format: Literal["discovery"],
    include_deleted: bool = False,
    index_name: Optional[str] = None,
    is_latest: Optional[bool] = None,
    metadata_filter: Optional[MetadataFilter] = None,
) -> List[Dict[str, Any]]: ...


def search_procedural(
    db: Database,
    query_embedding: List[float],
    org_id: str,
    *,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    tags: Optional[List[str]] = None,
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    return_format: Literal["model", "dict", "discovery"] = "model",
    include_deleted: bool = False,
    index_name: Optional[str] = None,
    is_latest: Optional[bool] = None,
    metadata_filter: Optional[MetadataFilter] = None,
) -> Union[List[ProceduralOut], List[Dict[str, Any]]]:
    """Unified vector search for procedural memories.

    Supports three return formats:
    - "model": Full ProceduralOut objects
    - "dict": Dict with content for consolidator compatibility
    - "discovery": Lightweight dicts (~100 tokens) without content/steps/resources.
      Returns only procedure name, description, version, tags, reinforcement_count,
      and similarity score. The agent then calls get_procedural() to activate
      selected procedures.
    """
    if not org_id:
        raise ValueError("org_id is required")

    col = get_collection(_PROCEDURAL_COL, db)
    effective_index_name = index_name or PROCEDURAL_VECTOR_INDEX.name

    rbac_filter = BaseQueryBuilder.build_base_filter(
        org_id,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        include_deleted=include_deleted,
    )

    if tags:
        rbac_filter["tags"] = {"$all": tags}

    if return_format == "dict":
        if user_id is None:
            raise ValueError("user_id is required when return_format='dict'")
    rbac_filter["is_latest"] = is_latest if is_latest is not None else True

    projection: Optional[Dict[str, Any]] = None
    if return_format == "discovery":
        projection = {
            "_id": 1,
            "procedure": 1,
            "description": 1,
            "version": 1,
            "memory_lineage_id": 1,
            "reinforcement_count": 1,
            "tags": 1,
            "score": {"$meta": "vectorSearchScore"},
        }
    elif return_format == "dict":
        projection = {
            "_id": 1,
            "content": 1,
            "procedure": 1,
            "description": 1,
            "version": 1,
            "memory_lineage_id": 1,
            "reinforcement_count": 1,
            "tags": 1,
            "score": {"$meta": "vectorSearchScore"},
        }

    results = execute_vector_search(
        col,
        index_name=effective_index_name,
        query_embedding=query_embedding,
        rbac_filter=rbac_filter,
        collection_name=_PROCEDURAL_COL.name,
        org_id=org_id,
        top_k=top_k,
        similarity_threshold=similarity_threshold,
        metadata_filter=metadata_filter,
        projection=projection,
    )

    if return_format == "discovery":
        normalized = []
        for doc in results:
            normalized.append(
                {
                    "id": str(doc["_id"]),
                    "procedure": doc.get("procedure"),
                    "description": doc.get("description"),
                    "score": doc.get("score", 0.0),
                    "version": doc.get("version", 1),
                    "memory_lineage_id": doc.get("memory_lineage_id"),
                    "reinforcement_count": doc.get("reinforcement_count", 0),
                    "tags": doc.get("tags"),
                }
            )
        logger.debug(
            "Vector search returned %d procedural results (discovery format) for org=%s",
            len(normalized),
            org_id,
        )
        return normalized
    elif return_format == "dict":
        normalized = []
        for doc in results:
            normalized.append(
                {
                    "id": str(doc["_id"]),
                    "text": doc.get("content", ""),
                    "procedure": doc.get("procedure"),
                    "description": doc.get("description"),
                    "score": doc.get("score", 0.0),
                    "version": doc.get("version", 1),
                    "memory_lineage_id": doc.get("memory_lineage_id"),
                    "reinforcement_count": doc.get("reinforcement_count", 0),
                    "tags": doc.get("tags"),
                }
            )
        logger.debug(
            "Vector search returned %d procedural results (dict format) for org=%s user=%s",
            len(normalized),
            org_id,
            user_id,
        )
        return normalized
    else:
        parsed = [doc_to_output(d, ProceduralOut) for d in results if d]
        logger.debug(
            "Vector search returned %d procedural results (model format) for org=%s",
            len(parsed),
            org_id,
        )
        return parsed
