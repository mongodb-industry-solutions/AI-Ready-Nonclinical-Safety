from __future__ import annotations

import asyncio
import inspect
import logging
import signal
import sys
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Dict, Literal, Optional

from pymongo.database import Database

from ..mongomem_core import MemoryEngine
from ..mongomem_core.config import Settings as CoreSettings
from ..mongomem_core.observability import LoggingObservability
from ..mongomem_core.protocols import ObservabilityProtocol
from ..mongomem_core.storage import get_database
from .config import WorkerConfig, WorkerSettings
from .constants import (
    CORE_SNAPSHOT_COLLECTION,
    CORE_STM_COLLECTION,
    EXTRACTION_TYPES,
)
from .handlers.embeddings import EmbeddingHandler
from .handlers.entity import EntityHandler
from .handlers.ingest import IngestHandler
from .handlers.learning import (
    EpisodicHandler,
    PreferencesHandler,
    ProceduralHandler,
    SemanticHandler,
    TaxonomicHandler,
)
from .handlers.maintenance import MaintenanceHandler
from .handlers.snapshots import SnapshotHandler
from .observability import WorkerObservability
from .queue import (
    TaskQueueProcessor,
    enqueue_task,
    requeue_stale_tasks,
)
from .storage import (
    ensure_worker_collections,
    ensure_worker_indexes,
    get_tasks_collection,
)
from .storage.worker_state import WorkerStateStore
from .streams import MemoryChangeStreamManager

logger = logging.getLogger(__name__)


def _is_notebook() -> bool:
    try:
        from IPython import get_ipython

        ipython = get_ipython()
        if ipython is None:
            return False
        return bool(ipython.__class__.__name__ == "ZMQInteractiveShell")
    except (ImportError, AttributeError, NameError):
        return False


def _get_or_create_event_loop() -> asyncio.AbstractEventLoop:
    """Get existing event loop or create a new one (notebook-safe)."""
    try:
        loop = asyncio.get_running_loop()
        return loop
    except RuntimeError:
        return asyncio.new_event_loop()


ScalingMode = Literal["single", "distributed"]


class MongoMemWorker:
    """
    Background processor for memory embeddings and extractions.

    Inherits embedder/llm from MemoryEngine. Worker-specific config
    (extraction prompts, concurrency, etc.) is passed separately.

    Scaling Modes:
    - "single": Direct change stream watching (one worker only)
    - "distributed": Task queue with lease-based claiming (multiple workers)
    """

    def __init__(
        self,
        engine: MemoryEngine,
        *,
        extraction_config: Optional[Dict[str, Any]] = None,
        concurrency: int = 5,
        batch_size: int = 10,
        poll_interval_seconds: float = 1.0,
        tenant_id: Optional[str] = None,
        scaling_mode: ScalingMode = "single",
        worker_db_name: Optional[str] = None,
        observability: Optional[ObservabilityProtocol] = None,
        snapshot_config: Optional[Any] = None,
        auto_extract_on_snapshot: bool = False,
        embed_stm_before_promotion: bool = False,
    ) -> None:
        if engine.embedder is None:
            raise ValueError(
                "MemoryEngine must have an embedder attached. "
                "Use: MemoryEngine(embedder=MyEmbedder())"
            )

        self._engine = engine
        self._embedder = engine.embedder
        self._llm = engine.llm
        self._embed_stm_before_promotion = embed_stm_before_promotion

        mongo_uri = engine.settings.mongo_uri
        core_db_name = engine.settings.db_name
        effective_worker_db = worker_db_name or core_db_name

        # Get interval settings from environment if available
        env_settings = WorkerSettings()

        self._config = WorkerConfig(
            mongo_uri=mongo_uri,
            db_name=core_db_name,
            llm=self._llm,
            worker_db_name=worker_db_name,
            concurrency=concurrency,
            batch_size=batch_size,
            poll_interval_seconds=poll_interval_seconds,
            idle_threshold_seconds=env_settings.idle_threshold_seconds,
            idle_maintenance_interval=env_settings.idle_maintenance_interval,
            stale_requeue_interval=env_settings.stale_requeue_interval,
            queue_metrics_interval=env_settings.queue_metrics_interval,
            embed_thread_pool_size=env_settings.embed_thread_pool_size,
            lease_seconds=env_settings.lease_seconds,
            heartbeat_interval=env_settings.heartbeat_interval,
            # FIX: Pass change stream settings from env to config
            # Without this, MONGOMEM_WORKER_ENABLE_CHANGE_STREAMS and
            # MONGOMEM_WORKER_EMBEDDING_TRIGGER_MODE env vars were ignored
            enable_change_streams=env_settings.enable_change_streams,
            embedding_trigger_mode=env_settings.embedding_trigger_mode,
            auto_extract_on_snapshot=auto_extract_on_snapshot,
            snapshot_config=snapshot_config,
        )

        if extraction_config:
            for ext_type in [
                "taxonomic",
                "episodic",
                "semantic",
                "entity",
                "preferences",
                "procedural",
            ]:
                if ext_type in extraction_config:
                    from .config import ExtractionConfig

                    ext_settings = extraction_config[ext_type]
                    if isinstance(ext_settings, dict):
                        setattr(self._config, ext_type, ExtractionConfig(**ext_settings))

        self._core_settings = CoreSettings(
            mongo_uri=mongo_uri,
            db_name=core_db_name,
            embedding_dimension=self._embedder.dimension,
        )

        self._worker_settings = CoreSettings(
            mongo_uri=mongo_uri,
            db_name=effective_worker_db,
            embedding_dimension=self._embedder.dimension,
        )

        self._tenant_id = tenant_id
        self._scaling_mode = scaling_mode

        self._obs = WorkerObservability(
            backend=observability or LoggingObservability(),
            worker_id=None,  # Set after worker ID is generated
            tenant_id=tenant_id,
        )

        # Separate database connections
        self._core_db: Optional[Database] = None
        self._worker_db: Optional[Database] = None

        self._handlers: Dict[str, Any] = {}
        self._custom_handlers: Dict[str, Any] = {}  # User-registered handlers
        self._task_queue_processor: Optional[TaskQueueProcessor] = None
        self._worker_state: Optional[WorkerStateStore] = None

        self._shutdown_event = threading.Event()
        self._async_shutdown_event: Optional[asyncio.Event] = None
        self._worker_thread: Optional[threading.Thread] = None
        self._executor: Optional[ThreadPoolExecutor] = None

        # Idle detection - use configurable intervals
        self._last_task_time: Optional[datetime] = None
        self._idle_threshold_seconds: float = self._config.idle_threshold_seconds
        self._last_idle_maintenance: Optional[datetime] = None
        self._idle_maintenance_interval: float = self._config.idle_maintenance_interval
        self._last_stale_requeue: Optional[datetime] = None
        self._stale_requeue_interval: float = self._config.stale_requeue_interval

        # Queue depth metrics
        self._queue_metrics_task: Optional[asyncio.Task] = None
        self._queue_metrics_interval: float = self._config.queue_metrics_interval

        # Change streams (single mode only)
        self._change_stream_manager: Optional[MemoryChangeStreamManager] = None
        self._use_change_streams: bool = False

        logger.info(
            "MongoMemWorker initialized: core_db=%s, worker_db=%s, tenant=%s, mode=%s",
            core_db_name,
            effective_worker_db,
            tenant_id or "all",
            scaling_mode,
        )

    @property
    def engine(self) -> MemoryEngine:
        return self._engine

    @classmethod
    def from_env(
        cls,
        engine: MemoryEngine,
        *,
        extraction_config: Optional[Dict[str, Any]] = None,
        tenant_id: Optional[str] = None,
        scaling_mode: ScalingMode = "single",
    ) -> "MongoMemWorker":
        settings = WorkerSettings()
        return cls(
            engine=engine,
            extraction_config=extraction_config,
            concurrency=settings.max_concurrent,
            batch_size=settings.batch_size,
            poll_interval_seconds=settings.poll_interval_seconds,
            tenant_id=tenant_id,
            scaling_mode=scaling_mode,
            worker_db_name=settings.effective_worker_db,
        )

    def register_task(
        self,
        handler: Any,
        *,
        task_type: Optional[str] = None,
        timeout_seconds: Optional[int] = None,
    ) -> "MongoMemWorker":
        """
        Register a custom task handler.

        The handler will be automatically integrated with the worker's
        task processing loop (both single and distributed modes).

        Args:
            handler: Task handler instance. Should have:
                - task_type: str (or pass as argument)
                - timeout_seconds: int (or pass as argument, default: 300)
                - handle_task(payload): async method
                - Optional: process_pending() for polling mode
                - Optional: shutdown() for cleanup
            task_type: Override handler's task_type attribute
            timeout_seconds: Override handler's timeout_seconds attribute

        Returns:
            self for chaining

        Example:
            from .handlers import TaskHandler

            class MyHandler(TaskHandler):
                task_type = "my_task"
                timeout_seconds = 600

                async def handle_task(self, payload):
                    doc_id = payload["doc_id"]
                    # ... process ...

            worker = MongoMemWorker(engine)
            worker.register_task(MyHandler())
            worker.start_background()
        """
        # Get task_type from handler or argument
        handler_task_type = task_type or getattr(handler, "task_type", None)
        if not handler_task_type:
            raise ValueError("Handler must have task_type attribute or pass task_type argument")

        # Get timeout from handler or argument
        handler_timeout = timeout_seconds or getattr(handler, "timeout_seconds", 300)

        # Validate handler has required async method
        if not hasattr(handler, "handle_task"):
            raise ValueError("Handler must have handle_task(payload) method")
        if not inspect.iscoroutinefunction(handler.handle_task):
            raise ValueError("Handler.handle_task must be an async method")

        # Store with metadata
        self._custom_handlers[handler_task_type] = {
            "handler": handler,
            "timeout": handler_timeout,
        }

        logger.info(
            "Registered custom task handler: %s (timeout=%ds)",
            handler_task_type,
            handler_timeout,
        )

        return self

    def _get_core_db(self) -> Database:
        """Get core database connection (memory collections).

        Reuses the database connection from the MemoryEngine to avoid
        creating duplicate connections. This is more efficient and ensures
        connection pooling is properly shared.
        """
        if self._core_db is None:
            # Reuse the engine's database connection instead of creating a new one
            self._core_db = self._engine.db
            logger.info(
                "Reusing core database connection from engine: %s",
                self._config.effective_core_db,
            )
        return self._core_db

    def _get_worker_db(self) -> Database:
        """Get or create worker database connection (task queue, state).

        If worker_db_name is the same as core_db_name, reuses the core
        database connection. Otherwise, creates a new connection.
        """
        if self._worker_db is None:
            # Check if we can reuse the core database
            if self._config.effective_worker_db == self._config.effective_core_db:
                self._worker_db = self._get_core_db()
                logger.info(
                    "Reusing core database for worker: %s",
                    self._config.effective_worker_db,
                )
            else:
                # Different database - need separate connection
                self._worker_db = get_database(self._worker_settings)
                logger.info(
                    "Worker database connection established: %s",
                    self._config.effective_worker_db,
                )
            ensure_worker_collections(self._worker_db)
            ensure_worker_indexes(self._worker_db)
        return self._worker_db

    def _init_handlers(self) -> None:
        """Initialize task handlers based on configuration."""
        core_db = self._get_core_db()
        worker_db = self._get_worker_db()

        # Handlers that access memory collections use core_db
        self._handlers["embedding"] = EmbeddingHandler(
            db=core_db,
            embedder=self._embedder,
            batch_size=self._config.batch_size,
            embed_thread_pool_size=self._config.embed_thread_pool_size,
        )
        logger.debug("Registered embedding handler")

        if self._config.is_extraction_enabled("taxonomic"):
            self._handlers["taxonomic"] = TaxonomicHandler(
                db=core_db,
                llm=self._config.get_extraction_llm("taxonomic"),
                embedder=self._embedder,
                prompt=self._config.taxonomic.prompt,
            )
            logger.debug("Registered taxonomic extraction handler")

        if self._config.is_extraction_enabled("episodic"):
            self._handlers["episodic"] = EpisodicHandler(
                db=core_db,
                llm=self._config.get_extraction_llm("episodic"),
                prompt=self._config.episodic.prompt,
                embedder=self._embedder,
            )
            logger.debug("Registered episodic extraction handler")

        if self._config.is_extraction_enabled("semantic"):
            self._handlers["semantic"] = SemanticHandler(
                db=core_db,
                llm=self._config.get_extraction_llm("semantic"),
                embedder=self._embedder,
                prompt=self._config.semantic.prompt,
            )
            logger.debug("Registered semantic extraction handler")

        if self._config.is_extraction_enabled("entity"):
            self._handlers["entity"] = EntityHandler(
                db=core_db,
                llm=self._config.get_extraction_llm("entity"),
                prompt=self._config.entity.prompt,
            )
            logger.debug("Registered entity extraction handler")

        if self._config.is_extraction_enabled("preferences"):
            self._handlers["preferences"] = PreferencesHandler(
                db=core_db,
                llm=self._config.get_extraction_llm("preferences"),
                prompt=getattr(self._config.preferences, "prompt", None),
            )
            logger.debug("Registered preferences extraction handler")

        if self._config.is_extraction_enabled("procedural"):
            self._handlers["procedural"] = ProceduralHandler(
                db=core_db,
                llm=self._config.get_extraction_llm("procedural"),
                embedder=self._embedder,
                prompt=getattr(self._config.procedural, "prompt", None),
            )
            logger.debug("Registered procedural extraction handler")

        self._handlers["maintenance"] = MaintenanceHandler(db=core_db)
        logger.debug("Registered maintenance handler")

        self._handlers["snapshot"] = SnapshotHandler(
            db=core_db,
            embedder=self._embedder,
            config=self._config.snapshot_config,
            embed_thread_pool_size=self._config.embed_thread_pool_size,
            batch_size=self._config.batch_size,
            on_snapshot_created=(
                self._on_snapshot_created if self._config.auto_extract_on_snapshot else None
            ),
            embedding_handler=self._handlers.get("embedding")
            if self._embed_stm_before_promotion
            else None,
        )
        logger.debug("Registered snapshot handler")

        # Ingestion handler for async document processing
        self._handlers["ingest_documents"] = IngestHandler(
            engine=self._engine,
            db=worker_db,
        )
        logger.debug("Registered ingest_documents handler")

        # Add custom handlers registered via register_task()
        for task_type, entry in self._custom_handlers.items():
            self._handlers[task_type] = entry["handler"]
            logger.debug("Registered custom handler: %s", task_type)

        # Worker state uses worker database
        self._worker_state = WorkerStateStore(worker_db)

        if self._scaling_mode == "distributed":
            # Build task types and timeouts including custom handlers
            task_types = [
                "embedding",
                "snapshot",
                "taxonomic",
                "episodic",
                "semantic",
                "entity",
                "preferences",
                "procedural",
                "maintenance",
                "ingest_documents",  # Document ingestion handler
            ] + list(self._custom_handlers.keys())

            task_timeouts = {
                "embedding": self._config.task_timeouts.embedding,
                "snapshot": self._config.task_timeouts.snapshot,
                "taxonomic": self._config.task_timeouts.taxonomic,
                "episodic": self._config.task_timeouts.episodic,
                "semantic": self._config.task_timeouts.semantic,
                "entity": self._config.task_timeouts.entity,
                "preferences": getattr(self._config.task_timeouts, "preferences", 120.0),
                "maintenance": self._config.task_timeouts.maintenance,
                "ingest_documents": 3600.0,  # 1 hour for large file batches
            }
            # Add custom handler timeouts
            for task_type, entry in self._custom_handlers.items():
                task_timeouts[task_type] = entry["timeout"]

            # Task queue uses worker database
            self._task_queue_processor = TaskQueueProcessor(
                db=worker_db,
                task_types=task_types,
                lease_seconds=self._config.lease_seconds,
                poll_interval=self._config.poll_interval_seconds,
                task_timeouts=task_timeouts,
                heartbeat_interval=self._config.heartbeat_interval,
                observability=self._obs,
            )
            self._register_queue_handlers()
            logger.debug("Using distributed mode with task queue")
        else:
            # Single mode: set up change stream manager for push notifications
            self._change_stream_manager = MemoryChangeStreamManager(core_db)

        logger.info("Initialized %d handlers (mode=%s)", len(self._handlers), self._scaling_mode)

    def _register_queue_handlers(self) -> None:
        """Register handlers with the task queue processor (distributed mode)."""
        if not self._task_queue_processor:
            return

        def make_handler(handler_name: str):
            """Factory to create handler wrappers (avoids closure issues)."""

            async def handler(payload: Dict[str, Any]) -> None:
                h = self._handlers.get(handler_name)
                if h:
                    await h.handle_task(payload)

            return handler

        # Register all handlers (built-in + custom)
        for task_type in self._handlers.keys():
            self._task_queue_processor.register_handler(task_type, make_handler(task_type))

    def _enqueue_embedding(self, doc: Dict[str, Any]) -> None:
        """Enqueue an embedding task."""
        payload = {
            "doc_id": doc.get("_id"),
            "org_id": doc.get("org_id"),
            "content": doc.get("content"),
            "collection": CORE_STM_COLLECTION,
        }

        if self._scaling_mode == "distributed":
            enqueue_task(
                "embedding",
                payload,
                settings=WorkerSettings(
                    mongo_uri=self._config.mongo_uri,
                    db_name=self._config.effective_worker_db,
                ),
            )
        elif self._executor:
            self._executor.submit(self._run_handler_sync, "embedding", payload)

    def _enqueue_snapshot_embedding(self, doc: Dict[str, Any]) -> None:
        """Enqueue a snapshot embedding task."""
        payload = {
            "snapshot_id": doc.get("_id"),
            "org_id": doc.get("org_id"),
            "snapshot_task_type": "embed",
        }

        if self._scaling_mode == "distributed":
            enqueue_task(
                "snapshot",
                payload,
                settings=WorkerSettings(
                    mongo_uri=self._config.mongo_uri,
                    db_name=self._config.effective_worker_db,
                ),
            )
        elif self._executor:
            self._executor.submit(self._run_handler_sync, "snapshot", payload)

    def _on_snapshot_created(self, snapshot_doc: Dict[str, Any]) -> None:
        """
        Handle new snapshot creation - trigger enabled extractions.

        Called automatically when auto_extract_on_snapshot=True and a new
        snapshot is detected via change stream.

        Triggers ALL enabled extraction types (semantic, taxonomic, episodic, etc.)
        for the new snapshot.

        Args:
            snapshot_doc: Full snapshot document from MongoDB
        """
        messages = snapshot_doc.get("messages", [])
        if not messages:
            logger.debug("Skipping extraction for snapshot with no messages")
            return

        # Convert SnapshotMessage format to extraction format
        # Preserve agent_id per message for multi-agent attribution
        formatted_messages = []
        for msg in messages:
            if isinstance(msg, dict):
                msg_entry: Dict[str, Any] = {
                    "role": msg.get("role", "user"),
                    "content": msg.get("content", ""),
                }
                # Include agent_id if present (multi-agent support)
                if msg.get("agent_id"):
                    msg_entry["agent_id"] = msg["agent_id"]
                formatted_messages.append(msg_entry)

        base_payload: Dict[str, Any] = {
            "messages": formatted_messages,
            "org_id": snapshot_doc.get("org_id"),
            "user_id": snapshot_doc.get("user_id"),
            "source_id": str(snapshot_doc.get("_id")),
        }

        # Include contributing agent IDs for LTM provenance
        contributing_agent_ids = snapshot_doc.get("contributing_agent_ids")
        if contributing_agent_ids:
            base_payload["contributing_agent_ids"] = contributing_agent_ids

        snapshot_id = snapshot_doc.get("_id")

        # Trigger all enabled extraction types
        triggered = []

        for extraction_type in EXTRACTION_TYPES:
            if self._config.is_extraction_enabled(extraction_type):
                self._enqueue_extraction(extraction_type, base_payload, snapshot_id)
                triggered.append(extraction_type)

        if triggered:
            logger.info(
                "Auto-triggered extractions for snapshot %s: %s",
                snapshot_id,
                ", ".join(triggered),
            )

    def _enqueue_extraction(
        self,
        extraction_type: str,
        payload: Dict[str, Any],
        snapshot_id: Any,
    ) -> None:
        """
        Enqueue a single extraction task.

        Args:
            extraction_type: Type of extraction (semantic, taxonomic, etc.)
            payload: Task payload with messages, org_id, user_id, source_id
            snapshot_id: Snapshot ID for logging
        """
        # Idempotency: ensure we enqueue at most one extraction task per snapshot per type.
        source_id = payload.get("source_id")
        idempotency_key = None
        if source_id:
            idempotency_key = f"auto_extract:{extraction_type}:{source_id}"

        if self._scaling_mode == "distributed":
            enqueue_task(
                extraction_type,
                payload,
                idempotency_key=idempotency_key,
                settings=WorkerSettings(
                    mongo_uri=self._config.mongo_uri,
                    db_name=self._config.effective_worker_db,
                ),
            )
            logger.debug(
                "Enqueued %s extraction for snapshot %s",
                extraction_type,
                snapshot_id,
            )
        elif self._executor:
            self._executor.submit(self._run_handler_sync, extraction_type, payload)
            logger.debug(
                "Submitted %s extraction for snapshot %s",
                extraction_type,
                snapshot_id,
            )

    async def _start_auto_extraction_watcher(self) -> None:
        """
        Start the auto-extraction change stream watcher.

        Watches for new snapshot inserts and automatically triggers
        semantic extraction. This provides a "set-and-forget" mode where
        extraction happens without manual task enqueueing.
        """
        if not self._change_stream_manager:
            # Create a new manager for distributed mode
            from .streams import MemoryChangeStreamManager

            core_db = self._get_core_db()
            self._change_stream_manager = MemoryChangeStreamManager(core_db)

        watcher = self._change_stream_manager.create_snapshot_extraction_watcher(
            on_snapshot_created=self._on_snapshot_created
        )

        started = await watcher.start()
        if started:
            # List which extraction types are enabled
            enabled = [t for t in EXTRACTION_TYPES if self._config.is_extraction_enabled(t)]
            logger.info(
                "Auto-extraction mode ENABLED: %s will trigger automatically for new snapshots",
                ", ".join(enabled) if enabled else "no extractions",
            )
        else:
            logger.warning("Auto-extraction watcher failed to start (change streams unavailable?)")

    def _run_handler_sync(self, handler_name: str, payload: Dict[str, Any]) -> None:
        """Run a handler synchronously (for thread pool)."""
        handler = self._handlers.get(handler_name)
        if not handler:
            logger.warning("No handler registered for %s", handler_name)
            return

        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                loop.run_until_complete(handler.handle_task(payload))
            finally:
                loop.close()

            if self._worker_state:
                self._worker_state.record_processed(handler_name, success=True)
        except Exception as exc:
            logger.error("Handler %s failed: %s", handler_name, exc)
            if self._worker_state:
                self._worker_state.record_processed(handler_name, success=False)

    def initialize(self) -> None:
        """Initialize handlers without starting the processing loop.

        Use this when the worker is driven externally (e.g. via an HTTP endpoint)
        rather than running its own loop. In distributed mode the executor is not
        needed — tasks run directly in the asyncio event loop.

        Raises:
            RuntimeError: If not in distributed mode or if change streams are enabled.
                On-demand processing requires distributed mode with change streams
                disabled to avoid split-brain between polling and push notifications.
        """
        if self._scaling_mode != "distributed":
            raise RuntimeError(
                f"On-demand processing (initialize) requires scaling_mode='distributed', "
                f"got '{self._scaling_mode}'."
            )
        if self._config.enable_change_streams:
            raise RuntimeError(
                "On-demand processing (initialize) requires enable_change_streams=False. "
                "Change streams must be disabled to avoid conflict with the polling pipeline."
            )
        self._init_handlers()

    def run(self) -> None:
        """
        Start the worker (blocks).

        For production use. Sets up signal handlers for graceful shutdown.
        NOT recommended for Jupyter notebooks - use start_background() instead.
        """
        if _is_notebook():
            logger.warning(
                "run() is not recommended in Jupyter notebooks. Use start_background() instead."
            )

        logger.info("Starting MongoMemWorker...")

        if sys.platform != "win32":
            signal.signal(signal.SIGINT, self._signal_handler)
            signal.signal(signal.SIGTERM, self._signal_handler)

        self._init_handlers()
        self._executor = ThreadPoolExecutor(max_workers=self._config.concurrency)

        try:
            asyncio.run(self._run_async())
        except KeyboardInterrupt:
            logger.info("Received keyboard interrupt, shutting down...")
        finally:
            self._cleanup()
            logger.info("MongoMemWorker stopped")

    def start_background(self) -> "MongoMemWorker":
        """
        Start the worker in a background thread (non-blocking).

        Safe for Jupyter notebooks and interactive environments.
        Returns self for chaining.

        Example:
            worker = MongoMemWorker(...).start_background()
            # ... do other work ...
            worker.stop()
        """
        if self._worker_thread and self._worker_thread.is_alive():
            logger.warning("Worker already running in background")
            return self

        self._shutdown_event.clear()
        self._worker_thread = threading.Thread(
            target=self._run_in_thread,
            name="MongoMemWorker",
            daemon=True,
        )
        self._worker_thread.start()
        logger.info("MongoMemWorker started in background thread")
        return self

    def _run_in_thread(self) -> None:
        """Run the worker in a background thread."""
        self._init_handlers()
        self._executor = ThreadPoolExecutor(max_workers=self._config.concurrency)

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        try:
            loop.run_until_complete(self._run_async())
        except Exception as exc:
            logger.exception("Worker thread error: %s", exc)
        finally:
            loop.close()
            self._cleanup()

    async def run_async(self) -> None:
        """
        Async version for integration with existing event loops.

        Use this when you already have an async application.
        """
        self._async_shutdown_event = asyncio.Event()
        self._init_handlers()
        self._executor = ThreadPoolExecutor(max_workers=self._config.concurrency)

        try:
            await self._run_async()
        finally:
            self._cleanup()

    async def _run_async(self) -> None:
        """Main async processing loop."""
        logger.info("Worker processing loop started")

        if self._worker_state:
            self._worker_state.heartbeat(status="running")

        self._obs.worker_active(True)
        self._last_task_time = datetime.now(timezone.utc)

        # Start change streams for single mode (push notifications)
        if self._scaling_mode == "single" and self._change_stream_manager:
            if not self._config.enable_change_streams:
                logger.info("Change streams disabled by config, using polling mode")
                self._obs.change_stream_active(False)
            else:
                self._use_change_streams = await self._change_stream_manager.start_all()
                if self._use_change_streams:
                    logger.info("Using change streams for push notifications")
                    self._obs.change_stream_active(True)
                else:
                    logger.warning("Change streams unavailable, using polling fallback")
                    self._obs.change_stream_active(False)

                # Start auto-extraction watcher if enabled
                if self._config.auto_extract_on_snapshot:
                    await self._start_auto_extraction_watcher()
                # Start embedding triggers if configured and change streams are active
                await self._start_embedding_triggers_if_enabled()

        # Start auto-extraction in distributed mode too (if enabled)
        if self._scaling_mode == "distributed" and self._config.auto_extract_on_snapshot:
            await self._start_auto_extraction_watcher()
            # If change streams are not available, ensure we still auto-extract via polling.
            if not self._config.enable_change_streams or not self._use_change_streams:
                asyncio.create_task(self._poll_for_new_snapshots_to_extract())

        # Start queue metrics background task (distributed mode)
        if self._scaling_mode == "distributed":
            self._queue_metrics_task = asyncio.create_task(self._update_queue_metrics())
            logger.debug("Started queue metrics background task")

        try:
            while not self._shutdown_event.is_set():
                if self._async_shutdown_event and self._async_shutdown_event.is_set():
                    break

                try:
                    processed = await self.process_batch()

                    if processed > 0:
                        self._last_task_time = datetime.now(timezone.utc)
                        status = "running"
                        idle_seconds = 0.0
                        self._obs.active_tasks(processed)
                    else:
                        idle_seconds = self._get_idle_seconds()
                        is_idle = idle_seconds > self._idle_threshold_seconds
                        status = "idle" if is_idle else "running"

                        if status == "idle":
                            self._obs.worker_idle(idle_seconds)
                            await self._run_idle_tasks()

                    if self._worker_state:
                        self._worker_state.heartbeat(
                            status=status,
                            metadata={"idle_seconds": idle_seconds},
                        )

                    # Wait for work: use change streams if available, otherwise poll
                    if processed == 0:
                        await self._wait_for_work()

                except Exception as exc:
                    logger.exception("Error in processing loop: %s", exc)
                    await asyncio.sleep(self._config.poll_interval_seconds)
        finally:
            # Cleanup change streams
            if self._change_stream_manager:
                self._change_stream_manager.stop_all()

            # Cleanup queue metrics task
            if self._queue_metrics_task and not self._queue_metrics_task.done():
                self._queue_metrics_task.cancel()
                try:
                    await self._queue_metrics_task
                except asyncio.CancelledError:
                    pass

        self._obs.worker_active(False)

        if self._worker_state:
            self._worker_state.shutdown()

        logger.info("Worker processing loop ended")

    def _embedding_mode_allows_polling(self) -> bool:
        mode = getattr(self._config, "embedding_trigger_mode", "auto")
        if mode in ("polling", "both"):
            return True
        if mode == "auto":
            # Polling is used when change streams aren't available.
            return not (self._use_change_streams and self._change_stream_manager)
        return False

    def _embedding_mode_allows_change_streams(self) -> bool:
        mode = getattr(self._config, "embedding_trigger_mode", "auto")
        if mode in ("change_streams", "both"):
            return True
        if mode == "auto":
            return True
        return False

    async def _start_embedding_triggers_if_enabled(self) -> None:
        """
        When change streams are available, directly embed new docs missing embeddings.

        This avoids collection scans in steady state. Polling remains as a safety sweep
        (depending on embedding_trigger_mode).
        """
        if not self._change_stream_manager:
            return
        if not self._use_change_streams:
            return
        if not self._embedding_mode_allows_change_streams():
            return

        embedding_handler: Optional[EmbeddingHandler] = self._handlers.get("embedding")
        if not embedding_handler:
            return

        # Create embedding trigger watchers (doc-level callbacks).
        def on_doc_needs_embedding(payload: Dict[str, Any]) -> None:
            try:
                asyncio.create_task(embedding_handler.handle_task(payload))
            except Exception as exc:
                logger.error("Failed to schedule embedding task from change stream: %s", exc)

        self._change_stream_manager.enable_embedding_triggers(on_doc_needs_embedding)
        logger.info("Embedding change-stream triggers enabled (no-scan steady state)")

    async def _poll_for_new_snapshots_to_extract(self) -> None:
        """
        Polling fallback for auto-extraction when change streams are unavailable.

        Uses an atomic claim marker on snapshot documents to prevent duplicate enqueue.
        Intended for smaller dev setups (standalone MongoDB) where change streams aren't supported.
        """
        if not self._config.auto_extract_on_snapshot:
            return

        core_db = self._get_core_db()
        snapshots = core_db[CORE_SNAPSHOT_COLLECTION]

        while not self._shutdown_event.is_set():
            try:
                now = datetime.now(timezone.utc)
                doc = snapshots.find_one_and_update(
                    {
                        "_auto_extraction_enqueued": {"$in": [None, False]},
                        "deleted": {"$ne": True},
                    },
                    {
                        "$set": {
                            "_auto_extraction_enqueued": True,
                            "_auto_extraction_enqueued_at": now,
                        }
                    },
                    sort=[("timestamp", 1)],
                    return_document=False,
                )
                if doc:
                    # Enqueue extraction tasks using existing handler logic
                    self._on_snapshot_created(doc)
                else:
                    await asyncio.sleep(self._config.poll_interval_seconds)
            except Exception as exc:
                logger.error("Auto-extraction polling loop error: %s", exc)
                await asyncio.sleep(self._config.poll_interval_seconds)

    async def _wait_for_work(self) -> None:
        """
        Wait for work to become available.

        Uses change streams if available (push-based), otherwise polls.
        This reduces unnecessary DB queries when there's no work.
        """
        if self._use_change_streams and self._change_stream_manager:
            # Wait for change stream notification or timeout
            got_change = await self._change_stream_manager.wait_for_change(
                timeout=self._config.poll_interval_seconds
            )
            if got_change:
                logger.debug("Change stream notification received")
        else:
            # Fallback to polling
            await asyncio.sleep(self._config.poll_interval_seconds)

    async def process_batch(self) -> int:
        """Process a batch of pending tasks. Returns count of tasks processed."""
        total_processed = 0

        if self._scaling_mode == "distributed" and self._task_queue_processor:
            for _ in range(self._config.batch_size):
                if await self._task_queue_processor.process_one():
                    total_processed += 1
                else:
                    break

            self._maybe_requeue_stale_tasks()
        else:
            embedding_handler = self._handlers.get("embedding")
            if embedding_handler:
                if self._embedding_mode_allows_polling():
                    count = await embedding_handler.process_pending()
                    total_processed += count

            snapshot_handler = self._handlers.get("snapshot")
            if snapshot_handler:
                count = await snapshot_handler.process_pending()
                total_processed += count

        return total_processed

    def _get_idle_seconds(self) -> float:
        """Get seconds since last task was processed."""
        if not self._last_task_time:
            return 0.0
        return (datetime.now(timezone.utc) - self._last_task_time).total_seconds()

    def _maybe_requeue_stale_tasks(self) -> None:
        """Periodically requeue stale tasks (distributed mode only)."""
        now = datetime.now(timezone.utc)
        if self._last_stale_requeue:
            since_last = (now - self._last_stale_requeue).total_seconds()
            if since_last < self._stale_requeue_interval:
                return

        self._last_stale_requeue = now
        count = requeue_stale_tasks(get_tasks_collection(self._get_worker_db()))
        if count > 0:
            self._obs.stale_tasks_reclaimed(count)

    async def _update_queue_metrics(self) -> None:
        """Background task to update queue depth metrics."""
        while not self._shutdown_event.is_set():
            try:
                tasks_col = get_tasks_collection(self._get_worker_db())

                # Count pending/queued tasks
                queued_count = tasks_col.count_documents({"status": "queued"})
                self._obs.queue_depth(queued_count, status="queued")

                # Count running tasks
                running_count = tasks_col.count_documents({"status": "running"})
                self._obs.queue_depth(running_count, status="running")

                logger.debug("Queue metrics: queued=%d, running=%d", queued_count, running_count)
            except Exception as exc:
                logger.warning("Failed to update queue metrics: %s", exc)

            # Check for async shutdown too
            if self._async_shutdown_event and self._async_shutdown_event.is_set():
                break

            await asyncio.sleep(self._queue_metrics_interval)

    @property
    def is_idle(self) -> bool:
        """Check if the worker is currently idle."""
        return self._get_idle_seconds() > self._idle_threshold_seconds

    @property
    def idle_seconds(self) -> float:
        """Get seconds since last task was processed."""
        return self._get_idle_seconds()

    async def _run_idle_tasks(self) -> None:
        """
        Run maintenance tasks during idle time.

        This is triggered when the worker has no tasks to process,
        using the idle time productively for:
        - Snapshot promotion (STM → Snapshot)
        - Memory consolidation
        - Cleanup of expired documents
        """
        now = datetime.now(timezone.utc)

        if self._last_idle_maintenance:
            since_last = (now - self._last_idle_maintenance).total_seconds()
            if since_last < self._idle_maintenance_interval:
                return

        logger.debug("Running idle maintenance tasks...")
        self._last_idle_maintenance = now

        try:
            maintenance_handler = self._handlers.get("maintenance")
            if maintenance_handler:
                result = await maintenance_handler.run_scheduled_maintenance()
                if result:
                    logger.info("Idle maintenance completed: %s", result)

            snapshot_handler = self._handlers.get("snapshot")
            if snapshot_handler:
                promoted = await snapshot_handler.process_pending()
                if promoted > 0:
                    logger.info("Idle: promoted %d snapshots", promoted)

            embedding_handler = self._handlers.get("embedding")
            if embedding_handler:
                embedded = await embedding_handler.process_pending()
                if embedded > 0:
                    logger.info("Idle: embedded %d documents", embedded)
                    self._last_task_time = datetime.now(timezone.utc)

        except Exception as exc:
            logger.warning("Idle maintenance task failed: %s", exc)

    # -------------------------------------------------------------------------
    # Live Configuration Updates (no restart required)
    # -------------------------------------------------------------------------

    def update_prompt(
        self,
        extraction_type: str,
        prompt: str,
    ) -> None:
        """
        Update extraction prompt live (no restart needed).

        Args:
            extraction_type: "taxonomic", "episodic", "semantic", or "entity"
            prompt: New prompt template (use {content} placeholder)

        Example:
            worker.update_prompt("taxonomic", "Extract key concepts: {content}")
        """
        handler = self._handlers.get(extraction_type)
        if handler is None:
            logger.warning("No handler found for %s", extraction_type)
            return

        if hasattr(handler, "_prompt"):
            handler._prompt = prompt
            logger.info("Updated %s prompt (len=%d)", extraction_type, len(prompt))
        else:
            logger.warning("Handler %s doesn't support prompt updates", extraction_type)

    def update_llm(
        self,
        extraction_type: str,
        llm: Any,
    ) -> None:
        """
        Swap LLM for an extraction handler live (no restart needed).

        Args:
            extraction_type: "taxonomic", "episodic", "semantic", or "entity"
            llm: New LLM instance (must implement LLMProtocol)

        Example:
            worker.update_llm("taxonomic", new_openai_client)
        """
        handler = self._handlers.get(extraction_type)
        if handler is None:
            logger.warning("No handler found for %s", extraction_type)
            return

        if hasattr(handler, "_llm"):
            old_model = getattr(handler._llm, "model_id", "unknown") if handler._llm else "none"
            handler._llm = llm
            new_model = getattr(llm, "model_id", "unknown") if llm else "none"
            logger.info("Swapped %s LLM: %s → %s", extraction_type, old_model, new_model)
        else:
            logger.warning("Handler %s doesn't support LLM updates", extraction_type)

    def update_embedder(self, embedder: Any) -> None:
        """
        Swap embedder live (no restart needed).

        Args:
            embedder: New embedder instance (must implement EmbedderProtocol)

        Example:
            worker.update_embedder(new_openai_embedder)
        """
        old_model = getattr(self._embedder, "model_id", "unknown")
        self._embedder = embedder

        # Update embedding handler
        handler = self._handlers.get("embedding")
        if handler and hasattr(handler, "_embedder"):
            handler._embedder = embedder

        # Update snapshot handler (also uses embedder)
        snap_handler = self._handlers.get("snapshot")
        if snap_handler and hasattr(snap_handler, "_embedder"):
            snap_handler._embedder = embedder

        # Update semantic handler (uses embedder for consolidation pipeline)
        sem_handler = self._handlers.get("semantic")
        if sem_handler and hasattr(sem_handler, "_embedder"):
            sem_handler._embedder = embedder

        new_model = getattr(embedder, "model_id", "unknown")
        logger.info("Swapped embedder: %s → %s", old_model, new_model)

    def update_batch_size(self, batch_size: int) -> None:
        """
        Update batch size live (no restart needed).

        Args:
            batch_size: New batch size for processing
        """
        old_size = self._config.batch_size
        self._config = WorkerConfig(**{**self._config.__dict__, "batch_size": batch_size})
        logger.info("Updated batch_size: %d → %d", old_size, batch_size)

    def get_prompt(self, extraction_type: str) -> Optional[str]:
        """
        Get current prompt for an extraction type.

        Args:
            extraction_type: "taxonomic", "episodic", "semantic", or "entity"

        Returns:
            Current prompt string or None if handler not found
        """
        handler = self._handlers.get(extraction_type)
        if handler and hasattr(handler, "_prompt"):
            prompt = getattr(handler, "_prompt", None)
            return str(prompt) if prompt is not None else None
        return None

    def get_config_snapshot(self) -> Dict[str, Any]:
        """
        Get current configuration snapshot (for debugging/display).

        Returns:
            Dict with current prompts, models, and settings
        """
        return {
            "embedder_model": getattr(self._embedder, "model_id", "unknown"),
            "llm_model": getattr(self._llm, "model_id", "unknown") if self._llm else None,
            "batch_size": self._config.batch_size,
            "concurrency": self._config.concurrency,
            "scaling_mode": self._scaling_mode,
            "prompts": {
                ext_type: self.get_prompt(ext_type)
                for ext_type in ["taxonomic", "episodic", "semantic", "entity"]
                if self.get_prompt(ext_type)
            },
            "handlers_registered": list(self._handlers.keys()),
        }

    def run_once(self) -> int:
        """
        Process pending tasks once (for testing/cron).

        Notebook-safe: uses nest_asyncio if available.

        Returns:
            Number of tasks processed
        """
        self._init_handlers()

        if _is_notebook():
            try:
                import nest_asyncio

                nest_asyncio.apply()
            except ImportError:
                pass

        try:
            loop = asyncio.get_running_loop()
            future = asyncio.ensure_future(self.process_batch())
            return loop.run_until_complete(future)
        except RuntimeError:
            return asyncio.run(self.process_batch())

    def stop(self) -> None:
        """Signal graceful shutdown."""
        logger.info("Stopping worker...")
        self._shutdown_event.set()
        if self._async_shutdown_event:
            self._async_shutdown_event.set()

    def shutdown(self) -> None:
        """Signal shutdown and release all handler resources.

        Call this when the worker will no longer process tasks — e.g. on server
        shutdown. Signals stop and joins all handler thread pools so the process
        can exit cleanly.
        """
        self.stop()
        self._cleanup()

    def _cleanup(self) -> None:
        """Clean up resources including handler thread pools."""
        if self._executor:
            self._executor.shutdown(wait=True)
            self._executor = None

        # Shutdown handler thread pools
        for handler_name, handler in self._handlers.items():
            if hasattr(handler, "shutdown"):
                try:
                    handler.shutdown()
                    logger.debug("Shutdown handler %s thread pool", handler_name)
                except Exception as exc:
                    logger.warning("Failed to shutdown handler %s: %s", handler_name, exc)

    def _signal_handler(self, signum: int, frame: Any) -> None:
        """Handle shutdown signals."""
        logger.info("Received signal %d, initiating shutdown...", signum)
        self.stop()

    def wait(self, timeout: Optional[float] = None) -> bool:
        """
        Wait for the background worker to finish.

        Args:
            timeout: Maximum time to wait (None = forever)

        Returns:
            True if worker stopped, False if timeout
        """
        if self._worker_thread:
            self._worker_thread.join(timeout=timeout)
            return not self._worker_thread.is_alive()
        return True

    @property
    def is_running(self) -> bool:
        """Check if the worker is currently running."""
        if self._worker_thread:
            return self._worker_thread.is_alive()
        return False

    @property
    def config(self) -> WorkerConfig:
        """Access the worker configuration."""
        return self._config

    @property
    def handlers(self) -> Dict[str, Any]:
        """Access registered handlers (for testing)."""
        return self._handlers

    @property
    def tenant_id(self) -> Optional[str]:
        """Get the tenant ID this worker is scoped to."""
        return self._tenant_id

    @property
    def scaling_mode(self) -> ScalingMode:
        """Get the scaling mode (single or distributed)."""
        return self._scaling_mode


__all__ = ["MongoMemWorker", "ScalingMode"]
