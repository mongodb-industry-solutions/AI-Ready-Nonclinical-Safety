"""
Retrieval constants.

NOTE: Constants are now defined in mongomem_core.common.constants for single source of truth.
This module re-exports them for backwards compatibility.
"""

from __future__ import annotations

# Re-export from canonical location
from mongomem_core.common.constants import (
    DEFAULT_MAX_TOKENS,
    FETCH_TIMEOUT_SECONDS,
    LARGE_MEMORY_LIST_THRESHOLD,
    REQUIRED_SOURCES,
)

__all__ = [
    "DEFAULT_MAX_TOKENS",
    "FETCH_TIMEOUT_SECONDS",
    "LARGE_MEMORY_LIST_THRESHOLD",
    "REQUIRED_SOURCES",
]
