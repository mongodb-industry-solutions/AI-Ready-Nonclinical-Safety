"""
Semantic extraction pipeline.

Provides SemanticPipeline class and factory function for creating
complete semantic extraction pipelines with ExoMemory parity.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

if TYPE_CHECKING:
    from mongomem_core.protocols import EmbedderProtocol, LLMProtocol
    from pymongo.database import Database

from mongomem_core.extraction.config import SemanticExtractionConfig
from mongomem_core.extraction.consolidator import (
    ConsolidationStrategy,
    Consolidator,
    LLMBasedStrategy,
    RuleBasedStrategy,
)
from mongomem_core.extraction.enrichment import enrich_citations
from mongomem_core.extraction.persistence import apply_decisions
from mongomem_core.extraction.scorer import filter_valid, score_batch
from mongomem_core.extraction.semantic.extractor import SemanticExtractor
from mongomem_core.extraction.types import (
    ApprovalMode,
    ConsolidationStats,
    ExtractionMetadata,
    ExtractionResult,
)
from mongomem_core.memory.semantic import search_semantic
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.observability import CoreObservability

logger = logging.getLogger(__name__)


class SemanticPipeline:
    """
    Full semantic extraction pipeline with ExoMemory parity.

    Orchestrates:
    1. Extract - LLM-based extraction from messages
    2. Enrich - Add citation text from source messages
    3. Score - Validate and score extractions
    4. Search - Find similar existing memories
    5. Decide - Consolidate with existing KB
    6. Persist - Idempotent database operations
    """

    def __init__(
        self,
        extractor: SemanticExtractor,
        config: SemanticExtractionConfig,
        consolidator: Consolidator,
        db: "Database",
        embedding_model_id: str,
        obs: Optional[CoreObservability] = None,
    ) -> None:
        """
        Initialize semantic pipeline.

        Args:
            extractor: SemanticExtractor instance
            config: Extraction configuration
            consolidator: Consolidator instance
            db: MongoDB database instance
            embedding_model_id: ID of embedding model used
            obs: Optional CoreObservability for observability (metrics/spans/events)
        """
        self.extractor = extractor
        self.config = config
        self.consolidator = consolidator
        self._db = db
        self._embedding_model_id = embedding_model_id
        self._obs = obs or CoreObservability()

    def run(
        self,
        messages: List[Dict[str, Any]],
        org_id: str,
        user_id: str,
        source_id: str,
        approval_mode: ApprovalMode = "auto",
        visibility: ChunkVisibility = ChunkVisibility.PRIVATE,
        project_id: Optional[str] = None,
    ) -> ExtractionResult:
        """
        Run full semantic extraction pipeline.

        Matches ExoMemory's SemanticExtractor.extract_from_snapshot().

        Args:
            messages: Conversation messages to extract from
            org_id: Organization ID
            user_id: User ID
            source_id: Source reference (snapshot ID)
            approval_mode: "auto" persists immediately, "manual" stages for review
            visibility: Visibility scope for created memories
            project_id: Project ID (required if visibility=SHARED)

        Returns:
            ExtractionResult with counts, IDs, and statistics
        """
        with self._obs.span_extraction("semantic") as span:
            return self._run_internal(
                messages=messages,
                org_id=org_id,
                user_id=user_id,
                source_id=source_id,
                approval_mode=approval_mode,
                visibility=visibility,
                project_id=project_id,
                span=span,
            )

    def _run_internal(
        self,
        messages: List[Dict[str, Any]],
        org_id: str,
        user_id: str,
        source_id: str,
        approval_mode: ApprovalMode,
        visibility: ChunkVisibility,
        project_id: Optional[str],
        span: Dict[str, Any],
    ) -> ExtractionResult:
        result = ExtractionResult(source_reference=source_id, approval_mode=approval_mode)
        start_time = datetime.now(timezone.utc)
        raw: List[Any] = []

        try:
            # Check if enabled
            if not self.config.enabled:
                logger.debug("Semantic extraction disabled")
                result.success = True
                return result

            # 1. Extract
            raw = self.extractor.extract(messages)
            result.extracted_count = len(raw)
            logger.debug("Extracted %d raw memories", len(raw))

            if not raw:
                result.success = True
                return result

            # Limit extractions per snapshot
            if len(raw) > self.config.max_facts_per_snapshot:
                logger.info(
                    "Limiting extractions from %d to %d",
                    len(raw),
                    self.config.max_facts_per_snapshot,
                )
                raw = raw[: self.config.max_facts_per_snapshot]

            # 2. Enrich citations
            enrich_citations(raw, messages)

            # 3. Score and filter
            scored = score_batch(raw, self.config)
            valid = filter_valid(scored)
            result.validation_failures = len(scored) - len(valid)
            logger.debug(
                "After scoring: %d/%d passed threshold",
                len(valid),
                len(scored),
            )

            if not valid:
                result.success = True
                return result

            # 4-5. Consolidate (search + decide)
            decisions = self.consolidator.process(valid, org_id, user_id)
            logger.debug("Consolidation returned %d decisions", len(decisions))

            # 6. Persist or Stage
            extraction_timestamp = datetime.now(timezone.utc)

            if approval_mode == "manual":
                # Stage instead of persist
                from mongomem_core.extraction.approval.store import PendingStore
                from mongomem_core.extraction.approval.types import (
                    ExtractionType,
                    PendingDecisionPayload,
                    PendingPayload,
                )

                store = PendingStore(self._db, obs=self._obs)
                items: list[tuple[ExtractionType, PendingPayload]] = []
                for d in decisions:
                    if d.action == "DUPLICATE":
                        continue
                    payload = PendingDecisionPayload(
                        action=d.action,
                        content=d.extraction.content,
                        citations=d.extraction.citations,
                        confidence=d.extraction.confidence,
                        citation_score=d.extraction.citation_score,
                        combined_score=d.extraction.combined_score,
                        embedding=d.extraction.embedding,
                        embedding_model_id=self._embedding_model_id,
                        cited_text=d.extraction.cited_text,
                        metadata=d.extraction.metadata,
                        existing_id=d.existing_id,
                        reason=d.reason,
                    )
                    items.append(("semantic", payload))

                pending_ids = store.stage_batch(
                    items=items,
                    org_id=org_id,
                    user_id=user_id,
                    source_id=source_id,
                    visibility=visibility,
                    project_id=project_id,
                )
                result.pending_ids = pending_ids
                result.consolidation_stats = ConsolidationStats(
                    add_count=sum(1 for d in decisions if d.action == "ADD"),
                    update_count=sum(1 for d in decisions if d.action == "UPDATE"),
                    reinforce_count=sum(1 for d in decisions if d.action == "REINFORCE"),
                    duplicate_count=sum(1 for d in decisions if d.action == "DUPLICATE"),
                )
            else:
                persist_result = apply_decisions(
                    db=self._db,
                    decisions=decisions,
                    org_id=org_id,
                    user_id=user_id,
                    source_id=source_id,
                    extraction_timestamp=extraction_timestamp,
                    embedding_model_id=self._embedding_model_id,
                    config=self.config,
                    visibility=visibility,
                    project_id=project_id,
                )

                # Update result
                result.stored_count = persist_result.added + persist_result.updated
                result.created_ids = persist_result.created_ids
                result.updated_ids = persist_result.updated_new_version_ids
                result.reinforced_ids = persist_result.reinforced_ids
                result.consolidation_stats = ConsolidationStats(
                    add_count=persist_result.added,
                    update_count=persist_result.updated,
                    reinforce_count=persist_result.reinforced,
                    duplicate_count=persist_result.skipped,
                )
                result.errors = persist_result.errors

            # Add sample extractions for observability
            result.sample_extractions = [
                {
                    "content": e.content[: self.config.sample_text_truncate_length],
                    "confidence": e.confidence,
                    "citations": e.citations,
                }
                for e in raw[: self.config.max_sample_extractions]
            ]

            result.success = True

        except Exception as e:
            result.errors.append(str(e))
            logger.error("Semantic extraction failed: %s", e, exc_info=True)
            self._obs.extraction_failed("semantic", str(e), source_id)

        finally:
            processing_time_ms = int(
                (datetime.now(timezone.utc) - start_time).total_seconds() * 1000
            )
            result.metadata = ExtractionMetadata(
                processing_time_ms=processing_time_ms,
                extraction_timestamp=start_time,
            )

            # Update span attributes
            span["duration_ms"] = processing_time_ms
            span["extracted_count"] = result.extracted_count
            span["success"] = result.success

            # Emit all extraction metrics in one call
            stats = result.consolidation_stats
            self._obs.emit_extraction_result(
                extraction_type="semantic",
                extracted_count=result.extracted_count,
                duration_ms=processing_time_ms,
                add_count=stats.add_count if stats else 0,
                update_count=stats.update_count if stats else 0,
                reinforce_count=stats.reinforce_count if stats else 0,
                duplicate_count=stats.duplicate_count if stats else 0,
            )

        return result


def create_semantic_pipeline(
    db: "Database",
    llm: "LLMProtocol",
    embedder: "EmbedderProtocol",
    config: Optional[SemanticExtractionConfig] = None,
    extraction_prompt_resolver: Optional[Callable[[], Optional[str]]] = None,
    consolidation_prompt_resolver: Optional[Callable[[], Optional[str]]] = None,
    use_llm_consolidation: bool = True,
    obs: Optional[CoreObservability] = None,
) -> SemanticPipeline:
    """
    Factory function to create a semantic pipeline with hot-swap support.

    Args:
        db: MongoDB database instance
        llm: LLM protocol implementation
        embedder: Embedder protocol implementation
        config: Optional extraction configuration (uses defaults if not provided)
        extraction_prompt_resolver: Optional callable for hot-reload extraction prompts
        consolidation_prompt_resolver: Optional callable for hot-reload consolidation prompts
        use_llm_consolidation: If True, use LLM-based consolidation. Otherwise use rule-based.
        obs: Optional CoreObservability for observability (metrics/spans/events)

    Returns:
        Configured SemanticPipeline ready to run
    """
    config = config or SemanticExtractionConfig()

    # Create extractor with hot-reload support
    extractor = SemanticExtractor(llm, extraction_prompt_resolver)

    # Create consolidation strategy
    strategy: ConsolidationStrategy
    if use_llm_consolidation:
        strategy = LLMBasedStrategy(llm, consolidation_prompt_resolver)
    else:
        strategy = RuleBasedStrategy(
            reinforce_threshold=0.95,
            update_threshold=config.consolidation_similarity_threshold,
        )

    # Create consolidator
    consolidator = Consolidator(
        db=db,
        embedder=embedder,
        strategy=strategy,
        search_fn=search_semantic,
        config=config,  # type: ignore[arg-type]
    )

    return SemanticPipeline(
        extractor=extractor,
        config=config,
        consolidator=consolidator,
        db=db,
        embedding_model_id=embedder.model_id,
        obs=obs,
    )


__all__ = [
    "SemanticPipeline",
    "SemanticExtractor",
    "create_semantic_pipeline",
]
