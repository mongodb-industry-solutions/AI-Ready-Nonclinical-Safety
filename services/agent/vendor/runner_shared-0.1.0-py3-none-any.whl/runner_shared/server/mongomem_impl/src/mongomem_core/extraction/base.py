"""
Base classes and protocols for extractors.

Provides ExtractorProtocol and BaseExtractor with hot-reload support
for prompts.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Protocol, runtime_checkable

if TYPE_CHECKING:
    from mongomem_core.protocols import LLMProtocol

from mongomem_core.extraction.types import ExtractedItem

logger = logging.getLogger(__name__)


@runtime_checkable
class ExtractorProtocol(Protocol):
    """Protocol for all extractors."""

    extraction_type: str

    def extract(self, messages: List[Dict[str, Any]]) -> List[ExtractedItem]:
        """Extract items from conversation messages."""
        ...


class BaseExtractor:
    """
    Base class with common extractor utilities.

    Supports hot-reload of prompts via optional prompt_resolver callable.
    """

    extraction_type: str = "base"

    def __init__(
        self,
        llm: "LLMProtocol",
        prompt_resolver: Optional[Callable[[], Optional[str]]] = None,
    ) -> None:
        """
        Initialize base extractor.

        Args:
            llm: LLM protocol implementation for extraction
            prompt_resolver: Optional callable that returns a custom prompt.
                            If provided and returns non-None, uses that prompt.
                            Enables hot-reload without worker restart.
        """
        self._llm = llm
        self._prompt_resolver = prompt_resolver

    def _get_prompt(self, default: str) -> str:
        """
        Get prompt with hot-reload support.

        Args:
            default: Default prompt to use if no custom prompt resolved

        Returns:
            Custom prompt from resolver if available, otherwise default
        """
        if self._prompt_resolver:
            try:
                custom = self._prompt_resolver()
                if custom:
                    logger.debug("Using custom prompt from resolver")
                    return custom
            except Exception as e:
                logger.warning("Prompt resolver failed, using default: %s", e)
        return default

    def _format_messages(self, messages: List[Dict[str, Any]]) -> str:
        """
        Format messages for prompt with proper JSON escaping.

        Args:
            messages: List of message dicts with 'role' and 'content' keys

        Returns:
            JSON-formatted string of messages
        """
        formatted = [
            {"role": m.get("role", "user"), "content": m.get("content", "")} for m in messages
        ]
        return json.dumps(formatted, indent=2, ensure_ascii=False)

    def _call_llm(self, system_prompt: str, user_prompt: str) -> Dict[str, Any]:
        """
        Call LLM with system and user prompts.

        Args:
            system_prompt: System prompt for context
            user_prompt: User prompt with content to extract from

        Returns:
            Parsed JSON response from LLM
        """
        combined_prompt = f"{system_prompt}\n\n{user_prompt}"
        return self._llm.complete_json(prompt=combined_prompt, schema={})

    def extract(self, messages: List[Dict[str, Any]]) -> List[ExtractedItem]:
        """
        Extract items from messages.

        Override in subclasses to implement specific extraction logic.
        """
        raise NotImplementedError("Subclasses must implement extract()")


__all__ = [
    "ExtractorProtocol",
    "BaseExtractor",
]
