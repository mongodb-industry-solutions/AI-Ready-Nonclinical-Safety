"""
Models for procedural memory documents.

Procedural memory stores reusable procedures (skills) with embeddings
for vector search. Each document represents a named procedure that can
be retrieved based on semantic similarity and executed by agent frameworks.

Designed for SKILL.md compatibility with progressive disclosure:
  - Discovery phase (~100 tokens): procedure name + description
  - Activation phase (<5000 tokens): full content body
  - Execution phase (on demand): structured steps + resources
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Union

from bson import ObjectId
from mongomem_core.common.utils import utcnow
from mongomem_core.models.memory.base import (
    BaseMemoryIn,
    ChunkVisibility,
    HasEmbeddings,
)
from mongomem_core.models.memory.publishing import PublishingMetadata
from mongomem_core.models.types import PyObjectId
from pydantic import BaseModel, Field, field_serializer, model_validator


class ProceduralStep(BaseModel):
    """A single step within a procedure.

    Steps are a structured data contract consumed by agent frameworks
    (LangGraph, CrewAI, custom loops). mongomem does not execute steps --
    it stores them for retrieval.
    """

    step_type: Literal["instruction", "code", "validation", "prompt", "human_input"] = Field(
        ..., description="Type of step determining how a framework should process it"
    )
    content: str = Field(
        ..., description="Step body: prose, code block, prompt template, or gate description"
    )
    description: str = Field(..., description="Human-readable summary of what this step does")
    language: Optional[str] = Field(
        default=None, description="Programming language for code/validation steps"
    )
    dependencies: Optional[List[str]] = Field(
        default=None, description="Required packages or tools for this step"
    )
    expected_output: Optional[str] = Field(
        default=None, description="Expected output description for validation steps"
    )
    timeout_ms: int = Field(
        default=30000, ge=1000, le=600000, description="Timeout hint for execution"
    )


class ProceduralResource(BaseModel):
    """An external file associated with a procedure.

    Maps to SKILL.md directory structure: scripts/, references/, assets/.
    """

    path: str = Field(..., description="Relative path (e.g. 'scripts/extract.py')")
    resource_type: Literal["script", "reference", "asset"] = Field(
        ..., description="Category of resource"
    )
    content: Optional[str] = Field(default=None, description="Inline content for small files")
    language: Optional[str] = Field(default=None, description="Programming language for scripts")
    description: Optional[str] = Field(default=None, description="What this resource provides")


class ProceduralIn(BaseMemoryIn, HasEmbeddings):
    """Input model for creating a procedural memory entry.

    Fields are organized by progressive disclosure phase to match SKILL.md's
    3-phase model while adding mongomem extensions as a strict superset.
    """

    publishing: Optional[PublishingMetadata] = Field(default_factory=PublishingMetadata)

    embedding_model_id: Optional[str] = Field(
        default=None, description="Model identifier used to generate the embedding"
    )

    # --- Discovery phase (~100 tokens) ---
    procedure: str = Field(
        ...,
        min_length=1,
        max_length=64,
        pattern=r"^[a-z0-9]+(-[a-z0-9]+)*$",
        description="Unique kebab-case name per org, SKILL.md `name` compatible",
    )
    description: str = Field(
        ...,
        min_length=1,
        max_length=1024,
        description="What this procedure does and when to use it",
    )

    # --- Activation phase (<5000 tokens) ---
    content: str = Field(
        ..., description="Full instruction body (markdown), the embeddable skill text"
    )
    content_token_count: Optional[int] = Field(
        default=None, ge=0, description="Token count for budget-aware retrieval"
    )

    # --- Execution phase (on demand) ---
    steps: Optional[List[ProceduralStep]] = Field(
        default=None, description="Structured steps for framework consumption"
    )
    resources: Optional[List[ProceduralResource]] = Field(
        default=None, description="Associated files (scripts, references, assets)"
    )

    # --- SKILL.md-compatible metadata ---
    allowed_tools: Optional[List[str]] = Field(
        default=None, description="Pre-approved tools for this procedure"
    )
    compatibility: Optional[str] = Field(
        default=None, max_length=500, description="Environment requirements"
    )
    license: Optional[str] = Field(default=None, description="License for publishing/sharing")

    # --- mongomem extensions (superset of SKILL.md) ---
    trigger_conditions: Optional[List[str]] = Field(
        default=None, description="Explicit activation triggers"
    )
    tags: Optional[List[str]] = Field(default=None, description="Categorization tags for filtering")
    source_format: Optional[str] = Field(
        default=None, description="Original format if migrated ('skill.md', 'yaml')"
    )
    source_path: Optional[str] = Field(
        default=None, description="Original file path for traceability"
    )

    # Agent attribution
    agent_id: Optional[str] = Field(
        default=None,
        description="Agent ID if extracted via agent-mediated learning",
    )
    extraction_source: Optional[str] = Field(
        default=None,
        description="Source of extraction: 'user_direct', 'agent_mediated', 'agent_collective'",
    )
    collective_metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Metadata for collective intelligence",
    )


class ProceduralUpdate(BaseModel):
    """Model for partial updates to procedural memory."""

    visibility: Optional[ChunkVisibility] = None
    project_id: Optional[str] = None
    publishing: Optional[PublishingMetadata] = None

    embedding: Optional[List[float]] = None
    embedding_model_id: Optional[str] = None

    description: Optional[str] = Field(default=None, max_length=1024)
    content: Optional[str] = None
    content_token_count: Optional[int] = Field(default=None, ge=0)

    steps: Optional[List[ProceduralStep]] = None
    resources: Optional[List[ProceduralResource]] = None

    allowed_tools: Optional[List[str]] = None
    compatibility: Optional[str] = Field(default=None, max_length=500)
    license: Optional[str] = None

    trigger_conditions: Optional[List[str]] = None
    tags: Optional[List[str]] = None

    agent_id: Optional[str] = None
    extraction_source: Optional[str] = None
    collective_metadata: Optional[Dict[str, Any]] = None


class ProceduralBase(ProceduralIn):
    """Base model with org/user context, versioning, and extraction metadata.

    Includes org_id, user_id, timestamps, version control, and extraction
    metadata which are typically set by the service layer.
    """

    org_id: str = Field(..., description="Organization/tenant ID")
    user_id: str = Field(..., description="Creator of procedure")
    timestamp: datetime = Field(default_factory=utcnow, description="Creation time")
    updated_at: datetime = Field(default_factory=utcnow, description="Last-modified time")

    version: int = Field(default=1, description="Version number, increments on each update")
    is_latest: bool = Field(default=True, description="Only the latest version has this flag")

    # Memory Lineage Fields
    memory_lineage_id: Optional[str] = Field(
        default=None, description="Shared ID across all versions of this memory"
    )
    previous_version_id: Optional[str] = Field(
        default=None, description="Reference to previous version for audit trail"
    )

    # Memory Reinforcement & Boosting Fields
    reinforcement_count: int = Field(
        default=0,
        ge=0,
        description="Number of times this procedure was attempted to be re-created",
    )
    last_reinforced_at: Optional[datetime] = Field(
        default=None, description="Timestamp of the most recent reinforcement"
    )
    reinforcement_history: List[datetime] = Field(
        default_factory=list, description="Recent reinforcement timestamps (capped at 50)"
    )

    # Extraction metadata for dual storage and cohort routing
    extraction_id: Optional[str] = Field(
        default=None,
        pattern="^[a-f0-9]{64}$",
        description="SHA-256 hash for idempotent extraction writes",
    )
    extraction_scope: Optional[Literal["user_private", "agent_shared", "org_wide"]] = Field(
        default=None,
        description="Scope of extraction: user_private, agent_shared (cohort), or org_wide",
    )
    contributed_by: Optional[str] = Field(
        default=None, description="User ID who contributed this extraction"
    )
    owner_id: Optional[str] = Field(
        default=None, description="User ID with permanent access rights"
    )
    deleted: bool = Field(default=False, description="Soft-delete flag for auditability")
    deleted_at: Optional[datetime] = Field(default=None, description="Timestamp of soft deletion")
    idempotency_key_in: Optional[str] = Field(
        default=None, description="Original idempotency key for debugging"
    )

    @model_validator(mode="before")
    @classmethod
    def set_timestamps(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        now = utcnow()
        values.setdefault("timestamp", now)
        values.setdefault("updated_at", now)
        return values

    model_config = {
        "arbitrary_types_allowed": True,
        "from_attributes": True,
        "populate_by_name": True,
        "use_enum_values": True,
    }


class ProceduralDB(ProceduralBase):
    """Database model with MongoDB _id."""

    id: PyObjectId = Field(default_factory=PyObjectId, alias="_id")

    @field_serializer("id", when_used="json")
    def _serialize_id(self, v: ObjectId) -> str:
        return str(v)


class ProceduralOut(ProceduralBase):
    """Output model for API responses."""

    id: str = Field(..., alias="_id")

    score: Optional[float] = Field(
        default=None,
        description="Vector search similarity score from MongoDB Atlas (query-specific, not stored)",
    )

    @staticmethod
    def of(doc: Union[ProceduralDB, Dict[str, Any], None]) -> Optional["ProceduralOut"]:
        if doc is None:
            return None
        if isinstance(doc, ProceduralDB):
            doc = doc.model_dump(by_alias=True, mode="json")
        doc["_id"] = str(doc["_id"])
        return ProceduralOut.model_validate(doc)


__all__ = [
    "ProceduralStep",
    "ProceduralResource",
    "ProceduralIn",
    "ProceduralUpdate",
    "ProceduralBase",
    "ProceduralDB",
    "ProceduralOut",
]
