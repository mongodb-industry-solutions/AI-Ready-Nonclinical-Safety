"""
Error handling for mongomem_worker.

Provides:
- Typed exceptions with severity for retry decisions
- Error classification for string-based errors
- Utilities for wrapping and enriching errors
"""

from .classifier import (
    ErrorTaxonomy,
    ErrorType,
    classify_error,
    get_error_taxonomy,
    get_retry_delay,
    should_retry,
)
from .exceptions import (
    ConfigurationError,
    DatabaseError,
    DocumentMissingError,
    EmbedderConfigError,
    EmbeddingError,
    HandlerNotFoundError,
    InvalidPayloadError,
    LeaseExpiredError,
    LLMError,
    RateLimitError,
    TimeoutError,
    TransientWorkerError,
    WorkerError,
    WorkerErrorSeverity,
    classify_exception,
    wrap_handler_error,
)

__all__ = [
    # Exception classes
    "WorkerError",
    "WorkerErrorSeverity",
    "ConfigurationError",
    "EmbedderConfigError",
    "HandlerNotFoundError",
    "InvalidPayloadError",
    "DocumentMissingError",
    "TransientWorkerError",
    "EmbeddingError",
    "LLMError",
    "RateLimitError",
    "TimeoutError",
    "DatabaseError",
    "LeaseExpiredError",
    # Exception utilities
    "classify_exception",
    "wrap_handler_error",
    # Error classification
    "ErrorType",
    "ErrorTaxonomy",
    "classify_error",
    "get_error_taxonomy",
    "should_retry",
    "get_retry_delay",
]
