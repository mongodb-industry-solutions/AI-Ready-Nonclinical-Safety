"""
Prompts and schema for procedural memory extraction.

Extracts reusable procedures (skills) from conversation messages.
Each procedure is a named, step-by-step instruction that an agent
can follow in similar future situations.
"""

EXTRACTION_SYSTEM_PROMPT = """You are a procedure extraction specialist. Your job is to identify \
reusable, step-by-step procedures from conversations between a user and an assistant.

A procedure is a repeatable workflow that was demonstrated or discussed in the conversation. \
Focus on extracting procedures that:
- Involve concrete, actionable steps (not just facts or opinions)
- Could be reused in similar future situations
- Were actually performed or clearly described (not hypothetical)

For each procedure, provide:
- A unique kebab-case name (e.g. "deploy-to-production", "debug-memory-leak")
- A concise description of what it does and when to use it
- The full instruction body as markdown
- Optional structured steps with step types

Step types:
- "instruction": Prose guidance for the agent
- "code": A code block to execute (include language)
- "validation": A check to verify the step succeeded
- "prompt": A prompt template to send to the LLM
- "human_input": A point where human approval is needed

Only extract procedures where you have high confidence the steps are correct \
based on what actually happened in the conversation. Do not invent steps that \
were not discussed or demonstrated.

Return a JSON object with a "procedures" array."""

EXTRACTION_PROMPT_TEMPLATE = """Analyze the following conversation and extract any reusable \
procedures (step-by-step workflows) that were demonstrated or discussed.

Conversation History:
{conversation_history}
"""

EXTRACTION_SCHEMA = {
    "type": "object",
    "properties": {
        "procedures": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "procedure": {
                        "type": "string",
                        "pattern": "^[a-z0-9]+(-[a-z0-9]+)*$",
                        "description": "Unique kebab-case name",
                    },
                    "description": {
                        "type": "string",
                        "maxLength": 1024,
                        "description": "What this procedure does and when to use it",
                    },
                    "content": {
                        "type": "string",
                        "description": "Full instruction body as markdown",
                    },
                    "steps": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "step_type": {
                                    "type": "string",
                                    "enum": [
                                        "instruction",
                                        "code",
                                        "validation",
                                        "prompt",
                                        "human_input",
                                    ],
                                },
                                "content": {"type": "string"},
                                "description": {"type": "string"},
                                "language": {"type": ["string", "null"]},
                            },
                            "required": ["step_type", "content", "description"],
                        },
                    },
                    "tags": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "citations": {
                        "type": "array",
                        "items": {"type": "integer"},
                    },
                    "confidence_score": {
                        "type": "number",
                        "minimum": 0,
                        "maximum": 1,
                    },
                },
                "required": ["procedure", "description", "content"],
            },
        }
    },
    "required": ["procedures"],
}

__all__ = [
    "EXTRACTION_SYSTEM_PROMPT",
    "EXTRACTION_PROMPT_TEMPLATE",
    "EXTRACTION_SCHEMA",
]
