"""Procedural memory operations for MemoryEngine.

Internal implementation - use MemoryEngine from mongomem_core.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Dict, List

from mongomem_core.exceptions import ValidationError
from mongomem_core.memory.procedural import (
    bulk_create_procedural,
    create_procedural,
    delete_procedural,
    get_procedural,
    list_procedural,
    search_procedural,
    soft_delete_procedural,
    update_procedural,
)
from mongomem_core.models.engine import CreateProceduralResult, DeleteResult
from mongomem_core.models.filters import MetadataFilter
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.procedural import (
    ProceduralIn,
    ProceduralOut,
    ProceduralResource,
    ProceduralStep,
    ProceduralUpdate,
)
from mongomem_core.models.retrieval import MemoryChunk
from mongomem_core.retrieval import fetch_procedural_memories
from pydantic import ValidationError as PydanticValidationError

if TYPE_CHECKING:
    from mongomem_core.engine._protocol import EngineProtocol

logger = logging.getLogger(__name__)


class _Procedural:
    """Procedural memory CRUD and retrieval operations."""

    def fetch_procedural_memories(
        self: "EngineProtocol",
        query: str | List[float],
        org_id: str,
        *,
        user_id: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        tags: List[str] | None = None,
        top_k: int = 50,
        similarity_threshold: float = 0.0,
        dedup_threshold: float = 0.5,
        prefetched: List[ProceduralOut] | None = None,
        deduplicate: bool = True,
        rank: bool = True,
        metadata_filter: MetadataFilter | None = None,
    ) -> List[MemoryChunk]:
        """Fetch, deduplicate, and rank procedural memories.

        Args:
            query: Query text or pre-computed embedding vector
            org_id: Organization ID for multi-tenancy
            user_id: Optional user ID filter
            visibility: Optional visibility scope filter
            project_id: Optional group ID filter
            tags: Optional tag filter
            top_k: Maximum number of results from vector search
            similarity_threshold: Minimum similarity score
            dedup_threshold: Threshold for similarity-based deduplication
            prefetched: Optional pre-fetched procedural memories
            deduplicate: Whether to deduplicate results
            rank: Whether to rank results
            metadata_filter: Optional metadata filter for Atlas Vector Search

        Returns:
            List of MemoryChunk objects
        """
        vis = ChunkVisibility(visibility) if visibility else None

        return fetch_procedural_memories(
            db=self._db,
            org_id=org_id,
            query=query,
            embedder=self._embedder,
            user_id=user_id,
            visibility=vis,
            project_id=project_id,
            tags=tags,
            top_k=top_k,
            similarity_threshold=similarity_threshold,
            dedup_threshold=dedup_threshold,
            prefetched=prefetched,
            deduplicate=deduplicate,
            rank=rank,
            metadata_filter=metadata_filter,
        )

    def discover_procedures(
        self: "EngineProtocol",
        query: str | List[float],
        org_id: str,
        *,
        user_id: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        tags: List[str] | None = None,
        top_k: int = 10,
        similarity_threshold: float = 0.0,
        metadata_filter: MetadataFilter | None = None,
    ) -> List[Dict[str, Any]]:
        """Discover procedures matching a query without loading full content.

        Returns lightweight dicts (~100 tokens each) with procedure name,
        description, version, tags, reinforcement_count, and similarity
        score. Call get_procedural() to activate selected procedures.

        Args:
            query: Query text or pre-computed embedding vector
            org_id: Organization ID for multi-tenancy
            user_id: Optional user ID filter
            visibility: Optional visibility scope filter
            project_id: Optional group ID filter
            tags: Optional tag filter
            top_k: Maximum number of results
            similarity_threshold: Minimum similarity score
            metadata_filter: Optional metadata filter for Atlas Vector Search

        Returns:
            List of lightweight procedure dicts (no content/steps/resources)
        """
        vis = ChunkVisibility(visibility) if visibility else None

        query_embedding: List[float]
        if isinstance(query, str):
            if self._embedder is None:
                raise ValueError("Embedder required for text queries")
            query_embedding = self._embedder.embed(query)
        else:
            query_embedding = query

        return search_procedural(
            db=self._db,
            query_embedding=query_embedding,
            org_id=org_id,
            user_id=user_id,
            visibility=vis,
            project_id=project_id,
            tags=tags,
            top_k=top_k,
            similarity_threshold=similarity_threshold,
            return_format="discovery",
            metadata_filter=metadata_filter,
        )

    def create_procedural(
        self: "EngineProtocol",
        *,
        procedure: str,
        description: str,
        content: str,
        org_id: str,
        user_id: str,
        steps: List[Dict[str, Any]] | None = None,
        resources: List[Dict[str, Any]] | None = None,
        allowed_tools: List[str] | None = None,
        compatibility: str | None = None,
        license: str | None = None,
        trigger_conditions: List[str] | None = None,
        tags: List[str] | None = None,
        visibility: str = "private",
        project_id: str | None = None,
        agent_id: str | None = None,
        extraction_source: str | None = None,
        source_format: str | None = None,
        source_path: str | None = None,
        embedding: list[float] | None = None,
        skip_embedding: bool = False,
    ) -> CreateProceduralResult:
        """Create a procedural memory (skill/procedure).

        Args:
            procedure: Unique kebab-case name for this procedure
            description: What this procedure does and when to use it
            content: Full instruction body (markdown)
            org_id: Organization ID for multi-tenancy
            user_id: User ID who owns this memory
            steps: Optional structured steps (list of step dicts)
            resources: Optional associated resources (list of resource dicts)
            allowed_tools: Pre-approved tools
            compatibility: Environment requirements
            license: License for sharing
            trigger_conditions: Explicit activation triggers
            tags: Categorization tags
            visibility: Visibility scope
            project_id: Project ID (required when visibility="shared")
            agent_id: Agent ID if created via agent
            extraction_source: Source type
            source_format: Original format if migrated
            source_path: Original file path
            embedding: Pre-computed embedding
            skip_embedding: If True, don't embed even if embedder available

        Returns:
            CreateProceduralResult with the created document's ID
        """
        logger.debug(
            "Creating procedural memory: procedure=%s org=%s user=%s skip_embedding=%s",
            procedure,
            org_id,
            user_id,
            skip_embedding,
        )

        final_embedding = embedding
        embedding_model_id = None
        if not skip_embedding and embedding is None and self._embedder is not None:
            logger.debug("Generating embedding for procedural memory: procedure=%s", procedure)
            final_embedding = self._embedder.embed(content)
            embedding_model_id = self._embedder.model_id

        try:
            step_models = [ProceduralStep(**s) for s in steps] if steps else None
            resource_models = [ProceduralResource(**r) for r in resources] if resources else None

            procedural_in = ProceduralIn(
                procedure=procedure,
                description=description,
                content=content,
                steps=step_models,
                resources=resource_models,
                allowed_tools=allowed_tools,
                compatibility=compatibility,
                license=license,
                trigger_conditions=trigger_conditions,
                tags=tags,
                visibility=ChunkVisibility(visibility) if visibility else ChunkVisibility.PRIVATE,
                project_id=project_id,
                agent_id=agent_id,
                extraction_source=extraction_source,
                source_format=source_format,
                source_path=source_path,
            )
        except PydanticValidationError as exc:
            logger.warning(
                "Validation failed for create_procedural: procedure=%s errors=%s",
                procedure,
                exc.errors(),
            )
            raise ValidationError(
                f"Invalid procedural data: {exc}",
                details={"procedure": procedure, "validation_errors": exc.errors()},
            ) from exc

        procedural_doc = create_procedural(
            db=self._db,
            procedural_in=procedural_in,
            org_id=org_id,
            user_id=user_id,
            embedding=final_embedding,
            embedding_model_id=embedding_model_id,
        )

        logger.info(
            "Procedural memory created: id=%s procedure=%s has_embedding=%s",
            procedural_doc.id,
            procedural_doc.procedure,
            procedural_doc.has_embedding,
        )

        return CreateProceduralResult(
            id=str(procedural_doc.id),
            procedure=procedural_doc.procedure,
            has_embedding=procedural_doc.has_embedding,
            acknowledged=True,
        )

    def get_procedural(
        self: "EngineProtocol",
        org_id: str,
        *,
        id: str | None = None,
        procedure: str | None = None,
        user_id: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        include_deleted: bool = False,
    ) -> ProceduralOut | None:
        """Retrieve a procedural memory by ID or procedure name."""
        return get_procedural(
            db=self._db,
            org_id=org_id,
            id=id,
            procedure=procedure,
            user_id=user_id,
            visibility=visibility,
            project_id=project_id,
            include_deleted=include_deleted,
        )

    def list_procedural(
        self: "EngineProtocol",
        org_id: str,
        *,
        user_id: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        tags: List[str] | None = None,
        limit: int = 100,
        include_deleted: bool = False,
    ) -> List[ProceduralOut]:
        """List procedural memories with optional filters."""
        return list_procedural(
            db=self._db,
            org_id=org_id,
            user_id=user_id,
            visibility=ChunkVisibility(visibility) if visibility else None,
            project_id=project_id,
            tags=tags,
            limit=limit,
            include_deleted=include_deleted,
        )

    def update_procedural(
        self: "EngineProtocol",
        org_id: str,
        *,
        id: str | None = None,
        procedure: str | None = None,
        description: str | None = None,
        content: str | None = None,
        steps: List[Dict[str, Any]] | None = None,
        resources: List[Dict[str, Any]] | None = None,
        allowed_tools: List[str] | None = None,
        compatibility: str | None = None,
        tags: List[str] | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
    ) -> ProceduralOut:
        """Update a procedural memory.

        When content changes and an embedder is available, the embedding
        is regenerated automatically to keep vector search accurate.
        """
        step_models = [ProceduralStep(**s) for s in steps] if steps else None
        resource_models = [ProceduralResource(**r) for r in resources] if resources else None

        embedding = None
        embedding_model_id = None
        if content is not None and self._embedder is not None:
            embedding = self._embedder.embed(content)
            embedding_model_id = self._embedder.model_id

        update = ProceduralUpdate(
            description=description,
            content=content,
            steps=step_models,
            resources=resource_models,
            allowed_tools=allowed_tools,
            compatibility=compatibility,
            tags=tags,
            visibility=ChunkVisibility(visibility) if visibility else None,
            project_id=project_id,
            embedding=embedding,
            embedding_model_id=embedding_model_id,
        )

        return update_procedural(
            db=self._db,
            org_id=org_id,
            update=update,
            id=id,
            procedure=procedure,
        )

    def delete_procedural(
        self: "EngineProtocol",
        org_id: str,
        *,
        id: str | None = None,
        procedure: str | None = None,
        soft: bool = True,
    ) -> DeleteResult:
        """Delete a procedural memory."""
        if soft:
            update_result = soft_delete_procedural(
                db=self._db,
                org_id=org_id,
                id=id,
                procedure=procedure,
            )
            deleted_count = update_result.modified_count
        else:
            delete_result = delete_procedural(
                db=self._db,
                org_id=org_id,
                id=id,
                procedure=procedure,
            )
            deleted_count = delete_result.deleted_count

        logger.info(
            "Deleted procedural memory: org=%s id=%s procedure=%s soft=%s count=%d",
            org_id,
            id,
            procedure,
            soft,
            deleted_count,
        )
        return DeleteResult(deleted_count=deleted_count, acknowledged=True)

    def bulk_create_procedural(
        self: "EngineProtocol",
        items: List[Dict[str, Any]],
        org_id: str,
        user_id: str,
        *,
        visibility: str = "private",
        project_id: str | None = None,
        generate_embeddings: bool = True,
        skip_duplicates: bool = True,
    ) -> Dict[str, Any]:
        """Bulk create multiple procedural memories efficiently.

        Args:
            items: List of dicts with keys: procedure, description, content,
                   and optional steps, resources, tags, etc.
            org_id: Organization ID
            user_id: User ID
            visibility: Visibility scope for all items
            project_id: Project ID
            generate_embeddings: Generate embeddings for all items
            skip_duplicates: Skip duplicates instead of failing

        Returns:
            Dict with created_count, skipped_count, created_ids, skipped_procedures
        """
        if not items:
            return {
                "created_count": 0,
                "skipped_count": 0,
                "created_ids": [],
                "skipped_procedures": [],
                "has_embeddings": False,
                "acknowledged": True,
            }

        logger.debug(
            "Bulk creating %d procedural memories for org=%s user=%s",
            len(items),
            org_id,
            user_id,
        )

        procedural_inputs: List[ProceduralIn] = []
        for item_data in items:
            try:
                step_models = None
                if item_data.get("steps"):
                    step_models = [ProceduralStep(**s) for s in item_data["steps"]]
                resource_models = None
                if item_data.get("resources"):
                    resource_models = [ProceduralResource(**r) for r in item_data["resources"]]

                procedural_in = ProceduralIn(
                    procedure=item_data["procedure"],
                    description=item_data["description"],
                    content=item_data["content"],
                    steps=step_models,
                    resources=resource_models,
                    allowed_tools=item_data.get("allowed_tools"),
                    tags=item_data.get("tags"),
                    visibility=ChunkVisibility(visibility)
                    if visibility
                    else ChunkVisibility.PRIVATE,
                    project_id=project_id if visibility == "shared" else None,
                    source_format=item_data.get("source_format"),
                    source_path=item_data.get("source_path"),
                )
                procedural_inputs.append(procedural_in)
            except (KeyError, PydanticValidationError) as exc:
                logger.warning(
                    "Skipping invalid item in bulk create: procedure=%s error=%s",
                    item_data.get("procedure", "unknown"),
                    exc,
                )
                continue

        if not procedural_inputs:
            return {
                "created_count": 0,
                "skipped_count": 0,
                "created_ids": [],
                "skipped_procedures": [],
                "has_embeddings": False,
                "acknowledged": True,
            }

        embeddings = None
        embedding_model_id = None
        if generate_embeddings and self._embedder is not None:
            texts = [p.content for p in procedural_inputs]
            try:
                logger.debug("Generating embeddings for %d items", len(texts))
                embeddings = self._embedder.embed_batch(texts)
                embedding_model_id = self._embedder.model_id
            except Exception as exc:
                logger.warning("Failed to generate embeddings for bulk create: %s", exc)

        created_docs, skipped_procedures = bulk_create_procedural(
            db=self._db,
            items=procedural_inputs,
            org_id=org_id,
            user_id=user_id,
            embeddings=embeddings,
            embedding_model_id=embedding_model_id,
            skip_duplicates=skip_duplicates,
        )

        has_embeddings = bool(embeddings) and len(created_docs) > 0

        logger.info(
            "Bulk created %d/%d procedural memories for org=%s (skipped=%d)",
            len(created_docs),
            len(procedural_inputs),
            org_id,
            len(skipped_procedures),
        )

        return {
            "created_count": len(created_docs),
            "skipped_count": len(skipped_procedures),
            "created_ids": [str(doc.id) for doc in created_docs],
            "skipped_procedures": skipped_procedures,
            "has_embeddings": has_embeddings,
            "acknowledged": True,
        }
