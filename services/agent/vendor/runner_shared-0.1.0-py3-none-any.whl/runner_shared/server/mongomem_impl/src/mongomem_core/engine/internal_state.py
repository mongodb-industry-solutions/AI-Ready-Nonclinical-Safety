"""
Internal Working Memory engine mixin.

Provides update_internal_state, get_internal_state, and clear_internal_state
methods for MemoryEngine. Always composed, but writes are mode-gated.

Key guarantees:
- Atomic conditional version bump (version only changes when content changes)
- Optimistic concurrency via expected_version / if_match_hash
- Noop detection via was_noop flag
- Multi-agent support: each agent in a session can have its own IS
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Dict, Optional

from mongomem_core.memory.internal_state import (
    delete_internal_state,
    get_internal_state,
    upsert_internal_state,
)
from mongomem_core.models.engine import InternalStateResult
from mongomem_core.models.memory.internal_state import (
    InternalStateIn,
    InternalStateOut,
    VersionConflictError,
)
from mongomem_core.modes import MemoryMode, require_mode

if TYPE_CHECKING:
    from mongomem_core.engine._protocol import EngineProtocol

logger = logging.getLogger(__name__)

# Re-export for convenience
__all__ = ["_InternalState", "VersionConflictError"]


class _InternalState:
    """
    Internal Working Memory operations.

    Always composed into MemoryEngine, but writes are mode-gated:
    - update_internal_state(): IWM, HYBRID only
    - get_internal_state(): ALL modes (observability)
    - clear_internal_state(): IWM, HYBRID only
    """

    def update_internal_state(
        self: "EngineProtocol",
        *,
        session_id: str,
        org_id: str,
        user_id: str,
        content: str,
        token_count: Optional[int] = None,
        token_count_estimated: bool = True,
        tokenizer_id: Optional[str] = None,
        model_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        source_turn_id: Optional[str] = None,
        update_reason: str = "turn_end",
        metadata: Optional[Dict[str, Any]] = None,
        # Optimistic concurrency
        expected_version: Optional[int] = None,
        if_match_hash: Optional[str] = None,
        # Redaction tracking
        redaction_applied: bool = False,
        redaction_policy_id: Optional[str] = None,
    ) -> InternalStateResult:
        """
        Update internal state for a session.

        This atomically upserts the agent's self-authored belief state.
        The content overwrites any previous state, maintaining constant
        prompt size for IWM mode.

        Key guarantees:
        - Version only bumps when content_hash changes (true noop detection)
        - Optimistic concurrency via expected_version / if_match_hash
        - Content is normalized (UTF-8, LF newlines) before hashing

        Args:
            session_id: Session identifier
            org_id: Organization ID
            user_id: User ID
            content: The agent's current belief state (raw text, no XML wrapping)
            token_count: Token count of content. If None, will be estimated.
            token_count_estimated: Whether token_count is an estimate
            tokenizer_id: Model/tokenizer used for token count (e.g., 'gpt-4')
            model_id: ID of the model that generated this state
            agent_id: ID of the agent instance
            source_turn_id: ID of the turn that triggered this update
            update_reason: Why this update occurred ("turn_end", "explicit", etc.)
            metadata: Arbitrary metadata for this state
            expected_version: If provided, fail with 409 if current version differs
            if_match_hash: If provided, fail with 409 if current hash differs
            redaction_applied: Whether content was redacted before storage
            redaction_policy_id: ID of the redaction policy applied

        Returns:
            InternalStateResult with version, token_count, content_hash, was_noop

        Raises:
            ModeError: If engine is not in IWM or HYBRID mode.
            VersionConflictError: If expected_version or if_match_hash doesn't match.
            ValidationError: If content is invalid.
            DatabaseOperationError: If the upsert fails.

        Example:
            >>> engine = MemoryEngine(mode=MemoryMode.IWM)
            >>> result = engine.update_internal_state(
            ...     session_id="sess_123",
            ...     org_id="org_1",
            ...     user_id="user_1",
            ...     content="User prefers dark mode.",
            ... )
            >>> result.version  # 1 on first call
            1
            >>> result.was_noop  # False (new content)
            False
            >>>
            >>> # Same content again - noop
            >>> result2 = engine.update_internal_state(
            ...     session_id="sess_123",
            ...     org_id="org_1",
            ...     user_id="user_1",
            ...     content="User prefers dark mode.",
            ... )
            >>> result2.version  # Still 1 (unchanged!)
            1
            >>> result2.was_noop  # True
            True
        """
        # Mode gate: only IWM and HYBRID modes can write IS
        require_mode(
            self._mode,
            [MemoryMode.IWM, MemoryMode.HYBRID],
            "update_internal_state",
        )

        logger.debug(
            "Updating internal state: session=%s org=%s",
            session_id,
            org_id,
        )

        is_in = InternalStateIn(
            content=content,
            token_count=token_count,
            token_count_estimated=token_count_estimated,
            tokenizer_id=tokenizer_id,
            model_id=model_id,
            agent_id=agent_id,
            source_turn_id=source_turn_id,
            update_reason=update_reason,
            metadata=metadata,
            expected_version=expected_version,
            if_match_hash=if_match_hash,
            redaction_applied=redaction_applied,
            redaction_policy_id=redaction_policy_id,
        )

        with self._obs.track_internal_state_update() as ctx:
            upsert_result = upsert_internal_state(
                db=self._db,
                is_in=is_in,
                org_id=org_id,
                user_id=user_id,
                session_id=session_id,
                agent_id=agent_id,  # Multi-agent support: scopes IS to this agent
            )
            ctx["tokens"] = upsert_result.token_count

        if upsert_result.was_noop:
            logger.debug(
                "Internal state unchanged (noop): session=%s org=%s version=%d",
                session_id,
                org_id,
                upsert_result.version,
            )
        else:
            logger.info(
                "Internal state updated: session=%s org=%s version=%d (was %s)",
                session_id,
                org_id,
                upsert_result.version,
                upsert_result.previous_version,
            )

        return InternalStateResult(
            session_id=upsert_result.session_id,
            version=upsert_result.version,
            previous_version=upsert_result.previous_version,
            token_count=upsert_result.token_count,
            content_hash=upsert_result.content_hash,
            was_noop=upsert_result.was_noop,
            acknowledged=True,
        )

    def get_internal_state(
        self: "EngineProtocol",
        *,
        session_id: str,
        org_id: str,
        agent_id: Optional[str] = None,
    ) -> Optional[InternalStateOut]:
        """
        Get current internal state for a session/agent.

        ALLOWED IN ALL MODES for observability/debugging.

        Args:
            session_id: Session identifier
            org_id: Organization ID
            agent_id: Agent identifier for multi-agent support (defaults to default agent)

        Returns:
            InternalStateOut if found, None otherwise.

        Raises:
            DatabaseOperationError: If the query fails.

        Example:
            >>> engine = MemoryEngine()  # Any mode
            >>> state = engine.get_internal_state(
            ...     session_id="sess_123",
            ...     org_id="org_1",
            ...     agent_id="planner_agent",  # Multi-agent
            ... )
            >>> if state:
            ...     print(f"Version {state.version}: {state.content[:50]}...")
        """
        # No mode gate - reads allowed in all modes for observability
        logger.debug(
            "Getting internal state: session=%s org=%s agent=%s",
            session_id,
            org_id,
            agent_id,
        )

        result = get_internal_state(
            db=self._db,
            session_id=session_id,
            org_id=org_id,
            agent_id=agent_id,
        )

        if result:
            logger.debug(
                "Retrieved internal state: session=%s org=%s agent=%s version=%d",
                session_id,
                org_id,
                agent_id,
                result.version,
            )
        else:
            logger.debug(
                "No internal state found: session=%s org=%s agent=%s",
                session_id,
                org_id,
                agent_id,
            )

        return result

    def clear_internal_state(
        self: "EngineProtocol",
        *,
        session_id: str,
        org_id: str,
        agent_id: Optional[str] = None,
    ) -> bool:
        """
        Clear internal state for a session/agent.

        Deletes the IS document for the given session and agent.

        Args:
            session_id: Session identifier
            org_id: Organization ID
            agent_id: Agent identifier for multi-agent support (defaults to default agent)

        Returns:
            True if a document was deleted, False if no document existed.

        Raises:
            ModeError: If engine is not in IWM or HYBRID mode.
            DatabaseOperationError: If the delete fails.

        Example:
            >>> engine = MemoryEngine(mode=MemoryMode.IWM)
            >>> engine.clear_internal_state(
            ...     session_id="sess_123",
            ...     org_id="org_1",
            ...     agent_id="planner_agent",
            ... )
            True
        """
        # Mode gate: only IWM and HYBRID modes can clear IS
        require_mode(
            self._mode,
            [MemoryMode.IWM, MemoryMode.HYBRID],
            "clear_internal_state",
        )

        logger.debug(
            "Clearing internal state: session=%s org=%s agent=%s",
            session_id,
            org_id,
            agent_id,
        )

        deleted = delete_internal_state(
            db=self._db,
            session_id=session_id,
            org_id=org_id,
            agent_id=agent_id,
        )

        if deleted:
            logger.info(
                "Internal state cleared: session=%s org=%s agent=%s",
                session_id,
                org_id,
                agent_id,
            )
        else:
            logger.debug(
                "No internal state to clear: session=%s org=%s agent=%s",
                session_id,
                org_id,
                agent_id,
            )

        return deleted


__all__ = ["_InternalState"]
