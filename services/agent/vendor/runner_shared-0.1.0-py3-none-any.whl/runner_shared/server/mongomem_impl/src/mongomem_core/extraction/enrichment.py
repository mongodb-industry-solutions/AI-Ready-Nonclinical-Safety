"""
Citation enrichment for extracted memories.

Adds cited text from conversation messages to extracted items,
matching ExoMemory's _add_cited_text_to_memories() behavior.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List

from mongomem_core.extraction.types import ExtractedItem

logger = logging.getLogger(__name__)


def enrich_citations(
    extractions: List[ExtractedItem],
    messages: List[Dict[str, Any]],
) -> None:
    """
    Add cited text from conversation to extracted memories (in-place).

    Port of ExoMemory's _add_cited_text_to_memories().
    Handles out-of-bounds citation indices gracefully.

    Args:
        extractions: List of extracted items to enrich
        messages: Original conversation messages

    Note:
        Modifies extractions in-place by setting cited_text field.
    """
    max_idx = len(messages)

    for extraction in extractions:
        if not extraction.citations:
            continue

        extraction.cited_text = []
        for cite_idx in extraction.citations:
            # Handle out-of-bounds indices (LLM hallucination)
            if cite_idx < 0 or cite_idx >= max_idx:
                logger.warning(
                    "Citation index %d out of bounds (max: %d), skipping",
                    cite_idx,
                    max_idx - 1,
                )
                continue

            extraction.cited_text.append(
                {
                    "cited_idx": cite_idx,
                    "cited_text": messages[cite_idx],
                }
            )


def enrich_single(
    extraction: ExtractedItem,
    messages: List[Dict[str, Any]],
) -> ExtractedItem:
    """
    Enrich a single extraction with citation text.

    Non-mutating version that returns a new ExtractedItem.

    Args:
        extraction: Extracted item to enrich
        messages: Original conversation messages

    Returns:
        New ExtractedItem with cited_text populated
    """
    enrich_citations([extraction], messages)
    return extraction


__all__ = [
    "enrich_citations",
    "enrich_single",
]
