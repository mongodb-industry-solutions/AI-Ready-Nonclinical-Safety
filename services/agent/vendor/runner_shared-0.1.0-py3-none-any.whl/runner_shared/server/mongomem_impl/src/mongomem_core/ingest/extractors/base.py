"""
Base protocol for document extractors.

All extractors must implement this protocol to be used in the ingestion pipeline.
"""

from pathlib import Path
from typing import Any, Dict, Protocol, Set, runtime_checkable


@runtime_checkable
class DocumentExtractor(Protocol):
    """Protocol for document text extractors."""

    @property
    def supported_extensions(self) -> Set[str]:
        """
        File extensions this extractor handles.

        Returns:
            Set of extensions like {'.pdf', '.pptx'}
        """
        ...

    def extract(self, file_path: Path) -> str:
        """
        Extract text content from a file.

        Args:
            file_path: Path to the file

        Returns:
            Extracted text as a string
        """
        ...

    def extract_with_metadata(self, file_path: Path) -> Dict[str, Any]:
        """
        Extract text and metadata from a file.

        Args:
            file_path: Path to the file

        Returns:
            Dict with 'text' (str) and 'metadata' (dict) keys
        """
        ...
