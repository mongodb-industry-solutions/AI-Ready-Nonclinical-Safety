"""
Snapshot configuration model for short-term -> snapshot promotion policies.

This is a logical configuration object used by higher-level promotion and
context-builder logic. It is intentionally kept framework-agnostic and
independent of how settings are sourced (env vars, org/user settings
collections, agent profiles, etc.).

Design Principles:
- `write_turn` stays fast - no inline promotion, worker handles auto-promotion
- Sync or async embedding - transfer from STM, generate fresh (sync), or defer to worker
- Platform-ready - manual control for OE, auto-promotion for standalone users
"""

from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field, model_validator


class SnapshotConfig(BaseModel):
    """
    Controls when and how short-term memory is promoted to snapshots.

    Usage Examples:
        # Standalone: auto-promotion via worker (defaults work)
        config = SnapshotConfig()
        engine = MemoryEngine.from_env(snapshot_config=config)
        engine.write_turn(...)  # Fast, worker promotes later

        # Platform/OE: manual control
        config = SnapshotConfig(strategy="manual")
        engine.write_turn(...)  # Just stores STM
        engine.promote_stm_to_snapshot(session_id, org_id, user_id)  # OE decides when

        # Fresh embedding instead of transfer
        config = SnapshotConfig(embedding_strategy="generate")

        # Defer embedding to worker
        config = SnapshotConfig(embedding_strategy="defer")
    """

    # === Trigger Strategy ===
    strategy: Literal["disabled", "manual", "auto"] = Field(
        default="auto",
        description=(
            "Promotion mode: "
            "'disabled' = never promote (STM-only mode, useful for streaming or OE with external storage), "
            "'manual' = explicit calls to promote_stm_to_snapshot() required (for OE control), "
            "'auto' = worker checks thresholds and promotes automatically."
        ),
    )

    # === Thresholds (checked by worker, NOT write_turn) ===
    max_messages: Optional[int] = Field(
        default=20,
        ge=1,
        description="Promote when the STM buffer reaches this many messages.",
    )
    max_tokens: Optional[int] = Field(
        default=None,
        ge=1,
        description="Promote when the STM buffer reaches this many tokens (optional).",
    )
    stale_minutes: int = Field(
        default=3,
        ge=1,
        description="Time-based promotion: promote if last STM is older than this (worker polling).",
    )

    # === Embedding Strategy ===
    embedding_strategy: Literal["transfer", "generate", "defer"] = Field(
        default="transfer",
        description=(
            "How to create snapshot embeddings: "
            "'transfer' = average STM embeddings (fast, no LLM call), "
            "'generate' = call embedder.embed() synchronously during promotion, "
            "'defer' = create snapshot without embedding (worker generates async)."
        ),
    )

    # === Topic Detection (requires embedder, checked by worker) ===
    topic_shift_enabled: bool = Field(
        default=False,
        description="Enable topic shift detection (requires embedder to be provided).",
    )
    topic_shift_threshold: float = Field(
        default=0.35,
        ge=0.0,
        le=1.0,
        description=(
            "Cosine similarity threshold for topic shift detection (0.0-1.0). "
            "When similarity drops below this, a topic shift is detected. "
            "Lower values = less sensitive to topic changes."
        ),
    )

    # === Behavior ===
    delete_promoted: bool = Field(
        default=False,
        description=(
            "If False (default), mark promoted STM docs with promoted=True and keep them in the "
            "collection. Subsequent promotions use exclude_promoted=True to skip already-promoted "
            "docs. If True, delete STM docs from the collection after promotion."
        ),
    )
    preserve_pairs: bool = Field(
        default=True,
        description=(
            "Preserve user-assistant message pairs when promoting. "
            "If the last message is from user, include the following assistant message."
        ),
    )
    ttl_days: int = Field(
        default=30,
        ge=1,
        description="Time-to-live in days for snapshots (used for expires_at calculation).",
    )

    def should_snapshot_by_count(self, n: int) -> bool:
        """Return True when the message count trigger should fire."""
        return self.max_messages is not None and n >= self.max_messages

    def should_snapshot_by_tokens(self, t: int) -> bool:
        """Return True when the token count trigger should fire."""
        return self.max_tokens is not None and t >= self.max_tokens

    def should_snapshot_by_topic(self, similarity_score: float) -> bool:
        """
        Return True when a topic shift trigger should fire.

        The trigger fires when topic_shift_enabled is True and the similarity
        score drops below the configured topic_shift_threshold.
        """
        return self.topic_shift_enabled and similarity_score < self.topic_shift_threshold

    def is_auto_promotion_enabled(self) -> bool:
        """Return True if automatic promotion is enabled."""
        return self.strategy == "auto"

    def is_promotion_disabled(self) -> bool:
        """Return True if promotion is completely disabled (STM-only mode)."""
        return self.strategy == "disabled"

    @model_validator(mode="after")
    def _check_constraints(self) -> "SnapshotConfig":
        """Enforce basic internal consistency."""
        # For auto mode, require at least one threshold
        if self.strategy == "auto":
            if self.max_messages is None and self.max_tokens is None:
                raise ValueError(
                    "'auto' strategy requires at least one of `max_messages` or `max_tokens`"
                )
        return self


__all__ = ["SnapshotConfig"]
