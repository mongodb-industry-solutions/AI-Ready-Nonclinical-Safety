"""
Circuit breaker pattern for external service calls.

Protects embedding and LLM services from cascading failures by:
- Tracking consecutive failures
- Opening the circuit when threshold is reached
- Allowing periodic test calls (half-open state)
- Closing the circuit after successful recovery
"""

from __future__ import annotations

import logging
import threading
import time
from enum import Enum
from typing import Any, Callable, Dict, Optional, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")

# Lock for thread-safe registry access
_registry_lock = threading.Lock()


class CircuitState(str, Enum):
    """Circuit breaker states."""

    CLOSED = "closed"  # Normal operation
    OPEN = "open"  # Rejecting calls
    HALF_OPEN = "half_open"  # Testing recovery


class CircuitBreakerOpen(Exception):
    """Raised when circuit is open and call is rejected."""

    def __init__(self, name: str, retry_in_seconds: int):
        self.name = name
        self.retry_in_seconds = retry_in_seconds
        super().__init__(f"Circuit breaker '{name}' is OPEN (retry in {retry_in_seconds}s)")


class CircuitBreaker:
    """
    Circuit breaker for protecting external service calls.

    Usage:
        breaker = get_circuit_breaker("embedding_service")

        try:
            result = await breaker.call_async(embedder.embed, text)
        except CircuitBreakerOpen:
            # Service temporarily unavailable, use fallback or fail fast
            raise

    States:
        CLOSED: Normal operation, calls pass through
        OPEN: Calls rejected immediately (service is down)
        HALF_OPEN: Testing if service recovered (limited calls allowed)
    """

    def __init__(
        self,
        name: str,
        failure_threshold: int = 5,
        timeout_seconds: float = 60.0,
        success_threshold: int = 2,
        on_state_change: Optional[Callable[[str, CircuitState], None]] = None,
    ):
        self.name = name
        self.failure_threshold = failure_threshold
        self.timeout_seconds = timeout_seconds
        self.success_threshold = success_threshold
        self._on_state_change = on_state_change

        self._lock = threading.Lock()
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._last_failure_time: Optional[float] = None

    @property
    def state(self) -> CircuitState:
        """Current circuit state."""
        return self._state

    @property
    def is_closed(self) -> bool:
        """True if circuit is allowing calls."""
        return self._state == CircuitState.CLOSED

    @property
    def is_open(self) -> bool:
        """True if circuit is rejecting calls."""
        return self._state == CircuitState.OPEN

    def call_sync(self, func: Callable[..., T], *args: Any, **kwargs: Any) -> T:
        """
        Execute a synchronous function through the circuit breaker.

        Raises:
            CircuitBreakerOpen: If circuit is open
            Exception: Any exception from the wrapped function
        """
        self._check_state()

        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result
        except Exception:
            self._on_failure()
            raise

    async def call_async(self, func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        """
        Execute an async function through the circuit breaker.

        Raises:
            CircuitBreakerOpen: If circuit is open
            Exception: Any exception from the wrapped function
        """
        self._check_state()

        try:
            result = await func(*args, **kwargs)
            self._on_success()
            return result
        except Exception:
            self._on_failure()
            raise

    def _check_state(self) -> None:
        """Check if call should be allowed, potentially transitioning state."""
        with self._lock:
            if self._state == CircuitState.OPEN:
                if self._last_failure_time is None:
                    self._transition_to_unlocked(CircuitState.CLOSED)
                    return

                elapsed = time.time() - self._last_failure_time
                if elapsed > self.timeout_seconds:
                    self._transition_to_unlocked(CircuitState.HALF_OPEN)
                    self._success_count = 0
                else:
                    retry_in = int(self.timeout_seconds - elapsed)
                    raise CircuitBreakerOpen(self.name, retry_in)

    def _on_success(self) -> None:
        """Handle successful call (thread-safe)."""
        with self._lock:
            if self._state == CircuitState.HALF_OPEN:
                self._success_count += 1
                if self._success_count >= self.success_threshold:
                    self._transition_to_unlocked(CircuitState.CLOSED)
                    self._failure_count = 0
                    self._success_count = 0
            elif self._state == CircuitState.CLOSED:
                self._failure_count = 0

    def _on_failure(self) -> None:
        """Handle failed call (thread-safe)."""
        with self._lock:
            self._last_failure_time = time.time()

            if self._state == CircuitState.HALF_OPEN:
                self._transition_to_unlocked(CircuitState.OPEN)
                self._failure_count = 0
                self._success_count = 0
            elif self._state == CircuitState.CLOSED:
                self._failure_count += 1
                if self._failure_count >= self.failure_threshold:
                    self._transition_to_unlocked(CircuitState.OPEN)
                    self._success_count = 0

    def _transition_to_unlocked(self, new_state: CircuitState) -> None:
        """Transition to a new state (caller must hold lock)."""
        old_state = self._state
        if old_state == new_state:
            return

        self._state = new_state
        logger.warning(
            "Circuit breaker '%s': %s -> %s",
            self.name,
            old_state.value,
            new_state.value,
        )

        if self._on_state_change:
            try:
                self._on_state_change(self.name, new_state)
            except Exception as exc:
                logger.error("Circuit breaker state change callback failed: %s", exc)

    def reset(self) -> None:
        """Manually reset the circuit breaker to closed state (thread-safe)."""
        with self._lock:
            self._state = CircuitState.CLOSED
            self._failure_count = 0
            self._success_count = 0
            self._last_failure_time = None
        logger.info("Circuit breaker '%s' manually reset", self.name)


# Global registry of circuit breakers
_circuit_breakers: Dict[str, CircuitBreaker] = {}


def get_circuit_breaker(
    name: str,
    failure_threshold: int = 5,
    timeout_seconds: float = 60.0,
    success_threshold: int = 2,
    on_state_change: Optional[Callable[[str, CircuitState], None]] = None,
) -> CircuitBreaker:
    """
    Get or create a circuit breaker by name (thread-safe).

    Circuit breakers are cached by name, so multiple calls with the same
    name return the same instance.
    """
    with _registry_lock:
        if name not in _circuit_breakers:
            _circuit_breakers[name] = CircuitBreaker(
                name=name,
                failure_threshold=failure_threshold,
                timeout_seconds=timeout_seconds,
                success_threshold=success_threshold,
                on_state_change=on_state_change,
            )
        return _circuit_breakers[name]


def reset_circuit_breaker(name: str) -> bool:
    """Reset a circuit breaker by name (thread-safe)."""
    with _registry_lock:
        if name in _circuit_breakers:
            _circuit_breakers[name].reset()
            return True
        return False


def get_all_circuit_breakers() -> Dict[str, CircuitBreaker]:
    """Get all registered circuit breakers (thread-safe snapshot)."""
    with _registry_lock:
        return _circuit_breakers.copy()


def clear_all_circuit_breakers() -> None:
    """Clear all circuit breakers (thread-safe). Useful for testing."""
    with _registry_lock:
        _circuit_breakers.clear()


__all__ = [
    "CircuitBreaker",
    "CircuitBreakerOpen",
    "CircuitState",
    "get_circuit_breaker",
    "reset_circuit_breaker",
    "get_all_circuit_breakers",
    "clear_all_circuit_breakers",
]
