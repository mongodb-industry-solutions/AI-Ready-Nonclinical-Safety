"""
Memory context models for IWM mode.

Pure data containers for context output. Prompt rendering is separate
(in retrieval/formatter.py).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, List, Literal, Optional

if TYPE_CHECKING:
    from mongomem_core.models.memory.episodic import EpisodicOut
    from mongomem_core.models.memory.semantic import SemanticOut
    from mongomem_core.models.memory.short_term import ShortTermOut


@dataclass
class ContextInvariants:
    """
    Mode-specific guarantees for downstream consumers.

    These invariants can be asserted against the MemoryContext to ensure
    it was built correctly for the given mode.
    """

    stm_empty: bool = False
    """True in IWM mode - STM is not included"""

    is_present: bool = False
    """True in IWM/HYBRID when IS exists for this session"""

    is_primary: bool = False
    """True in IWM mode - IS is the primary context source"""

    budget_enforced: bool = True
    """True when budget constraints were applied"""

    def assert_all(self, context: "MemoryContext") -> None:
        """
        Assert all invariants hold for the given context.

        Raises AssertionError with details if any invariant is violated.
        """
        if self.stm_empty:
            assert len(context.stm_turns) == 0, (
                f"Invariant violated: stm_empty=True but got {len(context.stm_turns)} turns"
            )

        if self.is_present:
            assert context.internal_state is not None, (
                "Invariant violated: is_present=True but internal_state is None"
            )

        if self.is_primary:
            assert context.internal_state is not None, (
                "Invariant violated: is_primary=True but internal_state is None"
            )
            assert len(context.stm_turns) == 0, (
                "Invariant violated: is_primary=True but STM turns present"
            )


@dataclass
class MemoryContext:
    """
    Pure data container for memory context.

    This is the output of build_context() in any mode. It contains:
    - Session/org/user identifiers
    - Mode source indicator
    - Invariants for the mode
    - Internal State content (IWM/HYBRID)
    - STM turns (TRADITIONAL/HYBRID)
    - LTM memories (all modes)
    - Token accounting

    Rendering to prompt text is handled separately by retrieval/formatter.py.
    """

    # Identifiers
    session_id: str
    org_id: str
    user_id: str

    # Mode/source
    source: Literal["traditional", "iwm", "hybrid"]
    """Which mode built this context"""

    invariants: ContextInvariants
    """Mode-specific guarantees"""

    # Internal State (IWM/HYBRID)
    internal_state: Optional[str] = None
    """Raw IS content (no XML wrapping)"""

    internal_state_tokens: int = 0
    """Token count of internal_state"""

    internal_state_version: int = 0
    """Version number of the IS document"""

    is_truncated: bool = False
    """True if IS was truncated to fit budget"""

    # STM (TRADITIONAL/HYBRID)
    stm_turns: List["ShortTermOut"] = field(default_factory=list)
    """Conversation turns from short-term memory"""

    stm_tokens: int = 0
    """Total token count of STM turns"""

    # LTM - Semantic (all modes)
    semantic_memories: List["SemanticOut"] = field(default_factory=list)
    """Semantic memories retrieved for this context"""

    # LTM - Episodic (all modes)
    episodic_memories: List["EpisodicOut"] = field(default_factory=list)
    """Episodic memories retrieved for this context"""

    ltm_tokens: int = 0
    """Total token count of LTM (semantic + episodic)"""

    # Budget tracking
    total_tokens: int = 0
    """Total tokens across all sections"""

    budget_remaining: int = 0
    """Tokens remaining in budget after packing"""

    def assert_invariants(self) -> None:
        """
        Assert mode-specific invariants hold.

        Call this in tests or debug code to verify context was built correctly.

        Raises:
            AssertionError: If any invariant is violated.
        """
        self.invariants.assert_all(self)

    @classmethod
    def for_iwm(
        cls,
        *,
        session_id: str,
        org_id: str,
        user_id: str,
        internal_state: Optional[str] = None,
        internal_state_tokens: int = 0,
        internal_state_version: int = 0,
        is_truncated: bool = False,
        semantic_memories: Optional[List["SemanticOut"]] = None,
        episodic_memories: Optional[List["EpisodicOut"]] = None,
        ltm_tokens: int = 0,
        total_tokens: int = 0,
        budget_remaining: int = 0,
    ) -> "MemoryContext":
        """
        Factory for IWM mode context.

        Sets correct invariants for IWM:
        - stm_empty=True
        - is_present=True if internal_state provided
        - is_primary=True
        """
        return cls(
            session_id=session_id,
            org_id=org_id,
            user_id=user_id,
            source="iwm",
            invariants=ContextInvariants(
                stm_empty=True,
                is_present=internal_state is not None,
                is_primary=True,
                budget_enforced=True,
            ),
            internal_state=internal_state,
            internal_state_tokens=internal_state_tokens,
            internal_state_version=internal_state_version,
            is_truncated=is_truncated,
            stm_turns=[],
            stm_tokens=0,
            semantic_memories=semantic_memories or [],
            episodic_memories=episodic_memories or [],
            ltm_tokens=ltm_tokens,
            total_tokens=total_tokens,
            budget_remaining=budget_remaining,
        )

    @classmethod
    def for_traditional(
        cls,
        *,
        session_id: str,
        org_id: str,
        user_id: str,
        stm_turns: Optional[List["ShortTermOut"]] = None,
        stm_tokens: int = 0,
        semantic_memories: Optional[List["SemanticOut"]] = None,
        episodic_memories: Optional[List["EpisodicOut"]] = None,
        ltm_tokens: int = 0,
        total_tokens: int = 0,
        budget_remaining: int = 0,
    ) -> "MemoryContext":
        """
        Factory for TRADITIONAL mode context.

        Sets correct invariants for TRADITIONAL:
        - stm_empty=False (unless no turns exist)
        - is_present=False
        - is_primary=False
        """
        turns = stm_turns or []
        return cls(
            session_id=session_id,
            org_id=org_id,
            user_id=user_id,
            source="traditional",
            invariants=ContextInvariants(
                stm_empty=len(turns) == 0,
                is_present=False,
                is_primary=False,
                budget_enforced=True,
            ),
            internal_state=None,
            internal_state_tokens=0,
            internal_state_version=0,
            is_truncated=False,
            stm_turns=turns,
            stm_tokens=stm_tokens,
            semantic_memories=semantic_memories or [],
            episodic_memories=episodic_memories or [],
            ltm_tokens=ltm_tokens,
            total_tokens=total_tokens,
            budget_remaining=budget_remaining,
        )

    @classmethod
    def for_hybrid(
        cls,
        *,
        session_id: str,
        org_id: str,
        user_id: str,
        internal_state: Optional[str] = None,
        internal_state_tokens: int = 0,
        internal_state_version: int = 0,
        is_truncated: bool = False,
        stm_turns: Optional[List["ShortTermOut"]] = None,
        stm_tokens: int = 0,
        semantic_memories: Optional[List["SemanticOut"]] = None,
        episodic_memories: Optional[List["EpisodicOut"]] = None,
        ltm_tokens: int = 0,
        total_tokens: int = 0,
        budget_remaining: int = 0,
    ) -> "MemoryContext":
        """
        Factory for HYBRID mode context.

        Sets correct invariants for HYBRID:
        - stm_empty=False (unless no turns exist)
        - is_present=True if internal_state provided
        - is_primary=False (both IS and STM present)
        """
        turns = stm_turns or []
        return cls(
            session_id=session_id,
            org_id=org_id,
            user_id=user_id,
            source="hybrid",
            invariants=ContextInvariants(
                stm_empty=len(turns) == 0,
                is_present=internal_state is not None,
                is_primary=False,
                budget_enforced=True,
            ),
            internal_state=internal_state,
            internal_state_tokens=internal_state_tokens,
            internal_state_version=internal_state_version,
            is_truncated=is_truncated,
            stm_turns=turns,
            stm_tokens=stm_tokens,
            semantic_memories=semantic_memories or [],
            episodic_memories=episodic_memories or [],
            ltm_tokens=ltm_tokens,
            total_tokens=total_tokens,
            budget_remaining=budget_remaining,
        )


__all__ = [
    "ContextInvariants",
    "MemoryContext",
]
