"""
Internal Working Memory (IWM) models.

These models represent the agent's self-authored belief state that is
overwritten each turn to maintain constant prompt size.

Key design decisions:
- content_hash uses full SHA256 (64 hex chars) with UTF-8 encoding, newlines normalized to \\n
- version only bumps when content_hash changes (atomic conditional update)
- optimistic concurrency via expected_version / if_match_hash (enforced in MongoDB filter)
- tokenizer_id tracks what model the token count is for
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional

from mongomem_core.models.types import PyObjectId
from pydantic import BaseModel, Field


class UpdateReason(str, Enum):
    """
    Reason for updating internal state.

    Used for observability and debugging.
    """

    TURN_END = "turn_end"
    EXPLICIT = "explicit"
    MIGRATION = "migration"
    ROLLBACK = "rollback"
    IS_GENERATION = "is_generation"


class InternalStateIn(BaseModel):
    """
    Input model for updating internal state.

    This is what callers provide when writing/updating IS.
    The engine adds session_id, org_id, user_id, and computed fields.
    """

    content: str = Field(
        ...,
        description="The agent's current belief state content (raw text, no XML wrapping)",
        min_length=1,
    )
    token_count: Optional[int] = Field(
        default=None,
        ge=0,
        description="Token count of content. If None, will be estimated.",
    )
    token_count_estimated: bool = Field(
        default=True,
        description="Whether token_count is an estimate vs accurate tokenizer count",
    )
    tokenizer_id: Optional[str] = Field(
        default=None,
        description="Model/tokenizer used for token count (e.g., 'gpt-4', 'cl100k_base')",
    )
    model_id: Optional[str] = Field(
        default=None,
        description="ID of the model that generated this state",
    )
    agent_id: Optional[str] = Field(
        default=None,
        description="ID of the agent instance (for multi-agent systems)",
    )
    source_turn_id: Optional[str] = Field(
        default=None,
        description="ID of the turn that triggered this update",
    )
    update_reason: str = Field(
        default=UpdateReason.TURN_END.value,
        description="Why this update occurred",
    )
    metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Arbitrary metadata for this state",
    )
    # Optimistic concurrency control
    expected_version: Optional[int] = Field(
        default=None,
        ge=1,
        description="If provided, update only if current version matches (409 on mismatch)",
    )
    if_match_hash: Optional[str] = Field(
        default=None,
        description="If provided, update only if current content_hash matches (ETag-like)",
    )
    # Redaction tracking
    redaction_applied: bool = Field(
        default=False,
        description="Whether redaction was applied to content before storage",
    )
    redaction_policy_id: Optional[str] = Field(
        default=None,
        description="ID of the redaction policy that was applied",
    )
    # Normalization mode for hashing
    normalize_mode: str = Field(
        default="newlines_only",
        description="How to normalize content for hashing: 'newlines_only' (safe for code) or 'strip_trailing' (for prose)",
    )

    model_config = {"extra": "forbid"}


class InternalStateDB(BaseModel):
    """
    Database model for internal state documents.

    One document per (org_id, session_id) - overwritten on each update.

    Version semantics:
    - version only increments when content_hash changes
    - version=1 on first insert, increments only on content change
    - was_noop=True in result when content unchanged (version stays same)
    """

    id: PyObjectId = Field(alias="_id")
    session_id: str
    org_id: str
    user_id: str
    content: str
    content_hash: str = Field(
        ...,
        description="Full SHA256 (64 hex chars) of content (UTF-8, newlines normalized to LF)",
    )
    token_count: int = Field(
        ...,
        ge=0,
        description="Token count of content",
    )
    token_count_estimated: bool = Field(
        default=True,
        description="Whether token_count is an estimate",
    )
    tokenizer_id: Optional[str] = Field(
        default=None,
        description="Model/tokenizer used for token count",
    )
    version: int = Field(
        ...,
        ge=1,
        description="Content version (only increments when content_hash changes)",
    )
    model_id: Optional[str] = None
    agent_id: Optional[str] = None
    source_turn_id: Optional[str] = None
    update_reason: str = UpdateReason.TURN_END.value
    created_at: datetime
    updated_at: datetime
    last_promoted_at: Optional[datetime] = Field(
        default=None,
        description="When content was last promoted to LTM",
    )
    promotion_count: int = Field(
        default=0,
        ge=0,
        description="Number of times this IS has been promoted to LTM",
    )
    # Redaction tracking
    redaction_applied: bool = Field(
        default=False,
        description="Whether redaction was applied",
    )
    redaction_policy_id: Optional[str] = Field(
        default=None,
        description="ID of the redaction policy applied",
    )
    # Coalescing fields (for rate-limit policy)
    last_generated_at: Optional[datetime] = Field(
        default=None,
        description="When IS was last generated (for coalesce rate limiting)",
    )
    metadata: Dict[str, Any] = Field(default_factory=dict)

    model_config = {
        "populate_by_name": True,
        "arbitrary_types_allowed": True,
    }


class InternalStateOut(BaseModel):
    """
    Output model for internal state (API response).

    Same as DB model but with id serialized as string.
    """

    id: str
    session_id: str
    org_id: str
    user_id: str
    content: str
    content_hash: str
    token_count: int
    token_count_estimated: bool
    tokenizer_id: Optional[str] = None
    version: int
    model_id: Optional[str] = None
    agent_id: Optional[str] = None
    source_turn_id: Optional[str] = None
    update_reason: str
    created_at: datetime
    updated_at: datetime
    last_promoted_at: Optional[datetime] = None
    promotion_count: int = 0
    redaction_applied: bool = False
    redaction_policy_id: Optional[str] = None
    last_generated_at: Optional[datetime] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_db(cls, db_doc: InternalStateDB) -> "InternalStateOut":
        """Convert DB document to output model."""
        return cls(
            id=str(db_doc.id),
            session_id=db_doc.session_id,
            org_id=db_doc.org_id,
            user_id=db_doc.user_id,
            content=db_doc.content,
            content_hash=db_doc.content_hash,
            token_count=db_doc.token_count,
            token_count_estimated=db_doc.token_count_estimated,
            tokenizer_id=db_doc.tokenizer_id,
            version=db_doc.version,
            model_id=db_doc.model_id,
            agent_id=db_doc.agent_id,
            source_turn_id=db_doc.source_turn_id,
            update_reason=db_doc.update_reason,
            created_at=db_doc.created_at,
            updated_at=db_doc.updated_at,
            last_promoted_at=db_doc.last_promoted_at,
            promotion_count=db_doc.promotion_count,
            redaction_applied=db_doc.redaction_applied,
            redaction_policy_id=db_doc.redaction_policy_id,
            last_generated_at=db_doc.last_generated_at,
            metadata=db_doc.metadata,
        )


class VersionConflictError(Exception):
    """
    Raised when optimistic concurrency check fails.

    Contains details about the conflict for debugging.
    """

    def __init__(
        self,
        message: str,
        expected_version: Optional[int] = None,
        actual_version: Optional[int] = None,
        expected_hash: Optional[str] = None,
        actual_hash: Optional[str] = None,
    ):
        super().__init__(message)
        self.expected_version = expected_version
        self.actual_version = actual_version
        self.expected_hash = expected_hash
        self.actual_hash = actual_hash


class UpsertResult(BaseModel):
    """
    Result of an internal state upsert operation.

    Provides full details about what happened:
    - was_noop: True if content unchanged (version NOT bumped)
    - previous_version: Version before this update (None on insert)
    - version: Current version after update
    """

    session_id: str
    org_id: str
    version: int = Field(..., description="Current version after update")
    previous_version: Optional[int] = Field(
        default=None,
        description="Version before this update (None on first insert)",
    )
    content_hash: str
    token_count: int
    was_noop: bool = Field(
        default=False,
        description="True if content unchanged (version stays same)",
    )
    was_insert: bool = Field(
        default=False,
        description="True if this was first insert (not update)",
    )
    acknowledged: bool = True


__all__ = [
    "UpdateReason",
    "InternalStateIn",
    "InternalStateDB",
    "InternalStateOut",
    "UpsertResult",
    "VersionConflictError",
]
