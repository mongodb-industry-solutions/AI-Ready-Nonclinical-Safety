"""
Document ingestion pipeline for mongomem_core.

This package provides utilities to extract text from documents (PDF, PPTX, DOCX, TXT),
chunk the text, and store as semantic memories.

Supports multiple storage backends:
- Local filesystem (default)
- Google Cloud Storage (gs:// URIs)

Example:
    from mongomem_core import MemoryEngine
    from mongomem_core.ingest import IngestConfig, ChunkConfig

    engine = MemoryEngine(embedder=my_embedder)

    # Simple usage
    result = engine.ingest_documents(
        paths=["docs/report.pdf", "slides/deck.pptx"],
        org_id="my-org",
        user_id="sakshi",
    )

    # With custom config
    config = IngestConfig(
        chunk_config=ChunkConfig(max_chunk_size=500, min_chunk_size=100),
        on_failure="skip",
    )
    result = engine.ingest_documents(paths=files, config=config, ...)

    # From GCS
    from mongomem_core.ingest.storage import GCSStorage

    result = engine.ingest_documents(
        paths=["gs://my-bucket/docs/"],
        org_id="my-org",
        user_id="sakshi",
        storage_backend=GCSStorage(),
    )
"""

from mongomem_core.ingest.models import (
    SUPPORTED_EXTENSIONS,
    ChunkConfig,
    ChunkerType,
    ExtractorType,
    FileResult,
    IngestConfig,
    IngestResult,
    validate_file_extension,
)
from mongomem_core.ingest.pipeline import ingest_documents
from mongomem_core.ingest.storage import (
    LocalStorage,
    StorageBackend,
    get_default_backends,
)

# GCS is optional
try:
    from mongomem_core.ingest.storage import GCSStorage

    _HAS_GCS = True
except ImportError:
    GCSStorage = None  # type: ignore
    _HAS_GCS = False

__all__ = [
    # Config
    "IngestConfig",
    "ChunkConfig",
    "ExtractorType",
    "ChunkerType",
    # Results
    "IngestResult",
    "FileResult",
    # Utilities
    "SUPPORTED_EXTENSIONS",
    "validate_file_extension",
    # Pipeline
    "ingest_documents",
    # Storage backends
    "StorageBackend",
    "LocalStorage",
    "GCSStorage",
    "get_default_backends",
]
