"""
Data models for the task queue.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, Literal

from bson import ObjectId

TaskStatus = Literal["queued", "running", "succeeded", "failed", "dead"]


@dataclass
class EnqueuedTask:
    """Result of enqueueing a task."""

    id: Any
    status: TaskStatus


@dataclass
class ClaimedTask:
    """A task claimed by a worker for processing."""

    id: ObjectId
    task_type: str
    payload: Dict[str, Any]
    priority: int
    remaining_retries: int
    attempts: int
    created_at: datetime
    lease_expires_at: datetime


__all__ = ["TaskStatus", "EnqueuedTask", "ClaimedTask"]
