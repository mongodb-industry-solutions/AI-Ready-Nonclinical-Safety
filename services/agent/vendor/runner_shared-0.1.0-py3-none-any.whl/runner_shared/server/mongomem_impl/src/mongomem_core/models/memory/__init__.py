"""
Memory-domain models for `mongomem_core`.

This package groups common base types and concrete schemas for the different
memory collections (short-term, semantic, episodic, snapshot, user context, etc.).
"""

from .base import BaseMemoryIn, ChunkVisibility, HasEmbeddings, MessageRole
from .episodic import (
    EpisodicBase,
    EpisodicDB,
    EpisodicIn,
    EpisodicOut,
    EpisodicUpdate,
)
from .internal_state import (
    InternalStateDB,
    InternalStateIn,
    InternalStateOut,
    UpdateReason,
)
from .procedural import (
    ProceduralBase,
    ProceduralDB,
    ProceduralIn,
    ProceduralOut,
    ProceduralResource,
    ProceduralStep,
    ProceduralUpdate,
)
from .publishing import (
    AgentAttributionMixin,
    ExtractionMetadataMixin,
    PublishedScope,
    PublishingLineageEntry,
    PublishingMetadata,
    ShareableMemoryType,
)
from .semantic import (
    SemanticBase,
    SemanticDB,
    SemanticIn,
    SemanticOut,
    SemanticUpdate,
)
from .short_term import (
    ShortTermBase,
    ShortTermDB,
    ShortTermIn,
    ShortTermOut,
    ToolCall,
    ToolResult,
)
from .snapshot import (
    SnapshotBase,
    SnapshotDB,
    SnapshotFunctionCall,
    SnapshotIn,
    SnapshotMessage,
    SnapshotOut,
    SnapshotToolCall,
    SnapshotUpdate,
)
from .taxonomic import (
    CreationMethod,
    TaxonomicBase,
    TaxonomicBulkIn,
    TaxonomicDB,
    TaxonomicIn,
    TaxonomicOut,
    TaxonomicOutFiltered,
    TaxonomicUpdate,
)
from .user_prefs import (
    UserContextMemoryBase,
    UserContextMemoryDB,
    UserContextMemoryIn,
    UserContextMemoryOut,
    UserContextMemoryUpdate,
)

__all__ = [
    # Base types
    "MessageRole",
    "ChunkVisibility",
    "BaseMemoryIn",
    "HasEmbeddings",
    # Publishing types
    "PublishedScope",
    "ShareableMemoryType",
    "PublishingLineageEntry",
    "PublishingMetadata",
    "ExtractionMetadataMixin",
    "AgentAttributionMixin",
    # Short-term memory
    "ShortTermIn",
    "ShortTermBase",
    "ShortTermDB",
    "ShortTermOut",
    "ToolCall",
    "ToolResult",
    # Episodic memory
    "EpisodicIn",
    "EpisodicBase",
    "EpisodicDB",
    "EpisodicOut",
    "EpisodicUpdate",
    # Semantic memory
    "SemanticIn",
    "SemanticUpdate",
    "SemanticBase",
    "SemanticDB",
    "SemanticOut",
    # Procedural memory
    "ProceduralStep",
    "ProceduralResource",
    "ProceduralIn",
    "ProceduralUpdate",
    "ProceduralBase",
    "ProceduralDB",
    "ProceduralOut",
    # Taxonomic memory
    "CreationMethod",
    "TaxonomicIn",
    "TaxonomicUpdate",
    "TaxonomicBase",
    "TaxonomicDB",
    "TaxonomicOut",
    "TaxonomicOutFiltered",
    "TaxonomicBulkIn",
    # Snapshot memory
    "SnapshotFunctionCall",
    "SnapshotToolCall",
    "SnapshotMessage",
    "SnapshotIn",
    "SnapshotUpdate",
    "SnapshotBase",
    "SnapshotDB",
    "SnapshotOut",
    # User context memory
    "UserContextMemoryIn",
    "UserContextMemoryUpdate",
    "UserContextMemoryBase",
    "UserContextMemoryDB",
    "UserContextMemoryOut",
    # Internal state (IWM)
    "UpdateReason",
    "InternalStateIn",
    "InternalStateDB",
    "InternalStateOut",
]
