"""
Configuration for extraction pipelines.

Provides frozen dataclasses for extraction settings, matching ExoMemory's
SemanticExtractionSettings for full parity.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable


@runtime_checkable
class ExtractionConfigProtocol(Protocol):
    """
    Protocol for extraction configurations.

    Defines the minimum required fields for use with Consolidator and scorer.
    Both SemanticExtractionConfig and EpisodicExtractionConfig implement this.
    """

    # Scoring fields
    min_combined_score_threshold: float
    citation_weight: float
    confidence_weight: float

    # Consolidator fields
    consolidation_top_k: int
    consolidation_similarity_threshold: float
    reinforcement_history_limit: int


@dataclass(frozen=True)
class SemanticExtractionConfig:
    """
    Full config matching ExoMemory SemanticExtractionSettings.

    Frozen for immutability and hashability.
    """

    enabled: bool = True

    # Scoring weights and thresholds
    min_combined_score_threshold: float = 0.5
    citation_weight: float = 0.6
    confidence_weight: float = 0.4

    # Consolidation settings
    consolidation_top_k: int = 5
    consolidation_similarity_threshold: float = 0.75

    # Limits
    max_facts_per_snapshot: int = 10
    reinforcement_history_limit: int = 20

    # Observability / sampling
    max_sample_extractions: int = 3
    sample_text_truncate_length: int = 100


@dataclass(frozen=True)
class EpisodicExtractionConfig:
    """
    Full config for episodic extraction with safe defaults.

    Episodic events are more contextual and less citation-dependent than
    semantic facts, hence the different weight ratios.

    Frozen for immutability and hashability.
    """

    enabled: bool = True

    # Scoring weights and thresholds (events are more contextual)
    min_combined_score_threshold: float = 0.4  # Lower than semantic (0.5)
    citation_weight: float = 0.3  # Events span multiple messages
    confidence_weight: float = 0.7

    # Consolidation settings (higher threshold to reduce false event merges)
    consolidation_top_k: int = 5
    consolidation_similarity_threshold: float = 0.80  # Higher than semantic (0.75)

    # Limits
    max_events_per_snapshot: int = 10
    reinforcement_history_limit: int = 20

    # Observability / sampling
    max_sample_extractions: int = 3
    sample_text_truncate_length: int = 100


@dataclass(frozen=True)
class TaxonomicExtractionConfig:
    """
    Full config for taxonomic extraction.

    Taxonomic concepts are domain-specific terms with definitions. They require
    higher precision than semantic facts since they form a knowledge ontology.
    Evidence spans are critical for validation.

    Frozen for immutability and hashability.
    """

    enabled: bool = True

    # Scoring weights and thresholds (evidence spans critical for taxonomic)
    min_combined_score_threshold: float = 0.6  # Higher than semantic - concepts need precision
    evidence_weight: float = 0.5  # Evidence spans are critical
    confidence_weight: float = 0.5

    # For compatibility with ExtractionConfigProtocol
    citation_weight: float = 0.5  # Mapped to evidence_weight for protocol

    # Evidence span requirements (unique to taxonomic)
    evidence_span_required: bool = True
    min_evidence_spans: int = 1

    # Consolidation settings (domain+term based, not similarity)
    consolidation_top_k: int = 3
    consolidation_similarity_threshold: float = 0.70
    reinforcement_history_limit: int = 10  # Lighter tracking for concepts

    # Limits
    max_terms_per_snapshot: int = 10
    max_definition_length: int = 1000

    # Observability / sampling
    max_sample_extractions: int = 3
    sample_text_truncate_length: int = 100


def __getattr__(name: str) -> object:
    if name == "ProceduralExtractionConfig":
        from mongomem_core.extraction.procedural.config import ProceduralExtractionConfig

        return ProceduralExtractionConfig
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "ExtractionConfigProtocol",
    "SemanticExtractionConfig",
    "EpisodicExtractionConfig",
    "TaxonomicExtractionConfig",
    "ProceduralExtractionConfig",  # noqa: F822
]
