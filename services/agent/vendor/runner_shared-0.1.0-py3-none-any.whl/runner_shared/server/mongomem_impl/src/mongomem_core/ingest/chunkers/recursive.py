"""
Recursive text chunker using LangChain's RecursiveCharacterTextSplitter.

This chunker splits text at natural boundaries (paragraphs, sentences, words)
while respecting token limits. It uses tiktoken for accurate token counting.
Tracks character offsets for each chunk for precise source attribution.
"""

import logging
from dataclasses import dataclass
from typing import List

from mongomem_core.ingest.models import ChunkConfig

logger = logging.getLogger(__name__)


@dataclass
class ChunkWithOffset:
    """A text chunk with its character offset information."""

    text: str
    start_char: int
    end_char: int


class RecursiveChunker:
    """
    LangChain RecursiveCharacterTextSplitter wrapper.

    Splits text at natural boundaries while respecting token limits.
    Small chunks below min_chunk_size are discarded if configured.
    Tracks character offsets for source attribution.
    """

    def __init__(self, config: ChunkConfig):
        self.config = config
        self._splitter = None
        self._tokenizer = None

    def _get_splitter(self):
        """Lazily initialize the LangChain splitter."""
        if self._splitter is None:
            from langchain_text_splitters import RecursiveCharacterTextSplitter

            self._splitter = RecursiveCharacterTextSplitter.from_tiktoken_encoder(
                encoding_name=self.config.encoding_name,
                chunk_size=self.config.max_chunk_size,
                chunk_overlap=self.config.chunk_overlap,
            )
        return self._splitter

    def _get_tokenizer(self):
        """Lazily initialize the tiktoken tokenizer for counting."""
        if self._tokenizer is None:
            import tiktoken

            self._tokenizer = tiktoken.get_encoding(self.config.encoding_name)
        return self._tokenizer

    def _count_tokens(self, text: str) -> int:
        """Count tokens in text."""
        return len(self._get_tokenizer().encode(text))

    def chunk(self, text: str) -> List[str]:
        """
        Split text into chunks.

        Args:
            text: Input text to split

        Returns:
            List of text chunks (filtered by min_chunk_size if configured)
        """
        if not text or not text.strip():
            return []

        splitter = self._get_splitter()
        chunks = splitter.split_text(text)

        # Filter out small chunks if configured
        if self.config.discard_small_chunks and self.config.min_chunk_size > 0:
            filtered_chunks = []
            for chunk in chunks:
                token_count = self._count_tokens(chunk)
                if token_count >= self.config.min_chunk_size:
                    filtered_chunks.append(chunk)
                else:
                    logger.debug(
                        f"Discarding small chunk ({token_count} tokens < {self.config.min_chunk_size})"
                    )
            return filtered_chunks

        return list(chunks)  # type: ignore[return-value]

    def chunk_with_offsets(self, text: str) -> List[ChunkWithOffset]:
        """
        Split text into chunks with character offset tracking.

        Args:
            text: Input text to split

        Returns:
            List of ChunkWithOffset objects with text and position info
        """
        if not text or not text.strip():
            return []

        chunks = self.chunk(text)
        chunks_with_offsets: List[ChunkWithOffset] = []

        # Track position in original text
        search_start = 0

        for chunk in chunks:
            # Find where this chunk appears in the original text
            # Account for overlap - chunks may start before the end of the previous chunk
            chunk_start = text.find(chunk, max(0, search_start - self.config.chunk_overlap))

            if chunk_start == -1:
                # Fallback: try from the beginning (shouldn't happen normally)
                chunk_start = text.find(chunk)

            if chunk_start != -1:
                chunk_end = chunk_start + len(chunk)
                chunks_with_offsets.append(
                    ChunkWithOffset(
                        text=chunk,
                        start_char=chunk_start,
                        end_char=chunk_end,
                    )
                )
                search_start = chunk_start + 1  # Move past overlap area
            else:
                # Chunk not found in original text (shouldn't happen)
                logger.warning("Could not find chunk position in original text")
                chunks_with_offsets.append(
                    ChunkWithOffset(
                        text=chunk,
                        start_char=-1,
                        end_char=-1,
                    )
                )

        return chunks_with_offsets
