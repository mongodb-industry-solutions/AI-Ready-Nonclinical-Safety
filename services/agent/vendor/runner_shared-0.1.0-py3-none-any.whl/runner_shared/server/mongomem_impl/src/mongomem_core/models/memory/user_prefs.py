"""
Models for user context/preferences memory documents.

User context memory stores user preferences, communication style,
and demographic information to personalize agent interactions.

Preferences can be scoped to:
- User-level (session_id=None): Default preferences across all sessions
- Session-level (session_id set): Preferences specific to a conversation
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Literal, Optional

from bson import ObjectId
from mongomem_core.common.utils import utcnow
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.types import PyObjectId
from pydantic import BaseModel, Field, field_serializer

# Type aliases for preference values
ToneType = Literal["formal", "casual", "professional", "friendly", "technical", "neutral"]
StyleType = Literal["concise", "detailed", "step_by_step", "conversational", "technical"]
ResponseLengthType = Literal["brief", "moderate", "comprehensive"]
FormatType = Literal["bullet_points", "paragraphs", "numbered_list", "code_heavy", "mixed"]
ExpertiseLevelType = Literal["beginner", "intermediate", "advanced", "expert"]
SourceType = Literal["extracted", "user_input", "inferred", "default"]


class UserContextMemoryIn(BaseModel):
    """Input model for creating a user context memory entry.

    User context memories capture communication preferences, style,
    and other user-specific information for personalization.

    All preference fields are optional to support incremental extraction.
    Preferences can be scoped to a session (session_id set) or be
    user-wide defaults (session_id=None).
    """

    # === Scope ===
    session_id: Optional[str] = Field(
        default=None,
        description="Session ID for session-scoped preferences. None = user-level default",
    )

    # === Visibility and sharing ===
    project_id: Optional[str] = Field(default=None, description="Project ID if visibility=shared")
    visibility: ChunkVisibility = Field(
        default=ChunkVisibility.PRIVATE,
        description="Visibility scope for this user context",
    )

    # === Communication Style (all optional for incremental extraction) ===
    tone: Optional[str] = Field(
        default=None,
        description="Preferred communication tone: 'formal', 'casual', 'professional', 'friendly', 'technical'",
    )
    style: Optional[str] = Field(
        default=None,
        description="Preferred communication style: 'concise', 'detailed', 'step_by_step', 'conversational'",
    )
    response_length: Optional[str] = Field(
        default=None,
        description="Preferred response length: 'brief', 'moderate', 'comprehensive'",
    )
    preferred_format: Optional[str] = Field(
        default=None,
        description="Preferred response format: 'bullet_points', 'paragraphs', 'numbered_list', 'code_heavy'",
    )
    language: Optional[str] = Field(
        default=None,
        description="Preferred language for communication (e.g., 'en', 'es', 'fr')",
    )

    # === User Context ===
    expertise_level: Optional[str] = Field(
        default=None,
        description="User's expertise level: 'beginner', 'intermediate', 'advanced', 'expert'",
    )

    # === Free-form Instructions ===
    custom_instructions: Optional[str] = Field(
        default=None,
        description="Free-form custom instructions (e.g., 'Use Python examples', 'Explain like I'm 5')",
    )

    # === User attributes ===
    demographic_tags: List[str] = Field(
        default_factory=list, description="Demographic tags for personalization"
    )
    preferences: Optional[Dict[str, Any]] = Field(
        default=None, description="Additional user preferences (catch-all)"
    )

    # === Metadata ===
    source: Optional[str] = Field(
        default="extracted",
        description="Source of this context: 'extracted', 'user_input', 'inferred', 'default'",
    )

    # Agent attribution fields for collective intelligence
    agent_id: Optional[str] = Field(
        default=None,
        description="Agent ID if this knowledge was extracted via agent-mediated learning",
    )
    extraction_source: Optional[str] = Field(
        default=None,
        description="Source of extraction: 'user_direct', 'agent_mediated', 'agent_collective'",
    )
    collective_metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Metadata for collective intelligence: contributing_users, confidence, patterns",
    )

    model_config = {"populate_by_name": True, "use_enum_values": True}


class UserContextMemoryUpdate(BaseModel):
    """Model for updating an existing user context memory entry.

    All fields optional - only provided fields will be updated.
    """

    # Scope (cannot change session_id after creation)
    project_id: Optional[str] = None
    visibility: Optional[ChunkVisibility] = None

    # Communication style
    tone: Optional[str] = None
    style: Optional[str] = None
    response_length: Optional[str] = None
    preferred_format: Optional[str] = None
    language: Optional[str] = None

    # User context
    expertise_level: Optional[str] = None
    custom_instructions: Optional[str] = None

    # User attributes
    demographic_tags: Optional[List[str]] = None
    preferences: Optional[Dict[str, Any]] = None
    timezone: Optional[str] = None

    # Metadata
    source: Optional[str] = None
    agent_id: Optional[str] = None
    extraction_source: Optional[str] = None
    collective_metadata: Optional[Dict[str, Any]] = None


class UserContextMemoryBase(UserContextMemoryIn):
    """
    Base model with fields added after input validation.

    Includes org_id, user_id, timestamps, and timezone which are
    typically set by the service layer.
    """

    org_id: str = Field(..., description="Organization/tenant ID")
    user_id: str = Field(..., description="User ID this context belongs to")
    timezone: Optional[str] = Field(default=None, description="User's preferred timezone")
    timestamp: datetime = Field(default_factory=utcnow, description="Creation timestamp")
    updated_at: Optional[datetime] = Field(default=None, description="Last update timestamp")

    model_config = {
        "arbitrary_types_allowed": True,
        "from_attributes": True,
        "populate_by_name": True,
        "use_enum_values": True,
    }


class UserContextMemoryDB(UserContextMemoryBase):
    """
    Database representation of a user context memory document.

    Includes the MongoDB _id field.
    """

    id: PyObjectId = Field(default_factory=PyObjectId, alias="_id")

    @field_serializer("id", when_used="json")
    def _serialize_id(self, v: ObjectId) -> str:
        return str(v)


class UserContextMemoryOut(UserContextMemoryBase):
    """Output model for user context memory reads."""

    id: str = Field(..., alias="_id")


__all__ = [
    "UserContextMemoryIn",
    "UserContextMemoryUpdate",
    "UserContextMemoryBase",
    "UserContextMemoryDB",
    "UserContextMemoryOut",
    "ToneType",
    "StyleType",
    "ResponseLengthType",
    "FormatType",
    "ExpertiseLevelType",
    "SourceType",
]
