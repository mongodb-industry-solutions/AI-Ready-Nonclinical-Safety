"""
Models for mongomem_core.

This package hosts Pydantic models and schema helpers for all domains.
"""

from .engine import (
    CreateEpisodicResult,
    CreateSemanticResult,
    CreateSnapshotResult,
    CreateUserContextResult,
    DeleteResult,
    PromoteSnapshotResult,
    WriteTurnResult,
)
from .filters import (
    FieldFilter,
    FilterOperator,
    MetadataFilter,
)
from .memory import (
    BaseMemoryIn,
    ChunkVisibility,
    HasEmbeddings,
    MessageRole,
    ShortTermBase,
    ShortTermDB,
    ShortTermIn,
    ShortTermOut,
    ToolCall,
    ToolResult,
)
from .retrieval import (
    ContextConfig,
    ContextMetadata,
    ContextResponse,
    FormatStyle,
    MemoryChunk,
    MemorySource,
    ModelType,
)
from .types import PyObjectId

__all__ = [
    # Type helpers
    "PyObjectId",
    # Engine request/response models
    "WriteTurnResult",
    "CreateSemanticResult",
    "CreateEpisodicResult",
    "CreateUserContextResult",
    "CreateSnapshotResult",
    "PromoteSnapshotResult",
    "DeleteResult",
    # Base memory types
    "MessageRole",
    "ChunkVisibility",
    "BaseMemoryIn",
    "HasEmbeddings",
    # Short-term memory
    "ShortTermIn",
    "ShortTermBase",
    "ShortTermDB",
    "ShortTermOut",
    "ToolCall",
    "ToolResult",
    # Retrieval models
    "MemorySource",
    "FormatStyle",
    "ModelType",
    "MemoryChunk",
    "ContextConfig",
    "ContextMetadata",
    "ContextResponse",
    # Filter models
    "FilterOperator",
    "FieldFilter",
    "MetadataFilter",
]
