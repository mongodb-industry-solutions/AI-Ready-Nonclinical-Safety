"""
Base models shared across memory types in ``mongomem_core``.

These are adapted from the legacy ExoMemory ``app.models.schemas.base`` module
and provide common structure for all memory-domain schemas.
"""

from __future__ import annotations

from abc import ABC
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, model_validator


class MessageRole(str, Enum):
    """Standard message roles for conversation participants."""

    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    TOOL = "tool"

    @classmethod
    def validation_pattern(cls) -> str:
        """Return a regex pattern suitable for validating roles."""

        roles = "|".join(role.value for role in cls)
        return f"^({roles})$"


class ChunkVisibility(str, Enum):
    """
    Visibility / sharing scope for memory chunks.

    Mirrors the ExoMemory visibility model:

    * ``PRIVATE`` – only the creating user
    * ``SHARED`` – members of a specific group
    * ``ORG`` – everyone in the org
    """

    PRIVATE = "private"
    SHARED = "shared"
    ORG = "org"

    @classmethod
    def schema_validation_domain(cls) -> list[str]:
        """Return the allowed visibility values for schema/domain use."""

        return [entry.value for entry in cls]


class BaseMemoryIn(ABC, BaseModel):
    """
    Common input fields shared by memory types.

    Concrete memory input models (e.g. ``SemanticIn``, ``EpisodicIn``,
    ``ShortTermIn``, ``SnapshotIn``) should inherit from this class.
    """

    project_id: Optional[str] = None
    visibility: ChunkVisibility = ChunkVisibility.PRIVATE
    metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Metadata dictionary for storing arbitrary key-value pairs.",
    )
    content_embedding_model_id: Optional[str] = Field(
        default=None,
        description=(
            "Model identifier used to generate the full content embedding, "
            "if separate from a summary embedding."
        ),
    )

    @model_validator(mode="after")
    def _validate_generic_fields(self) -> "BaseMemoryIn":
        """
        Cross-field validation for generic memory constraints.
        """

        if self.visibility == ChunkVisibility.SHARED and self.project_id is None:
            raise ValueError("`project_id` must be supplied when visibility=shared")
        return self


class HasEmbeddings:
    """
    Mixin for models that carry vector embeddings.

    This does not inherit from BaseModel directly so it can be mixed into
    multiple Pydantic models.
    """

    has_embedding: bool = Field(default=False, description="Flag for efficient indexing")
    embedding: Optional[List[float]] = Field(
        default=None,
        description="Single embedding vector for fast vector search.",
    )

    def embedding_present(self) -> bool:
        """Return True if an embedding is present and non-empty."""

        return bool(self.embedding and len(self.embedding) > 0)
