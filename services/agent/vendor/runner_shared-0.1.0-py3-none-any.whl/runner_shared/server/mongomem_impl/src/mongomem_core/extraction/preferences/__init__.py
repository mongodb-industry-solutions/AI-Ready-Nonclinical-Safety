"""
Preferences extraction pipeline.

Provides PreferencesPipeline class and factory function for creating
complete preferences extraction pipelines.

This pipeline is simpler than semantic/episodic because:
- No embeddings needed (preferences are structured, not semantic)
- No consolidator with similarity search
- Simple upsert with field-level merge
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

if TYPE_CHECKING:
    from mongomem_core.protocols import LLMProtocol
    from pymongo.database import Database

from mongomem_core.extraction.preferences.extractor import (
    ExtractedPreferences,
    PreferencesExtractor,
)
from mongomem_core.extraction.preferences.persistence import (
    PreferencesPersistenceResult,
    upsert_extracted_preferences,
)
from mongomem_core.extraction.types import ApprovalMode
from mongomem_core.observability import CoreObservability

logger = logging.getLogger(__name__)


@dataclass
class PreferencesExtractionConfig:
    """Configuration for preferences extraction."""

    enabled: bool = True
    min_confidence_threshold: float = 0.5


@dataclass
class PreferencesExtractionResult:
    """Result of preferences extraction pipeline."""

    success: bool = True
    source_reference: str = ""
    session_id: str = ""

    # Extraction stats
    extracted: bool = False
    confidence: float = 0.0

    # Persistence stats
    action: str = "none"  # "add", "merge", "skip", "error"
    doc_id: Optional[str] = None
    fields_updated: int = 0

    # Approval mode support
    pending_id: Optional[str] = None
    approval_mode: ApprovalMode = "auto"

    # Timing
    duration_ms: float = 0.0

    # Errors
    errors: List[str] = field(default_factory=list)


class PreferencesPipeline:
    """
    Preferences extraction pipeline.

    Orchestrates:
    1. Extract - LLM-based extraction from messages
    2. Persist - Upsert with field-level merge

    Simpler than semantic pipeline (no embeddings, no consolidation).
    """

    def __init__(
        self,
        extractor: PreferencesExtractor,
        config: PreferencesExtractionConfig,
        db: "Database",
        obs: Optional[CoreObservability] = None,
    ) -> None:
        """
        Initialize preferences pipeline.

        Args:
            extractor: PreferencesExtractor instance
            config: Extraction configuration
            db: MongoDB database instance
            obs: Optional CoreObservability for observability (metrics/spans/events)
        """
        self.extractor = extractor
        self.config = config
        self._db = db
        self._obs = obs or CoreObservability()

    def run(
        self,
        messages: List[Dict[str, Any]],
        org_id: str,
        user_id: str,
        session_id: str,
        source_id: str,
        approval_mode: ApprovalMode = "auto",
    ) -> PreferencesExtractionResult:
        """
        Run preferences extraction pipeline.

        Args:
            messages: Conversation messages to extract from
            org_id: Organization ID
            user_id: User ID
            session_id: Session ID for session-scoped preferences
            source_id: Source reference (snapshot ID)
            approval_mode: "auto" persists immediately, "manual" stages for review

        Returns:
            PreferencesExtractionResult with extraction and persistence stats
        """
        result = PreferencesExtractionResult(
            source_reference=source_id,
            session_id=session_id,
            approval_mode=approval_mode,
        )
        start_time = datetime.now(timezone.utc)

        try:
            # Check if enabled
            if not self.config.enabled:
                logger.debug("Preferences extraction disabled")
                result.success = True
                return result

            # 1. Extract preferences from messages
            extracted = self.extractor.extract(messages)

            if not extracted or not extracted.has_any_preference():
                logger.debug("No preferences extracted from conversation")
                result.success = True
                result.action = "skip"
                return result

            result.extracted = True
            result.confidence = extracted.confidence

            # 2. Persist or Stage
            if approval_mode == "manual":
                from mongomem_core.extraction.approval.store import PendingStore
                from mongomem_core.extraction.approval.types import PendingPreferencesPayload

                store = PendingStore(self._db, obs=self._obs)
                payload = PendingPreferencesPayload(
                    session_id=session_id,
                    tone=extracted.tone,
                    style=extracted.style,
                    response_length=extracted.response_length,
                    expertise_level=extracted.expertise_level,
                    preferred_format=extracted.preferred_format,
                    language=extracted.language,
                    custom_instructions=extracted.custom_instructions,
                    confidence=extracted.confidence,
                    evidence=extracted.evidence,
                )
                pending_id = store.stage(
                    org_id=org_id,
                    user_id=user_id,
                    source_id=source_id,
                    extraction_type="preferences",
                    payload=payload,
                )
                result.pending_id = pending_id
                result.action = "staged"
                logger.info(
                    "Preferences staged for approval: session=%s pending_id=%s",
                    session_id,
                    pending_id,
                )
            else:
                persistence_result = upsert_extracted_preferences(
                    db=self._db,
                    org_id=org_id,
                    user_id=user_id,
                    session_id=session_id,
                    extracted=extracted,
                    source_id=source_id,
                    min_confidence=self.config.min_confidence_threshold,
                )

                result.action = persistence_result.action
                result.doc_id = persistence_result.doc_id
                result.fields_updated = persistence_result.fields_updated

                if not persistence_result.success:
                    result.success = False
                    if persistence_result.error:
                        result.errors.append(persistence_result.error)

                # Log result
                if persistence_result.action in ("add", "merge"):
                    logger.info(
                        "Preferences pipeline completed for session=%s: action=%s fields=%d",
                        session_id,
                        persistence_result.action,
                        persistence_result.fields_updated,
                    )
                else:
                    logger.debug(
                        "Preferences pipeline completed for session=%s: action=%s",
                        session_id,
                        persistence_result.action,
                    )

        except Exception as e:
            logger.error(
                "Preferences extraction failed for session=%s: %s",
                session_id,
                e,
                exc_info=True,
            )
            result.success = False
            result.errors.append(str(e))

        finally:
            # Calculate duration
            end_time = datetime.now(timezone.utc)
            result.duration_ms = (end_time - start_time).total_seconds() * 1000

            # Emit observability metrics
            self._obs.preferences_updated(result.fields_updated, result.duration_ms)

        return result


def create_preferences_pipeline(
    db: "Database",
    llm: "LLMProtocol",
    config: Optional[PreferencesExtractionConfig] = None,
    prompt_resolver: Optional[Callable[[], Optional[str]]] = None,
    obs: Optional[CoreObservability] = None,
) -> PreferencesPipeline:
    """
    Factory function to create a preferences pipeline.

    Args:
        db: MongoDB database instance
        llm: LLM protocol implementation
        config: Optional extraction configuration (uses defaults if not provided)
        prompt_resolver: Optional callable for hot-reload prompts
        obs: Optional CoreObservability for observability (metrics/spans/events)

    Returns:
        Configured PreferencesPipeline ready to run
    """
    config = config or PreferencesExtractionConfig()

    extractor = PreferencesExtractor(llm, prompt_resolver)

    return PreferencesPipeline(
        extractor=extractor,
        config=config,
        db=db,
        obs=obs,
    )


__all__ = [
    "PreferencesPipeline",
    "PreferencesExtractor",
    "PreferencesExtractionConfig",
    "PreferencesExtractionResult",
    "PreferencesPersistenceResult",
    "ExtractedPreferences",
    "create_preferences_pipeline",
]
