"""Common utilities for mongomem_core."""

from mongomem_core.exceptions import (
    ConfigurationError,
    ConnectionError,
    DatabaseOperationError,
    DocumentNotFoundError,
    DuplicateDocumentError,
    ExtractionError,
    MongoMemError,
    ValidationError,
)

from .token_counting import (
    MODEL_TYPE_TO_FORMAT,
    MODEL_TYPE_TO_LITELLM,
    TokenCounter,
    get_token_counter,
    reset_token_counter,
    resolve_format_style,
    resolve_model_name,
)
from .utils import (
    cosine_similarity,
    handle_db_error,
    handle_duplicate_key_error,
    to_object_id,
    utcnow,
)

__all__ = [
    # Utils
    "utcnow",
    "to_object_id",
    "handle_db_error",
    "handle_duplicate_key_error",
    "cosine_similarity",
    # Token counting
    "TokenCounter",
    "resolve_model_name",
    "resolve_format_style",
    "get_token_counter",
    "reset_token_counter",
    "MODEL_TYPE_TO_LITELLM",
    "MODEL_TYPE_TO_FORMAT",
    # Exceptions
    "MongoMemError",
    "ConnectionError",
    "DocumentNotFoundError",
    "ValidationError",
    "DatabaseOperationError",
    "DuplicateDocumentError",
    "ConfigurationError",
    "ExtractionError",
]
