"""
STM to Snapshot promotion pipeline.

This module handles the promotion of short-term memory (STM) documents to
snapshots. It implements configurable thresholds, embedding strategies, and
pair preservation logic.

Design Principles:
- write_turn stays fast - no inline promotion (worker handles auto-promotion)
- Sync or async embedding - transfer from STM, generate fresh, or defer to worker
- Platform-ready - manual control for OE, auto-promotion for standalone users

Embedding Strategies:
- transfer: Average STM embeddings (fast, no LLM call)
- generate: Call embedder.embed() synchronously during promotion
- defer: Create snapshot without embedding (worker generates async)
"""

from __future__ import annotations

import logging
import uuid
from datetime import timedelta
from typing import Any, Dict, List, Literal, Optional, Protocol, Tuple

import numpy as np
from mongomem_core.common.constants import DEFAULT_MAX_MESSAGES
from mongomem_core.common.utils import cosine_similarity, utcnow
from mongomem_core.memory.snapshot import create_snapshot
from mongomem_core.models.config.snapshot_config import SnapshotConfig
from mongomem_core.models.memory.base import MessageRole
from mongomem_core.models.memory.snapshot import (
    SnapshotDB,
    SnapshotIn,
    SnapshotMessage,
    SnapshotToolCall,
)
from pydantic import ValidationError
from pymongo.database import Database

from ..memory.short_term import (
    delete_stm_by_ids,
    get_stm_raw_docs,
    mark_stm_promoted,
    mark_stm_promotion_failed,
)

logger = logging.getLogger(__name__)


class EmbedderProtocol(Protocol):
    """Protocol for embedding generation."""

    def embed(self, text: str) -> List[float]:
        """Generate embedding for text."""
        ...


def should_promote(
    stm_docs: List[Dict[str, Any]],
    config: SnapshotConfig,
    *,
    embedder: Optional[EmbedderProtocol] = None,
) -> Tuple[bool, str]:
    """
    Check if STM documents should be promoted to a snapshot.

    Checks thresholds in order: message_count, token_count, topic_shift.

    Args:
        stm_docs: List of STM documents (raw dicts from MongoDB)
        config: Snapshot configuration with thresholds
        embedder: Optional embedder for topic shift detection

    Returns:
        Tuple of (should_promote, reason)
        reason is one of: "message_count", "token_count", "topic_shift", "none"

    Example:
        >>> should, reason = should_promote(stm_docs, config)
        >>> if should:
        ...     print(f"Promoting because: {reason}")
    """
    if not stm_docs:
        return False, "none"

    # Check message count threshold
    if config.should_snapshot_by_count(len(stm_docs)):
        logger.debug(
            "Snapshot threshold met: message_count=%d >= max_messages=%d",
            len(stm_docs),
            config.max_messages,
        )
        return True, "message_count"

    # Check token count threshold
    if config.max_tokens is not None:
        total_tokens = _estimate_token_count(stm_docs)
        if config.should_snapshot_by_tokens(total_tokens):
            logger.debug(
                "Snapshot threshold met: token_count=%d >= max_tokens=%d",
                total_tokens,
                config.max_tokens,
            )
            return True, "token_count"

    # Check topic shift (requires embedder and enabled in config)
    if config.topic_shift_enabled and embedder is not None:
        is_shift, score = _detect_topic_shift(stm_docs, config.topic_shift_threshold)
        if is_shift:
            logger.debug(
                "Topic shift detected: similarity=%.3f < threshold=%.3f",
                score,
                config.topic_shift_threshold,
            )
            return True, "topic_shift"

    return False, "none"


def _estimate_token_count(stm_docs: List[Dict[str, Any]]) -> int:
    """
    Estimate total token count from STM documents.

    Uses a simple heuristic: ~4 characters per token (GPT-style tokenization).
    """
    total_chars = sum(len(doc.get("content", "") or "") for doc in stm_docs)
    return total_chars // 4


def _detect_topic_shift(
    stm_docs: List[Dict[str, Any]],
    threshold: float,
) -> Tuple[bool, float]:
    """
    Detect topic shift using cosine similarity of embeddings.

    Compares the average embedding of the first half of messages to the
    average embedding of the second half.

    Args:
        stm_docs: List of STM documents with embeddings
        threshold: Similarity threshold below which a shift is detected

    Returns:
        Tuple of (is_shift, similarity_score)
    """
    # Get user messages with embeddings
    embedded_docs = [
        doc for doc in stm_docs if doc.get("embedding") and doc.get("role") == MessageRole.USER
    ]

    if len(embedded_docs) < 4:  # Need at least 2 messages per half
        return False, 1.0

    # Split into halves
    mid = len(embedded_docs) // 2
    first_half = embedded_docs[:mid]
    second_half = embedded_docs[mid:]

    # Compute average embeddings
    first_avg = _compute_average_embedding([d["embedding"] for d in first_half])
    second_avg = _compute_average_embedding([d["embedding"] for d in second_half])

    if first_avg is None or second_avg is None:
        return False, 1.0

    # Compute cosine similarity
    similarity = cosine_similarity(first_avg, second_avg)

    return similarity < threshold, similarity


def _compute_average_embedding(
    embeddings: List[List[float]],
) -> Optional[List[float]]:
    """Compute the weighted mean of a list of embeddings."""
    if not embeddings:
        return None

    # Use numpy for efficient computation
    arr = np.array(embeddings)
    avg = np.mean(arr, axis=0)

    result: List[float] = avg.tolist()
    return result


# cosine_similarity is imported from common.utils


def transfer_embeddings(
    stm_docs: List[Dict[str, Any]],
) -> Tuple[Optional[List[float]], Optional[str]]:
    """
    Transfer embeddings from STM documents by computing weighted average.

    This is the "transfer" embedding strategy - fast, no LLM call required.

    Args:
        stm_docs: List of STM documents with optional embeddings

    Returns:
        Tuple of (embedding, strategy_name)
        Returns (None, None) if no embeddings available

    Example:
        >>> embedding, strategy = transfer_embeddings(stm_docs)
        >>> if embedding:
        ...     # Use transferred embedding
    """
    # Collect user message embeddings (more semantically meaningful)
    user_embeddings = [
        doc["embedding"]
        for doc in stm_docs
        if doc.get("embedding") and doc.get("role") == MessageRole.USER
    ]

    if not user_embeddings:
        # Fallback to all embeddings
        all_embeddings = [doc["embedding"] for doc in stm_docs if doc.get("embedding")]
        if not all_embeddings:
            logger.debug("No embeddings available for transfer")
            return None, None
        user_embeddings = all_embeddings

    avg_embedding = _compute_average_embedding(user_embeddings)
    if avg_embedding is None:
        return None, None

    logger.debug(
        "Transferred embedding from %d STM docs (dimension=%d)",
        len(user_embeddings),
        len(avg_embedding),
    )
    return avg_embedding, "transfer"


def _preserve_pairs(
    stm_docs: List[Dict[str, Any]],
    config: SnapshotConfig,
) -> List[Dict[str, Any]]:
    """
    Ensure we don't split user-assistant message pairs.

    If the last message is from the user, keep it for the next snapshot
    to ensure it gets paired with the assistant response.

    Args:
        stm_docs: List of STM documents sorted by timestamp
        config: Snapshot configuration

    Returns:
        List of STM documents to include in snapshot
    """
    if not config.preserve_pairs or not stm_docs:
        return stm_docs

    # Check if last message is from user
    last_doc = stm_docs[-1]
    if last_doc.get("role") == MessageRole.USER:
        # Exclude the last user message - it will be included in next snapshot
        # with its assistant response
        logger.debug("Preserving user message pair by excluding last user message")
        return stm_docs[:-1]

    return stm_docs


def _stm_to_snapshot_message(
    stm_doc: Dict[str, Any],
) -> tuple["SnapshotMessage", None] | tuple[None, str]:
    """Convert a raw STM document to a SnapshotMessage.

    Returns:
        (SnapshotMessage, None) on success.
        (None, error_str) if Pydantic validation fails — the doc should be
        DLQ'd and marked promoted with promotion_error rather than included
        in the snapshot.
    """
    try:
        return SnapshotMessage(
            role=stm_doc["role"],
            content=stm_doc.get("content"),
            timestamp=stm_doc.get("timestamp", utcnow()),
            agent_id=stm_doc.get("agent_id"),
            tool_calls=_normalize_tool_calls(stm_doc.get("tool_calls")),
            tool_call_id=stm_doc.get("tool_call_id"),
            stm_embedding=stm_doc.get("embedding"),
        ), None
    except (ValidationError, ValueError, Exception) as exc:
        return None, str(exc)


def _normalize_tool_calls(
    tool_calls: Optional[List[Dict[str, Any]]],
) -> Optional[List[Dict[str, Any]]]:
    """Normalize tool_calls to OpenAI-compatible SnapshotToolCall format.

    The OE writes STM tool_calls as flat dicts: {"name": ..., "arguments": ..., "id": ...}.
    SnapshotMessage expects: {"id": ..., "type": "function", "function": {"name": ..., "arguments": "<json string>"}}.
    Validates each entry against SnapshotToolCall before returning.
    """
    import json as _json

    if not tool_calls:
        return tool_calls

    normalized = []
    for tc in tool_calls:
        if "function" in tc:
            fn = tc["function"]
            # Validate id and function.name are non-empty before accepting
            tc_id = tc.get("id") or ""
            fn_name = fn.get("name") or ""
            if not tc_id:
                raise ValueError(f"tool_call missing required 'id': {tc}")
            if not fn_name:
                raise ValueError(f"tool_call missing required 'function.name': {tc}")
            args = fn.get("arguments", {})
            if not isinstance(args, str):
                fn = {**fn, "arguments": _json.dumps(args)}
                tc = {**tc, "function": fn}
            candidate = tc
        else:
            # Flat OE/mongomem format — validate id and name are non-empty
            tc_id = tc.get("id") or ""
            tc_name = tc.get("name") or ""
            if not tc_id:
                raise ValueError(f"tool_call missing required 'id': {tc}")
            if not tc_name:
                raise ValueError(f"tool_call missing required 'name': {tc}")
            args = tc.get("arguments", tc.get("args", {}))
            if not isinstance(args, str):
                args = _json.dumps(args)
            candidate = {
                "id": tc_id,
                "type": "function",
                "function": {
                    "name": tc_name,
                    "arguments": args,
                },
            }

        # Validate against the Pydantic schema — raises if still malformed
        validated = SnapshotToolCall.model_validate(candidate)
        normalized.append(validated.model_dump())

    return normalized


def promote_stm_to_snapshot(
    db: Database,
    session_id: str,
    org_id: str,
    user_id: str,
    project_id: str,
    *,
    stm_docs: Optional[List[Dict[str, Any]]] = None,
    config: Optional[SnapshotConfig] = None,
    embedder: Optional[EmbedderProtocol] = None,
    force: bool = False,
    delete_promoted: Optional[bool] = None,
    reason_override: Optional[
        Literal["auto", "manual", "idle", "disconnect", "scheduled", "topic_shift"]
    ] = None,
) -> Optional[SnapshotDB]:
    """
    Promote STM documents to a snapshot.

    This is the main entry point for STM -> Snapshot promotion.

    Steps:
    1. Fetch STM docs for session (skipped if stm_docs is provided)
    2. Check thresholds (unless force=True)
    3. Preserve user-assistant pairs
    4. Handle embedding based on config.embedding_strategy:
       - "transfer": average STM embeddings
       - "generate": call embedder.embed() (requires embedder)
       - "defer": create without embedding (worker fills later)
    5. Create snapshot
    6. Mark promoted STM docs (or delete them)

    Args:
        db: MongoDB database instance
        session_id: Session identifier
        org_id: Organization ID
        user_id: User ID
        project_id: Optional project ID for scoped fetching (used when stm_docs is None)
        stm_docs: Pre-fetched unpromoted STM docs; if provided the fetch step is skipped
        config: Optional snapshot configuration (uses defaults if not provided)
        embedder: Optional embedder for "generate" strategy
        force: If True, promote regardless of thresholds
        delete_promoted: If True, delete promoted STM docs; if False, mark as promoted.
            When None (default), the value from config.delete_promoted is used, making
            config the single source of truth.
        reason_override: Optional override for snapshot_reason field

    Returns:
        SnapshotDB if promotion occurred, None if thresholds not met or no STM docs

    Raises:
        DatabaseOperationError: If database operations fail.

    Example:
        >>> # Manual promotion (force=True)
        >>> snapshot = promote_stm_to_snapshot(
        ...     db, session_id, org_id, user_id, force=True
        ... )

        >>> # Auto promotion with threshold check
        >>> snapshot = promote_stm_to_snapshot(
        ...     db, session_id, org_id, user_id, config=config
        ... )
    """
    config = config or SnapshotConfig()

    # Resolve effective delete_promoted: explicit argument wins, otherwise use config
    effective_delete_promoted = (
        delete_promoted if delete_promoted is not None else config.delete_promoted
    )

    # Fetch only unpromoted STM documents if not supplied by the caller
    if stm_docs is None:
        stm_docs = get_stm_raw_docs(
            db, session_id, org_id, user_id=user_id, project_id=project_id, exclude_promoted=True
        )

    if not stm_docs:
        logger.debug("No STM docs to promote for session=%s", session_id)
        return None

    # Check if promotion is needed
    if not force:
        should, reason = should_promote(stm_docs, config, embedder=embedder)
        if not should:
            logger.debug(
                "Snapshot threshold not met for session=%s (count=%d)",
                session_id,
                len(stm_docs),
            )
            return None
    else:
        reason = "manual"

    # Use reason override if provided
    snapshot_reason = reason_override or _reason_to_snapshot_reason(reason)

    # Preserve user-assistant pairs
    docs_to_promote = _preserve_pairs(stm_docs, config)

    if not docs_to_promote:
        logger.debug("No docs left to promote after pair preservation")
        return None

    # Build snapshot messages — DLQ malformed docs before computing embeddings
    # so that embeddings are derived only from the docs that will actually go
    # into the snapshot, not from docs that are about to be rejected.
    messages = []
    failed_ids: Dict[str, str] = {}  # stm _id → error string
    for doc in docs_to_promote:
        msg, error = _stm_to_snapshot_message(doc)
        if msg is not None:
            messages.append(msg)
        else:
            doc_id = str(doc["_id"])
            failed_ids[doc_id] = error
            logger.warning(
                "STM doc %s failed schema validation, DLQ'd: %s",
                doc_id,
                error[:200],
            )

    if failed_ids:
        mark_stm_promotion_failed(db, failed_ids, org_id)

    if not messages:
        logger.warning(
            "All %d STM docs failed schema validation for session=%s — no snapshot created",
            len(docs_to_promote),
            session_id,
        )
        return None

    # Only the docs that passed validation contribute to the snapshot embedding.
    good_docs = [doc for doc in docs_to_promote if str(doc["_id"]) not in failed_ids]

    # Handle embedding strategy
    embedding: Optional[List[float]] = None
    embedding_model_id: Optional[str] = None
    embedding_strategy: Optional[str] = None

    if config.embedding_strategy == "transfer":
        embedding, embedding_strategy = transfer_embeddings(good_docs)
    elif config.embedding_strategy == "generate":
        if embedder is not None:
            embedding, embedding_model_id, embedding_strategy = _generate_embedding(
                good_docs, embedder
            )
        else:
            logger.warning(
                "embedding_strategy='generate' but no embedder provided, falling back to transfer"
            )
            embedding, embedding_strategy = transfer_embeddings(good_docs)
    elif config.embedding_strategy == "defer":
        embedding_strategy = "defer"
        # No embedding - worker will generate later

    # Extract contributing agent IDs (preserves multi-agent attribution)
    contributing_agent_ids: List[str] = [
        agent_id for agent_id in {doc.get("agent_id") for doc in good_docs} if agent_id is not None
    ]

    # Get boundary turn seq (last promoted turn)
    boundary_turn_seq = good_docs[-1].get("turn_seq")

    # Detect topic shift score if applicable
    topic_shift_score: Optional[float] = None
    topic_id: Optional[str] = None
    if reason == "topic_shift":
        _, topic_shift_score = _detect_topic_shift(good_docs, config.topic_shift_threshold)
        topic_id = str(uuid.uuid4())

    # Determine trigger source
    trigger_source = _reason_to_trigger_source(reason)

    # Create snapshot input
    snapshot_in = SnapshotIn(
        session_id=session_id,
        messages=messages,
        snapshot_reason=snapshot_reason,
        ttl_days=config.ttl_days,
        boundary_turn_seq=boundary_turn_seq,
        trigger_source=trigger_source,
        topic_id=topic_id,
        topic_shift_score=topic_shift_score,
        contributing_agent_ids=contributing_agent_ids,
    )

    # Create snapshot
    snapshot = create_snapshot(
        db,
        snapshot_in,
        org_id,
        user_id,
        embedding=embedding,
        embedding_model_id=embedding_model_id,
        embedding_strategy=embedding_strategy,
    )

    # Handle promoted STM docs — only the successfully converted ones
    # (failed docs were already marked promoted with promotion_error above)
    good_ids = [doc["_id"] for doc in good_docs]
    if good_ids:
        if effective_delete_promoted:
            delete_stm_by_ids(db, good_ids, org_id)
            logger.debug("Deleted %d promoted STM docs", len(good_ids))
        else:
            mark_stm_promoted(db, good_ids, org_id)
            logger.debug("Marked %d STM docs as promoted", len(good_ids))

    logger.info(
        "Promoted %d STM docs to snapshot: id=%s session=%s reason=%s",
        len(docs_to_promote),
        snapshot.id,
        session_id,
        snapshot_reason,
    )

    return snapshot


def _generate_embedding(
    stm_docs: List[Dict[str, Any]],
    embedder: EmbedderProtocol,
) -> Tuple[Optional[List[float]], Optional[str], Optional[str]]:
    """
    Generate a fresh embedding for the snapshot content.

    Args:
        stm_docs: List of STM documents
        embedder: Embedder to use

    Returns:
        Tuple of (embedding, model_id, strategy)
    """
    # Concatenate all content for embedding
    content_parts = []
    for doc in stm_docs:
        role = doc.get("role", "user")
        content = doc.get("content", "")
        if content:
            content_parts.append(f"{role}: {content}")

    combined_content = "\n".join(content_parts)

    if not combined_content:
        return None, None, None

    try:
        embedding = embedder.embed(combined_content)
        # Try to get model ID from embedder if available
        model_id = getattr(embedder, "model_id", None)
        return embedding, model_id, "generate"
    except Exception as e:
        logger.error("Failed to generate embedding: %s", e)
        return None, None, None


def _reason_to_snapshot_reason(
    reason: str,
) -> Literal["auto", "manual", "idle", "disconnect", "scheduled", "topic_shift"]:
    """Map internal reason to snapshot_reason field."""
    mapping = {
        "message_count": "auto",
        "token_count": "auto",
        "idle_session": "idle",
        "topic_shift": "topic_shift",
        "manual": "manual",
        "none": "manual",
    }
    return mapping.get(reason, "auto")  # type: ignore


def _reason_to_trigger_source(
    reason: str,
) -> Literal["topic_shift", "message_count", "token_count", "manual"]:
    """Map internal reason to trigger_source field."""
    mapping = {
        "message_count": "message_count",
        "token_count": "token_count",
        "topic_shift": "topic_shift",
        "manual": "manual",
        "none": "manual",
    }
    return mapping.get(reason, "manual")  # type: ignore


def check_snapshot_thresholds(
    db: Database,
    session_id: str,
    org_id: str,
    *,
    user_id: Optional[str] = None,
    config: Optional[SnapshotConfig] = None,
) -> Tuple[bool, str]:
    """
    Check if a session should be snapshotted based on current STM state.

    This is a read-only check that doesn't modify any data.

    Args:
        db: MongoDB database instance
        session_id: Session identifier
        org_id: Organization ID
        user_id: Optional user ID filter
        config: Optional snapshot configuration

    Returns:
        Tuple of (should_snapshot, reason)

    Example:
        >>> should, reason = check_snapshot_thresholds(db, session_id, org_id)
        >>> if should:
        ...     print(f"Should snapshot because: {reason}")
    """
    config = config or SnapshotConfig()

    stm_docs = get_stm_raw_docs(db, session_id, org_id, user_id=user_id)
    return should_promote(stm_docs, config)


# Note: Not called anywhere
def get_sessions_needing_snapshot(
    db: Database,
    org_id: str,
    *,
    config: Optional[SnapshotConfig] = None,
    stale_minutes: Optional[int] = None,
    limit: int = 100,
) -> List[str]:
    """
    Find sessions that need snapshotting based on message count or staleness.

    This is used by the worker for batch processing.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        config: Optional snapshot configuration
        stale_minutes: Override for stale session threshold
        limit: Maximum number of sessions to return

    Returns:
        List of session IDs that need snapshotting

    Note:
        This function uses aggregation to efficiently find sessions
        without loading all STM documents.
    """
    from mongomem_core.storage import get_collection
    from mongomem_core.storage.collections import ShortTermMemoryCollection

    config = config or SnapshotConfig()
    stale_threshold = stale_minutes or config.stale_minutes

    col = get_collection(ShortTermMemoryCollection(), db)

    # Find sessions with STM count >= max_messages
    pipeline: List[Dict[str, Any]] = [
        {"$match": {"org_id": org_id, "promoted": {"$ne": True}}},
        {
            "$group": {
                "_id": "$session_id",
                "count": {"$sum": 1},
                "last_timestamp": {"$max": "$timestamp"},
            }
        },
        {
            "$match": {
                "$or": [
                    {"count": {"$gte": config.max_messages or DEFAULT_MAX_MESSAGES}},
                    {"last_timestamp": {"$lt": utcnow() - timedelta(minutes=stale_threshold)}},
                ]
            }
        },
        {"$sort": {"last_timestamp": 1}},  # Oldest first
        {"$limit": limit},
    ]

    results = list(col.aggregate(pipeline))
    session_ids = [r["_id"] for r in results]

    logger.debug(
        "Found %d sessions needing snapshot for org=%s",
        len(session_ids),
        org_id,
    )

    return session_ids
