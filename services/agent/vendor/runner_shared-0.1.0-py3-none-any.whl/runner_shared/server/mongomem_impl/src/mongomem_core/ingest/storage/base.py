"""
Storage backend protocol for document ingestion.

Defines the interface for storage backends (local, GCS, S3, etc.)
that can resolve URIs to local paths for processing.
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import List, Set


class StorageBackend(ABC):
    """
    Abstract base class for storage backends.

    Storage backends resolve URIs to local file paths.
    For remote storage (GCS, S3), files are downloaded to temp locations.
    """

    @abstractmethod
    def supports(self, uri: str) -> bool:
        """
        Check if this backend supports the given URI.

        Args:
            uri: File path or URI (e.g., "/local/file.pdf", "gs://bucket/file.pdf")

        Returns:
            True if this backend can handle the URI
        """
        ...

    @abstractmethod
    def resolve(self, uri: str) -> Path:
        """
        Resolve URI to a local file path.

        For local files, returns the path directly.
        For remote files, downloads to a temp location and returns that path.

        Args:
            uri: File path or URI

        Returns:
            Local Path to the file

        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If URI is invalid
        """
        ...

    @abstractmethod
    def list_files(self, uri: str, extensions: Set[str]) -> List[str]:
        """
        List files in a directory/prefix matching given extensions.

        Args:
            uri: Directory path or URI prefix
            extensions: Set of extensions to match (e.g., {".pdf", ".txt"})

        Returns:
            List of URIs for matching files
        """
        ...

    @abstractmethod
    def cleanup(self, local_path: Path) -> None:
        """
        Cleanup a resolved file (remove temp files for remote storage).

        Args:
            local_path: Path returned by resolve()
        """
        ...

    def cleanup_all(self) -> None:
        """Cleanup all temp files created by this backend."""
        pass


def detect_backend(uri: str, backends: List[StorageBackend]) -> StorageBackend:
    """
    Detect the appropriate backend for a URI.

    Args:
        uri: File path or URI
        backends: List of available backends

    Returns:
        The first backend that supports the URI

    Raises:
        ValueError: If no backend supports the URI
    """
    for backend in backends:
        if backend.supports(uri):
            return backend

    raise ValueError(
        f"No storage backend supports URI: {uri}. "
        f"Available backends: {[type(b).__name__ for b in backends]}"
    )
