"""
Document ingestion pipeline.

Orchestrates extraction, chunking, and storage of documents into semantic memory.

Supports multiple storage backends:
- Local filesystem (default)
- Google Cloud Storage (gs:// URIs)
- S3 (s3:// URIs) - future
"""

import logging
import time
from pathlib import Path
from typing import Any, List, Optional, Union

from mongomem_core.ingest.chunkers.recursive import RecursiveChunker
from mongomem_core.ingest.extractors.docx import PythonDocxExtractor
from mongomem_core.ingest.extractors.pdf import PyMuPDFExtractor
from mongomem_core.ingest.extractors.pptx import PythonPPTXExtractor
from mongomem_core.ingest.extractors.text import PlainTextExtractor
from mongomem_core.ingest.models import (
    SUPPORTED_EXTENSIONS,
    ExtractorType,
    FileResult,
    IngestConfig,
    IngestResult,
    validate_file_extension,
)
from mongomem_core.ingest.storage import LocalStorage, StorageBackend
from mongomem_core.observability import CoreObservability

logger = logging.getLogger(__name__)


def _get_page_info(
    start_char: int,
    end_char: int,
    page_boundaries: list,
) -> dict:
    """
    Determine which page(s) a chunk belongs to based on character offsets.

    Args:
        start_char: Start character offset of the chunk
        end_char: End character offset of the chunk
        page_boundaries: List of (page_num, page_start, page_end) tuples

    Returns:
        Dict with page_start and page_end (may differ if chunk spans pages)
    """
    if not page_boundaries or start_char < 0:
        return {}

    page_start = None
    page_end = None

    for page_num, page_start_char, page_end_char in page_boundaries:
        # Check if chunk starts in this page
        if page_start is None and start_char < page_end_char:
            page_start = page_num

        # Check if chunk ends in this page
        if end_char <= page_end_char:
            page_end = page_num
            break

        # Chunk extends beyond this page
        page_end = page_num

    if page_start is not None:
        return {
            "page_start": page_start,
            "page_end": page_end or page_start,
        }

    return {}


# Extractor registry for simple extractor
_SIMPLE_EXTRACTORS = {
    ".txt": PlainTextExtractor,
    ".pdf": PyMuPDFExtractor,
    ".pptx": PythonPPTXExtractor,
    ".docx": PythonDocxExtractor,
}


def get_extractor_for_file(file_path: Path, extractor_type: ExtractorType):
    """
    Get the appropriate extractor for a file based on extension.

    Args:
        file_path: Path to the file
        extractor_type: Type of extractor to use

    Returns:
        Extractor instance

    Raises:
        ValueError: If file type is not supported
    """
    ext = file_path.suffix.lower()

    if extractor_type == ExtractorType.SIMPLE:
        extractor_class = _SIMPLE_EXTRACTORS.get(ext)
        if extractor_class is None:
            supported = ", ".join(sorted(_SIMPLE_EXTRACTORS.keys()))
            raise ValueError(
                f"Unsupported file type: {ext}. "
                f"Supported extensions: {supported}. "
                f"For .doc files, please convert to .docx or use extractor='docling'."
            )
        return extractor_class()

    elif extractor_type == ExtractorType.DOCLING:
        raise NotImplementedError(
            "Docling extractor is not yet implemented. Please use extractor='simple' for now."
        )

    raise ValueError(f"Unknown extractor type: {extractor_type}")


def ingest_documents(
    engine: Any,  # MemoryEngine - uses Any to avoid circular import issues
    paths: List[Union[str, Path]],
    org_id: str,
    user_id: str,
    *,
    config: Optional[IngestConfig] = None,
    visibility: str = "org",
    project_id: Optional[str] = None,
    generate_embeddings: bool = True,
    storage_backend: Optional[StorageBackend] = None,
    obs: Optional[CoreObservability] = None,
) -> IngestResult:
    """
    Ingest documents into semantic memory.

    Extracts text from files, chunks it, and stores as semantic memories
    using bulk_create_semantic().

    Supports multiple storage backends:
    - Local filesystem (default): "/path/to/file.pdf"
    - Google Cloud Storage: "gs://bucket/path/file.pdf"
    - Directories: "gs://bucket/docs/" or "/local/dir/" (processes all supported files)

    Args:
        engine: MemoryEngine instance with embedder attached
        paths: List of file paths or URIs to ingest
        org_id: Organization ID for the memories
        user_id: User ID of the creator
        config: Optional ingestion configuration
        visibility: Visibility for created memories ("private", "shared", "org")
        project_id: Optional group ID for shared visibility
        generate_embeddings: Whether to generate embeddings synchronously
        storage_backend: Optional storage backend (defaults to LocalStorage)
            Use GCSStorage for gs:// URIs
        obs: Optional CoreObservability for observability (metrics/spans/events).
            If not provided, a NoOp instance is used.

    Returns:
        IngestResult with processing details

    Example:
        # Local files
        result = ingest_documents(
            engine=engine,
            paths=["docs/report.pdf", "notes.txt"],
            org_id="my-org",
            user_id="sakshi",
        )

        # GCS files
        from mongomem_core.ingest.storage import GCSStorage
        result = ingest_documents(
            engine=engine,
            paths=["gs://my-bucket/docs/report.pdf"],
            org_id="my-org",
            user_id="sakshi",
            storage_backend=GCSStorage(),
        )

        print(f"Created {result.total_chunks} chunks from {result.files_succeeded} files")
    """
    config = config or IngestConfig()
    chunker = RecursiveChunker(config.chunk_config)
    backend = storage_backend or LocalStorage()
    obs = obs or CoreObservability()

    with obs.span_ingest() as span:
        return _ingest_documents_internal(
            engine=engine,
            paths=paths,
            org_id=org_id,
            user_id=user_id,
            config=config,
            visibility=visibility,
            project_id=project_id,
            generate_embeddings=generate_embeddings,
            chunker=chunker,
            backend=backend,
            obs=obs,
            span=span,
        )


def _ingest_documents_internal(
    engine: Any,
    paths: List[Union[str, Path]],
    org_id: str,
    user_id: str,
    config: IngestConfig,
    visibility: str,
    project_id: Optional[str],
    generate_embeddings: bool,
    chunker: RecursiveChunker,
    backend: StorageBackend,
    obs: CoreObservability,
    span: dict,
) -> IngestResult:
    """Internal implementation of ingest_documents with span context."""
    start_time = time.perf_counter()

    file_results: List[FileResult] = []
    all_items: List[dict] = []

    # Expand directories to individual files
    resolved_paths: List[str] = []
    for path_or_uri in paths:
        uri = str(path_or_uri)

        # Check if this is a directory/prefix (ends with /)
        if uri.endswith("/"):
            # List files in directory
            try:
                files = backend.list_files(uri, SUPPORTED_EXTENSIONS)
                resolved_paths.extend(files)
                logger.info(f"Found {len(files)} files in {uri}")
            except Exception as e:
                logger.warning(f"Failed to list files in {uri}: {e}")
                file_results.append(FileResult(path=uri, success=False, error=str(e)))
                if config.on_failure == "raise":
                    raise
        else:
            resolved_paths.append(uri)

    try:
        for uri in resolved_paths:
            # Resolve URI to local path (downloads if remote)
            try:
                if backend.supports(uri):
                    local_path = backend.resolve(uri)
                    is_remote = True
                else:
                    local_path = Path(uri)
                    is_remote = False
            except FileNotFoundError as e:
                logger.warning(f"File not found: {uri}")
                file_results.append(FileResult(path=uri, success=False, error=str(e)))
                if config.on_failure == "raise":
                    raise
                continue
            except Exception as e:
                logger.warning(f"Failed to resolve {uri}: {e}")
                file_results.append(FileResult(path=uri, success=False, error=str(e)))
                if config.on_failure == "raise":
                    raise
                continue

            # Use original URI for display, local path for processing
            display_path = uri
            path = local_path

            # Validate file extension first
            validation_error = validate_file_extension(str(path), config.extractor)
            if validation_error:
                logger.warning(f"Skipping {display_path}: {validation_error}")
                file_results.append(
                    FileResult(
                        path=display_path,
                        success=False,
                        error=validation_error,
                    )
                )
                if is_remote:
                    backend.cleanup(local_path)
                if config.on_failure == "raise":
                    raise ValueError(validation_error)
                continue

            # Check file exists (for local files not already resolved)
            if not path.exists():
                error_msg = f"File not found: {display_path}"
                logger.warning(error_msg)
                file_results.append(
                    FileResult(
                        path=display_path,
                        success=False,
                        error=error_msg,
                    )
                )
                if config.on_failure == "raise":
                    raise FileNotFoundError(error_msg)
                continue

            # Try extraction with retries
            for attempt in range(config.max_retries + 1):
                try:
                    # Extract text and metadata
                    extractor = get_extractor_for_file(path, config.extractor)
                    result = extractor.extract_with_metadata(path)
                    text = result["text"]
                    file_metadata = result["metadata"]
                    # Page boundaries for PDFs: [(page_num, start_char, end_char), ...]
                    page_boundaries = result.get("page_boundaries", [])

                    if not text or not text.strip():
                        logger.warning(f"No text extracted from {display_path}")
                        file_results.append(
                            FileResult(
                                path=display_path,
                                success=True,
                                chunks_created=0,
                            )
                        )
                        break

                    # Chunk text with offset tracking
                    chunks_with_offsets = chunker.chunk_with_offsets(text)

                    if not chunks_with_offsets:
                        logger.warning(f"No chunks created from {display_path} (text too short?)")
                        file_results.append(
                            FileResult(
                                path=display_path,
                                success=True,
                                chunks_created=0,
                            )
                        )
                        break

                    # Build items for bulk insert
                    for chunk_idx, chunk_obj in enumerate(chunks_with_offsets):
                        # Generate unique label: filename-chunk-index
                        label = f"{path.stem}-chunk-{chunk_idx:04d}"

                        # Determine page number(s) for this chunk based on character offsets
                        page_info = _get_page_info(
                            chunk_obj.start_char,
                            chunk_obj.end_char,
                            page_boundaries,
                        )

                        all_items.append(
                            {
                                "label": label,
                                "content": chunk_obj.text,
                                "source": Path(display_path).name,  # File name as source
                                "contextual_metadata": {  # Stored in SemanticDB.contextual_metadata
                                    **config.default_metadata,
                                    **file_metadata,
                                    "source_file": Path(display_path).name,
                                    "source_path": display_path,  # Original URI for remote files
                                    "chunk_index": chunk_idx,
                                    "total_chunks": len(chunks_with_offsets),
                                    "start_char": chunk_obj.start_char,
                                    "end_char": chunk_obj.end_char,
                                    **page_info,  # page_start, page_end (for PDFs)
                                },
                            }
                        )

                    file_results.append(
                        FileResult(
                            path=display_path,
                            success=True,
                            chunks_created=len(chunks_with_offsets),
                        )
                    )
                    logger.info(f"Extracted {len(chunks_with_offsets)} chunks from {display_path}")
                    break  # Success, no retry needed

                except Exception as e:
                    if attempt == config.max_retries:
                        error_msg = (
                            f"Failed to process after {config.max_retries + 1} attempts: {e}"
                        )
                        logger.error(f"Failed to process {display_path}: {e}")
                        file_results.append(
                            FileResult(
                                path=display_path,
                                success=False,
                                error=str(e),
                            )
                        )
                        if config.on_failure == "raise":
                            raise
                    else:
                        logger.warning(
                            f"Retry {attempt + 1}/{config.max_retries + 1} for {display_path}: {e}"
                        )

            # Cleanup temp files for remote storage
            if is_remote:
                backend.cleanup(local_path)

    finally:
        # Ensure all temp files are cleaned up on error
        backend.cleanup_all()

    # Bulk insert all chunks
    chunk_ids: List[str] = []
    if all_items:
        try:
            bulk_result = engine.bulk_create_semantic(
                items=all_items,
                org_id=org_id,
                user_id=user_id,
                visibility=visibility,
                project_id=project_id,
                generate_embeddings=generate_embeddings,
                skip_duplicates=True,
            )
            chunk_ids = bulk_result.created_ids
            logger.info(
                f"Bulk inserted {bulk_result.created_count} chunks "
                f"(skipped {bulk_result.skipped_count} duplicates)"
            )
        except Exception as e:
            logger.error(f"Failed to bulk insert chunks: {e}")
            if config.on_failure == "raise":
                raise

    # Calculate result counts
    files_succeeded = sum(1 for r in file_results if r.success)
    files_failed = sum(1 for r in file_results if not r.success)

    duration_ms = (time.perf_counter() - start_time) * 1000

    for result in file_results:
        file_type = Path(result.path).suffix.lower() or "unknown"
        if result.success:
            obs.ingest_file_processed(file_type)
        else:
            # Categorize error type based on error message
            error_type = "unknown"
            if result.error:
                if "not found" in result.error.lower():
                    error_type = "not_found"
                elif "not supported" in result.error.lower():
                    error_type = "unsupported"
                elif "failed to process" in result.error.lower():
                    error_type = "extraction_error"
            obs.ingest_file_failed(
                file_type=file_type,
                error_type=error_type,
                file_path=result.path,
                error_message=result.error,
            )

    if chunk_ids:
        obs.ingest_chunks_created(len(chunk_ids))

    obs.ingest_completed(duration_ms)

    # Update span attributes
    span["duration_ms"] = duration_ms
    span["files_processed"] = files_succeeded
    span["files_failed"] = files_failed
    span["chunks_created"] = len(chunk_ids)

    return IngestResult(
        files_processed=len(resolved_paths),
        files_succeeded=files_succeeded,
        files_failed=files_failed,
        total_chunks=len(chunk_ids),
        file_results=file_results,
        chunk_ids=chunk_ids,
    )
