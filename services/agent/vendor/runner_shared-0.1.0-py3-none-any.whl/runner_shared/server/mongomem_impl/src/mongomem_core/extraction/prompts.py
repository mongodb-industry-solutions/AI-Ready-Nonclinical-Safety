"""
Default extraction prompts for mongomem_core.

These prompts can be used standalone (headless) or overridden via configuration.
They are designed to be framework-agnostic and suitable for any LLM provider.

For production use, these prompts should be customized based on:
- The specific LLM being used (GPT-4, Claude, etc.)
- The domain/use case
- Required output format

Usage:
    from mongomem_core.extraction.prompts import SEMANTIC_EXTRACTION_PROMPT

    result = llm.complete(SEMANTIC_EXTRACTION_PROMPT.format(content=conversation))
"""

from __future__ import annotations

from typing import Dict, Literal

ExtractionType = Literal["taxonomic", "episodic", "semantic", "preferences", "procedural"]

# =============================================================================
# Taxonomic Extraction
# =============================================================================

TAXONOMIC_EXTRACTION_PROMPT = """Analyze the following content and extract domain-specific terminology.

Content:
{content}

Extract any domain-specific terms, concepts, or technical vocabulary with their definitions.
For each term, include:
- domain: The knowledge domain (e.g., programming, machine_learning, devops)
- term: The term or concept name
- definition: Clear, standalone definition of the term
- related_terms: Related terms for semantic linking
- evidence_spans: Source evidence with start/end positions and message_idx
- confidence_score: 0.0-1.0 confidence in the extraction

Return as JSON:
{{
    "terms": [
        {{
            "domain": "...",
            "term": "...",
            "definition": "...",
            "related_terms": ["...", "..."],
            "evidence_spans": [{{"start": 0, "end": 10, "message_idx": 0, "text": "..."}}],
            "confidence_score": 0.85
        }}
    ]
}}

If no domain-specific terminology is present, return {{"terms": []}}
"""

# =============================================================================
# Episodic Extraction
# =============================================================================

EPISODIC_EXTRACTION_PROMPT = """Analyze the following content and extract episodic information.

Content:
{content}

Extract any events, actions, or experiences mentioned:
- event: Description of what happened
- participants: Who was involved
- timestamp_hint: Any time references mentioned
- outcome: Result or consequence if mentioned

Return as JSON:
{{"event": "...", "participants": ["..."], "timestamp_hint": "...", "outcome": "..."}}
"""

# =============================================================================
# Semantic Extraction
# =============================================================================

SEMANTIC_EXTRACTION_PROMPT = """Analyze the following content and extract semantic facts.

Content:
{content}

Extract factual knowledge that could be useful to remember:
- facts: List of facts or knowledge items
- confidence: How certain is this fact (0.0-1.0)

Return as JSON:
{{"facts": [{{"statement": "...", "confidence": 0.9}}]}}
"""

# =============================================================================
# Preferences Extraction
# =============================================================================

PREFERENCES_EXTRACTION_PROMPT = """Analyze the following conversation and extract user communication preferences.

Conversation:
{content}

Extract any preferences about how the user wants to communicate:
- tone: preferred tone (formal, casual, professional, friendly, technical)
- style: preferred style (concise, detailed, step_by_step, conversational)
- expertise_level: user's level (beginner, intermediate, advanced, expert)
- preferred_format: format preference (bullet_points, paragraphs, code_heavy)
- language: preferred language (en, es, fr, etc.)
- custom_instructions: any specific requests

Return as JSON with only fields that have evidence:
{{"preferences": {{"tone": "...", "confidence": 0.8}}}}
"""

# =============================================================================
# Procedural Extraction
# =============================================================================

PROCEDURAL_EXTRACTION_PROMPT = """Analyze the following conversation and extract reusable procedures.

Conversation:
{content}

Extract step-by-step procedures (skills/workflows) that were demonstrated or discussed.
For each procedure, include:
- procedure: Unique kebab-case name for the procedure
- description: What this procedure does and when to use it
- content: Full instruction body as markdown
- steps: Optional list of structured steps (each with instruction, optional code, validation)
- tags: Relevant tags for categorization
- citations: Message indices where the procedure was discussed
- confidence_score: 0.0-1.0 confidence in the extraction

Return as JSON:
{{
    "procedures": [
        {{
            "procedure": "deploy-to-staging",
            "description": "Steps to deploy a service to staging environment",
            "content": "## Deploy to Staging\\n1. Run tests...",
            "steps": [{{"instruction": "Run tests", "step_type": "instruction"}}],
            "tags": ["deployment", "staging"],
            "citations": [0, 1],
            "confidence_score": 0.85
        }}
    ]
}}

If no procedures are present, return {{"procedures": []}}
"""

# =============================================================================
# Consolidated Access
# =============================================================================

DEFAULT_EXTRACTION_PROMPTS: Dict[ExtractionType, str] = {
    "taxonomic": TAXONOMIC_EXTRACTION_PROMPT,
    "episodic": EPISODIC_EXTRACTION_PROMPT,
    "semantic": SEMANTIC_EXTRACTION_PROMPT,
    "preferences": PREFERENCES_EXTRACTION_PROMPT,
    "procedural": PROCEDURAL_EXTRACTION_PROMPT,
}


def get_extraction_prompt(
    extraction_type: ExtractionType,
    custom_prompt: str | None = None,
) -> str:
    """
    Get the extraction prompt for the given type.

    Args:
        extraction_type: Type of extraction (taxonomic, episodic, semantic)
        custom_prompt: Optional custom prompt to use instead of default

    Returns:
        The prompt string to use for extraction
    """
    if custom_prompt:
        return custom_prompt
    return DEFAULT_EXTRACTION_PROMPTS.get(extraction_type, "")


__all__ = [
    "ExtractionType",
    "TAXONOMIC_EXTRACTION_PROMPT",
    "EPISODIC_EXTRACTION_PROMPT",
    "SEMANTIC_EXTRACTION_PROMPT",
    "PREFERENCES_EXTRACTION_PROMPT",
    "PROCEDURAL_EXTRACTION_PROMPT",
    "DEFAULT_EXTRACTION_PROMPTS",
    "get_extraction_prompt",
]
