"""
Models for episodic memory documents.

Episodic memory stores extracted summaries and learnings from conversation
snapshots. Each document represents a distinct episode or event with its
context, participants, and semantic content.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Literal, Optional

from bson import ObjectId
from mongomem_core.common.utils import utcnow
from mongomem_core.models.memory.base import BaseMemoryIn, ChunkVisibility, HasEmbeddings
from mongomem_core.models.memory.publishing import PublishingMetadata
from mongomem_core.models.types import PyObjectId
from pydantic import BaseModel, Field, field_serializer


class EpisodicIn(BaseMemoryIn, HasEmbeddings):
    """
    Input model for creating an episodic memory entry.

    Episodic memories capture summaries of conversation snapshots,
    including title, participants, and extracted content.

    For extractions from snapshots, session_id and snapshot_ref_id link
    to the source. For manual user entries, these can be omitted.
    """

    publishing: Optional[PublishingMetadata] = Field(default_factory=PublishingMetadata)

    # Session and reference fields (optional for manual entries)
    session_id: Optional[str] = Field(
        default=None,
        description="Session ID this episode originated from (required for extractions)",
    )
    title: str = Field(..., description="Title or label for this episode")
    snapshot_ref_id: Optional[str] = Field(
        default=None,
        description="Reference to the source snapshot (required for extractions, None for manual)",
    )

    # Content fields
    content: str = Field(default="", description="Full episodic content")
    summary_text: str = Field(default="", description="Summarized text of the episode")
    summary_type: Literal["heuristic", "llm", "manual"] = Field(
        default="llm", description="Method used to generate the summary"
    )
    source_agent: str = Field(default="user", description="Agent/model that created this episode")
    participants: List[str] = Field(
        default_factory=list, description="List of participant IDs in this episode"
    )
    tags: List[str] = Field(default_factory=list, description="Tags for categorization and search")

    # Embedding model tracking
    summary_embedding_model_id: Optional[str] = Field(
        default=None,
        description="Model identifier used to generate the summary embedding",
    )
    summary_embedding_dimension: Optional[int] = Field(
        default=None,
        description="Dimension of the summary embedding vector",
    )

    # Agent attribution fields for collective intelligence
    agent_id: Optional[str] = Field(
        default=None,
        description="Agent ID if this knowledge was extracted via agent-mediated learning",
    )
    extraction_source: Optional[str] = Field(
        default=None,
        description="Source of extraction: 'user_direct', 'agent_mediated', 'agent_collective'",
    )
    collective_metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Metadata for collective intelligence: contributing_users, confidence, patterns",
    )

    model_config = {"populate_by_name": True, "use_enum_values": True}


class EpisodicUpdate(BaseModel):
    """Model for partial updates to episodic memory."""

    visibility: Optional[ChunkVisibility] = None
    project_id: Optional[str] = None
    publishing: Optional[PublishingMetadata] = None

    # Content fields
    title: Optional[str] = None
    content: Optional[str] = None
    summary_text: Optional[str] = None
    summary_type: Optional[Literal["heuristic", "llm", "manual"]] = None
    source_agent: Optional[str] = None
    participants: Optional[List[str]] = None
    tags: Optional[List[str]] = None

    # Embedding fields
    embedding: Optional[List[float]] = None
    summary_embedding_model_id: Optional[str] = None
    summary_embedding_dimension: Optional[int] = None

    # Agent attribution fields for updates
    agent_id: Optional[str] = Field(
        default=None,
        description="Agent ID if this knowledge was extracted via agent-mediated learning",
    )
    extraction_source: Optional[str] = Field(
        default=None,
        description="Source of extraction: 'user_direct', 'agent_mediated', 'agent_collective'",
    )
    collective_metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Metadata for collective intelligence: contributing_users, confidence, patterns",
    )

    metadata: Optional[Dict[str, Any]] = None


class EpisodicBase(EpisodicIn):
    """Base model with org/user context and extraction metadata.

    Includes org_id, user_id, timestamp, and extraction metadata
    which are typically set by the service layer.
    """

    org_id: str = Field(..., description="Organization/tenant ID")
    user_id: str = Field(..., description="User ID who owns this episode")
    timestamp: datetime = Field(default_factory=utcnow)

    # Extraction metadata for dual storage and cohort routing
    extraction_id: Optional[str] = Field(
        default=None,
        pattern="^[a-f0-9]{64}$",
        description="SHA-256 hash for idempotent extraction writes",
    )
    extraction_scope: Optional[Literal["user_private", "agent_shared", "org_wide"]] = Field(
        default=None,
        description="Scope of extraction: user_private, agent_shared (cohort), or org_wide",
    )
    contributed_by: Optional[str] = Field(
        default=None,
        description="User ID who contributed this extraction (for cohort analytics)",
    )
    owner_id: Optional[str] = Field(
        default=None,
        description="User ID with permanent access rights to this extraction",
    )
    deleted: bool = Field(
        default=False,
        description="Soft-delete flag for auditability",
    )
    deleted_at: Optional[datetime] = Field(
        default=None,
        description="Timestamp of soft deletion",
    )
    idempotency_key_in: Optional[str] = Field(
        default=None,
        description="Original idempotency key for debugging",
    )

    model_config = {
        "arbitrary_types_allowed": True,
        "from_attributes": True,
        "populate_by_name": True,
        "use_enum_values": True,
    }


class EpisodicDB(EpisodicBase):
    """Database model with MongoDB _id."""

    id: PyObjectId = Field(default_factory=PyObjectId, alias="_id")

    @field_serializer("id", when_used="json")
    def _serialize_id(self, v: ObjectId) -> str:
        return str(v)


class EpisodicOut(EpisodicBase):
    """Output model for API responses."""

    id: str = Field(..., alias="_id")

    # Transient field from MongoDB $vectorSearch (not persisted to DB)
    score: Optional[float] = Field(
        default=None,
        description="Vector search similarity score from MongoDB Atlas (query-specific, not stored)",
        exclude=True,
    )
