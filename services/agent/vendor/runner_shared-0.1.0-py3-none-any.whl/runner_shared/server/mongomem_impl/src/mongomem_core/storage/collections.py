"""
Collection descriptors for ``mongomem_core``.

This module defines a small type system around MongoDB collections used by the
headless memory engine.  It is intentionally light on behavior for now – the
goal is to provide a **structured place** where:

* Each logical collection is represented by a descriptor class.
* Collection *names* live in one place (and are not hard‑coded throughout
  the codebase).
* Future helpers (typed accessors, ensure/initialisation logic, etc.) can be
  added without changing call‑sites.

The design is informed by the existing ExoMemory app constants in
``app.db.connection`` (e.g. ``MEMORY_SHORT_TERM_COL``, ``ENTITIES_COL``),
with a deliberate scope choice:

* Collections that are part of the **engine data model** (memories, TKG,
  pooled memory cohorts, engine‑level settings/config that affect memory
  behaviour) are modelled here.
* **Auth / security** collections (API keys, users, RBAC, rate limits, etc.)
  are intentionally **not** represented here.
* **Worker / task‑queue** collections (task queues, worker state, change
  streams, Celery kill switches, scheduled tasks, etc.) belong in
  ``mongomem_worker`` rather than the core engine.

No I/O logic should live here – just descriptors and light helpers.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import ClassVar, Iterable, Mapping

from pymongo.synchronous.collection import Collection
from pymongo.synchronous.database import Database


@dataclass(frozen=True)
class BaseCollectionDescriptor:
    """
    Minimal descriptor for a MongoDB collection.

    For now this only encapsulates the **logical name** of the collection and
    provides a typed accessor. Index creation / validation is handled in
    ``indexes.py``.
    """

    #: Canonical collection name in MongoDB.
    name: ClassVar[str]

    def get(self, db: Database) -> Collection:
        """Return the underlying ``Collection`` from a ``Database``."""

        return db[self.name]


# ---------------------------------------------------------------------------
# Memory collections
# ---------------------------------------------------------------------------


class ShortTermMemoryCollection(BaseCollectionDescriptor):
    """
    Short‑term memory documents.

    Mirrors ``MEMORY_SHORT_TERM_COL = "memory_short_term"`` in the legacy app.
    """

    name: ClassVar[str] = "memory_short_term"


class SemanticMemoryCollection(BaseCollectionDescriptor):
    """Long‑lived semantic memory."""

    name: ClassVar[str] = "memory_semantic"


class EpisodicMemoryCollection(BaseCollectionDescriptor):
    """Episodic memories capturing events / timelines."""

    name: ClassVar[str] = "memory_episodic"


class SnapshotMemoryCollection(BaseCollectionDescriptor):
    """Snapshot memories (aggregated from STM / episodic)."""

    name: ClassVar[str] = "memory_snapshot"


class TaxonomicMemoryCollection(BaseCollectionDescriptor):
    """Taxonomic / hierarchical memories."""

    name: ClassVar[str] = "memory_taxonomic"


class ProceduralMemoryCollection(BaseCollectionDescriptor):
    """Procedural / skills style memories."""

    name: ClassVar[str] = "memory_procedural"


class MemoryUserContextCollection(BaseCollectionDescriptor):
    """Per‑user context / profile state."""

    name: ClassVar[str] = "memory_user_context"


class MemorySessionsCollection(BaseCollectionDescriptor):
    """Conversation / session tracking for memory interactions."""

    name: ClassVar[str] = "memory_sessions"


class PersonaMemoryCollection(BaseCollectionDescriptor):
    """Per-user persona configurations stored as memory."""

    name: ClassVar[str] = "memory_persona"


class MemoryPooledRegistryCollection(BaseCollectionDescriptor):
    """
    Registry of pooled / cohort memories.

    Mirrors ``MEMORY_POOLED_REGISTRY_COL = "memory_pooled_registry"``.
    """

    name: ClassVar[str] = "memory_pooled_registry"


# ---------------------------------------------------------------------------
# Entity / TKG collections
# ---------------------------------------------------------------------------


class EntitiesCollection(BaseCollectionDescriptor):
    """Core entities in the Temporal Knowledge Graph."""

    name: ClassVar[str] = "entities"


class EntityProfilesCollection(BaseCollectionDescriptor):
    """Materialised entity profiles."""

    name: ClassVar[str] = "entity_profiles"


class EntityEdgesCollection(BaseCollectionDescriptor):
    """Edges/relations between entities (TKG edges)."""

    name: ClassVar[str] = "entity_edges"


class FactsCollection(BaseCollectionDescriptor):
    """Atomic facts linked to entities / memories."""

    name: ClassVar[str] = "facts"


class FactsArchiveCollection(BaseCollectionDescriptor):
    """Archived / compacted facts."""

    name: ClassVar[str] = "facts_archive"


class EntitySearchCollection(BaseCollectionDescriptor):
    """Search‑optimised view/index for entities."""

    name: ClassVar[str] = "entity_search"


# ---------------------------------------------------------------------------
# Engine-level configuration / control collections
# ---------------------------------------------------------------------------


class SessionCountersCollection(BaseCollectionDescriptor):
    """Per-session counters for atomic turn sequence generation."""

    name: ClassVar[str] = "session_counters"


class InternalStateCollection(BaseCollectionDescriptor):
    """
    Internal Working Memory state per session.

    Stores the agent's self-authored belief state that is overwritten each turn.
    One document per (org_id, session_id).
    """

    name: ClassVar[str] = "internal_state"


# ---------------------------------------------------------------------------
# Extraction approval collections
# ---------------------------------------------------------------------------


class ExtractionPendingCollection(BaseCollectionDescriptor):
    """
    Pending extractions awaiting approval.

    Stores staged extraction decisions for manual review before persistence
    to memory collections. Supports TTL-based expiration via expires_at field.
    """

    name: ClassVar[str] = "extraction_pending"


# ---------------------------------------------------------------------------
# Registry of core engine collections
# ---------------------------------------------------------------------------


#: All collections that are part of the headless **engine** data model.
ENGINE_COLLECTIONS: Mapping[str, BaseCollectionDescriptor] = {
    desc.name: desc
    for desc in [
        # Core memory types
        ShortTermMemoryCollection(),
        SemanticMemoryCollection(),
        EpisodicMemoryCollection(),
        SnapshotMemoryCollection(),
        TaxonomicMemoryCollection(),
        ProceduralMemoryCollection(),
        MemoryUserContextCollection(),
        MemorySessionsCollection(),
        PersonaMemoryCollection(),
        MemoryPooledRegistryCollection(),
        # Entity / TKG
        EntitiesCollection(),
        EntityProfilesCollection(),
        EntityEdgesCollection(),
        FactsCollection(),
        FactsArchiveCollection(),
        EntitySearchCollection(),
        # Engine-level control
        SessionCountersCollection(),
        # Internal Working Memory
        InternalStateCollection(),
        # Extraction approval
        ExtractionPendingCollection(),
    ]
}


def iter_engine_collections() -> Iterable[BaseCollectionDescriptor]:
    """
    Iterate over all engine collections.

    This helper is intended for use by startup / migration routines that need to
    ensure collections and indexes exist.  It deliberately does **not** perform
    any I/O by itself.
    """

    return ENGINE_COLLECTIONS.values()
