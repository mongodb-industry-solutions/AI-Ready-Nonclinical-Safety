from __future__ import annotations

from enum import Enum
from typing import Any, Optional

from ...mongomem_core.exceptions import MongoMemError


class WorkerErrorSeverity(str, Enum):
    """Determines retry behavior."""

    PERMANENT = "permanent"  # Don't retry - bad config, validation, etc.
    TRANSIENT = "transient"  # Retry - network, rate limit, timeout
    UNKNOWN = "unknown"  # Retry with caution


class WorkerError(MongoMemError):
    """
    Base exception for all worker errors.

    Extends core's MongoMemError with worker-specific context:
    - severity: Controls retry behavior
    - task_type: Which handler failed
    - task_id: Which task failed
    """

    severity: WorkerErrorSeverity = WorkerErrorSeverity.UNKNOWN

    def __init__(
        self,
        message: str,
        *,
        task_type: Optional[str] = None,
        task_id: Optional[str] = None,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        extra_details = details or {}
        if task_type:
            extra_details["task_type"] = task_type
        if task_id:
            extra_details["task_id"] = task_id
        super().__init__(message, details=extra_details)
        self.task_type = task_type
        self.task_id = task_id


# Permanent Errors (don't retry)


class ConfigurationError(WorkerError):
    """Worker configuration is invalid."""

    severity = WorkerErrorSeverity.PERMANENT


class EmbedderConfigError(ConfigurationError):
    """Embedder doesn't implement required protocol or dimension mismatch."""

    pass


class HandlerNotFoundError(WorkerError):
    """No handler registered for task type."""

    severity = WorkerErrorSeverity.PERMANENT


class InvalidPayloadError(WorkerError):
    """Task payload is malformed or missing required fields."""

    severity = WorkerErrorSeverity.PERMANENT


class DocumentMissingError(WorkerError):
    """Referenced document doesn't exist."""

    severity = WorkerErrorSeverity.PERMANENT

    def __init__(
        self,
        message: str,
        *,
        collection: Optional[str] = None,
        document_id: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.pop("details", {}) or {}
        if collection:
            details["collection"] = collection
        if document_id:
            details["document_id"] = document_id
        super().__init__(message, details=details, **kwargs)


# Transient Errors (retry with backoff)


class TransientWorkerError(WorkerError):
    """Base for all retryable errors."""

    severity = WorkerErrorSeverity.TRANSIENT


class EmbeddingError(TransientWorkerError):
    """Embedding generation failed (API error, rate limit, etc.)."""

    def __init__(
        self,
        message: str,
        *,
        model_id: Optional[str] = None,
        original_error: Optional[Exception] = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.pop("details", {}) or {}
        if model_id:
            details["model_id"] = model_id
        if original_error:
            details["original_error"] = str(original_error)
            details["original_error_type"] = type(original_error).__name__
        super().__init__(message, details=details, **kwargs)
        self.original_error = original_error


class LLMError(TransientWorkerError):
    """LLM completion failed (API error, rate limit, etc.)."""

    def __init__(
        self,
        message: str,
        *,
        model_id: Optional[str] = None,
        original_error: Optional[Exception] = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.pop("details", {}) or {}
        if model_id:
            details["model_id"] = model_id
        if original_error:
            details["original_error"] = str(original_error)
            details["original_error_type"] = type(original_error).__name__
        super().__init__(message, details=details, **kwargs)
        self.original_error = original_error


class RateLimitError(TransientWorkerError):
    """API rate limit exceeded."""

    def __init__(
        self,
        message: str,
        *,
        retry_after: Optional[float] = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.pop("details", {}) or {}
        if retry_after:
            details["retry_after"] = retry_after
        super().__init__(message, details=details, **kwargs)
        self.retry_after = retry_after


class TimeoutError(TransientWorkerError):
    """Operation timed out."""

    def __init__(
        self,
        message: str,
        *,
        timeout_seconds: Optional[float] = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.pop("details", {}) or {}
        if timeout_seconds:
            details["timeout_seconds"] = timeout_seconds
        super().__init__(message, details=details, **kwargs)


class DatabaseError(TransientWorkerError):
    """Database operation failed (connection, write concern, etc.)."""

    def __init__(
        self,
        message: str,
        *,
        operation: Optional[str] = None,
        collection: Optional[str] = None,
        original_error: Optional[Exception] = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.pop("details", {}) or {}
        if operation:
            details["operation"] = operation
        if collection:
            details["collection"] = collection
        if original_error:
            details["original_error"] = str(original_error)
            details["original_error_type"] = type(original_error).__name__
        super().__init__(message, details=details, **kwargs)
        self.original_error = original_error


class LeaseExpiredError(TransientWorkerError):
    """Task lease expired before completion (another worker may claim it)."""

    pass


# Utilities


def classify_exception(exc: Exception) -> WorkerErrorSeverity:
    """
    Classify any exception into a severity level for retry decisions.

    Uses exception type when possible, falls back to string matching.
    """
    # Our typed exceptions
    if isinstance(exc, WorkerError):
        return exc.severity

    # Core exceptions
    from ...mongomem_core.exceptions import (
        DocumentNotFoundError,
        DuplicateDocumentError,
        ValidationError,
    )

    if isinstance(exc, (ValidationError, DocumentNotFoundError, DuplicateDocumentError)):
        return WorkerErrorSeverity.PERMANENT

    # Common Python exceptions
    if isinstance(exc, (TypeError, ValueError, KeyError, AttributeError)):
        return WorkerErrorSeverity.PERMANENT

    # Timeout exceptions
    import asyncio

    if isinstance(exc, (asyncio.TimeoutError, TimeoutError)):
        return WorkerErrorSeverity.TRANSIENT

    # Connection exceptions
    if isinstance(exc, (ConnectionError, OSError)):
        return WorkerErrorSeverity.TRANSIENT

    # PyMongo exceptions
    try:
        from pymongo.errors import (
            AutoReconnect,
            ConnectionFailure,
            DuplicateKeyError,
            NetworkTimeout,
            OperationFailure,
        )

        if isinstance(exc, DuplicateKeyError):
            return WorkerErrorSeverity.PERMANENT
        if isinstance(exc, (ConnectionFailure, AutoReconnect, NetworkTimeout)):
            return WorkerErrorSeverity.TRANSIENT
        if isinstance(exc, OperationFailure):
            # Check error code for specific cases
            return WorkerErrorSeverity.TRANSIENT
    except ImportError:
        pass

    # Fall back to string matching for unknown exceptions
    error_str = str(exc).lower()

    permanent_patterns = ["validation", "invalid", "not found", "permission", "unauthorized"]
    for pattern in permanent_patterns:
        if pattern in error_str:
            return WorkerErrorSeverity.PERMANENT

    transient_patterns = ["timeout", "rate limit", "connection", "network", "unavailable"]
    for pattern in transient_patterns:
        if pattern in error_str:
            return WorkerErrorSeverity.TRANSIENT

    return WorkerErrorSeverity.UNKNOWN


def wrap_handler_error(
    exc: Exception,
    *,
    task_type: str,
    task_id: Optional[str] = None,
    context: Optional[str] = None,
) -> WorkerError:
    """
    Wrap any exception in an appropriate WorkerError.

    Use this in handlers to provide consistent error context.
    """
    # Already a WorkerError - add task context if missing
    if isinstance(exc, WorkerError):
        if not exc.task_type:
            exc.task_type = task_type
        if not exc.task_id and task_id:
            exc.task_id = task_id
        return exc

    severity = classify_exception(exc)
    message = f"{context}: {exc}" if context else str(exc)

    if severity == WorkerErrorSeverity.PERMANENT:
        return InvalidPayloadError(
            message,
            task_type=task_type,
            task_id=task_id,
            details={"original_error": str(exc), "original_type": type(exc).__name__},
        )
    else:
        return TransientWorkerError(
            message,
            task_type=task_type,
            task_id=task_id,
            details={"original_error": str(exc), "original_type": type(exc).__name__},
        )


__all__ = [
    # Base
    "WorkerError",
    "WorkerErrorSeverity",
    # Permanent
    "ConfigurationError",
    "EmbedderConfigError",
    "HandlerNotFoundError",
    "InvalidPayloadError",
    "DocumentMissingError",
    # Transient
    "TransientWorkerError",
    "EmbeddingError",
    "LLMError",
    "RateLimitError",
    "TimeoutError",
    "DatabaseError",
    "LeaseExpiredError",
    # Utilities
    "classify_exception",
    "wrap_handler_error",
]
