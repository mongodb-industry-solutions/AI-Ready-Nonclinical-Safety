"""
Configuration domain models for ``mongomem_core``.

This package is the home for strongly-typed configuration structures that are
shared across the engine, such as snapshot promotion policies.  The concrete
Settings implementation backed by environment variables lives in
``mongomem_core.config``; models here represent *logical* config objects that
higher-level services can depend on without being coupled to how settings are
loaded.
"""

from .snapshot_config import SnapshotConfig
from .thread_retrieval import (
    DEEP_CONTEXT_CONFIG,
    KNOWLEDGE_RETRIEVAL_CONFIG,
    QUICK_CONTEXT_CONFIG,
    RESUME_SESSION_CONFIG,
    ThreadRetrievalConfig,
)

__all__ = [
    "SnapshotConfig",
    "ThreadRetrievalConfig",
    # Presets
    "RESUME_SESSION_CONFIG",
    "KNOWLEDGE_RETRIEVAL_CONFIG",
    "DEEP_CONTEXT_CONFIG",
    "QUICK_CONTEXT_CONFIG",
]
