"""
Local filesystem storage backend.

Handles local file paths for document ingestion.
"""

from pathlib import Path
from typing import List, Set

from mongomem_core.ingest.storage.base import StorageBackend


class LocalStorage(StorageBackend):
    """
    Local filesystem storage backend.

    Handles paths like:
    - /absolute/path/to/file.pdf
    - relative/path/to/file.pdf
    - ./file.pdf
    """

    def supports(self, uri: str) -> bool:
        """
        Check if this is a local path (not a cloud URI).

        Returns True for anything that doesn't look like a cloud URI.
        """
        # Cloud URIs have specific prefixes
        cloud_prefixes = ("gs://", "s3://", "https://", "http://", "az://")
        return not uri.startswith(cloud_prefixes)

    def resolve(self, uri: str) -> Path:
        """
        Resolve local path.

        Simply converts to Path object and validates existence.
        """
        path = Path(uri)

        if not path.exists():
            raise FileNotFoundError(f"Local file not found: {uri}")

        return path

    def list_files(self, uri: str, extensions: Set[str]) -> List[str]:
        """
        List files in a local directory matching extensions.

        Args:
            uri: Directory path
            extensions: Set of extensions to match (e.g., {".pdf", ".txt"})

        Returns:
            List of file paths as strings
        """
        path = Path(uri)

        if not path.exists():
            return []

        if not path.is_dir():
            # Single file - return if extension matches
            if path.suffix.lower() in extensions:
                return [str(path)]
            return []

        # Directory - list matching files
        files: list[str] = []
        for ext in extensions:
            files.extend(str(f) for f in path.glob(f"*{ext}"))
            files.extend(str(f) for f in path.glob(f"*{ext.upper()}"))

        return sorted(set(files))

    def cleanup(self, local_path: Path) -> None:
        """No cleanup needed for local files."""
        pass

    def cleanup_all(self) -> None:
        """No cleanup needed for local files."""
        pass
