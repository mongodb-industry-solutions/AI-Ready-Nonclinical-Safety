"""
Optional IS generation convenience layer.

Provides generate_is_from_turn() / update_is_from_events() as sugar
on top of the core update_internal_state() primitive.

This is OPTIONAL — frameworks can call update_internal_state() directly
if they author IS themselves.

COALESCING SEMANTICS (IMPORTANT):
    Coalesce policy is RATE-LIMITING ONLY, NOT event-buffering.

    When coalesce_window_ms=5000:
    - t=0ms:   generate_is_from_turn(A) → LLM call, IS updated
    - t=1000ms: generate_is_from_turn(B) → SKIPPED (events B are LOST)
    - t=2000ms: generate_is_from_turn(C) → SKIPPED (events C are LOST)
    - t=6000ms: generate_is_from_turn(D) → LLM call (only sees D)

    If you need to preserve all events:
    - Store raw events elsewhere (STM, event stream, etc.)
    - Use coalesce policy only to limit LLM call frequency
    - Have the IS generator pull from event storage, not just current turn

    The "coalesced" events are NOT queued — they're dropped.
    This is intentional: IS generation should work from the source-of-truth
    conversation history, not from the IS generation layer itself.
"""

from __future__ import annotations

import hashlib
import logging
import re
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any, Dict, List, Optional, cast

from mongomem_core.config import DEFAULT_IS_PROMPT_TEMPLATE, ISGenerationConfig
from mongomem_core.memory.internal_state import get_internal_state
from mongomem_core.models.engine import ISGenerationResult
from mongomem_core.modes import MemoryMode, require_mode
from mongomem_core.storage import get_collection
from mongomem_core.storage.collections import InternalStateCollection

if TYPE_CHECKING:
    from mongomem_core.engine._protocol import EngineProtocol

logger = logging.getLogger(__name__)

_IS_COL = InternalStateCollection()


def _utcnow() -> datetime:
    """Get current UTC time."""
    return datetime.now(timezone.utc)


def _hash_content(content: str) -> str:
    """Compute SHA256[:16] hash."""
    return hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]


class _ISGeneration:
    """
    Optional IS generation from turn events.

    Sugar on top of update_internal_state(). Provides:
    - Auto-generation of IS content via LLM
    - DB-backed coalescing for multi-pod safety
    - Provenance tracking
    - Noop detection (skip if unchanged)
    - Sectioned prompt template
    """

    def generate_is_from_turn(
        self: "EngineProtocol",
        *,
        session_id: str,
        org_id: str,
        user_id: str,
        # Flexible turn shape — all optional
        user_message: Optional[str] = None,
        assistant_response: Optional[str] = None,
        tool_observations: Optional[List[str]] = None,
        intermediate_thoughts: Optional[str] = None,
        # Policy controls
        milestone: Optional[str] = None,
        turn_index: Optional[int] = None,
        force: bool = False,
        # Overrides
        prompt_template: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        # Multi-agent support
        agent_id: Optional[str] = None,
    ) -> ISGenerationResult:
        """
        Generate IS from turn events. Calls update_internal_state() internally.

        This is OPTIONAL convenience — frameworks can call update_internal_state()
        directly if they author IS themselves.

        Args:
            session_id: Session identifier
            org_id: Organization ID
            user_id: User ID
            user_message: User's message (optional)
            assistant_response: Assistant's response (optional)
            tool_observations: Tool outputs/observations (optional)
            intermediate_thoughts: Agent's reasoning steps (optional)
            milestone: Milestone trigger (for "milestone" policy)
            turn_index: Turn counter (for "every_n" policy)
            force: Bypass coalesce/policy checks
            prompt_template: Override IS generation prompt
            max_tokens: Override max token limit
            temperature: Override temperature
            agent_id: Agent identifier for multi-agent support

        Returns:
            ISGenerationResult with update status and provenance

        Raises:
            ModeError: If not in IWM or HYBRID mode
            ValueError: If no LLM available for generation
        """
        require_mode(
            self._mode,
            [MemoryMode.IWM, MemoryMode.HYBRID],
            "generate_is_from_turn",
        )

        config = self._is_config or ISGenerationConfig()

        # Resolve LLM (is_llm preferred, fall back to llm)
        is_llm = getattr(self, "_is_llm", None) or self._llm
        if is_llm is None:
            raise ValueError(
                "generate_is_from_turn requires is_llm or llm to be set. "
                "Pass llm= or is_llm= when constructing MemoryEngine."
            )

        # Sanitize inputs if configured
        inputs = self._sanitize_is_inputs(
            config=config,
            user_message=user_message,
            assistant_response=assistant_response,
            tool_observations=tool_observations,
            intermediate_thoughts=intermediate_thoughts,
        )

        # Check policy: should we update now?
        if not force:
            skip_result = self._check_is_update_policy(
                session_id=session_id,
                org_id=org_id,
                config=config,
                milestone=milestone,
                turn_index=turn_index,
                agent_id=agent_id,
            )
            if skip_result is not None:
                return skip_result

        # Get current IS (scoped to agent for multi-agent support)
        current_is = get_internal_state(self._db, session_id, org_id, agent_id=agent_id)
        current_content = current_is.content if current_is else "No prior state."
        current_version = current_is.version if current_is else 0

        # Build events section for prompt
        events_section = self._build_events_section(inputs)

        # Build full prompt
        template = prompt_template or config.prompt_template or DEFAULT_IS_PROMPT_TEMPLATE
        prompt = template.format(
            current_is=current_content,
            events_section=events_section,
        )

        # Generate new IS content
        effective_max_tokens = max_tokens or config.max_tokens
        effective_temp = temperature if temperature is not None else config.temperature
        stop_seqs = config.stop_sequences or None

        logger.debug(
            "Generating IS: session=%s max_tokens=%d temp=%.2f",
            session_id,
            effective_max_tokens,
            effective_temp,
        )

        try:
            new_content = is_llm.generate(
                prompt,
                max_tokens=effective_max_tokens,
                temperature=effective_temp,
                stop=stop_seqs,
            )
        except AttributeError:
            # Fallback if generate() not implemented
            new_content = is_llm.complete(prompt)
            # Manual truncation as fallback
            if len(new_content) > effective_max_tokens * 4:  # Rough char estimate
                new_content = new_content[: effective_max_tokens * 4]

        # Clean up generated content
        new_content = new_content.strip()

        # Compute hashes for provenance and noop detection
        new_hash = _hash_content(new_content)
        events_hash = self._compute_events_hash(inputs)

        # Noop detection: skip if content unchanged
        if config.skip_if_unchanged and current_is and current_is.content_hash == new_hash:
            logger.info(
                "IS unchanged (hash=%s), skipping update: session=%s",
                new_hash,
                session_id,
            )
            return ISGenerationResult(
                updated=False,
                version=current_version,
                content_hash=new_hash,
                previous_version=current_version,
                was_noop=True,
                skipped_reason="content_unchanged",
                model_id=getattr(is_llm, "model_id", None),
                events_hash=events_hash,
            )

        # Update IS via the core primitive
        result = self.update_internal_state(
            session_id=session_id,
            org_id=org_id,
            user_id=user_id,
            content=new_content,
            model_id=getattr(is_llm, "model_id", None),
            agent_id=agent_id,  # Multi-agent support
            update_reason="auto_turn",
            metadata={
                "derived_from": self._compute_derived_from(inputs),
                "events_hash": events_hash,
                "milestone": milestone,
                "turn_index": turn_index,
            },
        )

        # Update coalesce tracking
        self._update_coalesce_timestamp(session_id, org_id, agent_id)

        logger.info(
            "IS generated: session=%s version=%d tokens=%d hash=%s",
            session_id,
            result.version,
            result.token_count,
            result.content_hash,
        )

        return ISGenerationResult(
            updated=True,
            version=result.version,
            token_count=result.token_count,
            content_hash=result.content_hash,
            previous_version=current_version,
            was_noop=False,
            model_id=getattr(is_llm, "model_id", None),
            events_hash=events_hash,
        )

    # Alias for clarity
    update_is_from_events = generate_is_from_turn

    def _sanitize_is_inputs(
        self: "EngineProtocol",
        config: ISGenerationConfig,
        user_message: Optional[str],
        assistant_response: Optional[str],
        tool_observations: Optional[List[str]],
        intermediate_thoughts: Optional[str],
    ) -> Dict[str, Any]:
        """Sanitize inputs before IS generation."""
        inputs = {
            "user_message": user_message,
            "assistant_response": assistant_response,
            "tool_observations": tool_observations,
            "intermediate_thoughts": intermediate_thoughts,
        }

        # Apply custom sanitizer if provided
        if config.sanitize_inputs:
            inputs = config.sanitize_inputs(inputs)

        # Apply redact patterns
        if config.redact_patterns:
            for key, value in inputs.items():
                if isinstance(value, str):
                    for pattern in config.redact_patterns:
                        value = re.sub(pattern, "[REDACTED]", value)
                    inputs[key] = value
                elif isinstance(value, list):
                    inputs[key] = [
                        re.sub(pattern, "[REDACTED]", v) if isinstance(v, str) else v
                        for v in value
                        for pattern in config.redact_patterns
                    ]

        return inputs

    def _build_events_section(
        self: "EngineProtocol",
        inputs: Dict[str, Any],
    ) -> str:
        """Build the events section for the IS prompt."""
        sections = []

        if inputs.get("user_message"):
            sections.append(f"User: {inputs['user_message']}")

        if inputs.get("assistant_response"):
            sections.append(f"Assistant: {inputs['assistant_response']}")

        if inputs.get("tool_observations"):
            obs_text = "\n".join(f"- {obs}" for obs in inputs["tool_observations"])
            sections.append(f"Tool Observations:\n{obs_text}")

        if inputs.get("intermediate_thoughts"):
            sections.append(f"Intermediate Thoughts: {inputs['intermediate_thoughts']}")

        if not sections:
            return "(No new events)"

        return "\n\n".join(sections)

    def _compute_events_hash(
        self: "EngineProtocol",
        inputs: Dict[str, Any],
    ) -> str:
        """Compute hash of all input events for provenance."""
        combined = ""
        for key in sorted(inputs.keys()):
            value = inputs[key]
            if value:
                if isinstance(value, list):
                    combined += f"{key}:{','.join(str(v) for v in value)};"
                else:
                    combined += f"{key}:{value};"
        return _hash_content(combined) if combined else ""

    def _compute_derived_from(
        self: "EngineProtocol",
        inputs: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Compute provenance hashes for each input."""
        derived: Dict[str, Any] = {}

        if inputs.get("user_message"):
            derived["user_msg_hash"] = _hash_content(inputs["user_message"])

        if inputs.get("assistant_response"):
            derived["assistant_msg_hash"] = _hash_content(inputs["assistant_response"])

        if inputs.get("tool_observations"):
            derived["tool_obs_hashes"] = [_hash_content(obs) for obs in inputs["tool_observations"]]

        if inputs.get("intermediate_thoughts"):
            derived["thoughts_hash"] = _hash_content(inputs["intermediate_thoughts"])

        return derived

    def _check_is_update_policy(
        self: "EngineProtocol",
        session_id: str,
        org_id: str,
        config: ISGenerationConfig,
        milestone: Optional[str],
        turn_index: Optional[int],
        agent_id: Optional[str] = None,
    ) -> Optional[ISGenerationResult]:
        """
        Check if IS update should be skipped based on policy.

        Returns ISGenerationResult if skipped, None if should proceed.
        """
        policy = config.update_policy

        if policy == "always":
            return None

        if policy == "milestone":
            if milestone is None:
                return ISGenerationResult(
                    updated=False,
                    skipped_reason="no_milestone_provided",
                )
            if milestone not in config.milestone_triggers:
                return ISGenerationResult(
                    updated=False,
                    skipped_reason=f"milestone_not_in_triggers: {milestone}",
                )
            return None

        if policy == "every_n":
            if turn_index is None:
                # Check DB counter
                counter = self._get_turn_counter(session_id, org_id)
                turn_index = counter

            if turn_index % config.every_n_turns != 0:
                return ISGenerationResult(
                    updated=False,
                    skipped_reason=f"every_n: turn {turn_index} not divisible by {config.every_n_turns}",
                )
            return None

        if policy == "coalesce":
            # DB-backed coalescing for multi-pod safety
            last_update = self._get_last_is_generation_time(session_id, org_id, agent_id)
            if last_update:
                window_ms = config.coalesce_window_ms
                window_end = last_update + timedelta(milliseconds=window_ms)
                now = _utcnow()

                if now < window_end:
                    return ISGenerationResult(
                        updated=False,
                        coalesced=True,
                        skipped_reason="within_coalesce_window",
                        next_update_at=window_end.isoformat(),
                    )
            return None

        return None

    def _get_last_is_generation_time(
        self: "EngineProtocol",
        session_id: str,
        org_id: str,
        agent_id: Optional[str] = None,
    ) -> Optional[datetime]:
        """
        Get last IS generation timestamp from DB (for coalescing).

        Uses top-level last_generated_at field for efficient querying
        and cross-pod coordination.
        """
        from mongomem_core.memory.internal_state import DEFAULT_AGENT_ID

        effective_agent_id = agent_id if agent_id is not None else DEFAULT_AGENT_ID
        col = get_collection(_IS_COL, self._db)
        doc = col.find_one(
            {"session_id": session_id, "org_id": org_id, "agent_id": effective_agent_id},
            {"last_generated_at": 1},
        )
        if doc and doc.get("last_generated_at"):
            return cast(datetime, doc["last_generated_at"])
        return None

    def _update_coalesce_timestamp(
        self: "EngineProtocol",
        session_id: str,
        org_id: str,
        agent_id: Optional[str] = None,
    ) -> None:
        """
        Update last generation timestamp for coalescing.

        DB-backed for multi-pod safety — all pods see the same timestamp.
        """
        from mongomem_core.memory.internal_state import DEFAULT_AGENT_ID

        effective_agent_id = agent_id if agent_id is not None else DEFAULT_AGENT_ID
        col = get_collection(_IS_COL, self._db)
        col.update_one(
            {"session_id": session_id, "org_id": org_id, "agent_id": effective_agent_id},
            {"$set": {"last_generated_at": _utcnow()}},
        )

    def _get_turn_counter(
        self: "EngineProtocol",
        session_id: str,
        org_id: str,
    ) -> int:
        """Get turn counter from session_counters collection."""
        # Use existing session counter infrastructure
        # Note: Turn counter is shared per session, not per agent
        from mongomem_core.storage.collections import SessionCountersCollection

        col = get_collection(SessionCountersCollection(), self._db)
        doc = col.find_one({"session_id": session_id, "org_id": org_id})
        if doc:
            return int(doc.get("turn_count", 0))
        return 0


__all__ = ["_ISGeneration"]
