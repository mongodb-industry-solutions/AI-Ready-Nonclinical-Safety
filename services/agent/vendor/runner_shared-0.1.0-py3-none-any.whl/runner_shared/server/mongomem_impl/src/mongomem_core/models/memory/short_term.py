"""
Models for short-term memory documents.

Short-term memory (STM) holds individual conversation turns before they are
consolidated into snapshots. Each document represents a single message in a
conversation session.
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Dict, List, Optional

from bson import ObjectId
from mongomem_core.common.utils import utcnow
from mongomem_core.models.memory.base import (
    BaseMemoryIn,
    HasEmbeddings,
    MessageRole,
)
from mongomem_core.models.types import PyObjectId
from pydantic import BaseModel, Field, field_serializer, model_validator


class ToolCall(BaseModel):
    """
    LLM/framework-agnostic tool call representation.

    This schema is designed to capture tool calls from any LLM provider
    (OpenAI, Anthropic, Gemini, etc.) or agent framework (LangChain, CrewAI,
    AutoGen, etc.) in a normalized format.

    The `arguments` field accepts either:
    - A dict (native Python, Anthropic's `input`, Gemini's `args`)
    - A JSON string (OpenAI's `arguments`).
    """

    name: str = Field(..., description="Name of the tool/function being called")
    arguments: dict | str = Field(
        default={},
        description=(
            "Tool arguments as a dict or JSON string. Stored as-is to preserve provider fidelity."
        ),
    )
    id: Optional[str] = Field(
        default=None,
        description="Provider-assigned call ID (for correlating with tool results)",
    )
    provider: Optional[str] = Field(
        default=None,
        description="Source provider/framework (e.g., 'openai', 'anthropic', 'langchain')",
    )

    def get_arguments_dict(self) -> dict:
        """
        Return arguments as a dict, parsing JSON string if necessary.

        Returns:
            Arguments as a Python dict
        """
        if isinstance(self.arguments, str):
            try:
                result: Dict[Any, Any] = json.loads(self.arguments)
                return result
            except json.JSONDecodeError:
                return {"raw": self.arguments}
        return self.arguments

    def get_arguments_json(self) -> str:
        """
        Return arguments as a JSON string.

        Returns:
            Arguments serialized as JSON
        """
        if isinstance(self.arguments, str):
            return self.arguments
        return json.dumps(self.arguments)


class ToolResult(BaseModel):
    """
    Result from a tool call execution.

    Used for 'tool' role messages that contain the output of a tool call.
    """

    tool_call_id: str = Field(..., description="ID of the tool call this result corresponds to")
    content: str = Field(..., description="The tool's output/result")
    name: Optional[str] = Field(default=None, description="Name of the tool (for clarity in logs)")
    is_error: bool = Field(default=False, description="Whether this result represents an error")


class ShortTermIn(BaseMemoryIn, HasEmbeddings):
    """
    Input model for creating a short-term memory turn.

    This represents a single message in a conversation that will be stored
    in the STM collection.
    """

    # Management fields
    session_id: str = Field(..., description="Conversation thread/session identifier")
    role: MessageRole = Field(..., description="Role of the message author")
    agent_id: Optional[str] = Field(default=None, description="ID of the agent if applicable")
    share_learning_with_team: bool = Field(
        default=True,
        description="Whether to share learning extractions with agent's team cohort",
    )

    # Payload fields
    content: Optional[str] = Field(
        default=None, description="Message content (can be None for tool_calls)"
    )
    tokens: Optional[int] = Field(default=None, description="Token count for message")
    stop_reason: Optional[str] = Field(default=None, description="Stop reason if applicable")
    model_name: Optional[str] = Field(
        default=None, description="Model used to generate this message"
    )

    # Tool call fields (for assistant messages with function calling)
    tool_calls: Optional[List[ToolCall]] = Field(
        default=None, description="Tool calls for assistant messages"
    )
    # Tool result fields (for tool role messages)
    tool_call_id: Optional[str] = Field(
        default=None, description="Tool call ID this result corresponds to"
    )
    tool_name: Optional[str] = Field(
        default=None, description="Name of the tool that produced this result"
    )
    is_error: bool = Field(
        default=False, description="Whether this tool result represents an error"
    )

    @model_validator(mode="after")
    def validate_message_content(self) -> ShortTermIn:
        """Validate message content based on role."""
        if self.role == MessageRole.TOOL:
            if not self.tool_call_id:
                raise ValueError("tool role messages must have tool_call_id")
            if not self.content:
                raise ValueError("tool role messages must have content")
        elif self.role == MessageRole.ASSISTANT:
            if not self.content and not self.tool_calls:
                raise ValueError("assistant messages must have either content or tool_calls")
        else:
            if not self.content:
                raise ValueError(f"{self.role} messages must have content")
        return self


class ShortTermBase(ShortTermIn):
    """
    Base model with fields added after input validation.

    Includes org_id, user_id, and timestamp which are typically set by the
    service layer rather than provided in input.
    """

    org_id: str = Field(..., description="Organization/tenant ID")
    user_id: str = Field(..., description="User ID of the message author")
    timestamp: datetime = Field(default_factory=utcnow)

    model_config = {
        "arbitrary_types_allowed": True,
        "from_attributes": True,
        "populate_by_name": True,
        "use_enum_values": True,
    }


class ShortTermDB(ShortTermBase):
    """
    Database representation of a short-term memory document.

    Includes the MongoDB _id and additional tracking fields.
    """

    id: PyObjectId = Field(default_factory=PyObjectId, alias="_id")
    promoted: bool = Field(
        default=False, description="Whether this turn has been promoted to a snapshot"
    )
    turn_seq: int = Field(
        default=0,
        description="Monotonic sequence number per session for ordering",
    )
    embedding_model_id: Optional[str] = Field(
        default=None,
        description="Model identifier used to generate the embedding",
    )
    embedded_at: Optional[datetime] = Field(
        default=None, description="Timestamp when embedding was generated"
    )
    idempotency_hash: Optional[str] = Field(default=None, description="Hash for idempotency checks")

    @field_serializer("id", when_used="json")
    def _serialize_id(self, v: ObjectId) -> str:
        return str(v)


class ShortTermOut(ShortTermBase):
    """Output model for short-term memory reads."""

    id: str = Field(..., alias="_id")
    promoted: bool = Field(default=False)
    turn_seq: int = Field(default=0)
