"""
Preferences extractor for communication preferences.

Extracts user communication preferences from conversations using LLM.
Unlike semantic/episodic extractors, returns a single preference dict
rather than a list of extracted items.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

if TYPE_CHECKING:
    from mongomem_core.protocols import LLMProtocol

from mongomem_core.extraction.base import BaseExtractor
from mongomem_core.extraction.preferences.prompts import (
    EXTRACTION_PROMPT_TEMPLATE,
    EXTRACTION_SCHEMA,
    EXTRACTION_SYSTEM_PROMPT,
)

logger = logging.getLogger(__name__)


@dataclass
class ExtractedPreferences:
    """Extracted preferences from a conversation."""

    tone: Optional[str] = None
    style: Optional[str] = None
    response_length: Optional[str] = None
    expertise_level: Optional[str] = None
    preferred_format: Optional[str] = None
    language: Optional[str] = None
    custom_instructions: Optional[str] = None
    confidence: float = 0.0
    evidence: List[int] = field(default_factory=list)  # Message indices that informed extraction

    def has_any_preference(self) -> bool:
        """Check if any preference was extracted."""
        return any(
            [
                self.tone,
                self.style,
                self.response_length,
                self.expertise_level,
                self.preferred_format,
                self.language,
                self.custom_instructions,
            ]
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary, excluding None/empty values except confidence."""
        result: Dict[str, Any] = {}
        if self.tone:
            result["tone"] = self.tone
        if self.style:
            result["style"] = self.style
        if self.response_length:
            result["response_length"] = self.response_length
        if self.expertise_level:
            result["expertise_level"] = self.expertise_level
        if self.preferred_format:
            result["preferred_format"] = self.preferred_format
        if self.language:
            result["language"] = self.language
        if self.custom_instructions:
            result["custom_instructions"] = self.custom_instructions
        result["confidence"] = self.confidence
        # Only include evidence if non-empty
        if self.evidence:
            result["evidence"] = self.evidence
        return result


class PreferencesExtractor(BaseExtractor):
    """
    Extractor for user communication preferences.

    Unlike semantic/episodic extractors which return lists of items,
    this extractor returns a single ExtractedPreferences object
    representing the user's preferences for the current session.
    """

    extraction_type: str = "preferences"

    def __init__(
        self,
        llm: "LLMProtocol",
        prompt_resolver: Optional[Callable[[], Optional[str]]] = None,
    ) -> None:
        """
        Initialize preferences extractor.

        Args:
            llm: LLM protocol implementation for extraction
            prompt_resolver: Optional callable for hot-reload prompts
        """
        super().__init__(llm, prompt_resolver)

    def extract(self, messages: List[Dict[str, Any]]) -> Optional[ExtractedPreferences]:  # type: ignore[override]
        """
        Extract communication preferences from conversation messages.

        Args:
            messages: List of conversation messages with 'role' and 'content' keys

        Returns:
            ExtractedPreferences if preferences found, None otherwise
        """
        if not messages:
            logger.debug("No messages to extract preferences from")
            return None

        # Get prompt (supports hot-reload)
        system_prompt = self._get_prompt(EXTRACTION_SYSTEM_PROMPT)

        # Format conversation for prompt
        formatted_conversation = self._format_messages(messages)
        user_prompt = EXTRACTION_PROMPT_TEMPLATE.format(conversation_history=formatted_conversation)

        # Call LLM
        try:
            result = self._llm.complete_json(
                prompt=f"{system_prompt}\n\n{user_prompt}",
                schema=EXTRACTION_SCHEMA,
            )
        except Exception as e:
            logger.error("LLM preferences extraction failed: %s", e)
            return None

        # Parse response
        preferences_data = result.get("preferences", {})
        confidence = result.get("confidence", 0.0)
        evidence = result.get("evidence", [])

        # Create ExtractedPreferences
        # Only use nested confidence if top-level is missing or zero
        if (confidence is None or confidence == 0.0) and "confidence" in preferences_data:
            confidence = preferences_data.get("confidence", 0.0)

        extracted = ExtractedPreferences(
            tone=preferences_data.get("tone"),
            style=preferences_data.get("style"),
            response_length=preferences_data.get("response_length"),
            expertise_level=preferences_data.get("expertise_level"),
            preferred_format=preferences_data.get("preferred_format"),
            language=preferences_data.get("language"),
            custom_instructions=preferences_data.get("custom_instructions"),
            confidence=confidence,
            evidence=evidence,
        )

        if extracted.has_any_preference():
            logger.debug(
                "Extracted preferences with confidence=%.2f: %s",
                confidence,
                extracted.to_dict(),
            )
        else:
            logger.debug("No preferences extracted from conversation")

        return extracted

    def extract_raw(self, messages: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Extract preferences and return as raw dictionary.

        Args:
            messages: List of conversation messages

        Returns:
            Dictionary with extracted preferences
        """
        result = self.extract(messages)
        if result:
            return result.to_dict()
        return {}

    def extract_list(self, messages: List[Dict[str, Any]]) -> List[Any]:
        """
        Extract preferences and return as list for compatibility.

        This method exists for compatibility with ExtractorProtocol,
        but preferences extraction typically returns a single result.

        Args:
            messages: List of conversation messages

        Returns:
            List containing single ExtractedPreferences or empty list
        """
        result = self.extract(messages)
        return [result] if result else []


__all__ = ["PreferencesExtractor", "ExtractedPreferences"]
