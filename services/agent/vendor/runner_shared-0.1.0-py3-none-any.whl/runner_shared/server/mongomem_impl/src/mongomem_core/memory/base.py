"""
Common parameters and utilities for memory CRUD operations.

This module provides shared abstractions for query building, document creation,
and update field building to reduce duplication across memory type modules.
"""

from __future__ import annotations

import logging
import time
from datetime import datetime
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Protocol,
    Sequence,
    Tuple,
    Type,
    TypeVar,
    cast,
)

from bson import ObjectId
from mongomem_core.common.constants import (
    VECTOR_SEARCH_CANDIDATE_MULTIPLIER,
    VECTOR_SEARCH_MIN_CANDIDATES,
)
from mongomem_core.common.utils import format_document_identifier, handle_db_error, to_object_id
from mongomem_core.exceptions import DatabaseOperationError, ValidationError
from mongomem_core.models.memory.base import ChunkVisibility
from pymongo.collection import Collection
from pymongo.errors import OperationFailure
from pymongo.results import DeleteResult, UpdateResult

if TYPE_CHECKING:
    from mongomem_core.models.filters import MetadataFilter

logger = logging.getLogger(__name__)

# Type variables for generic document building
# Note: TOut is unbound to allow any Pydantic model class. Type safety is enforced
# at call sites by passing the correct db_model_class/out_model_class.
TOut = TypeVar("TOut")


class HasEmbeddingProtocol(Protocol):
    """Protocol for models that have embedding support."""

    def embedding_present(self) -> bool:
        """Check if embedding is present."""
        ...

    embedding: Optional[List[float]]


class BaseQueryBuilder:
    """
    Builder for common MongoDB query filters across memory types.

    Provides utilities for building consistent query filters with common
    patterns like org_id, user_id, visibility, timestamps, and deleted status.
    """

    @staticmethod
    def build_base_filter(
        org_id: str,
        *,
        user_id: Optional[str] = None,
        visibility: Optional[ChunkVisibility] = None,
        project_id: Optional[str] = None,
        include_deleted: bool = False,
        session_id: Optional[str] = None,
        **additional_filters: Any,
    ) -> Dict[str, Any]:
        """
        Build a base query filter with common fields.

        Args:
            org_id: Organization ID (required)
            user_id: Optional user ID filter
            visibility: Optional visibility filter
            project_id: Optional group ID filter
            include_deleted: If True, don't filter out deleted documents
            **additional_filters: Additional filter fields to merge in

        Returns:
            MongoDB query filter dictionary
        """
        q_filter: Dict[str, Any] = {"org_id": org_id}
        if user_id is not None:
            q_filter["user_id"] = user_id
        if visibility is not None:
            q_filter["visibility"] = visibility
        if project_id is not None:
            q_filter["project_id"] = project_id
        if session_id is not None:
            q_filter["session_id"] = session_id
        if not include_deleted:
            q_filter["deleted"] = {"$ne": True}

        q_filter.update(additional_filters)
        return q_filter

    @staticmethod
    def add_timestamp_filters(
        q_filter: Dict[str, Any],
        *,
        from_timestamp: Optional[datetime] = None,
        before: Optional[datetime] = None,
        timestamp_field: str = "timestamp",
    ) -> Dict[str, Any]:
        """
        Add timestamp-based filters to an existing query filter.

        Args:
            q_filter: Existing query filter to modify
            from_timestamp: Optional filter - fetch documents from this timestamp onwards
            before: Optional cursor - fetch documents before this timestamp
            timestamp_field: Name of the timestamp field (default: "timestamp")

        Returns:
            Modified query filter with timestamp constraints
        """
        if not (from_timestamp or before):
            return q_filter

        timestamp_filter: Dict[str, Any] = {}
        if from_timestamp:
            timestamp_filter["$gte"] = from_timestamp
        if before:
            timestamp_filter["$lt"] = before

        existing = q_filter.get(timestamp_field)
        if isinstance(existing, dict):
            existing.update(timestamp_filter)
        else:
            q_filter[timestamp_field] = timestamp_filter

        return q_filter

    @staticmethod
    def build_list_filter(
        org_id: str,
        *,
        user_id: Optional[str] = None,
        visibility: Optional[ChunkVisibility] = None,
        project_id: Optional[str] = None,
        from_timestamp: Optional[datetime] = None,
        before: Optional[datetime] = None,
        include_deleted: bool = False,
        timestamp_field: str = "timestamp",
        **additional_filters: Any,
    ) -> Dict[str, Any]:
        """
        Build a complete filter for list operations.

        Combines base filter, timestamp filters, and additional filters.

        Args:
            org_id: Organization ID
            user_id: Optional user ID filter
            visibility: Optional visibility filter
            project_id: Optional group ID filter
            from_timestamp: Optional filter - fetch documents from this timestamp onwards
            before: Optional cursor - fetch documents before this timestamp
            include_deleted: If True, include soft-deleted documents
            timestamp_field: Name of the timestamp field
            **additional_filters: Additional filter fields

        Returns:
            Complete MongoDB query filter dictionary
        """
        q_filter = BaseQueryBuilder.build_base_filter(
            org_id,
            user_id=user_id,
            visibility=visibility,
            project_id=project_id,
            include_deleted=include_deleted,
            **additional_filters,
        )
        BaseQueryBuilder.add_timestamp_filters(
            q_filter,
            from_timestamp=from_timestamp,
            before=before,
            timestamp_field=timestamp_field,
        )
        return q_filter

    @staticmethod
    def build_id_filter(
        org_id: str,
        doc_id: str | ObjectId,
        *,
        include_deleted: bool = False,
    ) -> Tuple[Dict[str, Any], str]:
        """
        Build a MongoDB query filter for ID-based lookups.

        Common helper for the ID lookup pattern used across memory types.
        This handles the common parts: ObjectId conversion, org_id, and deleted filtering.

        Args:
            org_id: Organization ID (required)
            doc_id: Document ID (string or ObjectId)
            include_deleted: If True, include soft-deleted documents

        Returns:
            Tuple of (query_filter_dict, identifier_string)
        """
        oid = to_object_id(doc_id)
        q_filter: Dict[str, Any] = {"_id": oid, "org_id": org_id}

        if not include_deleted:
            q_filter["deleted"] = {"$ne": True}

        return q_filter, format_document_identifier(id=doc_id)


class BaseDocumentBuilder:
    """
    Utilities for building memory documents from input models.

    Provides common patterns for handling embeddings, extraction IDs,
    and other shared document building logic.
    """

    @staticmethod
    def apply_embedding(
        doc: Any,
        input_model: HasEmbeddingProtocol,
        *,
        embedding: Optional[List[float]] = None,
        embedding_model_id: Optional[str] = None,
        embedding_field: str = "embedding",
        has_embedding_field: str = "has_embedding",
        model_id_field: Optional[str] = None,
        embedded_at_field: Optional[str] = None,
        timestamp: Optional[datetime] = None,
        log_context: Optional[str] = None,
    ) -> None:
        """
        Apply embedding to a document, handling both provided and model embeddings.

        Args:
            doc: Document object to modify (must support attribute assignment)
            input_model: Input model that may contain embeddings
            embedding: Pre-computed embedding vector (takes precedence)
            embedding_model_id: Model used to generate embedding
            embedding_field: Name of embedding field on document
            has_embedding_field: Name of has_embedding flag field
            model_id_field: Name of model ID field (if None, not set)
            embedded_at_field: Name of embedded_at timestamp field (if None, not set)
            timestamp: Timestamp to use for embedded_at (if embedded_at_field provided)
            log_context: Context string for logging (e.g., "title=xyz")
        """
        if embedding is not None:
            if embedding:
                setattr(doc, embedding_field, embedding)
                setattr(doc, has_embedding_field, True)
                if model_id_field and embedding_model_id:
                    setattr(doc, model_id_field, embedding_model_id)
                if embedded_at_field and timestamp:
                    setattr(doc, embedded_at_field, timestamp)
            elif log_context:
                logger.warning(
                    "Empty embedding list provided for %s, ignoring",
                    log_context,
                )
        elif input_model.embedding_present():
            setattr(doc, embedding_field, input_model.embedding)
            setattr(doc, has_embedding_field, True)

    @staticmethod
    def build_document_payload(
        input_model: Any,
        exclude_fields: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Extract payload from input model, excluding specified fields.

        Args:
            input_model: Pydantic input model
            exclude_fields: Fields to exclude (default: ["org_id", "user_id", "has_embedding"])

        Returns:
            Dictionary of model fields
        """
        if exclude_fields is None:
            exclude_fields = ["org_id", "user_id", "has_embedding"]
        # Exclude None values to avoid writing explicit nulls for optional fields.
        return cast(
            Dict[str, Any],
            input_model.model_dump(exclude=set(exclude_fields), exclude_none=True),
        )

    @staticmethod
    def build_memory_document(
        input_model: Any,
        db_model_class: Type[TOut],
        org_id: str,
        user_id: str,
        timestamp: datetime,
        *,
        embedding: Optional[List[float]] = None,
        embedding_model_id: Optional[str] = None,
        extraction_id: Optional[str] = None,
        idempotency_hash: Optional[str] = None,
        embedding_config: Optional[Dict[str, Any]] = None,
        exclude_fields: Optional[List[str]] = None,
        **additional_fields: Any,
    ) -> TOut:
        """
        Generic document builder for memory types.

        This method consolidates the common pattern of building memory documents
        from input models, handling embeddings, extraction IDs, and other shared logic.

        Args:
            input_model: Input model (e.g., EpisodicIn, SemanticIn, ShortTermIn)
            db_model_class: Database model class to instantiate (e.g., EpisodicDB, SemanticDB)
            org_id: Organization ID
            user_id: User ID
            timestamp: Timestamp for the document
            embedding: Pre-computed embedding vector (if any)
            embedding_model_id: Model used to generate embedding
            extraction_id: Optional extraction ID for idempotency
            idempotency_hash: Optional idempotency hash (alternative to extraction_id)
            embedding_config: Optional dict with embedding configuration:
                - model_id_field: Name of model ID field (default: "embedding_model_id")
                - embedded_at_field: Name of embedded_at field (default: None)
                - log_context: Context string for logging
            exclude_fields: Fields to exclude from payload (default: ["org_id", "user_id", "has_embedding"])
            **additional_fields: Additional fields to set on the document (e.g., turn_seq, updated_at)

        Returns:
            Instance of db_model_class with all fields set
        """
        payload = BaseDocumentBuilder.build_document_payload(
            input_model, exclude_fields=exclude_fields
        )

        doc = db_model_class(  # type: ignore[call-arg]
            **payload,
            org_id=org_id,
            user_id=user_id,
            timestamp=timestamp,
            **additional_fields,
        )

        if hasattr(input_model, "embedding_present"):
            config = embedding_config or {}
            BaseDocumentBuilder.apply_embedding(
                doc,
                input_model,
                embedding=embedding,
                embedding_model_id=embedding_model_id,
                model_id_field=config.get("model_id_field", "embedding_model_id"),
                embedded_at_field=config.get("embedded_at_field"),
                timestamp=timestamp if config.get("embedded_at_field") else None,
                log_context=config.get("log_context"),
            )

        if extraction_id:
            doc.extraction_id = extraction_id  # type: ignore[attr-defined]

        if idempotency_hash:
            doc.idempotency_hash = idempotency_hash  # type: ignore[attr-defined]

        return doc


class BaseUpdateFieldBuilder:
    """
    Utilities for building update fields from update models.

    Provides common patterns for handling visibility, project_id, publishing,
    and agent attribution fields.
    """

    @staticmethod
    def build_visibility_fields(
        update: Any,
        *,
        visibility_field: str = "visibility",
        project_id_field: str = "project_id",
    ) -> Dict[str, Any]:
        """
        Build visibility and project_id update fields from update model.

        Args:
            update: Update model with optional visibility and project_id fields
            visibility_field: Name of visibility field in update model
            project_id_field: Name of project_id field in update model

        Returns:
            Dictionary of update fields for visibility/project_id
        """
        update_fields: Dict[str, Any] = {}
        visibility = getattr(update, visibility_field, None)
        project_id = getattr(update, project_id_field, None)

        if visibility is not None:
            update_fields["visibility"] = visibility
            if visibility == ChunkVisibility.SHARED:
                update_fields[project_id_field] = project_id
            elif visibility != ChunkVisibility.SHARED:
                update_fields[project_id_field] = None
        elif project_id is not None:
            update_fields[project_id_field] = project_id

        return update_fields

    @staticmethod
    def build_publishing_fields(update: Any) -> Dict[str, Any]:
        """
        Build publishing metadata update fields from update model.

        Args:
            update: Update model with optional publishing field

        Returns:
            Dictionary of update fields for publishing (empty if not present)
        """
        update_fields: Dict[str, Any] = {}
        publishing = getattr(update, "publishing", None)
        if publishing is not None:
            if hasattr(publishing, "model_dump"):
                update_fields["publishing"] = publishing.model_dump(exclude_none=True)
            else:
                update_fields["publishing"] = publishing
        return update_fields

    @staticmethod
    def build_agent_attribution_fields(update: Any) -> Dict[str, Any]:
        """
        Build agent attribution update fields from update model.

        Args:
            update: Update model with optional agent attribution fields

        Returns:
            Dictionary of update fields for agent attribution
        """
        update_fields: Dict[str, Any] = {}
        if hasattr(update, "agent_id") and update.agent_id is not None:
            update_fields["agent_id"] = update.agent_id
        if hasattr(update, "extraction_source") and update.extraction_source is not None:
            update_fields["extraction_source"] = update.extraction_source
        if hasattr(update, "collective_metadata") and update.collective_metadata is not None:
            update_fields["collective_metadata"] = update.collective_metadata
        return update_fields

    @staticmethod
    def build_embedding_update_fields(
        update: Any,
        *,
        embedding_field: str = "embedding",
        has_embedding_field: str = "has_embedding",
    ) -> Dict[str, Any]:
        """
        Build embedding update fields from update model.

        Args:
            update: Update model with optional embedding field
            embedding_field: Name of embedding field
            has_embedding_field: Name of has_embedding flag field

        Returns:
            Dictionary of update fields for embeddings
        """
        update_fields: Dict[str, Any] = {}
        embedding = getattr(update, embedding_field, None)
        if embedding is not None:
            update_fields[embedding_field] = embedding
            update_fields[has_embedding_field] = True
        return update_fields

    @staticmethod
    def build_update_fields(
        update: Any,
        *,
        field_mappings: Optional[Dict[str, str]] = None,
        include_visibility: bool = True,
        include_publishing: bool = True,
        include_agent_attribution: bool = True,
        include_embedding: bool = True,
        custom_fields: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Generic update field builder that consolidates common patterns.

        This method builds update fields from an update model by:
        1. Including common fields (visibility, publishing, agent attribution, embedding)
        2. Mapping specific fields from the update model to DB fields
        3. Adding any custom fields provided

        Args:
            update: Update model instance
            field_mappings: Dict mapping update model field names to DB field names.
                If None, no field mappings are applied.
                Example: {"title": "title", "content": "content"}
            include_visibility: Whether to include visibility/project_id fields
            include_publishing: Whether to include publishing fields
            include_agent_attribution: Whether to include agent attribution fields
            include_embedding: Whether to include embedding fields
            custom_fields: Optional dict of additional fields to include directly

        Returns:
            Dictionary of update fields ready for MongoDB $set operation
        """
        update_fields: Dict[str, Any] = {}

        if include_visibility:
            update_fields.update(BaseUpdateFieldBuilder.build_visibility_fields(update))
        if include_publishing:
            update_fields.update(BaseUpdateFieldBuilder.build_publishing_fields(update))
        if include_agent_attribution:
            update_fields.update(BaseUpdateFieldBuilder.build_agent_attribution_fields(update))
        if include_embedding:
            update_fields.update(BaseUpdateFieldBuilder.build_embedding_update_fields(update))

        if field_mappings:
            for update_field, db_field in field_mappings.items():
                value = getattr(update, update_field, None)
                if value is not None:
                    update_fields[db_field] = value

        # Add custom fields (for special cases like summary_embedding_model_id)
        if custom_fields:
            update_fields.update(custom_fields)

        return update_fields


def doc_to_output(doc: Dict[str, Any], model: Type[TOut]) -> TOut:
    """
    Transform a raw MongoDB document to a Pydantic output model.

    Converts the MongoDB ObjectId `_id` field to a string for JSON serialization.

    Args:
        doc: Raw MongoDB document dictionary
        model: Pydantic model class to validate against

    Returns:
        Validated Pydantic model instance

    Example:
        >>> doc = {"_id": ObjectId(...), "org_id": "org1", ...}
        >>> output = doc_to_output(doc, EpisodicOut)
        >>> isinstance(output, EpisodicOut)
        True
    """
    return model.model_validate({**doc, "_id": str(doc["_id"])})  # type: ignore[attr-defined,return-value,no-any-return]


def handle_empty_sequence(
    seq: Sequence[Any],
    operation_name: str,
    result_type: type[DeleteResult] | type[UpdateResult],
) -> DeleteResult | UpdateResult | None:
    """
    Handle empty sequence case for batch operations (idempotent early return).

    This utility provides consistent handling of empty sequences for batch
    operations like delete_many and update_many. When an empty sequence is
    provided, it returns immediately with a result indicating 0 operations,
    matching MongoDB's behavior for operations with empty $in arrays.

    Args:
        seq: The sequence to check
        operation_name: Name of the operation (for logging), e.g., "delete_episodic_by_ids"
        result_type: The result type to return (DeleteResult or UpdateResult)

    Returns:
        A DeleteResult or UpdateResult with 0 operations if sequence is empty,
        None if sequence is not empty (caller should proceed with operation).

    Example:
        >>> result = handle_empty_sequence(episodic_ids, "delete_episodic_by_ids", DeleteResult)
        >>> if result is not None:
        ...     return result  # Early return for empty sequence
        >>> # Proceed with actual delete operation
    """
    if not seq:
        logger.debug("%s called with empty sequence, skipping", operation_name)
        # Return a result matching MongoDB's response format
        if result_type == DeleteResult:
            return DeleteResult({"n": 0, "ok": 1}, acknowledged=True)
        elif result_type == UpdateResult:
            return UpdateResult({"n": 0, "ok": 1}, acknowledged=True)
        else:
            raise ValueError(f"Unsupported result type: {result_type}")
    return None


def _is_index_not_ready_error(exc: OperationFailure) -> bool:
    """
    Check if error indicates vector index is not ready.

    Handles multiple error message formats that MongoDB might use.
    Uses error codes first (more reliable) and falls back to string matching.
    Checks for various transient index states including not_started, building, paused.

    Args:
        exc: The OperationFailure exception to check

    Returns:
        True if the error indicates the index is not ready, False otherwise
    """
    error_msg = str(exc).lower()
    error_code = getattr(exc, "code", None)

    # Check for known error codes first (more reliable)
    if error_code in (171, 172):  # Index not ready error codes
        return True

    # Check for various transient index states
    transient_states = ["not_started", "building", "paused", "not ready"]
    index_error_keywords = ["cannot query vector index", "vector index", "index"]

    return any(
        keyword in error_msg and state in error_msg
        for keyword in index_error_keywords
        for state in transient_states
    )


def retry_vector_search(
    *,
    collection_name: str,
    index_name: str,
    org_id: str,
    max_retries: int = 2,
    base_delay: float = 0.5,
) -> Callable[[Callable[[], List[Dict[str, Any]]]], Callable[[], List[Dict[str, Any]]]]:
    """
    Decorator factory for vector search operations with retry logic.

    Returns a decorator that handles the transient "index not ready" state that can
    occur during index rebuilds or in distributed systems. Uses exponential backoff
    for retries.

    Note: This retry logic is essential when using the default bootstrap behavior
    (``wait_for_indexes_ready=False``), as indexes may still be building when
    search operations are first called. It also handles:
    - Index rebuilds (indexes can transition from ready -> building -> ready)
    - Distributed systems (bootstrap on one node, search on another)
    - Race conditions in multi-process environments
    - Async worker scenarios where indexes are created during bootstrap but
      search operations occur before indexes are fully ready

    This is a decorator factory pattern that allows passing runtime parameters while
    still using decorator syntax. Use it like:

    ```python
    @retry_vector_search(
        collection_name="my_collection",
        index_name="my_index",
        org_id="org_1"
    )
    def my_search():
        return list(col.aggregate(pipeline))

    results = my_search()  # Automatically retries on index not ready
    ```

    Or call it directly as a function wrapper:

    ```python
    wrapped_search = retry_vector_search(
        collection_name="my_collection",
        index_name="my_index",
        org_id="org_1"
    )(my_search_function)
    results = wrapped_search()
    ```

    Args:
        collection_name: Name of the collection (for logging/errors)
        index_name: Name of the vector index (for logging)
        org_id: Organization ID (for logging/errors)
        max_retries: Maximum number of retry attempts (default: 2, reduced since
            bootstrap typically waits for indexes to be ready)
        base_delay: Base delay in seconds for exponential backoff (default: 0.5)

    Returns:
        A decorator function that wraps the operation with retry logic

    Raises:
        DatabaseOperationError: If the operation fails after all retries or
            encounters a non-retryable error
    """

    def decorator(
        operation: Callable[[], List[Dict[str, Any]]],
    ) -> Callable[[], List[Dict[str, Any]]]:
        """Inner decorator that applies retry logic to the operation."""

        def wrapped() -> List[Dict[str, Any]]:
            """Wrapped function with retry logic."""
            for attempt in range(max_retries + 1):
                try:
                    return operation()
                except OperationFailure as e:
                    # Retry if index is not ready yet
                    if _is_index_not_ready_error(e):
                        if attempt < max_retries:
                            delay = base_delay * (2**attempt)  # Exponential backoff
                            logger.warning(
                                "%s vector index not ready, retrying in %.1fs (attempt %d/%d)",
                                index_name,
                                delay,
                                attempt + 1,
                                max_retries + 1,
                            )
                            time.sleep(delay)
                            continue
                        else:
                            logger.error(
                                "%s vector index still not ready after %d retries",
                                index_name,
                                max_retries,
                            )
                            raise DatabaseOperationError(
                                "Vector index not ready after retries",
                                operation="vector_search",
                                collection=collection_name,
                                original_error=e,
                                details={"org_id": org_id, "index_name": index_name},
                            ) from e
                    else:
                        # Re-raise for other types of OperationFailure
                        raise

            # This should never be reached, but satisfies mypy
            return []

        return wrapped

    return decorator


# Platform-owned filter keys that a caller-supplied metadata_filter must never
# set. These are the tenant-isolation / identity / lifecycle fields the memory
# server controls. They are reserved REGARDLESS of whether a given rbac_filter
# currently contains them: build_base_filter adds user_id/project_id/visibility/
# session_id only when provided, and deleted/is_latest only on some paths, so
# without a fixed reserved set a caller could *inject* an omitted key (not just
# override a present one) to narrow a query onto another principal's data inside
# a shared store. "tags" and "agent_id" are intentionally NOT reserved — they
# are legitimate user-facing metadata fields, not tenant-isolation boundaries.
_RESERVED_RBAC_KEYS = frozenset(
    {
        "org_id",
        "user_id",
        "project_id",
        "visibility",
        "session_id",
        "deleted",
        "is_latest",
        "has_embedding",
    }
)


def merge_rbac_and_metadata_filter(
    rbac_filter: Dict[str, Any],
    metadata_filter: Optional["MetadataFilter"],
) -> Dict[str, Any]:
    """
    Merge a caller-supplied metadata filter into the RBAC/base filter.

    Security: the RBAC filter carries the tenant-isolation boundary (``org_id``,
    ``user_id``, ``project_id``, ``visibility``, ``session_id``, ...) and MUST
    NOT be settable by caller input. A caller that re-specifies — or injects — a
    reserved key (see ``_RESERVED_RBAC_KEYS``) would otherwise clobber or forge
    the constraint and read another tenant's or user's data. Reserved keys (the
    fixed set plus whatever the rbac_filter already contains) are dropped from
    the caller filter (and logged); the RBAC filter is then applied last so its
    values always win on any remaining collision.

    Args:
        rbac_filter: Security-critical filter dict (also includes internal
            filters such as ``is_latest``). Its keys, plus all reserved keys,
            are non-settable by the caller.
        metadata_filter: Optional user-provided metadata filter.

    Returns:
        Merged MongoDB filter dict with the tenant-isolation boundary intact.

    Note on nested operators (raw-mode ``$or``/``$and``/``$nor``) — read before
    "fixing" a flag from a reviewer or pentest:
        This guard strips reserved keys only at the TOP LEVEL of the caller
        filter; it deliberately does not recurse into boolean-operator clauses.
        A reserved key smuggled inside a nested clause (e.g.
        ``{"$or": [{"user_id": "<victim>"}]}``) is therefore not stripped here —
        but it is NOT a tenant-isolation bypass in the OE-mediated request path,
        because it is defended in depth:

        1. ``org_id``/``project_id`` (the tenant boundary) are platform-pinned
           from pod env and are always present at the top level of
           ``rbac_filter``. ``$vectorSearch`` ANDs top-level keys, so a nested
           ``{"org_id": "<other>"}`` is unsatisfiable (``org_id == self`` AND
           ``org_id == other``). Cross-org/cross-project reads are blocked
           regardless of nesting.
        2. ``user_id``/``visibility`` are enforced by the OE memory proxy against
           the principal taken from the execution token — not caller input:
           private cross-user reads are 403'd, cross-user reads require
           ``shared``/``org`` visibility, and at least one of
           ``user_id``/``visibility`` is required at the top level (see
           ``internal/domains/orchestration-engine/memory_proxy.go``,
           ``enforceMemoryAccessPolicy``). That mandatory top-level scalar also
           lands in ``rbac_filter`` and ANDs against any nested clause, making a
           contradictory nested private/cross-user predicate unsatisfiable; a
           nested clause can at most widen to ``shared``/``org`` data, which is
           non-private by definition.
        3. In the intended topology the memory server is reached via the OE —
           external traffic is proxied API Gateway → OE (AP-2237) and in-cluster
           Cilium policy admits only the OE (see
           ``agentic-operator/internal/fctr/policy.go``). The cell-shared
           ``mem-ingress`` Envoy gateway (``reconcileMemHTTPRoute`` in
           ``tenantenvironment_ingress_httproute.go``) routes directly to the
           memory-server Service without OE or Gateway-level auth today; it is
           internal-only. If ``mem-ingress`` is ever externally exposed, add
           recursive reserved-key stripping for ``$or``/``$and``/``$nor`` here.
    """
    final_filter: Dict[str, Any] = {}
    if metadata_filter is not None and not metadata_filter.is_empty():
        user_filter = metadata_filter.to_mongo_filter()
        protected = _RESERVED_RBAC_KEYS | rbac_filter.keys()
        dropped = [key for key in user_filter if key in protected]
        if dropped:
            logger.warning(
                "Dropping metadata_filter keys that collide with reserved RBAC fields: %s",
                sorted(dropped),
            )
        final_filter.update({k: v for k, v in user_filter.items() if k not in protected})
    # Apply RBAC keys last so the tenant-isolation boundary cannot be clobbered.
    final_filter.update(rbac_filter)
    return final_filter


def execute_vector_search(
    col: Collection,
    *,
    index_name: str,
    query_embedding: List[float],
    rbac_filter: Dict[str, Any],
    collection_name: str,
    org_id: str,
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    max_retries: int = 2,
    base_delay: float = 0.5,
    expected_dimension: Optional[int] = None,
    metadata_filter: Optional["MetadataFilter"] = None,
    projection: Optional[Dict[str, Any]] = None,
    include_fields: Optional[List[str]] = None,
) -> List[Dict[str, Any]]:
    """
    Execute a MongoDB $vectorSearch aggregation with retry logic.

    This is a generic vector search function that can be reused across memory types.
    It builds the aggregation pipeline, executes it with retry logic, and returns
    raw result documents.

    Filter Priority (RBAC is non-overridable for tenant isolation):
        1. metadata_filter (user-provided, via MetadataFilter.to_mongo_filter()),
           with reserved RBAC keys stripped out (see merge_rbac_and_metadata_filter)
        2. rbac_filter (security-critical, includes internal filters like is_latest)
           — applied last so its keys always win on collision.

    Args:
        col: MongoDB collection instance
        index_name: Name of the vector search index
        query_embedding: Query embedding vector for similarity search
        rbac_filter: RBAC filter dictionary (org_id, user_id, visibility, etc.).
            Internal filters like `is_latest` should be merged into this dict
            before calling.
        collection_name: Name of the collection (for logging/errors)
        org_id: Organization ID (for logging/errors)
        top_k: Maximum number of results to return (default: 50)
        similarity_threshold: Minimum similarity score threshold (default: 0.0)
        max_retries: Maximum number of retry attempts for index not ready (default: 2,
            reduced since bootstrap typically waits for indexes to be ready)
        base_delay: Base delay in seconds for exponential backoff (default: 0.5)
        expected_dimension: Optional expected dimension for query_embedding validation
        metadata_filter: Optional user-provided metadata filter. Merged with the
            RBAC filter; reserved RBAC keys (org_id, user_id, project_id,
            visibility, session_id, deleted, is_latest, has_embedding) are
            non-settable, so any colliding/injected caller keys are dropped (and
            logged) to preserve tenant isolation.
        projection: Optional custom projection dictionary. If provided, this will be used
            as the $project stage. Must include score field if needed.
        include_fields: Optional list of field names to include in projection. If provided
            (and projection is None), builds a projection that includes these fields plus
            the score. Fields are included as 1, embedding is excluded.

    Returns:
        List of result documents with similarity scores

    Raises:
        ValidationError: If query_embedding is empty or dimension mismatch occurs
        DatabaseOperationError: If the vector search operation fails after retries

    Example:
        >>> # Default usage (excludes embedding, includes score)
        >>> results = execute_vector_search(
        ...     col, index_name="idx", query_embedding=[0.1]*1536,
        ...     rbac_filter={"org_id": "org_1"}, collection_name="semantic", org_id="org_1"
        ... )
        >>> # With internal filter merged into rbac_filter
        >>> results = execute_vector_search(
        ...     col, index_name="idx", query_embedding=[0.1]*1536,
        ...     rbac_filter={"org_id": "org_1", "is_latest": True},
        ...     collection_name="semantic", org_id="org_1"
        ... )
        >>> # With user-provided metadata filter
        >>> from mongomem_core.models.filters import MetadataFilter
        >>> results = execute_vector_search(
        ...     col, index_name="idx", query_embedding=[0.1]*1536,
        ...     rbac_filter={"org_id": "org_1"}, collection_name="semantic", org_id="org_1",
        ...     metadata_filter=MetadataFilter(raw={"label": "python_basics"})
        ... )
        >>> # Custom projection
        >>> results = execute_vector_search(
        ...     col, index_name="idx", query_embedding=[0.1]*1536,
        ...     rbac_filter={"org_id": "org_1"}, collection_name="semantic", org_id="org_1",
        ...     projection={"_id": 1, "content": 1, "score": {"$meta": "vectorSearchScore"}}
        ... )
        >>> # Include specific fields
        >>> results = execute_vector_search(
        ...     col, index_name="idx", query_embedding=[0.1]*1536,
        ...     rbac_filter={"org_id": "org_1"}, collection_name="semantic", org_id="org_1",
        ...     include_fields=["_id", "content", "label"]
        ... )
    """
    if not query_embedding:
        raise ValidationError(
            "query_embedding cannot be empty",
            field="query_embedding",
            value=query_embedding,
        )

    if expected_dimension is not None and len(query_embedding) != expected_dimension:
        raise ValidationError(
            f"query_embedding dimension mismatch: expected {expected_dimension}, got {len(query_embedding)}",
            field="query_embedding",
            value=len(query_embedding),
        )

    # Merge user metadata while keeping RBAC keys non-overridable (tenant isolation).
    final_filter = merge_rbac_and_metadata_filter(rbac_filter, metadata_filter)

    num_candidates = max(top_k * VECTOR_SEARCH_CANDIDATE_MULTIPLIER, VECTOR_SEARCH_MIN_CANDIDATES)

    vs_filter: Dict[str, Any] = {
        "index": index_name,
        "path": "embedding",
        "queryVector": query_embedding,
        "numCandidates": num_candidates,
        "limit": top_k,
        "similarity": "cosine",
        "filter": final_filter,
    }

    # Build projection stage
    if projection is not None:
        # Use custom projection as-is (caller must include score if needed)
        project_stage = projection
    elif include_fields is not None:
        # Build projection from include_fields list
        project_stage = {field: 1 for field in include_fields}
        project_stage["score"] = {"$meta": "vectorSearchScore"}
        project_stage["embedding"] = 0  # Always exclude embedding
    else:
        # Default projection: exclude embedding, include score
        project_stage = {
            "score": {"$meta": "vectorSearchScore"},
            "embedding": 0,  # Exclude embedding from results to reduce data transfer
        }

    pipeline = [
        {"$vectorSearch": vs_filter},
        {"$project": project_stage},
    ]

    if similarity_threshold > 0.0:
        pipeline.append({"$match": {"score": {"$gte": similarity_threshold}}})

    @retry_vector_search(
        collection_name=collection_name,
        index_name=index_name,
        org_id=org_id,
        max_retries=max_retries,
        base_delay=base_delay,
    )
    def _execute_search() -> List[Dict[str, Any]]:
        """Inner function to execute the search for retry logic."""
        with handle_db_error(
            operation="aggregate",
            collection=collection_name,
            log_message="Failed to perform vector search: org=%s",
            log_args_tuple=(org_id,),
        ):
            results = list(col.aggregate(pipeline))
            logger.debug(
                "Vector search returned %d results for org=%s index=%s",
                len(results),
                org_id,
                index_name,
            )
            return results

    return _execute_search()
