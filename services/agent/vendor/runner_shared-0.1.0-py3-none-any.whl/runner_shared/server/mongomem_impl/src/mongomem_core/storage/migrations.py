"""
Optional migration helpers for ``mongomem_core`` storage.

The legacy ExoMemory service encodes a number of **engine-domain** data
evolutions directly inside ``init_collections.py`` – for example:

* Field renames (``contextual_metadata`` → ``metadata``, ``context`` → ``metadata``)
  on semantic / episodic memories.
* Behavioural fixes around ``tenant_id`` → ``org_id`` transitions.
* One-off cleanups that keep engine data in a consistent shape for newer
  models.

This module provides an explicit, opt-in hook for such migrations so that
hosting applications can run them in a controlled maintenance step, separate
from the idempotent ``ensure_*`` bootstrap helpers.
"""

from __future__ import annotations

import logging
from typing import Any, Mapping, Optional

from mongomem_core.config import Settings
from pymongo.errors import OperationFailure
from pymongo.synchronous.database import Database

from .collections import (
    EpisodicMemoryCollection,
    SemanticMemoryCollection,
    SnapshotMemoryCollection,
    TaxonomicMemoryCollection,
)
from .search_indexes import ENGINE_SEARCH_INDEXES

logger = logging.getLogger(__name__)


def run_engine_migrations(
    db: Database,
    *,
    force_update_text_indexes: bool = False,
    settings: Optional[Settings] = None,
) -> None:  # pragma: no cover - orchestration
    """
    Run engine-domain storage migrations against ``db``.

    Current behaviour:

    * Perform semantic metadata field rename
      (``contextual_metadata`` → ``metadata``) if needed.
    * Ensure vector search index dimensions match the current configuration by
      dropping and recreating incompatible indexes.
    * Optionally refresh text search indexes to ensure they have the expected
      token mappings when ``force_update_text_indexes`` is True.

    This helper is intended to run in an explicit maintenance / migration
    context rather than implicitly at every process startup.
    """

    if settings is None:
        settings = Settings()

    _migrate_semantic_metadata_field(db)
    _migrate_vector_index_dimensions(db, settings=settings)
    _migrate_text_index_token_mappings(db, force_update=force_update_text_indexes)


def _migrate_semantic_metadata_field(db: Database) -> None:
    """
    Rename ``contextual_metadata`` → ``metadata`` on semantic memory documents.

    Mirrors the data migration block in the legacy ``_init_semantic_cols``
    helper.  The operation is idempotent: it only touches documents that still
    have ``contextual_metadata`` and do not yet have ``metadata``.
    """

    col = db[SemanticMemoryCollection.name]
    try:
        result = col.update_many(
            {
                "contextual_metadata": {"$exists": True},
                "metadata": {"$exists": False},
            },
            {"$rename": {"contextual_metadata": "metadata"}},
        )
        if result.modified_count:
            logger.info(
                "Migrated %s semantic documents from 'contextual_metadata' to "
                "'metadata' in collection %s",
                result.modified_count,
                SemanticMemoryCollection.name,
            )
    except Exception:
        logger.exception(
            "Failed to migrate 'contextual_metadata' to 'metadata' in %s",
            SemanticMemoryCollection.name,
        )


def _migrate_vector_index_dimensions(db: Database, *, settings: Settings) -> None:
    """
    Detect and repair vector search index dimension mismatches.

    For each vectorSearch index defined in ``ENGINE_SEARCH_INDEXES`` we:

    * Read the existing index definitions via ``list_search_indexes``.
    * Extract ``numDimensions`` for the ``embedding`` field if present.
    * Drop the index when dimensions are explicitly different, allowing the
      bootstrap helper to recreate it with the correct configuration.

    The behaviour mirrors the legacy ``_init_*`` helpers while keeping all
    destructive actions constrained to this explicit migration step.
    """

    collections_with_vectors = {
        EpisodicMemoryCollection.name,
        SemanticMemoryCollection.name,
        SnapshotMemoryCollection.name,
        TaxonomicMemoryCollection.name,
    }

    for collection_name, definitions in ENGINE_SEARCH_INDEXES.items():
        if collection_name not in collections_with_vectors:
            continue

        col = db[collection_name]
        try:
            existing_indexes = list(col.list_search_indexes())
        except Exception:
            logger.exception(
                "Unable to list search indexes for collection %s; skipping "
                "vector dimension migration",
                collection_name,
            )
            continue

        for idx in definitions:
            if idx.index_type != "vectorSearch":
                continue

            existing_index = _find_search_index(existing_indexes, idx.name)
            if existing_index is None:
                continue

            existing_dims = _extract_embedding_dimensions(existing_index.get("definition", {}))
            desired_dims = settings.embedding_dimension
            if existing_dims is not None:
                if existing_dims != desired_dims:
                    logger.info(
                        "Dropping vector index %s on %s due to dimension "
                        "mismatch: existing=%s desired=%s",
                        idx.name,
                        collection_name,
                        existing_dims,
                        desired_dims,
                    )
                    try:
                        col.drop_search_index(idx.name)
                    except OperationFailure as exc:
                        msg = str(exc)
                        if "Index not found" in msg or "not found" in msg:
                            logger.info(
                                "Vector index %s on %s already dropped: %s",
                                idx.name,
                                collection_name,
                                exc,
                            )
                        else:
                            logger.exception(
                                "Failed to drop vector index %s on %s",
                                idx.name,
                                collection_name,
                            )
                    except Exception as exc:
                        logger.exception(
                            "Unexpected error dropping vector index %s on %s: %s",
                            idx.name,
                            collection_name,
                            exc,
                        )


def _find_search_index(
    existing_indexes: list[Mapping[str, Any]], name: str
) -> Mapping[str, Any] | None:
    for idx in existing_indexes:
        if idx.get("name") == name:
            return idx
    return None


def _extract_embedding_dimensions(definition: Mapping[str, Any]) -> int | None:
    """
    Extract ``numDimensions`` for the ``embedding`` vector field, if present.
    """

    fields = definition.get("fields", [])
    for field in fields:
        if field.get("type") == "vector" and field.get("path") == "embedding":
            num_dims = field.get("numDimensions")
            return int(num_dims) if num_dims is not None else None
    return None


def _migrate_text_index_token_mappings(db: Database, *, force_update: bool) -> None:
    """
    Ensure text search indexes have explicit token mappings where expected.

    Mirrors the legacy ``_init_*_text_index`` helpers by:

    * Inspecting existing search index definitions.
    * If ``force_update`` is True and the index lacks an explicit token mapping
      for ``org_id``, dropping the index to allow recreation with the desired
      mappings.
    """

    if not force_update:
        return

    collections_and_indexes = [
        (SemanticMemoryCollection.name, "sem_text_search_index"),
        (EpisodicMemoryCollection.name, "epi_text_search_index"),
        (SnapshotMemoryCollection.name, "snap_text_search_index"),
        (TaxonomicMemoryCollection.name, "tax_text_search_index"),
    ]

    for collection_name, index_name in collections_and_indexes:
        col = db[collection_name]
        try:
            existing_indexes = list(col.list_search_indexes())
        except Exception:
            logger.exception(
                "Unable to list search indexes for collection %s; skipping text index migration",
                collection_name,
            )
            continue

        existing = _find_search_index(existing_indexes, index_name)
        if existing is None:
            continue

        mappings = existing.get("definition", {}).get("mappings", {}).get("fields", {})
        has_token_mappings = mappings.get("org_id", {}).get("type") == "token"

        if has_token_mappings:
            logger.debug(
                "Text index %s on %s already has token mappings; skipping update",
                index_name,
                collection_name,
            )
            continue

        logger.info(
            "Force updating text index %s on %s to include token mappings",
            index_name,
            collection_name,
        )
        try:
            col.drop_search_index(index_name)
        except Exception as exc:
            msg = str(exc)
            if "Index already requested to be deleted" in msg:
                logger.info(
                    "Text index %s on %s already being deleted; skipping recreation",
                    index_name,
                    collection_name,
                )
            else:
                logger.warning(
                    "Error dropping text index %s on %s: %s",
                    index_name,
                    collection_name,
                    exc,
                )
