"""
Procedural memory extractor.

Extracts reusable procedures (skills/workflows) from conversation
messages using LLM-based extraction with configurable prompts.
"""

from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

if TYPE_CHECKING:
    from mongomem_core.protocols import LLMProtocol

from mongomem_core.extraction.base import BaseExtractor
from mongomem_core.extraction.procedural.prompts import (
    EXTRACTION_PROMPT_TEMPLATE,
    EXTRACTION_SCHEMA,
    EXTRACTION_SYSTEM_PROMPT,
)
from mongomem_core.extraction.types import ExtractedItem

logger = logging.getLogger(__name__)

_KEBAB_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")


class ProceduralExtractor(BaseExtractor):
    """Extract procedural memories (skills/workflows) from conversation messages.

    Uses LLM to identify reusable, step-by-step procedures that were
    demonstrated or discussed in conversations.

    Supports hot-reload of prompts via optional prompt_resolver callable.
    """

    extraction_type = "procedural"

    def __init__(
        self,
        llm: "LLMProtocol",
        prompt_resolver: Optional[Callable[[], Optional[str]]] = None,
    ) -> None:
        super().__init__(llm, prompt_resolver)

    def extract(self, messages: List[Dict[str, Any]]) -> List[ExtractedItem]:
        """Extract procedural memories from conversation messages.

        Args:
            messages: List of conversation messages with 'role' and 'content' keys

        Returns:
            List of extracted items with content, citations, and confidence scores
        """
        if not messages:
            logger.debug("No messages to extract from")
            return []

        system_prompt = self._get_prompt(EXTRACTION_SYSTEM_PROMPT)
        formatted_conversation = self._format_messages(messages)
        user_prompt = EXTRACTION_PROMPT_TEMPLATE.format(conversation_history=formatted_conversation)

        try:
            result = self._llm.complete_json(
                prompt=f"{system_prompt}\n\n{user_prompt}",
                schema=EXTRACTION_SCHEMA,
            )
        except Exception as e:
            logger.error("LLM extraction failed: %s", e)
            return []

        procedures = result.get("procedures", [])
        if not procedures:
            logger.debug("No procedures extracted from conversation")
            return []

        extracted = []
        for proc in procedures:
            procedure_name = proc.get("procedure", "").strip()
            description = proc.get("description", "").strip()
            content = proc.get("content", "").strip()

            if not content or not procedure_name:
                continue

            if not _KEBAB_RE.match(procedure_name):
                logger.debug("Skipping procedure with invalid name: %s", procedure_name)
                continue

            metadata: Dict[str, Any] = {
                "extraction_type": "procedural",
                "procedure": procedure_name,
                "description": description,
            }

            steps = proc.get("steps")
            if steps:
                metadata["steps"] = steps

            tags = proc.get("tags")
            if tags:
                metadata["tags"] = tags

            extracted.append(
                ExtractedItem(
                    content=content,
                    citations=proc.get("citations", []),
                    confidence=proc.get("confidence_score", 0.5),
                    metadata=metadata,
                )
            )

        logger.debug(
            "Extracted %d procedures from %d messages",
            len(extracted),
            len(messages),
        )
        return extracted


__all__ = ["ProceduralExtractor"]
