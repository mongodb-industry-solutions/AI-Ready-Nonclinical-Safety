from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from pymongo.database import Database

from ..utils import generate_worker_id
from .cache import get_worker_state_collection

logger = logging.getLogger(__name__)


class WorkerStateStore:
    """
    Persistent storage for worker health and state information.

    Tracks:
    - Worker heartbeats
    - Processing statistics
    - Error counts
    """

    def __init__(
        self,
        db: Database,
        worker_id: Optional[str] = None,
    ) -> None:
        self._db = db
        self._collection = get_worker_state_collection(db)
        self._worker_id = worker_id or generate_worker_id()

    @property
    def worker_id(self) -> str:
        """Get this worker's ID."""
        return self._worker_id

    def heartbeat(self, status: str = "running", metadata: Optional[Dict[str, Any]] = None) -> None:
        """
        Record a heartbeat for this worker.

        Args:
            status: Current worker status (e.g., "running", "idle", "stopping")
            metadata: Additional metadata to store
        """
        now = datetime.now(timezone.utc)
        update: Dict[str, Any] = {
            "$set": {
                "status": status,
                "last_heartbeat": now,
                "metadata": metadata or {},
            },
            "$setOnInsert": {
                "started_at": now,
            },
        }

        self._collection.update_one(
            {"worker_id": self._worker_id},
            update,
            upsert=True,
        )
        logger.debug("Recorded heartbeat for worker %s", self._worker_id)

    def record_processed(self, task_type: str, count: int = 1, success: bool = True) -> None:
        """
        Record task processing statistics.

        Args:
            task_type: Type of task processed
            count: Number of tasks
            success: Whether processing was successful
        """
        field = f"stats.{task_type}.{'success' if success else 'failed'}"
        self._collection.update_one(
            {"worker_id": self._worker_id},
            {
                "$inc": {field: count},
                "$set": {"last_activity": datetime.now(timezone.utc)},
            },
            upsert=True,
        )

    def get_state(self) -> Optional[Dict[str, Any]]:
        """Get the current state for this worker."""
        return self._collection.find_one({"worker_id": self._worker_id})

    def get_all_workers(self, active_only: bool = True) -> list[Dict[str, Any]]:
        """
        Get state for all workers.

        Args:
            active_only: If True, only return workers with recent heartbeats
        """
        query: Dict[str, Any] = {}
        if active_only:
            from datetime import timedelta

            cutoff = datetime.now(timezone.utc) - timedelta(minutes=5)
            query["last_heartbeat"] = {"$gte": cutoff}

        return list(self._collection.find(query))

    def cleanup_stale_workers(self, max_age_minutes: int = 30) -> int:
        """
        Remove state for workers that haven't sent heartbeats.

        Returns:
            Number of workers cleaned up
        """
        from datetime import timedelta

        cutoff = datetime.now(timezone.utc) - timedelta(minutes=max_age_minutes)
        result = self._collection.delete_many({"last_heartbeat": {"$lt": cutoff}})
        if result.deleted_count > 0:
            logger.info("Cleaned up %d stale worker records", result.deleted_count)
        return result.deleted_count

    def shutdown(self) -> None:
        """Record worker shutdown."""
        self._collection.update_one(
            {"worker_id": self._worker_id},
            {
                "$set": {
                    "status": "stopped",
                    "stopped_at": datetime.now(timezone.utc),
                }
            },
        )
        logger.info("Recorded shutdown for worker %s", self._worker_id)


__all__ = ["WorkerStateStore"]
