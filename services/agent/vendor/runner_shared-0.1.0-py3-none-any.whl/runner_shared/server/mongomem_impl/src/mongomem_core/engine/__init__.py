"""
Memory Engine - Composable API for agent memory management.

This package provides the MemoryEngine class composed from internal components.
Users should import MemoryEngine from mongomem_core, not this package directly.
"""

from mongomem_core.engine.base import _EngineBase
from mongomem_core.engine.episodic import _Episodic
from mongomem_core.engine.ingest import _IngestMixin
from mongomem_core.engine.internal_state import _InternalState
from mongomem_core.engine.is_generation import _ISGeneration
from mongomem_core.engine.procedural import _Procedural
from mongomem_core.engine.retrieval import _Retrieval
from mongomem_core.engine.semantic import _Semantic
from mongomem_core.engine.snapshot import _Snapshot
from mongomem_core.engine.taxonomic import _Taxonomic
from mongomem_core.engine.user_context import _UserContext


class MemoryEngine(
    _IngestMixin,
    _ISGeneration,  # Optional IS generation convenience (sugar on _InternalState)
    _InternalState,  # IWM operations (always composed, writes mode-gated)
    _Semantic,
    _Taxonomic,
    _Procedural,
    _Episodic,
    _Snapshot,
    _UserContext,
    _Retrieval,
    _EngineBase,  # Must be last for correct MRO
):
    """
    Full-featured memory engine for agent memory management.

    Combines semantic, episodic, snapshot, user context, Internal Working Memory,
    and retrieval capabilities into a single cohesive API.

    The engine supports three operating modes (set at construction):
    - TRADITIONAL: STM accumulation with write_turn(), build_context returns STM + LTM
    - IWM: Internal Working Memory with update_internal_state(), constant prompt size
    - HYBRID: Both for migration/debugging/evals

    The engine is thread-safe: _db, _embedder, _llm, and _mode are set once
    during initialization and never mutated. All operations delegate
    to stateless functions.

    Example (Traditional mode - default):
        >>> from mongomem_core import MemoryEngine
        >>> engine = MemoryEngine.from_env(embedder=my_embedder)
        >>> engine.bootstrap()
        >>> engine.write_turn(
        ...     session_id="sess_123",
        ...     role="user",
        ...     content="Hello!",
        ...     org_id="org_1",
        ...     user_id="user_1",
        ... )

    Example (IWM mode - manual IS):
        >>> from mongomem_core import MemoryEngine, MemoryMode
        >>> engine = MemoryEngine.from_env(mode=MemoryMode.IWM)
        >>> engine.bootstrap()
        >>> engine.update_internal_state(
        ...     session_id="sess_123",
        ...     org_id="org_1",
        ...     user_id="user_1",
        ...     content="User prefers dark mode. Project X is active.",
        ... )

    Example (IWM mode - auto IS generation):
        >>> from mongomem_core import MemoryEngine, MemoryMode, ISGenerationConfig
        >>> engine = MemoryEngine.from_env(
        ...     mode=MemoryMode.IWM,
        ...     llm=my_llm,
        ...     is_llm=cheap_summarizer,  # Optional: separate model for IS
        ...     is_config=ISGenerationConfig(
        ...         update_policy="coalesce",
        ...         coalesce_window_ms=5000,
        ...         max_tokens=500,
        ...     ),
        ... )
        >>> result = engine.generate_is_from_turn(
        ...     session_id="sess_123",
        ...     org_id="org_1",
        ...     user_id="user_1",
        ...     user_message="How do I refresh tokens?",
        ...     assistant_response="To refresh tokens, use...",
        ... )
        >>> result.updated  # True if IS was generated
        >>> result.version  # New IS version
    """

    pass


__all__ = ["MemoryEngine"]
