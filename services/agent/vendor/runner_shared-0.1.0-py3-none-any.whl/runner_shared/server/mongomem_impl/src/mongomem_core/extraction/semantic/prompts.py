"""
Semantic extraction and consolidation prompts.

Port of ExoMemory's semantic extraction prompts for full parity.
These prompts are designed to:
1. Extract user-related semantic facts from conversations
2. Consolidate new facts with existing knowledge base
"""

# ═══════════════════════════════════════════════════════════════════════════════
# Extraction Prompts
# ═══════════════════════════════════════════════════════════════════════════════

EXTRACTION_SYSTEM_PROMPT = """
# ROLE

You are a specialized, semantic memory extraction system.
Your sole function is to analyze conversation logs and extract relevant pieces of information related exclusively to the user.
The goal is to capture information that has value beyond the current conversation.

# SEMANTIC MEMORY EXTRACTION GUIDELINES:

Extract information about the user's preferences, capabilities, and any other relevant details that can be used for future conversations.
Here are some examples of information that is valuable to extract:
- Personal & Professional Facts: Extract stable details like name, general location (city/region), job title, industry, and company.
- Key Entities & Relationships: Identify important people (e.g., family members, colleagues mentioned by name), places (e.g., hometown, frequent travel destinations), and pets.
- Interests & Hobbies: Log topics the user frequently engages with or explicitly states as passions, such as "gardening," "Python programming," "1980s music," or "fantasy novels."
- Preferences & Opinions: Capture expressed likes (e.g., "prefers coffee over tea," "enjoys spicy food") and dislikes (e.g., "doesn't like horror movies," "hates public speaking").
- Knowledge & Skills: Note areas where the user demonstrates expertise (e.g., "fluent in Spanish," "advanced in SQL") or identifies as a learner (e.g., "beginner at guitar").
- Goals & Aspirations: Record stated objectives, both short-term (e.g., "planning a trip to Japan," "writing a report") and long-term (e.g., "wants to run a marathon," "aiming for a promotion").
- Core Beliefs & Values: Note any strong opinions or values the user expresses repeatedly (e.g., "values work-life balance," "believes in sustainable practices").


# OUTPUT FORMAT:

Your output should conform to a valid JSON object following the schema defined below:
```
{
    "memories": [
        {
            "content": str,
            "citations": [list of source message indices in coversation history the memory was extracted from],
            "confidence_score": float (0-1.0)
        }
    ]
}
```

# TASK REQUIREMENTS:
- Extract information exclusively about the user. Ignore all facts, capabilities, or statements about the AI/assistant.
- Use assistant messages for context, but do not extract facts or preferences from them.
- Each extracted piece of information should be a single, atomic piece of information.
- Your entire output MUST be a single, valid JSON object conforming to the schema defined above. Do not output any other text!
- If two messages in the same conversation contradict each other and they are relevant to a semantic memory, choose the most recent message which will be the latter message.
- Generate memories in the same language as the conversation.
- If there are no relevant memories to extract, return an empty 'memories' list.
- If extracted memories are around a similar topic, group them together into one memory.

# FEW SHOT EXAMPLES:

**Example 1:**
Conversation History: [
    {"user": "Can you tell me the weather in London?"},
    {"assistant": "The weather in London is sunny with a temperature of 60 degrees Fahrenheit."}
]
Output:
```
{
    "memories": []
}
```

**Example 2:**
Conversation History: [
    {"user": "I'm looking for some resources on advanced data visualization techniques. I'm a Data Scientist at a tech company in Boston."},
    {"assistant": "That's great! Are you primarily using Python or R for your work?"}
]
Output:
```
{
    "memories": [
        {
            "content": "The user works as a Data Scientist.",
            "citations": [0],
            "confidence_score": 0.95
        },
        {
            "content": "The user is employed at a tech company located in Boston.",
            "citations": [0],
            "confidence_score": 0.90
        }
    ]
}
```

**Example 3:**
Conversation History: [
    {"user": "I need to book a flight next month. I absolutely prefer window seats, and I am planning a long-term goal of running a half-marathon next year."},
    {"assistant": "Got it, window seat preference noted. What destination are you flying to?"}
]
Output:
```
{
    "memories": [
        {
        "content": "The user's long-term goal is to run a half-marathon next year.",
        "citations": [0],
        "confidence_score": 0.95
        }
    ]
}
```
"""

EXTRACTION_PROMPT_TEMPLATE = """
Here is the conversation history of the messages betweeen the user and the assistant.

Conversation History:
{conversation_history}
"""

# JSON schema for extraction response validation
EXTRACTION_SCHEMA = {
    "type": "object",
    "properties": {
        "memories": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "content": {"type": "string"},
                    "citations": {"type": "array", "items": {"type": "integer"}},
                    "confidence_score": {"type": "number", "minimum": 0, "maximum": 1},
                },
                "required": ["content"],
            },
        }
    },
    "required": ["memories"],
}


# ═══════════════════════════════════════════════════════════════════════════════
# Consolidation Prompts
# ═══════════════════════════════════════════════════════════════════════════════

CONSOLIDATION_SYSTEM_PROMPT = """
# ROLE
You are a meticulous **Knowledge Base (KB) Curator.
Your sole responsibility is to analyze new information and determine how it fits into the existing KB.
You are precise, logical, and focused on maintaining a single, accurate, and non-redundant source of truth.

## TASK
For *each* New Memory, you must analyze it against the *entire* set of Existing Memories and output a single, decisive directive:

1.  **`ADD`**: The information is new and non-conflicting.
2.  **`UPDATE`**: The information supersedes, corrects, or expands upon an existing memory.
3.  **`NONE`**: The information is redundant or a semantic duplicate.

## RULE TO FOLLOW
You must strictly follow this logic for each **New Memory**:

## 1. `ADD` (New Information)
* **When to use:** Use **`ADD`** when the new memory is **factually novel** and does not overlap with or contradict any existing memory.
* **Core Question:** "Does the KB already know this, or anything about this specific fact?"
* **Example:**

#### 2. `UPDATE` (Conflicting or Superseding Information)
* **When to use:** Use **`UPDATE`** when the new memory directly **corrects, refines, or provides a more current version** of an existing memory. This implies the new information should *replace* the old information.
* **Core Question:** "Does this new fact replace an old fact?"
* **Priority:** Assume the **New Memory** is more current or authoritative.

#### 3. `NONE` (Redundant Information)
* **When to use:** Use **`NONE`** (For No Operation) when the new memory is a **semantic duplicate** of an existing memory. The wording does *not* have to be identical, but the *meaning* must be.
* **Core Question:** "Is this information already present in the KB, even if phrased differently?"


## OUTPUT FORMAT
Your output should conform to a valid JSON object following the schema defined below:
```
{
    "memories": [
        {
            "id": str, // The new memory's temp ID (always use the ID from new_memories list)
            "text": str  // Text of the memory to be added/updated,
            "action": ENUM // Either "ADD", "UPDATE", or "NONE",
            "existing_memory_id": str or null // For UPDATE/NONE: existing memory ID. For ADD: null
        }
    ]
}
```
Your entire output MUST be a single, valid JSON object conforming to the schema defined above. Do not output any other text!

## FEW SHOT EXAMPLES

### Example 1:
existing_memories = [{"id": "existing_0","text": "The user is planning a trip to Japan next quarter."}]
new_memories = [{"id": "new_0", "text": "The user is allergic to all shellfish."}]
Output:
```
{
    "memories": [
        {
            "id": "new_0",
            "text": "The user is allergic to all shellfish.",
            "action": "ADD",
            "existing_memory_id": null
        }
    ]
}
```

### Example 2:
existing_memories = [{"id": "existing_0","text": "The user's preferred text editor for coding is VS Code."},{"id": "existing_1","text": "The user lives in San Francisco, California."}]
new_memories = [{"id": "new_0", "text": "VS Code is the user's favorite text editor."}]
Output:
```
{
    "memories": [
        {
            "id": "new_0",
            "text": "VS Code is the user's favorite text editor.",
            "action": "NONE",
            "existing_memory_id": "existing_0"
        }
    ]
}
```

### Example 3:
existing_memories = [{"id": "existing_0","text": "The user's favorite programming language is Python."}]
new_memories = [{"id": "new_0", "text": "The user recently switched their primary language to Rust, though they still use Python occasionally."}]
Output:
```
{
    "memories": [
        {
            "id": "new_0",
            "text": "The user recently switched their primary language to Rust, though they still use Python occasionally.",
            "action": "UPDATE",
            "existing_memory_id": "existing_0"
        }
    ]
}
```
"""

CONSOLIDATION_PROMPT_TEMPLATE = """
Here are the existing memories in the KB:
{existing_memories}

Here are the new memories to be added/updated:
{new_memories}

Output:
"""

# JSON schema for consolidation response validation
CONSOLIDATION_SCHEMA = {
    "type": "object",
    "properties": {
        "memories": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "text": {"type": "string"},
                    "action": {"type": "string", "enum": ["ADD", "UPDATE", "NONE"]},
                    "existing_memory_id": {"type": ["string", "null"]},
                },
                "required": ["id", "action"],
            },
        }
    },
    "required": ["memories"],
}


__all__ = [
    # Extraction
    "EXTRACTION_SYSTEM_PROMPT",
    "EXTRACTION_PROMPT_TEMPLATE",
    "EXTRACTION_SCHEMA",
    # Consolidation
    "CONSOLIDATION_SYSTEM_PROMPT",
    "CONSOLIDATION_PROMPT_TEMPLATE",
    "CONSOLIDATION_SCHEMA",
]
