"""
Search / vector index descriptors for ``mongomem_core`` collections.

This module mirrors the Atlas Search / vector index usage in the legacy
ExoMemory ``init_collections`` module, but keeps the representation
**purely structural** so it can be inspected and tested without a live
database.

The focus is on providing a stable type surface and registry:

* ``SearchIndexDefinition`` – value object describing a single search index.
* ``ENGINE_SEARCH_INDEXES`` – mapping of collection name → search indexes for
  the engine-domain memory collections.
* ``iter_engine_search_indexes`` – iterator used by bootstrap helpers to
  materialise search indexes.
"""

from __future__ import annotations

import copy
import logging
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Literal, Mapping, Sequence

from .collections import (
    EpisodicMemoryCollection,
    ProceduralMemoryCollection,
    SemanticMemoryCollection,
    SnapshotMemoryCollection,
    TaxonomicMemoryCollection,
)

logger = logging.getLogger(__name__)

SearchIndexType = Literal["search", "vectorSearch"]


def _vector_field(
    path: str = "embedding",
    similarity: str = "cosine",
    num_dimensions: int = 1536,
) -> Dict[str, Any]:
    """
    Create a vector field definition for Atlas Vector Search.

    Args:
        path: The document field path containing the vector.
        similarity: Similarity metric ("cosine", "euclidean", or "dotProduct").
        num_dimensions: Vector dimensions.

    Returns:
        A dict suitable for use in a vectorSearch index definition.
    """
    return {
        "type": "vector",
        "path": path,
        "similarity": similarity,
        "numDimensions": num_dimensions,
    }


def _filter_field(path: str) -> Dict[str, str]:
    """
    Create a filter field definition for Atlas Vector Search.

    Args:
        path: The document field path to use for filtering.

    Returns:
        A dict suitable for use in a vectorSearch index definition.
    """
    return {"type": "filter", "path": path}


# Common RBAC filter fields used across all memory vector indexes
RBAC_FILTER_FIELDS: List[Dict[str, str]] = [
    _filter_field("visibility"),
    _filter_field("user_id"),
    _filter_field("org_id"),
    _filter_field("project_id"),
    _filter_field("agent_id"),
]


@dataclass(frozen=True)
class SearchIndexDefinition:
    """
    Structural description of an Atlas Search / vector index.

    This is intentionally a light wrapper around the parameters used with
    :class:`pymongo.operations.SearchIndexModel`, keeping the definition as
    plain data so it can be inspected without a live database.
    """

    #: Target collection name.
    collection_name: str
    #: Index name as seen in MongoDB.
    name: str
    #: Atlas Search index type, e.g. ``"search"`` or ``"vectorSearch"``.
    index_type: SearchIndexType
    #: Raw index definition document (``fields``, mappings, etc.).
    definition: Mapping[str, Any]
    #: Optional human-readable comment about the index purpose.
    comment: str | None = None

    def to_model_kwargs(
        self,
        embedding_dimension: int | None = None,
    ) -> Dict[str, Any]:
        """
        Render this definition into kwargs for :class:`SearchIndexModel`.

        ``SearchIndexModel`` typically accepts ``definition``, ``name`` and
        ``type``; we keep the mapping here so callers do not reach into the
        dataclass attributes directly.

        Args:
            embedding_dimension: Optional override for vector field dimensions.
                If provided, replaces ``numDimensions`` in all vector fields.
                If None, uses the dimensions already in the definition.

        Returns:
            Dict with ``definition``, ``name``, and ``type`` keys suitable for
            passing to ``SearchIndexModel(**kwargs)``.
        """
        # Deep copy the entire definition to ensure nested mutable structures
        # (like lists and dicts within 'fields') are not shared with the
        # frozen dataclass instance.
        definition_copy = copy.deepcopy(dict(self.definition))

        if self.index_type == "vectorSearch" and embedding_dimension is not None:
            self._override_dimensions(definition_copy, embedding_dimension)

        return {
            "definition": definition_copy,
            "name": self.name,
            "type": self.index_type,
        }

    def _override_dimensions(
        self,
        definition: Dict[str, Any],
        embedding_dimension: int,
    ) -> None:
        """
        Override embedding dimensions in vector fields.

        Modifies ``definition`` in place.

        Args:
            definition: The mutable definition dict to modify.
            embedding_dimension: The dimension value to set.
        """
        fields = definition.get("fields", [])
        for field in fields:
            if field.get("type") == "vector":
                field["numDimensions"] = embedding_dimension
                logger.debug(
                    "Set numDimensions=%d for vector field '%s' in index '%s'",
                    embedding_dimension,
                    field.get("path", "unknown"),
                    self.name,
                )


# ---------------------------------------------------------------------------
# Engine search / vector index descriptors
# ---------------------------------------------------------------------------


EPISODIC_VECTOR_INDEX = SearchIndexDefinition(
    collection_name=EpisodicMemoryCollection.name,
    name="epi_embedding_vector_index",
    index_type="vectorSearch",
    definition={
        "fields": [
            _vector_field(),
            *RBAC_FILTER_FIELDS,
            _filter_field("session_id"),
            _filter_field("deleted"),
            _filter_field("is_latest"),
            _filter_field("publishing.published"),
            _filter_field("publishing.revoked_at"),
            _filter_field("publishing.published_scope"),
            _filter_field("publishing.published_by_project"),
        ]
    },
    comment="Vector search index for episodic memory embeddings",
)


SEMANTIC_VECTOR_INDEX = SearchIndexDefinition(
    collection_name=SemanticMemoryCollection.name,
    name="sem_embedding_vector_index",
    index_type="vectorSearch",
    definition={
        "fields": [
            _vector_field(),
            *RBAC_FILTER_FIELDS,
            _filter_field("deleted"),
            _filter_field("is_latest"),
            _filter_field("publishing.published"),
            _filter_field("publishing.revoked_at"),
            _filter_field("publishing.published_scope"),
            _filter_field("publishing.published_by_project"),
        ]
    },
    comment="Vector search index for semantic memory embeddings",
)


SNAPSHOT_VECTOR_INDEX = SearchIndexDefinition(
    collection_name=SnapshotMemoryCollection.name,
    name="snap_embedding_vector_index",
    index_type="vectorSearch",
    definition={
        "fields": [
            _vector_field(),
            *RBAC_FILTER_FIELDS,
            _filter_field("session_id"),
            _filter_field("timestamp"),
            _filter_field("has_embedding"),
            _filter_field("deleted"),
            _filter_field("promoted"),
        ]
    },
    comment="Vector search index for snapshot embeddings with cross-session retrieval support",
)


TAXONOMIC_VECTOR_INDEX = SearchIndexDefinition(
    collection_name=TaxonomicMemoryCollection.name,
    name="tax_embedding_vector_index",
    index_type="vectorSearch",
    definition={
        "fields": [
            _vector_field(),
            *RBAC_FILTER_FIELDS,
            _filter_field("domain"),
            _filter_field("deleted"),
            _filter_field("is_latest"),
            _filter_field("publishing.published"),
            _filter_field("publishing.revoked_at"),
            _filter_field("publishing.published_scope"),
            _filter_field("publishing.published_by_project"),
        ]
    },
    comment="Vector search index for taxonomic term embeddings",
)


SEMANTIC_TEXT_INDEX = SearchIndexDefinition(
    collection_name=SemanticMemoryCollection.name,
    name="sem_text_search_index",
    index_type="search",
    definition={
        "mappings": {
            "dynamic": True,
            "fields": {
                "org_id": {"type": "token"},
                "user_id": {"type": "token"},
                "visibility": {"type": "token"},
                "project_id": {"type": "token"},
            },
        }
    },
    comment="Atlas Search text index for semantic memory with RBAC filters",
)


EPISODIC_TEXT_INDEX = SearchIndexDefinition(
    collection_name=EpisodicMemoryCollection.name,
    name="epi_text_search_index",
    index_type="search",
    definition={
        "mappings": {
            "dynamic": True,
            "fields": {
                "org_id": {"type": "token"},
                "user_id": {"type": "token"},
                "visibility": {"type": "token"},
                "project_id": {"type": "token"},
            },
        }
    },
    comment="Atlas Search text index for episodic memory with RBAC filters",
)


SNAPSHOT_TEXT_INDEX = SearchIndexDefinition(
    collection_name=SnapshotMemoryCollection.name,
    name="snap_text_search_index",
    index_type="search",
    definition={
        "mappings": {
            "dynamic": True,
            "fields": {
                "org_id": {"type": "token"},
                "user_id": {"type": "token"},
                "visibility": {"type": "token"},
                "project_id": {"type": "token"},
                "session_id": {"type": "token"},
            },
        }
    },
    comment="Atlas Search text index for snapshot memory with RBAC and session filters",
)


TAXONOMIC_TEXT_INDEX = SearchIndexDefinition(
    collection_name=TaxonomicMemoryCollection.name,
    name="tax_text_search_index",
    index_type="search",
    definition={
        "mappings": {
            "dynamic": True,
            "fields": {
                "org_id": {"type": "token"},
                "user_id": {"type": "token"},
                "visibility": {"type": "token"},
                "project_id": {"type": "token"},
            },
        }
    },
    comment="Atlas Search text index for taxonomic terms with RBAC filters",
)


PROCEDURAL_VECTOR_INDEX = SearchIndexDefinition(
    collection_name=ProceduralMemoryCollection.name,
    name="proc_embedding_vector_index",
    index_type="vectorSearch",
    definition={
        "fields": [
            _vector_field(),
            *RBAC_FILTER_FIELDS,
            _filter_field("tags"),
            _filter_field("deleted"),
            _filter_field("is_latest"),
            _filter_field("publishing.published"),
            _filter_field("publishing.revoked_at"),
            _filter_field("publishing.published_scope"),
            _filter_field("publishing.published_by_project"),
        ]
    },
    comment="Vector search index for procedural memory embeddings",
)


PROCEDURAL_TEXT_INDEX = SearchIndexDefinition(
    collection_name=ProceduralMemoryCollection.name,
    name="proc_text_search_index",
    index_type="search",
    definition={
        "mappings": {
            "dynamic": True,
            "fields": {
                "org_id": {"type": "token"},
                "user_id": {"type": "token"},
                "visibility": {"type": "token"},
                "project_id": {"type": "token"},
                "tags": {"type": "token"},
            },
        }
    },
    comment="Atlas Search text index for procedural memory with RBAC and tag filters",
)


#: Engine-domain search / vector index definitions, keyed by collection name.
ENGINE_SEARCH_INDEXES: Mapping[str, Sequence[SearchIndexDefinition]] = {
    EpisodicMemoryCollection.name: (
        EPISODIC_VECTOR_INDEX,
        EPISODIC_TEXT_INDEX,
    ),
    SemanticMemoryCollection.name: (
        SEMANTIC_VECTOR_INDEX,
        SEMANTIC_TEXT_INDEX,
    ),
    SnapshotMemoryCollection.name: (
        SNAPSHOT_VECTOR_INDEX,
        SNAPSHOT_TEXT_INDEX,
    ),
    TaxonomicMemoryCollection.name: (
        TAXONOMIC_VECTOR_INDEX,
        TAXONOMIC_TEXT_INDEX,
    ),
    ProceduralMemoryCollection.name: (
        PROCEDURAL_VECTOR_INDEX,
        PROCEDURAL_TEXT_INDEX,
    ),
}


def iter_engine_search_indexes() -> Iterable[SearchIndexDefinition]:
    """
    Iterate over all engine-domain search / vector indexes.

    Bootstrap helpers use this to materialise search indexes on a real
    database.
    """

    for defs in ENGINE_SEARCH_INDEXES.values():
        yield from defs
