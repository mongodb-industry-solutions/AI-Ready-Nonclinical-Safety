"""Datetime utilities for consistent timezone handling.

MongoDB stores datetime values without timezone information (timezone-naive).
This module provides utilities to ensure consistent UTC handling throughout
the worker codebase.

Usage:
    from . import ensure_utc, utcnow

    # Get current time as UTC-aware datetime
    now = utcnow()

    # Ensure a datetime from MongoDB is UTC-aware
    created_at = ensure_utc(task.created_at)
"""

from datetime import datetime, timezone

# Re-export from core to avoid duplication
from ...mongomem_core.common.utils import utcnow


def ensure_utc(dt: datetime) -> datetime:
    """Ensure a datetime is UTC-aware.

    MongoDB returns timezone-naive datetimes. This function converts them
    to UTC-aware datetimes for safe comparison with other UTC datetimes.

    If the datetime is already timezone-aware, it's converted to UTC.
    If the datetime is timezone-naive, it's assumed to be UTC and marked as such.

    Args:
        dt: A datetime object (may be timezone-naive or timezone-aware)

    Returns:
        datetime: UTC-aware datetime

    Example:
        >>> from datetime import datetime, timezone
        >>> naive_dt = datetime(2024, 1, 1, 12, 0, 0)
        >>> aware_dt = ensure_utc(naive_dt)
        >>> aware_dt.tzinfo
        datetime.timezone.utc

        >>> utc_dt = datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        >>> ensure_utc(utc_dt) == utc_dt
        True
    """
    if dt.tzinfo is None:
        # Assume timezone-naive datetime from MongoDB is UTC
        return dt.replace(tzinfo=timezone.utc)
    # Convert timezone-aware datetime to UTC
    return dt.astimezone(timezone.utc)


__all__ = ["ensure_utc", "utcnow"]
