"""
Worker identity utilities.

Provides centralized worker ID generation for consistent identification
across the worker codebase.
"""

from __future__ import annotations

import os
import socket
import threading
import uuid
from functools import lru_cache


@lru_cache(maxsize=1)
def get_hostname() -> str:
    """Get the hostname, cached for efficiency."""
    return os.environ.get("HOSTNAME", os.environ.get("POD_NAME", socket.gethostname()))


def generate_worker_id(*, include_thread: bool = False, include_uuid: bool = False) -> str:
    """
    Generate a unique worker ID.

    The ID format depends on the parameters:
    - Default: hostname-pid
    - include_thread: hostname-pid-thread_id
    - include_uuid: hostname-uuid8

    Args:
        include_thread: Include thread ID for per-thread uniqueness
        include_uuid: Use UUID instead of PID (for ephemeral workers)

    Returns:
        Unique worker identifier string
    """
    hostname = get_hostname()

    if include_uuid:
        return f"{hostname}-{uuid.uuid4().hex[:8]}"

    pid = os.getpid()
    if include_thread:
        thread_id = threading.current_thread().ident or 0
        return f"{hostname}-{pid}-{thread_id}"

    return f"{hostname}-{pid}"


__all__ = ["generate_worker_id", "get_hostname"]
