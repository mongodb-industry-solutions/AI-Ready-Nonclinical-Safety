"""
Google Cloud Storage backend for document ingestion.

Handles gs:// URIs, downloading files to temp locations for processing.
"""

import logging
import os
import tempfile
from pathlib import Path
from typing import List, Optional, Set

from mongomem_core.ingest.storage.base import StorageBackend

logger = logging.getLogger(__name__)


class GCSStorage(StorageBackend):
    """
    Google Cloud Storage backend.

    Handles URIs like:
    - gs://bucket/path/to/file.pdf
    - gs://bucket/prefix/ (list files)

    Authentication:
    - Uses GOOGLE_APPLICATION_CREDENTIALS env var if set
    - Otherwise uses default credentials (gcloud auth)

    Example:
        from mongomem_core.ingest.storage import GCSStorage

        gcs = GCSStorage()
        # or with explicit credentials:
        gcs = GCSStorage(credentials_path="/path/to/service-account.json")

        result = engine.ingest_documents(
            paths=["gs://my-bucket/docs/report.pdf"],
            org_id="my-org",
            user_id="sakshi",
            storage_backend=gcs,
        )
    """

    def __init__(
        self,
        credentials_path: Optional[str] = None,
        project_id: Optional[str] = None,
    ):
        """
        Initialize GCS storage backend.

        Args:
            credentials_path: Path to service account JSON file.
                            If None, uses GOOGLE_APPLICATION_CREDENTIALS or default.
            project_id: GCP project ID. If None, uses default from credentials.
        """
        self._credentials_path = credentials_path
        self._project_id = project_id
        self._client = None
        self._temp_files: List[Path] = []

    def _get_client(self):
        """Lazy-load the GCS client."""
        if self._client is None:
            try:
                from google.cloud import storage
            except ImportError:
                raise ImportError(
                    "google-cloud-storage is required for GCS support. "
                    "Install with: pip install 'mongomem[gcs]' or pip install google-cloud-storage"
                )

            if self._credentials_path:
                self._client = storage.Client.from_service_account_json(
                    self._credentials_path,
                    project=self._project_id,
                )
            else:
                self._client = storage.Client(project=self._project_id)

        return self._client

    def supports(self, uri: str) -> bool:
        """Check if URI is a GCS path."""
        return uri.startswith("gs://")

    def _parse_uri(self, uri: str) -> tuple:
        """
        Parse gs://bucket/path into (bucket_name, blob_path).

        Args:
            uri: GCS URI like "gs://bucket/path/to/file.pdf"

        Returns:
            Tuple of (bucket_name, blob_path)
        """
        if not uri.startswith("gs://"):
            raise ValueError(f"Invalid GCS URI (must start with gs://): {uri}")

        # Remove gs:// prefix
        path = uri[5:]

        if "/" not in path:
            # Just bucket name
            return path, ""

        bucket_name, blob_path = path.split("/", 1)
        return bucket_name, blob_path

    def resolve(self, uri: str) -> Path:
        """
        Download file from GCS to a temp location.

        Args:
            uri: GCS URI like "gs://bucket/path/to/file.pdf"

        Returns:
            Path to the downloaded temp file
        """
        client = self._get_client()
        bucket_name, blob_path = self._parse_uri(uri)

        if not blob_path:
            raise ValueError(f"URI must include file path, not just bucket: {uri}")

        bucket = client.bucket(bucket_name)
        blob = bucket.blob(blob_path)

        if not blob.exists():
            raise FileNotFoundError(f"GCS file not found: {uri}")

        # Create temp file with same extension
        suffix = Path(blob_path).suffix or ""
        temp_fd, temp_path_str = tempfile.mkstemp(suffix=suffix, prefix="gcs_")
        os.close(temp_fd)
        temp_path = Path(temp_path_str)

        logger.info("Downloading %s to %s", uri, temp_path)
        blob.download_to_filename(str(temp_path))

        self._temp_files.append(temp_path)
        return temp_path

    def list_files(self, uri: str, extensions: Set[str]) -> List[str]:
        """
        List files in a GCS prefix matching extensions.

        Args:
            uri: GCS prefix like "gs://bucket/prefix/" or "gs://bucket/"
            extensions: Set of extensions to match (e.g., {".pdf", ".txt"})

        Returns:
            List of GCS URIs for matching files
        """
        client = self._get_client()
        bucket_name, prefix = self._parse_uri(uri)

        bucket = client.bucket(bucket_name)

        # Normalize extensions to lowercase
        extensions_lower = {ext.lower() for ext in extensions}

        files = []
        for blob in bucket.list_blobs(prefix=prefix):
            # Skip "directories" (blobs ending with /)
            if blob.name.endswith("/"):
                continue

            # Check extension
            blob_ext = Path(blob.name).suffix.lower()
            if blob_ext in extensions_lower:
                files.append(f"gs://{bucket_name}/{blob.name}")

        logger.info("Found %d files in %s", len(files), uri)
        return sorted(files)

    def cleanup(self, local_path: Path) -> None:
        """
        Remove a temp file created by resolve().

        Args:
            local_path: Path returned by resolve()
        """
        if local_path in self._temp_files:
            try:
                local_path.unlink(missing_ok=True)
                self._temp_files.remove(local_path)
                logger.debug("Cleaned up temp file: %s", local_path)
            except Exception as e:
                logger.warning("Failed to cleanup temp file %s: %s", local_path, e)

    def cleanup_all(self) -> None:
        """Remove all temp files created by this backend."""
        for path in list(self._temp_files):
            try:
                path.unlink(missing_ok=True)
            except Exception as e:
                logger.warning("Failed to cleanup temp file %s: %s", path, e)

        self._temp_files.clear()
        logger.debug("Cleaned up all GCS temp files")
