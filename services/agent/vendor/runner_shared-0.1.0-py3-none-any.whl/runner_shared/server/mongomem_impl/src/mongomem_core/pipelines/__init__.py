"""
High-level pipelines for mongomem_core (write, ingest, maintenance).

These modules orchestrate multi-step data transformation operations
(mutation pipelines), while remaining pure Python + Mongo.

Note: Thread retrieval is in `retrieval/` since it's a read operation.
"""

from .stm_to_snapshot import (
    EmbedderProtocol,
    check_snapshot_thresholds,
    get_sessions_needing_snapshot,
    promote_stm_to_snapshot,
    should_promote,
    transfer_embeddings,
)

__all__ = [
    # STM to Snapshot promotion
    "EmbedderProtocol",
    "should_promote",
    "transfer_embeddings",
    "promote_stm_to_snapshot",
    "check_snapshot_thresholds",
    "get_sessions_needing_snapshot",
]
