"""
Adapters for connecting ObservabilityProtocol to observability backends.

Available adapters:
- OpenTelemetryObservability: Connects to OpenTelemetry SDK

Note: Adapters require additional dependencies. Install with:
    pip install mongomem[opentelemetry]
"""

from __future__ import annotations

try:
    from mongomem_core.observability.adapters.opentelemetry import (
        OTEL_AVAILABLE,
        OpenTelemetryObservability,
    )
except Exception:
    OTEL_AVAILABLE = False
    OpenTelemetryObservability = None  # type: ignore[assignment, misc]

__all__ = ["OpenTelemetryObservability", "OTEL_AVAILABLE"]
