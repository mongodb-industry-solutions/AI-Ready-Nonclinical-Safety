"""Custom exceptions for mongomem_core."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, List, Optional

if TYPE_CHECKING:
    from mongomem_core.modes import MemoryMode

__all__ = [
    "MongoMemError",
    "ConnectionError",
    "DocumentNotFoundError",
    "ValidationError",
    "DatabaseOperationError",
    "DuplicateDocumentError",
    "ConfigurationError",
    "ExtractionError",
    "EmbeddingGenerationError",
    "ModeError",
]


class MongoMemError(Exception):
    """
    Base exception for all mongomem_core errors.

    All custom exceptions in this library inherit from this class, allowing
    callers to catch all library-specific errors with a single except clause.
    """

    def __init__(
        self,
        message: str,
        *,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.details = details or {}

    def __str__(self) -> str:
        if self.details:
            return f"{self.message} | details={self.details}"
        return self.message


class ConnectionError(MongoMemError):
    """
    Raised when a database connection cannot be established.

    This includes initial connection failures, authentication errors,
    and connection pool exhaustion.
    """

    pass


class DocumentNotFoundError(MongoMemError):
    """
    Raised when a requested document does not exist.

    This is used for operations that expect a document to exist (e.g., update)
    rather than queries that may legitimately return no results.
    """

    def __init__(
        self,
        message: str,
        *,
        collection: Optional[str] = None,
        document_id: Optional[str] = None,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        extra_details = details or {}
        if collection:
            extra_details["collection"] = collection
        if document_id:
            extra_details["document_id"] = document_id
        super().__init__(message, details=extra_details)


class ValidationError(MongoMemError):
    """
    Raised when input validation fails.

    This covers both Pydantic validation errors and custom business logic
    validation (e.g., invalid ObjectId format).
    """

    def __init__(
        self,
        message: str,
        *,
        field: Optional[str] = None,
        value: Optional[Any] = None,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        extra_details = details or {}
        if field:
            extra_details["field"] = field
        if value is not None:
            extra_details["value"] = repr(value)
        super().__init__(message, details=extra_details)


class DatabaseOperationError(MongoMemError):
    """
    Raised when a database operation fails unexpectedly.

    This wraps PyMongo errors to provide additional context about
    the operation that failed.
    """

    def __init__(
        self,
        message: str,
        *,
        operation: Optional[str] = None,
        collection: Optional[str] = None,
        original_error: Optional[Exception] = None,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        extra_details = details or {}
        if operation:
            extra_details["operation"] = operation
        if collection:
            extra_details["collection"] = collection
        if original_error:
            extra_details["original_error"] = str(original_error)
            extra_details["original_error_type"] = type(original_error).__name__
        super().__init__(message, details=extra_details)
        self.original_error = original_error


class DuplicateDocumentError(DatabaseOperationError):
    """
    Raised when attempting to create a document that violates uniqueness constraints.

    This typically occurs with idempotency checks or unique indexes.
    """

    pass


class ConfigurationError(MongoMemError):
    """
    Raised when there is a configuration problem.

    This includes missing required settings, invalid setting values,
    or incompatible setting combinations.
    """

    def __init__(
        self,
        message: str,
        *,
        setting: Optional[str] = None,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        extra_details = details or {}
        if setting:
            extra_details["setting"] = setting
        super().__init__(message, details=extra_details)


class EmbeddingGenerationError(MongoMemError):
    """
    Raised when embedding generation fails.

    This covers failures from embedding providers including network errors,
    API rate limits, invalid inputs, or empty embedding responses.
    """

    def __init__(
        self,
        message: str,
        *,
        query: Optional[str] = None,
        original_error: Optional[Exception] = None,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        extra_details = details or {}
        if query:
            extra_details["query"] = query[:100] + "..." if len(query) > 100 else query
        if original_error:
            extra_details["original_error"] = str(original_error)
            extra_details["original_error_type"] = type(original_error).__name__
        super().__init__(message, details=extra_details)
        self.original_error = original_error


class ExtractionError(MongoMemError):
    """
    Raised when memory extraction fails.

    Covers LLM failures, parsing errors, and extraction pipeline issues.
    """

    def __init__(
        self,
        message: str,
        *,
        extraction_type: Optional[str] = None,
        source_id: Optional[str] = None,
        original_error: Optional[Exception] = None,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        extra_details = details or {}
        if extraction_type:
            extra_details["extraction_type"] = extraction_type
        if source_id:
            extra_details["source_id"] = source_id
        if original_error:
            extra_details["original_error"] = str(original_error)
            extra_details["original_error_type"] = type(original_error).__name__
        super().__init__(message, details=extra_details)
        self.original_error = original_error


class ModeError(MongoMemError):
    """
    Raised when an operation is not allowed in the current memory mode.

    This exception provides actionable information about:
    - What mode the engine is currently in
    - Which modes would allow the operation
    - How to fix the issue

    Example:
        >>> engine = MemoryEngine(mode=MemoryMode.TRADITIONAL)
        >>> engine.update_internal_state(...)  # Raises ModeError
        ModeError: update_internal_state() is not available in traditional mode
                   Required: iwm, hybrid
                   Fix: Create engine with mode=MemoryMode.IWM or mode=MemoryMode.HYBRID
    """

    def __init__(
        self,
        message: str,
        *,
        current_mode: "MemoryMode",
        required_modes: List["MemoryMode"],
        method: str,
        fix: Optional[str] = None,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        extra_details = details or {}
        extra_details["current_mode"] = current_mode.value
        extra_details["required_modes"] = [m.value for m in required_modes]
        extra_details["method"] = method

        # Store typed attributes for programmatic access
        self.current_mode = current_mode
        self.required_modes = required_modes
        self.method = method
        self.fix = fix or self._default_fix()

        extra_details["fix"] = self.fix

        super().__init__(message, details=extra_details)

    def _default_fix(self) -> str:
        """Generate default fix message based on required modes."""
        from mongomem_core.modes import MemoryMode

        mode_options = " or ".join(f"mode=MemoryMode.{m.name}" for m in self.required_modes)

        if MemoryMode.IWM in self.required_modes:
            return f"Create engine with {mode_options} to use Internal Working Memory"
        elif MemoryMode.TRADITIONAL in self.required_modes:
            return f"Create engine with {mode_options} to use STM accumulation"
        else:
            return f"Create engine with {mode_options}"

    def __str__(self) -> str:
        modes_str = ", ".join(m.value for m in self.required_modes)
        return (
            f"{self.message}\n"
            f"  Current mode: {self.current_mode.value}\n"
            f"  Required: {modes_str}\n"
            f"  Fix: {self.fix}"
        )
