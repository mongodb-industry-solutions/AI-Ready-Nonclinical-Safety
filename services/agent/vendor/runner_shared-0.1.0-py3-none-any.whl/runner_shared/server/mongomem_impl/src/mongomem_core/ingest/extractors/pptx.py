"""
PowerPoint text extractor using python-pptx.

Handles .pptx files with text extraction from all slides.
"""

import logging
from pathlib import Path
from typing import Any, Dict, Set

logger = logging.getLogger(__name__)


class PythonPPTXExtractor:
    """PowerPoint text extractor using python-pptx."""

    @property
    def supported_extensions(self) -> Set[str]:
        return {".pptx"}

    def extract(self, file_path: Path) -> str:
        """Extract text from all slides of a PowerPoint."""
        from pptx import Presentation

        text_parts = []
        prs = Presentation(str(file_path))  # type: ignore[arg-type]

        for slide_num, slide in enumerate(prs.slides, 1):
            slide_texts = []

            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text.strip():
                    slide_texts.append(shape.text)

            if slide_texts:
                slide_content = f"[Slide {slide_num}]\n" + "\n".join(slide_texts)
                text_parts.append(slide_content)

        return "\n\n".join(text_parts)

    def extract_with_metadata(self, file_path: Path) -> Dict[str, Any]:
        """Extract text and metadata from a PowerPoint."""
        from pptx import Presentation

        prs = Presentation(str(file_path))  # type: ignore[arg-type]
        text = self.extract(file_path)

        # Get core properties if available
        props = prs.core_properties

        return {
            "text": text,
            "metadata": {
                "source_type": "pptx",
                "slide_count": len(prs.slides),
                "title": props.title or None,
                "author": props.author or None,
                "subject": props.subject or None,
            },
        }
