"""
Pure scoring functions for extraction validation.

No external dependencies - easily testable without mocks.
Matches ExoMemory's _validate_and_score_memory() behavior.
"""

from __future__ import annotations

from typing import List, Union

from mongomem_core.extraction.config import (
    EpisodicExtractionConfig,
    ExtractionConfigProtocol,
    SemanticExtractionConfig,
    TaxonomicExtractionConfig,
)
from mongomem_core.extraction.types import ExtractedItem, ScoredExtraction

# Any config implementing ExtractionConfigProtocol is accepted.
# ProceduralExtractionConfig is not listed explicitly to avoid
# a circular import (procedural/__init__.py imports from this module).
ScoringConfig = Union[
    SemanticExtractionConfig,
    EpisodicExtractionConfig,
    TaxonomicExtractionConfig,
    ExtractionConfigProtocol,
]


def score_extraction(
    extraction: ExtractedItem,
    config: ScoringConfig,
) -> ScoredExtraction:
    """
    Pure function: Validate schema and calculate combined score.

    Port of ExoMemory's _validate_and_score_memory().

    Args:
        extraction: Raw extracted item from LLM
        config: Scoring configuration with weights and thresholds

    Returns:
        ScoredExtraction with is_valid=False if validation fails,
        or is_valid based on threshold comparison if validation passes
    """
    # Schema validation - content must be non-empty
    if not extraction.content or not extraction.content.strip():
        return ScoredExtraction(
            content=extraction.content or "",
            citations=extraction.citations,
            confidence=0.0,
            citation_score=0.0,
            combined_score=0.0,
            is_valid=False,
            cited_text=extraction.cited_text,
            metadata={"validation_error": "empty_content", **extraction.metadata},
        )

    # Score calculation (matching ExoMemory weights)
    citation_score = 1.0 if extraction.citations else 0.0

    # Clamp confidence to [0, 1]
    confidence = max(0.0, min(1.0, extraction.confidence))

    # Combined score using configured weights
    combined = citation_score * config.citation_weight + confidence * config.confidence_weight

    # Determine validity based on threshold
    is_valid = combined >= config.min_combined_score_threshold

    return ScoredExtraction(
        content=extraction.content,
        citations=extraction.citations,
        confidence=confidence,
        citation_score=citation_score,
        combined_score=combined,
        is_valid=is_valid,
        cited_text=extraction.cited_text,
        metadata={
            "llm_confidence_score": confidence,
            **extraction.metadata,
        },
    )


def score_batch(
    extractions: List[ExtractedItem],
    config: ScoringConfig,
) -> List[ScoredExtraction]:
    """
    Score multiple extractions.

    Args:
        extractions: List of raw extracted items
        config: Scoring configuration

    Returns:
        List of scored extractions
    """
    return [score_extraction(e, config) for e in extractions]


def filter_valid(extractions: List[ScoredExtraction]) -> List[ScoredExtraction]:
    """
    Filter to extractions that pass validation and threshold.

    Args:
        extractions: List of scored extractions

    Returns:
        List of extractions where is_valid=True
    """
    return [e for e in extractions if e.is_valid]


def calculate_combined_score(
    citation_score: float,
    confidence_score: float,
    citation_weight: float = 0.6,
    confidence_weight: float = 0.4,
) -> float:
    """
    Calculate weighted combined score.

    Args:
        citation_score: Citation signal score (1.0 if has citations, else 0.0)
        confidence_score: LLM confidence score (0.0-1.0)
        citation_weight: Weight for citation score
        confidence_weight: Weight for confidence score

    Returns:
        Weighted combined score
    """
    return citation_score * citation_weight + confidence_score * confidence_weight


__all__ = [
    "score_extraction",
    "score_batch",
    "filter_valid",
    "calculate_combined_score",
]
