from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, Literal, Optional, cast

from pydantic_settings import BaseSettings, SettingsConfigDict

from ..mongomem_core.extraction.types import ApprovalMode
from .constants import (
    DEFAULT_BATCH_SIZE,
    DEFAULT_DB_NAME,
    DEFAULT_EMBED_THREAD_POOL_SIZE,
    DEFAULT_HEARTBEAT_INTERVAL_SECONDS,
    DEFAULT_IDLE_MAINTENANCE_INTERVAL_SECONDS,
    DEFAULT_IDLE_THRESHOLD_SECONDS,
    DEFAULT_LEASE_SECONDS,
    DEFAULT_MAX_CONCURRENT,
    DEFAULT_MONGO_URI,
    DEFAULT_POLL_INTERVAL_SECONDS,
    DEFAULT_QUEUE_METRICS_INTERVAL_SECONDS,
    DEFAULT_STALE_REQUEUE_INTERVAL_SECONDS,
    DEFAULT_TASK_TIMEOUT,
    DEFAULT_TASK_TIMEOUT_EMBEDDING,
    DEFAULT_TASK_TIMEOUT_ENTITY,
    DEFAULT_TASK_TIMEOUT_EPISODIC,
    DEFAULT_TASK_TIMEOUT_MAINTENANCE,
    DEFAULT_TASK_TIMEOUT_SEMANTIC,
    DEFAULT_TASK_TIMEOUT_SNAPSHOT,
    DEFAULT_TASK_TIMEOUT_TAXONOMIC,
    EXTRACTION_TYPES,
    RESUME_TOKENS_COLLECTION,
)

if TYPE_CHECKING:
    from ..mongomem_core.protocols import LLMProtocol


class WorkerSettings(BaseSettings):
    """
    Environment-based worker configuration.

    Used for connection strings and operational parameters that
    are typically set via environment variables.

    Supports split databases:
    - core_db_name: Database for memory collections (STM, snapshots, etc.)
    - worker_db_name: Database for worker collections (tasks, state, etc.)

    If only db_name is set, both use the same database.

    Note: All defaults are imported from constants.py (single source of truth).
    """

    mongo_uri: str = DEFAULT_MONGO_URI
    db_name: str = DEFAULT_DB_NAME

    # Optional: split databases (if not set, uses db_name for both)
    core_db_name: Optional[str] = None
    worker_db_name: Optional[str] = None

    # Concurrency
    max_concurrent: int = DEFAULT_MAX_CONCURRENT
    batch_size: int = DEFAULT_BATCH_SIZE

    # Polling
    poll_interval_seconds: float = DEFAULT_POLL_INTERVAL_SECONDS

    # Idle detection and maintenance intervals (seconds)
    idle_threshold_seconds: float = DEFAULT_IDLE_THRESHOLD_SECONDS
    idle_maintenance_interval: float = DEFAULT_IDLE_MAINTENANCE_INTERVAL_SECONDS
    stale_requeue_interval: float = DEFAULT_STALE_REQUEUE_INTERVAL_SECONDS
    queue_metrics_interval: float = DEFAULT_QUEUE_METRICS_INTERVAL_SECONDS

    # Embedding thread pool
    embed_thread_pool_size: int = DEFAULT_EMBED_THREAD_POOL_SIZE

    # Task queue settings
    lease_seconds: int = DEFAULT_LEASE_SECONDS
    heartbeat_interval: float = DEFAULT_HEARTBEAT_INTERVAL_SECONDS

    # Change streams
    enable_change_streams: bool = True  # Set False to force polling mode
    resume_token_collection: str = RESUME_TOKENS_COLLECTION

    # Embedding triggers
    # - "auto": use change streams when available, otherwise polling scans
    # - "change_streams": only change streams (no polling scans)
    # - "polling": only polling scans (no change streams)
    # - "both": use change streams + polling safety sweep
    embedding_trigger_mode: Literal["auto", "change_streams", "polling", "both"] = "auto"

    # Pydantic v2 settings configuration
    model_config = SettingsConfigDict(env_prefix="MONGOMEM_WORKER_")

    @property
    def effective_core_db(self) -> str:
        """Get the effective core database name."""
        return self.core_db_name or self.db_name

    @property
    def effective_worker_db(self) -> str:
        """Get the effective worker database name."""
        return self.worker_db_name or self.db_name


@dataclass
class ExtractionConfig:
    """Configuration for a single extraction type."""

    enabled: bool = True
    prompt: Optional[str] = None
    llm: Optional["LLMProtocol"] = None
    batch_size: int = 5
    approval_mode: ApprovalMode = "auto"

    def __post_init__(self) -> None:
        self.approval_mode = _validate_approval_mode(
            self.approval_mode, context="ExtractionConfig.approval_mode"
        )


def _validate_approval_mode(value: Any, *, context: str) -> ApprovalMode:
    if value in ("auto", "manual"):
        return cast(ApprovalMode, value)
    raise ValueError(f"Invalid approval_mode for {context}: {value!r}")


# Default task timeouts dict (uses constants as source of truth)
DEFAULT_TASK_TIMEOUTS: Dict[str, float] = {
    "embedding": DEFAULT_TASK_TIMEOUT_EMBEDDING,
    "snapshot": DEFAULT_TASK_TIMEOUT_SNAPSHOT,
    "taxonomic": DEFAULT_TASK_TIMEOUT_TAXONOMIC,
    "episodic": DEFAULT_TASK_TIMEOUT_EPISODIC,
    "semantic": DEFAULT_TASK_TIMEOUT_SEMANTIC,
    "entity": DEFAULT_TASK_TIMEOUT_ENTITY,
    "preferences": 120.0,  # Preferences extraction
    "maintenance": DEFAULT_TASK_TIMEOUT_MAINTENANCE,
}


@dataclass
class TaskTimeouts:
    """Configurable timeouts per task type."""

    embedding: float = DEFAULT_TASK_TIMEOUT_EMBEDDING
    snapshot: float = DEFAULT_TASK_TIMEOUT_SNAPSHOT
    taxonomic: float = DEFAULT_TASK_TIMEOUT_TAXONOMIC
    episodic: float = DEFAULT_TASK_TIMEOUT_EPISODIC
    semantic: float = DEFAULT_TASK_TIMEOUT_SEMANTIC
    entity: float = DEFAULT_TASK_TIMEOUT_ENTITY
    preferences: float = 120.0  # Preferences extraction timeout
    maintenance: float = DEFAULT_TASK_TIMEOUT_MAINTENANCE
    default: float = DEFAULT_TASK_TIMEOUT

    def get(self, task_type: str) -> float:
        """Get timeout for a task type."""
        return getattr(self, task_type, self.default)


@dataclass
class WorkerConfig:
    """
    Worker-specific configuration.

    Does NOT store embedder/llm - those come from MemoryEngine to avoid
    duplicate validation and ensure single source of truth.

    Supports split databases:
    - core_db_name: Database for memory collections (STM, snapshots, etc.)
    - worker_db_name: Database for worker collections (tasks, state, etc.)

    If only db_name is provided, both use the same database (backward compatible).
    """

    # Connection (inherited from engine, stored here for convenience)
    mongo_uri: str
    db_name: str

    # Optional: split databases
    core_db_name: Optional[str] = None
    worker_db_name: Optional[str] = None

    # Extractions (optional) - llm here is for per-extraction overrides only
    llm: Optional["LLMProtocol"] = None
    taxonomic: ExtractionConfig = field(default_factory=ExtractionConfig)
    episodic: ExtractionConfig = field(default_factory=ExtractionConfig)
    semantic: ExtractionConfig = field(default_factory=ExtractionConfig)
    entity: ExtractionConfig = field(default_factory=ExtractionConfig)
    preferences: ExtractionConfig = field(default_factory=ExtractionConfig)
    procedural: ExtractionConfig = field(default_factory=ExtractionConfig)

    # Worker behavior
    concurrency: int = 5  # Note: MongoMemWorker default, not same as WorkerSettings
    batch_size: int = DEFAULT_BATCH_SIZE
    poll_interval_seconds: float = DEFAULT_POLL_INTERVAL_SECONDS

    # Idle detection and maintenance intervals (seconds)
    idle_threshold_seconds: float = DEFAULT_IDLE_THRESHOLD_SECONDS
    idle_maintenance_interval: float = DEFAULT_IDLE_MAINTENANCE_INTERVAL_SECONDS
    stale_requeue_interval: float = DEFAULT_STALE_REQUEUE_INTERVAL_SECONDS
    queue_metrics_interval: float = DEFAULT_QUEUE_METRICS_INTERVAL_SECONDS

    # Embedding thread pool
    embed_thread_pool_size: int = DEFAULT_EMBED_THREAD_POOL_SIZE

    # Task queue settings
    lease_seconds: int = DEFAULT_LEASE_SECONDS
    heartbeat_interval: float = DEFAULT_HEARTBEAT_INTERVAL_SECONDS

    # Task timeouts
    task_timeouts: TaskTimeouts = field(default_factory=TaskTimeouts)

    # Change streams
    enable_change_streams: bool = True  # Set False to force polling mode
    resume_token_collection: str = RESUME_TOKENS_COLLECTION

    # Embedding trigger mode (see WorkerSettings.embedding_trigger_mode)
    embedding_trigger_mode: Literal["auto", "change_streams", "polling", "both"] = "auto"

    # Auto-extraction: automatically trigger extractions when snapshots are created
    # When True, all enabled extraction types trigger on every new snapshot
    auto_extract_on_snapshot: bool = False

    # Snapshot promotion configuration (thresholds, embedding strategy, etc.)
    snapshot_config: Any = None  # Optional[SnapshotConfig] — typed as Any to avoid import cycle

    # Default approval mode for extractions (can be overridden per-extraction type)
    default_approval_mode: ApprovalMode = "auto"

    @property
    def extraction_mode(self) -> str:
        """
        Get extraction trigger mode.

        Returns:
            "auto" - extractions trigger automatically on new snapshots
            "manual" - OE/platform must call enqueue_task() explicitly
        """
        return "auto" if self.auto_extract_on_snapshot else "manual"

    @property
    def enabled_extractions(self) -> list:
        """List of enabled extraction types."""
        return [t for t in EXTRACTION_TYPES if self.is_extraction_enabled(t)]

    @property
    def effective_core_db(self) -> str:
        """Get the effective core database name (memory collections)."""
        return self.core_db_name or self.db_name

    @property
    def effective_worker_db(self) -> str:
        """Get the effective worker database name (task queue, state)."""
        return self.worker_db_name or self.db_name

    @property
    def is_split_db(self) -> bool:
        """Check if using split databases."""
        return self.effective_core_db != self.effective_worker_db

    def get_extraction_llm(self, extraction_type: str) -> Optional["LLMProtocol"]:
        """Get the LLM for a specific extraction type, falling back to default."""
        config_obj: object | None = getattr(self, extraction_type, None)
        if isinstance(config_obj, ExtractionConfig):
            return config_obj.llm or self.llm
        return self.llm

    def is_extraction_enabled(self, extraction_type: str) -> bool:
        """Check if an extraction type is enabled."""
        config_obj: object | None = getattr(self, extraction_type, None)
        if isinstance(config_obj, ExtractionConfig):
            return config_obj.enabled and (config_obj.llm is not None or self.llm is not None)
        return False

    def get_approval_mode(self, extraction_type: str) -> ApprovalMode:
        """Get approval mode for an extraction type, falling back to default."""
        config_obj: object | None = getattr(self, extraction_type, None)
        if isinstance(config_obj, ExtractionConfig):
            return config_obj.approval_mode
        return self.default_approval_mode

    def __post_init__(self) -> None:
        """Validate config and warn about potential issues."""
        import logging

        logger = logging.getLogger(__name__)

        self.default_approval_mode = _validate_approval_mode(
            self.default_approval_mode, context="WorkerConfig.default_approval_mode"
        )

        # Warn if auto mode is on but no extractions are enabled
        if self.auto_extract_on_snapshot and not self.enabled_extractions:
            logger.warning(
                "auto_extract_on_snapshot=True but no extractions are enabled. "
                "Did you forget to pass an LLM? Use WorkerConfig.auto_extraction() instead."
            )

        # Warn if auto mode is on but change streams are disabled
        if self.auto_extract_on_snapshot and not self.enable_change_streams:
            logger.warning(
                "auto_extract_on_snapshot=True but enable_change_streams=False. "
                "Auto-extraction change streams disabled; worker will fall back to polling (standalone/dev mode)."
            )

    def validate(self) -> list:
        """
        Validate config and return list of issues.

        Returns:
            List of validation issue strings (empty if valid)
        """
        issues = []

        if self.auto_extract_on_snapshot:
            if not self.enabled_extractions:
                issues.append(
                    "Auto mode enabled but no extractions configured. "
                    "Provide an LLM and enable at least one extraction type."
                )
            # Change streams are preferred, but polling fallback exists for standalone/dev.

        return issues

    def summary(self) -> str:
        """
        Get a human-readable summary of the config.

        Returns:
            Multi-line string describing the configuration
        """
        lines = [
            "WorkerConfig:",
            f"  Mode: {self.extraction_mode}",
            f"  Database: {self.effective_core_db}",
        ]

        if self.enabled_extractions:
            lines.append(f"  Enabled extractions: {', '.join(self.enabled_extractions)}")
        else:
            lines.append("  Enabled extractions: none")

        if self.auto_extract_on_snapshot:
            lines.append("  Trigger: Change stream (automatic)")
        else:
            lines.append("  Trigger: Manual (enqueue_task)")

        return "\n".join(lines)

    @classmethod
    def from_dict(
        cls,
        mongo_uri: str,
        db_name: str,
        llm: Optional["LLMProtocol"] = None,
        extraction_config: Optional[Dict[str, Any]] = None,
        task_timeouts: Optional[Dict[str, float]] = None,
        core_db_name: Optional[str] = None,
        worker_db_name: Optional[str] = None,
        **kwargs: Any,
    ) -> "WorkerConfig":
        """Create WorkerConfig from a dictionary of extraction settings."""
        # Convert task_timeouts dict to TaskTimeouts object
        timeouts = TaskTimeouts(**task_timeouts) if task_timeouts else TaskTimeouts()

        config = cls(
            mongo_uri=mongo_uri,
            db_name=db_name,
            llm=llm,
            core_db_name=core_db_name,
            worker_db_name=worker_db_name,
            task_timeouts=timeouts,
            **kwargs,
        )

        if extraction_config:
            for ext_type in EXTRACTION_TYPES:
                if ext_type in extraction_config:
                    ext_settings = extraction_config[ext_type]
                    if isinstance(ext_settings, dict):
                        setattr(config, ext_type, ExtractionConfig(**ext_settings))
                    elif isinstance(ext_settings, ExtractionConfig):
                        setattr(config, ext_type, ext_settings)

        return config

    @classmethod
    def auto_extraction(
        cls,
        mongo_uri: str,
        db_name: str,
        llm: "LLMProtocol",
        extractions: Optional[list] = None,
        embedder: Optional[Any] = None,
        **kwargs: Any,
    ) -> "WorkerConfig":
        """
        Create config with automatic extraction mode.

        Extractions trigger automatically when new snapshots are created.
        This is the "set and forget" mode - no manual task enqueueing needed.

        Example:
            config = WorkerConfig.auto_extraction(
                mongo_uri="mongodb://localhost:27017",
                db_name="memory_db",
                llm=my_llm,
            )
            worker = MongoMemWorker(config, embedder=my_embedder)
            worker.run()  # Extractions happen automatically!

        Args:
            mongo_uri: MongoDB connection string
            db_name: Database name
            llm: LLM for extraction (required)
            extractions: List of extraction types to enable.
                        Defaults to ["semantic"].
                        Valid: semantic, taxonomic, episodic, entity
            embedder: Optional embedder (can also pass to MongoMemWorker)
            **kwargs: Additional WorkerConfig options

        Returns:
            WorkerConfig with auto_extract_on_snapshot=True

        Raises:
            ValueError: If extractions list contains invalid types
        """
        extractions = extractions or ["semantic"]

        # Validate against centralized extraction types
        invalid = set(extractions) - EXTRACTION_TYPES
        if invalid:
            raise ValueError(
                f"Invalid extraction types: {invalid}. Valid options: {EXTRACTION_TYPES}"
            )

        config = cls(
            mongo_uri=mongo_uri,
            db_name=db_name,
            llm=llm,
            auto_extract_on_snapshot=True,
            **kwargs,
        )

        # Explicitly set all extraction types:
        # - Enable those in the extractions list
        # - Disable those NOT in the list (overriding default enabled=True)
        for ext_type in EXTRACTION_TYPES:
            if ext_type in extractions:
                setattr(config, ext_type, ExtractionConfig(enabled=True))
            else:
                setattr(config, ext_type, ExtractionConfig(enabled=False))

        return config

    @classmethod
    def manual(
        cls,
        mongo_uri: str,
        db_name: str,
        llm: Optional["LLMProtocol"] = None,
        **kwargs: Any,
    ) -> "WorkerConfig":
        """
        Create config with manual extraction mode (platform-triggered).

        Extractions only happen when explicitly triggered via enqueue_task().
        Use this when your platform (OE) controls when extraction happens.

        Example:
            config = WorkerConfig.manual(
                mongo_uri="mongodb://localhost:27017",
                db_name="memory_db",
                llm=my_llm,
            )
            worker = MongoMemWorker(config, embedder=my_embedder)
            worker.run()

            # Later, platform triggers extraction:
            enqueue_task("semantic", {"messages": [...], ...})

        Args:
            mongo_uri: MongoDB connection string
            db_name: Database name
            llm: Optional LLM for extraction
            **kwargs: Additional WorkerConfig options

        Returns:
            WorkerConfig with auto_extract_on_snapshot=False
        """
        return cls(
            mongo_uri=mongo_uri,
            db_name=db_name,
            llm=llm,
            auto_extract_on_snapshot=False,
            **kwargs,
        )


__all__ = [
    "ApprovalMode",
    "DEFAULT_TASK_TIMEOUT",
    "DEFAULT_TASK_TIMEOUTS",
    "ExtractionConfig",
    "TaskTimeouts",
    "WorkerConfig",
    "WorkerSettings",
]
