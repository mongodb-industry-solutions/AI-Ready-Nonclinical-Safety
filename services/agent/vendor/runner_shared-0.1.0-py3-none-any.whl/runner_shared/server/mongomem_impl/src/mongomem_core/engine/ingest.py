"""
Document ingestion mixin for MemoryEngine.

Provides:
- ingest_documents(): Synchronous ingestion of documents
- queue_ingestion(): Queue documents for async worker processing
- get_ingestion_status(): Check status of queued ingestion job
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

from mongomem_core.ingest.models import IngestConfig, IngestResult
from mongomem_core.ingest.pipeline import ingest_documents as _ingest_documents
from mongomem_core.ingest.storage import StorageBackend

if TYPE_CHECKING:
    from mongomem_core.engine._protocol import EngineProtocol


class _IngestMixin:
    """Mixin providing document ingestion capabilities."""

    def ingest_documents(
        self: "EngineProtocol",
        paths: List[Union[str, Path]],
        org_id: str,
        user_id: str,
        *,
        config: Optional[IngestConfig] = None,
        visibility: str = "org",
        project_id: Optional[str] = None,
        generate_embeddings: bool = True,
        storage_backend: Optional[StorageBackend] = None,
    ) -> IngestResult:
        """
        Ingest PDF, PPTX, DOCX, and TXT documents into semantic memory.

        Extracts text from files, chunks it using LangChain's RecursiveCharacterTextSplitter,
        and stores as semantic memories using bulk_create_semantic().

        Supported file types:
        - .txt (plain text)
        - .pdf (PDF documents)
        - .pptx (PowerPoint presentations)
        - .docx (Word documents)

        Supported storage backends:
        - Local filesystem (default): "/path/to/file.pdf"
        - Google Cloud Storage: "gs://bucket/path/file.pdf"
        - Directories: "gs://bucket/docs/" or "/local/dir/"

        Args:
            paths: List of file paths or URIs to ingest
            org_id: Organization ID for the memories
            user_id: User ID of the creator
            config: Optional IngestConfig for customizing extraction and chunking
            visibility: Visibility for created memories ("private", "shared", "org")
            project_id: Optional group ID for shared visibility
            generate_embeddings: Whether to generate embeddings synchronously (default True)
            storage_backend: Optional storage backend (defaults to LocalStorage).
                Use GCSStorage for gs:// URIs.

        Returns:
            IngestResult with processing details including:
            - files_processed: Total files attempted
            - files_succeeded: Successfully processed files
            - files_failed: Failed files
            - total_chunks: Total chunks created
            - file_results: Per-file results
            - chunk_ids: List of created chunk IDs

        Example:
            # Local files
            result = engine.ingest_documents(
                paths=["docs/report.pdf", "notes.txt"],
                org_id="my-org",
                user_id="sakshi",
            )
            print(f"Created {result.total_chunks} chunks from {result.files_succeeded} files")

            # GCS files
            from mongomem_core.ingest.storage import GCSStorage

            result = engine.ingest_documents(
                paths=["gs://my-bucket/docs/report.pdf"],
                org_id="my-org",
                user_id="sakshi",
                storage_backend=GCSStorage(),
            )

            # GCS directory (all supported files)
            result = engine.ingest_documents(
                paths=["gs://my-bucket/docs/"],  # Trailing slash = directory
                org_id="my-org",
                user_id="sakshi",
                storage_backend=GCSStorage(),
            )

        Raises:
            ValueError: If on_failure="raise" and a file has unsupported type
            FileNotFoundError: If on_failure="raise" and a file doesn't exist
        """
        return _ingest_documents(
            engine=self,
            paths=paths,
            org_id=org_id,
            user_id=user_id,
            config=config,
            visibility=visibility,
            project_id=project_id,
            storage_backend=storage_backend,
            generate_embeddings=generate_embeddings,
        )

    def queue_ingestion(
        self: "EngineProtocol",
        paths: List[Union[str, Path]],
        org_id: str,
        user_id: str,
        *,
        config: Optional[IngestConfig] = None,
        visibility: str = "org",
        project_id: Optional[str] = None,
        generate_embeddings: bool = True,
    ) -> "QueuedIngestJob":
        """
        Queue documents for async ingestion by the worker.

        Unlike ingest_documents() which blocks until complete, this method
        returns immediately after queuing the job. The worker processes
        the ingestion in the background.

        Args:
            paths: List of file paths to ingest
            org_id: Organization ID for the memories
            user_id: User ID of the creator
            config: Optional IngestConfig for customizing extraction and chunking
            visibility: Visibility for created memories ("private", "shared", "org")
            project_id: Optional group ID for shared visibility
            generate_embeddings: Whether to generate embeddings (default True)

        Returns:
            QueuedIngestJob with job_id for status tracking

        Example:
            # Queue a job
            job = engine.queue_ingestion(
                paths=["docs/large_report.pdf", "slides/deck.pptx"],
                org_id="my-org",
                user_id="sakshi",
            )
            print(f"Queued job: {job.job_id}")

            # Check status later
            status = engine.get_ingestion_status(job.job_id)
            if status.state == "completed":
                print(f"Done! Created {status.total_chunks} chunks")

        Note:
            Requires MongoMemWorker to be running to process the job.
        """
        from ...mongomem_worker.config import WorkerSettings
        from ...mongomem_worker.handlers.ingest import (
            create_ingest_job,
        )
        from ...mongomem_worker.queue import enqueue_task

        # Convert paths to strings
        str_paths = [str(p) for p in paths]

        # Convert config to dict if provided
        config_dict: Optional[Dict[str, Any]] = None
        if config:
            config_dict = {
                "extractor": config.extractor.value,
                "chunker": config.chunker.value,
                "chunk_config": {
                    "max_chunk_size": config.chunk_config.max_chunk_size,
                    "min_chunk_size": config.chunk_config.min_chunk_size,
                    "chunk_overlap": config.chunk_config.chunk_overlap,
                    "encoding_name": config.chunk_config.encoding_name,
                    "discard_small_chunks": config.chunk_config.discard_small_chunks,
                },
                "max_retries": config.max_retries,
                "on_failure": config.on_failure,
                "default_metadata": config.default_metadata,
            }

        # Use the engine's database for job storage (same as worker will use)
        # This ensures jobs are created in the same database the worker reads from
        worker_db = self._db

        # Create job record
        job = create_ingest_job(
            db=worker_db,
            paths=str_paths,
            org_id=org_id,
            user_id=user_id,
            config_dict=config_dict,
            visibility=visibility,
            project_id=project_id,
            generate_embeddings=generate_embeddings,
        )

        # Create worker settings that matches the engine's database
        # This ensures tasks are queued to the same database the worker uses
        worker_settings = WorkerSettings(
            mongo_uri=self.settings.mongo_uri,
            db_name=self.settings.db_name,
        )

        # Enqueue task for worker
        enqueue_task(
            "ingest_documents",
            {
                "job_id": job.job_id,
                "paths": str_paths,
                "org_id": org_id,
                "user_id": user_id,
                "config": config_dict or {},
                "visibility": visibility,
                "project_id": project_id,
                "generate_embeddings": generate_embeddings,
            },
            idempotency_key=f"ingest:{job.job_id}",
            settings=worker_settings,
        )

        return job

    def get_ingestion_status(
        self: "EngineProtocol",
        job_id: str,
    ) -> Optional["IngestJobStatus"]:
        """
        Get the status of a queued ingestion job.

        Args:
            job_id: Job ID returned by queue_ingestion()

        Returns:
            IngestJobStatus with current state and progress, or None if not found

        Example:
            status = engine.get_ingestion_status(job.job_id)
            print(f"State: {status.state}")
            print(f"Progress: {status.files_processed}/{status.total_files}")
            if status.state == "completed":
                print(f"Created {status.total_chunks} chunks")
            elif status.state == "failed":
                print(f"Error: {status.error}")
        """
        from ...mongomem_worker.handlers.ingest import (
            get_ingest_job_status,
        )

        # Use the engine's database (same as where jobs are created)
        return get_ingest_job_status(self._db, job_id)


# Re-export types for convenience
try:
    from ...mongomem_worker.handlers.ingest import (
        IngestJobState as IngestJobState,
    )
    from ...mongomem_worker.handlers.ingest import (
        IngestJobStatus as IngestJobStatus,
    )
    from ...mongomem_worker.handlers.ingest import (
        QueuedIngestJob as QueuedIngestJob,
    )
except ImportError:
    # Worker not installed - async ingestion not available
    IngestJobState = None  # type: ignore
    IngestJobStatus = None  # type: ignore
    QueuedIngestJob = None  # type: ignore
