"""Models for Temporal Knowledge Graph (TKG) entities and edges."""
