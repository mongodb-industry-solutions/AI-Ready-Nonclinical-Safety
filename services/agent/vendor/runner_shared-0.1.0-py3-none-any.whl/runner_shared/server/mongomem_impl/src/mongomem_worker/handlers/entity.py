from __future__ import annotations

import asyncio
import logging
from functools import partial
from typing import TYPE_CHECKING, Any, Dict, Optional

from pymongo.database import Database

from ..circuit_breaker import get_circuit_breaker
from ..constants import CIRCUIT_BREAKER_LLM
from .base import TaskHandler

if TYPE_CHECKING:
    from ...mongomem_core.protocols import LLMProtocol

logger = logging.getLogger(__name__)

DEFAULT_ENTITY_PROMPT = """Extract entities from the following content.

Content:
{content}

Extract all named entities (people, organizations, locations, concepts) mentioned.
For each entity, provide:
- name: The entity name
- type: One of [person, organization, location, concept, product, event]
- context: Brief context about this entity from the content

Return as JSON array:
[{{"name": "...", "type": "...", "context": "..."}}]
"""

ENTITY_SCHEMA = {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "type": {"type": "string"},
            "context": {"type": "string"},
        },
        "required": ["name", "type"],
    },
}


class EntityHandler(TaskHandler):
    """Handler for entity extraction from memory content."""

    task_type = "entity"
    timeout_seconds = 600

    def __init__(
        self,
        db: Database,
        llm: Optional["LLMProtocol"],
        prompt: Optional[str] = None,
    ) -> None:
        self._db = db
        self._llm = llm
        self._prompt = prompt or DEFAULT_ENTITY_PROMPT

    async def handle_task(self, payload: Dict[str, Any]) -> None:
        if self._llm is None:
            logger.warning("LLM not configured for entity extraction")
            return

        content = payload.get("content")
        org_id = payload.get("org_id")
        user_id = payload.get("user_id")
        source_id = payload.get("source_id")
        source_type = payload.get("source_type", "stm")

        if not content or not org_id or not user_id or not source_id:
            logger.warning("Missing required fields in entity extraction task")
            return

        try:
            entities = await self._extract_entities(content)
            await self._store_entities(
                entities=entities,
                org_id=org_id,
                user_id=user_id,
                source_id=source_id,
                source_type=source_type,
            )
            logger.info(
                "Extracted %d entities from %s/%s",
                len(entities),
                source_type,
                source_id,
            )
        except Exception as exc:
            logger.error("Entity extraction failed: %s", exc)
            raise

    async def _extract_entities(self, content: str) -> list[Dict[str, Any]]:
        if self._llm is None:
            return []

        breaker = get_circuit_breaker(CIRCUIT_BREAKER_LLM)
        prompt = self._prompt.format(content=content)
        loop = asyncio.get_running_loop()

        # Circuit breaker protects LLM service calls
        result = await breaker.call_async(
            loop.run_in_executor,
            None,
            partial(self._llm.complete_json, prompt=prompt, schema=ENTITY_SCHEMA),
        )
        return result if isinstance(result, list) else []

    async def _store_entities(
        self,
        entities: list[Dict[str, Any]],
        org_id: str,
        user_id: str,
        source_id: str,
        source_type: str,
    ) -> None:
        """Store extracted entities in TKG.

        TODO: Import and use mongomem_core TKG storage once implemented:

            from ...mongomem_core.tkg import create_tkg_node, create_tkg_edge

            for entity in entities:
                # Create entity node
                node = create_tkg_node(
                    db=self._db,
                    org_id=org_id,
                    node_type=entity.get("type", "concept"),
                    label=entity.get("name"),
                    properties={"context": entity.get("context")},
                    source_id=source_id,
                    source_type=source_type,
                )

                # Optionally create edges to source document
                create_tkg_edge(
                    db=self._db,
                    org_id=org_id,
                    from_node=source_id,
                    to_node=node.id,
                    edge_type="mentions",
                )
        """
        if not entities:
            logger.debug(
                "No entities to store for source=%s org=%s",
                source_id,
                org_id,
            )
            return

        # Future: Replace with mongomem_core.tkg storage calls
        # For now, log the extracted entities (storage not yet implemented)
        logger.warning(
            f"Entity storage not yet implemented. Extracted {len(entities)} entities for "
            f"source={source_id} org={org_id} (entities will not be persisted until TKG is implemented)"
        )
        logger.debug("Extracted entities: %s", entities)


__all__ = ["EntityHandler"]
