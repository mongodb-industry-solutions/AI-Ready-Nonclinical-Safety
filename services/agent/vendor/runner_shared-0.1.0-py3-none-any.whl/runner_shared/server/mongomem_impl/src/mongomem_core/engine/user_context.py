"""User context memory operations for MemoryEngine.

Internal implementation - use MemoryEngine from mongomem_core.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from mongomem_core.exceptions import ValidationError
from mongomem_core.memory.user_prefs import (
    create_user_context,
    delete_user_context,
    get_user_context,
    list_user_context,
    update_user_context,
)
from mongomem_core.models.engine import CreateUserContextResult, DeleteResult
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.user_prefs import (
    UserContextMemoryIn,
    UserContextMemoryOut,
    UserContextMemoryUpdate,
)
from pydantic import ValidationError as PydanticValidationError

if TYPE_CHECKING:
    from mongomem_core.engine._protocol import EngineProtocol

logger = logging.getLogger(__name__)


class _UserContext:
    """User context/preference CRUD operations."""

    def create_user_context(
        self: "EngineProtocol",
        *,
        org_id: str,
        user_id: str,
        tone: str | None = None,
        style: str | None = None,
        language: str | None = None,
        preferred_format: str | None = None,
        source: str | None = None,
        demographic_tags: List[str] | None = None,
        preferences: Dict[str, Any] | None = None,
        visibility: str = "private",
        project_id: str | None = None,
        agent_id: str | None = None,
        extraction_source: str | None = None,
    ) -> CreateUserContextResult:
        """
        Create a user context/preference memory.

        Args:
            tone: Preferred communication tone
            style: Preferred communication style
            language: Preferred language for communication
            preferred_format: Preferred response format
            source: Source of this context
            org_id: Organization ID for multi-tenancy
            user_id: User ID who owns this context
            demographic_tags: Demographic tags for personalization
            preferences: Additional user preferences dict
            visibility: Visibility scope
            project_id: Project ID (required when visibility="shared")
            agent_id: Agent ID if created via agent
            extraction_source: Source type

        Returns:
            CreateUserContextResult with the created document's ID
        """
        logger.debug(
            "Creating user context: tone=%s style=%s org=%s user=%s",
            tone,
            style,
            org_id,
            user_id,
        )

        try:
            context_in = UserContextMemoryIn(
                tone=tone,
                style=style,
                language=language,
                preferred_format=preferred_format,
                source=source,
                demographic_tags=demographic_tags or [],
                preferences=preferences or {},
                visibility=ChunkVisibility(visibility) if visibility else ChunkVisibility.PRIVATE,
                project_id=project_id,
                agent_id=agent_id,
                extraction_source=extraction_source,
            )
        except PydanticValidationError as exc:
            logger.warning(
                "Validation failed for create_user_context: tone=%s errors=%s",
                tone,
                exc.errors(),
            )
            raise ValidationError(
                f"Invalid user context data: {exc}",
                details={"tone": tone, "style": style, "validation_errors": exc.errors()},
            ) from exc

        context_doc = create_user_context(
            db=self._db,
            ctx_in=context_in,
            org_id=org_id,
            user_id=user_id,
        )

        logger.info(
            "User context created: id=%s tone=%s style=%s",
            context_doc.id,
            context_doc.tone,
            context_doc.style,
        )

        return CreateUserContextResult(
            id=str(context_doc.id),
            context_key=f"{tone}_{style}_{language}",
            acknowledged=True,
        )

    def get_user_context(
        self: "EngineProtocol",
        org_id: str,
        user_id: str,
    ) -> Optional[UserContextMemoryOut]:
        """
        Get a user context memory by org_id and user_id.

        Args:
            org_id: Organization ID
            user_id: User ID

        Returns:
            UserContextMemoryOut if found, None otherwise
        """
        return get_user_context(db=self._db, org_id=org_id, user_id=user_id)

    def list_user_context(
        self: "EngineProtocol",
        org_id: str,
        *,
        user_id: Optional[str] = None,
        visibility: Optional[str] = None,
        project_id: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[UserContextMemoryOut]:
        """
        List user context memories for an organization.

        Args:
            org_id: Organization ID
            user_id: Optional filter by user ID
            visibility: Optional filter by visibility
            project_id: Optional filter by group ID
            limit: Maximum number of results

        Returns:
            List of UserContextMemoryOut documents
        """
        vis = ChunkVisibility(visibility) if visibility else None
        return list_user_context(
            db=self._db,
            org_id=org_id,
            user_id=user_id,
            visibility=vis,
            project_id=project_id,
            limit=limit,
        )

    def update_user_context(
        self: "EngineProtocol",
        org_id: str,
        user_id: str,
        *,
        tone: Optional[str] = None,
        style: Optional[str] = None,
        language: Optional[str] = None,
        preferred_format: Optional[str] = None,
        demographic_tags: Optional[List[str]] = None,
        preferences: Optional[Dict[str, Any]] = None,
        source: Optional[str] = None,
        timezone: Optional[str] = None,
    ) -> Optional[UserContextMemoryOut]:
        """
        Update a user context memory.

        Args:
            org_id: Organization ID
            user_id: User ID
            tone: New tone preference
            style: New style preference
            language: New language code
            preferred_format: New format preference
            demographic_tags: New demographic tags
            preferences: New preferences dict
            source: New source
            timezone: New timezone

        Returns:
            Updated UserContextMemoryOut or None if not found
        """
        update_model = UserContextMemoryUpdate(
            tone=tone,
            style=style,
            language=language,
            preferred_format=preferred_format,
            demographic_tags=demographic_tags,
            preferences=preferences,
            source=source,
            timezone=timezone,
        )
        return update_user_context(
            db=self._db,
            org_id=org_id,
            user_id=user_id,
            update=update_model,
        )

    def delete_user_context(
        self: "EngineProtocol",
        org_id: str,
        user_id: str,
    ) -> DeleteResult:
        """
        Delete a user context memory.

        Note: User context only supports hard delete.

        Args:
            org_id: Organization ID
            user_id: User ID

        Returns:
            DeleteResult with deleted_count
        """
        result = delete_user_context(db=self._db, org_id=org_id, user_id=user_id)
        logger.info(
            "Deleted user context: org=%s user=%s count=%d",
            org_id,
            user_id,
            result.deleted_count,
        )
        return DeleteResult(deleted_count=result.deleted_count, acknowledged=True)
