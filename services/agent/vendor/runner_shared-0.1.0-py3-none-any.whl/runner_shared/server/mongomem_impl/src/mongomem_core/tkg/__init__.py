"""
Temporal Knowledge Graph (TKG) storage and queries for mongomem_core.

This package will host low-level graph operations, query helpers, and links
between TKG entities/edges and memory documents.
"""
