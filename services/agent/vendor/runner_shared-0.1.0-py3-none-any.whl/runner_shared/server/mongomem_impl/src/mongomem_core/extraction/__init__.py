"""
Extraction pipelines for mongomem_core.

This package contains:
- Default extraction prompts (headless, framework-agnostic)
- LLM-heavy flows (semantic/episodic extraction, prefs, TKG)
- Job tracking and prompt building utilities
"""

# Types
# Base
from mongomem_core.extraction.base import BaseExtractor, ExtractorProtocol

# Config
from mongomem_core.extraction.config import (
    EpisodicExtractionConfig,
    SemanticExtractionConfig,
    TaxonomicExtractionConfig,
)

# Consolidation
from mongomem_core.extraction.consolidator import (
    ConsolidationStrategy,
    Consolidator,
    LLMBasedStrategy,
    MemoryIdMapper,
    RuleBasedStrategy,
)

# Pipeline components
from mongomem_core.extraction.enrichment import enrich_citations, enrich_single

# Episodic pipeline
from mongomem_core.extraction.episodic import (
    EpisodicExtractor,
    EpisodicPipeline,
    create_episodic_pipeline,
)
from mongomem_core.extraction.persistence import (
    apply_decisions,
    generate_extraction_id,
    generate_semantic_label,
    perform_add,
    perform_reinforce,
    perform_update,
)

# Preferences pipeline
from mongomem_core.extraction.preferences import (
    ExtractedPreferences,
    PreferencesExtractionConfig,
    PreferencesExtractionResult,
    PreferencesExtractor,
    PreferencesPipeline,
    create_preferences_pipeline,
)

# Procedural pipeline
from mongomem_core.extraction.procedural import (
    ProceduralExtractor,
    ProceduralPipeline,
    create_procedural_pipeline,
)
from mongomem_core.extraction.procedural.config import ProceduralExtractionConfig
from mongomem_core.extraction.procedural.persistence import (
    apply_procedural_decisions,
    generate_procedural_extraction_id,
    perform_procedural_add,
    perform_procedural_reinforce,
    perform_procedural_update,
)

# Prompts
from mongomem_core.extraction.prompts import (
    DEFAULT_EXTRACTION_PROMPTS,
    EPISODIC_EXTRACTION_PROMPT,
    PREFERENCES_EXTRACTION_PROMPT,
    PROCEDURAL_EXTRACTION_PROMPT,
    SEMANTIC_EXTRACTION_PROMPT,
    TAXONOMIC_EXTRACTION_PROMPT,
    ExtractionType,
    get_extraction_prompt,
)
from mongomem_core.extraction.scorer import (
    calculate_combined_score,
    filter_valid,
    score_batch,
    score_extraction,
)

# Semantic pipeline
from mongomem_core.extraction.semantic import (
    SemanticExtractor,
    SemanticPipeline,
    create_semantic_pipeline,
)

# Taxonomic pipeline
from mongomem_core.extraction.taxonomic import (
    ExtractedTerm,
    TaxonomicExtractionResult,
    TaxonomicExtractor,
    TaxonomicPipeline,
    create_taxonomic_pipeline,
    filter_valid_taxonomic,
    score_taxonomic_batch,
    score_taxonomic_extraction,
)
from mongomem_core.extraction.taxonomic.persistence import (
    apply_taxonomic_decisions,
    generate_taxonomic_extraction_id,
    perform_taxonomic_add,
    perform_taxonomic_update,
    perform_taxonomic_upsert,
)
from mongomem_core.extraction.types import (
    ConsolidationAction,
    ConsolidationDecision,
    ConsolidationStats,
    ExtractedItem,
    ExtractionMetadata,
    ExtractionResult,
    PersistenceResult,
    ScoredExtraction,
    SimilarMatch,
)

__all__ = [
    # Types
    "ConsolidationAction",
    "ConsolidationDecision",
    "ConsolidationStats",
    "ExtractedItem",
    "ExtractionMetadata",
    "ExtractionResult",
    "PersistenceResult",
    "ScoredExtraction",
    "SimilarMatch",
    # Base
    "BaseExtractor",
    "ExtractorProtocol",
    # Config
    "EpisodicExtractionConfig",
    "SemanticExtractionConfig",
    "TaxonomicExtractionConfig",
    # Consolidation
    "ConsolidationStrategy",
    "Consolidator",
    "LLMBasedStrategy",
    "MemoryIdMapper",
    "RuleBasedStrategy",
    # Enrichment
    "enrich_citations",
    "enrich_single",
    # Persistence
    "apply_decisions",
    "generate_extraction_id",
    "generate_semantic_label",
    "perform_add",
    "perform_reinforce",
    "perform_update",
    # Scorer
    "calculate_combined_score",
    "filter_valid",
    "score_batch",
    "score_extraction",
    # Episodic pipeline
    "EpisodicExtractor",
    "EpisodicPipeline",
    "create_episodic_pipeline",
    # Semantic pipeline
    "SemanticExtractor",
    "SemanticPipeline",
    "create_semantic_pipeline",
    # Taxonomic pipeline
    "ExtractedTerm",
    "TaxonomicExtractor",
    "TaxonomicPipeline",
    "create_taxonomic_pipeline",
    "score_taxonomic_extraction",
    "score_taxonomic_batch",
    "filter_valid_taxonomic",
    # Taxonomic persistence
    "generate_taxonomic_extraction_id",
    "perform_taxonomic_add",
    "perform_taxonomic_update",
    "perform_taxonomic_upsert",
    "apply_taxonomic_decisions",
    # Procedural pipeline
    "ProceduralExtractionConfig",
    "ProceduralExtractor",
    "ProceduralPipeline",
    "create_procedural_pipeline",
    # Procedural persistence
    "generate_procedural_extraction_id",
    "perform_procedural_add",
    "perform_procedural_update",
    "perform_procedural_reinforce",
    "apply_procedural_decisions",
    # Preferences pipeline
    "ExtractedPreferences",
    "PreferencesExtractionConfig",
    "PreferencesExtractionResult",
    "PreferencesPipeline",
    "PreferencesExtractor",
    "create_preferences_pipeline",
    # Taxonomic config and result (not duplicated above)
    "TaxonomicExtractionConfig",
    "TaxonomicExtractionResult",
    # Prompts
    "ExtractionType",
    "DEFAULT_EXTRACTION_PROMPTS",
    "EPISODIC_EXTRACTION_PROMPT",
    "PREFERENCES_EXTRACTION_PROMPT",
    "PROCEDURAL_EXTRACTION_PROMPT",
    "SEMANTIC_EXTRACTION_PROMPT",
    "TAXONOMIC_EXTRACTION_PROMPT",
    "get_extraction_prompt",
]
