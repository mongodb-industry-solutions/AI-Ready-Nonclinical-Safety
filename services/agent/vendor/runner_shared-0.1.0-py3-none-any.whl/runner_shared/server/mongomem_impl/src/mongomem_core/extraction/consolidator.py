"""
Consolidator with strategy pattern for deciding ADD/UPDATE/REINFORCE/DUPLICATE.

Includes MemoryIdMapper to prevent LLM hallucination of ObjectIDs,
and both rule-based and LLM-based consolidation strategies.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Protocol,
    Set,
)

if TYPE_CHECKING:
    from mongomem_core.protocols import EmbedderProtocol, LLMProtocol
    from pymongo.database import Database

from mongomem_core.extraction.config import ExtractionConfigProtocol
from mongomem_core.extraction.types import (
    ConsolidationDecision,
    ScoredExtraction,
    SimilarMatch,
)

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
# Memory ID Mapper - prevents LLM hallucination of ObjectIDs
# ═══════════════════════════════════════════════════════════════════════════════


@dataclass
class MemoryIdMapper:
    """
    Maps ObjectIDs to temp IDs to prevent LLM hallucination.

    Port of ExoMemory's MemoryIdMapper.

    - existing_to_temp: ObjectID → "existing_0"
    - temp_to_existing: "existing_0" → ObjectID
    - new_to_data: "new_0" → ScoredExtraction
    """

    existing_to_temp: Dict[str, str] = field(default_factory=dict)
    temp_to_existing: Dict[str, str] = field(default_factory=dict)
    new_to_data: Dict[str, ScoredExtraction] = field(default_factory=dict)

    @classmethod
    def create(
        cls,
        existing_memories: List[SimilarMatch],
        new_extractions: List[ScoredExtraction],
    ) -> "MemoryIdMapper":
        """
        Create mapper from memory lists.

        Args:
            existing_memories: Similar existing memories from search
            new_extractions: New extractions to consolidate

        Returns:
            Configured MemoryIdMapper
        """
        # Map existing memories to temp IDs
        existing_to_temp = {mem.id: f"existing_{idx}" for idx, mem in enumerate(existing_memories)}
        temp_to_existing = {v: k for k, v in existing_to_temp.items()}

        # Map new extractions to temp IDs
        new_to_data = {}
        for idx, extraction in enumerate(new_extractions):
            temp_id = f"new_{idx}"
            new_to_data[temp_id] = extraction

        return cls(
            existing_to_temp=existing_to_temp,
            temp_to_existing=temp_to_existing,
            new_to_data=new_to_data,
        )

    @property
    def valid_new_ids(self) -> Set[str]:
        """Get set of valid new memory temp IDs."""
        return set(self.new_to_data.keys())

    @property
    def valid_existing_ids(self) -> Set[str]:
        """Get set of valid existing memory temp IDs."""
        return set(self.temp_to_existing.keys())

    def get_new_extraction(self, temp_id: str) -> Optional[ScoredExtraction]:
        """Get new extraction by temp ID."""
        return self.new_to_data.get(temp_id)

    def resolve_existing_id(self, temp_id: str) -> Optional[str]:
        """Convert temp existing ID back to original ObjectID."""
        return self.temp_to_existing.get(temp_id)


# ═══════════════════════════════════════════════════════════════════════════════
# Consolidation Strategies
# ═══════════════════════════════════════════════════════════════════════════════


class ConsolidationStrategy(Protocol):
    """Protocol for consolidation decision strategies."""

    def decide(
        self,
        extraction: ScoredExtraction,
        similar: List[SimilarMatch],
    ) -> ConsolidationDecision:
        """Decide action for a single extraction."""
        ...


class RuleBasedStrategy:
    """
    Rule-based consolidation (no LLM required).

    - similarity >= reinforce_threshold: REINFORCE (same fact)
    - similarity >= update_threshold: UPDATE (related, merge/update)
    - else: ADD (new information)
    """

    def __init__(
        self,
        reinforce_threshold: float = 0.95,
        update_threshold: float = 0.85,
    ) -> None:
        self._reinforce_threshold = reinforce_threshold
        self._update_threshold = update_threshold

    def decide(
        self,
        extraction: ScoredExtraction,
        similar: List[SimilarMatch],
    ) -> ConsolidationDecision:
        """
        Decide action based on similarity thresholds.

        Args:
            extraction: Scored extraction to decide on
            similar: Similar existing memories from search

        Returns:
            ConsolidationDecision with appropriate action
        """
        if not similar:
            return ConsolidationDecision(
                extraction=extraction,
                action="ADD",
                reason="no similar memories found",
            )

        # Find best match
        best = max(similar, key=lambda s: s.score)

        if best.score >= self._reinforce_threshold:
            return ConsolidationDecision(
                extraction=extraction,
                action="REINFORCE",
                existing_id=best.id,
                reason=f"similarity {best.score:.3f} >= reinforce threshold {self._reinforce_threshold}",
            )
        elif best.score >= self._update_threshold:
            return ConsolidationDecision(
                extraction=extraction,
                action="UPDATE",
                existing_id=best.id,
                reason=f"similarity {best.score:.3f} >= update threshold {self._update_threshold}",
            )

        return ConsolidationDecision(
            extraction=extraction,
            action="ADD",
            reason=f"similarity {best.score:.3f} below thresholds",
        )


class LLMBasedStrategy:
    """
    LLM-based consolidation with ID mapping and response validation.

    Port of ExoMemory's SemanticConsolidation.consolidate_memories().
    Uses temp IDs to prevent LLM hallucination of ObjectIDs.
    """

    def __init__(
        self,
        llm: "LLMProtocol",
        prompt_resolver: Optional[Callable[[], Optional[str]]] = None,
    ) -> None:
        self._llm = llm
        self._prompt_resolver = prompt_resolver

    def _get_consolidation_prompt(self) -> str:
        """Get consolidation prompt with hot-reload support."""
        if self._prompt_resolver:
            try:
                custom = self._prompt_resolver()
                if custom:
                    return custom
            except Exception as e:
                logger.warning("Consolidation prompt resolver failed: %s", e)

        # Import default prompt
        from mongomem_core.extraction.semantic.prompts import (
            CONSOLIDATION_SYSTEM_PROMPT,
        )

        return CONSOLIDATION_SYSTEM_PROMPT

    def decide_batch(
        self,
        extractions: List[ScoredExtraction],
        all_similar: List[SimilarMatch],
    ) -> List[ConsolidationDecision]:
        """
        Decide actions for a batch of extractions using LLM.

        Args:
            extractions: List of scored extractions
            all_similar: All similar existing memories (deduplicated across extractions)

        Returns:
            List of consolidation decisions
        """
        if not extractions:
            return []

        # If no similar memories, all are ADD
        if not all_similar:
            return [
                ConsolidationDecision(
                    extraction=ext,
                    action="ADD",
                    reason="no similar memories found",
                )
                for ext in extractions
            ]

        # Create ID mapper
        id_mapper = MemoryIdMapper.create(all_similar, extractions)

        # Format for prompt with temp IDs
        formatted_existing = [
            {"id": id_mapper.existing_to_temp[m.id], "text": m.content} for m in all_similar
        ]
        formatted_new = [
            {"id": f"new_{idx}", "text": ext.content} for idx, ext in enumerate(extractions)
        ]

        # Call LLM
        try:
            from mongomem_core.extraction.semantic.prompts import (
                CONSOLIDATION_PROMPT_TEMPLATE,
            )

            system_prompt = self._get_consolidation_prompt()
            user_prompt = CONSOLIDATION_PROMPT_TEMPLATE.format(
                existing_memories=formatted_existing,
                new_memories=formatted_new,
            )

            result = self._llm.complete_json(
                prompt=f"{system_prompt}\n\n{user_prompt}",
                schema={},
            )

            # Parse and validate response
            return self._parse_llm_response(result, id_mapper, extractions)

        except Exception as e:
            logger.error("LLM consolidation failed, falling back to ADD: %s", e)
            # Fallback to ADD for all
            return [
                ConsolidationDecision(
                    extraction=ext,
                    action="ADD",
                    reason=f"LLM consolidation failed: {e}",
                )
                for ext in extractions
            ]

    def _parse_llm_response(
        self,
        result: Dict[str, Any],
        id_mapper: MemoryIdMapper,
        extractions: List[ScoredExtraction],
    ) -> List[ConsolidationDecision]:
        """
        Parse and validate LLM response, mapping temp IDs back to real IDs.

        Args:
            result: Raw LLM response
            id_mapper: ID mapper for resolving temp IDs
            extractions: Original extractions

        Returns:
            List of validated consolidation decisions
        """
        memories = result.get("memories", [])
        decisions = []

        # Build lookup for extractions by temp ID
        extraction_by_temp_id = {f"new_{idx}": ext for idx, ext in enumerate(extractions)}

        for memory in memories:
            temp_id = memory.get("id")
            action = memory.get("action", "ADD").upper()
            existing_temp_id = memory.get("existing_memory_id")

            # Validate temp ID
            if temp_id not in id_mapper.valid_new_ids:
                logger.warning("Invalid temp ID in LLM response: %s", temp_id)
                continue

            extraction = extraction_by_temp_id.get(temp_id)
            if not extraction:
                continue

            # Validate action
            if action not in ("ADD", "UPDATE", "NONE", "REINFORCE", "DUPLICATE"):
                logger.warning("Invalid action in LLM response: %s", action)
                action = "ADD"

            # Map NONE to REINFORCE (ExoMemory compatibility)
            if action == "NONE":
                action = "REINFORCE"

            # Resolve existing ID for UPDATE/REINFORCE
            existing_id = None
            if action in ("UPDATE", "REINFORCE") and existing_temp_id:
                if existing_temp_id in id_mapper.valid_existing_ids:
                    existing_id = id_mapper.resolve_existing_id(existing_temp_id)
                else:
                    logger.warning(
                        "Invalid existing_memory_id in LLM response: %s",
                        existing_temp_id,
                    )
                    # Fallback to ADD if invalid existing ID
                    action = "ADD"

            decisions.append(
                ConsolidationDecision(
                    extraction=extraction,
                    action=action,  # type: ignore[arg-type]
                    existing_id=existing_id,
                    reason=f"LLM decided {action}",
                )
            )

        # Handle any extractions not in LLM response (default to ADD)
        responded_ids = {m.get("id") for m in memories}
        for temp_id, extraction in extraction_by_temp_id.items():
            if temp_id not in responded_ids:
                logger.warning("Extraction %s not in LLM response, defaulting to ADD", temp_id)
                decisions.append(
                    ConsolidationDecision(
                        extraction=extraction,
                        action="ADD",
                        reason="not in LLM response, defaulting to ADD",
                    )
                )

        return decisions

    def decide(
        self,
        extraction: ScoredExtraction,
        similar: List[SimilarMatch],
    ) -> ConsolidationDecision:
        """
        Decide action for a single extraction (wraps batch method).

        Args:
            extraction: Single extraction to decide on
            similar: Similar existing memories

        Returns:
            Single consolidation decision
        """
        decisions = self.decide_batch([extraction], similar)
        return (
            decisions[0]
            if decisions
            else ConsolidationDecision(
                extraction=extraction,
                action="ADD",
                reason="no decision from batch",
            )
        )


# ═══════════════════════════════════════════════════════════════════════════════
# Main Consolidator
# ═══════════════════════════════════════════════════════════════════════════════


class Consolidator:
    """
    Orchestrates similarity search + decision strategy.

    Uses batch embeddings for efficiency.
    """

    def __init__(
        self,
        db: "Database",
        embedder: "EmbedderProtocol",
        strategy: ConsolidationStrategy,
        search_fn: Callable,
        config: ExtractionConfigProtocol,
    ) -> None:
        """
        Initialize consolidator.

        Args:
            db: MongoDB database instance
            embedder: Embedder for generating embeddings
            strategy: Strategy for deciding actions (rule-based or LLM-based)
            search_fn: Function to search for similar memories
            config: Extraction configuration
        """
        self._db = db
        self._embedder = embedder
        self._strategy = strategy
        self._search_fn = search_fn
        self._config = config

    @property
    def strategy_type(self) -> str:
        """
        Return the type name of the consolidation strategy.

        Useful for testing and debugging without exposing private internals.

        Returns:
            String name of the strategy class (e.g., 'LLMBasedStrategy', 'RuleBasedStrategy')
        """
        return type(self._strategy).__name__

    def process(
        self,
        extractions: List[ScoredExtraction],
        org_id: str,
        user_id: str,
    ) -> List[ConsolidationDecision]:
        """
        Search for similar memories and decide actions.

        Args:
            extractions: Scored extractions to consolidate
            org_id: Organization ID
            user_id: User ID

        Returns:
            List of consolidation decisions
        """
        if not extractions:
            return []

        # Batch embed all extractions
        contents = [e.content for e in extractions]
        try:
            embeddings = self._embedder.embed_batch(contents)
        except Exception as e:
            logger.error("Batch embedding failed: %s", e)
            # Fallback to individual embedding
            embeddings = []
            for content in contents:
                try:
                    embeddings.append(self._embedder.embed(content))
                except Exception as embed_error:
                    logger.error("Individual embedding failed: %s", embed_error)
                    embeddings.append([])

        # Store embeddings on extractions
        for ext, emb in zip(extractions, embeddings):
            ext.embedding = emb

        # Search for similar memories for each extraction
        all_similar: Dict[str, SimilarMatch] = {}  # Deduplicated by ID
        extraction_similar: Dict[int, List[SimilarMatch]] = {}

        for idx, (ext, embedding) in enumerate(zip(extractions, embeddings)):
            if not embedding:
                extraction_similar[idx] = []
                continue

            try:
                similar = self._search_similar(embedding, org_id, user_id)
                extraction_similar[idx] = similar

                # Deduplicate across extractions
                for match in similar:
                    if match.id not in all_similar:
                        all_similar[match.id] = match
            except Exception as e:
                logger.warning("Search failed for extraction %d: %s", idx, e)
                extraction_similar[idx] = []

        # Decide actions
        if not all_similar:
            # No similar memories found - all ADD
            return [
                ConsolidationDecision(
                    extraction=ext,
                    action="ADD",
                    reason="no similar memories found",
                )
                for ext in extractions
            ]

        # Use strategy to decide
        if isinstance(self._strategy, LLMBasedStrategy):
            # LLM strategy handles batch
            return self._strategy.decide_batch(extractions, list(all_similar.values()))
        else:
            # Rule-based handles individually
            decisions = []
            for idx, ext in enumerate(extractions):
                similar = extraction_similar.get(idx, [])
                decision = self._strategy.decide(ext, similar)
                decisions.append(decision)
            return decisions

    def _search_similar(
        self,
        embedding: List[float],
        org_id: str,
        user_id: str,
    ) -> List[SimilarMatch]:
        """
        Search for similar existing memories.

        Args:
            embedding: Query embedding
            org_id: Organization ID
            user_id: User ID

        Returns:
            List of similar matches
        """
        results = self._search_fn(
            db=self._db,
            query_embedding=embedding,
            org_id=org_id,
            user_id=user_id,
            top_k=self._config.consolidation_top_k,
            similarity_threshold=self._config.consolidation_similarity_threshold,
            return_format="dict",
        )

        return [
            SimilarMatch(
                id=str(getattr(r, "id", r.get("_id", r.get("id", "")))),
                content=getattr(r, "text", r.get("text", "")),
                score=getattr(r, "score", r.get("score", 0.0)),
            )
            for r in results
        ]


__all__ = [
    "MemoryIdMapper",
    "ConsolidationStrategy",
    "RuleBasedStrategy",
    "LLMBasedStrategy",
    "Consolidator",
]
