"""Source selection and candidate fetching for retrieval."""

from __future__ import annotations

import logging
import time
from concurrent.futures import (
    ThreadPoolExecutor,
    as_completed,
)
from concurrent.futures import (
    TimeoutError as FutureTimeoutError,
)
from threading import Lock
from typing import TYPE_CHECKING, Callable, Dict, List, Literal, Optional, Set, Tuple, Union, cast

from mongomem_core.common.utils import cosine_similarity
from mongomem_core.exceptions import (
    ConnectionError as MongoMemConnectionError,
)
from mongomem_core.exceptions import (
    DatabaseOperationError,
    EmbeddingGenerationError,
)
from mongomem_core.memory.episodic import vector_search_episodic
from mongomem_core.memory.procedural import search_procedural
from mongomem_core.memory.semantic import search_semantic
from mongomem_core.memory.short_term import get_stm_by_session
from mongomem_core.memory.taxonomic import search_taxonomic
from mongomem_core.observability import CoreObservability
from pymongo.database import Database

if TYPE_CHECKING:
    from mongomem_core.protocols import EmbedderProtocol
from mongomem_core.models.filters import MetadataFilter
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.episodic import EpisodicOut
from mongomem_core.models.memory.procedural import ProceduralOut
from mongomem_core.models.memory.semantic import SemanticOut
from mongomem_core.models.memory.short_term import ShortTermOut
from mongomem_core.models.memory.taxonomic import TaxonomicOut
from mongomem_core.models.retrieval import MemoryChunk, MemorySource
from mongomem_core.retrieval.constants import (
    FETCH_TIMEOUT_SECONDS,
    REQUIRED_SOURCES,
)
from mongomem_core.retrieval.deduplication import deduplicate_memory_chunks

logger = logging.getLogger(__name__)


def resolve_query_embedding(
    query: Union[str, List[float]],
    embedder: Optional["EmbedderProtocol"] = None,
) -> List[float]:
    """
    Resolve query to embedding vector.

    This is a utility function for converting a query (text or embedding)
    into an embedding vector. If the query is already an embedding, it's
    returned as-is. If it's text, the embedder is used to generate the embedding.

    Args:
        query: Query text (str) or pre-computed embedding (List[float])
        embedder: Optional embedder for text-to-embedding conversion.
            Required if query is a string.

    Returns:
        Embedding vector (List[float])

    Raises:
        ValueError: If query is a string but embedder not available,
            or if query/embedding is empty
        EmbeddingGenerationError: If embedding generation fails

    Example:
        >>> # With pre-computed embedding
        >>> embedding = resolve_query_embedding([0.1, 0.2, 0.3])

        >>> # With text query and embedder
        >>> embedding = resolve_query_embedding("Python dictionaries", embedder=my_embedder)
    """
    # If query is already an embedding vector, return it
    if isinstance(query, list):
        if not query:
            raise ValueError("Query embedding cannot be empty")
        return query

    # Query is text, need to embed
    if embedder is None:
        raise ValueError(
            "Cannot generate embedding: query is text but embedder not available. "
            "Either provide a pre-computed embedding vector or pass an embedder."
        )

    if not query or not query.strip():
        raise ValueError("Query text cannot be empty when embedding is required")

    try:
        embedding = embedder.embed(query)
        if not embedding or len(embedding) == 0:
            raise EmbeddingGenerationError(
                "Embedder returned empty embedding vector",
                query=query,
            )
        return embedding
    except EmbeddingGenerationError:
        raise
    except Exception as e:
        logger.error("Failed to generate embedding: %s", e, exc_info=True)
        raise EmbeddingGenerationError(
            f"Embedding generation failed: {e}",
            query=query,
            original_error=e,
        ) from e


# Cosine similarity is imported from common.utils - see imports at top


def calculate_similarity_for_prefetched(
    memories: List[Union[EpisodicOut, SemanticOut, MemoryChunk]],
    query_embedding: List[float],
    memory_type: str,
) -> List[MemoryChunk]:
    """
    Calculate similarity scores for pre-fetched memories and convert to MemoryChunk.

    This is a public utility function for processing pre-fetched memories
    by calculating cosine similarity against a query embedding.

    Supports both raw memory documents (SemanticOut, EpisodicOut) and
    already-converted MemoryChunk objects.

    Args:
        memories: List of episodic, semantic, or MemoryChunk objects
        query_embedding: Query embedding vector
        memory_type: "episodic" or "semantic" for conversion (ignored for MemoryChunk)

    Returns:
        List of MemoryChunk objects with calculated similarity scores
    """
    chunks = []
    for memory in memories:
        try:
            # Handle already-converted MemoryChunk objects
            if isinstance(memory, MemoryChunk):
                similarity_score = memory.similarity_score
                if memory.embedding and query_embedding:
                    try:
                        similarity_score = cosine_similarity(query_embedding, memory.embedding)
                    except (ValueError, TypeError) as exc:
                        logger.warning(
                            "Failed to calculate similarity for MemoryChunk id=%s: %s",
                            memory.id,
                            exc,
                        )
                memory.similarity_score = similarity_score
                chunks.append(memory)
                continue

            # Handle raw memory documents (SemanticOut, EpisodicOut)
            similarity_score = getattr(memory, "score", None)
            if (
                hasattr(memory, "embedding_present")
                and memory.embedding_present()
                and query_embedding
                and memory.embedding
            ):
                try:
                    similarity_score = cosine_similarity(query_embedding, memory.embedding)
                except (ValueError, TypeError) as exc:
                    logger.warning(
                        "Failed to calculate similarity for %s memory id=%s: %s",
                        memory_type,
                        memory.id,
                        exc,
                    )
                    similarity_score = getattr(memory, "score", None)

            if memory_type == "episodic":
                chunks.append(
                    MemoryChunk.from_episodic(
                        cast(EpisodicOut, memory), similarity_score=similarity_score
                    )
                )
            elif memory_type == "semantic":
                chunks.append(
                    MemoryChunk.from_semantic(
                        cast(SemanticOut, memory), similarity_score=similarity_score
                    )
                )
        except Exception as exc:
            logger.error(
                "Failed to convert %s memory id=%s to MemoryChunk: %s",
                memory_type,
                getattr(memory, "id", "unknown"),
                exc,
                exc_info=True,
            )
    return chunks


def _fetch_memory_chunks_core(
    db: Database,
    org_id: str,
    memory_type: Literal["semantic", "episodic"],
    *,
    query: Optional[Union[str, List[float]]] = None,
    query_embedding: Optional[List[float]] = None,
    embedder: Optional["EmbedderProtocol"] = None,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    session_id: Optional[str] = None,  # Only used for episodic
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    dedup_threshold: float = 0.5,
    prefetched: Optional[List[Union[SemanticOut, EpisodicOut, MemoryChunk]]] = None,
    deduplicate: bool = True,
    rank: bool = False,
    ranking_config: Optional[Dict] = None,
    metadata_filter: Optional[MetadataFilter] = None,
) -> List[MemoryChunk]:
    """
    Core logic for fetching and processing memory chunks (semantic or episodic).

    This internal helper function contains the shared logic for both
    fetch_semantic_memories and fetch_episodic_memories.

    Args:
        db: MongoDB database instance
        org_id: Organization ID for multi-tenancy
        memory_type: Type of memory to fetch ("semantic" or "episodic")
        query: Query text (str) or embedding (List[float]). Used if query_embedding not provided.
        query_embedding: Pre-computed query embedding vector. Takes precedence over query.
        embedder: Embedder for text-to-embedding conversion. Required if query is text.
        user_id: Optional user ID filter
        visibility: Optional visibility scope filter
        project_id: Optional group ID filter
        session_id: Optional session ID filter (only used for episodic)
        top_k: Maximum number of results from vector search
        similarity_threshold: Minimum similarity score for vector search
        dedup_threshold: Threshold for similarity-based deduplication
        prefetched: Optional pre-fetched memories (skips DB query)
        deduplicate: Whether to deduplicate results
        rank: Whether to rank results using multi-factor scoring
        ranking_config: Optional dict with ranking weights
        metadata_filter: Optional user-provided metadata filter for field-level filtering.
            Applied after RBAC filters.

    Returns:
        List of MemoryChunk objects, optionally deduplicated and ranked.
        Returns empty list on database errors to allow RetrievalHub to continue.

    Raises:
        ValueError: If neither query nor query_embedding is provided,
            or if query is text but embedder not available
    """
    # Resolve query embedding
    if query_embedding is not None:
        # Validate query_embedding is not empty
        if not query_embedding or len(query_embedding) == 0:
            raise ValueError("query_embedding cannot be empty")
        effective_embedding = query_embedding
    elif query is not None:
        effective_embedding = resolve_query_embedding(query, embedder=embedder)
    else:
        raise ValueError("Either 'query' or 'query_embedding' must be provided")

    # Fetch from DB or use pre-fetched
    if prefetched is not None:
        # Filter prefetched memories by org_id
        filtered_prefetched = []
        mismatches = []
        for mem in prefetched:
            if mem.org_id == org_id:
                filtered_prefetched.append(mem)
            else:
                mismatches.append(mem)

        if mismatches:
            logger.warning(
                "Filtered %d %s memories with org_id mismatch: expected=%s, found %d mismatches",
                len(mismatches),
                memory_type,
                org_id,
                len(mismatches),
            )

        chunks = calculate_similarity_for_prefetched(
            filtered_prefetched, effective_embedding, memory_type
        )
    else:
        if memory_type == "semantic":
            semantic_results = search_semantic(
                db=db,
                query_embedding=effective_embedding,
                org_id=org_id,
                user_id=user_id,
                visibility=visibility,
                project_id=project_id,
                top_k=top_k,
                similarity_threshold=similarity_threshold,
                return_format="model",
                metadata_filter=metadata_filter,
            )
            chunks = [MemoryChunk.from_semantic(mem) for mem in semantic_results]
        elif memory_type == "episodic":
            episodic_results = vector_search_episodic(
                db=db,
                query_embedding=effective_embedding,
                org_id=org_id,
                user_id=user_id,
                visibility=visibility,
                project_id=project_id,
                session_id=session_id,
                top_k=top_k,
                similarity_threshold=similarity_threshold,
                metadata_filter=metadata_filter,
            )
            chunks = [MemoryChunk.from_episodic(mem) for mem in episodic_results]

    # Deduplicate
    if deduplicate:
        chunks = deduplicate_memory_chunks(chunks, dedup_threshold)

    # Rank if requested
    if rank:
        from mongomem_core.models.retrieval import ContextConfig
        from mongomem_core.retrieval.ranking import MemoryRanker

        ranker = MemoryRanker()
        config = ContextConfig(ranking_weights=ranking_config or {})
        chunks = ranker.rank_memories(chunks, config)

    logger.debug(
        "fetch_%s_memories: org=%s fetched=%d (deduplicate=%s, rank=%s)",
        memory_type,
        org_id,
        len(chunks),
        deduplicate,
        rank,
    )

    return chunks


def fetch_semantic_memories(
    db: Database,
    org_id: str,
    *,
    query: Optional[Union[str, List[float]]] = None,
    query_embedding: Optional[List[float]] = None,
    embedder: Optional["EmbedderProtocol"] = None,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    dedup_threshold: float = 0.5,
    prefetched: Optional[List[SemanticOut]] = None,
    deduplicate: bool = True,
    rank: bool = False,
    ranking_config: Optional[Dict] = None,
    metadata_filter: Optional[MetadataFilter] = None,
) -> List[MemoryChunk]:
    """
    Fetch semantic memories with optional deduplication and ranking.

    This is the main entry point for retrieving semantic memories. Supports
    both database queries and pre-fetched memory lists.

    Query Resolution:
        - If `query_embedding` is provided, use it directly
        - If `query` is a List[float], use it as the embedding
        - If `query` is a str, use `embedder` to generate the embedding

    Args:
        db: MongoDB database instance
        org_id: Organization ID for multi-tenancy
        query: Query text (str) or embedding (List[float]). Used if query_embedding not provided.
        query_embedding: Pre-computed query embedding vector. Takes precedence over query.
        embedder: Embedder for text-to-embedding conversion. Required if query is text.
        user_id: Optional user ID filter
        visibility: Optional visibility scope filter
        project_id: Optional group ID filter (for shared visibility)
        top_k: Maximum number of results from vector search (default: 50)
        similarity_threshold: Minimum similarity score for vector search (default: 0.0)
        dedup_threshold: Threshold for similarity-based deduplication (default: 0.5)
        prefetched: Optional pre-fetched semantic memories (skips DB query)
        deduplicate: Whether to deduplicate results (default: True)
        rank: Whether to rank results using multi-factor scoring (default: False)
        ranking_config: Optional dict with ranking weights (similarity, recency, importance)
        metadata_filter: Optional user-provided metadata filter for field-level filtering.
            Applied after RBAC filters. See MetadataFilter for usage.

    Returns:
        List of MemoryChunk objects, optionally deduplicated and ranked.
        Returns empty list on database errors to allow RetrievalHub to continue
        with other sources.

    Raises:
        ValueError: If neither query nor query_embedding is provided,
            or if query is text but embedder not available

    Example:
        >>> # With query text and embedder
        >>> chunks = fetch_semantic_memories(
        ...     db=db,
        ...     org_id="org_1",
        ...     query="Python dictionaries",
        ...     embedder=my_embedder,
        ...     top_k=20,
        ... )

        >>> # With pre-computed embedding and metadata filter
        >>> from mongomem_core.models.filters import MetadataFilter
        >>> chunks = fetch_semantic_memories(
        ...     db=db,
        ...     org_id="org_1",
        ...     query_embedding=embedding,
        ...     metadata_filter=MetadataFilter(raw={"source": "python-docs"}),
        ...     rank=True,
        ... )

        >>> # Use pre-fetched memories
        >>> chunks = fetch_semantic_memories(
        ...     db=db,
        ...     org_id="org_1",
        ...     query_embedding=embedding,
        ...     prefetched=my_semantic_list,
        ... )
    """
    try:
        return _fetch_memory_chunks_core(
            db=db,
            org_id=org_id,
            memory_type="semantic",
            query=query,
            query_embedding=query_embedding,
            embedder=embedder,
            user_id=user_id,
            visibility=visibility,
            project_id=project_id,
            top_k=top_k,
            similarity_threshold=similarity_threshold,
            dedup_threshold=dedup_threshold,
            prefetched=cast(
                Optional[List[Union[SemanticOut, EpisodicOut, MemoryChunk]]], prefetched
            ),
            deduplicate=deduplicate,
            rank=rank,
            ranking_config=ranking_config,
            metadata_filter=metadata_filter,
        )
    except (DatabaseOperationError, MongoMemConnectionError) as exc:
        logger.warning(
            "Failed to fetch semantic memories (will continue with other sources): org_id=%s, error=%s",
            org_id,
            exc,
        )
        return []
    except (ValueError, EmbeddingGenerationError):
        raise
    except Exception:
        logger.error(
            "Unexpected error fetching semantic memories: org_id=%s",
            org_id,
            exc_info=True,
        )
        return []


def fetch_episodic_memories(
    db: Database,
    org_id: str,
    *,
    query: Optional[Union[str, List[float]]] = None,
    query_embedding: Optional[List[float]] = None,
    embedder: Optional["EmbedderProtocol"] = None,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    session_id: Optional[str] = None,
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    dedup_threshold: float = 0.5,
    prefetched: Optional[List[EpisodicOut]] = None,
    deduplicate: bool = True,
    rank: bool = False,
    ranking_config: Optional[Dict] = None,
    metadata_filter: Optional[MetadataFilter] = None,
) -> List[MemoryChunk]:
    """
    Fetch episodic memories with optional deduplication and ranking.

    This is the main entry point for retrieving episodic memories. Supports
    both database queries and pre-fetched memory lists.

    Query Resolution:
        - If `query_embedding` is provided, use it directly
        - If `query` is a List[float], use it as the embedding
        - If `query` is a str, use `embedder` to generate the embedding

    Args:
        db: MongoDB database instance
        org_id: Organization ID for multi-tenancy
        query: Query text (str) or embedding (List[float]). Used if query_embedding not provided.
        query_embedding: Pre-computed query embedding vector. Takes precedence over query.
        embedder: Embedder for text-to-embedding conversion. Required if query is text.
        user_id: Optional user ID filter
        visibility: Optional visibility scope filter
        project_id: Optional group ID filter (for shared visibility)
        session_id: Optional session ID filter
        top_k: Maximum number of results from vector search (default: 50)
        similarity_threshold: Minimum similarity score for vector search (default: 0.0)
        dedup_threshold: Threshold for similarity-based deduplication (default: 0.5)
        prefetched: Optional pre-fetched episodic memories (skips DB query)
        deduplicate: Whether to deduplicate results (default: True)
        rank: Whether to rank results using multi-factor scoring (default: False)
        ranking_config: Optional dict with ranking weights (similarity, recency, importance)
        metadata_filter: Optional user-provided metadata filter for field-level filtering.
            Applied after RBAC filters. See MetadataFilter for usage.

    Returns:
        List of MemoryChunk objects, optionally deduplicated and ranked.
        Returns empty list on database errors to allow RetrievalHub to continue
        with other sources.

    Raises:
        ValueError: If neither query nor query_embedding is provided,
            or if query is text but embedder not available

    Example:
        >>> # With query text and embedder
        >>> chunks = fetch_episodic_memories(
        ...     db=db,
        ...     org_id="org_1",
        ...     query="meeting about project timeline",
        ...     embedder=my_embedder,
        ...     top_k=20,
        ... )

        >>> # With pre-computed embedding and metadata filter
        >>> from mongomem_core.models.filters import MetadataFilter
        >>> chunks = fetch_episodic_memories(
        ...     db=db,
        ...     org_id="org_1",
        ...     query_embedding=embedding,
        ...     metadata_filter=MetadataFilter(raw={"tags": {"$in": ["meeting", "project"]}}),
        ...     rank=True,
        ... )

        >>> # Use pre-fetched memories
        >>> chunks = fetch_episodic_memories(
        ...     db=db,
        ...     org_id="org_1",
        ...     query_embedding=embedding,
        ...     prefetched=my_episodic_list,
        ... )
    """
    return _fetch_memory_chunks_core(
        db=db,
        org_id=org_id,
        memory_type="episodic",
        query=query,
        query_embedding=query_embedding,
        embedder=embedder,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        session_id=session_id,
        top_k=top_k,
        similarity_threshold=similarity_threshold,
        dedup_threshold=dedup_threshold,
        prefetched=cast(Optional[List[Union[SemanticOut, EpisodicOut, MemoryChunk]]], prefetched),
        deduplicate=deduplicate,
        rank=rank,
        ranking_config=ranking_config,
        metadata_filter=metadata_filter,
    )


def fetch_taxonomic_memories(
    db: Database,
    org_id: str,
    *,
    query: Optional[Union[str, List[float]]] = None,
    query_embedding: Optional[List[float]] = None,
    embedder: Optional["EmbedderProtocol"] = None,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    domain: Optional[str] = None,
    domains: Optional[List[str]] = None,
    query_expansion: Optional[bool] = None,
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    dedup_threshold: float = 0.5,
    prefetched: Optional[List[TaxonomicOut]] = None,
    deduplicate: bool = True,
    rank: bool = False,
    ranking_config: Optional[Dict] = None,
    metadata_filter: Optional[MetadataFilter] = None,
) -> List[MemoryChunk]:
    """
    Fetch taxonomic memories with optional deduplication and ranking.

    This is the main entry point for retrieving taxonomic memories. Supports
    both database queries and pre-fetched memory lists.

    Query Resolution:
        - If `query_embedding` is provided, use it directly
        - If `query` is a List[float], use it as the embedding
        - If `query` is a str, use `embedder` to generate the embedding

    Args:
        db: MongoDB database instance
        org_id: Organization ID for multi-tenancy
        query: Query text (str) or embedding (List[float]). Used if query_embedding not provided.
        query_embedding: Pre-computed query embedding vector. Takes precedence over query.
        embedder: Embedder for text-to-embedding conversion. Required if query is text.
        user_id: Optional user ID filter
        visibility: Optional visibility scope filter
        project_id: Optional group ID filter (for shared visibility)
        domain: Optional filter by single domain
        domains: Optional filter by multiple domains
        query_expansion: Optional filter by query_expansion flag
        top_k: Maximum number of results from vector search (default: 50)
        similarity_threshold: Minimum similarity score for vector search (default: 0.0)
        dedup_threshold: Threshold for similarity-based deduplication (default: 0.5)
        prefetched: Optional pre-fetched taxonomic memories (skips DB query)
        deduplicate: Whether to deduplicate results (default: True)
        rank: Whether to rank results using multi-factor scoring (default: False)
        ranking_config: Optional dict with ranking weights (similarity, recency, importance)
        metadata_filter: Optional user-provided metadata filter for field-level filtering.
            Applied after RBAC filters. See MetadataFilter for usage.

    Returns:
        List of MemoryChunk objects, optionally deduplicated and ranked.
        Returns empty list on database errors to allow RetrievalHub to continue
        with other sources.

    Raises:
        ValueError: If neither query nor query_embedding is provided,
            or if query is text but embedder not available

    Example:
        >>> # With query text and embedder
        >>> chunks = fetch_taxonomic_memories(
        ...     db=db,
        ...     org_id="org_1",
        ...     query="Python dictionaries",
        ...     embedder=my_embedder,
        ...     top_k=20,
        ... )

        >>> # With pre-computed embedding and domain filter
        >>> chunks = fetch_taxonomic_memories(
        ...     db=db,
        ...     org_id="org_1",
        ...     query_embedding=embedding,
        ...     domain="programming",
        ...     rank=True,
        ... )

        >>> # Use pre-fetched memories
        >>> chunks = fetch_taxonomic_memories(
        ...     db=db,
        ...     org_id="org_1",
        ...     query_embedding=embedding,
        ...     prefetched=my_taxonomic_list,
        ... )
    """
    try:
        # Resolve query embedding
        if query_embedding is not None:
            if not query_embedding or len(query_embedding) == 0:
                raise ValueError("query_embedding cannot be empty")
            effective_embedding = query_embedding
        elif query is not None:
            effective_embedding = resolve_query_embedding(query, embedder=embedder)
        else:
            raise ValueError("Either 'query' or 'query_embedding' must be provided")

        # Fetch from DB or use pre-fetched
        if prefetched is not None:
            # Filter prefetched memories by org_id
            filtered_prefetched = []
            mismatches = []
            for mem in prefetched:
                if mem.org_id == org_id:
                    filtered_prefetched.append(mem)
                else:
                    mismatches.append(mem)

            if mismatches:
                logger.warning(
                    "Filtered %d taxonomic memories with org_id mismatch: expected=%s, found %d mismatches",
                    len(mismatches),
                    org_id,
                    len(mismatches),
                )

            # Calculate similarity for pre-fetched memories
            chunks = []
            for memory in filtered_prefetched:
                try:
                    similarity_score = memory.score
                    if memory.embedding_present() and effective_embedding and memory.embedding:
                        try:
                            similarity_score = cosine_similarity(
                                effective_embedding, memory.embedding
                            )
                        except (ValueError, TypeError) as exc:
                            logger.warning(
                                "Failed to calculate similarity for taxonomic memory id=%s: %s",
                                memory.id,
                                exc,
                            )
                            similarity_score = memory.score

                    chunks.append(
                        MemoryChunk.from_taxonomic(memory, similarity_score=similarity_score)
                    )
                except Exception as exc:
                    logger.error(
                        "Failed to convert taxonomic memory id=%s to MemoryChunk: %s",
                        getattr(memory, "id", "unknown"),
                        exc,
                        exc_info=True,
                    )
        else:
            results = search_taxonomic(
                db=db,
                query_embedding=effective_embedding,
                org_id=org_id,
                user_id=user_id,
                visibility=visibility,
                project_id=project_id,
                domain=domain,
                domains=domains,
                query_expansion=query_expansion,
                top_k=top_k,
                similarity_threshold=similarity_threshold,
                return_format="model",
                metadata_filter=metadata_filter,
            )
            chunks = [MemoryChunk.from_taxonomic(mem) for mem in results]

        # Deduplicate
        if deduplicate:
            chunks = deduplicate_memory_chunks(chunks, dedup_threshold)

        # Rank if requested
        if rank:
            from mongomem_core.models.retrieval import ContextConfig
            from mongomem_core.retrieval.ranking import MemoryRanker

            ranker = MemoryRanker()
            config = ContextConfig(ranking_weights=ranking_config or {})
            chunks = ranker.rank_memories(chunks, config)

        logger.debug(
            "fetch_taxonomic_memories: org=%s fetched=%d (deduplicate=%s, rank=%s)",
            org_id,
            len(chunks),
            deduplicate,
            rank,
        )

        return chunks
    except (DatabaseOperationError, MongoMemConnectionError) as exc:
        logger.warning(
            "Failed to fetch taxonomic memories (will continue with other sources): org_id=%s, error=%s",
            org_id,
            exc,
        )
        return []
    except (ValueError, EmbeddingGenerationError):
        raise
    except Exception:
        logger.error(
            "Unexpected error fetching taxonomic memories: org_id=%s",
            org_id,
            exc_info=True,
        )
        return []


def fetch_procedural_memories(
    db: Database,
    org_id: str,
    *,
    query: Optional[Union[str, List[float]]] = None,
    query_embedding: Optional[List[float]] = None,
    embedder: Optional["EmbedderProtocol"] = None,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    tags: Optional[List[str]] = None,
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    dedup_threshold: float = 0.5,
    prefetched: Optional[List[ProceduralOut]] = None,
    deduplicate: bool = True,
    rank: bool = False,
    ranking_config: Optional[Dict] = None,
    metadata_filter: Optional[MetadataFilter] = None,
) -> List[MemoryChunk]:
    """Fetch procedural memories with optional deduplication and ranking.

    Args:
        db: MongoDB database instance
        org_id: Organization ID for multi-tenancy
        query: Query text or embedding vector
        query_embedding: Pre-computed query embedding (takes precedence)
        embedder: Embedder for text-to-embedding conversion
        user_id: Optional user ID filter
        visibility: Optional visibility scope filter
        project_id: Optional group ID filter
        tags: Optional tag filter
        top_k: Maximum results from vector search
        similarity_threshold: Minimum similarity score
        dedup_threshold: Deduplication threshold
        prefetched: Optional pre-fetched procedural memories
        deduplicate: Whether to deduplicate results
        rank: Whether to rank results
        ranking_config: Optional ranking weights
        metadata_filter: Optional metadata filter

    Returns:
        List of MemoryChunk objects
    """
    try:
        if query_embedding is not None:
            if not query_embedding or len(query_embedding) == 0:
                raise ValueError("query_embedding cannot be empty")
            effective_embedding = query_embedding
        elif query is not None:
            effective_embedding = resolve_query_embedding(query, embedder=embedder)
        else:
            raise ValueError("Either 'query' or 'query_embedding' must be provided")

        if prefetched is not None:
            filtered_prefetched = [m for m in prefetched if m.org_id == org_id]
            chunks = []
            for memory in filtered_prefetched:
                try:
                    similarity_score = memory.score
                    if memory.embedding_present() and effective_embedding and memory.embedding:
                        try:
                            similarity_score = cosine_similarity(
                                effective_embedding, memory.embedding
                            )
                        except (ValueError, TypeError) as exc:
                            logger.warning(
                                "Failed to calculate similarity for procedural memory id=%s: %s",
                                memory.id,
                                exc,
                            )
                            similarity_score = memory.score
                    chunks.append(
                        MemoryChunk.from_procedural(memory, similarity_score=similarity_score)
                    )
                except Exception as exc:
                    logger.error(
                        "Failed to convert procedural memory id=%s to MemoryChunk: %s",
                        getattr(memory, "id", "unknown"),
                        exc,
                        exc_info=True,
                    )
        else:
            results = search_procedural(
                db=db,
                query_embedding=effective_embedding,
                org_id=org_id,
                user_id=user_id,
                visibility=visibility,
                project_id=project_id,
                tags=tags,
                top_k=top_k,
                similarity_threshold=similarity_threshold,
                return_format="model",
                metadata_filter=metadata_filter,
            )
            chunks = [MemoryChunk.from_procedural(mem) for mem in results]

        if deduplicate:
            chunks = deduplicate_memory_chunks(chunks, dedup_threshold)

        if rank:
            from mongomem_core.models.retrieval import ContextConfig
            from mongomem_core.retrieval.ranking import MemoryRanker

            ranker = MemoryRanker()
            config = ContextConfig(ranking_weights=ranking_config or {})
            chunks = ranker.rank_memories(chunks, config)

        logger.debug(
            "fetch_procedural_memories: org=%s fetched=%d (deduplicate=%s, rank=%s)",
            org_id,
            len(chunks),
            deduplicate,
            rank,
        )
        return chunks
    except (DatabaseOperationError, MongoMemConnectionError) as exc:
        logger.warning(
            "Failed to fetch procedural memories (will continue with other sources): org_id=%s, error=%s",
            org_id,
            exc,
        )
        return []
    except (ValueError, EmbeddingGenerationError):
        raise
    except Exception:
        logger.error(
            "Unexpected error fetching procedural memories: org_id=%s",
            org_id,
            exc_info=True,
        )
        return []


class RetrievalHub:
    """
    Central hub for retrieving memories from multiple sources.

    Supports both database queries and pre-fetched memory lists, with
    automatic consolidation and deduplication.
    """

    def __init__(
        self,
        obs: Optional[CoreObservability] = None,
    ) -> None:
        """
        Initialize RetrievalHub instance.

        Args:
            obs: Optional CoreObservability for observability (metrics/spans/events).
                If not provided, a default CoreObservability with NoOpObservability is used.
        """
        self._obs = obs or CoreObservability()

    def fetch_memories(
        self,
        db: Database,
        session_id: str,
        query_embedding: List[float],
        org_id: str,
        *,
        user_id: Optional[str] = None,
        visibility: Optional[ChunkVisibility] = None,
        project_id: Optional[str] = None,
        metadata_filter: Optional[MetadataFilter] = None,
        top_k: int = 50,
        similarity_threshold: float = 0.0,
        enabled_sources: Optional[Set[MemorySource]] = None,
        stm_memories: Optional[List[ShortTermOut]] = None,
        episodic_memories: Optional[List[EpisodicOut]] = None,
        semantic_memories: Optional[List[SemanticOut]] = None,
        taxonomic_memories: Optional[List[TaxonomicOut]] = None,
        procedural_memories: Optional[List[ProceduralOut]] = None,
    ) -> List[MemoryChunk]:
        """
        Fetch memories from enabled sources with consolidation and deduplication.

        Supports two modes:
        - DB Mode: Fetches from database using vector search and session queries
        - Pre-fetched Mode: Uses provided memory lists (can mix with DB mode)

        Args:
            db: MongoDB database instance
            session_id: Session identifier for STM retrieval
            query_embedding: Query embedding vector for vector search
            org_id: Organization ID
            user_id: Optional user ID filter
            visibility: Optional visibility scope filter
            project_id: Optional group ID filter (for shared visibility)
            top_k: Maximum number of results per source (default: 50)
            similarity_threshold: Minimum similarity threshold for vector search (default: 0.0)
            enabled_sources: Set of memory sources to include (default: all sources)
            stm_memories: Optional pre-fetched short-term memories
            episodic_memories: Optional pre-fetched episodic memories
            semantic_memories: Optional pre-fetched semantic memories
            taxonomic_memories: Optional pre-fetched taxonomic memories
            procedural_memories: Optional pre-fetched procedural memories

        Returns:
            List of MemoryChunk objects, deduplicated and consolidated

        Raises:
            ValueError: If query_embedding is required but empty or None
            DatabaseOperationError: If required sources (STM, episodic) fail
        """
        if enabled_sources is None:
            enabled_sources = {
                MemorySource.STM,
                MemorySource.EPISODIC,
                MemorySource.SEMANTIC,
                MemorySource.TAXONOMIC,
            }

        vector_sources_enabled = {
            MemorySource.EPISODIC,
            MemorySource.SEMANTIC,
            MemorySource.TAXONOMIC,
            MemorySource.PROCEDURAL,
        } & enabled_sources
        if vector_sources_enabled:
            if not query_embedding or len(query_embedding) == 0:
                raise ValueError(
                    f"query_embedding is required and cannot be empty when "
                    f"{vector_sources_enabled} sources are enabled"
                )

        all_chunks = self._consolidate_results(
            db=db,
            session_id=session_id,
            query_embedding=query_embedding,
            org_id=org_id,
            user_id=user_id,
            visibility=visibility,
            project_id=project_id,
            metadata_filter=metadata_filter,
            top_k=top_k,
            similarity_threshold=similarity_threshold,
            enabled_sources=enabled_sources,
            stm_memories=stm_memories,
            episodic_memories=episodic_memories,
            semantic_memories=semantic_memories,
            taxonomic_memories=taxonomic_memories,
            procedural_memories=procedural_memories,
        )

        # Deduplicate and track metrics
        count_before = len(all_chunks)
        deduped_chunks = deduplicate_memory_chunks(all_chunks)
        removed_count = count_before - len(deduped_chunks)

        if removed_count > 0:
            self._obs.deduplication_completed(removed_count)

        return deduped_chunks

    def _consolidate_results(
        self,
        db: Database,
        session_id: str,
        query_embedding: List[float],
        org_id: str,
        *,
        user_id: Optional[str] = None,
        visibility: Optional[ChunkVisibility] = None,
        project_id: Optional[str] = None,
        metadata_filter: Optional[MetadataFilter] = None,
        top_k: int = 50,
        similarity_threshold: float = 0.0,
        enabled_sources: Set[MemorySource],
        stm_memories: Optional[List[ShortTermOut]] = None,
        episodic_memories: Optional[List[EpisodicOut]] = None,
        semantic_memories: Optional[List[SemanticOut]] = None,
        taxonomic_memories: Optional[List[TaxonomicOut]] = None,
        procedural_memories: Optional[List[ProceduralOut]] = None,
    ) -> List[MemoryChunk]:
        """
        Consolidate memories from all enabled sources into unified MemoryChunk format.

        Fetches from multiple sources in parallel to improve performance.
        Sources are independent and can be fetched concurrently.
        """
        sources_to_fetch = []
        if MemorySource.STM in enabled_sources:
            sources_to_fetch.append("stm")
        if MemorySource.EPISODIC in enabled_sources:
            sources_to_fetch.append("episodic")
        if MemorySource.SEMANTIC in enabled_sources:
            sources_to_fetch.append("semantic")
        if MemorySource.TAXONOMIC in enabled_sources:
            sources_to_fetch.append("taxonomic")
        if MemorySource.PROCEDURAL in enabled_sources:
            sources_to_fetch.append("procedural")

        if not sources_to_fetch:
            return []

        return self._consolidate_results_parallel(
            sources_to_fetch=sources_to_fetch,
            db=db,
            session_id=session_id,
            query_embedding=query_embedding,
            org_id=org_id,
            user_id=user_id,
            visibility=visibility,
            project_id=project_id,
            metadata_filter=metadata_filter,
            top_k=top_k,
            similarity_threshold=similarity_threshold,
            stm_memories=stm_memories,
            episodic_memories=episodic_memories,
            semantic_memories=semantic_memories,
            taxonomic_memories=taxonomic_memories,
            procedural_memories=procedural_memories,
        )

    def _handle_source_fetch_error(
        self,
        source_name: str,
        exc: Exception,
        error_msg: Optional[str] = None,
    ) -> None:
        """
        Handle errors from source fetching with appropriate logging.

        Args:
            source_name: Name of the source that failed
            exc: The exception that occurred
            error_msg: Optional custom error message
        """
        if error_msg is None:
            error_msg = str(exc)

        is_required = source_name in REQUIRED_SOURCES
        log_level = logger.error if is_required else logger.warning
        log_level(
            "%s source %s failed: %s"
            % ("Required" if is_required else "Optional", source_name, error_msg),
            exc_info=is_required,
        )

    def _consolidate_results_parallel(
        self,
        sources_to_fetch: List[str],
        db: Database,
        session_id: str,
        query_embedding: List[float],
        org_id: str,
        *,
        user_id: Optional[str] = None,
        visibility: Optional[ChunkVisibility] = None,
        project_id: Optional[str] = None,
        metadata_filter: Optional[MetadataFilter] = None,
        top_k: int = 50,
        similarity_threshold: float = 0.0,
        stm_memories: Optional[List[ShortTermOut]] = None,
        episodic_memories: Optional[List[EpisodicOut]] = None,
        semantic_memories: Optional[List[SemanticOut]] = None,
        taxonomic_memories: Optional[List[TaxonomicOut]] = None,
        procedural_memories: Optional[List[ProceduralOut]] = None,
    ) -> List[MemoryChunk]:
        """
        Fetch memories from multiple sources in parallel using threading.

        Thread-safe implementation that ensures proper error handling and timeout
        management. Each source is fetched in its own thread with independent
        error handling.

        Args:
            sources_to_fetch: List of source names to fetch ("stm", "episodic", "semantic", "taxonomic")
            db: MongoDB database instance (thread-safe via PyMongo connection pooling)
            session_id: Session identifier
            query_embedding: Query embedding vector
            org_id: Organization ID
            user_id: Optional user ID filter
            visibility: Optional visibility scope filter
            project_id: Optional group ID filter
            top_k: Maximum results per source
            similarity_threshold: Minimum similarity threshold
            stm_memories: Optional pre-fetched STM memories
            episodic_memories: Optional pre-fetched episodic memories
            semantic_memories: Optional pre-fetched semantic memories
            taxonomic_memories: Optional pre-fetched taxonomic memories

        Returns:
            List of MemoryChunk objects from all sources

        Raises:
            DatabaseOperationError: If required sources (STM, episodic) fail
        """
        all_chunks: List[MemoryChunk] = []
        chunks_lock = Lock()

        # Wrapper to track timing for each source fetch
        def _timed_fetch(
            source_name: str, fetch_fn: Callable[[], List[MemoryChunk]]
        ) -> Tuple[str, List[MemoryChunk], float]:
            """Execute fetch function and return source name, chunks, and duration_ms."""
            start = time.perf_counter()
            chunks = fetch_fn()
            duration_ms = (time.perf_counter() - start) * 1000
            return source_name, chunks, duration_ms

        def fetch_stm() -> Tuple[str, List[MemoryChunk], float]:
            return _timed_fetch(
                "stm",
                lambda: self._fetch_stm_memories(
                    db=db,
                    session_id=session_id,
                    org_id=org_id,
                    user_id=user_id,
                    visibility=visibility,
                    project_id=project_id,
                    stm_memories=stm_memories,
                ),
            )

        def fetch_episodic() -> Tuple[str, List[MemoryChunk], float]:
            return _timed_fetch(
                "episodic",
                lambda: fetch_episodic_memories(
                    db=db,
                    org_id=org_id,
                    query_embedding=query_embedding,
                    user_id=user_id,
                    visibility=visibility,
                    project_id=project_id,
                    metadata_filter=metadata_filter,
                    top_k=top_k,
                    similarity_threshold=similarity_threshold,
                    prefetched=episodic_memories,
                    deduplicate=False,  # Dedup happens at RetrievalHub level
                    rank=False,  # Ranking happens externally
                ),
            )

        def fetch_semantic() -> Tuple[str, List[MemoryChunk], float]:
            return _timed_fetch(
                "semantic",
                lambda: fetch_semantic_memories(
                    db=db,
                    org_id=org_id,
                    query_embedding=query_embedding,
                    user_id=user_id,
                    visibility=visibility,
                    project_id=project_id,
                    metadata_filter=metadata_filter,
                    top_k=top_k,
                    similarity_threshold=similarity_threshold,
                    prefetched=semantic_memories,
                    deduplicate=False,  # Dedup happens at RetrievalHub level
                    rank=False,  # Ranking happens externally
                ),
            )

        def fetch_taxonomic() -> Tuple[str, List[MemoryChunk], float]:
            return _timed_fetch(
                "taxonomic",
                lambda: fetch_taxonomic_memories(
                    db=db,
                    org_id=org_id,
                    query=query_embedding,
                    user_id=user_id,
                    visibility=visibility,
                    project_id=project_id,
                    metadata_filter=metadata_filter,
                    top_k=top_k,
                    similarity_threshold=similarity_threshold,
                    prefetched=taxonomic_memories,
                    deduplicate=False,  # Dedup happens at RetrievalHub level
                    rank=False,  # Ranking happens externally
                ),
            )

        def fetch_procedural_source() -> Tuple[str, List[MemoryChunk], float]:
            return _timed_fetch(
                "procedural",
                lambda: fetch_procedural_memories(
                    db=db,
                    org_id=org_id,
                    query=query_embedding,
                    user_id=user_id,
                    visibility=visibility,
                    project_id=project_id,
                    metadata_filter=metadata_filter,
                    top_k=top_k,
                    similarity_threshold=similarity_threshold,
                    prefetched=procedural_memories,
                    deduplicate=False,
                    rank=False,
                ),
            )

        source_functions: Dict[str, Callable[[], Tuple[str, List[MemoryChunk], float]]] = {
            "stm": fetch_stm,
            "episodic": fetch_episodic,
            "semantic": fetch_semantic,
            "taxonomic": fetch_taxonomic,
            "procedural": fetch_procedural_source,
        }

        errors: Dict[str, Exception] = {}
        with ThreadPoolExecutor(max_workers=len(sources_to_fetch)) as executor:
            future_to_source = {
                executor.submit(source_functions[source_name]): source_name
                for source_name in sources_to_fetch
            }

            try:
                for future in as_completed(future_to_source, timeout=FETCH_TIMEOUT_SECONDS):
                    source_name = future_to_source[future]
                    try:
                        src_name, chunks, duration_ms = future.result()
                        with chunks_lock:
                            all_chunks.extend(chunks)

                        self._obs.retrieval_source_completed(
                            source=src_name,
                            count=len(chunks),
                            duration_ms=duration_ms,
                        )
                    except FutureTimeoutError as exc:
                        error_msg = f"Timeout fetching {source_name} memories after {FETCH_TIMEOUT_SECONDS}s"
                        errors[source_name] = exc
                        self._handle_source_fetch_error(source_name, exc, error_msg)
                        self._obs.retrieval_source_failed(
                            source=source_name,
                            error_type="timeout",
                            error_message=error_msg,
                        )
                    except DatabaseOperationError as exc:
                        errors[source_name] = exc
                        self._handle_source_fetch_error(source_name, exc)
                        self._obs.retrieval_source_failed(
                            source=source_name,
                            error_type="database_error",
                            error_message=str(exc),
                        )
                    except Exception as exc:
                        errors[source_name] = exc
                        self._handle_source_fetch_error(source_name, exc)
                        self._obs.retrieval_source_failed(
                            source=source_name,
                            error_type="unknown",
                            error_message=str(exc),
                        )
            except FutureTimeoutError as exc:
                error_msg = f"Timeout waiting for memory sources after {FETCH_TIMEOUT_SECONDS}s"
                logger.error(error_msg)
                incomplete_sources = [
                    name for future, name in future_to_source.items() if not future.done()
                ]
                for source_name in incomplete_sources:
                    errors[source_name] = exc
                    # Emit metrics for incomplete sources that timed out
                    self._obs.retrieval_source_failed(
                        source=source_name,
                        error_type="timeout",
                        error_message=f"Timeout waiting for {source_name} after {FETCH_TIMEOUT_SECONDS}s",
                    )
                required_incomplete = [s for s in incomplete_sources if s in REQUIRED_SOURCES]
                if required_incomplete:
                    all_failure_names = ", ".join(required_incomplete)
                    raise DatabaseOperationError(
                        f"Timeout waiting for required sources: {all_failure_names}",
                        operation="fetch_memories",
                        original_error=exc,
                    ) from exc

        required_failures = {name: err for name, err in errors.items() if name in REQUIRED_SOURCES}
        if required_failures:
            first_failure_name = next(iter(required_failures))
            first_failure = required_failures[first_failure_name]
            all_failure_names = ", ".join(required_failures.keys())
            raise DatabaseOperationError(
                f"Failed to fetch required memory sources: {all_failure_names}",
                operation="fetch_memories",
                original_error=first_failure,
            ) from first_failure

        return all_chunks

    def _fetch_stm_memories(
        self,
        db: Database,
        session_id: str,
        org_id: str,
        *,
        user_id: Optional[str] = None,
        visibility: Optional[ChunkVisibility] = None,
        project_id: Optional[str] = None,
        stm_memories: Optional[List[ShortTermOut]] = None,
    ) -> List[MemoryChunk]:
        """
        Fetch short-term memories from DB or use pre-fetched list.

        Args:
            db: MongoDB database instance
            session_id: Session identifier
            org_id: Organization ID
            user_id: Optional user ID filter
            visibility: Optional visibility scope filter
            project_id: Optional group ID filter
            stm_memories: Optional pre-fetched STM memories

        Returns:
            List of MemoryChunk objects from STM source

        Raises:
            DatabaseOperationError: If DB query fails
        """
        if stm_memories is not None:
            mismatches = [m for m in stm_memories if m.session_id != session_id]
            if mismatches:
                logger.warning(
                    "STM memory session_id mismatch: expected=%s, found %d mismatches"
                    % (session_id, len(mismatches))
                )
            return [MemoryChunk.from_short_term(stm) for stm in stm_memories]

        try:
            stm_results = get_stm_by_session(
                db=db,
                session_id=session_id,
                org_id=org_id,
                user_id=user_id,
                visibility=visibility,
                project_id=project_id,
            )
            return [MemoryChunk.from_short_term(stm) for stm in stm_results]
        except Exception as exc:
            logger.error(
                "Failed to fetch STM memories: session_id=%s org_id=%s" % (session_id, org_id),
                exc_info=True,
            )
            raise DatabaseOperationError(
                "Failed to fetch short-term memories",
                operation="get_stm_by_session",
                original_error=exc,
            ) from exc
