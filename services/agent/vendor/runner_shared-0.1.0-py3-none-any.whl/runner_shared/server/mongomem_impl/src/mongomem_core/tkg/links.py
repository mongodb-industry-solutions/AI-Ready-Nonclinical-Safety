"""Cross-links between TKG nodes/edges and memory documents."""
