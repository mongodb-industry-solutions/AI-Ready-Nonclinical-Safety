"""
Centralized constants for mongomem_worker.

This module is the SINGLE SOURCE OF TRUTH for all default values.
Config classes (WorkerSettings, WorkerConfig) should import from here.
"""

from __future__ import annotations

from ..mongomem_core.storage.collections import (
    EpisodicMemoryCollection,
    SemanticMemoryCollection,
    ShortTermMemoryCollection,
    SnapshotMemoryCollection,
    TaxonomicMemoryCollection,
)

# =============================================================================
# Circuit Breaker Service Names
# =============================================================================
CIRCUIT_BREAKER_EMBEDDING = "embedding_service"
CIRCUIT_BREAKER_LLM = "llm_service"

# =============================================================================
# Collection Names
# =============================================================================

# Worker-specific collections
TASKS_COLLECTION = "tasks"
TASKS_DLQ_COLLECTION = "tasks_dlq"
WORKER_STATE_COLLECTION = "worker_state"
CHANGE_STREAM_STATE_COLLECTION = "change_stream_state"
SCHEDULED_TASKS_COLLECTION = "scheduled_tasks"
RESUME_TOKENS_COLLECTION = "worker_resume_tokens"
EXTRACTION_CONFIG_COLLECTION = "extraction_config"


CORE_STM_COLLECTION = ShortTermMemoryCollection.name
CORE_SNAPSHOT_COLLECTION = SnapshotMemoryCollection.name
CORE_SEMANTIC_COLLECTION = SemanticMemoryCollection.name
CORE_EPISODIC_COLLECTION = EpisodicMemoryCollection.name
CORE_TAXONOMIC_COLLECTION = TaxonomicMemoryCollection.name

# =============================================================================
# Task Types
# =============================================================================
TASK_TYPE_EMBEDDING = "embedding"
TASK_TYPE_SNAPSHOT = "snapshot"
TASK_TYPE_TAXONOMIC = "taxonomic"
TASK_TYPE_EPISODIC = "episodic"
TASK_TYPE_SEMANTIC = "semantic"
TASK_TYPE_ENTITY = "entity"
TASK_TYPE_PREFERENCES = "preferences"
TASK_TYPE_PROCEDURAL = "procedural"
TASK_TYPE_MAINTENANCE = "maintenance"

ALL_TASK_TYPES = [
    TASK_TYPE_EMBEDDING,
    TASK_TYPE_SNAPSHOT,
    TASK_TYPE_TAXONOMIC,
    TASK_TYPE_EPISODIC,
    TASK_TYPE_SEMANTIC,
    TASK_TYPE_ENTITY,
    TASK_TYPE_PREFERENCES,
    TASK_TYPE_PROCEDURAL,
    TASK_TYPE_MAINTENANCE,
]

# Extraction types (subset of task types that use LLM for extraction)
EXTRACTION_TYPES = frozenset(
    [
        TASK_TYPE_SEMANTIC,
        TASK_TYPE_TAXONOMIC,
        TASK_TYPE_EPISODIC,
        TASK_TYPE_ENTITY,
        TASK_TYPE_PREFERENCES,
        TASK_TYPE_PROCEDURAL,
    ]
)

# =============================================================================
# Task Statuses
# =============================================================================
TASK_STATUS_QUEUED = "queued"
TASK_STATUS_RUNNING = "running"
TASK_STATUS_COMPLETED = "completed"
TASK_STATUS_FAILED = "failed"

# =============================================================================
# Default Values (Single Source of Truth)
# Config classes should import these rather than defining their own.
# =============================================================================

# Connection defaults
DEFAULT_MONGO_URI = "mongodb://localhost:27017"
DEFAULT_DB_NAME = "agentic_memory"

# Concurrency defaults
DEFAULT_MAX_CONCURRENT = 8
DEFAULT_BATCH_SIZE = 10
DEFAULT_EMBED_THREAD_POOL_SIZE = 4

# Timing defaults (seconds)
DEFAULT_POLL_INTERVAL_SECONDS = 1.0
DEFAULT_IDLE_THRESHOLD_SECONDS = 30.0
DEFAULT_IDLE_MAINTENANCE_INTERVAL_SECONDS = 60.0
DEFAULT_STALE_REQUEUE_INTERVAL_SECONDS = 60.0
DEFAULT_QUEUE_METRICS_INTERVAL_SECONDS = 10.0

# Task queue defaults
DEFAULT_LEASE_SECONDS = 300
DEFAULT_HEARTBEAT_INTERVAL_SECONDS = 30.0

# Task timeout defaults (seconds)
DEFAULT_TASK_TIMEOUT_EMBEDDING = 30.0
DEFAULT_TASK_TIMEOUT_SNAPSHOT = 60.0
DEFAULT_TASK_TIMEOUT_TAXONOMIC = 120.0
DEFAULT_TASK_TIMEOUT_EPISODIC = 120.0
DEFAULT_TASK_TIMEOUT_SEMANTIC = 120.0
DEFAULT_TASK_TIMEOUT_ENTITY = 180.0
DEFAULT_TASK_TIMEOUT_MAINTENANCE = 300.0
DEFAULT_TASK_TIMEOUT = 60.0  # Fallback for unknown task types

# Cache TTLs (seconds)
DEFAULT_EXTRACTION_CONFIG_CACHE_TTL_SECONDS = 300.0

# Snapshot promotion defaults
DEFAULT_MAX_MESSAGES = 20
DEFAULT_STALE_THRESHOLD_MINUTES = 30

# Embedding handler defaults
DEFAULT_CLAIM_TIMEOUT_SECONDS = 300  # 5 minutes - if worker crashes, another can claim


__all__ = [
    # Circuit breakers
    "CIRCUIT_BREAKER_EMBEDDING",
    "CIRCUIT_BREAKER_LLM",
    # Worker collections
    "TASKS_COLLECTION",
    "TASKS_DLQ_COLLECTION",
    "WORKER_STATE_COLLECTION",
    "CHANGE_STREAM_STATE_COLLECTION",
    "SCHEDULED_TASKS_COLLECTION",
    "RESUME_TOKENS_COLLECTION",
    "EXTRACTION_CONFIG_COLLECTION",
    # Core collections
    "CORE_STM_COLLECTION",
    "CORE_SNAPSHOT_COLLECTION",
    "CORE_SEMANTIC_COLLECTION",
    "CORE_EPISODIC_COLLECTION",
    # Task types
    "TASK_TYPE_EMBEDDING",
    "TASK_TYPE_SNAPSHOT",
    "TASK_TYPE_TAXONOMIC",
    "TASK_TYPE_EPISODIC",
    "TASK_TYPE_SEMANTIC",
    "TASK_TYPE_ENTITY",
    "TASK_TYPE_PROCEDURAL",
    "TASK_TYPE_MAINTENANCE",
    "ALL_TASK_TYPES",
    "EXTRACTION_TYPES",
    # Task statuses
    "TASK_STATUS_QUEUED",
    "TASK_STATUS_RUNNING",
    "TASK_STATUS_COMPLETED",
    "TASK_STATUS_FAILED",
    # Default values
    "DEFAULT_MONGO_URI",
    "DEFAULT_DB_NAME",
    "DEFAULT_MAX_CONCURRENT",
    "DEFAULT_BATCH_SIZE",
    "DEFAULT_EMBED_THREAD_POOL_SIZE",
    "DEFAULT_POLL_INTERVAL_SECONDS",
    "DEFAULT_IDLE_THRESHOLD_SECONDS",
    "DEFAULT_IDLE_MAINTENANCE_INTERVAL_SECONDS",
    "DEFAULT_STALE_REQUEUE_INTERVAL_SECONDS",
    "DEFAULT_QUEUE_METRICS_INTERVAL_SECONDS",
    "DEFAULT_LEASE_SECONDS",
    "DEFAULT_HEARTBEAT_INTERVAL_SECONDS",
    "DEFAULT_TASK_TIMEOUT_EMBEDDING",
    "DEFAULT_TASK_TIMEOUT_SNAPSHOT",
    "DEFAULT_TASK_TIMEOUT_TAXONOMIC",
    "DEFAULT_TASK_TIMEOUT_EPISODIC",
    "DEFAULT_TASK_TIMEOUT_SEMANTIC",
    "DEFAULT_TASK_TIMEOUT_ENTITY",
    "DEFAULT_TASK_TIMEOUT_MAINTENANCE",
    "DEFAULT_TASK_TIMEOUT",
    "DEFAULT_EXTRACTION_CONFIG_CACHE_TTL_SECONDS",
    "DEFAULT_MAX_MESSAGES",
    "DEFAULT_STALE_THRESHOLD_MINUTES",
    "DEFAULT_CLAIM_TIMEOUT_SECONDS",
]
