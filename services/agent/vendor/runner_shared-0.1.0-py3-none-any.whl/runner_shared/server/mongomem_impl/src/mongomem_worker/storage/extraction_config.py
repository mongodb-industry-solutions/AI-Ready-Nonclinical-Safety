"""
Versioned extraction configuration store with hierarchical defaults.

Manages extraction prompts and settings with:
- Hierarchical resolution: User → Group → Org → System
- Version history with rollback
- Per-scope customization
- Audit trail (created_by, notes)
- TTL cache for hot-path efficiency
"""

from __future__ import annotations

import logging
import threading
from datetime import datetime, timezone
from time import monotonic
from typing import Any, Dict, List, Literal, Optional, Tuple

from bson import ObjectId
from pymongo.database import Database

from ..constants import DEFAULT_EXTRACTION_CONFIG_CACHE_TTL_SECONDS
from .cache import get_extraction_config_collection

logger = logging.getLogger(__name__)

ExtractionType = Literal["taxonomic", "episodic", "semantic", "entity", "preferences", "procedural"]

# Cache key: (org_id, project_id, user_id, extraction_type)
CacheKey = Tuple[Optional[str], Optional[str], Optional[str], str]


class ExtractionConfigStore:
    """
    Versioned extraction configuration with hierarchical defaults.

    Resolution order (first match wins):
    1. User-specific: (org_id, project_id, user_id)
    2. Group-specific: (org_id, project_id, user_id=None)
    3. Org-specific: (org_id, project_id=None, user_id=None)
    4. System default: (org_id=None, project_id=None, user_id=None)

    Example:
        store = ExtractionConfigStore(db)

        # Set system default
        store.create(None, "taxonomic", "Default: {content}", activate=True)

        # Set org override
        store.create("acme", "taxonomic", "Acme: {content}", activate=True)

        # Set group override
        store.create("acme", "taxonomic", "Engineering: {content}",
                     project_id="engineering", activate=True)

        # Set user override
        store.create("acme", "taxonomic", "Alice: {content}",
                     project_id="engineering", user_id="alice", activate=True)

        # Lookup cascades automatically
        prompt = store.get_active("acme", "taxonomic",
                                  project_id="engineering", user_id="alice")
        # Returns: "Alice: {content}"

        prompt = store.get_active("acme", "taxonomic",
                                  project_id="engineering", user_id="bob")
        # Returns: "Engineering: {content}" (bob has no override, falls back to group)
    """

    def __init__(
        self,
        db: Database,
        cache_ttl: float = DEFAULT_EXTRACTION_CONFIG_CACHE_TTL_SECONDS,
    ) -> None:
        self._db = db
        self._collection = get_extraction_config_collection(db)
        self._cache_ttl = cache_ttl
        self._cache: Dict[CacheKey, Tuple[Optional[str], float]] = {}
        self._cache_lock = threading.Lock()

    def _scope_key(
        self,
        org_id: Optional[str],
        project_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Build the scope key for queries."""
        return {
            "org_id": org_id,
            "project_id": project_id,
            "user_id": user_id,
        }

    def _scope_label(
        self,
        org_id: Optional[str],
        project_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> str:
        """Human-readable scope label for logging."""
        parts = []
        if org_id:
            parts.append(f"org={org_id}")
        if project_id:
            parts.append(f"group={project_id}")
        if user_id:
            parts.append(f"user={user_id}")
        return "/".join(parts) if parts else "system"

    def create(
        self,
        org_id: Optional[str],
        extraction_type: ExtractionType,
        prompt: str,
        *,
        project_id: Optional[str] = None,
        user_id: Optional[str] = None,
        created_by: Optional[str] = None,
        notes: Optional[str] = None,
        activate: bool = False,
    ) -> str:
        """
        Create a new prompt version at the specified scope.

        Args:
            org_id: Organization ID (None for system default)
            extraction_type: "taxonomic", "episodic", "semantic", or "entity"
            prompt: Prompt template (use {content} placeholder)
            project_id: Project ID for group-level config (optional)
            user_id: User ID for user-level config (optional)
            created_by: User ID for audit trail
            notes: Description of changes
            activate: If True, immediately activate this version

        Returns:
            ID of created config document
        """
        scope = self._scope_key(org_id, project_id, user_id)

        # Get next version number for this scope
        latest = self._collection.find_one(
            {**scope, "extraction_type": extraction_type},
            sort=[("version", -1)],
        )
        next_version = (latest["version"] + 1) if latest else 1

        doc = {
            **scope,
            "extraction_type": extraction_type,
            "version": next_version,
            "prompt": prompt,
            "is_active": False,
            "created_at": datetime.now(timezone.utc),
            "created_by": created_by,
            "notes": notes,
        }

        result = self._collection.insert_one(doc)
        config_id = str(result.inserted_id)

        scope_label = self._scope_label(org_id, project_id, user_id)
        logger.info(
            "Created extraction config v%d for %s/%s (id=%s)",
            next_version,
            scope_label,
            extraction_type,
            config_id,
        )

        if activate:
            self.activate(
                org_id,
                extraction_type,
                project_id=project_id,
                user_id=user_id,
                version=next_version,
            )

        return config_id

    def activate(
        self,
        org_id: Optional[str],
        extraction_type: ExtractionType,
        *,
        project_id: Optional[str] = None,
        user_id: Optional[str] = None,
        version: Optional[int] = None,
        config_id: Optional[str] = None,
    ) -> bool:
        """
        Activate a specific config version at the given scope.

        Args:
            org_id: Organization ID
            extraction_type: Extraction type
            project_id: Project ID (optional)
            user_id: User ID (optional)
            version: Version number to activate (mutually exclusive with config_id)
            config_id: Document ID to activate (mutually exclusive with version)

        Returns:
            True if activation succeeded
        """
        if version is None and config_id is None:
            raise ValueError("Must specify either version or config_id")

        scope = self._scope_key(org_id, project_id, user_id)

        # Build query for target config
        query: Dict[str, Any] = {
            **scope,
            "extraction_type": extraction_type,
        }
        if version is not None:
            query["version"] = version
        else:
            query["_id"] = ObjectId(config_id)

        # Deactivate current active at this scope
        self._collection.update_many(
            {**scope, "extraction_type": extraction_type, "is_active": True},
            {"$set": {"is_active": False}},
        )

        # Activate target
        result = self._collection.update_one(query, {"$set": {"is_active": True}})

        if result.modified_count > 0:
            # Invalidate cache for this org/type (affects all users/groups)
            self.invalidate_cache(org_id=org_id, extraction_type=extraction_type)

            scope_label = self._scope_label(org_id, project_id, user_id)
            logger.info(
                "Activated extraction config v%s for %s/%s",
                version or config_id,
                scope_label,
                extraction_type,
            )
            return True

        logger.warning("Extraction config not found: %s", query)
        return False

    def rollback(
        self,
        org_id: Optional[str],
        extraction_type: ExtractionType,
        *,
        project_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> Optional[int]:
        """
        Rollback to previous config version at the given scope.

        Returns:
            Version number activated, or None if no previous version
        """
        scope = self._scope_key(org_id, project_id, user_id)

        # Get current active version
        current = self._collection.find_one(
            {**scope, "extraction_type": extraction_type, "is_active": True}
        )

        if not current:
            logger.warning("No active config to rollback from")
            return None

        # Find previous version
        previous = self._collection.find_one(
            {
                **scope,
                "extraction_type": extraction_type,
                "version": {"$lt": current["version"]},
            },
            sort=[("version", -1)],
        )

        if not previous:
            logger.warning("No previous version to rollback to")
            return None

        self.activate(
            org_id,
            extraction_type,
            project_id=project_id,
            user_id=user_id,
            version=previous["version"],
        )

        scope_label = self._scope_label(org_id, project_id, user_id)
        logger.info(
            "Rolled back %s/%s from v%d to v%d",
            scope_label,
            extraction_type,
            current["version"],
            previous["version"],
        )

        return int(previous["version"])

    def _find_active_at_scope(
        self,
        org_id: Optional[str],
        extraction_type: ExtractionType,
        project_id: Optional[str],
        user_id: Optional[str],
    ) -> Optional[Dict[str, Any]]:
        """Find active config at exact scope (no fallback)."""
        scope = self._scope_key(org_id, project_id, user_id)
        return self._collection.find_one(
            {**scope, "extraction_type": extraction_type, "is_active": True}
        )

    def _get_cache_key(
        self,
        org_id: Optional[str],
        extraction_type: str,
        project_id: Optional[str],
        user_id: Optional[str],
    ) -> CacheKey:
        """Generate cache key for a lookup context."""
        return (org_id, project_id, user_id, extraction_type)

    def _get_from_cache(self, key: CacheKey) -> Tuple[bool, Optional[str]]:
        """Check cache for a key. Returns (hit, value)."""
        with self._cache_lock:
            if key in self._cache:
                value, timestamp = self._cache[key]
                if monotonic() - timestamp < self._cache_ttl:
                    return True, value
                # Expired - remove
                del self._cache[key]
        return False, None

    def _set_cache(self, key: CacheKey, value: Optional[str]) -> None:
        """Set a value in cache."""
        with self._cache_lock:
            self._cache[key] = (value, monotonic())

    def invalidate_cache(
        self,
        org_id: Optional[str] = None,
        extraction_type: Optional[str] = None,
    ) -> int:
        """
        Invalidate cache entries. Called after create/activate/rollback.

        Args:
            org_id: If provided, only invalidate for this org
            extraction_type: If provided, only invalidate for this type

        Returns:
            Number of entries invalidated
        """
        with self._cache_lock:
            if org_id is None and extraction_type is None:
                count = len(self._cache)
                self._cache.clear()
                return count

            to_delete = []
            for key in self._cache:
                key_org, key_group, key_user, key_type = key
                if org_id is not None and key_org != org_id:
                    continue
                if extraction_type is not None and key_type != extraction_type:
                    continue
                to_delete.append(key)

            for key in to_delete:
                del self._cache[key]
            return len(to_delete)

    def get_active(
        self,
        org_id: Optional[str],
        extraction_type: ExtractionType,
        *,
        project_id: Optional[str] = None,
        user_id: Optional[str] = None,
        skip_cache: bool = False,
    ) -> Optional[str]:
        """
        Get active prompt with hierarchical fallback.

        Uses TTL cache for efficiency. Single DB query fetches all
        candidate scopes, then picks highest priority match.

        Resolution order:
        1. User-specific (if user_id provided)
        2. Group-specific (if project_id provided)
        3. Org-specific (if org_id provided)
        4. System default (all None)

        Args:
            org_id: Organization ID
            extraction_type: Extraction type
            project_id: Project ID for context (optional)
            user_id: User ID for context (optional)
            skip_cache: Bypass cache (for testing/debugging)

        Returns:
            Prompt string, or None if not found at any level
        """
        cache_key = self._get_cache_key(org_id, extraction_type, project_id, user_id)

        # Check cache first
        if not skip_cache:
            hit, cached_value = self._get_from_cache(cache_key)
            if hit:
                logger.debug("Cache hit for %s", cache_key)
                return cached_value

        # Build $or query for all candidate scopes (single round trip)
        candidates: List[Dict[str, Optional[str]]] = [
            # System default (always checked)
            {"org_id": None, "project_id": None, "user_id": None},
        ]

        if org_id:
            # Org level
            candidates.append({"org_id": org_id, "project_id": None, "user_id": None})

            if project_id:
                # Group level
                candidates.append({"org_id": org_id, "project_id": project_id, "user_id": None})

                if user_id:
                    # User in group level
                    candidates.append(
                        {"org_id": org_id, "project_id": project_id, "user_id": user_id}
                    )
            elif user_id:
                # User without group (private context)
                candidates.append({"org_id": org_id, "project_id": None, "user_id": user_id})

        # Single query with $or
        docs = list(
            self._collection.find(
                {
                    "$or": candidates,
                    "extraction_type": extraction_type,
                    "is_active": True,
                }
            )
        )

        # Find highest priority match
        result = self._resolve_priority(docs, org_id, project_id, user_id)

        # Cache result (even None)
        if not skip_cache:
            self._set_cache(cache_key, result)

        return result

    def _resolve_priority(
        self,
        docs: List[Dict[str, Any]],
        org_id: Optional[str],
        project_id: Optional[str],
        user_id: Optional[str],
    ) -> Optional[str]:
        """
        Resolve highest priority match from candidate docs.

        Priority (highest to lowest):
        1. User + Group + Org (score 4)
        2. User + Org (no group) (score 3)
        3. Group + Org (score 2)
        4. Org only (score 1)
        5. System default (score 0)
        """
        if not docs:
            return None

        def score(doc: Dict[str, Any]) -> int:
            """Calculate priority score for a doc."""
            s = 0
            if doc.get("org_id") == org_id and org_id is not None:
                s += 1
            if doc.get("project_id") == project_id and project_id is not None:
                s += 1
            if doc.get("user_id") == user_id and user_id is not None:
                s += 2  # User match is highest priority
            return s

        # Sort by score descending, pick highest
        docs.sort(key=score, reverse=True)
        best = docs[0]

        level = "system"
        if best.get("user_id"):
            level = "user"
        elif best.get("project_id"):
            level = "group"
        elif best.get("org_id"):
            level = "org"

        logger.debug("Resolved config at %s level", level)
        return str(best["prompt"])

    def get_resolution_chain(
        self,
        org_id: Optional[str],
        extraction_type: ExtractionType,
        *,
        project_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get the full resolution chain showing which configs exist at each level.

        Useful for debugging and understanding the inheritance hierarchy.

        Returns:
            List of configs from most specific to least specific, with 'level' field
        """
        chain = []

        # Check each level
        levels = [
            ("user", org_id, project_id, user_id),
            ("group", org_id, project_id, None),
            ("org", org_id, None, None),
            ("system", None, None, None),
        ]

        for level_name, o, g, u in levels:
            # Skip invalid combinations
            if level_name == "user" and not (user_id and org_id):
                continue
            if level_name == "group" and not (project_id and org_id):
                continue
            if level_name == "org" and not org_id:
                continue

            doc = self._find_active_at_scope(o, extraction_type, g, u)
            chain.append(
                {
                    "level": level_name,
                    "org_id": o,
                    "project_id": g,
                    "user_id": u,
                    "exists": doc is not None,
                    "version": doc["version"] if doc else None,
                    "is_resolved": False,  # Will mark the first found one
                }
            )

        # Mark which one is actually resolved
        for item in chain:
            if item["exists"]:
                item["is_resolved"] = True
                break

        return chain

    def get_version(
        self,
        org_id: Optional[str],
        extraction_type: ExtractionType,
        version: int,
        *,
        project_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Get a specific config version at the given scope."""
        scope = self._scope_key(org_id, project_id, user_id)
        doc = self._collection.find_one(
            {**scope, "extraction_type": extraction_type, "version": version}
        )
        return dict(doc) if doc else None

    def list_versions(
        self,
        org_id: Optional[str],
        extraction_type: ExtractionType,
        *,
        project_id: Optional[str] = None,
        user_id: Optional[str] = None,
        limit: int = 20,
    ) -> List[Dict[str, Any]]:
        """
        List config versions at the given scope (newest first).

        Returns:
            List of versions with: version, is_active, created_at, created_by, notes
        """
        scope = self._scope_key(org_id, project_id, user_id)
        cursor = (
            self._collection.find(
                {**scope, "extraction_type": extraction_type},
                {
                    "version": 1,
                    "is_active": 1,
                    "created_at": 1,
                    "created_by": 1,
                    "notes": 1,
                },
            )
            .sort("version", -1)
            .limit(limit)
        )

        return [dict(doc) for doc in cursor]

    def delete_version(
        self,
        org_id: Optional[str],
        extraction_type: ExtractionType,
        version: int,
        *,
        project_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> bool:
        """
        Delete a specific version (cannot delete active).

        Returns:
            True if deleted
        """
        scope = self._scope_key(org_id, project_id, user_id)
        result = self._collection.delete_one(
            {
                **scope,
                "extraction_type": extraction_type,
                "version": version,
                "is_active": False,  # Cannot delete active
            }
        )
        return result.deleted_count > 0

    def delete_scope(
        self,
        org_id: Optional[str],
        extraction_type: ExtractionType,
        *,
        project_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> int:
        """
        Delete all versions at a scope (removes override, falls back to parent).

        Returns:
            Number of documents deleted
        """
        scope = self._scope_key(org_id, project_id, user_id)
        result = self._collection.delete_many({**scope, "extraction_type": extraction_type})

        if result.deleted_count > 0:
            scope_label = self._scope_label(org_id, project_id, user_id)
            logger.info(
                "Deleted %d configs for %s/%s (will fall back to parent)",
                result.deleted_count,
                scope_label,
                extraction_type,
            )

        return result.deleted_count


__all__ = ["ExtractionConfigStore", "ExtractionType"]
