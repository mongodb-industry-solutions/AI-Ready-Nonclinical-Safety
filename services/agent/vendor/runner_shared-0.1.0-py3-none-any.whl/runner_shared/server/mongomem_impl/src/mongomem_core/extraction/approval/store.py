"""
PendingStore: CRUD operations for pending extractions.

Provides storage layer for the extraction_pending collection.
No business logic - just database operations.
"""

from __future__ import annotations

from datetime import timedelta
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

if TYPE_CHECKING:
    from pymongo.database import Database

from mongomem_core.common.utils import safe_object_id, utcnow
from mongomem_core.extraction.approval.types import (
    ExtractionType,
    PendingExtraction,
    PendingPayload,
    PendingStatus,
    from_mongo_doc,
    to_mongo_doc,
)
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.observability import CoreObservability

DEFAULT_PENDING_TTL_HOURS = 72  # 3 days for unreviewed items
DEFAULT_AUDIT_RETENTION_DAYS = 30  # How long to keep approved/rejected items


class PendingStore:
    """CRUD operations for pending extractions. No business logic."""

    def __init__(
        self,
        db: "Database",
        pending_ttl_hours: int = DEFAULT_PENDING_TTL_HOURS,
        audit_retention_days: int = DEFAULT_AUDIT_RETENTION_DAYS,
        obs: Optional[CoreObservability] = None,
    ):
        self._db = db
        self._col = db["extraction_pending"]
        self._pending_ttl_hours = pending_ttl_hours
        self._audit_retention_days = audit_retention_days
        self._obs = obs or CoreObservability()

    def stage(
        self,
        org_id: str,
        user_id: str,
        source_id: str,
        extraction_type: ExtractionType,
        payload: PendingPayload,
        visibility: ChunkVisibility = ChunkVisibility.PRIVATE,
        project_id: Optional[str] = None,
    ) -> str:
        """Stage a single extraction. Returns pending_id."""
        now = utcnow()
        pending = PendingExtraction(
            org_id=org_id,
            user_id=user_id,
            source_id=source_id,
            extraction_type=extraction_type,
            payload=payload,
            visibility=visibility,
            project_id=project_id,
            status="pending",
            created_at=now,
            expires_at=now + timedelta(hours=self._pending_ttl_hours),
        )
        doc = to_mongo_doc(pending)
        result = self._col.insert_one(doc)

        action = getattr(payload, "action", "unknown")
        self._obs.approval_staged(extraction_type, action, source_id)

        return str(result.inserted_id)

    def stage_batch(
        self,
        items: List[Tuple[ExtractionType, PendingPayload]],
        org_id: str,
        user_id: str,
        source_id: str,
        visibility: ChunkVisibility = ChunkVisibility.PRIVATE,
        project_id: Optional[str] = None,
    ) -> List[str]:
        """Stage multiple extractions. Returns pending_ids.

        Note: PendingDecisionPayload.action only allows ADD/UPDATE/REINFORCE,
        so DUPLICATE decisions are filtered at the pipeline level before staging.
        """
        if not items:
            return []
        now = utcnow()
        docs = []
        for extraction_type, payload in items:
            pending = PendingExtraction(
                org_id=org_id,
                user_id=user_id,
                source_id=source_id,
                extraction_type=extraction_type,
                payload=payload,
                visibility=visibility,
                project_id=project_id,
                status="pending",
                created_at=now,
                expires_at=now + timedelta(hours=self._pending_ttl_hours),
            )
            docs.append(to_mongo_doc(pending))
        if not docs:
            return []
        result = self._col.insert_many(docs)

        for extraction_type, payload in items:
            action = getattr(payload, "action", "unknown")
            self._obs.approval_staged(extraction_type, action, source_id)

        return [str(oid) for oid in result.inserted_ids]

    def find(
        self,
        org_id: str,
        user_id: Optional[str] = None,
        project_id: Optional[str] = None,
        extraction_type: Optional[ExtractionType] = None,
        source_id: Optional[str] = None,
        status: PendingStatus = "pending",
        limit: int = 100,
    ) -> List[PendingExtraction]:
        """Query pending extractions."""
        query: Dict[str, Any] = {"org_id": org_id, "status": status}
        if user_id:
            query["user_id"] = user_id
        if project_id:
            query["project_id"] = project_id
        if extraction_type:
            query["extraction_type"] = extraction_type
        if source_id:
            query["source_id"] = source_id

        cursor = self._col.find(query).limit(limit).sort("created_at", -1)
        return [from_mongo_doc(doc) for doc in cursor]

    def get(self, pending_id: str) -> Optional[PendingExtraction]:
        """Get single pending extraction by ID."""
        oid = safe_object_id(pending_id, "PendingStore.get")
        if oid is None:
            return None
        doc = self._col.find_one({"_id": oid})
        return from_mongo_doc(doc) if doc else None

    def get_many(self, pending_ids: List[str]) -> Dict[str, PendingExtraction]:
        """Get multiple pending extractions by ID."""
        if not pending_ids:
            return {}
        oids = []
        oid_to_str: Dict[Any, str] = {}
        for pending_id in pending_ids:
            oid = safe_object_id(pending_id, "PendingStore.get_many")
            if oid is None:
                continue
            oids.append(oid)
            oid_to_str[oid] = pending_id
        if not oids:
            return {}
        docs = self._col.find({"_id": {"$in": oids}})
        out: Dict[str, PendingExtraction] = {}
        for doc in docs:
            oid = doc.get("_id")
            lookup_id = oid_to_str.get(oid)
            if lookup_id is None:
                continue
            out[lookup_id] = from_mongo_doc(doc)
        return out

    def mark_approved(
        self,
        pending_id: str,
        memory_id: str,
        reviewed_by: Optional[str] = None,
    ) -> bool:
        """Mark as approved. Set expires_at for configurable audit retention."""
        oid = safe_object_id(pending_id, "PendingStore.mark_approved")
        if oid is None:
            return False
        now = utcnow()

        # Atomically update and return the original document (for queue time calculation)
        doc = self._col.find_one_and_update(
            {"_id": oid, "status": "pending"},
            {
                "$set": {
                    "status": "approved",
                    "memory_id": memory_id,
                    "reviewed_at": now,
                    "reviewed_by": reviewed_by,
                    "expires_at": now + timedelta(days=self._audit_retention_days),
                }
            },
        )

        if doc:
            # Calculate queue time (time from staging to approval)
            created_at = doc.get("created_at")
            queue_time_ms = 0.0
            if created_at:
                # Handle timezone-aware vs naive datetime comparison
                try:
                    queue_time_ms = (now - created_at).total_seconds() * 1000
                except TypeError:
                    # If one is timezone-aware and other is naive, log warning and use 0
                    self._obs.approval_timezone_mismatch(pending_id, memory_id)

            self._obs.approval_approved(memory_id, queue_time_ms, reviewed_by)
            return True

        return False

    def mark_rejected(
        self,
        pending_id: str,
        reason: Optional[str] = None,
        reviewed_by: Optional[str] = None,
    ) -> bool:
        """Mark as rejected. Set expires_at for configurable audit retention."""
        oid = safe_object_id(pending_id, "PendingStore.mark_rejected")
        if oid is None:
            return False
        now = utcnow()
        result = self._col.update_one(
            {"_id": oid, "status": "pending"},
            {
                "$set": {
                    "status": "rejected",
                    "rejection_reason": reason,
                    "reviewed_at": now,
                    "reviewed_by": reviewed_by,
                    "expires_at": now + timedelta(days=self._audit_retention_days),
                }
            },
        )

        if result.modified_count > 0:
            self._obs.approval_rejected(pending_id, reason, reviewed_by)
            return True

        return False


__all__ = [
    "DEFAULT_AUDIT_RETENTION_DAYS",
    "DEFAULT_PENDING_TTL_HOURS",
    "PendingStore",
]
