"""Orchestration entrypoint for building retrieval context.

This module provides the ContextBuilder class, which orchestrates the full
retrieval pipeline: embedding generation, memory fetching, ranking, budgeting,
and formatting into a final context response.
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, List, Optional, Set

from mongomem_core.exceptions import EmbeddingGenerationError
from mongomem_core.memory.user_prefs import get_session_preferences_with_fallback
from mongomem_core.models.filters import MetadataFilter
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.episodic import EpisodicOut
from mongomem_core.models.memory.semantic import SemanticOut
from mongomem_core.models.memory.short_term import ShortTermOut
from mongomem_core.models.memory.user_prefs import UserContextMemoryOut
from mongomem_core.models.retrieval import (
    ContextConfig,
    ContextResponse,
    MemorySource,
)
from mongomem_core.observability import CoreObservability
from mongomem_core.retrieval.budgeting import Budgeter
from mongomem_core.retrieval.formatting import Formatter
from mongomem_core.retrieval.ranking import MemoryRanker
from mongomem_core.retrieval.sources import RetrievalHub
from pymongo.database import Database

if TYPE_CHECKING:
    from mongomem_core.protocols import EmbedderProtocol, LLMProtocol

logger = logging.getLogger(__name__)


class ContextBuilder:
    """
    Main orchestrator for building retrieval context.

    Coordinates the full retrieval pipeline:
    1. Generate query embedding (if needed) using EmbedderProtocol
    2. Fetch memories via RetrievalHub
    3. Rank memories via MemoryRanker
    4. Select within budget via Budgeter
    5. Format into final context via Formatter (includes user_context preferences)

    Example:
        >>> builder = ContextBuilder(
        ...     retrieval_hub=RetrievalHub(),
        ...     ranker=MemoryRanker(),
        ...     budgeter=Budgeter(),
        ...     formatter=Formatter(),
        ...     embedder=my_embedder,
        ...     llm=my_llm,
        ... )
        >>> response = builder.build_context(
        ...     db=db,
        ...     session_id="sess_123",
        ...     query="What did we discuss yesterday?",
        ...     org_id="org_1",
        ...     user_id="user_1",
        ... )
    """

    def __init__(
        self,
        retrieval_hub: RetrievalHub,
        ranker: MemoryRanker,
        budgeter: Budgeter,
        formatter: Formatter,
        embedder: Optional["EmbedderProtocol"] = None,
        llm: Optional["LLMProtocol"] = None,
        obs: Optional[CoreObservability] = None,
    ) -> None:
        """
        Initialize ContextBuilder with required components.

        Args:
            retrieval_hub: Hub for fetching memories from multiple sources
            ranker: Ranker for scoring and sorting memories
            budgeter: Budgeter for selecting memories within token budget
            formatter: Formatter for producing final context output
            embedder: Optional embedder for query embedding generation.
                Required if query_embedding is not provided to build_context().
            llm: Optional LLM for model-specific token counting and format detection
            obs: Optional CoreObservability for observability (metrics/spans/events).
                If not provided, a default CoreObservability with NoOpObservability is used.
        """
        self._retrieval_hub = retrieval_hub
        self._ranker = ranker
        self._budgeter = budgeter
        self._formatter = formatter
        self._embedder = embedder
        self._llm = llm
        self._obs = obs or CoreObservability()

    def build_context(
        self,
        db: Database,
        session_id: str,
        query: str,
        org_id: str,
        *,
        user_id: Optional[str] = None,
        query_embedding: Optional[List[float]] = None,
        visibility: Optional[ChunkVisibility] = None,
        project_id: Optional[str] = None,
        metadata_filter: Optional[MetadataFilter] = None,
        config: Optional[ContextConfig] = None,
        user_context: Optional[UserContextMemoryOut] = None,
        auto_fetch_user_context: bool = True,
        top_k: int = 50,
        enabled_sources: Optional[Set[MemorySource]] = None,
        stm_memories: Optional[List[ShortTermOut]] = None,
        episodic_memories: Optional[List[EpisodicOut]] = None,
        semantic_memories: Optional[List[SemanticOut]] = None,
    ) -> ContextResponse:
        """
        Build context by orchestrating the full retrieval pipeline.

        This is the main entry point for context building. It coordinates all
        pipeline stages and tracks timing metadata for performance monitoring.

        Args:
            db: MongoDB database instance
            session_id: Session identifier for STM retrieval
            query: Query text for embedding generation (used if query_embedding not provided)
            org_id: Organization ID for multi-tenancy
            user_id: Optional user ID filter
            query_embedding: Pre-computed query embedding vector. If not provided,
                the embedder must be available to generate it.
            visibility: Optional visibility scope filter
            project_id: Optional group ID filter (for shared visibility)
            config: Context configuration. Defaults to ContextConfig() if not provided.
            user_context: Optional user context for personalization (tone, style,
                language, preferred_format). Passed to Formatter for inclusion in output.
                If not provided and auto_fetch_user_context is True, will be fetched
                automatically from the database.
            auto_fetch_user_context: If True and user_context is not provided,
                automatically fetch session preferences from the database with
                fallback to user-level defaults. Default: True.
            top_k: Maximum number of results per source (default: 50)
            enabled_sources: Set of memory sources to include.
                Defaults to all sources if not provided.
            stm_memories: Optional pre-fetched short-term memories
            episodic_memories: Optional pre-fetched episodic memories
            semantic_memories: Optional pre-fetched semantic memories

        Returns:
            ContextResponse with formatted context and metadata including timing

        Raises:
            ValueError: If query_embedding not provided and embedder not available,
                or if query is empty when embedding is required.
            EmbeddingGenerationError: If embedding generation fails (network error,
                API rate limit, invalid input, or empty response).
        """
        pipeline_start = time.perf_counter()

        # Initialize config with defaults
        effective_config = config or ContextConfig()

        # Override enabled_sources if provided.
        if enabled_sources is not None:
            effective_config.enabled_sources = enabled_sources

        # Stage 1: Embed query
        embedding_start = time.perf_counter()
        with self._obs.span_context_stage("embed_query") as span_attrs:
            effective_embedding = self._resolve_query_embedding(query, query_embedding)
            span_attrs["dimension"] = len(effective_embedding)
        embedding_duration = time.perf_counter() - embedding_start

        logger.debug(
            "Query embedding resolved: dimension=%d, duration=%.3fs",
            len(effective_embedding),
            embedding_duration,
        )

        # Stage 2: Fetch memories from enabled sources
        retrieval_start = time.perf_counter()
        with self._obs.span_context_stage("fetch_memories") as span_attrs:
            fetched_memories = self._retrieval_hub.fetch_memories(
                db=db,
                session_id=session_id,
                query_embedding=effective_embedding,
                org_id=org_id,
                user_id=user_id,
                visibility=visibility,
                project_id=project_id,
                metadata_filter=metadata_filter,
                top_k=top_k,
                similarity_threshold=effective_config.similarity_threshold,
                enabled_sources=effective_config.enabled_sources,
                stm_memories=stm_memories,
                episodic_memories=episodic_memories,
                semantic_memories=semantic_memories,
            )
            span_attrs["memories_fetched"] = len(fetched_memories)
        retrieval_duration = time.perf_counter() - retrieval_start

        logger.debug(
            "Fetched %d memories in %.3fs",
            len(fetched_memories),
            retrieval_duration,
        )

        # Stage 3: Rank memories by multi-factor scoring
        ranking_start = time.perf_counter()
        with self._obs.span_context_stage("rank") as span_attrs:
            ranked_memories = self._ranker.rank_memories(fetched_memories, effective_config)
            span_attrs["memories_ranked"] = len(ranked_memories)
        ranking_duration = time.perf_counter() - ranking_start

        logger.debug(
            "Ranked %d memories in %.3fs",
            len(ranked_memories),
            ranking_duration,
        )

        # Stage 4: Select memories within token budget
        budgeting_start = time.perf_counter()
        with self._obs.span_context_stage("budget") as span_attrs:
            selected_memories = self._budgeter.select_memories(
                memories=ranked_memories,
                config=effective_config,
                llm=self._llm,
            )
            span_attrs["memories_selected"] = len(selected_memories)
            span_attrs["memories_dropped"] = len(ranked_memories) - len(selected_memories)
        budgeting_duration = time.perf_counter() - budgeting_start

        logger.debug(
            "Selected %d/%d memories within budget in %.3fs",
            len(selected_memories),
            len(ranked_memories),
            budgeting_duration,
        )

        # Stage 5: Format context
        formatting_start = time.perf_counter()

        # Auto-fetch user context if enabled and not provided
        resolved_user_context = user_context
        if resolved_user_context is None and auto_fetch_user_context and session_id and user_id:
            try:
                resolved_user_context = get_session_preferences_with_fallback(
                    db=db,
                    org_id=org_id,
                    user_id=user_id,
                    session_id=session_id,
                )
                if resolved_user_context:
                    logger.debug(
                        "Auto-fetched user preferences for session=%s: tone=%s, style=%s",
                        session_id,
                        resolved_user_context.tone,
                        resolved_user_context.style,
                    )
            except Exception as e:
                logger.warning(
                    "Failed to auto-fetch user preferences for session=%s: %s",
                    session_id,
                    e,
                )

        with self._obs.span_context_stage("format") as span_attrs:
            response = self._formatter.format_context(
                memories=selected_memories,
                config=effective_config,
                user_context=resolved_user_context,
                llm=self._llm,
            )
            span_attrs["token_count"] = response.metadata.token_count
        formatting_duration = time.perf_counter() - formatting_start

        logger.debug(
            "Formatted context in %.3fs, token_count=%d",
            formatting_duration,
            response.metadata.token_count,
        )

        # Add timing metadata
        pipeline_duration = time.perf_counter() - pipeline_start
        response.metadata.add_timing("embedding", embedding_duration)
        response.metadata.add_timing("retrieval", retrieval_duration)
        response.metadata.add_timing("ranking", ranking_duration)
        response.metadata.add_timing("budgeting", budgeting_duration)
        response.metadata.add_timing("formatting", formatting_duration)
        response.metadata.add_timing("total", pipeline_duration)

        # Emit overall context building metrics
        total_memories = sum(response.metadata.memory_counts.values())
        self._obs.context_built(
            memories_count=total_memories,
            tokens=response.metadata.token_count,
            duration_ms=pipeline_duration * 1000,
        )

        logger.info(
            "Context built: memories=%d, tokens=%d, total_time=%.3fs",
            sum(response.metadata.memory_counts.values()),
            response.metadata.token_count,
            pipeline_duration,
        )

        return response

    def _resolve_query_embedding(
        self,
        query: str,
        query_embedding: Optional[List[float]],
    ) -> List[float]:
        """
        Resolve query embedding from provided value or generate via embedder.

        Priority:
        1. Use query_embedding if provided and non-empty
        2. Generate embedding via embedder if available
        3. Raise ValueError if neither option available

        Args:
            query: Query text for embedding generation
            query_embedding: Pre-computed embedding vector (may be None or empty)

        Returns:
            Valid embedding vector (non-empty list of floats)

        Raises:
            ValueError: If embedding cannot be resolved (no embedder available)
            EmbeddingGenerationError: If embedding generation fails (network error,
                API rate limit, invalid input, or empty response)
        """
        if query_embedding and len(query_embedding) > 0:
            return query_embedding

        if self._embedder is not None:
            if not query or not query.strip():
                raise ValueError(
                    "Query text is required for embedding generation when "
                    "query_embedding is not provided"
                )

            logger.debug("Generating query embedding via embedder")
            try:
                embedding = self._embedder.embed(query)
                if not embedding or len(embedding) == 0:
                    raise EmbeddingGenerationError(
                        "Embedder returned empty embedding vector",
                        query=query,
                    )
                return embedding
            except EmbeddingGenerationError:
                raise
            except Exception as e:
                logger.error("Failed to generate embedding: %s", e, exc_info=True)
                raise EmbeddingGenerationError(
                    f"Embedding generation failed: {e}",
                    query=query,
                    original_error=e,
                ) from e

        raise ValueError(
            "Cannot build context: query_embedding not provided and "
            "embedder not available. Either provide query_embedding or "
            "initialize ContextBuilder with an embedder."
        )
