"""
Text chunkers for the ingestion pipeline.

Chunkers split extracted text into smaller pieces suitable for embedding.
"""

from mongomem_core.ingest.chunkers.base import TextChunker
from mongomem_core.ingest.chunkers.recursive import ChunkWithOffset, RecursiveChunker

__all__ = [
    "TextChunker",
    "RecursiveChunker",
    "ChunkWithOffset",
]
