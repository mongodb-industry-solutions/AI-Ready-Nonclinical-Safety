"""
Configuration models for conversation thread retrieval.

Thread retrieval enables "conversation resumption" - retrieving coherent
sequences of snapshots that represent complete conversation threads,
not just scattered top-k results.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class ThreadRetrievalConfig:
    """
    Configuration for adaptive thread retrieval.

    This controls how conversation threads are discovered and expanded
    from an initial query. The adaptive strategy combines topic-based,
    session-based, and similarity-based expansion to retrieve coherent
    conversation context.

    Example:
        >>> config = ThreadRetrievalConfig(
        ...     search_mode="hybrid",
        ...     expansion="adaptive",
        ...     max_tokens=8000,
        ... )
        >>> thread = retrieve_conversation_thread(backend, org_id, "MongoDB indexes", config)
    """

    # ─────────────────────────────────────────────────────────────────────
    # Search Mode - How to find the anchor snapshot(s)
    # ─────────────────────────────────────────────────────────────────────

    search_mode: Literal["vector", "text", "hybrid"] = "vector"
    """
    How to search for anchor snapshots:
    - "vector": Embedding similarity (requires embedder)
    - "text": Full-text search on message content
    - "hybrid": Combines vector + text search (best results, requires embedder)
    """

    anchor_top_k: int = 3
    """Number of candidate anchors to consider. Higher = more exploration."""

    # ─────────────────────────────────────────────────────────────────────
    # Expansion Strategy - How to grow the thread from the anchor
    # ─────────────────────────────────────────────────────────────────────

    expansion: Literal["topic", "session", "similarity", "adaptive"] = "adaptive"
    """
    How to expand from anchor to full thread:
    - "topic": Follow topic_id links within session
    - "session": Get snapshots before/after anchor in same session
    - "similarity": Chase embedding similarity across sessions
    - "adaptive": Smart combination (topic → session → cross-session)
    """

    # ─────────────────────────────────────────────────────────────────────
    # Termination Conditions - When to stop expanding
    # ─────────────────────────────────────────────────────────────────────

    min_relevancy: float = 0.65
    """Minimum similarity score for including a snapshot."""

    max_snapshots: int = 10
    """Maximum number of snapshots in the thread."""

    max_tokens: int = 8_000
    """Maximum total tokens across all snapshots (context budget)."""

    # ─────────────────────────────────────────────────────────────────────
    # Session Behavior - How to handle session boundaries
    # ─────────────────────────────────────────────────────────────────────

    allow_cross_session: bool = True
    """
    If True, include related snapshots from other sessions.
    Useful for "What do you know about X?" queries.
    If False, stay within the anchor's session only.
    """

    session_window_before: int = 3
    """Number of snapshots to include before anchor in session."""

    session_window_after: int = 2
    """Number of snapshots to include after anchor in session."""

    # ─────────────────────────────────────────────────────────────────────
    # Similarity Cascade - Settings for similarity-based expansion
    # ─────────────────────────────────────────────────────────────────────

    similarity_top_k: int = 3
    """Candidates to consider at each similarity cascade step."""

    similarity_min_score: float = 0.70
    """Minimum score to continue similarity cascade."""

    def with_overrides(self, **kwargs) -> "ThreadRetrievalConfig":
        """
        Create a new config with specific overrides.

        Useful for temporarily adjusting settings without mutation.

        Example:
            >>> narrow_config = config.with_overrides(
            ...     session_window_before=1,
            ...     session_window_after=1,
            ... )
        """
        return ThreadRetrievalConfig(**{**self.__dict__, **kwargs})


# ─────────────────────────────────────────────────────────────────────────────
# Preset Configurations for Common Use Cases
# ─────────────────────────────────────────────────────────────────────────────

# Resume the current conversation
RESUME_SESSION_CONFIG = ThreadRetrievalConfig(
    search_mode="vector",
    expansion="session",
    allow_cross_session=False,
    max_snapshots=5,
    max_tokens=4_000,
)

# "What do you know about X?" - cross-session knowledge retrieval
KNOWLEDGE_RETRIEVAL_CONFIG = ThreadRetrievalConfig(
    search_mode="hybrid",
    expansion="adaptive",
    allow_cross_session=True,
    max_snapshots=10,
    max_tokens=8_000,
    min_relevancy=0.6,
)

# Deep context for complex queries
DEEP_CONTEXT_CONFIG = ThreadRetrievalConfig(
    search_mode="hybrid",
    expansion="adaptive",
    allow_cross_session=True,
    max_snapshots=15,
    max_tokens=12_000,
    session_window_before=5,
    session_window_after=3,
    min_relevancy=0.55,
)

# Fast, minimal retrieval
QUICK_CONTEXT_CONFIG = ThreadRetrievalConfig(
    search_mode="vector",
    expansion="topic",
    allow_cross_session=False,
    max_snapshots=3,
    max_tokens=2_000,
)


__all__ = [
    "ThreadRetrievalConfig",
    "RESUME_SESSION_CONFIG",
    "KNOWLEDGE_RETRIEVAL_CONFIG",
    "DEEP_CONTEXT_CONFIG",
    "QUICK_CONTEXT_CONFIG",
]
