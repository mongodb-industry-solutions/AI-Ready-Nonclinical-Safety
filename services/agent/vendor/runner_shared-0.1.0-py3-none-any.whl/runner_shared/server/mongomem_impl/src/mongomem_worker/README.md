# mongomem_worker

Background processor for memory embeddings and extractions. Watches for new memory content and processes it asynchronously.

## Overview

The worker handles:

- **Embeddings**: Generate vector embeddings for STM and snapshot content
- **Extractions**: Extract structured knowledge using LLMs (taxonomic, episodic, semantic, entity)
- **Maintenance**: Snapshot promotion, cleanup, archival

## Features

- **Engine-First Design**: Takes a `MemoryEngine` instance—embedder/LLM are configured once
- **Notebook-Safe**: Use `start_background()` in Jupyter notebooks
- **Production-Ready**: Signal handling, graceful shutdown, health monitoring
- **Multi-Tenant**: Optional tenant isolation via `tenant_id`
- **Horizontal Scaling**: Run multiple workers with `scaling_mode="distributed"`
- **Pluggable Observability**: Implement `ObservabilityProtocol` for any backend
- **Error Classification**: Smart retries (permanent vs transient errors)
- **Task Timeouts**: Per-task-type configurable timeouts
- **Non-Blocking I/O**: Embedding/LLM calls run in executor threads
- **Circuit Breaker**: Protects external services (embedding, LLM) from cascading failures
- **Recovery Logging**: Tracks task recovery history for debugging
- **Queue Depth Metrics**: Real-time queue size monitoring for autoscaling

## Quick Start

```python
from mongomem_core import MemoryEngine, Settings
from mongomem_worker import MongoMemWorker

# 1. Implement your embedder (example with Voyage AI)
class VoyageEmbedder:
    def __init__(self):
        import voyageai
        self.client = voyageai.Client()
    
    def embed(self, text: str) -> list[float]:
        result = self.client.embed([text], model="voyage-3")
        return result.embeddings[0]
    
    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        result = self.client.embed(texts, model="voyage-3")
        return result.embeddings
    
    @property
    def dimension(self) -> int:
        return 1024
    
    @property
    def model_id(self) -> str:
        return "voyage-3"

# 2. Create engine with embedder attached
engine = MemoryEngine(
    Settings(
        mongo_uri="mongodb://localhost:27017",
        db_name="my_app",
        embedding_dimension=1024,  # Must match embedder.dimension
    ),
    embedder=VoyageEmbedder(),
)

# 3. Create and run worker
worker = MongoMemWorker(engine)
worker.run()
```

## Protocols

Users implement these protocols to provide embedding/LLM infrastructure.

### EmbedderProtocol

**Required** for all workers. Generates vector embeddings for memory content.

```python
from mongomem_core import EmbedderProtocol

class MyEmbedder(EmbedderProtocol):
    def embed(self, text: str) -> list[float]:
        """Embed a single text string."""
        ...
    
    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Embed multiple texts (for efficiency)."""
        ...
    
    @property
    def dimension(self) -> int:
        """Embedding dimension (e.g., 1024 for voyage-3)."""
        ...
    
    @property
    def model_id(self) -> str:
        """Model identifier for provenance tracking."""
        ...
```

### LLMProtocol

**Optional**. Required only for extraction features (taxonomic, episodic, semantic, entity).

```python
from mongomem_core import LLMProtocol

class MyLLM(LLMProtocol):
    def complete(self, prompt: str, **kwargs) -> str:
        """Generate a text completion."""
        ...
    
    def complete_json(self, prompt: str, schema: dict, **kwargs) -> dict:
        """Generate structured JSON output."""
        ...
```

## Configuration

### Constructor Arguments

```python
worker = MongoMemWorker(
    # Required - engine with embedder attached
    engine,
    
    # Optional - Extractions
    extraction_config={
        "taxonomic": {"enabled": True, "prompt": "Custom prompt..."},
        "episodic": {"enabled": True},
        "semantic": {"enabled": False},
        "entity": {"enabled": True},
    },
    
    # Optional - Worker behavior
    concurrency=5,                # Max concurrent tasks
    batch_size=10,                # Batch size for processing
    poll_interval_seconds=1.0,    # Polling interval
    tenant_id="tenant_abc",       # Optional tenant identifier
    scaling_mode="single",        # "single" or "distributed"
    worker_db_name=None,          # Separate DB for task queue (optional)
    observability=None,           # Custom observability backend
)
```

### Embedding Dimension Validation

**Important**: The engine validates that `embedding_dimension` in `Settings` matches your embedder's dimension at construction time.

```python
# Dimension mismatch raises ValueError at construction
engine = MemoryEngine(
    Settings(
        mongo_uri="...",
        db_name="...",
        embedding_dimension=1024,  # Must match embedder.dimension
    ),
    embedder=MyEmbedder(),  # Has .dimension property
)
# Raises ValueError if MyEmbedder.dimension != 1024
```

| Scenario | Without validation | With validation |
|----------|-------------------|-----------------|
| Embedder: 512, Index: 1024 | Silent failure - inserts work, search returns nothing | `ValueError` at startup |
| Model changed | Silent failure until you notice | `ValueError` at startup |

### Environment Variables

When using `MongoMemWorker.from_env()` or the CLI:

| Variable | Description | Default |
|----------|-------------|---------|
| `MONGOMEM_WORKER_MONGO_URI` | MongoDB connection string | `mongodb://localhost:27017` |
| `MONGOMEM_WORKER_DB_NAME` | Database name | `agentic_memory` |
| `MONGOMEM_WORKER_MAX_CONCURRENT` | Max concurrent tasks | `8` |
| `MONGOMEM_WORKER_BATCH_SIZE` | Batch size | `10` |
| `MONGOMEM_WORKER_POLL_INTERVAL_SECONDS` | Poll interval | `1.0` |

### Extraction Config

Each extraction type can be configured independently:

```python
extraction_config = {
    "taxonomic": {
        "enabled": True,           # Enable/disable this extraction
        "prompt": "Custom...",     # Override default prompt
        "llm": CustomLLM(),        # Use different LLM for this type
        "batch_size": 5,           # Type-specific batch size
        "use_db_prompts": True,    # Enable database-driven prompts (hot-reload)
    },
    "episodic": {...},
    "semantic": {...},
    "entity": {...},
}
```

### Hierarchical Prompt Configuration

The worker supports **database-driven prompts** with hierarchical defaults. This enables:

- **Hot-reload**: Change prompts without restarting workers
- **Version history**: Rollback to previous prompts
- **Per-scope customization**: Different prompts for users, groups, or orgs

#### Resolution Order

```
┌─────────────────────────────────────────────────────────┐
│            Prompt Resolution Hierarchy                  │
│                                                         │
│   1. User     →  org_id + project_id + user_id           │
│       ↓ not found                                       │
│   2. Group    →  org_id + project_id                     │
│       ↓ not found                                       │
│   3. Org      →  org_id only                           │
│       ↓ not found                                       │
│   4. System   →  global default                        │
│       ↓ not found                                       │
│   5. Static   →  hardcoded prompt                      │
└─────────────────────────────────────────────────────────┘
```

#### Using ExtractionConfigStore

```python
from mongomem_worker import ExtractionConfigStore

config = ExtractionConfigStore(db)

# Set system default (fallback for everyone)
config.create(None, "taxonomic", "Default prompt: {content}", activate=True)

# Set org-level override
config.create("acme", "taxonomic", "Acme style: {content}", activate=True)

# Set group-level override (e.g., engineering team)
config.create(
    "acme", "taxonomic", "Technical extraction: {content}",
    project_id="engineering",
    activate=True,
)

# Set user-level override (power user customization)
config.create(
    "acme", "taxonomic", "Alice's preferred style: {content}",
    project_id="engineering",
    user_id="alice",
    activate=True,
)
```

#### Lookup Examples

```python
# Alice gets her custom prompt
prompt = config.get_active(
    org_id="acme",
    extraction_type="taxonomic",
    project_id="engineering",
    user_id="alice",
)
# Returns: "Alice's preferred style: {content}"

# Bob (no custom prompt) falls back to group
prompt = config.get_active(
    org_id="acme",
    extraction_type="taxonomic",
    project_id="engineering",
    user_id="bob",
)
# Returns: "Technical extraction: {content}"

# Sales team (no group override) falls back to org
prompt = config.get_active(
    org_id="acme",
    extraction_type="taxonomic",
    project_id="sales",
)
# Returns: "Acme style: {content}"

# New org (no overrides) falls back to system default
prompt = config.get_active(
    org_id="newcorp",
    extraction_type="taxonomic",
)
# Returns: "Default prompt: {content}"
```

#### Version Management

```python
# List versions at a scope
versions = config.list_versions("acme", "taxonomic", project_id="engineering")
# [{"version": 2, "is_active": True, "notes": "Added context"},
#  {"version": 1, "is_active": False, "notes": "Initial"}]

# Rollback to previous version
config.rollback("acme", "taxonomic", project_id="engineering")

# Delete override (falls back to parent scope)
config.delete_scope("acme", "taxonomic", project_id="engineering", user_id="alice")

# Debug: see full resolution chain
chain = config.get_resolution_chain(
    org_id="acme",
    extraction_type="taxonomic",
    project_id="engineering",
    user_id="alice",
)
# [{"level": "user", "exists": True, "is_resolved": True},
#  {"level": "group", "exists": True, "is_resolved": False},
#  {"level": "org", "exists": True, "is_resolved": False},
#  {"level": "system", "exists": True, "is_resolved": False}]
```

#### Enable in Worker

```python
worker = MongoMemWorker(
    engine,
    extraction_config={
        "taxonomic": {"enabled": True, "use_db_prompts": True},
        "episodic": {"enabled": True, "use_db_prompts": True},
        # Static prompts for others
        "semantic": {"enabled": True, "prompt": "Static prompt..."},
    },
)
```

## Usage Patterns

### Embedding Only (No LLM)

```python
engine = MemoryEngine(
    Settings(mongo_uri="...", db_name="..."),
    embedder=MyEmbedder(),
    # No llm = extractions disabled
)

worker = MongoMemWorker(engine)
worker.run()
```

### Full Processing (Embedding + Extractions)

```python
engine = MemoryEngine(
    Settings(mongo_uri="...", db_name="..."),
    embedder=MyEmbedder(),
    llm=MyLLM(),  # Enables extractions
)

worker = MongoMemWorker(
    engine,
    extraction_config={
        "taxonomic": {"enabled": True},
        "episodic": {"enabled": True},
        "semantic": {"enabled": True},
        "entity": {"enabled": True},
    },
)
worker.run()
```

### From Environment (Production)

```python
engine = MemoryEngine.from_env(
    embedder=MyEmbedder(),
    llm=MyLLM(),
)
worker = MongoMemWorker.from_env(engine)
worker.run()
```

### Async Integration

```python
import asyncio

async def main():
    engine = MemoryEngine(...)
    worker = MongoMemWorker(engine)
    await worker.run_async()

asyncio.run(main())
```

### Jupyter Notebook (Non-Blocking)

```python
# In a notebook cell - starts worker in background thread
engine = MemoryEngine(
    Settings(mongo_uri="...", db_name="..."),
    embedder=MyEmbedder(),
)
worker = MongoMemWorker(engine)
worker.start_background()

print("Worker running in background!")
print(f"Is running: {worker.is_running}")

# ... do other work in subsequent cells ...

# When done:
worker.stop()
worker.wait(timeout=5.0)
```

### Multi-Tenant Deployment

```python
engine = MemoryEngine(
    Settings(mongo_uri="...", db_name="tenant_abc_memory"),
    embedder=MyEmbedder(),
)
worker = MongoMemWorker(
    engine,
    tenant_id="tenant_abc",  # For logging/filtering
)
worker.run()
```

## Split Database Architecture

The worker supports separate databases for core memory collections and worker collections.

### Use Cases

| Scenario | Core DB | Worker DB |
|----------|---------|-----------|
| **Single-tenant (default)** | Same | Same |
| **Multi-tenant SaaS** | Per-tenant | Shared |
| **Isolation** | Production data | Worker state |

### Configuration

```python
# Same database (default - backward compatible)
engine = MemoryEngine(
    Settings(mongo_uri="...", db_name="my_app"),
    embedder=MyEmbedder(),
)
worker = MongoMemWorker(engine)

# Split databases
worker = MongoMemWorker(
    engine,
    worker_db_name="worker_shared",  # Task queue, worker state
)
```

### Environment Variables

```bash
# Single database
MONGOMEM_WORKER_DB_NAME=my_app

# Split databases
MONGOMEM_WORKER_DB_NAME=my_app           # Fallback
MONGOMEM_WORKER_CORE_DB_NAME=tenant_memory
MONGOMEM_WORKER_WORKER_DB_NAME=worker_shared
```

### Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Same MongoDB Cluster                     │
│                                                             │
│  ┌─────────────────────────┐  ┌─────────────────────────┐  │
│  │   Core Database          │  │   Worker Database       │  │
│  │   (tenant_123_memory)    │  │   (worker_shared)       │  │
│  │                          │  │                         │  │
│  │  • memory_short_term     │  │  • tasks               │  │
│  │  • memory_snapshot       │  │  • tasks_dlq           │  │
│  │  • memory_episodic       │  │  • worker_state        │  │
│  │  • memory_semantic       │  │  • change_stream_state │  │
│  │  • entities              │  │                         │  │
│  │  • facts                 │  │                         │  │
│  └───────────┬──────────────┘  └────────────────────────┘  │
│              │                                              │
│              │ Polling / Change Streams                    │
│              ▼                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │                   MongoMemWorker                      │  │
│  │  • Watches core_db for new memory                    │  │
│  │  • Stores task queue in worker_db                    │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

### Multi-Tenant SaaS Pattern

```python
def create_tenant_worker(tenant_id: str) -> MongoMemWorker:
    engine = MemoryEngine(
        Settings(
            mongo_uri="mongodb+srv://cluster...",
            db_name=f"tenant_{tenant_id}_memory",
        ),
        embedder=get_embedder_for_tenant(tenant_id),
    )
    return MongoMemWorker(
        engine,
        worker_db_name="worker_shared",
        tenant_id=tenant_id,
    )
```

### Multi-Cluster Support

The connection layer caches MongoDB clients by URI, allowing core and worker databases to be on different clusters:

```python
# Core on cluster A, worker tasks on cluster B
# Note: This requires passing different URIs to engine vs worker settings
engine = MemoryEngine(
    Settings(
        mongo_uri="mongodb+srv://cluster-a.mongodb.net",  # Core cluster
        db_name="tenant_memory",
    ),
    embedder=MyEmbedder(),
)

# Worker can use a different cluster for its task queue
# (Currently uses same URI as engine; different-cluster support
#  requires explicit worker_mongo_uri parameter - not yet exposed)
```

**Connection Caching**: Clients are cached by URI, so multiple engines/workers with the same URI share a connection pool.

## Horizontal Scaling (Multiple Workers)

### Scaling Modes

| Mode | Description | Use Case |
|------|-------------|----------|
| `single` | Direct polling (one worker only) | Development, single-instance |
| `distributed` | Task queue with lease-based claiming | Production, Kubernetes |

### Single Mode (Default)

One worker polls for pending documents. **Do not run multiple workers** in this mode.

```python
worker = MongoMemWorker(
    engine,
    scaling_mode="single",  # Default
)
```

**Change Streams**: In single mode, the worker attempts to use MongoDB change streams for push-based notifications. If change streams are unavailable (e.g., standalone MongoDB), it falls back to polling.

```
┌─────────────────────────────────────────────────────────────────┐
│                    Single Mode                                   │
├─────────────────────────────────────────────────────────────────┤
│  If change streams available (replica set):                      │
│    Change Stream → Notification → Process immediately            │
│                                                                  │
│  If change streams unavailable (standalone):                     │
│    Poll every N seconds → Check for pending docs → Process       │
└─────────────────────────────────────────────────────────────────┘
```

### Distributed Mode (Multiple Workers)

Multiple workers pull from a shared task queue. Tasks are claimed with leases to prevent duplicate processing.

```python
# Worker 1, 2, 3... (same config, run on different pods/processes)
worker = MongoMemWorker(
    engine,
    scaling_mode="distributed",
    concurrency=5,
)
worker.run()
```

### How Distributed Mode Works

```
External Producer (or change stream watcher)
        │
        ▼ enqueue_task()
┌─────────────────────────────────────────────┐
│           Task Queue (MongoDB)              │
│  • Atomic claiming with findAndModify       │
│  • Lease-based ownership (5 min default)    │
│  • Automatic retry on failure               │
│  • Dead letter queue for poison pills       │
└─────────────────────────────────────────────┘
        │ claim_task() (atomic)
        ├─────────────────┬─────────────────┐
        ▼                 ▼                 ▼
   Worker 1          Worker 2          Worker 3
```

### Kubernetes Deployment Example

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: mongomem-worker
spec:
  replicas: 3
  template:
    spec:
      containers:
      - name: worker
        image: my-app:latest
        command: ["mongomem-worker"]
        args:
          - "--embedder=myapp.embedders.VoyageEmbedder"
          - "--scaling-mode=distributed"
        env:
          - name: MONGOMEM_WORKER_MONGO_URI
            valueFrom:
              secretKeyRef:
                name: mongodb-secrets
                key: uri
          - name: MONGOMEM_WORKER_DB_NAME
            value: "my_app_memory"
```

### External Task Producer

In distributed mode, you can have an external process produce tasks:

```python
from mongomem_worker import enqueue_task

enqueue_task(
    task_type="embedding",
    payload={
        "doc_id": "...",
        "org_id": "...",
        "content": "...",
        "collection": "memory_short_term",
    },
    priority=0,       # Lower = higher priority
    max_retries=3,
)
```

### Task Lease and Recovery

- **Lease Duration**: 5 minutes (configurable)
- **Stale Recovery**: Tasks from dead workers are automatically requeued
- **Retry Backoff**: Exponential backoff on failures (30s, 60s, 120s)
- **DLQ**: Failed tasks (after retries exhausted) can be moved to dead letter queue

## Observability

The worker supports pluggable observability via `ObservabilityProtocol` from `mongomem_core.protocols`.

### Built-in Implementations

| Implementation | Description |
|----------------|-------------|
| `LoggingObservability` | Logs to Python logger (default) |
| `NoOpObservability` | Zero overhead (production/testing) |
| `OpenTelemetryObservability` | Enterprise observability |

### Using Custom Observability Backend

```python
from mongomem_worker import MongoMemWorker, ObservabilityProtocol

class MyPrometheusObservability:
    def increment(self, name, value=1.0, tags=None):
        ...
    
    def gauge(self, name, value, tags=None):
        ...
    
    def histogram(self, name, value, tags=None):
        ...
    
    def timing(self, name, value_ms, tags=None):
        ...
    
    def span(self, name, *, kind="internal", attributes=None):
        # Context manager for tracing
        ...
    
    def event(self, name, *, attributes=None, level="info"):
        ...

worker = MongoMemWorker(engine, observability=MyPrometheusObservability())
```

### Metrics Emitted

| Metric | Type | Tags | Description |
|--------|------|------|-------------|
| `tasks_claimed` | counter | task_type | Task claimed by worker |
| `tasks_completed` | counter | task_type | Task completed successfully |
| `task_duration` | timing | task_type | Task execution time (ms) |
| `tasks_failed` | counter | task_type, error_type, error_taxonomy | Task failed |
| `tasks_timeout` | counter | task_type | Task exceeded timeout |
| `tasks_retried` | counter | task_type, attempt | Task queued for retry |
| `queue_depth` | gauge | status | Number of tasks in queue |
| `queue_wait_time` | histogram | task_type | Time task waited in queue (ms) |
| `worker_active` | gauge | worker_id | Worker is running |
| `worker_idle_seconds` | gauge | worker_id | Seconds worker has been idle |

### Example: DataDog

```python
from datadog import statsd

class DataDogObservability:
    def increment(self, name, value=1.0, tags=None):
        dd_tags = [f"{k}:{v}" for k, v in (tags or {}).items()]
        statsd.increment(f"mongomem.{name}", value, tags=dd_tags)
    
    def gauge(self, name, value, tags=None):
        dd_tags = [f"{k}:{v}" for k, v in (tags or {}).items()]
        statsd.gauge(f"mongomem.{name}", value, tags=dd_tags)
    
    def histogram(self, name, value, tags=None):
        dd_tags = [f"{k}:{v}" for k, v in (tags or {}).items()]
        statsd.histogram(f"mongomem.{name}", value, tags=dd_tags)
    
    def timing(self, name, value_ms, tags=None):
        dd_tags = [f"{k}:{v}" for k, v in (tags or {}).items()]
        statsd.timing(f"mongomem.{name}", value_ms, tags=dd_tags)

worker = MongoMemWorker(engine, observability=DataDogObservability())
```

### Example: Prometheus

```python
from prometheus_client import Counter, Gauge, Histogram

class PrometheusObservability:
    def __init__(self):
        self._counters = {}
        self._gauges = {}
        self._histograms = {}
    
    def _get_counter(self, name, labels):
        key = name
        if key not in self._counters:
            self._counters[key] = Counter(
                f"mongomem_{name}_total",
                f"mongomem {name}",
                list(labels) if labels else [],
            )
        return self._counters[key]
    
    def increment(self, name, value=1.0, tags=None):
        counter = self._get_counter(name, (tags or {}).keys())
        if tags:
            counter.labels(**tags).inc(value)
        else:
            counter.inc(value)
    
    # ... similar for gauge, histogram, timing

worker = MongoMemWorker(engine, observability=PrometheusObservability())
```

## Circuit Breaker

The worker uses circuit breakers to protect external services (embedding, LLM) from cascading failures.

### How It Works

```
Normal Operation (CLOSED):
  Request → Service → Success → Request → ...

After 5 failures (OPEN):
  Request → REJECTED immediately (fail fast)
  
After 60 seconds (HALF_OPEN):
  Test request → Success? → CLOSED (recovered)
                 Failure? → OPEN (stay open)
```

### States

| State | Description | Behavior |
|-------|-------------|----------|
| CLOSED | Normal operation | Requests pass through |
| OPEN | Service down | Requests rejected immediately |
| HALF_OPEN | Testing recovery | Limited requests allowed |

### Configuration

Circuit breakers are configured per-service with sensible defaults:

| Service | Failure Threshold | Timeout | Success Threshold |
|---------|------------------|---------|-------------------|
| `embedding_service` | 5 failures | 60s | 2 successes |
| `llm_service` | 5 failures | 60s | 2 successes |

### Using Circuit Breakers

Circuit breakers are automatically integrated into handlers. For custom usage:

```python
from mongomem_worker import (
    get_circuit_breaker,
    CircuitBreakerOpen,
    reset_circuit_breaker,
)

# Get or create a circuit breaker
breaker = get_circuit_breaker("my_service", failure_threshold=3)

# Use in async code
try:
    result = await breaker.call_async(my_async_function, arg1, arg2)
except CircuitBreakerOpen as exc:
    print(f"Service unavailable, retry in {exc.retry_in_seconds}s")

# Use in sync code
try:
    result = breaker.call_sync(my_sync_function, arg1)
except CircuitBreakerOpen:
    # Handle gracefully
    pass

# Manually reset (e.g., after deployment fix)
reset_circuit_breaker("my_service")
```

### Metrics

Circuit breaker state changes emit metrics:

| Metric | Type | Description |
|--------|------|-------------|
| `circuit_breaker_state` | gauge | 0=closed, 1=open, 2=half_open |
| `circuit_breaker_opens` | counter | Times circuit opened |
| `circuit_breaker_rejected` | counter | Calls rejected due to open circuit |

### State Change Callback

Register a callback for state transitions:

```python
def on_state_change(name: str, state: CircuitState):
    print(f"Circuit {name} changed to {state.value}")
    # Send alert, log, etc.

breaker = get_circuit_breaker(
    "embedding_service",
    on_state_change=on_state_change,
)
```

## Recovery Logging

When tasks are requeued from stale workers, recovery information is logged.

### What Gets Logged

When a worker dies (lease expires) and its tasks are recovered:

```python
# Task document after recovery
{
    "_id": ObjectId("..."),
    "task_type": "embedding",
    "status": "queued",  # Back to pending
    "recovery_log": [
        {
            "recovered_at": ISODate("2024-01-15T10:30:00Z"),
            "stale_worker_id": "worker-pod-abc-123",
            "lease_expired_at": ISODate("2024-01-15T10:25:00Z"),
        },
        # Additional recoveries if task keeps failing
    ],
}
```

### Use Cases

1. **Debugging**: Track why tasks are being retried
2. **Monitoring**: Alert on workers frequently dying
3. **Capacity Planning**: Identify overloaded workers

### Query Recovery History

```python
# Find tasks recovered more than once
db.tasks.find({
    "recovery_log.1": {"$exists": True}
})

# Find tasks recovered from a specific worker
db.tasks.find({
    "recovery_log.stale_worker_id": "worker-pod-abc-123"
})
```

## Queue Depth Metrics

In distributed mode, the worker continuously reports queue depth for autoscaling.

### Metrics Emitted

| Metric | Type | Tags | Description |
|--------|------|------|-------------|
| `queue_depth` | gauge | status=queued | Pending tasks waiting |
| `queue_depth` | gauge | status=running | Tasks currently processing |

### Update Interval

Queue depth is updated every 10 seconds (configurable).

### Use for Autoscaling

```yaml
# Kubernetes HPA example
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: mongomem-worker-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: mongomem-worker
  minReplicas: 1
  maxReplicas: 10
  metrics:
    - type: External
      external:
        metric:
          name: mongomem_queue_depth
          selector:
            matchLabels:
              status: queued
        target:
          type: AverageValue
          averageValue: "50"  # Scale up when >50 tasks per worker
```

### Custom Query

```python
# Direct query for queue depth
pending = db.tasks.count_documents({"status": "queued"})
running = db.tasks.count_documents({"status": "running"})

print(f"Queue depth: {pending} pending, {running} running")
```

## Idle Detection

The worker automatically detects when it's idle and uses that time productively.

### How It Works

```
Normal Operation:
  Task arrives → Process → Task arrives → Process → ...

Idle Detection (after 30s of no tasks):
  No tasks → Wait → No tasks → [IDLE] → Run maintenance tasks
                                      → Promote snapshots
                                      → Cleanup expired docs
```

### Idle Tasks (Run Automatically)

When idle, the worker runs:
1. **Snapshot promotion** - Promote STM to snapshots
2. **Embedding backfill** - Embed any documents missing embeddings  
3. **Maintenance** - Cleanup expired documents

### Checking Idle Status

```python
worker = MongoMemWorker(engine)

# Check if worker is idle
if worker.is_idle:
    print(f"Worker idle for {worker.idle_seconds:.0f} seconds")

# Query from MongoDB (for autoscaling)
idle_workers = db.worker_state.find({
    "status": "idle",
    "metadata.idle_seconds": {"$gt": 300}
})
```

### Use Case: Trigger Snapshots on Idle

The worker automatically promotes snapshots during idle time. You can also trigger manually:

```python
from mongomem_worker import enqueue_task

enqueue_task(
    task_type="maintenance",
    payload={
        "maintenance_type": "promote_snapshot",
        "session_id": "session_123",
        "org_id": "org_abc",
        "reason": "manual_trigger",
    },
)
```

## CLI

```bash
# Install adds `mongomem-worker` command
mongomem-worker --embedder myapp.embedders.VoyageEmbedder

# With extractions
mongomem-worker \
    --embedder myapp.embedders.VoyageEmbedder \
    --llm myapp.llms.AnthropicLLM \
    --log-level DEBUG
```

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    MongoMemWorker                           │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐ │
│  │ Embedding   │  │ Learning    │  │ Entity              │ │
│  │ Handler     │  │ Handlers    │  │ Handler             │ │
│  │             │  │ (tax/epi/   │  │                     │ │
│  │ (runs in    │  │  semantic)  │  │ (TKG extraction)    │ │
│  │  executor)  │  │             │  │                     │ │
│  └──────┬──────┘  └──────┬──────┘  └──────────┬──────────┘ │
│         │                │                     │            │
│  ┌──────▼────────────────▼─────────────────────▼──────────┐ │
│  │              Polling / Task Queue                      │ │
│  │  (STM inserts, Snapshot updates, etc.)                │ │
│  └────────────────────────┬───────────────────────────────┘ │
│                           │                                  │
│  ┌────────────────────────▼───────────────────────────────┐ │
│  │              Resume Token Store                         │ │
│  │  (Survives restarts, no missed events)                 │ │
│  └─────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
                   ┌─────────────────┐
                   │  MongoDB        │
                   │  (Tenant DB)    │
                   └─────────────────┘
```

## Handlers

### EmbeddingHandler

Watches for new STM/snapshot documents without embeddings and generates them.

- Triggered by: Documents with `has_embedding != true`
- Uses: `EmbedderProtocol` from `MemoryEngine`
- Stores: `embedding`, `has_embedding`, `embedding_model_id`
- **Non-blocking**: `embed()` runs in executor thread

### Learning Handlers

Specialized handlers for extracting structured knowledge:

#### SemanticHandler
- Extracts: Facts, knowledge, user preferences
- Full consolidation pipeline (ADD/UPDATE/REINFORCE)
- **Requires**: `LLMProtocol` + `EmbedderProtocol`

#### EpisodicHandler
- Extracts: Events, participants, timeline
- **Requires**: `LLMProtocol`

#### TaxonomicHandler
- Extracts: Domain, category, tags
- **Requires**: `LLMProtocol`
- Storage: TKG (pending implementation)

All handlers are **non-blocking**: LLM calls run in executor threads

### EntityHandler

Extracts named entities for the Temporal Knowledge Graph (TKG).

- Entities: People, organizations, locations, concepts
- Relationships: Connections between entities
- **Non-blocking**: LLM calls run in executor thread

### MaintenanceHandler

Background maintenance tasks:

- Snapshot promotion (STM → Snapshot)
- Expired document cleanup
- Archive management

### SnapshotHandler

Snapshot-specific processing:

- Embedding generation for snapshots
- Summary generation (if LLM available)

## Storage

### Resume Tokens

Change stream resume tokens are persisted to survive worker restarts:

```python
# Collection: worker_resume_tokens
{
    "stream_name": "stm_changes",
    "resume_token": {...},
    "updated_at": ISODate("...")
}
```

### Worker State

Health and statistics tracking:

```python
# Collection: worker_state
{
    "worker_id": "hostname-pid",
    "status": "running",
    "last_heartbeat": ISODate("..."),
    "stats": {
        "embedding": {"success": 100, "failed": 2},
        "taxonomic": {"success": 50, "failed": 0}
    }
}
```

## Integration with MongoDB Agentic Platform

The worker runs as a separate service alongside the Orchestrator.

### Architecture Fit

```
┌─────────────────────────────────────────────────────────────┐
│                      ORCHESTRATOR                           │
│  ┌──────────────┐  ┌──────────────┐  ┌─────────────────┐   │
│  │ LangGraph    │  │ Checkpoint   │  │ mongomem_core   │   │
│  │ Runtime      │  │ Store        │  │ (sync memory)   │   │
│  └──────────────┘  └──────────────┘  └─────────────────┘   │
│         │                 │                  │              │
└─────────┼─────────────────┼──────────────────┼──────────────┘
          │                 │                  │
          ▼                 ▼                  ▼
   ┌─────────────────────────────────────────────────────┐
   │                   Tenant MongoDB                     │
   │  (checkpoints, memory_short_term, memory_snapshot)  │
   └──────────────────────────┬──────────────────────────┘
                              │ Polling
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    mongomem_worker (Separate Pod)           │
│  ┌──────────────┐  ┌──────────────┐  ┌─────────────────┐   │
│  │ Embedding    │  │ Extraction   │  │ Maintenance     │   │
│  │ Handler      │  │ Handlers     │  │ Handler         │   │
│  │ (async)      │  │ (async)      │  │ (async)         │   │
│  └──────────────┘  └──────────────┘  └─────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

### Key Design Principles

| Component | Memory Access | Network | Purpose |
|-----------|---------------|---------|---------|
| Orchestrator | `mongomem_core` (sync) | Yes | Build context, write turns |
| Worker | Polling (async) | Yes | Embeddings, extractions |
| AER | None (isolated) | No | Execute user code |
| ToolPod | None (isolated) | No | Execute tools |

### Orchestrator Integration Example

```python
from mongomem_core import MemoryEngine, Settings

class Orchestrator:
    def __init__(self, settings: Settings, embedder):
        self.engine = MemoryEngine(settings, embedder=embedder)
        self.engine.bootstrap()
    
    async def execute_node(self, node_name: str, state: dict, context):
        # 1. Build memory context (sync, low-latency)
        memory_context = self.engine.build_context(
            session_id=context.thread_id,
            org_id=context.tenant_id,
            user_id=context.user_id,
            query_embedding=self.engine.embedder.embed(state.get("query")),
        )
        
        # 2. Inject into state for AER
        state["memory_context"] = memory_context
        
        # 3. Execute node...
        result = await self.spawn_aer(node_name, state)
        
        # 4. Write turn (sync) - worker picks up for embedding
        self.engine.write_turn(
            session_id=context.thread_id,
            org_id=context.tenant_id,
            user_id=context.user_id,
            role="assistant",
            content=result.get("response"),
        )
        
        return result
```

### Worker Deployment

```python
from mongomem_core import MemoryEngine, Settings
from mongomem_worker import MongoMemWorker

# Separate worker process/pod
engine = MemoryEngine(
    Settings(
        mongo_uri=os.environ["TENANT_MONGODB_URI"],
        db_name=os.environ["TENANT_DB_NAME"],
    ),
    embedder=TenantEmbedder(),
    llm=TenantLLM(),
)

worker = MongoMemWorker(
    engine,
    tenant_id=os.environ.get("TENANT_ID"),
)
worker.run()
```

### Event Flow

1. **Orchestrator** writes STM via `engine.write_turn()`
2. **Worker** polls for documents without embeddings
3. **Worker** generates embedding (in executor thread), updates document
4. **Worker** (if LLM configured) runs extractions
5. **Next request**: Orchestrator finds embedded content for context

## Example Implementations

### Voyage AI Embedder (Recommended)

```python
import voyageai
from mongomem_core import EmbedderProtocol

class VoyageEmbedder(EmbedderProtocol):
    MODEL_DIMENSIONS = {
        "voyage-3": 1024,
        "voyage-3-lite": 512,
        "voyage-code-3": 1024,
    }
    
    def __init__(self, model: str = "voyage-3"):
        self.client = voyageai.Client()
        self._model = model
        self._dimension = self.MODEL_DIMENSIONS.get(model, 1024)
    
    def embed(self, text: str) -> list[float]:
        result = self.client.embed([text], model=self._model)
        return result.embeddings[0]
    
    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        result = self.client.embed(texts, model=self._model)
        return result.embeddings
    
    @property
    def dimension(self) -> int:
        return self._dimension
    
    @property
    def model_id(self) -> str:
        return self._model
```

### Anthropic LLM

```python
import json
import anthropic
from mongomem_core import LLMProtocol

class AnthropicLLM(LLMProtocol):
    def __init__(self, model: str = "claude-3-5-haiku-latest"):
        self.client = anthropic.Anthropic()
        self.model = model
    
    def complete(self, prompt: str, **kwargs) -> str:
        resp = self.client.messages.create(
            model=self.model,
            max_tokens=1024,
            messages=[{"role": "user", "content": prompt}],
            **kwargs,
        )
        return resp.content[0].text
    
    def complete_json(self, prompt: str, schema: dict, **kwargs) -> dict:
        json_prompt = f"{prompt}\n\nRespond with valid JSON only."
        resp = self.client.messages.create(
            model=self.model,
            max_tokens=1024,
            messages=[{"role": "user", "content": json_prompt}],
            **kwargs,
        )
        return json.loads(resp.content[0].text)
```

## Graceful Shutdown

The worker handles SIGINT and SIGTERM for graceful shutdown:

```python
engine = MemoryEngine(...)
worker = MongoMemWorker(engine)

# Ctrl+C or kill signal triggers graceful shutdown
worker.run()

# Or manually:
worker.stop()
```

## Monitoring

Check worker health via the state collection:

```python
from mongomem_worker.storage import WorkerStateStore
from pymongo import MongoClient

db = MongoClient("mongodb://localhost:27017")["my_app"]
state_store = WorkerStateStore(db)

workers = state_store.get_all_workers(active_only=True)
for w in workers:
    print(f"{w['worker_id']}: {w['status']} - last heartbeat: {w['last_heartbeat']}")
```
