"""CRUD and invariants for episodic memory.

Episodic memory stores extracted summaries and learnings from conversation
snapshots. Each document represents a distinct episode or event with its
context, participants, and semantic content.

All functions operate synchronously against MongoDB and expect the caller to
provide necessary context (org_id, user_id, etc.).
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional, Sequence, Tuple

from bson import ObjectId
from mongomem_core.common.utils import (
    format_document_identifier,
    handle_db_error,
    handle_duplicate_key_error,
    to_object_id,
    utcnow,
)
from mongomem_core.exceptions import (
    DatabaseOperationError,
    DocumentNotFoundError,
)
from mongomem_core.memory.base import (
    BaseDocumentBuilder,
    BaseQueryBuilder,
    BaseUpdateFieldBuilder,
    doc_to_output,
    execute_vector_search,
    handle_empty_sequence,
)
from mongomem_core.models.filters import MetadataFilter
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.episodic import (
    EpisodicDB,
    EpisodicIn,
    EpisodicOut,
    EpisodicUpdate,
)
from mongomem_core.storage import get_collection
from mongomem_core.storage.collections import EpisodicMemoryCollection
from mongomem_core.storage.search_indexes import EPISODIC_VECTOR_INDEX
from pymongo import ReturnDocument
from pymongo.database import Database
from pymongo.errors import DuplicateKeyError
from pymongo.results import DeleteResult, InsertOneResult, UpdateResult

logger = logging.getLogger(__name__)


_EPISODIC_COL = EpisodicMemoryCollection()


def _build_episodic_query_filter(
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    session_id: Optional[str] = None,
    snapshot_ref_id: Optional[str] = None,
    project_id: Optional[str] = None,
    user_id: Optional[str] = None,
    visibility: Optional[str] = None,
    include_deleted: bool = False,
) -> Tuple[Dict[str, Any], str]:
    """
    Build a MongoDB query filter and identifier string for episodic lookups.

    Supports lookup by ID or by composite key (session_id, snapshot_ref_id).

    Args:
        org_id: Organization ID
        id: Document ID (string or ObjectId) - mutually exclusive with session_id/snapshot_ref_id
        session_id: Session ID - must be provided with snapshot_ref_id
        snapshot_ref_id: Snapshot reference ID - must be provided with session_id
        project_id: Optional project ID to bind lookups to a project
        include_deleted: If True, include soft-deleted documents

    Returns:
        Tuple of (query_filter_dict, identifier_string)

    Raises:
        ValueError: If neither id nor (session_id, snapshot_ref_id) is provided, or both are provided.
    """
    if id is not None:
        if session_id is not None or snapshot_ref_id is not None:
            raise ValueError("Cannot provide both 'id' and ('session_id', 'snapshot_ref_id')")
        q_filter, identifier = BaseQueryBuilder.build_id_filter(
            org_id, id, include_deleted=include_deleted
        )
    elif session_id is not None and snapshot_ref_id is not None:
        q_filter = BaseQueryBuilder.build_base_filter(
            org_id,
            include_deleted=include_deleted,
            session_id=session_id,
            snapshot_ref_id=snapshot_ref_id,
        )
        identifier = format_document_identifier(
            session_id=session_id, snapshot_ref_id=snapshot_ref_id
        )
    else:
        raise ValueError("Must provide either 'id' or both 'session_id' and 'snapshot_ref_id'")

    if project_id is not None:
        q_filter["project_id"] = project_id
    if user_id is not None:
        q_filter["user_id"] = user_id
    if visibility is not None:
        q_filter["visibility"] = visibility

    return q_filter, identifier


def _build_episodic_doc(
    episodic_in: EpisodicIn,
    org_id: str,
    user_id: str,
    timestamp: datetime,
    *,
    embedding: Optional[List[float]] = None,
    embedding_model_id: Optional[str] = None,
    extraction_id: Optional[str] = None,
) -> EpisodicDB:
    """Build an EpisodicDB document from input.

    Args:
        episodic_in: Input model with episodic memory data
        org_id: Organization ID
        user_id: User ID of the creator
        timestamp: Timestamp for the document
        embedding: Pre-computed embedding vector (if any)
        embedding_model_id: Model used to generate embedding
        extraction_id: Optional extraction ID for idempotency

    Returns:
        An EpisodicDB document (not yet persisted)
    """
    return BaseDocumentBuilder.build_memory_document(
        episodic_in,
        EpisodicDB,
        org_id,
        user_id,
        timestamp,
        embedding=embedding,
        embedding_model_id=embedding_model_id,
        extraction_id=extraction_id,
        embedding_config={
            "model_id_field": "summary_embedding_model_id",
            "log_context": f"title={episodic_in.title}",
        },
    )


def create_episodic(
    db: Database,
    episodic_in: EpisodicIn,
    org_id: str,
    user_id: str,
    *,
    embedding: Optional[List[float]] = None,
    embedding_model_id: Optional[str] = None,
    extraction_id: Optional[str] = None,
) -> EpisodicDB:
    """
    Create an episodic memory document.

    Args:
        db: MongoDB database instance
        episodic_in: Input model with episodic memory data
        org_id: Organization ID
        user_id: User ID of the creator
        embedding: Pre-computed embedding vector (if any)
        embedding_model_id: Model used to generate embedding
        extraction_id: Optional extraction ID for idempotency (SHA-256 hash)

    Returns:
        The created EpisodicDB document

    Raises:
        DuplicateDocumentError: If (org_id, session_id, snapshot_ref_id) already exists (unique constraint).
        DatabaseOperationError: If the insert operation fails.

    Example:
        >>> from mongomem_core.storage import get_database
        >>> from mongomem_core.models.memory.episodic import EpisodicIn
        >>> db = get_database()
        >>> episodic = EpisodicIn(
        ...     session_id="session_1",
        ...     title="Meeting Summary",
        ...     snapshot_ref_id="snap_1",
        ...     summary_text="Discussed project timeline"
        ... )
        >>> doc = create_episodic(db, episodic, org_id="org_1", user_id="user_1")
    """
    logger.debug(
        "Creating episodic memory document: title=%s session=%s org=%s user=%s",
        episodic_in.title,
        episodic_in.session_id,
        org_id,
        user_id,
    )

    now = utcnow()
    doc = _build_episodic_doc(
        episodic_in,
        org_id,
        user_id,
        now,
        embedding=embedding,
        embedding_model_id=embedding_model_id,
        extraction_id=extraction_id,
    )

    col = get_collection(_EPISODIC_COL, db)
    try:
        with handle_db_error(
            operation="insert_one",
            collection=_EPISODIC_COL.name,
            log_message="Failed to create episodic document: title=%s session=%s org=%s",
            log_args_tuple=(episodic_in.title, episodic_in.session_id, org_id),
        ):
            result: InsertOneResult = col.insert_one(doc.model_dump(by_alias=True))
            doc.id = result.inserted_id

            logger.debug(
                "Created episodic document: id=%s title=%s session=%s org=%s",
                result.inserted_id,
                episodic_in.title,
                episodic_in.session_id,
                org_id,
            )
            return doc
    except DuplicateKeyError as exc:
        handle_duplicate_key_error(
            exc,
            collection_name=_EPISODIC_COL.name,
            log_message="Duplicate episodic document detected: session=%s snapshot=%s org=%s",
            log_args=(episodic_in.session_id, episodic_in.snapshot_ref_id, org_id),
            details={
                "session_id": episodic_in.session_id,
                "snapshot_ref_id": episodic_in.snapshot_ref_id,
                "org_id": org_id,
            },
        )


def upsert_episodic(
    db: Database,
    episodic_in: EpisodicIn,
    org_id: str,
    user_id: str,
    *,
    embedding: Optional[List[float]] = None,
    embedding_model_id: Optional[str] = None,
    extraction_id: Optional[str] = None,
) -> EpisodicOut:
    """
    Create or update an episodic memory document by (session_id, snapshot_ref_id).

    If a document with the same (org_id, session_id, snapshot_ref_id) exists, it will be updated.
    Otherwise, a new document will be created.

    Args:
        db: MongoDB database instance
        episodic_in: Input model with episodic memory data
        org_id: Organization ID
        user_id: User ID of the creator
        embedding: Pre-computed embedding vector (if any)
        embedding_model_id: Model used to generate embedding
        extraction_id: Optional extraction ID for idempotency (SHA-256 hash)

    Returns:
        The created or updated EpisodicOut document

    Raises:
        DatabaseOperationError: If the upsert operation fails.

    Example:
        >>> from mongomem_core.storage import get_database
        >>> from mongomem_core.models.memory.episodic import EpisodicIn
        >>> db = get_database()
        >>> episodic = EpisodicIn(
        ...     session_id="session_1",
        ...     title="Meeting Summary",
        ...     snapshot_ref_id="snap_1",
        ...     summary_text="Discussed project timeline"
        ... )
        >>> doc = upsert_episodic(db, episodic, org_id="org_1", user_id="user_1")
    """
    logger.debug(
        "Upserting episodic memory document: title=%s session=%s snapshot=%s org=%s user=%s",
        episodic_in.title,
        episodic_in.session_id,
        episodic_in.snapshot_ref_id,
        org_id,
        user_id,
    )

    col = get_collection(_EPISODIC_COL, db)
    now = utcnow()

    doc = _build_episodic_doc(
        episodic_in,
        org_id,
        user_id,
        now,
        embedding=embedding,
        embedding_model_id=embedding_model_id,
        extraction_id=extraction_id,
    )

    update_doc = doc.model_dump(by_alias=True, exclude={"id", "_id", "timestamp"})

    set_on_insert = {
        "timestamp": now,
    }

    q_filter = {
        "session_id": episodic_in.session_id,
        "snapshot_ref_id": episodic_in.snapshot_ref_id,
        "org_id": org_id,
        "deleted": {"$ne": True},
    }

    with handle_db_error(
        operation="find_one_and_update",
        collection=_EPISODIC_COL.name,
        log_message="Failed to upsert episodic document: session=%s snapshot=%s org=%s",
        log_args_tuple=(episodic_in.session_id, episodic_in.snapshot_ref_id, org_id),
    ):
        result = col.find_one_and_update(
            q_filter,
            {
                "$set": update_doc,
                "$setOnInsert": set_on_insert,
            },
            upsert=True,
            return_document=ReturnDocument.AFTER,
        )

        if not result:
            logger.error(
                "Upsert returned None despite upsert=True: session=%s snapshot=%s org=%s",
                episodic_in.session_id,
                episodic_in.snapshot_ref_id,
                org_id,
                exc_info=True,
            )
            raise DatabaseOperationError(
                "Upsert operation failed unexpectedly",
                operation="find_one_and_update",
                collection=_EPISODIC_COL.name,
                details={
                    "org_id": org_id,
                    "session_id": episodic_in.session_id,
                    "snapshot_ref_id": episodic_in.snapshot_ref_id,
                },
            )

        result["_id"] = str(result["_id"])
        logger.debug(
            "Upserted episodic document: id=%s session=%s snapshot=%s org=%s",
            result["_id"],
            episodic_in.session_id,
            episodic_in.snapshot_ref_id,
            org_id,
        )
        return EpisodicOut.model_validate(result)


def get_episodic(
    db: Database,
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    session_id: Optional[str] = None,
    snapshot_ref_id: Optional[str] = None,
    project_id: Optional[str] = None,
    user_id: Optional[str] = None,
    visibility: Optional[str] = None,
    include_deleted: bool = False,
) -> Optional[EpisodicOut]:
    """
    Fetch a single episodic memory document by ID or (session_id, snapshot_ref_id).

    Either `id` or both `session_id` and `snapshot_ref_id` must be provided.

    Args:
        db: MongoDB database instance
        org_id: Organization ID (for access control)
        id: Document ID (string or ObjectId) - mutually exclusive with session_id/snapshot_ref_id
        session_id: Session ID - must be provided with snapshot_ref_id
        snapshot_ref_id: Snapshot reference ID - must be provided with session_id
        project_id: Optional project ID to bind lookups to a project
        include_deleted: If True, include soft-deleted documents

    Returns:
        EpisodicOut if found, None otherwise.

    Raises:
        ValueError: If neither id nor (session_id, snapshot_ref_id) is provided, or invalid combination.
        ValidationError: If id is not a valid ObjectId format.
        DatabaseOperationError: If the query fails.

    Example:
        >>> # Get by ID
        >>> doc = get_episodic(db, org_id="org_1", id="507f1f77bcf86cd799439011")
        >>> # Get by session and snapshot
        >>> doc = get_episodic(db, org_id="org_1", session_id="session_1", snapshot_ref_id="snap_1")
    """
    q_filter, identifier = _build_episodic_query_filter(
        org_id,
        id=id,
        session_id=session_id,
        snapshot_ref_id=snapshot_ref_id,
        project_id=project_id,
        user_id=user_id,
        visibility=visibility,
        include_deleted=include_deleted,
    )

    col = get_collection(_EPISODIC_COL, db)
    with handle_db_error(
        operation="find_one",
        collection=_EPISODIC_COL.name,
        log_message="Failed to retrieve episodic document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        doc = col.find_one(q_filter)
        if not doc:
            logger.debug("Episodic document not found: %s org=%s", identifier, org_id)
            return None

        doc["_id"] = str(doc["_id"])
        logger.debug("Retrieved episodic document: %s", identifier)
        return EpisodicOut.model_validate(doc)


def list_episodic(
    db: Database,
    org_id: str,
    *,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    tag: Optional[str] = None,
    from_timestamp: Optional[datetime] = None,
    before: Optional[datetime] = None,
    include_deleted: bool = False,
    limit: Optional[int] = None,
    sort_by: str = "timestamp",
    sort_descending: bool = False,
) -> List[EpisodicOut]:
    """
    List episodic memory documents for an organization with optional filters and pagination.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        user_id: Optional filter by user ID
        session_id: Optional filter by session ID
        visibility: Optional filter by visibility scope
        project_id: Optional filter by group ID (for shared visibility)
        tag: Optional filter by tag (exact match)
        from_timestamp: Optional filter - fetch documents from this timestamp onwards
        before: Optional cursor - fetch documents before this timestamp (for pagination)
        include_deleted: If True, include soft-deleted documents
        limit: Optional limit on number of results
        sort_by: Field to sort by (default: "timestamp")
        sort_descending: If True, sort descending (newest first)

    Returns:
        List of EpisodicOut documents

    Raises:
        DatabaseOperationError: If the query fails.

    Example:
        >>> # Get all documents for org
        >>> docs = list_episodic(db, org_id="org_1")
        >>> # Get latest 10 documents with pagination
        >>> docs = list_episodic(db, org_id="org_1", limit=10, before=some_timestamp)
        >>> # Filter by session and visibility
        >>> docs = list_episodic(db, org_id="org_1", session_id="session_1", visibility=ChunkVisibility.PRIVATE)
    """
    col = get_collection(_EPISODIC_COL, db)

    q_filter = BaseQueryBuilder.build_list_filter(
        org_id,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        from_timestamp=from_timestamp,
        before=before,
        include_deleted=include_deleted,
        timestamp_field="timestamp",
    )

    if session_id:
        q_filter["session_id"] = session_id
    if tag:
        q_filter["tags"] = tag

    sort_direction = -1 if sort_descending else 1

    with handle_db_error(
        operation="find",
        collection=_EPISODIC_COL.name,
        log_message="Failed to retrieve episodic documents for org=%s",
        log_args_tuple=(org_id,),
    ):
        cursor = col.find(q_filter).sort(sort_by, sort_direction)
        if limit and limit > 0:
            cursor = cursor.limit(limit)
        results = [doc_to_output(d, EpisodicOut) for d in cursor]
        logger.debug(
            "Retrieved %d episodic documents for org=%s",
            len(results),
            org_id,
        )
        return results


def _build_update_fields(update: EpisodicUpdate) -> Dict[str, Any]:
    """Build MongoDB update fields from EpisodicUpdate model."""
    custom_fields: Dict[str, Any] = {}
    if update.summary_embedding_model_id is not None:
        custom_fields["summary_embedding_model_id"] = update.summary_embedding_model_id
    if update.summary_embedding_dimension is not None:
        custom_fields["summary_embedding_dimension"] = update.summary_embedding_dimension

    return BaseUpdateFieldBuilder.build_update_fields(
        update,
        field_mappings={
            "title": "title",
            "content": "content",
            "summary_text": "summary_text",
            "summary_type": "summary_type",
            "source_agent": "source_agent",
            "participants": "participants",
            "tags": "tags",
            "metadata": "metadata",
        },
        custom_fields=custom_fields if custom_fields else None,
    )


def update_episodic(
    db: Database,
    org_id: str,
    update: EpisodicUpdate,
    *,
    id: Optional[str | ObjectId] = None,
    session_id: Optional[str] = None,
    snapshot_ref_id: Optional[str] = None,
) -> EpisodicOut:
    """
    Update an episodic memory document by ID or (session_id, snapshot_ref_id).

    Either `id` or both `session_id` and `snapshot_ref_id` must be provided, but not both.

    Args:
        db: MongoDB database instance
        org_id: Organization ID (for access control)
        update: Update model with fields to modify
        id: Document ID (string or ObjectId) - mutually exclusive with session_id/snapshot_ref_id
        session_id: Session ID - must be provided with snapshot_ref_id
        snapshot_ref_id: Snapshot reference ID - must be provided with session_id

    Returns:
        Updated EpisodicOut document

    Raises:
        ValueError: If neither id nor (session_id, snapshot_ref_id) is provided, or both are provided.
        ValidationError: If id is not a valid ObjectId format.
        DocumentNotFoundError: If the document doesn't exist.
        DatabaseOperationError: If the update operation fails.

    Example:
        >>> # Update by ID
        >>> update = EpisodicUpdate(title="Updated Title")
        >>> doc = update_episodic(db, org_id="org_1", update=update, id="507f1f77bcf86cd799439011")
        >>> # Update by session and snapshot
        >>> doc = update_episodic(db, org_id="org_1", update=update, session_id="session_1", snapshot_ref_id="snap_1")
    """
    update_fields = _build_update_fields(update)

    if not update_fields:
        doc = get_episodic(
            db, org_id, id=id, session_id=session_id, snapshot_ref_id=snapshot_ref_id
        )
        if not doc:
            _, identifier = _build_episodic_query_filter(
                org_id,
                id=id,
                session_id=session_id,
                snapshot_ref_id=snapshot_ref_id,
                include_deleted=True,
            )
            raise DocumentNotFoundError(
                "Episodic document not found",
                collection=_EPISODIC_COL.name,
                document_id=str(id) if id else None,
                details={"org_id": org_id, "identifier": identifier},
            )
        return doc

    q_filter, identifier = _build_episodic_query_filter(
        org_id, id=id, session_id=session_id, snapshot_ref_id=snapshot_ref_id, include_deleted=False
    )

    col = get_collection(_EPISODIC_COL, db)
    with handle_db_error(
        operation="find_one_and_update",
        collection=_EPISODIC_COL.name,
        log_message="Failed to update episodic document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result_doc = col.find_one_and_update(
            q_filter,
            {"$set": update_fields},
            return_document=ReturnDocument.AFTER,
        )

        if not result_doc:
            raise DocumentNotFoundError(
                "Episodic document not found or is deleted",
                collection=_EPISODIC_COL.name,
                document_id=str(id) if id else None,
                details={"org_id": org_id, "identifier": identifier},
            )

        logger.debug("Updated episodic document: %s org=%s", identifier, org_id)
        return EpisodicOut.model_validate({**result_doc, "_id": str(result_doc["_id"])})


def update_episodic_embedding(
    db: Database,
    org_id: str,
    embedding: List[float],
    *,
    id: Optional[str | ObjectId] = None,
    session_id: Optional[str] = None,
    snapshot_ref_id: Optional[str] = None,
    embedding_model_id: Optional[str] = None,
) -> UpdateResult:
    """
    Update the embedding on an existing episodic memory document.

    Supports lookup by ID or by composite key (session_id, snapshot_ref_id) for consistency
    with other update operations.

    Args:
        db: MongoDB database instance
        org_id: Organization ID
        embedding: The embedding vector
        id: Document ID (string or ObjectId) - mutually exclusive with session_id/snapshot_ref_id
        session_id: Session ID - must be provided with snapshot_ref_id
        snapshot_ref_id: Snapshot reference ID - must be provided with session_id
        embedding_model_id: Optional model identifier

    Returns:
        UpdateResult from MongoDB

    Raises:
        ValueError: If neither id nor (session_id, snapshot_ref_id) is provided, or both are provided.
        ValidationError: If id is not a valid ObjectId format.
        DatabaseOperationError: If the update operation fails.

    Example:
        >>> # Update embedding by ID
        >>> result = update_episodic_embedding(db, org_id="org_1", embedding=[0.1, 0.2], id="507f1f77bcf86cd799439011")
        >>> # Update embedding by session and snapshot
        >>> result = update_episodic_embedding(db, org_id="org_1", embedding=[0.1, 0.2], session_id="session_1", snapshot_ref_id="snap_1")
    """
    q_filter, identifier = _build_episodic_query_filter(
        org_id, id=id, session_id=session_id, snapshot_ref_id=snapshot_ref_id, include_deleted=False
    )

    update_fields: Dict[str, Any] = {
        "embedding": embedding,
        "has_embedding": True,
    }
    if embedding_model_id:
        update_fields["summary_embedding_model_id"] = embedding_model_id

    col = get_collection(_EPISODIC_COL, db)
    with handle_db_error(
        operation="update_one",
        collection=_EPISODIC_COL.name,
        log_message="Failed to update embedding for episodic document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result = col.update_one(q_filter, {"$set": update_fields})
        if result.modified_count > 0:
            logger.debug(
                "Updated embedding for episodic document: %s model=%s",
                identifier,
                embedding_model_id,
            )
        else:
            logger.warning(
                "No episodic document modified for embedding update: %s org=%s",
                identifier,
                org_id,
            )
        return result


def soft_delete_episodic(
    db: Database,
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    session_id: Optional[str] = None,
    snapshot_ref_id: Optional[str] = None,
) -> UpdateResult:
    """
    Soft delete an episodic memory document by ID or (session_id, snapshot_ref_id).

    Sets the deleted flag and deleted_at timestamp without removing the document.
    Either `id` or both `session_id` and `snapshot_ref_id` must be provided, but not both.

    Args:
        db: MongoDB database instance
        org_id: Organization ID (for access control)
        id: Document ID (string or ObjectId) - mutually exclusive with session_id/snapshot_ref_id
        session_id: Session ID - must be provided with snapshot_ref_id
        snapshot_ref_id: Snapshot reference ID - must be provided with session_id

    Returns:
        UpdateResult from MongoDB

    Raises:
        ValueError: If neither id nor (session_id, snapshot_ref_id) is provided, or both are provided.
        ValidationError: If id is not a valid ObjectId format.
        DatabaseOperationError: If the update operation fails.

    Example:
        >>> # Soft delete by ID
        >>> result = soft_delete_episodic(db, org_id="org_1", id="507f1f77bcf86cd799439011")
        >>> # Soft delete by session and snapshot
        >>> result = soft_delete_episodic(db, org_id="org_1", session_id="session_1", snapshot_ref_id="snap_1")
    """
    q_filter, identifier = _build_episodic_query_filter(
        org_id,
        id=id,
        session_id=session_id,
        snapshot_ref_id=snapshot_ref_id,
        include_deleted=True,
    )
    q_filter.pop("deleted", None)

    col = get_collection(_EPISODIC_COL, db)
    now = utcnow()
    with handle_db_error(
        operation="update_one",
        collection=_EPISODIC_COL.name,
        log_message="Failed to soft delete episodic document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result = col.update_one(
            q_filter,
            {"$set": {"deleted": True, "deleted_at": now}},
        )
        if result.modified_count > 0:
            logger.debug("Soft deleted episodic document: %s org=%s", identifier, org_id)
        else:
            logger.warning(
                "No episodic document modified for soft delete: %s org=%s",
                identifier,
                org_id,
            )
        return result


def delete_episodic(
    db: Database,
    org_id: str,
    *,
    id: Optional[str | ObjectId] = None,
    session_id: Optional[str] = None,
    snapshot_ref_id: Optional[str] = None,
) -> DeleteResult:
    """
    Hard delete an episodic memory document by ID or (session_id, snapshot_ref_id).

    Permanently removes the document from the database.
    Either `id` or both `session_id` and `snapshot_ref_id` must be provided, but not both.

    Args:
        db: MongoDB database instance
        org_id: Organization ID (for access control)
        id: Document ID (string or ObjectId) - mutually exclusive with session_id/snapshot_ref_id
        session_id: Session ID - must be provided with snapshot_ref_id
        snapshot_ref_id: Snapshot reference ID - must be provided with session_id

    Returns:
        DeleteResult from MongoDB

    Raises:
        ValueError: If neither id nor (session_id, snapshot_ref_id) is provided, or both are provided.
        ValidationError: If id is not a valid ObjectId format.
        DatabaseOperationError: If the delete operation fails.

    Example:
        >>> # Delete by ID
        >>> result = delete_episodic(db, org_id="org_1", id="507f1f77bcf86cd799439011")
        >>> # Delete by session and snapshot
        >>> result = delete_episodic(db, org_id="org_1", session_id="session_1", snapshot_ref_id="snap_1")
    """
    # For hard delete, we don't filter by deleted status - we delete regardless
    q_filter, identifier = _build_episodic_query_filter(
        org_id,
        id=id,
        session_id=session_id,
        snapshot_ref_id=snapshot_ref_id,
        include_deleted=True,
    )
    q_filter.pop("deleted", None)

    col = get_collection(_EPISODIC_COL, db)
    with handle_db_error(
        operation="delete_one",
        collection=_EPISODIC_COL.name,
        log_message="Failed to delete episodic document: %s org=%s",
        log_args_tuple=(identifier, org_id),
    ):
        result = col.delete_one(q_filter)
        logger.debug(
            "Deleted episodic document: %s org=%s (deleted_count=%d)",
            identifier,
            org_id,
            result.deleted_count,
        )
        return result


def delete_episodic_by_ids(
    db: Database,
    episodic_ids: Sequence[str | ObjectId],
    org_id: str,
) -> DeleteResult:
    """
    Hard delete multiple episodic memory documents by ID.

    Args:
        db: MongoDB database instance
        episodic_ids: List of document IDs to delete
        org_id: Organization ID (for access control)

    Returns:
        DeleteResult from MongoDB. If an empty sequence is provided, returns a
        result with deleted_count=0 (idempotent operation - no database call is made).

    Raises:
        ValidationError: If any episodic_id is not a valid ObjectId format.
        DatabaseOperationError: If the delete operation fails.

    Note:
        Empty sequences are handled idempotently: the function returns immediately
        with a DeleteResult indicating 0 deletions, matching MongoDB's behavior
        for delete_many operations with empty $in arrays.
    """
    early_return = handle_empty_sequence(episodic_ids, "delete_episodic_by_ids", DeleteResult)
    if early_return is not None:
        return early_return  # type: ignore[return-value]

    col = get_collection(_EPISODIC_COL, db)
    oids = [to_object_id(eid) for eid in episodic_ids]

    with handle_db_error(
        operation="delete_many",
        collection=_EPISODIC_COL.name,
        log_message="Failed to delete episodic documents: count=%d org=%s",
        log_args_tuple=(len(episodic_ids), org_id),
    ):
        result = col.delete_many({"_id": {"$in": oids}, "org_id": org_id})
        logger.info(
            "Deleted %d episodic documents (requested=%d, org=%s)",
            result.deleted_count,
            len(episodic_ids),
            org_id,
        )
        return result


def vector_search_episodic(
    db: Database,
    query_embedding: List[float],
    org_id: str,
    *,
    user_id: Optional[str] = None,
    visibility: Optional[ChunkVisibility] = None,
    project_id: Optional[str] = None,
    session_id: Optional[str] = None,
    top_k: int = 50,
    similarity_threshold: float = 0.0,
    metadata_filter: Optional[MetadataFilter] = None,
) -> List[EpisodicOut]:
    """
    Perform vector search on episodic memory using MongoDB $vectorSearch.

    Uses the index defined by ``EPISODIC_VECTOR_INDEX`` for efficient similarity search.
    Includes retry logic for when the vector index is not ready yet.

    Args:
        db: MongoDB database instance
        query_embedding: Query embedding vector for similarity search
        org_id: Organization ID (required)
        user_id: Optional filter by user ID
        visibility: Optional filter by visibility scope
        project_id: Optional filter by group ID (for shared visibility)
        session_id: Optional filter by session ID
        top_k: Maximum number of results to return (default: 50)
        similarity_threshold: Minimum similarity score threshold (default: 0.0)
        metadata_filter: Optional user-provided metadata filter for field-level filtering.
            Applied after RBAC filters. See MetadataFilter for usage.

    Returns:
        List of EpisodicOut documents with similarity scores, sorted by score (descending)

    Raises:
        DatabaseOperationError: If the vector search operation fails after retries

    Example:
        >>> from mongomem_core.storage import get_database
        >>> from mongomem_core.models.filters import MetadataFilter
        >>> db = get_database()
        >>> query_emb = [0.1, 0.2, ...]  # 1536-dimensional vector
        >>> results = vector_search_episodic(
        ...     db, query_emb, org_id="org_1",
        ...     top_k=10, similarity_threshold=0.3
        ... )
        >>>
        >>> # With metadata filter for tags
        >>> results = vector_search_episodic(
        ...     db, query_emb, org_id="org_1",
        ...     metadata_filter=MetadataFilter(raw={"tags": {"$in": ["meeting", "project"]}})
        ... )
    """
    col = get_collection(_EPISODIC_COL, db)

    rbac_filter = BaseQueryBuilder.build_base_filter(
        org_id,
        user_id=user_id,
        visibility=visibility,
        project_id=project_id,
        session_id=session_id,
    )

    results = execute_vector_search(
        col,
        index_name=EPISODIC_VECTOR_INDEX.name,
        query_embedding=query_embedding,
        rbac_filter=rbac_filter,
        collection_name=_EPISODIC_COL.name,
        org_id=org_id,
        top_k=top_k,
        similarity_threshold=similarity_threshold,
        metadata_filter=metadata_filter,
    )
    parsed = [doc_to_output(d, EpisodicOut) for d in results if d]
    logger.debug(
        "Vector search returned %d episodic results for org=%s",
        len(parsed),
        org_id,
    )
    return parsed
