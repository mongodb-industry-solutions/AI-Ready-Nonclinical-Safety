"""Ranking and scoring logic for retrieval candidates."""

from __future__ import annotations

import logging
import math
from datetime import datetime, timezone
from typing import Dict, List

from mongomem_core.models.retrieval import ContextConfig, MemoryChunk

logger = logging.getLogger(__name__)


class MemoryRanker:
    """
    Multi-factor ranking system for memory chunks.

    Combines cosine similarity, recency decay, and optional importance scoring
    to produce a final ranking score for memory chunks.
    """

    def __init__(
        self,
        similarity_weight: float = 0.6,
        recency_weight: float = 0.3,
        importance_weight: float = 0.1,
        recency_decay_rate: float = 0.1,
    ) -> None:
        """
        Initialize MemoryRanker with scoring weights and decay rate.

        Args:
            similarity_weight: Weight for cosine similarity score (default: 0.6)
            recency_weight: Weight for recency decay score (default: 0.3)
            importance_weight: Weight for importance score (default: 0.1)
            recency_decay_rate: Exponential decay rate for recency (default: 0.1)
                Must be > 0.0 and < 100.0

        Raises:
            ValueError: If recency_decay_rate is out of valid range
        """
        if not (0.0 < recency_decay_rate < 100.0):
            raise ValueError(
                f"recency_decay_rate must be between 0.0 and 100.0, got {recency_decay_rate}"
            )
        self.similarity_weight = similarity_weight
        self.recency_weight = recency_weight
        self.importance_weight = importance_weight
        self.recency_decay_rate = recency_decay_rate

    def rank_memories(
        self, memories: List[MemoryChunk], config: ContextConfig
    ) -> List[MemoryChunk]:
        """
        Rank memories by multi-factor scoring and return sorted list.

        Calculates final scores using weighted combination of:
        - Cosine similarity (already calculated in retrieval step, stored in
          memory.similarity_score)
        - Recency decay (exponential decay based on age)
        - Importance (from metadata if available)

        Args:
            memories: List of MemoryChunk objects to rank (should already have
                similarity_score populated from retrieval step)
            config: ContextConfig with ranking weights (overrides defaults if provided)

        Returns:
            List of MemoryChunk objects sorted by final_score (descending),
            with ranking scores stored in metadata
        """
        if not memories:
            return []

        weights = self._get_weights(config)
        current_time = datetime.now(timezone.utc)

        ranked_memories = []
        for memory in memories:
            similarity_score = self._get_similarity_score(memory)
            recency_score = self._calculate_recency_score(memory, current_time)
            importance_score = self._get_importance_score(memory)

            final_score = (
                weights["similarity"] * similarity_score
                + weights["recency"] * recency_score
                + weights["importance"] * importance_score
            )

            if memory.metadata is None:
                memory.metadata = {}

            memory.metadata["ranking_scores"] = {
                "similarity": similarity_score,
                "recency": recency_score,
                "importance": importance_score,
                "final_score": final_score,
            }

            ranked_memories.append(memory)

        ranked_memories.sort(key=self._get_final_score, reverse=True)

        top_score = self._get_final_score(ranked_memories[0]) if ranked_memories else 0.0
        bottom_score = self._get_final_score(ranked_memories[-1]) if ranked_memories else 0.0
        logger.debug(
            "Ranked %d memories: top score=%.4f, bottom score=%.4f",
            len(ranked_memories),
            top_score,
            bottom_score,
        )

        return ranked_memories

    def _get_weights(self, config: ContextConfig) -> Dict[str, float]:
        """
        Extract ranking weights from config or use defaults.

        Args:
            config: ContextConfig with optional ranking_weights

        Returns:
            Dictionary with similarity, recency, and importance weights (normalized)
        """
        # Determine which weights to use (config override or defaults)
        weights = {
            "similarity": self.similarity_weight,
            "recency": self.recency_weight,
            "importance": self.importance_weight,
        }

        if config.ranking_weights:
            weights.update(
                {key: config.ranking_weights.get(key, weights[key]) for key in weights.keys()}
            )

        # Validate and normalize
        return self._normalize_weights(weights)

    def _normalize_weights(self, weights: Dict[str, float]) -> Dict[str, float]:
        """
        Normalize weights to sum to 1.0, with validation.

        Args:
            weights: Dictionary with similarity, recency, importance weights

        Returns:
            Normalized weights dictionary
        """
        # Check for negative weights
        if any(w < 0 for w in weights.values()):
            logger.warning("Negative weights detected, using defaults")
            return self._get_default_normalized_weights()

        total = sum(weights.values())
        if total > 0:
            return {key: value / total for key, value in weights.items()}

        # Fallback to defaults if total is 0
        return self._get_default_normalized_weights()

    def _get_default_normalized_weights(self) -> Dict[str, float]:
        """Get normalized default weights."""
        total = self.similarity_weight + self.recency_weight + self.importance_weight
        if total > 0:
            return {
                "similarity": self.similarity_weight / total,
                "recency": self.recency_weight / total,
                "importance": self.importance_weight / total,
            }
        # Equal weights as last resort
        return {
            "similarity": 1.0 / 3.0,
            "recency": 1.0 / 3.0,
            "importance": 1.0 / 3.0,
        }

    def _get_final_score(self, memory: MemoryChunk) -> float:
        """
        Extract final_score from memory metadata safely.

        Args:
            memory: MemoryChunk with ranking_scores in metadata

        Returns:
            Final score (0.0 if not found or metadata is None)
        """
        if not memory.metadata:
            return 0.0
        ranking_scores = memory.metadata.get("ranking_scores", {})
        return float(ranking_scores.get("final_score", 0.0))

    def _get_similarity_score(self, memory: MemoryChunk) -> float:
        """
        Extract similarity score from memory chunk.

        The similarity score should already be populated by the retrieval step
        (e.g., from vector search in sources.py). This method simply extracts
        the pre-calculated value.

        Args:
            memory: MemoryChunk with similarity_score (populated during retrieval)

        Returns:
            Similarity score (0.0-1.0), defaulting to 0.0 if missing
        """
        if memory.similarity_score is not None:
            return max(0.0, min(1.0, float(memory.similarity_score)))
        return 0.0

    @staticmethod
    def _ensure_utc(dt: datetime) -> datetime:
        """
        Ensure datetime is timezone-aware in UTC.

        Args:
            dt: Datetime (may be naive or timezone-aware)

        Returns:
            Timezone-aware datetime in UTC
        """
        if dt.tzinfo is None:
            return dt.replace(tzinfo=timezone.utc)
        return dt

    def _calculate_recency_score(self, memory: MemoryChunk, current_time: datetime) -> float:
        """
        Calculate recency score using exponential decay.

        Formula: recency_score = exp(-decay_rate * days_old)

        Args:
            memory: MemoryChunk with timestamp
            current_time: Current datetime for age calculation

        Returns:
            Recency score between 0.0 and 1.0 (newer memories score higher)
        """
        memory_time = self._ensure_utc(memory.timestamp)
        current_time = self._ensure_utc(current_time)

        time_delta = current_time - memory_time
        days_old = max(0.0, time_delta.total_seconds() / 86400.0)

        recency_score = math.exp(-self.recency_decay_rate * days_old)
        return max(0.0, min(1.0, recency_score))

    def _get_importance_score(self, memory: MemoryChunk) -> float:
        """
        Extract importance score from memory metadata if available.

        This method uses graceful degradation: invalid importance values are logged
        at debug level and default to 0.0. This design choice prioritizes system
        stability over strict data validation, allowing ranking to continue even
        with malformed metadata.

        Args:
            memory: MemoryChunk with potential importance in metadata

        Returns:
            Importance score (0.0-1.0), defaulting to 0.0 if not found or invalid
        """
        if not memory.metadata:
            return 0.0

        importance = memory.metadata.get("importance")
        if importance is None:
            return 0.0

        try:
            importance_float = float(importance)
            return max(0.0, min(1.0, importance_float))
        except (ValueError, TypeError):
            logger.debug(
                "Invalid importance value in metadata for memory id=%s: %s",
                memory.id,
                importance,
            )
            return 0.0
