"""Taxonomic memory operations for MemoryEngine.

Internal implementation - use MemoryEngine from mongomem_core.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Dict, List

from mongomem_core.exceptions import ValidationError
from mongomem_core.memory.taxonomic import (
    create_taxonomic,
    delete_taxonomic,
    get_distinct_domains,
    get_taxonomic,
    list_taxonomic,
    list_taxonomic_by_domains,
    soft_delete_taxonomic,
    update_taxonomic,
)
from mongomem_core.models.engine import CreateTaxonomicResult, DeleteResult
from mongomem_core.models.filters import MetadataFilter
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.models.memory.taxonomic import (
    CreationMethod,
    TaxonomicIn,
    TaxonomicOut,
    TaxonomicUpdate,
)
from mongomem_core.models.retrieval import MemoryChunk
from mongomem_core.retrieval import fetch_taxonomic_memories
from pydantic import ValidationError as PydanticValidationError

if TYPE_CHECKING:
    from mongomem_core.engine._protocol import EngineProtocol

logger = logging.getLogger(__name__)


class _Taxonomic:
    """Taxonomic memory CRUD and retrieval operations."""

    def fetch_taxonomic_memories(
        self: "EngineProtocol",
        query: str | List[float],
        org_id: str,
        *,
        user_id: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        domain: str | None = None,
        domains: List[str] | None = None,
        query_expansion: bool | None = None,
        top_k: int = 50,
        similarity_threshold: float = 0.0,
        dedup_threshold: float = 0.5,
        prefetched: List[TaxonomicOut] | None = None,
        deduplicate: bool = True,
        rank: bool = True,
        metadata_filter: MetadataFilter | None = None,
    ) -> List[MemoryChunk]:
        """
        Fetch, deduplicate, and rank taxonomic memories.

        Args:
            query: Query text or pre-computed embedding vector
            org_id: Organization ID for multi-tenancy
            user_id: Optional user ID filter
            visibility: Optional visibility scope filter
            project_id: Optional group ID filter
            domain: Optional filter by single domain
            domains: Optional filter by multiple domains
            query_expansion: Optional filter by query_expansion flag
            top_k: Maximum number of results from vector search
            similarity_threshold: Minimum similarity score
            dedup_threshold: Threshold for similarity-based deduplication
            prefetched: Optional pre-fetched taxonomic memories
            deduplicate: Whether to deduplicate results
            rank: Whether to rank results
            metadata_filter: Optional metadata filter for Atlas Vector Search pre-filtering

        Returns:
            List of MemoryChunk objects
        """
        vis = ChunkVisibility(visibility) if visibility else None

        return fetch_taxonomic_memories(
            db=self._db,
            org_id=org_id,
            query=query,
            embedder=self._embedder,
            user_id=user_id,
            visibility=vis,
            project_id=project_id,
            domain=domain,
            domains=domains,
            query_expansion=query_expansion,
            top_k=top_k,
            similarity_threshold=similarity_threshold,
            dedup_threshold=dedup_threshold,
            prefetched=prefetched,
            deduplicate=deduplicate,
            rank=rank,
            metadata_filter=metadata_filter,
        )

    def create_taxonomic(
        self: "EngineProtocol",
        *,
        domain: str,
        term: str,
        definition: str,
        org_id: str,
        user_id: str,
        related_terms: List[str] | None = None,
        query_expansion: bool = True,
        visibility: str = "org",
        project_id: str | None = None,
        contextual_metadata: Dict[str, Any] | None = None,
        agent_id: str | None = None,
        extraction_source: str | None = None,
        creation_method: str = "user_created",
        source_agent: str | None = None,
        user_source: str | None = None,
        source_reference: str | None = None,
        evidence_spans: List[Dict[str, Any]] | None = None,
        confidence_score: float | None = None,
        embedding: list[float] | None = None,
        skip_embedding: bool = False,
    ) -> CreateTaxonomicResult:
        """
        Create a taxonomic memory (domain-specific term with definition).

        Args:
            domain: Domain/category for this term
            term: The term being defined
            definition: Definition of the term
            org_id: Organization ID for multi-tenancy
            user_id: User ID who owns this memory
            related_terms: Related terms for semantic linking
            query_expansion: Whether to use this term for query expansion
            visibility: Visibility scope (default: "org" for taxonomic)
            project_id: Project ID (required when visibility="shared")
            contextual_metadata: Additional context
            agent_id: Agent ID if created via agent
            extraction_source: Source type (user_direct, agent_mediated, etc.)
            creation_method: How the entry was created (user_created, llm_extraction, etc.)
            source_agent: Agent/model that created this entry (for LLM extractions)
            user_source: User ID who initiated the creation
            source_reference: Reference to source document (e.g., snapshot ID)
            evidence_spans: Evidence spans for LLM extractions
            confidence_score: Confidence score for LLM extractions
            embedding: Pre-computed embedding
            skip_embedding: If True, don't embed even if embedder available

        Returns:
            CreateTaxonomicResult with the created document's ID
        """
        logger.debug(
            "Creating taxonomic memory: domain=%s term=%s org=%s user=%s skip_embedding=%s",
            domain,
            term,
            org_id,
            user_id,
            skip_embedding,
        )

        # Generate embedding from definition (the main content)
        final_embedding = embedding
        embedding_model_id = None
        if not skip_embedding and embedding is None and self._embedder is not None:
            logger.debug(
                "Generating embedding for taxonomic memory: domain=%s term=%s", domain, term
            )
            # Embed the definition as the primary content
            final_embedding = self._embedder.embed(definition)
            embedding_model_id = self._embedder.model_id

        try:
            taxonomic_in = TaxonomicIn(
                domain=domain,
                term=term,
                definition=definition,
                related_terms=related_terms or [],
                query_expansion=query_expansion,
                visibility=ChunkVisibility(visibility) if visibility else ChunkVisibility.ORG,
                project_id=project_id,
                contextual_metadata=contextual_metadata,
                agent_id=agent_id,
                extraction_source=extraction_source,
                creation_method=CreationMethod(creation_method)
                if creation_method
                else CreationMethod.USER_CREATED,
                source_agent=source_agent,
                user_source=user_source,
                source_reference=source_reference,
                evidence_spans=evidence_spans,
                confidence_score=confidence_score,
            )
        except PydanticValidationError as exc:
            logger.warning(
                "Validation failed for create_taxonomic: domain=%s term=%s errors=%s",
                domain,
                term,
                exc.errors(),
            )
            raise ValidationError(
                f"Invalid taxonomic data: {exc}",
                details={"domain": domain, "term": term, "validation_errors": exc.errors()},
            ) from exc

        taxonomic_doc = create_taxonomic(
            db=self._db,
            taxonomic_in=taxonomic_in,
            org_id=org_id,
            user_id=user_id,
            embedding=final_embedding,
            embedding_model_id=embedding_model_id,
        )

        logger.info(
            "Taxonomic memory created: id=%s domain=%s term=%s has_embedding=%s",
            taxonomic_doc.id,
            taxonomic_doc.domain,
            taxonomic_doc.term,
            taxonomic_doc.has_embedding,
        )

        return CreateTaxonomicResult(
            id=str(taxonomic_doc.id),
            domain=taxonomic_doc.domain,
            term=taxonomic_doc.term,
            has_embedding=taxonomic_doc.has_embedding,
            acknowledged=True,
        )

    def bulk_create_taxonomic(
        self: "EngineProtocol",
        terms: List[Dict[str, Any]],
        org_id: str,
        user_id: str,
        *,
        domain: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        generate_embeddings: bool = True,
        skip_duplicates: bool = True,
    ) -> List[CreateTaxonomicResult]:
        """
        Bulk create multiple taxonomic memories.

        Efficiently creates multiple terms, optionally generating embeddings
        for all of them in a batch. This is optimized for extraction pipelines.

        Args:
            terms: List of term dicts with keys: term, definition, related_terms (optional)
            org_id: Organization ID
            user_id: User ID of the creator
            domain: Domain for all terms (required if not in each term dict)
            visibility: Visibility scope (default: org)
            project_id: Project ID for shared visibility
            generate_embeddings: If True, generate embeddings for all terms
            skip_duplicates: If True, skip duplicates instead of failing

        Returns:
            List of CreateTaxonomicResult for successfully created terms

        Example:
            >>> results = engine.bulk_create_taxonomic(
            ...     terms=[
            ...         {"term": "Python", "definition": "A programming language"},
            ...         {"term": "Rust", "definition": "A systems language"},
            ...     ],
            ...     org_id="org_1",
            ...     user_id="user_1",
            ...     domain="programming",
            ... )
        """
        from mongomem_core.memory.taxonomic import bulk_create_taxonomic
        from mongomem_core.models.memory.taxonomic import TaxonomicIn

        if not terms:
            return []

        # Build TaxonomicIn models
        taxonomic_inputs: List[TaxonomicIn] = []
        for term_data in terms:
            term_domain = term_data.get("domain", domain)
            if not term_domain:
                logger.warning("Skipping term without domain: %s", term_data.get("term"))
                continue

            try:
                taxonomic_in = TaxonomicIn(
                    domain=term_domain,
                    term=term_data["term"],
                    definition=term_data["definition"],
                    related_terms=term_data.get("related_terms", []),
                    query_expansion=term_data.get("query_expansion", True),
                    visibility=ChunkVisibility(visibility) if visibility else ChunkVisibility.ORG,
                    project_id=project_id if visibility == "shared" else None,
                )
                taxonomic_inputs.append(taxonomic_in)
            except (KeyError, PydanticValidationError) as exc:
                logger.warning("Skipping invalid term: %s - %s", term_data.get("term"), exc)
                continue

        if not taxonomic_inputs:
            return []

        # Generate embeddings if requested
        embeddings: List[List[float]] | None = None
        embedding_model_id: str | None = None
        if generate_embeddings and self._embedder:
            texts = [f"{t.term}: {t.definition}" for t in taxonomic_inputs]
            try:
                embeddings = self._embedder.embed_batch(texts)
                embedding_model_id = self._embedder.model_id
            except Exception as exc:
                logger.warning("Failed to generate embeddings for bulk create: %s", exc)

        # Bulk create
        created_docs = bulk_create_taxonomic(
            db=self._db,
            terms=taxonomic_inputs,
            org_id=org_id,
            user_id=user_id,
            embeddings=embeddings,
            embedding_model_id=embedding_model_id,
            skip_duplicates=skip_duplicates,
        )

        logger.info(
            "Bulk created %d/%d taxonomic memories for org=%s",
            len(created_docs),
            len(taxonomic_inputs),
            org_id,
        )

        return [
            CreateTaxonomicResult(
                id=str(doc.id),
                domain=doc.domain,
                term=doc.term,
                has_embedding=doc.has_embedding,
                acknowledged=True,
            )
            for doc in created_docs
        ]

    def count_taxonomic(
        self: "EngineProtocol",
        org_id: str,
        *,
        domain: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        include_deleted: bool = False,
    ) -> int:
        """
        Count taxonomic memories matching criteria.

        Args:
            org_id: Organization ID
            domain: Optional filter by domain
            visibility: Optional filter by visibility scope
            project_id: Optional filter by group ID
            include_deleted: If True, include soft-deleted documents

        Returns:
            Count of matching documents
        """
        from mongomem_core.memory.taxonomic import count_taxonomic

        return count_taxonomic(
            db=self._db,
            org_id=org_id,
            domain=domain,
            visibility=ChunkVisibility(visibility) if visibility else None,
            project_id=project_id,
            include_deleted=include_deleted,
        )

    def get_taxonomic(
        self: "EngineProtocol",
        org_id: str,
        *,
        id: str | None = None,
        domain: str | None = None,
        term: str | None = None,
        user_id: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        include_deleted: bool = False,
    ) -> TaxonomicOut | None:
        """
        Retrieve a taxonomic memory by ID or domain+term.

        Args:
            org_id: Organization ID
            id: Document ID (mutually exclusive with domain+term)
            domain: Domain name (used with term)
            term: Term name (used with domain)
            project_id: Optional project ID for scope filtering
            include_deleted: Include soft-deleted documents

        Returns:
            TaxonomicOut if found, None otherwise
        """
        return get_taxonomic(
            db=self._db,
            org_id=org_id,
            id=id,
            domain=domain,
            term=term,
            user_id=user_id,
            visibility=visibility,
            project_id=project_id,
            include_deleted=include_deleted,
        )

    def list_taxonomic(
        self: "EngineProtocol",
        org_id: str,
        *,
        user_id: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        domain: str | None = None,
        query_expansion: bool | None = None,
        limit: int = 100,
        include_deleted: bool = False,
    ) -> List[TaxonomicOut]:
        """
        List taxonomic memories with optional filters.

        Args:
            org_id: Organization ID
            user_id: Filter by user ID
            visibility: Filter by visibility
            project_id: Filter by group ID
            domain: Filter by domain
            query_expansion: Filter by query_expansion flag
            limit: Maximum number of results
            include_deleted: Include soft-deleted documents

        Returns:
            List of TaxonomicOut documents
        """
        return list_taxonomic(
            db=self._db,
            org_id=org_id,
            user_id=user_id,
            visibility=ChunkVisibility(visibility) if visibility else None,
            project_id=project_id,
            domain=domain,
            query_expansion=query_expansion,
            limit=limit,
            include_deleted=include_deleted,
        )

    def list_taxonomic_by_domains(
        self: "EngineProtocol",
        org_id: str,
        domains: List[str],
        *,
        user_id: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        query_expansion: bool | None = None,
        limit: int | None = None,
        include_deleted: bool = False,
    ) -> List[TaxonomicOut]:
        """
        List taxonomic memories for multiple domains.

        Args:
            org_id: Organization ID
            domains: List of domains to filter by
            user_id: Filter by user ID
            visibility: Filter by visibility
            project_id: Filter by group ID
            query_expansion: Filter by query_expansion flag
            limit: Maximum number of results
            include_deleted: Include soft-deleted documents

        Returns:
            List of TaxonomicOut documents
        """
        return list_taxonomic_by_domains(
            db=self._db,
            org_id=org_id,
            domains=domains,
            user_id=user_id,
            visibility=ChunkVisibility(visibility) if visibility else None,
            project_id=project_id,
            query_expansion=query_expansion,
            limit=limit,
            include_deleted=include_deleted,
        )

    def get_taxonomic_domains(
        self: "EngineProtocol",
        org_id: str,
        *,
        visibility: str | None = None,
        project_id: str | None = None,
        include_deleted: bool = False,
    ) -> List[str]:
        """
        Get distinct domains for an organization.

        Args:
            org_id: Organization ID
            visibility: Filter by visibility
            project_id: Filter by group ID
            include_deleted: Include soft-deleted documents

        Returns:
            List of distinct domain names
        """
        return get_distinct_domains(
            db=self._db,
            org_id=org_id,
            visibility=ChunkVisibility(visibility) if visibility else None,
            project_id=project_id,
            include_deleted=include_deleted,
        )

    def update_taxonomic(
        self: "EngineProtocol",
        org_id: str,
        *,
        id: str | None = None,
        domain: str | None = None,
        term: str | None = None,
        definition: str | None = None,
        related_terms: List[str] | None = None,
        query_expansion: bool | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        contextual_metadata: Dict[str, Any] | None = None,
    ) -> TaxonomicOut | None:
        """
        Update a taxonomic memory.

        Args:
            org_id: Organization ID
            id: Document ID (mutually exclusive with domain+term for lookup)
            domain: Domain name (for lookup, or new domain value)
            term: Term name (for lookup, or new term value)
            definition: New definition
            related_terms: New related terms
            query_expansion: New query_expansion flag
            visibility: New visibility
            project_id: New group ID
            contextual_metadata: New metadata

        Returns:
            Updated TaxonomicOut if found, None otherwise

        Note:
            Either `id` or (`domain` and `term`) must be provided for lookup.
            If updating domain/term, use a separate update model fields.
        """
        # Build update model
        update = TaxonomicUpdate(
            definition=definition,
            related_terms=related_terms,
            query_expansion=query_expansion,
            visibility=ChunkVisibility(visibility) if visibility else None,
            project_id=project_id,
            contextual_metadata=contextual_metadata,
        )

        # Determine lookup parameters
        lookup_id = id
        lookup_domain = None
        lookup_term = None

        # If no id provided, use domain+term for lookup
        if id is None and domain is not None and term is not None:
            lookup_domain = domain
            lookup_term = term

        return update_taxonomic(
            db=self._db,
            org_id=org_id,
            update=update,
            id=lookup_id,
            domain=lookup_domain,
            term=lookup_term,
        )

    def delete_taxonomic(
        self: "EngineProtocol",
        org_id: str,
        *,
        id: str | None = None,
        domain: str | None = None,
        term: str | None = None,
        soft: bool = True,
    ) -> DeleteResult:
        """
        Delete a taxonomic memory.

        Args:
            org_id: Organization ID
            id: Document ID (mutually exclusive with domain+term)
            domain: Domain name (used with term)
            term: Term name (used with domain)
            soft: If True (default), soft delete. If False, hard delete.

        Returns:
            DeleteResult with deleted_count
        """
        if soft:
            update_result = soft_delete_taxonomic(
                db=self._db, org_id=org_id, id=id, domain=domain, term=term
            )
            deleted_count = update_result.modified_count
        else:
            delete_result = delete_taxonomic(
                db=self._db, org_id=org_id, id=id, domain=domain, term=term
            )
            deleted_count = delete_result.deleted_count

        logger.info(
            "Deleted taxonomic memory: org=%s id=%s domain=%s term=%s soft=%s count=%d",
            org_id,
            id,
            domain,
            term,
            soft,
            deleted_count,
        )
        return DeleteResult(deleted_count=deleted_count, acknowledged=True)
