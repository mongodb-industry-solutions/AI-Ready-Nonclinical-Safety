"""Domain-specific observability helper for mongomem_core.

Provides a high-level API for emitting metrics, spans, and events
with consistent naming and tagging conventions.
"""

from __future__ import annotations

import time
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, Dict, Generator, Optional

if TYPE_CHECKING:
    from mongomem_core.protocols import ObservabilityProtocol


class CoreObservability:
    """
    Domain-specific observability helper for mongomem_core.

    Wraps an ObservabilityProtocol with convenient methods for emitting
    metrics, spans, and events for common engine, retrieval, and extraction
    operations. All names are prefixed with 'mongomem.' for consistent namespacing.

    Args:
        backend: ObservabilityProtocol implementation to delegate to.
                 If None, a NoOpObservability is used.
        org_id: Optional organization ID to include in all metric tags.
        user_id: Optional user ID to include in all metric tags.
    """

    def __init__(
        self,
        backend: Optional["ObservabilityProtocol"] = None,
        org_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> None:
        if backend is None:
            from mongomem_core.observability.defaults import NoOpObservability

            backend = NoOpObservability()
        self._backend = backend
        self._org_id = org_id
        self._user_id = user_id

    def _tags(self, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        """Build tags dict with org_id/user_id if set."""
        tags: Dict[str, str] = {}
        if self._org_id:
            tags["org_id"] = self._org_id
        if self._user_id:
            tags["user_id"] = self._user_id
        if extra:
            tags.update(extra)
        return tags

    # -------------------------------------------------------------------------
    # Engine: Write Operations (Phase 2)
    # -------------------------------------------------------------------------

    def write_turn_started(self) -> None:
        """Record start of a write_turn operation."""
        self._backend.increment("mongomem.engine.write_turn.count", tags=self._tags())

    def write_turn_completed(self, duration_ms: float) -> None:
        """Record completion of a write_turn operation."""
        self._backend.timing("mongomem.engine.write_turn.latency", duration_ms, tags=self._tags())

    @contextmanager
    def track_write_turn(self) -> Generator[None, None, None]:
        """Context manager to track write_turn duration with span."""
        self.write_turn_started()
        start = time.perf_counter()
        with self._backend.span("mongomem.engine.write_turn", kind="internal") as span:
            try:
                yield
            finally:
                duration_ms = (time.perf_counter() - start) * 1000
                span["duration_ms"] = duration_ms
                self.write_turn_completed(duration_ms)

    def internal_state_updated(self, duration_ms: float, tokens: int) -> None:
        """Record internal state (IWM) update metrics."""
        tags = self._tags()
        self._backend.timing("mongomem.engine.internal_state.latency", duration_ms, tags=tags)
        self._backend.histogram("mongomem.engine.internal_state.tokens", tokens, tags=tags)

    @contextmanager
    def track_internal_state_update(self) -> Generator[Dict[str, Any], None, None]:
        """
        Context manager to track internal state update duration with span.

        Yields a dict where you must set 'tokens' before exiting:

            with obs.track_internal_state_update() as ctx:
                result = upsert_internal_state(...)
                ctx['tokens'] = result.token_count

        This ensures consistent timing while allowing access to the result.
        """
        start = time.perf_counter()
        ctx: Dict[str, Any] = {"tokens": 0}
        with self._backend.span("mongomem.engine.internal_state", kind="internal") as span:
            try:
                yield ctx
            finally:
                duration_ms = (time.perf_counter() - start) * 1000
                span["duration_ms"] = duration_ms
                span["tokens"] = ctx.get("tokens", 0)
                self.internal_state_updated(duration_ms, ctx.get("tokens", 0))

    # -------------------------------------------------------------------------
    # Memory: Write Operations
    # -------------------------------------------------------------------------

    def memory_written(self, memory_type: str, duration_ms: float) -> None:
        """Record a memory write operation."""
        tags = self._tags({"memory_type": memory_type})
        self._backend.increment("mongomem.memory.written", tags=tags)
        self._backend.timing("mongomem.memory.write.latency", duration_ms, tags=tags)

    # -------------------------------------------------------------------------
    # Context Building (Phase 3)
    # -------------------------------------------------------------------------

    def context_built(
        self,
        memories_count: int,
        tokens: int,
        duration_ms: float,
    ) -> None:
        """Record context building completion metrics."""
        tags = self._tags()
        self._backend.timing("mongomem.context.latency", duration_ms, tags=tags)
        self._backend.histogram("mongomem.context.memories.count", memories_count, tags=tags)
        self._backend.histogram("mongomem.context.tokens.used", tokens, tags=tags)

    @contextmanager
    def track_context_build(self) -> Generator[Dict[str, Any], None, None]:
        """
        Context manager to track context building duration with span.

        Yields a dict where you must set 'memories_count' and 'tokens' before exiting:

            with obs.track_context_build() as ctx:
                response = build_context(...)
                ctx['memories_count'] = response.metadata.memory_count
                ctx['tokens'] = response.metadata.token_count

        This ensures consistent timing while allowing access to the result.
        """
        start = time.perf_counter()
        ctx: Dict[str, Any] = {"memories_count": 0, "tokens": 0}
        with self._backend.span("mongomem.engine.build_context", kind="internal") as span:
            try:
                yield ctx
            finally:
                duration_ms = (time.perf_counter() - start) * 1000
                span["duration_ms"] = duration_ms
                span["memories_count"] = ctx.get("memories_count", 0)
                span["tokens"] = ctx.get("tokens", 0)
                self.context_built(ctx.get("memories_count", 0), ctx.get("tokens", 0), duration_ms)

    @contextmanager
    def span_context_stage(
        self,
        stage: str,
        attributes: Optional[Dict[str, Any]] = None,
    ) -> Generator[Dict[str, Any], None, None]:
        """Create a span for a context building stage."""
        with self._backend.span(
            f"mongomem.context.{stage}",
            kind="internal",
            attributes=attributes,
        ) as span:
            yield span

    def retrieval_source_completed(
        self,
        source: str,
        count: int,
        duration_ms: float,
    ) -> None:
        """Record retrieval from a specific source (STM, semantic, episodic, etc.)."""
        tags = self._tags({"source": source, "status": "success"})
        self._backend.timing("mongomem.retrieval.source.latency", duration_ms, tags=tags)
        self._backend.histogram("mongomem.retrieval.source.count", count, tags=tags)

    def retrieval_source_failed(
        self,
        source: str,
        error_type: str,
        duration_ms: Optional[float] = None,
        error_message: Optional[str] = None,
    ) -> None:
        """
        Record a failed retrieval from a specific source.

        Args:
            source: Source name (stm, semantic, episodic, taxonomic)
            error_type: Type of error (timeout, database_error, unknown)
            duration_ms: Optional duration if timing is available
            error_message: Optional error message for the event
        """
        tags = self._tags({"source": source, "status": "error", "error_type": error_type})
        self._backend.increment("mongomem.retrieval.source.failed", tags=tags)
        if duration_ms is not None:
            self._backend.timing("mongomem.retrieval.source.latency", duration_ms, tags=tags)

        self._backend.event(
            "mongomem.retrieval.source.failed",
            attributes={
                "source": source,
                "error_type": error_type,
                "error_message": error_message,
            },
            level="warning",
        )

    @contextmanager
    def track_retrieval_source(self, source: str) -> Generator[Dict[str, Any], None, None]:
        """
        Context manager to track retrieval from a specific source.

        Yields a dict where you must set 'count' before exiting:

            with obs.track_retrieval_source("semantic") as ctx:
                chunks = fetch_semantic_memories(...)
                ctx['count'] = len(chunks)

        This ensures consistent timing while allowing access to the result.
        """
        start = time.perf_counter()
        ctx: Dict[str, Any] = {"count": 0}
        try:
            yield ctx
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            self.retrieval_source_completed(source, ctx.get("count", 0), duration_ms)

    def deduplication_completed(self, removed_count: int) -> None:
        """Record deduplication results."""
        self._backend.histogram(
            "mongomem.retrieval.dedup.removed",
            removed_count,
            tags=self._tags(),
        )

    # -------------------------------------------------------------------------
    # Embeddings
    # -------------------------------------------------------------------------

    def embedding_generated(
        self,
        text_length: int,
        dimension: int,
        duration_ms: float,
    ) -> None:
        """Record embedding generation metrics."""
        tags = self._tags({"dimension": str(dimension)})
        self._backend.increment("mongomem.embedding.generated", tags=tags)
        self._backend.timing("mongomem.embedding.latency", duration_ms, tags=tags)
        self._backend.histogram("mongomem.embedding.text_length", text_length, tags=tags)

    def embedding_batch_generated(
        self,
        batch_size: int,
        dimension: int,
        duration_ms: float,
    ) -> None:
        """Record batch embedding generation metrics."""
        tags = self._tags({"dimension": str(dimension)})
        self._backend.increment("mongomem.embedding.batch.generated", tags=tags)
        self._backend.histogram("mongomem.embedding.batch.size", batch_size, tags=tags)
        self._backend.timing("mongomem.embedding.batch.latency", duration_ms, tags=tags)

    # -------------------------------------------------------------------------
    # Extraction Pipelines (Phase 4)
    # -------------------------------------------------------------------------

    def extraction_completed(
        self,
        extraction_type: str,
        extracted_count: int,
        duration_ms: float,
    ) -> None:
        """Record extraction pipeline completion metrics."""
        tags = self._tags({"extraction_type": extraction_type})
        self._backend.timing("mongomem.extraction.latency", duration_ms, tags=tags)
        self._backend.histogram("mongomem.extraction.items.extracted", extracted_count, tags=tags)

    @contextmanager
    def span_extraction(
        self,
        extraction_type: str,
    ) -> Generator[Dict[str, Any], None, None]:
        """
        Create a span for an extraction pipeline run.

        This creates only the span, not the metrics (use emit_extraction_result for metrics).
        Use this when you have existing metric emission logic and just need span tracing.

            with obs.span_extraction("semantic") as span:
                result = self._run_extraction(...)
                span['extracted_count'] = result.extracted_count
        """
        with self._backend.span(
            f"mongomem.extraction.{extraction_type}",
            kind="internal",
            attributes={"extraction_type": extraction_type},
        ) as span:
            yield span

    def extraction_consolidation(
        self,
        extraction_type: str,
        action: str,
        count: int = 1,
    ) -> None:
        """
        Record extraction consolidation action.

        Args:
            extraction_type: Type of extraction (semantic, episodic, taxonomic)
            action: Consolidation action (add, update, reinforce, duplicate)
            count: Number of items affected
        """
        tags = self._tags({"extraction_type": extraction_type, "action": action})
        self._backend.increment("mongomem.extraction.consolidation", value=count, tags=tags)

    def extraction_failed(
        self,
        extraction_type: str,
        error_message: str,
        source_id: Optional[str] = None,
    ) -> None:
        """
        Emit an event when an extraction pipeline fails.

        Args:
            extraction_type: Type of extraction (semantic, episodic, taxonomic)
            error_message: Error message describing the failure
            source_id: Optional source reference (snapshot ID)
        """
        self._backend.event(
            "mongomem.extraction.failed",
            attributes={
                "extraction_type": extraction_type,
                "error_message": error_message,
                "source_id": source_id,
            },
            level="error",
        )

    def emit_extraction_result(
        self,
        extraction_type: str,
        extracted_count: int,
        duration_ms: float,
        add_count: int = 0,
        update_count: int = 0,
        reinforce_count: int = 0,
        duplicate_count: int = 0,
    ) -> None:
        """
        Emit all metrics for an extraction pipeline run.

        This is a convenience method that combines extraction_completed and
        extraction_consolidation calls into a single method, reducing
        boilerplate in extraction pipelines.

        Args:
            extraction_type: Type of extraction (semantic, episodic, taxonomic)
            extracted_count: Number of items extracted
            duration_ms: Processing time in milliseconds
            add_count: Number of items added (consolidation)
            update_count: Number of items updated (consolidation)
            reinforce_count: Number of items reinforced (consolidation)
            duplicate_count: Number of duplicates skipped (consolidation)
        """
        # Emit extraction completion metrics
        self.extraction_completed(extraction_type, extracted_count, duration_ms)

        # Emit consolidation stats (only if non-zero)
        if add_count:
            self.extraction_consolidation(extraction_type, "add", add_count)
        if update_count:
            self.extraction_consolidation(extraction_type, "update", update_count)
        if reinforce_count:
            self.extraction_consolidation(extraction_type, "reinforce", reinforce_count)
        if duplicate_count:
            self.extraction_consolidation(extraction_type, "duplicate", duplicate_count)

    def preferences_updated(self, fields_updated: int, duration_ms: float) -> None:
        """Record preferences extraction metrics."""
        tags = self._tags()
        self._backend.timing("mongomem.extraction.preferences.latency", duration_ms, tags=tags)
        self._backend.histogram(
            "mongomem.extraction.preferences.fields_updated",
            fields_updated,
            tags=tags,
        )

    @contextmanager
    def track_extraction(self, extraction_type: str) -> Generator[Dict[str, Any], None, None]:
        """
        Context manager to track extraction pipeline duration with span.

        Yields a dict where you must set 'extracted_count' before exiting:

            with obs.track_extraction("semantic") as ctx:
                result = pipeline.run(...)
                ctx['extracted_count'] = result.extracted_count

        This ensures consistent timing while allowing access to the result.
        """
        start = time.perf_counter()
        ctx: Dict[str, Any] = {"extracted_count": 0}
        with self._backend.span(
            f"mongomem.extraction.{extraction_type}",
            kind="internal",
            attributes={"extraction_type": extraction_type},
        ) as span:
            try:
                yield ctx
            finally:
                duration_ms = (time.perf_counter() - start) * 1000
                span["duration_ms"] = duration_ms
                span["extracted_count"] = ctx.get("extracted_count", 0)
                self.extraction_completed(
                    extraction_type, ctx.get("extracted_count", 0), duration_ms
                )

    @contextmanager
    def track_preferences_update(self) -> Generator[Dict[str, Any], None, None]:
        """
        Context manager to track preferences update duration with span.

        Yields a dict where you must set 'fields_updated' before exiting:

            with obs.track_preferences_update() as ctx:
                result = pipeline.run(...)
                ctx['fields_updated'] = result.fields_updated

        This ensures consistent timing while allowing access to the result.
        """
        start = time.perf_counter()
        ctx: Dict[str, Any] = {"fields_updated": 0}
        with self._backend.span(
            "mongomem.extraction.preferences",
            kind="internal",
        ) as span:
            try:
                yield ctx
            finally:
                duration_ms = (time.perf_counter() - start) * 1000
                span["duration_ms"] = duration_ms
                span["fields_updated"] = ctx.get("fields_updated", 0)
                self.preferences_updated(ctx.get("fields_updated", 0), duration_ms)

    # -------------------------------------------------------------------------
    # Approval Workflow (Phase 5)
    # -------------------------------------------------------------------------

    def approval_staged(
        self,
        extraction_type: str,
        action: str,
        source_id: Optional[str] = None,
    ) -> None:
        """Record item staged for approval."""
        tags = self._tags({"extraction_type": extraction_type, "action": action})
        self._backend.increment("mongomem.approval.staged", tags=tags)
        self._backend.event(
            "mongomem.approval.staged",
            attributes={
                "extraction_type": extraction_type,
                "action": action,
                "source_id": source_id,
            },
        )

    def approval_approved(
        self,
        memory_id: str,
        queue_time_ms: float,
        approved_by: Optional[str] = None,
    ) -> None:
        """Record item approved."""
        tags = self._tags()
        self._backend.increment("mongomem.approval.approved", tags=tags)
        self._backend.histogram("mongomem.approval.queue_time", queue_time_ms, tags=tags)
        self._backend.event(
            "mongomem.approval.approved",
            attributes={
                "memory_id": memory_id,
                "queue_time_ms": queue_time_ms,
                "approved_by": approved_by,
            },
        )

    def approval_rejected(
        self,
        pending_id: str,
        rejection_reason: Optional[str] = None,
        reviewed_by: Optional[str] = None,
    ) -> None:
        """Record item rejected."""
        tags = self._tags()
        self._backend.increment("mongomem.approval.rejected", tags=tags)
        self._backend.event(
            "mongomem.approval.rejected",
            attributes={
                "pending_id": pending_id,
                "rejection_reason": rejection_reason,
                "reviewed_by": reviewed_by,
            },
        )

    def approval_timezone_mismatch(
        self,
        pending_id: str,
        memory_id: str,
    ) -> None:
        """Emit warning when timezone mismatch prevents queue time calculation."""
        self._backend.event(
            "mongomem.approval.timezone_mismatch",
            attributes={
                "pending_id": pending_id,
                "memory_id": memory_id,
                "message": "Timezone mismatch between now and created_at, queue_time_ms set to 0",
            },
            level="warning",
        )

    # -------------------------------------------------------------------------
    # Document Ingestion (Phase 6)
    # -------------------------------------------------------------------------

    def ingest_file_processed(self, file_type: str) -> None:
        """Record successful file ingestion."""
        self._backend.increment(
            "mongomem.ingest.files.processed",
            tags=self._tags({"file_type": file_type}),
        )

    def ingest_file_failed(
        self,
        file_type: str,
        error_type: str,
        file_path: Optional[str] = None,
        error_message: Optional[str] = None,
    ) -> None:
        """Record failed file ingestion with event."""
        self._backend.increment(
            "mongomem.ingest.files.failed",
            tags=self._tags({"file_type": file_type, "error_type": error_type}),
        )

        self._backend.event(
            "mongomem.ingest.file.failed",
            attributes={
                "file_type": file_type,
                "file_path": file_path,
                "error_type": error_type,
                "error_message": error_message,
            },
            level="warning",
        )

    def ingest_chunks_created(self, count: int) -> None:
        """Record chunks created during ingestion."""
        self._backend.histogram(
            "mongomem.ingest.chunks.created",
            count,
            tags=self._tags(),
        )

    def ingest_completed(self, duration_ms: float) -> None:
        """Record ingestion pipeline completion."""
        self._backend.timing("mongomem.ingest.latency", duration_ms, tags=self._tags())

    @contextmanager
    def span_ingest(self) -> Generator[Dict[str, Any], None, None]:
        """
        Create a span for document ingestion.

        This creates only the span, not the metrics (use ingest_* methods for metrics).
        Use this when you have existing metric emission logic and just need span tracing.

            with obs.span_ingest() as span:
                result = ingest_documents(...)
                span['files_processed'] = result.files_succeeded
        """
        with self._backend.span("mongomem.ingest", kind="internal") as span:
            yield span

    @contextmanager
    def track_ingest(self) -> Generator[Dict[str, Any], None, None]:
        """
        Context manager to track document ingestion duration with span.

        Yields a dict where you should set tracking data before exiting:

            with obs.track_ingest() as ctx:
                result = ingest_documents(...)
                ctx['files_processed'] = result.files_succeeded
                ctx['files_failed'] = result.files_failed
                ctx['chunks_created'] = result.total_chunks

        This ensures consistent timing while allowing access to the result.
        """
        start = time.perf_counter()
        ctx: Dict[str, Any] = {
            "files_processed": 0,
            "files_failed": 0,
            "chunks_created": 0,
        }
        with self._backend.span("mongomem.ingest", kind="internal") as span:
            try:
                yield ctx
            finally:
                duration_ms = (time.perf_counter() - start) * 1000
                span["duration_ms"] = duration_ms
                span["files_processed"] = ctx.get("files_processed", 0)
                span["files_failed"] = ctx.get("files_failed", 0)
                span["chunks_created"] = ctx.get("chunks_created", 0)
                self.ingest_completed(duration_ms)


__all__ = ["CoreObservability"]
