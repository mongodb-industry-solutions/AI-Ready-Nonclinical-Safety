from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict

from pymongo.database import Database

from ..storage import get_snapshot_collection, get_stm_collection
from ..utils import utcnow
from .base import TaskHandler

logger = logging.getLogger(__name__)


class MaintenanceHandler(TaskHandler):
    """
    Handler for memory maintenance tasks.

    Handles:
    - Snapshot promotion (STM → Snapshot)
    - Expired memory cleanup
    - Archive management
    """

    task_type = "maintenance"
    timeout_seconds = 300

    def __init__(self, db: Database) -> None:
        self._db = db
        self._stm_col = get_stm_collection(db)
        self._snapshot_col = get_snapshot_collection(db)

    async def handle_task(self, payload: Dict[str, Any]) -> None:
        """Handle a maintenance task."""
        task_type = payload.get("maintenance_type")

        if task_type == "promote_snapshot":
            await self._promote_snapshot(payload)
        elif task_type == "cleanup_expired":
            await self._cleanup_expired(payload)
        elif task_type == "archive_old":
            await self._archive_old(payload)
        else:
            logger.warning("Unknown maintenance task type: %s", task_type)

    async def _promote_snapshot(self, payload: Dict[str, Any]) -> None:
        """Promote STM documents to a snapshot.

        TODO: Import and use mongomem_core snapshot promotion once implemented:

            from ...mongomem_core.memory.snapshot import promote_session_to_snapshot

            snapshot = promote_session_to_snapshot(
                db=self._db,
                session_id=session_id,
                org_id=org_id,
                reason=reason,
                # Optional: summarizer for generating snapshot summary
                summarizer=self._llm,
            )

            # After promotion, optionally clean up promoted STM docs
            from ...mongomem_core.memory.short_term import delete_session_stm
            delete_session_stm(db=self._db, session_id=session_id, org_id=org_id)
        """
        session_id = payload.get("session_id")
        org_id = payload.get("org_id")
        reason = payload.get("reason", "auto")

        if not all([session_id, org_id]):
            logger.warning("Invalid promote_snapshot payload")
            return

        # TODO: Replace with mongomem_core.memory.snapshot.promote_session_to_snapshot()
        logger.info(
            "Snapshot promotion not yet implemented for session=%s org=%s reason=%s",
            session_id,
            org_id,
            reason,
        )

    async def _cleanup_expired(self, payload: Dict[str, Any]) -> None:
        """
        Clean up expired memory documents.

        IMPORTANT: STM documents are NOT deleted here. They should be:
        1. Promoted to snapshots first (via promotion logic)
        2. Deleted only after successful promotion

        This cleanup only handles:
        - Expired snapshots (if configured)
        - Orphaned metadata
        """
        org_id = payload.get("org_id")
        cutoff = payload.get("cutoff") or utcnow()

        if isinstance(cutoff, str):
            cutoff = datetime.fromisoformat(cutoff)

        try:
            # NOTE: We do NOT delete STM docs directly!
            # STM docs should be deleted only after promotion to snapshot.
            # The promotion flow handles: promote → delete promoted STMs
            #
            # Only delete snapshots that are:
            # 1. Past their expires_at
            # 2. Already promoted to episodic (promoted=True)
            snapshot_result = self._snapshot_col.delete_many(
                {
                    **({"org_id": org_id} if org_id else {}),
                    "expires_at": {"$lt": cutoff},
                    "promoted": True,  # Only delete if already promoted to episodic
                }
            )

            if snapshot_result.deleted_count > 0:
                logger.info(
                    "Cleaned up %d expired (promoted) snapshots (org=%s)",
                    snapshot_result.deleted_count,
                    org_id or "all",
                )
        except Exception as exc:
            logger.error("Failed to cleanup expired snapshots: %s", exc)
            raise

    async def _archive_old(self, payload: Dict[str, Any]) -> None:
        """Archive old memory documents.

        TODO: Import and use mongomem_core archival once implemented:

            from ...mongomem_core.memory.archive import archive_old_memories

            archived_count = archive_old_memories(
                db=self._db,
                org_id=payload.get("org_id"),
                cutoff_days=payload.get("cutoff_days", 90),
                memory_types=payload.get("memory_types", ["episodic", "semantic"]),
            )
        """
        # TODO: Replace with mongomem_core archival logic
        logger.debug("Archive not yet implemented")

    async def run_scheduled_maintenance(self) -> Dict[str, int]:
        """Run scheduled maintenance tasks. Returns counts of processed items."""
        results: Dict[str, int] = {}

        # Cleanup expired documents
        await self._cleanup_expired({})

        # TODO: Add more scheduled maintenance tasks

        return results


__all__ = ["MaintenanceHandler"]
