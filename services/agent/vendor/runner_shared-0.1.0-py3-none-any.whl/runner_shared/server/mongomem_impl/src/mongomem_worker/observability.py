from __future__ import annotations

import time
from contextlib import contextmanager
from typing import Any, Dict, Generator, Optional

from ..mongomem_core.observability import LoggingObservability, NoOpObservability
from ..mongomem_core.protocols import ObservabilityProtocol


class WorkerObservability:
    """
    Worker-specific observability helper.

    Wraps an ObservabilityProtocol with worker-specific metric names,
    structured events, and spans.

    Example usage:
        from ..mongomem_core.observability import LoggingObservability
        obs = WorkerObservability(backend=LoggingObservability(), worker_id="worker-1")

        # Or use NoOpObservability for zero overhead
        from ..mongomem_core.observability import NoOpObservability
        obs = WorkerObservability(backend=NoOpObservability(), worker_id="worker-1")
    """

    def __init__(
        self,
        backend: Optional[ObservabilityProtocol] = None,
        worker_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
    ):
        self._backend: ObservabilityProtocol = backend or LoggingObservability()
        self._worker_id = worker_id
        self._tenant_id = tenant_id

    def _tags(self, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        tags: Dict[str, str] = {}
        if self._worker_id:
            tags["worker_id"] = self._worker_id
        if self._tenant_id:
            tags["tenant_id"] = self._tenant_id
        if extra:
            tags.update(extra)
        return tags

    def _emit_event(
        self,
        name: str,
        attributes: Optional[Dict[str, Any]] = None,
        level: str = "info",
    ) -> None:
        """Emit structured event."""
        event_attrs: Dict[str, Any] = {}
        if self._worker_id:
            event_attrs["worker_id"] = self._worker_id
        if self._tenant_id:
            event_attrs["tenant_id"] = self._tenant_id
        if attributes:
            event_attrs.update(attributes)
        self._backend.event(name, attributes=event_attrs, level=level)

    @contextmanager
    def track_task(
        self,
        task_type: str,
        task_id: Optional[str] = None,
    ) -> Generator[Dict[str, Any], None, None]:
        """
        Context manager to track a task with spans and metrics.

        Creates a span for the task and emits task_claimed/task_completed/task_failed
        events automatically.

        Example:
            with metrics.track_task("embedding", task_id="task-123") as ctx:
                # Do task work...
                ctx["result"] = "success"
        """
        self.task_claimed(task_type, task_id=task_id)
        start = time.perf_counter()
        ctx: Dict[str, Any] = {"task_type": task_type, "task_id": task_id}

        try:
            with self._backend.span(
                f"mongomem.worker.task.{task_type}",
                kind="consumer",
                attributes={"task_type": task_type, "task_id": task_id},
            ) as span_attrs:
                yield ctx
                span_attrs.update(ctx)
        except Exception:
            if "error" not in ctx:
                ctx["error"] = True
            raise
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            if "error" not in ctx:
                self.task_completed(task_type, duration_ms, task_id=task_id)
            else:
                self.task_failed(
                    task_type,
                    error_type=ctx.get("error_type", "unknown"),
                    error_taxonomy=ctx.get("error_taxonomy", "unknown"),
                    task_id=task_id,
                )

    # Task metrics
    def task_claimed(self, task_type: str, task_id: Optional[str] = None) -> None:
        self._backend.increment("tasks_claimed", tags=self._tags({"task_type": task_type}))
        self._emit_event(
            "mongomem.worker.task.claimed",
            attributes={"task_type": task_type, "task_id": task_id},
        )

    def task_completed(
        self, task_type: str, duration_ms: float, task_id: Optional[str] = None
    ) -> None:
        tags = self._tags({"task_type": task_type})
        self._backend.increment("tasks_completed", tags=tags)
        self._backend.timing("task_duration", duration_ms, tags=tags)
        self._emit_event(
            "mongomem.worker.task.completed",
            attributes={
                "task_type": task_type,
                "task_id": task_id,
                "duration_ms": duration_ms,
            },
        )

    def task_failed(
        self,
        task_type: str,
        error_type: str,
        error_taxonomy: str,
        task_id: Optional[str] = None,
    ) -> None:
        self._backend.increment(
            "tasks_failed",
            tags=self._tags(
                {
                    "task_type": task_type,
                    "error_type": error_type,
                    "error_taxonomy": error_taxonomy,
                }
            ),
        )
        self._emit_event(
            "mongomem.worker.task.failed",
            attributes={
                "task_type": task_type,
                "task_id": task_id,
                "error_type": error_type,
                "error_taxonomy": error_taxonomy,
            },
            level="error",
        )

    def task_timeout(self, task_type: str, timeout_seconds: float) -> None:
        self._backend.increment(
            "tasks_timeout",
            tags=self._tags(
                {
                    "task_type": task_type,
                    "timeout": str(timeout_seconds),
                }
            ),
        )
        self._emit_event(
            "mongomem.worker.task.timeout",
            attributes={"task_type": task_type, "timeout_seconds": timeout_seconds},
            level="warning",
        )

    def task_retried(self, task_type: str, attempt: int) -> None:
        self._backend.increment(
            "tasks_retried",
            tags=self._tags(
                {
                    "task_type": task_type,
                    "attempt": str(attempt),
                }
            ),
        )
        self._emit_event(
            "mongomem.worker.task.retried",
            attributes={"task_type": task_type, "attempt": attempt},
            level="warning",
        )

    # Queue metrics
    def queue_depth(self, depth: int, status: str = "queued") -> None:
        self._backend.gauge(
            "queue_depth",
            depth,
            tags=self._tags({"status": status}),
        )

    def queue_time(self, task_type: str, wait_ms: float) -> None:
        self._backend.histogram(
            "queue_wait_time",
            wait_ms,
            tags=self._tags({"task_type": task_type}),
        )

    # Worker metrics
    def worker_active(self, active: bool) -> None:
        self._backend.gauge("worker_active", 1.0 if active else 0.0, tags=self._tags())

    def worker_idle(self, idle_seconds: float) -> None:
        self._backend.gauge("worker_idle_seconds", idle_seconds, tags=self._tags())

    def active_tasks(self, count: int) -> None:
        self._backend.gauge("active_tasks", count, tags=self._tags())

    # Change stream metrics
    def change_stream_active(self, active: bool) -> None:
        self._backend.gauge("change_stream_active", 1.0 if active else 0.0, tags=self._tags())

    def change_stream_reconnect(self) -> None:
        self._backend.increment("change_stream_reconnects", tags=self._tags())

    def change_stream_notification(self, collection: str) -> None:
        self._backend.increment(
            "change_stream_notifications",
            tags=self._tags({"collection": collection}),
        )

    def change_stream_latency(self, latency_ms: float) -> None:
        self._backend.histogram("change_stream_latency", latency_ms, tags=self._tags())

    # Heartbeat metrics
    def heartbeat_sent(self, task_type: str) -> None:
        self._backend.increment("heartbeats_sent", tags=self._tags({"task_type": task_type}))

    def heartbeat_failed(self, task_type: str) -> None:
        self._backend.increment("heartbeats_failed", tags=self._tags({"task_type": task_type}))

    # Stale task recovery
    def stale_tasks_reclaimed(self, count: int) -> None:
        self._backend.increment("stale_tasks_reclaimed", value=count, tags=self._tags())
        if count > 0:
            self._emit_event(
                "mongomem.worker.stale_tasks_reclaimed",
                attributes={"count": count},
                level="warning",
            )

    # Circuit breaker metrics
    def circuit_breaker_state(self, service: str, state: str) -> None:
        """Record circuit breaker state (closed=0, open=1, half_open=2)."""
        state_value = {"closed": 0, "open": 1, "half_open": 2}.get(state, -1)
        self._backend.gauge(
            "circuit_breaker_state",
            state_value,
            tags=self._tags({"service": service}),
        )

    def circuit_breaker_opened(self, service: str) -> None:
        """Count circuit breaker opens (failures)."""
        self._backend.increment(
            "circuit_breaker_opens",
            tags=self._tags({"service": service}),
        )
        self._emit_event(
            "mongomem.worker.circuit_breaker.opened",
            attributes={"service": service},
            level="warning",
        )

    def circuit_breaker_rejected(self, service: str) -> None:
        """Count calls rejected due to open circuit."""
        self._backend.increment(
            "circuit_breaker_rejected",
            tags=self._tags({"service": service}),
        )
        self._emit_event(
            "mongomem.worker.circuit_breaker.rejected",
            attributes={"service": service},
            level="warning",
        )

    @contextmanager
    def track_task_duration(self, task_type: str):
        """Context manager to track task duration."""
        start = time.perf_counter()
        try:
            yield
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            self.task_completed(task_type, duration_ms)


# Example implementations for common backends


class PrometheusObservabilityExample:
    """
    Example Prometheus implementation.

    To use:
    ```python
    from prometheus_client import Counter, Gauge, Histogram

    class PrometheusObservability:
        def __init__(self):
            self.counters = {}
            self.gauges = {}
            self.histograms = {}

        def increment(self, name, value=1.0, tags=None):
            key = (name, tuple(sorted(tags.items())) if tags else ())
            if key not in self.counters:
                self.counters[key] = Counter(name, name, list(tags.keys()) if tags else [])
            self.counters[key].labels(**tags).inc(value)

        # ... similar for gauge, histogram, timing, span, event
    ```
    """

    pass


class DataDogObservabilityExample:
    """
    Example DataDog implementation.

    To use:
    ```python
    from datadog import statsd

    class DataDogObservability:
        def increment(self, name, value=1.0, tags=None):
            dd_tags = [f"{k}:{v}" for k, v in (tags or {}).items()]
            statsd.increment(name, value, tags=dd_tags)

        def gauge(self, name, value, tags=None):
            dd_tags = [f"{k}:{v}" for k, v in (tags or {}).items()]
            statsd.gauge(name, value, tags=dd_tags)

        # ... similar for histogram, timing, span, event
    ```
    """

    pass


__all__ = [
    # Re-exported from core
    "ObservabilityProtocol",
    "LoggingObservability",
    "NoOpObservability",
    # Worker-specific
    "WorkerObservability",
]
