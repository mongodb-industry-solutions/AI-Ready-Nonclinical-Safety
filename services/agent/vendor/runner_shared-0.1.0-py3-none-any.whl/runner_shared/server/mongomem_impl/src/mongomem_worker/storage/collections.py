"""
Collection descriptors for ``mongomem_worker``.

This module defines structural descriptors for **worker / task-queue**
collections only.  Engine-domain collections live in
``mongomem_core.storage.collections`` and are intentionally excluded here.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping

from pymongo.synchronous.collection import Collection
from pymongo.synchronous.database import Database


@dataclass(frozen=True)
class BaseCollectionDescriptor:
    """
    Minimal descriptor for a MongoDB collection used by the worker.

    We keep the same shape as the core engine's ``BaseCollectionDescriptor``
    but define it locally to avoid a hard dependency cycle between the two
    packages.
    """

    #: Canonical collection name in MongoDB.
    name: str

    def get(self, db: Database) -> Collection:
        """Return the underlying ``Collection`` from a ``Database``."""

        return db[self.name]


class TasksCollection(BaseCollectionDescriptor):
    """Primary task queue backing collection (``tasks``)."""

    def __init__(self) -> None:
        super().__init__(name="tasks")


class TasksDlqCollection(BaseCollectionDescriptor):
    """Dead-letter queue collection for failed tasks (``tasks_dlq``)."""

    def __init__(self) -> None:
        super().__init__(name="tasks_dlq")


class WorkerStateCollection(BaseCollectionDescriptor):
    """Worker lifecycle / heartbeat state (``worker_state``)."""

    def __init__(self) -> None:
        super().__init__(name="worker_state")


class ChangeStreamStateCollection(BaseCollectionDescriptor):
    """Change stream resume token persistence (``change_stream_state``)."""

    def __init__(self) -> None:
        super().__init__(name="change_stream_state")


class ScheduledTasksCollection(BaseCollectionDescriptor):
    """Simplified scheduled tasks collection (``scheduled_tasks``)."""

    def __init__(self) -> None:
        super().__init__(name="scheduled_tasks")


class ExtractionConfigCollection(BaseCollectionDescriptor):
    """
    Versioned extraction configuration (prompts, models).

    Stores extraction prompts with version history, enabling:
    - Hot-reload without worker restart
    - Per-org customization
    - Rollback capability
    """

    def __init__(self) -> None:
        super().__init__(name="extraction_config")


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


WORKER_COLLECTIONS: Mapping[str, BaseCollectionDescriptor] = {
    desc.name: desc
    for desc in [
        TasksCollection(),
        TasksDlqCollection(),
        WorkerStateCollection(),
        ChangeStreamStateCollection(),
        ScheduledTasksCollection(),
        ExtractionConfigCollection(),
    ]
}


def iter_worker_collections() -> Iterable[BaseCollectionDescriptor]:
    """Iterate over all worker-domain collections."""

    return WORKER_COLLECTIONS.values()
