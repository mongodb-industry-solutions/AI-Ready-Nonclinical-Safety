"""
Memory operating modes for mongomem_core.

Defines how the engine manages conversation context:
- TRADITIONAL: Accumulate STM turns, snapshot consolidation
- IWM: Internal Working Memory, model-authored belief state
- HYBRID: Both (for migration, debugging, evals)
"""

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    pass


class MemoryMode(str, Enum):
    """
    Memory operating mode.

    TRADITIONAL:
        - write_turn() accumulates STM history
        - build_context() returns STM + snapshots + LTM
        - Prompt size grows with conversation length

    IWM (Internal Working Memory):
        - update_internal_state() overwrites IS each turn
        - build_context() returns IS + LTM only
        - Prompt size stays constant (~500 tokens IS + LTM budget)

    HYBRID:
        - Both write_turn() and update_internal_state() available
        - build_context() returns IS + STM + LTM
        - For migration, debugging, evals
    """

    TRADITIONAL = "traditional"
    IWM = "iwm"
    HYBRID = "hybrid"

    @property
    def uses_stm(self) -> bool:
        """Mode uses short-term memory accumulation."""
        return self in (MemoryMode.TRADITIONAL, MemoryMode.HYBRID)

    @property
    def uses_internal_state(self) -> bool:
        """Mode uses Internal Working Memory."""
        return self in (MemoryMode.IWM, MemoryMode.HYBRID)

    @property
    def requires_is_for_context(self) -> bool:
        """Mode requires IS as primary context source."""
        return self == MemoryMode.IWM


def require_mode(
    current: MemoryMode,
    allowed: List[MemoryMode],
    method: str,
) -> None:
    """
    Raise ModeError if current mode is not in allowed list.

    Args:
        current: The engine's current mode
        allowed: List of modes that allow this operation
        method: Name of the method being called (for error message)

    Raises:
        ModeError: If current mode is not in allowed list

    Example:
        require_mode(self._mode, [MemoryMode.IWM, MemoryMode.HYBRID], "update_internal_state")
    """
    if current not in allowed:
        from mongomem_core.exceptions import ModeError

        raise ModeError(
            f"{method}() is not available in {current.value} mode",
            current_mode=current,
            required_modes=allowed,
            method=method,
        )


__all__ = ["MemoryMode", "require_mode"]
