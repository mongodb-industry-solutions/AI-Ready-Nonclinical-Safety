"""
Document extractors for the ingestion pipeline.

Extractors read text content from various file formats.
"""

from mongomem_core.ingest.extractors.base import DocumentExtractor
from mongomem_core.ingest.extractors.docx import PythonDocxExtractor
from mongomem_core.ingest.extractors.pdf import PyMuPDFExtractor
from mongomem_core.ingest.extractors.pptx import PythonPPTXExtractor
from mongomem_core.ingest.extractors.text import PlainTextExtractor

__all__ = [
    "DocumentExtractor",
    "PlainTextExtractor",
    "PyMuPDFExtractor",
    "PythonPPTXExtractor",
    "PythonDocxExtractor",
]
