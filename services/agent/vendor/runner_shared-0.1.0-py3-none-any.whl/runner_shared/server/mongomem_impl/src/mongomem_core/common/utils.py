"""Utility functions for the mongomem_core package."""

from __future__ import annotations

import logging
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Generator, List, NoReturn, Optional, Tuple, Union

from bson import ObjectId
from bson.errors import InvalidId
from mongomem_core.exceptions import (
    DatabaseOperationError,
    DuplicateDocumentError,
    ValidationError,
)
from pymongo.errors import DuplicateKeyError, PyMongoError

logger = logging.getLogger(__name__)


def utcnow() -> datetime:
    """Return current UTC datetime."""
    return datetime.now(timezone.utc)


def cosine_similarity(vec_a: List[float], vec_b: List[float]) -> float:
    """
    Calculate cosine similarity between two embedding vectors.

    Uses pure Python for portability. Formula:
    cosine_similarity = dot(a, b) / (norm(a) * norm(b))

    Args:
        vec_a: First embedding vector
        vec_b: Second embedding vector

    Returns:
        Cosine similarity score between -1.0 and 1.0
        (typically 0.0-1.0 for normalized embeddings)

    Raises:
        ValueError: If vectors have different dimensions or are empty
    """
    if not vec_a or not vec_b:
        raise ValueError("Vectors cannot be empty")
    if len(vec_a) != len(vec_b):
        raise ValueError(f"Vector dimensions must match: {len(vec_a)} vs {len(vec_b)}")

    dot_product: float = sum(a * b for a, b in zip(vec_a, vec_b))
    norm_a: float = sum(a * a for a in vec_a) ** 0.5
    norm_b: float = sum(b * b for b in vec_b) ** 0.5

    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0

    return float(dot_product / (norm_a * norm_b))


def to_object_id(doc_id: Union[str, ObjectId]) -> ObjectId:
    """
    Convert a string or ObjectId to ObjectId, with validation.

    Args:
        doc_id: Document ID as string or ObjectId

    Returns:
        ObjectId instance

    Raises:
        ValidationError: If the string is not a valid ObjectId.
    """
    if isinstance(doc_id, ObjectId):
        return doc_id
    try:
        return ObjectId(doc_id)
    except InvalidId as exc:
        raise ValidationError(
            f"Invalid document ID format: {doc_id}",
            field="doc_id",
            value=doc_id,
        ) from exc


def safe_object_id(
    doc_id: Optional[str],
    operation: str = "",
) -> Optional[ObjectId]:
    """
    Convert a string to ObjectId, returning None on failure instead of raising.

    This is a safe variant of to_object_id() for use in persistence operations
    where invalid IDs should be logged and skipped rather than causing exceptions.

    Args:
        doc_id: Document ID as string (or None)
        operation: Operation name for logging context (e.g., "REINFORCE", "UPDATE")

    Returns:
        ObjectId if conversion succeeds, None if doc_id is None or invalid

    Example:
        >>> query_id = safe_object_id(existing_id, "REINFORCE")
        >>> if not query_id:
        ...     return None  # Skip this operation
    """
    if not doc_id:
        if operation:
            logger.warning("%s: missing document ID", operation)
        return None

    try:
        return ObjectId(doc_id)
    except (InvalidId, TypeError) as e:
        logger.warning(
            "%s: invalid ObjectId format: %s - %s",
            operation or "ObjectId conversion",
            doc_id,
            e,
        )
        return None


def format_document_identifier(
    *,
    id: Optional[Union[str, ObjectId]] = None,
    **kwargs: Any,
) -> str:
    """
    Format a document identifier string for logging and error messages.

    This utility provides consistent formatting of document identifiers across
    the codebase. If an ID is provided, it returns "id={id}". Otherwise, it
    formats all non-None keyword arguments as "key=value" pairs.

    Args:
        id: Optional document ID (takes precedence if provided)
        **kwargs: Additional identifier fields (e.g., label, session_id, snapshot_ref_id)

    Returns:
        Formatted identifier string (e.g., "id=123" or "label=xyz" or "session=sess_123 snapshot=snap_456")
    """
    if id is not None:
        return f"id={id}"
    parts = [f"{k}={v}" for k, v in kwargs.items() if v is not None]
    return " ".join(parts)


@contextmanager
def handle_db_error(
    operation: str,
    collection: str,
    log_message: str,
    *,
    log_args_tuple: Tuple[Any, ...] | None = None,
    **details: Any,
) -> Generator[None, None, None]:
    """
    Context manager for consistent MongoDB error handling.

    Catches PyMongoError exceptions, logs them, and re-raises as
    DatabaseOperationError with consistent structure.

    Note: DuplicateKeyError is NOT caught by this context manager.
    Use handle_duplicate_key_error() for explicit duplicate handling.

    Args:
        operation: The MongoDB operation name (e.g., "find_one", "insert_one")
        collection: The collection name being operated on
        log_message: Format string for log message (supports % formatting)
        log_args_tuple: Tuple of arguments for log message formatting
        **details: Additional context to include in the error details

    Yields:
        None

    Raises:
        DatabaseOperationError: When a PyMongoError (except DuplicateKeyError) is caught.
        DuplicateKeyError: Re-raised as-is for explicit handling by caller.
    """
    try:
        yield
    except DuplicateKeyError:
        # Let DuplicateKeyError pass through for explicit handling
        raise
    except PyMongoError as exc:
        if log_args_tuple:
            formatted_message = log_message % log_args_tuple
        else:
            formatted_message = log_message
        logger.exception(formatted_message)
        raise DatabaseOperationError(
            formatted_message,
            operation=operation,
            collection=collection,
            original_error=exc,
            details=details,
        ) from exc


def handle_duplicate_key_error(
    exc: DuplicateKeyError,
    *,
    collection_name: str,
    operation: str = "insert_one",
    log_message: str,
    log_args: Optional[Tuple] = None,
    details: Optional[dict[str, Any]] = None,
) -> NoReturn:
    """
    Convert a PyMongo DuplicateKeyError to a DuplicateDocumentError.

    This utility provides consistent error handling for duplicate key violations
    across all memory types. It logs a warning and raises a DuplicateDocumentError
    with appropriate context.

    This is a companion utility to ``handle_db_error()``, specifically for
    handling duplicate key violations which are a common case that deserves
    special treatment.

    Args:
        exc: The DuplicateKeyError from PyMongo
        collection_name: Name of the collection where the duplicate occurred
        operation: Name of the operation (default: "insert_one")
        log_message: Log message format string (e.g., "Duplicate document: %s")
        log_args: Arguments for the log message format string
        details: Additional details to include in the error

    Raises:
        DuplicateDocumentError: Always raises this exception with context

    Example:
        >>> try:
        ...     col.insert_one(doc)
        ... except DuplicateKeyError as exc:
        ...     handle_duplicate_key_error(
        ...         exc,
        ...         collection_name="episodic",
        ...         log_message="Duplicate episodic: session=%s org=%s",
        ...         log_args=(session_id, org_id),
        ...         details={"session_id": session_id, "org_id": org_id},
        ...     )
    """
    logger.warning(log_message, *(log_args or ()))
    raise DuplicateDocumentError(
        "Duplicate document: uniqueness constraint violated",
        operation=operation,
        collection=collection_name,
        original_error=exc,
        details=details or {},
    ) from exc
