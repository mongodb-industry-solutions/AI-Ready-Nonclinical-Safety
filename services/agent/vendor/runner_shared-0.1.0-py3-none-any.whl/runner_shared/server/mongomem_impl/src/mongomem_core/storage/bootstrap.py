"""
Bootstrap helpers for ``mongomem_core`` storage.

This module is the integration point between the **structural descriptors**
defined in:

* ``storage.collections`` (engine-domain collection names), and
* ``storage.indexes`` (engine-domain B-tree index definitions),

and a **real MongoDB database**.  It provides small, framework-agnostic
functions that can be called at process startup to ensure that collections and
their indexes exist.

Design constraints:

* Engine-only: auth / security and worker / task-queue collections are
  intentionally out of scope here.
* Idempotent: helpers are safe to run multiple times.
* Minimal behaviour: no schema validators or collMod logic; those belong in
  migrations or higher layers.
* Mode-aware: can create minimum required collections for a given MemoryMode,
  but defaults to creating all collections for operational flexibility.
"""

from __future__ import annotations

import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import TYPE_CHECKING, Iterable, List, Optional, Set

from mongomem_core.config import Settings
from mongomem_core.exceptions import DatabaseOperationError
from pymongo.collection import Collection
from pymongo.errors import OperationFailure, PyMongoError
from pymongo.operations import IndexModel, SearchIndexModel
from pymongo.synchronous.database import Database

from .collections import BaseCollectionDescriptor, iter_engine_collections
from .indexes import CollectionIndexes, IndexDefinition, iter_engine_indexes
from .search_indexes import SearchIndexDefinition, iter_engine_search_indexes

if TYPE_CHECKING:
    from mongomem_core.modes import MemoryMode

logger = logging.getLogger(__name__)


# =============================================================================
# Mode-aware collection requirements
# =============================================================================


# Collections required per mode
# Note: This is "minimum required", not "only allowed"
# Bootstrap with create_all=True (default) creates ALL collections for flexibility
COLLECTIONS_FOR_MODE: dict[str, Set[str]] = {
    "traditional": {
        "memory_short_term",
        "memory_snapshot",
        "memory_semantic",
        "memory_episodic",
        "session_counters",
    },
    "iwm": {
        "internal_state",
        "memory_semantic",
        "memory_episodic",
    },
    "hybrid": {
        "internal_state",
        "memory_short_term",
        "memory_snapshot",
        "memory_semantic",
        "memory_episodic",
        "session_counters",
    },
}


def get_collections_for_mode(mode: "MemoryMode") -> Set[str]:
    """
    Get the minimum required collections for a given mode.

    Args:
        mode: Memory operating mode

    Returns:
        Set of collection names required for this mode
    """
    return COLLECTIONS_FOR_MODE.get(mode.value, set())


def _iter_collection_descriptors() -> Iterable[BaseCollectionDescriptor]:
    """Internal helper to allow patching in tests."""

    return iter_engine_collections()


def _iter_collection_indexes() -> Iterable[CollectionIndexes]:
    """Internal helper to allow patching in tests."""

    return iter_engine_indexes()


def _iter_search_indexes() -> Iterable[SearchIndexDefinition]:
    """Internal helper to allow patching in tests."""

    return iter_engine_search_indexes()


def _is_existing_search_index_error(exc: OperationFailure) -> bool:
    """
    Detect Atlas Search create races that are safe to treat as idempotent.

    Atlas currently reports duplicate-name search-index creates as a generic
    ``BadValue`` OperationFailure (code=2), so there is not a search-index-
    specific code we can rely on by itself. Tighten the match by requiring the
    generic envelope *and* the specific duplicate-name errmsg we observed.
    """
    details = exc.details if isinstance(exc.details, dict) else {}
    code = details.get("code", getattr(exc, "code", None))
    code_name = details.get("codeName")
    message = str(details.get("errmsg") or exc).lower()

    if code != 2 or code_name != "BadValue":
        return False

    return "duplicate index names for the same collection" in message


def ensure_engine_collections(
    db: Database,
    *,
    mode: Optional["MemoryMode"] = None,
    create_all: bool = True,
) -> None:
    """
    Ensure that engine-domain collections are addressable in ``db``.

    This function walks the collection descriptors from ``storage.collections``
    and obtains a handle for each collection via ``db[name]``. MongoDB
    materialises collections lazily on first write, so we intentionally avoid
    calling ``create_collection`` here; the goal is to guarantee a consistent
    naming surface, not to enforce schema.

    Args:
        db: MongoDB database instance.
        mode: Optional memory mode. If provided with create_all=False, only
            collections required for that mode are ensured.
        create_all: If True (default), ensure ALL collections regardless of
            mode. This is recommended for production as it allows mode
            switching without migration. Set to False only for minimal
            test/dev setups.

    Note:
        Bootstrap is idempotent and safe to call multiple times. Mode-aware
        bootstrap means "minimum required", not "only allowed". Existing
        collections are never dropped.
    """
    required_collections: Optional[Set[str]] = None
    if not create_all and mode is not None:
        required_collections = get_collections_for_mode(mode)
        logger.debug(
            "Mode-aware bootstrap: ensuring %d collections for mode=%s",
            len(required_collections),
            mode.value,
        )

    for desc in _iter_collection_descriptors():
        # If mode filtering is active, skip collections not required
        if required_collections is not None and desc.name not in required_collections:
            logger.debug(
                "Skipping collection %s (not required for mode=%s)",
                desc.name,
                mode.value if mode else "none",
            )
            continue

        _ = desc.get(db)
        logger.debug("Ensured collection handle for %s", desc.name)


_INDEX_NOT_FOUND_ERROR_CODE = 27


def _drop_conflicting_indexes(
    col: Collection,
    collection_name: str,
    desired_indexes: Iterable["IndexDefinition"],
    existing_indexes: list,
    existing_names: set,
) -> None:
    """
    Drop existing indexes whose key pattern conflicts with a desired index
    under a different name.

    MongoDB rejects creating an index when the same key pattern already exists
    under a different name (``IndexOptionsConflict``, code 85).  This can
    happen when an external service (e.g. the OE's STM direct-write path)
    previously created an equivalent index with a non-canonical name.
    """
    existing_by_keys: dict[tuple, str] = {}
    for idx in existing_indexes:
        name = idx.get("name", "")
        if name == "_id_":
            continue
        key_tuple = tuple(idx.get("key", {}).items())
        existing_by_keys[key_tuple] = name

    desired_names = {idx.name for idx in desired_indexes}

    for index in desired_indexes:
        if index.name in existing_names:
            continue
        key_tuple = tuple(index.keys)
        conflicting_name = existing_by_keys.get(key_tuple)
        if conflicting_name is None or conflicting_name in desired_names:
            continue
        logger.warning(
            "Dropping legacy index %s on collection %s (key conflict with canonical %s)",
            conflicting_name,
            collection_name,
            index.name,
        )
        try:
            col.drop_index(conflicting_name)
        except OperationFailure as exc:
            if getattr(exc, "code", None) == _INDEX_NOT_FOUND_ERROR_CODE:
                logger.debug(
                    "Index %s already dropped on %s (race), continuing",
                    conflicting_name,
                    collection_name,
                )
            else:
                raise
        existing_names.discard(conflicting_name)


def ensure_engine_indexes(db: Database) -> None:
    """
    Ensure B-tree indexes for all engine-domain collections exist.

    This walks the structural index descriptors from ``storage.indexes`` and
    creates indexes in batches per collection for better performance. MongoDB's
    index creation is idempotent as long as the index specification matches;
    if it does not, the driver will raise and the error will bubble up after
    being logged.

    Before creating new indexes, any existing index whose key pattern matches
    a desired index but under a different name is dropped to avoid
    ``IndexOptionsConflict`` (code 85).

    Optimizations:
    - Batch checks existing indexes first to avoid unnecessary creation attempts
    - Uses create_indexes() to create multiple indexes at once per collection
    - This significantly reduces round-trips to the database
    """

    for ci in _iter_collection_indexes():
        col = db[ci.collection_name]

        try:
            existing_indexes = list(col.list_indexes())
            existing_names = {idx.get("name") for idx in existing_indexes if idx.get("name")}
        except PyMongoError:
            logger.exception(
                "Failed to list existing indexes for collection %s",
                ci.collection_name,
            )
            raise

        _drop_conflicting_indexes(
            col,
            ci.collection_name,
            ci.indexes,
            existing_indexes,
            existing_names,
        )

        indexes_to_create = []
        for index in ci.indexes:
            if index.name in existing_names:
                logger.debug(
                    "Index %s on collection %s already exists; skipping",
                    index.name,
                    ci.collection_name,
                )
                continue

            kwargs = index.to_create_index_kwargs()
            # Create IndexModel for batch creation.
            index_model = IndexModel(index.keys, **kwargs)
            indexes_to_create.append(index_model)

        # Batch create all indexes for this collection at once.
        if indexes_to_create:
            try:
                col.create_indexes(indexes_to_create)
                created_names = [idx.name for idx in ci.indexes if idx.name not in existing_names]
                logger.info(
                    "Created %d indexes on collection %s: %s",
                    len(indexes_to_create),
                    ci.collection_name,
                    ", ".join(created_names),
                )
            except PyMongoError:
                logger.exception(
                    "Failed to create indexes on collection %s",
                    ci.collection_name,
                )
                raise


def _wait_for_index_ready(
    col: Collection,
    index_name: str,
    max_wait_seconds: int = 300,
    poll_interval_seconds: float = 2.0,
) -> None:
    """
    Wait for a search index to become ready.

    Polls the index status until it's "ready" or timeout is reached.

    Args:
        col: MongoDB collection instance
        index_name: Name of the index to wait for
        max_wait_seconds: Maximum time to wait (default: 300)
        poll_interval_seconds: Interval between status checks (default: 2.0)

    Raises:
        DatabaseOperationError: If index status is "failed" or "error"
        TimeoutError: If index doesn't become ready within max_wait_seconds
    """
    start_time = time.time()
    logger.debug("Waiting for search index %s to be ready", index_name)
    consecutive_errors = 0

    while True:
        elapsed = time.time() - start_time
        if elapsed >= max_wait_seconds:
            raise TimeoutError(
                f"Search index {index_name} did not become ready within {max_wait_seconds} seconds"
            )

        try:
            indexes = list(col.list_search_indexes())
            consecutive_errors = 0
            for idx in indexes:
                if idx.get("name") == index_name:
                    status = idx.get("status", "unknown")
                    if status == "ready":
                        logger.info(
                            "Search index %s is ready (waited %.1fs)",
                            index_name,
                            elapsed,
                        )
                        return
                    elif status in ("failed", "error"):
                        error_msg = f"Search index {index_name} has status {status}"
                        logger.error(error_msg)
                        raise DatabaseOperationError(
                            error_msg,
                            operation="ensure_search_index",
                            collection=col.name,
                            details={"index_name": index_name, "status": status},
                        )
                    else:
                        logger.debug(
                            "Search index %s status: %s (elapsed %.1fs)",
                            index_name,
                            status,
                            elapsed,
                        )
                        break
            else:
                # Index not found in list - might still be initializing
                logger.debug(
                    "Search index %s not yet in list (elapsed %.1fs)",
                    index_name,
                    elapsed,
                )
        except (OperationFailure, PyMongoError) as exc:
            consecutive_errors += 1
            error_str = str(exc).lower()
            is_transient = any(
                pattern in error_str
                for pattern in ["timeout", "network", "connection", "temporary"]
            )

            if not is_transient:
                logger.error(
                    "Non-transient error checking index status for %s: %s",
                    index_name,
                    exc,
                )
                raise DatabaseOperationError(
                    f"Failed to check index status: {exc}",
                    operation="ensure_search_index",
                    collection=col.name,
                    original_error=exc,
                    details={"index_name": index_name},
                ) from exc

            logger.warning(
                "Transient error checking index status for %s (consecutive errors: %d): %s",
                index_name,
                consecutive_errors,
                exc,
            )

        time.sleep(poll_interval_seconds)


def ensure_engine_search_indexes(
    db: Database,
    settings: Optional[Settings] = None,
    *,
    wait_for_ready: bool = True,
    max_wait_seconds: int = 300,
    poll_interval_seconds: float = 2.0,
) -> None:
    """
    Ensure Atlas Search / vector indexes for engine-domain collections exist.

    The concrete index definitions live in ``storage.search_indexes`` as
    :class:`SearchIndexDefinition` instances. This helper translates each
    definition into a :class:`SearchIndexModel` and applies it via
    ``Collection.create_search_index``.

    Vector indexes will use ``settings.embedding_dimension`` to override
    the default ``numDimensions`` value.

    For now we implement a conservative behaviour:

    * If an index with the same name already exists, we log and skip creation.
    * We do **not** attempt to drop or mutate existing search indexes –
      dimension / mapping drift should be handled by an explicit migrations
      layer.

    Optimizations:
    - Creates indexes in parallel across collections using threads
    - If wait_for_ready is True, waits for all indexes in parallel using threads
    - This significantly reduces total bootstrap time compared to sequential creation

    Args:
        db: MongoDB database instance.
        settings: Engine settings. If None, defaults are loaded from environment.
        wait_for_ready: If True, wait for newly created indexes to be ready
            before returning. This ensures indexes are queryable immediately after
            bootstrap. Defaults to True for seamless user experience.
        max_wait_seconds: Maximum time to wait for indexes to be ready (default: 300).
        poll_interval_seconds: Interval between status checks in seconds (default: 2.0).

    Raises:
        PyMongoError: If index creation fails.
        TimeoutError: If wait_for_ready is True and indexes don't become ready
            within max_wait_seconds.
    """
    if settings is None:
        settings = Settings()

    embedding_dimension = settings.embedding_dimension
    logger.debug("Ensuring search indexes with embedding_dimension=%d", embedding_dimension)

    # Group indexes by collection to avoid N+1: call list_search_indexes() once per collection
    indexes_by_collection: dict[str, list[SearchIndexDefinition]] = {}
    for idx in _iter_search_indexes():
        indexes_by_collection.setdefault(idx.collection_name, []).append(idx)

    indexes_to_wait: list[tuple[Collection, str]] = []

    # Phase 1: Create all indexes in parallel across collections (using ThreadPoolExecutor)
    def create_indexes_for_collection(
        collection_name: str, indexes: list[SearchIndexDefinition]
    ) -> tuple[str, list[tuple[Collection, str]], Optional[Exception]]:
        """
        Create indexes for a single collection, returning created indexes for waiting.

        Returns: (collection_name, list of (col, index_name) tuples, error)
        """
        col = db[collection_name]
        created_indexes: list[tuple[Collection, str]] = []

        try:
            existing_indexes = list(col.list_search_indexes())
            existing_names = {i.get("name") for i in existing_indexes}
        except OperationFailure as exc:
            # Atlas Search may not be available (e.g., local MongoDB)
            if "CommandNotSupported" in str(exc) or "not supported" in str(exc).lower():
                logger.warning(
                    "Atlas Search not supported for collection %s; skipping search indexes",
                    collection_name,
                )
                return (collection_name, [], None)
            logger.exception(
                "Unable to list search indexes for collection %s",
                collection_name,
            )
            return (collection_name, [], exc)
        except PyMongoError as exc:
            logger.exception(
                "MongoDB error listing search indexes for collection %s",
                collection_name,
            )
            return (collection_name, [], exc)

        for idx in indexes:
            if idx.name in existing_names:
                logger.info(
                    "Search index %s on collection %s already exists; skipping",
                    idx.name,
                    collection_name,
                )
                continue

            try:
                kwargs = idx.to_model_kwargs(embedding_dimension=embedding_dimension)

                model = SearchIndexModel(**kwargs)
                col.create_search_index(model=model)
                logger.info(
                    "Created search index %s on collection %s",
                    idx.name,
                    collection_name,
                )

                # Track for parallel waiting later
                if wait_for_ready:
                    created_indexes.append((col, idx.name))
            except OperationFailure as exc:
                if _is_existing_search_index_error(exc):
                    logger.info(
                        "Search index %s on collection %s already exists (server): %s",
                        idx.name,
                        collection_name,
                        exc,
                    )
                    continue
                logger.exception(
                    "Failed to ensure search index %s on collection %s",
                    idx.name,
                    collection_name,
                )
                return (collection_name, created_indexes, exc)
            except PyMongoError as exc:
                logger.exception(
                    "Unexpected error while ensuring search index %s on collection %s",
                    idx.name,
                    collection_name,
                )
                return (collection_name, created_indexes, exc)

        return (collection_name, created_indexes, None)

    # Create indexes in parallel across collections
    with ThreadPoolExecutor(max_workers=min(len(indexes_by_collection), 10)) as executor:
        futures = {
            executor.submit(create_indexes_for_collection, col_name, idxs): col_name
            for col_name, idxs in indexes_by_collection.items()
        }

        errors = []
        for future in as_completed(futures):
            col_name, created, error = future.result()
            if error:
                errors.append((col_name, error))
            else:
                indexes_to_wait.extend(created)

        if errors:
            # Raise the first error with context about all failures
            error_msg = f"Failed to create search indexes for {len(errors)} collection(s)"
            raise DatabaseOperationError(
                error_msg,
                operation="ensure_search_index",
                details={
                    "failed_collections": [
                        {"collection": col, "error": str(err)} for col, err in errors
                    ]
                },
            )

    # Phase 2: Wait for all indexes in parallel if requested (using ThreadPoolExecutor)
    if wait_for_ready and indexes_to_wait:
        logger.info(
            "Waiting for %d search indexes to become ready (parallel)",
            len(indexes_to_wait),
        )

        def wait_for_one(col: Collection, index_name: str) -> tuple[str, str, Optional[Exception]]:
            """Wait for a single index, returning (collection_name, index_name, error)."""
            try:
                _wait_for_index_ready(
                    col=col,
                    index_name=index_name,
                    max_wait_seconds=max_wait_seconds,
                    poll_interval_seconds=poll_interval_seconds,
                )
                return (col.name, index_name, None)
            except Exception as exc:
                return (col.name, index_name, exc)

        with ThreadPoolExecutor(max_workers=min(len(indexes_to_wait), 10)) as wait_executor:
            wait_futures_map = {
                wait_executor.submit(wait_for_one, col, idx_name): (col, idx_name)
                for col, idx_name in indexes_to_wait
            }

            wait_errors: List[tuple[str, str, Exception]] = []
            for wait_future in as_completed(wait_futures_map):
                wait_result = wait_future.result()
                col_name, idx_name, error = wait_result
                if error:
                    wait_errors.append((col_name, idx_name, error))
                    logger.error(
                        "Failed to wait for search index %s on collection %s: %s",
                        idx_name,
                        col_name,
                        error,
                    )

            if wait_errors:
                # Raise the first error with context about all failures
                error_msg = f"Failed to wait for {len(wait_errors)} search indexes"
                raise DatabaseOperationError(
                    error_msg,
                    operation="ensure_search_index",
                    details={
                        "failed_indexes": [
                            {"collection": col, "index": idx, "error": str(err)}
                            for col, idx, err in wait_errors
                        ]
                    },
                )

        logger.info("All search indexes are ready")
