"""
Error classification for retry decisions and metrics.

Provides:
- ErrorType: Permanent, Transient, Unknown
- ErrorTaxonomy: Detailed categories for debugging
- Functions for classification and retry logic
"""

from __future__ import annotations

import re
from enum import Enum
from typing import Union

# Import typed exceptions for classification
from .exceptions import (
    ConfigurationError,
    DatabaseError,
    DocumentMissingError,
    EmbedderConfigError,
    EmbeddingError,
    HandlerNotFoundError,
    InvalidPayloadError,
    LeaseExpiredError,
    LLMError,
    RateLimitError,
    WorkerError,
    WorkerErrorSeverity,
)
from .exceptions import (
    TimeoutError as WorkerTimeoutError,
)


class ErrorType(str, Enum):
    """Classification of error types for retry decisions."""

    PERMANENT = "permanent"  # Don't retry - bad data, validation, etc.
    TRANSIENT = "transient"  # Retry - network, timeout, rate limit, etc.
    UNKNOWN = "unknown"  # Default - retry with caution

    @classmethod
    def from_severity(cls, severity: WorkerErrorSeverity) -> "ErrorType":
        """Convert WorkerErrorSeverity to ErrorType."""
        return cls(severity.value)


class ErrorTaxonomy(str, Enum):
    """Detailed error categories for metrics and debugging."""

    # Permanent errors
    VALIDATION = "validation"
    NOT_FOUND = "not_found"
    PERMISSION = "permission"
    BAD_REQUEST = "bad_request"
    CONFIG = "config"
    NO_HANDLER = "no_handler"

    # Transient errors
    TIMEOUT = "timeout"
    RATE_LIMIT = "rate_limit"
    CONNECTION = "connection"
    SERVICE_UNAVAILABLE = "service_unavailable"
    DATABASE = "database"
    EMBEDDING = "embedding"
    LLM = "llm"
    LEASE_EXPIRED = "lease_expired"

    # Unknown
    INTERNAL = "internal"
    UNKNOWN = "unknown"


# Patterns for classifying errors
PERMANENT_PATTERNS = [
    r"validation.*error",
    r"invalid.*input",
    r"not\s+found",
    r"does\s+not\s+exist",
    r"permission\s+denied",
    r"unauthorized",
    r"forbidden",
    r"bad\s+request",
    r"missing\s+required",
    r"malformed",
    r"schema.*error",
    r"type\s+error",
    r"value\s+error",
    r"duplicate\s+key",  # MongoDB duplicate key errors
    r"e11000",  # MongoDB duplicate key error code
    r"no\s+handler",  # Task handler not registered (config issue)
]

TRANSIENT_PATTERNS = [
    r"timeout",
    r"timed?\s*out",
    r"rate\s*limit",
    r"too\s+many\s+requests",
    r"429",
    r"connection.*refused",
    r"connection.*reset",
    r"connection.*error",
    r"connection",  # Generic connection issues
    r"network",  # Generic network issues
    r"unreachable",  # Network unreachable
    r"service.*unavailable",
    r"503",
    r"502",
    r"504",
    r"temporarily.*unavailable",
    r"retry.*later",
    r"server.*error",
    r"internal.*error",
    r"500",
]


def classify_error(error: Union[str, Exception]) -> ErrorType:
    """
    Classify an error as permanent, transient, or unknown.

    Permanent errors should not be retried (bad data, validation).
    Transient errors should be retried (network, timeout, rate limit).

    Uses typed exceptions when available, falls back to regex for strings.
    """
    # Typed exception: use severity directly
    if isinstance(error, WorkerError):
        return ErrorType.from_severity(error.severity)

    # Core exceptions
    try:
        from ...mongomem_core.exceptions import (
            DocumentNotFoundError,
            DuplicateDocumentError,
            ValidationError,
        )

        if isinstance(error, (ValidationError, DocumentNotFoundError, DuplicateDocumentError)):
            return ErrorType.PERMANENT
    except ImportError:
        pass

    # Common Python exceptions indicating permanent errors
    if isinstance(error, (TypeError, ValueError, KeyError, AttributeError)):
        return ErrorType.PERMANENT

    # Timeout exceptions
    import asyncio

    if isinstance(error, (asyncio.TimeoutError, TimeoutError)):
        return ErrorType.TRANSIENT

    # Connection exceptions
    if isinstance(error, (ConnectionError, OSError)):
        return ErrorType.TRANSIENT

    # PyMongo exceptions
    try:
        from pymongo.errors import (
            AutoReconnect,
            ConnectionFailure,
            DuplicateKeyError,
            NetworkTimeout,
        )

        if isinstance(error, DuplicateKeyError):
            return ErrorType.PERMANENT
        if isinstance(error, (ConnectionFailure, AutoReconnect, NetworkTimeout)):
            return ErrorType.TRANSIENT
    except ImportError:
        pass

    # Fall back to regex for strings or unknown exception types
    error_str = str(error).lower()

    # Check permanent patterns first
    for pattern in PERMANENT_PATTERNS:
        if re.search(pattern, error_str, re.IGNORECASE):
            return ErrorType.PERMANENT

    # Check transient patterns
    for pattern in TRANSIENT_PATTERNS:
        if re.search(pattern, error_str, re.IGNORECASE):
            return ErrorType.TRANSIENT

    # Default to unknown (will retry with caution)
    return ErrorType.UNKNOWN


def get_error_taxonomy(error: Union[str, Exception]) -> ErrorTaxonomy:
    """
    Get detailed error taxonomy for metrics and debugging.

    Uses typed exceptions when available for deterministic classification.
    """
    # Typed worker exceptions - deterministic mapping
    if isinstance(error, ConfigurationError):
        return ErrorTaxonomy.CONFIG
    if isinstance(error, EmbedderConfigError):
        return ErrorTaxonomy.CONFIG
    if isinstance(error, HandlerNotFoundError):
        return ErrorTaxonomy.NO_HANDLER
    if isinstance(error, InvalidPayloadError):
        return ErrorTaxonomy.VALIDATION
    if isinstance(error, DocumentMissingError):
        return ErrorTaxonomy.NOT_FOUND
    if isinstance(error, EmbeddingError):
        return ErrorTaxonomy.EMBEDDING
    if isinstance(error, LLMError):
        return ErrorTaxonomy.LLM
    if isinstance(error, RateLimitError):
        return ErrorTaxonomy.RATE_LIMIT
    if isinstance(error, WorkerTimeoutError):
        return ErrorTaxonomy.TIMEOUT
    if isinstance(error, DatabaseError):
        return ErrorTaxonomy.DATABASE
    if isinstance(error, LeaseExpiredError):
        return ErrorTaxonomy.LEASE_EXPIRED

    # Core exceptions
    try:
        from ...mongomem_core.exceptions import (
            DocumentNotFoundError,
            DuplicateDocumentError,
            ValidationError,
        )

        if isinstance(error, ValidationError):
            return ErrorTaxonomy.VALIDATION
        if isinstance(error, DocumentNotFoundError):
            return ErrorTaxonomy.NOT_FOUND
        if isinstance(error, DuplicateDocumentError):
            return ErrorTaxonomy.DATABASE
    except ImportError:
        pass

    # PyMongo exceptions
    try:
        from pymongo.errors import (
            AutoReconnect,
            ConnectionFailure,
            DuplicateKeyError,
            NetworkTimeout,
        )

        if isinstance(error, DuplicateKeyError):
            return ErrorTaxonomy.DATABASE
        if isinstance(error, (ConnectionFailure, AutoReconnect)):
            return ErrorTaxonomy.CONNECTION
        if isinstance(error, NetworkTimeout):
            return ErrorTaxonomy.TIMEOUT
    except ImportError:
        pass

    # Common Python exceptions
    if isinstance(error, (TypeError, ValueError)):
        return ErrorTaxonomy.VALIDATION

    import asyncio

    if isinstance(error, (asyncio.TimeoutError, TimeoutError)):
        return ErrorTaxonomy.TIMEOUT
    if isinstance(error, ConnectionError):
        return ErrorTaxonomy.CONNECTION

    # Fall back to regex for strings or unknown exception types
    error_str = str(error).lower()

    # Permanent categories
    if re.search(r"validation|invalid|malformed|schema|type\s+error", error_str):
        return ErrorTaxonomy.VALIDATION
    if re.search(r"not\s+found|does\s+not\s+exist", error_str):
        return ErrorTaxonomy.NOT_FOUND
    if re.search(r"permission|unauthorized|forbidden", error_str):
        return ErrorTaxonomy.PERMISSION
    if re.search(r"bad\s+request|missing\s+required", error_str):
        return ErrorTaxonomy.BAD_REQUEST

    # Transient categories
    if re.search(r"timeout|timed?\s*out", error_str):
        return ErrorTaxonomy.TIMEOUT
    if re.search(r"rate\s*limit|too\s+many|429", error_str):
        return ErrorTaxonomy.RATE_LIMIT
    if re.search(r"connection|network|unreachable", error_str):
        return ErrorTaxonomy.CONNECTION
    if re.search(r"unavailable|503|502|504", error_str):
        return ErrorTaxonomy.SERVICE_UNAVAILABLE

    # Domain-specific errors
    if re.search(r"embed|embedding", error_str):
        return ErrorTaxonomy.EMBEDDING
    if re.search(r"llm|model|chat|completion", error_str):
        return ErrorTaxonomy.LLM
    if re.search(r"mongo|pymongo|database|e11000|duplicate\s+key", error_str):
        return ErrorTaxonomy.DATABASE

    # Internal errors
    if re.search(r"internal|500|server.*error", error_str):
        return ErrorTaxonomy.INTERNAL

    return ErrorTaxonomy.UNKNOWN


def should_retry(
    error: str | Exception,
    attempts: int,
    max_retries: int,
) -> bool:
    """
    Determine if a task should be retried based on error type and attempts.
    """
    error_type = classify_error(error)

    # Never retry permanent errors
    if error_type == ErrorType.PERMANENT:
        return False

    # Check retry limit
    if attempts >= max_retries:
        return False

    # Retry transient and unknown errors
    return True


def get_retry_delay(
    error: str | Exception,
    attempts: int,
    base_delay: float = 2.0,
    max_delay: float = 60.0,
    jitter: float = 0.5,
) -> float:
    """
    Calculate retry delay with exponential backoff and jitter.

    Rate limit errors get longer delays.
    """
    import random

    taxonomy = get_error_taxonomy(error)

    # Rate limit errors get longer base delay
    if taxonomy == ErrorTaxonomy.RATE_LIMIT:
        base_delay = 10.0
        max_delay = 120.0

    # Exponential backoff: base * 2^attempts
    # attempts=0 → 1x, attempts=1 → 2x, attempts=2 → 4x
    delay = base_delay * (2**attempts)

    # Cap at max delay
    delay = min(delay, max_delay)

    # Add jitter (0 to jitter * delay)
    delay += random.uniform(0, jitter * delay)

    return float(delay)


__all__ = [
    "ErrorType",
    "ErrorTaxonomy",
    "classify_error",
    "get_error_taxonomy",
    "should_retry",
    "get_retry_delay",
]
