"""
Models for semantic memory documents.

Semantic memory stores user-provided knowledge chunks with embeddings
for vector search. Each document represents a labeled piece of knowledge
that can be retrieved based on semantic similarity.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Union

from bson import ObjectId
from mongomem_core.common.utils import utcnow
from mongomem_core.models.memory.base import (
    BaseMemoryIn,
    ChunkVisibility,
    HasEmbeddings,
)
from mongomem_core.models.memory.publishing import PublishingMetadata
from mongomem_core.models.types import PyObjectId
from pydantic import BaseModel, Field, field_serializer, model_validator


class SemanticIn(BaseMemoryIn, HasEmbeddings):
    """Input model for creating a semantic memory entry."""

    publishing: Optional[PublishingMetadata] = Field(default_factory=PublishingMetadata)

    # Embedding model tracking
    embedding_model_id: Optional[str] = Field(
        default=None,
        description="Model identifier used to generate the embedding",
    )

    # Payload fields
    label: str = Field(..., description="User-assigned identifier for this chunk")
    content: str = Field(..., description="The actual content that was embedded")
    source: Optional[str] = Field(default=None, description="Document source or name of doc")
    contextual_metadata: Optional[Dict[str, Any]] = Field(
        default=None, description="Additional context about the knowledge"
    )

    # Agent attribution fields for collective intelligence
    agent_id: Optional[str] = Field(
        default=None,
        description="Agent ID if this knowledge was extracted via agent-mediated learning",
    )
    extraction_source: Optional[str] = Field(
        default=None,
        description="Source of extraction: 'user_direct', 'agent_mediated', 'agent_collective'",
    )
    collective_metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Metadata for collective intelligence: contributing_users, confidence, patterns",
    )


class SemanticUpdate(BaseModel):
    """Model for partial updates to semantic memory."""

    visibility: Optional[ChunkVisibility] = None
    project_id: Optional[str] = None
    publishing: Optional[PublishingMetadata] = None

    embedding: Optional[List[float]] = None
    embedding_model_id: Optional[str] = None
    content: Optional[str] = None
    source: Optional[str] = None
    contextual_metadata: Optional[Dict[str, Any]] = None

    # Agent attribution fields for updates
    agent_id: Optional[str] = Field(
        default=None,
        description="Agent ID if this knowledge was extracted via agent-mediated learning",
    )
    extraction_source: Optional[str] = Field(
        default=None,
        description="Source of extraction: 'user_direct', 'agent_mediated', 'agent_collective'",
    )
    collective_metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Metadata for collective intelligence: contributing_users, confidence, patterns",
    )


class SemanticBase(SemanticIn):
    """Base model with org/user context, versioning, and extraction metadata.

    Includes org_id, user_id, timestamps, version control, and extraction
    metadata which are typically set by the service layer.
    """

    org_id: str = Field(..., description="Organization/tenant ID")
    user_id: str = Field(..., description="Creator of chunk")
    timestamp: datetime = Field(default_factory=utcnow, description="Creation time")
    updated_at: datetime = Field(default_factory=utcnow, description="Last-modified time")

    version: int = Field(default=1, description="Version number, increments on each update")
    is_latest: bool = Field(default=True, description="Only the latest version has this flag")

    # Memory Lineage Fields
    memory_lineage_id: Optional[str] = Field(
        default=None, description="Shared ID across all versions of this memory"
    )
    previous_version_id: Optional[str] = Field(
        default=None, description="Reference to previous version for audit trail"
    )

    # Memory Reinforcement & Boosting Fields
    reinforcement_count: int = Field(
        default=0,
        ge=0,
        description="Number of times this memory was attempted to be re-created",
    )
    last_reinforced_at: Optional[datetime] = Field(
        default=None, description="Timestamp of the most recent reinforcement"
    )
    reinforcement_history: List[datetime] = Field(
        default_factory=list,
        description="Recent reinforcement timestamps (capped at 50)",
    )

    # Extraction metadata for dual storage and cohort routing
    extraction_id: Optional[str] = Field(
        default=None,
        pattern="^[a-f0-9]{64}$",
        description="SHA-256 hash for idempotent extraction writes",
    )
    extraction_scope: Optional[Literal["user_private", "agent_shared", "org_wide"]] = Field(
        default=None,
        description="Scope of extraction: user_private, agent_shared (cohort), or org_wide",
    )
    contributed_by: Optional[str] = Field(
        default=None,
        description="User ID who contributed this extraction (for cohort analytics)",
    )
    owner_id: Optional[str] = Field(
        default=None,
        description="User ID with permanent access rights to this extraction",
    )
    deleted: bool = Field(
        default=False,
        description="Soft-delete flag for auditability",
    )
    deleted_at: Optional[datetime] = Field(
        default=None,
        description="Timestamp of soft deletion",
    )
    idempotency_key_in: Optional[str] = Field(
        default=None,
        description="Original idempotency key for debugging",
    )

    @model_validator(mode="before")
    @classmethod
    def set_timestamps(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        now = utcnow()
        values.setdefault("timestamp", now)
        values.setdefault("updated_at", now)
        return values

    model_config = {
        "arbitrary_types_allowed": True,
        "from_attributes": True,
        "populate_by_name": True,
        "use_enum_values": True,
    }


class SemanticDB(SemanticBase):
    """Database model with MongoDB _id."""

    id: PyObjectId = Field(default_factory=PyObjectId, alias="_id")

    @field_serializer("id", when_used="json")
    def _serialize_id(self, v: ObjectId) -> str:
        return str(v)


class SemanticOut(SemanticBase):
    """Output model for API responses."""

    id: str = Field(..., alias="_id")

    # Transient field from MongoDB $vectorSearch (not persisted to DB)
    score: Optional[float] = Field(
        default=None,
        description="Vector search similarity score from MongoDB Atlas (query-specific, not stored)",
    )

    @staticmethod
    def of(doc: Union[SemanticDB, Dict[str, Any], None]) -> Optional["SemanticOut"]:
        if doc is None:
            return None
        if isinstance(doc, SemanticDB):
            doc = doc.model_dump(by_alias=True, mode="json")
        doc["_id"] = str(doc["_id"])
        return SemanticOut.model_validate(doc)
