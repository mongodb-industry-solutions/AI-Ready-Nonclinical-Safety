"""
MongoDB connection management for mongomem_core.

This module provides thread-safe connection pooling and database access.
Clients are cached by URI to support split database configurations
(e.g., worker using a different cluster than core).
"""

from __future__ import annotations

import logging
import threading
from typing import Any, Dict, Optional

from mongomem_core.config import Settings
from mongomem_core.exceptions import ConfigurationError, ConnectionError
from mongomem_core.storage.collections import BaseCollectionDescriptor
from pymongo import MongoClient
from pymongo.database import Database
from pymongo.errors import ConfigurationError as PyMongoConfigError
from pymongo.errors import ConnectionFailure
from pymongo.synchronous.collection import Collection

logger = logging.getLogger(__name__)

# Cache clients by URI to support multiple clusters
_clients: Dict[str, MongoClient] = {}
_clients_lock = threading.Lock()


def get_client(settings: Optional[Settings] = None) -> MongoClient:
    """
    Get (and lazily create) a MongoClient for the given URI.

    Clients are cached by URI, so multiple calls with the same URI
    return the same client. Different URIs get different clients,
    supporting split database configurations.

    Args:
        settings: Optional Settings instance. If None, loads from environment.

    Returns:
        A MongoClient instance (cached by URI).

    Raises:
        ConfigurationError: If the MongoDB URI is invalid.
        ConnectionError: If the connection to MongoDB cannot be established.
    """
    s = settings or Settings()
    uri = (
        s.mongo_uri.get_secret_value()
        if hasattr(s.mongo_uri, "get_secret_value")
        else str(s.mongo_uri)
    )

    if uri not in _clients:
        with _clients_lock:
            if uri not in _clients:
                logger.debug("Initializing MongoClient for URI (hash=%s)", hash(uri) % 10000)
                try:
                    client: MongoClient[Dict[str, Any]] = MongoClient(uri)
                    # Verify connection is valid by pinging the server
                    client.admin.command("ping")
                    _clients[uri] = client
                    logger.info(
                        "Successfully connected to MongoDB (clients cached: %d)", len(_clients)
                    )
                except PyMongoConfigError as exc:
                    logger.error("Invalid MongoDB configuration: %s", exc)
                    raise ConfigurationError(
                        f"Invalid MongoDB URI or configuration: {exc}",
                        setting="mongo_uri",
                    ) from exc
                except ConnectionFailure as exc:
                    logger.error("Failed to connect to MongoDB: %s", exc)
                    raise ConnectionError(f"Failed to connect to MongoDB: {exc}") from exc

    return _clients[uri]


def get_database(settings: Optional[Settings] = None) -> Database:
    """
    Get the MongoDB database for the given settings.

    Args:
        settings: Optional Settings instance. If None, loads from environment.

    Returns:
        The MongoDB Database instance.

    Raises:
        ConfigurationError: If the MongoDB URI is invalid.
        ConnectionError: If the connection to MongoDB cannot be established.
    """
    s = settings or Settings()
    client = get_client(s)
    return client[s.db_name]


def get_collection(descriptor: BaseCollectionDescriptor, db: Database) -> Collection:
    """
    Get a MongoDB collection from a collection descriptor and database.

    This helper function provides a cleaner way to access collections without
    instantiating the descriptor class each time. Since collection descriptors
    are stateless, module-level singleton instances should be used.

    Args:
        descriptor: Collection descriptor instance (should be a module-level singleton)
        db: MongoDB database instance

    Returns:
        MongoDB Collection instance

    Example:
        >>> from mongomem_core.storage.collections import EpisodicMemoryCollection
        >>> from mongomem_core.storage import get_database, get_collection
        >>> # Use module-level singleton: _EPISODIC_COL = EpisodicMemoryCollection()
        >>> db = get_database()
        >>> col = get_collection(_EPISODIC_COL, db)
    """
    return descriptor.get(db)
