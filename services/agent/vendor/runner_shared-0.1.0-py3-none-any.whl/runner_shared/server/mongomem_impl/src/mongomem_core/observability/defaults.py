"""Default implementations of ObservabilityProtocol."""

from __future__ import annotations

import logging
import time
from contextlib import contextmanager
from typing import Any, Dict, Generator, Optional

from mongomem_core.protocols import ObservabilityProtocol


class NoOpObservability(ObservabilityProtocol):
    """
    No-operation observability implementation.

    All methods are empty stubs with zero overhead. Use this when observability
    is disabled or not needed (e.g., in tests or when no monitoring is configured).
    """

    def increment(
        self,
        name: str,
        value: float = 1.0,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """Increment a counter metric (no-op)."""
        pass

    def gauge(
        self,
        name: str,
        value: float,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """Set a gauge metric (no-op)."""
        pass

    def histogram(
        self,
        name: str,
        value: float,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """Record a histogram value (no-op)."""
        pass

    def timing(
        self,
        name: str,
        value_ms: float,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """Record a timing metric (no-op)."""
        pass

    @contextmanager
    def span(
        self,
        name: str,
        *,
        kind: str = "internal",
        attributes: Optional[Dict[str, Any]] = None,
    ) -> Generator[Dict[str, Any], None, None]:
        """Create a tracing span (no-op, yields empty dict)."""
        yield {}

    def event(
        self,
        name: str,
        *,
        attributes: Optional[Dict[str, Any]] = None,
        level: str = "info",
    ) -> None:
        """Emit a structured event (no-op)."""
        pass


class LoggingObservability(ObservabilityProtocol):
    """
    Logging-based observability implementation.

    Emits all metrics, spans, and events to a Python logger. Useful for
    development, debugging, or environments without dedicated observability
    infrastructure.

    Args:
        logger_name: Name for the logger (default: "mongomem.observability")
        log_level: Log level for output (default: DEBUG)
    """

    def __init__(
        self,
        logger_name: str = "mongomem.observability",
        log_level: int = logging.DEBUG,
    ) -> None:
        self._logger = logging.getLogger(logger_name)
        self._log_level = log_level

    def _format_tags(self, tags: Optional[Dict[str, str]]) -> str:
        if not tags:
            return ""
        return " " + " ".join(f"{k}={v}" for k, v in sorted(tags.items()))

    def increment(
        self,
        name: str,
        value: float = 1.0,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """Increment a counter metric and log it."""
        self._logger.log(
            self._log_level,
            "[metric:counter] %s +%s%s",
            name,
            value,
            self._format_tags(tags),
        )

    def gauge(
        self,
        name: str,
        value: float,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """Set a gauge metric and log it."""
        self._logger.log(
            self._log_level,
            "[metric:gauge] %s =%s%s",
            name,
            value,
            self._format_tags(tags),
        )

    def histogram(
        self,
        name: str,
        value: float,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """Record a histogram value and log it."""
        self._logger.log(
            self._log_level,
            "[metric:histogram] %s %s%s",
            name,
            value,
            self._format_tags(tags),
        )

    def timing(
        self,
        name: str,
        value_ms: float,
        tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """Record a timing metric and log it."""
        self._logger.log(
            self._log_level,
            "[metric:timing] %s %.2fms%s",
            name,
            value_ms,
            self._format_tags(tags),
        )

    @contextmanager
    def span(
        self,
        name: str,
        *,
        kind: str = "internal",
        attributes: Optional[Dict[str, Any]] = None,
    ) -> Generator[Dict[str, Any], None, None]:
        """Create a tracing span, logging start and end with duration."""
        attrs = dict(attributes) if attributes else {}
        self._logger.log(
            self._log_level,
            "[span:start] %s kind=%s attributes=%s",
            name,
            kind,
            attrs,
        )
        start = time.perf_counter()
        try:
            yield attrs
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            self._logger.log(
                self._log_level,
                "[span:end] %s duration=%.2fms attributes=%s",
                name,
                duration_ms,
                attrs,
            )

    def event(
        self,
        name: str,
        *,
        attributes: Optional[Dict[str, Any]] = None,
        level: str = "info",
    ) -> None:
        """Emit a structured event and log it."""
        log_level = getattr(logging, level.upper(), logging.INFO)
        self._logger.log(
            log_level,
            "[event] %s attributes=%s",
            name,
            attributes or {},
        )


__all__ = ["NoOpObservability", "LoggingObservability"]
