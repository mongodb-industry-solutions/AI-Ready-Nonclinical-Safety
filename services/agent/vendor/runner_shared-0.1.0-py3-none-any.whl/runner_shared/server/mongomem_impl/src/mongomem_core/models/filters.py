"""
Metadata filtering for Atlas Vector Search.

This module provides flexible metadata filtering for vector search operations
across all memory types (semantic, episodic, snapshot).

"""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, model_validator


class FilterOperator(str, Enum):
    """
    MongoDB Atlas Vector Search filter operators.

    Supported comparison operators for filtering vector search results.
    Note: Atlas Vector Search does not support $regex, $text, $expr, or $where.
    """

    EQ = "$eq"
    NE = "$ne"
    GT = "$gt"
    GTE = "$gte"
    LT = "$lt"
    LTE = "$lte"
    IN = "$in"
    NIN = "$nin"
    EXISTS = "$exists"


class FieldFilter(BaseModel):
    """
    A single field filter condition for structured mode.

    Args:
        field: Field path to filter on (e.g., "label", "metadata.source")
        operator: Comparison operator (default: EQ for equality)
        value: Value to compare against
    """

    field: str = Field(..., description="Field path to filter on")
    operator: FilterOperator = Field(default=FilterOperator.EQ, description="Comparison operator")
    value: Any = Field(..., description="Value to compare against")

    def to_mongo_condition(self) -> Dict[str, Any]:
        """Convert to MongoDB filter condition."""
        if self.operator == FilterOperator.EQ:
            return {self.field: self.value}
        return {self.field: {self.operator.value: self.value}}


class MetadataFilter(BaseModel):
    """
    Metadata filter for Atlas Vector Search.

    Two modes are available:

    **Raw mode** (recommended for most cases): Pass a MongoDB filter dict directly.
    Simple, flexible, and familiar to MongoDB users::

        MetadataFilter(raw={"label": "python", "version": {"$gte": 2}})

    **Structured mode**: Use FieldFilter for type-safe, validated conditions.
    Multiple conditions are combined with AND logic::

        MetadataFilter(conditions=[
            FieldFilter(field="label", value="python"),
            FieldFilter(field="version", operator=FilterOperator.GTE, value=2),
        ])

    Args:
        conditions: List of FieldFilter conditions (combined with AND)
        raw: Raw MongoDB filter dict for direct passthrough

    Note:
        Only one of ``conditions`` or ``raw`` can be specified.
    """

    conditions: Optional[List[FieldFilter]] = Field(
        default=None, description="Field conditions (combined with AND)"
    )
    raw: Optional[Dict[str, Any]] = Field(default=None, description="Raw MongoDB filter dict")

    @model_validator(mode="after")
    def validate_exclusive(self) -> "MetadataFilter":
        """Ensure only one mode is used."""
        if self.conditions and self.raw:
            raise ValueError("Cannot specify both 'conditions' and 'raw'; use one or the other")
        return self

    def is_empty(self) -> bool:
        """Return True if no filter conditions are specified."""
        return not self.conditions and not self.raw

    def to_mongo_filter(self) -> Dict[str, Any]:
        """
        Convert to MongoDB filter dict for $vectorSearch.

        Returns:
            MongoDB filter dict. Empty dict if no conditions specified.
        """
        if self.raw:
            return self.raw

        if not self.conditions:
            return {}

        result: Dict[str, Any] = {}
        for cond in self.conditions:
            result.update(cond.to_mongo_condition())

        return result
