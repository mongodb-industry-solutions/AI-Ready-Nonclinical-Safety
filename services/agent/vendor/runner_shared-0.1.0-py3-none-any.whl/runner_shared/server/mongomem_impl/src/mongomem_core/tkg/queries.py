"""Query helpers for the Temporal Knowledge Graph (TKG)."""
