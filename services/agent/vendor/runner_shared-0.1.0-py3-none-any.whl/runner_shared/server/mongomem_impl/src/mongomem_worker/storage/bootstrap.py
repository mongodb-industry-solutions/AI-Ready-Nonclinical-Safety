"""
Bootstrap helpers for ``mongomem_worker`` storage.

These helpers are the worker-side counterpart to
``mongomem_core.storage.bootstrap`` and are responsible for materialising the
worker / task-queue collections and their indexes on a real MongoDB database.
"""

from __future__ import annotations

import logging
from typing import Iterable, Sequence, Tuple

from pymongo.errors import OperationFailure, PyMongoError
from pymongo.synchronous.database import Database

from .collections import BaseCollectionDescriptor, iter_worker_collections
from .indexes import CollectionIndexes, iter_worker_indexes

logger = logging.getLogger(__name__)

INDEX_NOT_FOUND_ERROR_CODE = 27


def _iter_collection_descriptors() -> Iterable[BaseCollectionDescriptor]:
    """Internal indirection for tests."""

    return iter_worker_collections()


def _iter_collection_indexes() -> Iterable[CollectionIndexes]:
    """Internal indirection for tests."""

    return iter_worker_indexes()


def ensure_worker_collections(db: Database) -> None:
    """
    Ensure that all worker-domain collections are addressable in ``db``.

    This mirrors ``ensure_engine_collections`` in the core storage layer but is
    limited strictly to task-queue / worker state collections.
    """

    for desc in _iter_collection_descriptors():
        _ = desc.get(db)
        logger.debug("Ensured worker collection handle for %s", desc.name)


def ensure_worker_indexes(db: Database) -> None:
    """
    Ensure B-tree indexes for all worker-domain collections exist.

    This function walks the index descriptors from
    ``mongomem_worker.storage.indexes`` and applies them via
    ``Collection.create_index``.  It is safe to run multiple times.
    """

    def _get_current_indexes_by_name(col) -> dict[str, dict]:
        out: dict[str, dict] = {}
        for ix in col.list_indexes():
            name = ix.get("name")
            if not name or name == "_id_":
                continue
            out[name] = ix
        return out

    def _equivalent(
        current_index: dict,
        keys: Sequence[Tuple[str, int]],
        kwargs: dict,
    ) -> bool:
        # Compare only the parts we control.
        key_doc = current_index.get("key", {})
        current_keys = list(key_doc.items())
        desired_keys = list(keys)
        if current_keys != desired_keys:
            return False
        if bool(current_index.get("unique", False)) != bool(kwargs.get("unique", False)):
            return False
        if bool(current_index.get("sparse", False)) != bool(kwargs.get("sparse", False)):
            return False
        if current_index.get("expireAfterSeconds") != kwargs.get("expireAfterSeconds"):
            return False
        if current_index.get("partialFilterExpression") != kwargs.get("partialFilterExpression"):
            return False
        return True

    for ci in _iter_collection_indexes():
        col = db[ci.collection_name]
        existing = _get_current_indexes_by_name(col)

        for index in ci.indexes:
            try:
                kwargs = index.to_create_index_kwargs()
                current_ix = existing.get(index.name)
                if current_ix is not None:
                    if _equivalent(current_ix, index.keys, kwargs):
                        continue
                    # Spec changed: drop and recreate.
                    try:
                        col.drop_index(index.name)
                    except OperationFailure as exc:
                        # Race-safe: another worker/thread may have dropped it already.
                        if getattr(exc, "code", None) == INDEX_NOT_FOUND_ERROR_CODE:
                            logger.debug(
                                "Index %s already dropped on %s (race), continuing",
                                index.name,
                                ci.collection_name,
                            )
                        else:
                            raise
                col.create_index(index.keys, **kwargs)
                logger.debug(
                    "Ensured worker index %s on collection %s", index.name, ci.collection_name
                )
            except PyMongoError:
                logger.exception(
                    "Failed to ensure worker index %s on collection %s",
                    index.name,
                    ci.collection_name,
                )
                raise
