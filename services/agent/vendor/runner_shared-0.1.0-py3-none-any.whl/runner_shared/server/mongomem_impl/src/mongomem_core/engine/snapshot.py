"""Snapshot memory operations for MemoryEngine.

Internal implementation - use MemoryEngine from mongomem_core.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from mongomem_core.models.engine import CreateSnapshotResult, DeleteResult, PromoteSnapshotResult
from mongomem_core.models.memory.base import ChunkVisibility

if TYPE_CHECKING:
    from mongomem_core.engine._protocol import EngineProtocol
    from mongomem_core.models.memory.snapshot import SnapshotOut

logger = logging.getLogger(__name__)


class _Snapshot:
    """Snapshot memory operations and STM promotion."""

    def create_snapshot(
        self: "EngineProtocol",
        *,
        session_id: str,
        org_id: str,
        user_id: str,
        messages: List[Dict[str, Any]],
        reason: str = "manual",
        ttl_days: int | None = None,
        embedding: list[float] | None = None,
        embedding_model_id: str | None = None,
        embedding_strategy: str | None = None,
        topic_id: str | None = None,
        topic_title: str | None = None,
        topic_shift_score: float | None = None,
        boundary_turn_seq: int | None = None,
        visibility: str = "private",
        project_id: str | None = None,
    ) -> CreateSnapshotResult:
        """
        Create a snapshot memory manually.

        Args:
            session_id: Session identifier
            org_id: Organization ID for multi-tenancy
            user_id: User ID who owns this memory
            messages: List of message dicts with role, content, timestamp
            reason: Snapshot reason ("manual", "auto", "idle", etc.)
            ttl_days: Time-to-live in days
            embedding: Pre-computed embedding vector
            embedding_model_id: Model used for embedding
            embedding_strategy: How embedding was created
            topic_id: Topic grouping identifier
            topic_title: Topic title
            topic_shift_score: Similarity score that triggered topic shift
            boundary_turn_seq: Turn sequence boundary
            visibility: Visibility scope
            project_id: Project ID

        Returns:
            CreateSnapshotResult with the created document's ID
        """
        from mongomem_core.common.utils import utcnow
        from mongomem_core.memory.snapshot import create_snapshot
        from mongomem_core.models.memory.snapshot import SnapshotIn, SnapshotMessage

        snapshot_messages = []
        for msg in messages:
            snapshot_messages.append(
                SnapshotMessage(
                    role=msg["role"],
                    content=msg.get("content"),
                    timestamp=msg.get("timestamp", utcnow()),
                    tool_calls=msg.get("tool_calls"),
                    tool_call_id=msg.get("tool_call_id"),
                    stm_embedding=msg.get("stm_embedding"),
                )
            )

        vis = ChunkVisibility(visibility)

        snapshot_in = SnapshotIn(
            session_id=session_id,
            messages=snapshot_messages,
            snapshot_reason=reason,  # type: ignore
            ttl_days=ttl_days,
            visibility=vis,
            project_id=project_id,
            topic_id=topic_id,
            topic_title=topic_title,
            topic_shift_score=topic_shift_score,
            boundary_turn_seq=boundary_turn_seq,
            trigger_source="manual",  # type: ignore
        )

        doc = create_snapshot(
            db=self._db,
            snapshot_in=snapshot_in,
            org_id=org_id,
            user_id=user_id,
            embedding=embedding,
            embedding_model_id=embedding_model_id,
            embedding_strategy=embedding_strategy,
        )

        logger.info(
            "Created snapshot: id=%s session=%s reason=%s messages=%d",
            doc.id,
            session_id,
            reason,
            len(messages),
        )

        return CreateSnapshotResult(
            id=str(doc.id),
            session_id=session_id,
            message_count=len(messages),
            has_embedding=doc.has_embedding,
            embedding_strategy=embedding_strategy,
            snapshot_reason=reason,
            acknowledged=True,
        )

    def get_snapshot(
        self: "EngineProtocol",
        org_id: str,
        *,
        id: str | None = None,
        session_id: str | None = None,
        boundary_turn_seq: int | None = None,
        include_deleted: bool = False,
    ) -> "SnapshotOut | None":
        """
        Retrieve a snapshot by ID or session.

        Args:
            org_id: Organization ID
            id: Document ID (mutually exclusive with session_id)
            session_id: Session ID
            boundary_turn_seq: Turn sequence boundary
            include_deleted: Include soft-deleted documents

        Returns:
            SnapshotOut if found, None otherwise
        """
        from mongomem_core.memory.snapshot import get_snapshot

        return get_snapshot(
            db=self._db,
            org_id=org_id,
            id=id,
            session_id=session_id,
            boundary_turn_seq=boundary_turn_seq,
            include_deleted=include_deleted,
        )

    def get_latest_snapshot(
        self: "EngineProtocol",
        session_id: str,
        org_id: str,
        *,
        include_deleted: bool = False,
    ) -> "SnapshotOut | None":
        """
        Get the most recent snapshot for a session.

        Args:
            session_id: Session identifier
            org_id: Organization ID
            include_deleted: Include soft-deleted documents

        Returns:
            SnapshotOut if found, None otherwise
        """
        from mongomem_core.memory.snapshot import get_latest_snapshot

        return get_latest_snapshot(
            db=self._db,
            session_id=session_id,
            org_id=org_id,
            include_deleted=include_deleted,
        )

    def list_snapshots(
        self: "EngineProtocol",
        org_id: str,
        *,
        user_id: str | None = None,
        session_id: str | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        promoted: bool | None = None,
        has_embedding: bool | None = None,
        limit: int = 50,
        include_deleted: bool = False,
    ) -> "List[SnapshotOut]":
        """
        List snapshots with optional filters.

        Args:
            org_id: Organization ID
            user_id: Filter by user ID
            session_id: Filter by session ID
            visibility: Filter by visibility
            project_id: Filter by group ID
            promoted: Filter by promotion status
            has_embedding: Filter by embedding presence
            limit: Maximum number of results
            include_deleted: Include soft-deleted documents

        Returns:
            List of SnapshotOut documents
        """
        from mongomem_core.memory.snapshot import list_snapshots

        vis = ChunkVisibility(visibility) if visibility else None

        return list_snapshots(
            db=self._db,
            org_id=org_id,
            user_id=user_id,
            session_id=session_id,
            visibility=vis,
            project_id=project_id,
            promoted=promoted,
            has_embedding=has_embedding,
            limit=limit,
            include_deleted=include_deleted,
        )

    def update_snapshot(
        self: "EngineProtocol",
        org_id: str,
        *,
        id: str | None = None,
        session_id: str | None = None,
        boundary_turn_seq: int | None = None,
        visibility: str | None = None,
        project_id: str | None = None,
        topic_id: str | None = None,
        topic_title: str | None = None,
        promoted: bool | None = None,
        embedding: list[float] | None = None,
        embedding_model_id: str | None = None,
    ) -> "SnapshotOut | None":
        """
        Update a snapshot.

        Args:
            org_id: Organization ID
            id: Document ID (mutually exclusive with session_id)
            session_id: Session ID
            boundary_turn_seq: Turn sequence boundary
            visibility: New visibility
            project_id: New group ID
            topic_id: New topic ID
            topic_title: New topic title
            promoted: Mark as promoted
            embedding: New embedding vector
            embedding_model_id: New embedding model ID

        Returns:
            Updated SnapshotOut or None if not found
        """
        from mongomem_core.memory.snapshot import update_snapshot
        from mongomem_core.models.memory.snapshot import SnapshotUpdate

        vis = ChunkVisibility(visibility) if visibility else None

        update_model = SnapshotUpdate(
            visibility=vis,
            project_id=project_id,
            topic_id=topic_id,
            topic_title=topic_title,
            promoted=promoted,
            embedding=embedding,
            embedding_model_id=embedding_model_id,
        )

        return update_snapshot(
            db=self._db,
            org_id=org_id,
            update=update_model,
            id=id,
            session_id=session_id,
            boundary_turn_seq=boundary_turn_seq,
        )

    def delete_snapshot(
        self: "EngineProtocol",
        org_id: str,
        *,
        id: str | None = None,
        session_id: str | None = None,
        boundary_turn_seq: int | None = None,
        soft: bool = True,
    ) -> DeleteResult:
        """
        Delete a snapshot.

        Args:
            org_id: Organization ID
            id: Document ID (mutually exclusive with session_id)
            session_id: Session ID
            boundary_turn_seq: Turn sequence boundary
            soft: If True (default), soft delete. If False, hard delete.

        Returns:
            DeleteResult with deleted_count
        """
        from mongomem_core.memory.snapshot import delete_snapshot

        result = delete_snapshot(
            db=self._db,
            org_id=org_id,
            id=id,
            session_id=session_id,
            boundary_turn_seq=boundary_turn_seq,
            soft=soft,
        )

        if hasattr(result, "deleted_count"):
            deleted_count = result.deleted_count
        else:
            deleted_count = result.modified_count

        logger.info(
            "Deleted snapshot: org=%s id=%s soft=%s count=%d",
            org_id,
            id,
            soft,
            deleted_count,
        )
        return DeleteResult(deleted_count=deleted_count, acknowledged=True)

    def search_snapshots(
        self: "EngineProtocol",
        embedding: list[float],
        org_id: str,
        *,
        user_id: str | None = None,
        exclude_session_id: str | None = None,
        visibility: str | None = None,
        top_k: int = 10,
        min_score: float | None = None,
    ) -> "List[SnapshotOut]":
        """
        Vector search across snapshots.

        Args:
            embedding: Query embedding vector
            org_id: Organization ID
            user_id: Filter by user ID
            exclude_session_id: Exclude this session
            visibility: Filter by visibility
            top_k: Number of results
            min_score: Minimum similarity score

        Returns:
            List of SnapshotOut documents sorted by similarity
        """
        from mongomem_core.memory.snapshot import search_snapshots

        vis = ChunkVisibility(visibility) if visibility else None

        return search_snapshots(
            db=self._db,
            embedding=embedding,
            org_id=org_id,
            user_id=user_id,
            exclude_session_id=exclude_session_id,
            visibility=vis,
            top_k=top_k,
            min_score=min_score,
        )

    def promote_stm_to_snapshot(
        self: "EngineProtocol",
        session_id: str,
        org_id: str,
        user_id: str,
        project_id: str,
        *,
        force: bool = False,
        delete_promoted: Optional[bool] = None,
    ) -> PromoteSnapshotResult:
        """
        Promote STM documents to a snapshot.

        Args:
            session_id: Session identifier
            org_id: Organization ID
            user_id: User ID
            project_id: Project ID
            force: If True, promote regardless of thresholds
            delete_promoted: If True (default), delete promoted STM docs

        Returns:
            PromoteSnapshotResult with promotion details
        """
        from mongomem_core.pipelines.stm_to_snapshot import promote_stm_to_snapshot

        snapshot = promote_stm_to_snapshot(
            db=self._db,
            session_id=session_id,
            org_id=org_id,
            user_id=user_id,
            project_id=project_id,
            embedder=self._embedder,
            force=force,
            delete_promoted=delete_promoted,
        )

        if snapshot:
            return PromoteSnapshotResult(
                snapshot_id=str(snapshot.id),
                session_id=session_id,
                promoted_count=len(snapshot.messages),
                reason=snapshot.snapshot_reason,
                has_embedding=snapshot.has_embedding,
                acknowledged=True,
            )
        else:
            return PromoteSnapshotResult(
                snapshot_id=None,
                session_id=session_id,
                promoted_count=0,
                reason="threshold_not_met",
                has_embedding=False,
                acknowledged=True,
            )

    def check_snapshot_thresholds(
        self: "EngineProtocol",
        session_id: str,
        org_id: str,
        *,
        user_id: str | None = None,
    ) -> tuple[bool, str]:
        """
        Check if a session should be snapshotted based on current STM state.

        Args:
            session_id: Session identifier
            org_id: Organization ID
            user_id: Optional user ID filter

        Returns:
            Tuple of (should_snapshot, reason)
        """
        from mongomem_core.pipelines.stm_to_snapshot import check_snapshot_thresholds

        return check_snapshot_thresholds(
            db=self._db,
            session_id=session_id,
            org_id=org_id,
            user_id=user_id,
        )
