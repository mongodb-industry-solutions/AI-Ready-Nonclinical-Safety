"""Event/CDC ingestion into memory and vector indexes."""
