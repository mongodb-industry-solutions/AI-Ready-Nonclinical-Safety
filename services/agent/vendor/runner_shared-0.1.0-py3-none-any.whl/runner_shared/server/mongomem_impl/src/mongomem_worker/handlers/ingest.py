"""
Document ingestion handler for worker-based processing.

Handles async document ingestion - extract, chunk, and store as semantic memories.
Allows users to queue large ingestion jobs that run in the background.

Usage:
    # Queue a job
    job = engine.queue_ingestion(
        paths=["docs/report.pdf", "gs://bucket/slides/"],
        org_id="my-org",
        user_id="sakshi",
    )
    print(f"Queued job: {job.job_id}")

    # Check status later
    status = engine.get_ingestion_status(job.job_id)
    print(f"Status: {status.state}, {status.files_processed}/{status.total_files}")
"""

from __future__ import annotations

import logging
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from bson import ObjectId
from pymongo.database import Database

from .base import TaskHandler

if TYPE_CHECKING:
    from ...mongomem_core.engine import MemoryEngine

logger = logging.getLogger(__name__)

# Collection name for ingestion jobs
INGEST_JOBS_COLLECTION = "ingest_jobs"


class IngestJobState(str, Enum):
    """State of an ingestion job."""

    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    PARTIAL = "partial"  # Some files succeeded, some failed


@dataclass
class IngestJobStatus:
    """Status of an ingestion job."""

    job_id: str
    state: IngestJobState
    total_files: int
    files_processed: int
    files_succeeded: int
    files_failed: int
    total_chunks: int
    chunk_ids: List[str]
    error: Optional[str]
    created_at: datetime
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    file_results: List[Dict[str, Any]]

    @classmethod
    def from_doc(cls, doc: Dict[str, Any]) -> "IngestJobStatus":
        """Create from MongoDB document."""
        return cls(
            job_id=str(doc["_id"]),
            state=IngestJobState(doc.get("state", "queued")),
            total_files=doc.get("total_files", 0),
            files_processed=doc.get("files_processed", 0),
            files_succeeded=doc.get("files_succeeded", 0),
            files_failed=doc.get("files_failed", 0),
            total_chunks=doc.get("total_chunks", 0),
            chunk_ids=doc.get("chunk_ids", []),
            error=doc.get("error"),
            created_at=doc.get("created_at", datetime.now(timezone.utc)),
            started_at=doc.get("started_at"),
            completed_at=doc.get("completed_at"),
            file_results=doc.get("file_results", []),
        )


@dataclass
class QueuedIngestJob:
    """Result of queuing an ingestion job."""

    job_id: str
    state: IngestJobState = IngestJobState.QUEUED


class IngestHandler(TaskHandler):
    """
    Handler for async document ingestion.

    Processes ingestion jobs that have been queued via engine.queue_ingestion().
    Extracts text from documents, chunks it, and stores as semantic memories.

    Job status is tracked in the ingest_jobs collection.
    """

    task_type = "ingest_documents"
    timeout_seconds = 3600  # 1 hour for large batches

    def __init__(
        self,
        engine: "MemoryEngine",
        db: Database,
    ) -> None:
        """
        Initialize IngestHandler.

        Args:
            engine: MemoryEngine instance for bulk_create_semantic
            db: Worker database for job status tracking
        """
        self._engine = engine
        self._db = db
        self._jobs_col = db[INGEST_JOBS_COLLECTION]

    async def handle_task(self, payload: Dict[str, Any]) -> None:
        """
        Process a queued ingestion job.

        Args:
            payload: Task payload containing:
                - job_id: Job ID for status tracking
                - paths: List of file paths to ingest
                - org_id: Organization ID
                - user_id: User ID
                - config: Optional IngestConfig dict
                - visibility: Memory visibility
                - project_id: Optional group ID
                - generate_embeddings: Whether to generate embeddings
        """
        job_id = payload.get("job_id")
        if not job_id:
            logger.error("IngestHandler received task without job_id")
            return

        try:
            job_oid = ObjectId(job_id)
        except Exception:
            logger.error("Invalid job_id: %s", job_id)
            return

        # Mark job as running
        self._jobs_col.update_one(
            {"_id": job_oid},
            {
                "$set": {
                    "state": IngestJobState.RUNNING.value,
                    "started_at": datetime.now(timezone.utc),
                }
            },
        )

        logger.info(
            "Starting ingestion job %s with %d files", job_id, len(payload.get("paths", []))
        )

        try:
            # Import here to avoid circular imports
            from ...mongomem_core.ingest.models import (
                ChunkConfig,
                ChunkerType,
                ExtractorType,
                IngestConfig,
            )
            from ...mongomem_core.ingest.pipeline import ingest_documents

            # Build config from payload (reconstruct nested objects)
            config_dict = payload.get("config", {})
            config = None
            if config_dict:
                # Reconstruct ChunkConfig from dict
                chunk_config_dict = config_dict.get("chunk_config", {})
                chunk_config = ChunkConfig(
                    max_chunk_size=chunk_config_dict.get("max_chunk_size", 400),
                    min_chunk_size=chunk_config_dict.get("min_chunk_size", 50),
                    chunk_overlap=chunk_config_dict.get("chunk_overlap", 50),
                    encoding_name=chunk_config_dict.get("encoding_name", "cl100k_base"),
                    discard_small_chunks=chunk_config_dict.get("discard_small_chunks", True),
                )

                # Reconstruct IngestConfig
                config = IngestConfig(
                    extractor=ExtractorType(config_dict.get("extractor", "simple")),
                    chunker=ChunkerType(config_dict.get("chunker", "auto")),
                    chunk_config=chunk_config,
                    max_retries=config_dict.get("max_retries", 2),
                    on_failure=config_dict.get("on_failure", "skip"),
                    default_metadata=config_dict.get("default_metadata", {}),
                )

            # Run ingestion
            result = ingest_documents(
                engine=self._engine,
                paths=payload.get("paths", []),
                org_id=payload["org_id"],
                user_id=payload["user_id"],
                config=config,
                visibility=payload.get("visibility", "org"),
                project_id=payload.get("project_id"),
                generate_embeddings=payload.get("generate_embeddings", True),
            )

            # Determine final state
            if result.files_failed == 0:
                state = IngestJobState.COMPLETED
            elif result.files_succeeded == 0:
                state = IngestJobState.FAILED
            else:
                state = IngestJobState.PARTIAL

            # Update job with results
            self._jobs_col.update_one(
                {"_id": job_oid},
                {
                    "$set": {
                        "state": state.value,
                        "files_processed": result.files_processed,
                        "files_succeeded": result.files_succeeded,
                        "files_failed": result.files_failed,
                        "total_chunks": result.total_chunks,
                        "chunk_ids": result.chunk_ids,
                        "file_results": [asdict(fr) for fr in result.file_results],
                        "completed_at": datetime.now(timezone.utc),
                    }
                },
            )

            logger.info(
                "Completed ingestion job %s: %d files, %d chunks, state=%s",
                job_id,
                result.files_processed,
                result.total_chunks,
                state.value,
            )

        except Exception as e:
            logger.exception("Ingestion job %s failed: %s", job_id, e)

            # Mark job as failed
            self._jobs_col.update_one(
                {"_id": job_oid},
                {
                    "$set": {
                        "state": IngestJobState.FAILED.value,
                        "error": str(e),
                        "completed_at": datetime.now(timezone.utc),
                    }
                },
            )
            raise


def create_ingest_job(
    db: Database,
    paths: List[str],
    org_id: str,
    user_id: str,
    *,
    config_dict: Optional[Dict[str, Any]] = None,
    visibility: str = "org",
    project_id: Optional[str] = None,
    generate_embeddings: bool = True,
) -> QueuedIngestJob:
    """
    Create an ingestion job record.

    Args:
        db: Worker database
        paths: List of file paths to ingest
        org_id: Organization ID
        user_id: User ID
        config_dict: Optional IngestConfig as dict
        visibility: Memory visibility
        project_id: Optional group ID
        generate_embeddings: Whether to generate embeddings

    Returns:
        QueuedIngestJob with job_id
    """
    now = datetime.now(timezone.utc)
    job_doc = {
        "state": IngestJobState.QUEUED.value,
        "paths": paths,
        "org_id": org_id,
        "user_id": user_id,
        "config": config_dict or {},
        "visibility": visibility,
        "project_id": project_id,
        "generate_embeddings": generate_embeddings,
        "total_files": len(paths),
        "files_processed": 0,
        "files_succeeded": 0,
        "files_failed": 0,
        "total_chunks": 0,
        "chunk_ids": [],
        "file_results": [],
        "error": None,
        "created_at": now,
        "started_at": None,
        "completed_at": None,
    }

    result = db[INGEST_JOBS_COLLECTION].insert_one(job_doc)
    job_id = str(result.inserted_id)

    logger.info("Created ingestion job %s with %d files", job_id, len(paths))

    return QueuedIngestJob(job_id=job_id)


def get_ingest_job_status(db: Database, job_id: str) -> Optional[IngestJobStatus]:
    """
    Get the status of an ingestion job.

    Args:
        db: Worker database
        job_id: Job ID

    Returns:
        IngestJobStatus or None if not found
    """
    try:
        job_oid = ObjectId(job_id)
    except Exception:
        return None

    doc = db[INGEST_JOBS_COLLECTION].find_one({"_id": job_oid})
    if not doc:
        return None

    return IngestJobStatus.from_doc(doc)


__all__ = [
    "IngestHandler",
    "IngestJobState",
    "IngestJobStatus",
    "QueuedIngestJob",
    "create_ingest_job",
    "get_ingest_job_status",
    "INGEST_JOBS_COLLECTION",
]
