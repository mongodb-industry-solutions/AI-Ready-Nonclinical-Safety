"""
Retrieval engine for mongomem_core.

This package implements source selection, ranking, budgeting, and
formatting of context blocks for agents.

Key modules:
- sources.py: Retrieval sources and hub
- backends.py: Storage backend protocols (MongoDB, etc.)
- thread.py: Conversation thread retrieval algorithm
- context_builder.py: High-level context building
- ranking.py: Memory ranking strategies
- budgeting.py: Token budgeting
- formatting.py: Context formatting
"""

from .backends import MongoSnapshotBackend, SnapshotSearchBackend
from .budgeting import Budgeter
from .context_builder import ContextBuilder
from .deduplication import deduplicate_memory_chunks
from .formatting import Formatter
from .ranking import MemoryRanker
from .sources import (
    RetrievalHub,
    calculate_similarity_for_prefetched,
    fetch_episodic_memories,
    fetch_procedural_memories,
    fetch_semantic_memories,
    fetch_taxonomic_memories,
    resolve_query_embedding,
)
from .thread import retrieve_conversation_thread

__all__ = [
    # High-level API
    "ContextBuilder",
    "Budgeter",
    "Formatter",
    "MemoryRanker",
    # Retrieval hub
    "RetrievalHub",
    # Standalone fetch functions
    "fetch_semantic_memories",
    "fetch_episodic_memories",
    "fetch_taxonomic_memories",
    "fetch_procedural_memories",
    # Utility functions
    "resolve_query_embedding",
    "deduplicate_memory_chunks",
    "calculate_similarity_for_prefetched",
    # Backends
    "SnapshotSearchBackend",
    "MongoSnapshotBackend",
    # Thread retrieval
    "retrieve_conversation_thread",
]
