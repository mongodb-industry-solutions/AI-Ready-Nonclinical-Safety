from __future__ import annotations

import asyncio
import logging
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from typing import TYPE_CHECKING, Any, Dict, List, Literal, Optional

from pymongo.database import Database

from ...mongomem_core.common.utils import utcnow
from ...mongomem_core.memory.episodic import update_episodic_embedding
from ...mongomem_core.memory.semantic import update_semantic_embedding
from ...mongomem_core.memory.short_term import update_stm_embedding
from ...mongomem_core.memory.taxonomic import update_taxonomic_embedding
from ...mongomem_core.storage.collections import (
    EpisodicMemoryCollection,
    SemanticMemoryCollection,
    TaxonomicMemoryCollection,
)
from ..circuit_breaker import CircuitBreakerOpen, get_circuit_breaker
from ..constants import (
    CIRCUIT_BREAKER_EMBEDDING,
    CORE_STM_COLLECTION,
    DEFAULT_CLAIM_TIMEOUT_SECONDS,
    DEFAULT_EMBED_THREAD_POOL_SIZE,
)
from ..storage import get_collection, get_stm_collection
from ..utils import generate_worker_id
from .base import TaskHandler

if TYPE_CHECKING:
    from ...mongomem_core.protocols import EmbedderProtocol

logger = logging.getLogger(__name__)

# Collection names for memory types
SEMANTIC_COLLECTION = SemanticMemoryCollection.name
EPISODIC_COLLECTION = EpisodicMemoryCollection.name
TAXONOMIC_COLLECTION = TaxonomicMemoryCollection.name

# Memory type literals
MemoryType = Literal["stm", "semantic", "episodic", "taxonomic"]


class EmbeddingHandler(TaskHandler):
    """Handler for embedding semantic and episodic content.

    Uses a dedicated thread pool for embedding operations to avoid
    blocking the event loop during CPU-bound tokenization and I/O-bound
    API calls.

    Supports both:
    - Task-based embedding (handle_task): For immediate embedding via queue
    - Polling-based embedding (process_pending_*): For batch background processing

    Multi-instance safe: Uses atomic claiming to prevent duplicate embedding work.
    Each document is claimed by a worker before processing. If a worker crashes,
    the claim expires after `claim_timeout_seconds` and another worker can pick it up.

    Note: STM async embedding is disabled by default since STM should typically
    be embedded synchronously through the engine for real-time retrieval.
    Set enable_stm_async=True to enable async STM embedding.
    """

    task_type = "embedding"
    timeout_seconds = 300

    def __init__(
        self,
        db: Database,
        embedder: "EmbedderProtocol",
        batch_size: int = 10,
        embed_thread_pool_size: int = DEFAULT_EMBED_THREAD_POOL_SIZE,
        enable_stm_async: bool = False,
        claim_timeout_seconds: int = DEFAULT_CLAIM_TIMEOUT_SECONDS,
        worker_id: Optional[str] = None,
    ) -> None:
        self._db = db
        self._embedder = embedder
        self._batch_size = batch_size
        self._enable_stm_async = enable_stm_async
        self._claim_timeout = timedelta(seconds=claim_timeout_seconds)
        self._worker_id = worker_id or generate_worker_id(include_uuid=True)
        self._stm_col = get_stm_collection(db)
        self._semantic_col = get_collection(db, SEMANTIC_COLLECTION)
        self._episodic_col = get_collection(db, EPISODIC_COLLECTION)
        self._taxonomic_col = get_collection(db, TAXONOMIC_COLLECTION)
        # Dedicated thread pool for embedding operations
        self._embed_executor: Optional[ThreadPoolExecutor] = None
        self._embed_thread_pool_size = embed_thread_pool_size
        self._executor_lock = threading.Lock()

        logger.info("EmbeddingHandler initialized: worker_id=%s", self._worker_id)
        if enable_stm_async:
            logger.info("STM async embedding enabled")

    def _get_executor(self) -> ThreadPoolExecutor:
        """Get or create the dedicated thread pool for embedding operations.

        Uses double-checked locking for thread-safe lazy initialization.
        """
        if self._embed_executor is None:
            with self._executor_lock:
                # Double-check inside lock to prevent race conditions
                if self._embed_executor is None:
                    self._embed_executor = ThreadPoolExecutor(
                        max_workers=self._embed_thread_pool_size,
                        thread_name_prefix="embed",
                    )
        return self._embed_executor

    def shutdown(self) -> None:
        """Shutdown the embedding thread pool."""
        if self._embed_executor is not None:
            self._embed_executor.shutdown(wait=True)
            self._embed_executor = None

    # ═══════════════════════════════════════════════════════════════════
    # Unified Processing
    # ═══════════════════════════════════════════════════════════════════

    async def process_pending(self) -> int:
        """Process pending embeddings and return total count.

        This is the standard TaskHandler interface method.
        For detailed breakdown by memory type, use process_pending_all().

        Returns:
            Total number of documents embedded
        """
        results = await self.process_pending_all()
        return sum(results.values())

    async def process_pending_all(self) -> Dict[str, int]:
        """Process pending embeddings across enabled memory types.

        Note: STM is skipped by default (enable_stm_async=False).

        Returns:
            Dict with counts per memory type: {"stm": N, "semantic": N, "episodic": N, "taxonomic": N}
        """
        results: Dict[str, int] = {
            "stm": 0,
            "semantic": await self.process_pending_semantic(),
            "episodic": await self.process_pending_episodic(),
            "taxonomic": await self.process_pending_taxonomic(),
        }

        # Only process STM if explicitly enabled
        if self._enable_stm_async:
            results["stm"] = await self.process_pending_stm()

        total = sum(results.values())
        if total > 0:
            logger.info("Embedded %d total documents: %s", total, results)
        return results

    # ═══════════════════════════════════════════════════════════════════
    # STM Processing (disabled by default, with atomic claiming)
    # ═══════════════════════════════════════════════════════════════════

    async def process_pending_stm(self) -> int:
        """Process pending STM embeddings.

        Note: Returns 0 if enable_stm_async=False (default).
        STM should typically be embedded synchronously through the engine.

        Uses atomic claiming to prevent duplicate work across multiple workers.
        """
        if not self._enable_stm_async:
            return 0

        claimed_docs = self._claim_stm_batch(limit=self._batch_size)
        if not claimed_docs:
            return 0

        processed = 0
        for doc in claimed_docs:
            try:
                await self._embed_stm_document(doc)
                self._clear_stm_claim(doc["_id"])
                processed += 1
            except Exception as exc:
                logger.error("Failed to embed STM document %s: %s", doc.get("_id"), exc)
                self._release_stm_claims([doc["_id"]])

        if processed > 0:
            logger.info(
                "Embedded %d/%d STM documents (worker=%s)",
                processed,
                len(claimed_docs),
                self._worker_id,
            )
        return processed

    def _claim_stm_batch(self, limit: int) -> List[Dict[str, Any]]:
        """Atomically claim STM documents for embedding."""
        now = utcnow()
        claim_expiry = now - self._claim_timeout
        claimed: List[Dict[str, Any]] = []

        for _ in range(limit):
            doc = self._stm_col.find_one_and_update(
                {
                    "has_embedding": False,
                    "content": {"$ne": None},
                    "$or": [
                        {"_embedding_claimed_at": None},
                        {"_embedding_claimed_at": {"$exists": False}},
                        {"_embedding_claimed_at": {"$lt": claim_expiry}},
                    ],
                },
                {
                    "$set": {
                        "_embedding_claimed_at": now,
                        "_embedding_claimed_by": self._worker_id,
                    }
                },
                sort=[("timestamp", 1)],
            )
            if doc is None:
                break
            claimed.append(doc)

        if claimed:
            logger.debug(
                "Claimed %d STM documents for embedding (worker=%s)",
                len(claimed),
                self._worker_id,
            )
        return claimed

    def _release_stm_claims(self, doc_ids: List[Any]) -> None:
        """Release claims on STM documents."""
        if not doc_ids:
            return
        self._stm_col.update_many(
            {"_id": {"$in": doc_ids}, "_embedding_claimed_by": self._worker_id},
            {"$unset": {"_embedding_claimed_at": "", "_embedding_claimed_by": ""}},
        )

    def _clear_stm_claim(self, doc_id: Any) -> None:
        """Clear claim fields after successful STM embedding."""
        self._stm_col.update_one(
            {"_id": doc_id},
            {"$unset": {"_embedding_claimed_at": "", "_embedding_claimed_by": ""}},
        )

    async def _embed_stm_document(self, doc: Dict[str, Any]) -> None:
        """Embed a single STM document."""
        content = doc.get("content")
        if not content or not content.strip():
            logger.debug("Skipping empty STM content for document %s", doc.get("_id"))
            return

        embedding = await self._generate_embedding(content, doc.get("_id"))

        update_stm_embedding(
            db=self._db,
            stm_id=doc["_id"],
            org_id=doc["org_id"],
            embedding=embedding,
            embedding_model_id=self._embedder.model_id,
        )

        logger.debug(
            "Embedded STM document %s (dim=%d, model=%s)",
            doc["_id"],
            len(embedding),
            self._embedder.model_id,
        )

    async def embed_stm_docs_for_session(
        self,
        session_id: str,
        org_id: str,
        user_id: str,
        project_id: str,
    ) -> int:
        """Batch-embed unembedded STM docs for {org_id, session_id, user_id, project_id}.

        Fetches and embeds docs in chunks of self._batch_size to bound memory
        usage and stay within embed_batch API limits.  No atomic claiming is
        needed — the task queue guarantees at-most-one active check_promotion
        task per {org_id, session_id, user_id, project_id}.

        Returns the number of documents successfully embedded.
        """
        query: Dict[str, Any] = {
            "session_id": session_id,
            "org_id": org_id,
            "user_id": user_id,
            "project_id": project_id,
            "has_embedding": False,
            "content": {"$ne": None},
        }

        total_processed = 0
        last_id = None

        while True:
            page_query = dict(query)
            if last_id is not None:
                page_query["_id"] = {"$gt": last_id}

            docs = list(self._stm_col.find(page_query).sort("_id", 1).limit(self._batch_size))
            if not docs:
                break

            last_id = docs[-1]["_id"]

            texts_with_docs = [
                (doc, doc["content"].strip()) for doc in docs if doc.get("content", "").strip()
            ]
            if not texts_with_docs:
                continue

            docs_to_embed, texts = zip(*texts_with_docs)

            try:
                embeddings = await self._generate_embeddings_batch(list(texts))
            except Exception as exc:
                logger.warning(
                    "Batch STM embedding failed for session=%s chunk ending at %s: %s",
                    session_id,
                    last_id,
                    exc,
                )
                break

            for doc, embedding in zip(docs_to_embed, embeddings):
                try:
                    update_stm_embedding(
                        db=self._db,
                        stm_id=doc["_id"],
                        org_id=doc["org_id"],
                        embedding=embedding,
                        embedding_model_id=self._embedder.model_id,
                    )
                    total_processed += 1
                except Exception as exc:
                    logger.warning(
                        "Failed to write STM embedding for doc %s: %s", doc.get("_id"), exc
                    )

        if total_processed > 0:
            logger.info(
                "Batch-embedded %d STM docs for session=%s",
                total_processed,
                session_id,
            )
        return total_processed

    # ═══════════════════════════════════════════════════════════════════
    # Semantic Processing (with atomic claiming)
    # ═══════════════════════════════════════════════════════════════════

    async def process_pending_semantic(self) -> int:
        """Process pending semantic memory embeddings using batch API.

        Uses atomic claiming to prevent duplicate work across multiple workers.
        """
        # Claim documents atomically
        claimed_docs = self._claim_semantic_batch(limit=self._batch_size)
        if not claimed_docs:
            return 0

        # Extract content and filter empty
        # FIX: SemanticDB uses "content" field, not "text"
        texts_with_docs = [
            (doc, doc.get("content", "").strip())
            for doc in claimed_docs
            if doc.get("content", "").strip()
        ]

        if not texts_with_docs:
            # Release claims for docs with no content
            self._release_semantic_claims([doc["_id"] for doc in claimed_docs])
            return 0

        docs_to_embed, texts = zip(*texts_with_docs)

        try:
            # Batch embed all texts at once
            embeddings = await self._generate_embeddings_batch(list(texts))

            # Update each document (embedding update also clears the claim)
            processed = 0
            for doc, embedding in zip(docs_to_embed, embeddings):
                try:
                    update_semantic_embedding(
                        db=self._db,
                        semantic_id=doc["_id"],
                        org_id=doc["org_id"],
                        embedding=embedding,
                        embedding_model_id=self._embedder.model_id,
                    )
                    # Clear claim fields after successful embedding
                    self._clear_semantic_claim(doc["_id"])
                    processed += 1
                except Exception as exc:
                    logger.error("Failed to update semantic embedding %s: %s", doc["_id"], exc)
                    # Release claim so another worker can retry
                    self._release_semantic_claims([doc["_id"]])

            if processed > 0:
                logger.info(
                    "Batch embedded %d/%d semantic documents (worker=%s)",
                    processed,
                    len(claimed_docs),
                    self._worker_id,
                )
            return processed

        except Exception as exc:
            logger.error("Batch semantic embedding failed: %s", exc)
            # Release all claims so another worker can retry
            self._release_semantic_claims([doc["_id"] for doc in claimed_docs])
            return 0

    def _claim_semantic_batch(self, limit: int) -> List[Dict[str, Any]]:
        """Atomically claim semantic documents for embedding.

        Uses find_one_and_update to claim one document at a time,
        preventing race conditions between workers.
        """
        now = utcnow()
        claim_expiry = now - self._claim_timeout
        claimed: List[Dict[str, Any]] = []

        for _ in range(limit):
            # Atomically claim one unclaimed (or expired claim) document
            # FIX: Query uses "content" field to match SemanticDB model (was "text")
            doc = self._semantic_col.find_one_and_update(
                {
                    "has_embedding": False,
                    "content": {"$ne": None},
                    "$or": [
                        {"_embedding_claimed_at": None},
                        {"_embedding_claimed_at": {"$exists": False}},
                        {"_embedding_claimed_at": {"$lt": claim_expiry}},  # Expired claim
                    ],
                },
                {
                    "$set": {
                        "_embedding_claimed_at": now,
                        "_embedding_claimed_by": self._worker_id,
                    }
                },
                sort=[("timestamp", 1)],
            )
            if doc is None:
                break  # No more documents to claim
            claimed.append(doc)

        if claimed:
            logger.debug(
                "Claimed %d semantic documents for embedding (worker=%s)",
                len(claimed),
                self._worker_id,
            )
        return claimed

    def _release_semantic_claims(self, doc_ids: List[Any]) -> None:
        """Release claims on documents (e.g., on failure)."""
        if not doc_ids:
            return
        self._semantic_col.update_many(
            {"_id": {"$in": doc_ids}, "_embedding_claimed_by": self._worker_id},
            {"$unset": {"_embedding_claimed_at": "", "_embedding_claimed_by": ""}},
        )

    def _clear_semantic_claim(self, doc_id: Any) -> None:
        """Clear claim fields after successful embedding."""
        self._semantic_col.update_one(
            {"_id": doc_id},
            {"$unset": {"_embedding_claimed_at": "", "_embedding_claimed_by": ""}},
        )

    # ═══════════════════════════════════════════════════════════════════
    # Episodic Processing (with atomic claiming)
    # ═══════════════════════════════════════════════════════════════════

    async def process_pending_episodic(self) -> int:
        """Process pending episodic memory embeddings using batch API.

        Uses atomic claiming to prevent duplicate work across multiple workers.
        """
        # Claim documents atomically
        claimed_docs = self._claim_episodic_batch(limit=self._batch_size)
        if not claimed_docs:
            return 0

        # Extract texts (prefer summary_text, fall back to content)
        texts_with_docs = [
            (doc, (doc.get("summary_text") or doc.get("content", "")).strip())
            for doc in claimed_docs
        ]
        texts_with_docs = [(doc, text) for doc, text in texts_with_docs if text]

        if not texts_with_docs:
            # Release claims for docs with no text
            self._release_episodic_claims([doc["_id"] for doc in claimed_docs])
            return 0

        docs_to_embed, texts = zip(*texts_with_docs)

        try:
            # Batch embed all texts at once
            embeddings = await self._generate_embeddings_batch(list(texts))

            # Update each document
            processed = 0
            for doc, embedding in zip(docs_to_embed, embeddings):
                try:
                    update_episodic_embedding(
                        db=self._db,
                        org_id=doc["org_id"],
                        embedding=embedding,
                        id=doc["_id"],
                        embedding_model_id=self._embedder.model_id,
                    )
                    # Clear claim fields after successful embedding
                    self._clear_episodic_claim(doc["_id"])
                    processed += 1
                except Exception as exc:
                    logger.error("Failed to update episodic embedding %s: %s", doc["_id"], exc)
                    # Release claim so another worker can retry
                    self._release_episodic_claims([doc["_id"]])

            if processed > 0:
                logger.info(
                    "Batch embedded %d/%d episodic documents (worker=%s)",
                    processed,
                    len(claimed_docs),
                    self._worker_id,
                )
            return processed

        except Exception as exc:
            logger.error("Batch episodic embedding failed: %s", exc)
            # Release all claims so another worker can retry
            self._release_episodic_claims([doc["_id"] for doc in claimed_docs])
            return 0

    def _claim_episodic_batch(self, limit: int) -> List[Dict[str, Any]]:
        """Atomically claim episodic documents for embedding."""
        now = utcnow()
        claim_expiry = now - self._claim_timeout
        claimed: List[Dict[str, Any]] = []

        for _ in range(limit):
            doc = self._episodic_col.find_one_and_update(
                {
                    "has_embedding": False,
                    "$or": [
                        {"summary_text": {"$nin": [None, ""]}},
                        {"content": {"$nin": [None, ""]}},
                    ],
                    "$and": [
                        {
                            "$or": [
                                {"_embedding_claimed_at": None},
                                {"_embedding_claimed_at": {"$exists": False}},
                                {"_embedding_claimed_at": {"$lt": claim_expiry}},
                            ]
                        }
                    ],
                },
                {
                    "$set": {
                        "_embedding_claimed_at": now,
                        "_embedding_claimed_by": self._worker_id,
                    }
                },
                sort=[("timestamp", 1)],
            )
            if doc is None:
                break
            claimed.append(doc)

        if claimed:
            logger.debug(
                "Claimed %d episodic documents for embedding (worker=%s)",
                len(claimed),
                self._worker_id,
            )
        return claimed

    def _release_episodic_claims(self, doc_ids: List[Any]) -> None:
        """Release claims on documents (e.g., on failure)."""
        if not doc_ids:
            return
        self._episodic_col.update_many(
            {"_id": {"$in": doc_ids}, "_embedding_claimed_by": self._worker_id},
            {"$unset": {"_embedding_claimed_at": "", "_embedding_claimed_by": ""}},
        )

    def _clear_episodic_claim(self, doc_id: Any) -> None:
        """Clear claim fields after successful embedding."""
        self._episodic_col.update_one(
            {"_id": doc_id},
            {"$unset": {"_embedding_claimed_at": "", "_embedding_claimed_by": ""}},
        )

    # ═══════════════════════════════════════════════════════════════════
    # Taxonomic Processing (with atomic claiming)
    # ═══════════════════════════════════════════════════════════════════

    async def process_pending_taxonomic(self) -> int:
        """Process pending taxonomic memory embeddings using batch API.

        Taxonomic embeddings are generated from "term: definition" format
        to enable vector search for domain terminology.

        Uses atomic claiming to prevent duplicate work across multiple workers.
        """
        # Claim documents atomically
        claimed_docs = self._claim_taxonomic_batch(limit=self._batch_size)
        if not claimed_docs:
            return 0

        # Extract texts: "term: definition" format for embedding
        texts_with_docs = []
        for doc in claimed_docs:
            term = doc.get("term", "").strip()
            definition = doc.get("definition", "").strip()
            if term and definition:
                # Format: "term: definition" for semantic embedding
                text = f"{term}: {definition}"
                texts_with_docs.append((doc, text))

        if not texts_with_docs:
            # Release claims for docs with no valid content
            self._release_taxonomic_claims([doc["_id"] for doc in claimed_docs])
            return 0

        docs_to_embed, texts = zip(*texts_with_docs)

        try:
            # Batch embed all texts at once
            embeddings = await self._generate_embeddings_batch(list(texts))

            # Update each document
            processed = 0
            for doc, embedding in zip(docs_to_embed, embeddings):
                try:
                    update_taxonomic_embedding(
                        db=self._db,
                        taxonomic_id=doc["_id"],
                        org_id=doc["org_id"],
                        embedding=embedding,
                        embedding_model_id=self._embedder.model_id,
                    )
                    # Clear claim fields after successful embedding
                    self._clear_taxonomic_claim(doc["_id"])
                    processed += 1
                except Exception as exc:
                    logger.error("Failed to update taxonomic embedding %s: %s", doc["_id"], exc)
                    # Release claim so another worker can retry
                    self._release_taxonomic_claims([doc["_id"]])

            if processed > 0:
                logger.info(
                    "Batch embedded %d/%d taxonomic documents (worker=%s)",
                    processed,
                    len(claimed_docs),
                    self._worker_id,
                )
            return processed

        except Exception as exc:
            logger.error("Batch taxonomic embedding failed: %s", exc)
            # Release all claims so another worker can retry
            self._release_taxonomic_claims([doc["_id"] for doc in claimed_docs])
            return 0

    def _claim_taxonomic_batch(self, limit: int) -> List[Dict[str, Any]]:
        """Atomically claim taxonomic documents for embedding.

        Uses find_one_and_update to claim one document at a time,
        preventing race conditions between workers.
        """
        now = utcnow()
        claim_expiry = now - self._claim_timeout
        claimed: List[Dict[str, Any]] = []

        for _ in range(limit):
            # Atomically claim one unclaimed (or expired claim) document
            doc = self._taxonomic_col.find_one_and_update(
                {
                    "has_embedding": False,
                    "deleted": {"$ne": True},
                    "term": {"$nin": [None, ""]},
                    "definition": {"$nin": [None, ""]},
                    "$or": [
                        {"_embedding_claimed_at": None},
                        {"_embedding_claimed_at": {"$exists": False}},
                        {"_embedding_claimed_at": {"$lt": claim_expiry}},  # Expired claim
                    ],
                },
                {
                    "$set": {
                        "_embedding_claimed_at": now,
                        "_embedding_claimed_by": self._worker_id,
                    }
                },
                sort=[("timestamp", 1)],
            )
            if doc is None:
                break  # No more documents to claim
            claimed.append(doc)

        if claimed:
            logger.debug(
                "Claimed %d taxonomic documents for embedding (worker=%s)",
                len(claimed),
                self._worker_id,
            )
        return claimed

    def _release_taxonomic_claims(self, doc_ids: List[Any]) -> None:
        """Release claims on taxonomic documents (e.g., on failure)."""
        if not doc_ids:
            return
        self._taxonomic_col.update_many(
            {"_id": {"$in": doc_ids}, "_embedding_claimed_by": self._worker_id},
            {"$unset": {"_embedding_claimed_at": "", "_embedding_claimed_by": ""}},
        )

    def _clear_taxonomic_claim(self, doc_id: Any) -> None:
        """Clear claim fields after successful taxonomic embedding."""
        self._taxonomic_col.update_one(
            {"_id": doc_id},
            {"$unset": {"_embedding_claimed_at": "", "_embedding_claimed_by": ""}},
        )

    # ═══════════════════════════════════════════════════════════════════
    # Shared Embedding Generation
    # ═══════════════════════════════════════════════════════════════════

    async def _generate_embedding(self, text: str, doc_id: Any) -> List[float]:
        """Generate single embedding using circuit breaker and thread pool."""
        breaker = get_circuit_breaker(CIRCUIT_BREAKER_EMBEDDING)
        loop = asyncio.get_running_loop()
        executor = self._get_executor()

        try:
            embedding: List[float] = await breaker.call_async(
                loop.run_in_executor, executor, self._embedder.embed, text
            )
            return embedding
        except CircuitBreakerOpen as exc:
            logger.warning("Embedding circuit open, skipping doc %s: %s", doc_id, exc)
            raise

    async def _generate_embeddings_batch(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings in batch using embed_batch for efficiency.

        Most embedding APIs support batch embedding which is more efficient
        than single calls (fewer round trips, potential batching on server).
        """
        if not texts:
            return []

        breaker = get_circuit_breaker(CIRCUIT_BREAKER_EMBEDDING)
        loop = asyncio.get_running_loop()
        executor = self._get_executor()

        try:
            embeddings: List[List[float]] = await breaker.call_async(
                loop.run_in_executor, executor, self._embedder.embed_batch, texts
            )
            return embeddings
        except CircuitBreakerOpen as exc:
            logger.warning("Embedding circuit open during batch: %s", exc)
            raise

    async def handle_task(self, payload: Dict[str, Any]) -> None:
        doc_id = payload.get("doc_id")
        org_id = payload.get("org_id")
        content = payload.get("content")
        collection = payload.get("collection", CORE_STM_COLLECTION)

        if not doc_id or not org_id or not content:
            raise ValueError(
                f"Invalid embedding task payload: missing required fields. "
                f"Required: doc_id, org_id, content. "
                f"Got: doc_id={doc_id}, org_id={org_id}, content={bool(content)}"
            )

        breaker = get_circuit_breaker(CIRCUIT_BREAKER_EMBEDDING)
        loop = asyncio.get_running_loop()
        executor = self._get_executor()

        # Circuit breaker protects embedding service calls
        # Use dedicated thread pool for embedding operations
        embedding = await breaker.call_async(
            loop.run_in_executor, executor, self._embedder.embed, str(content)
        )

        if collection == CORE_STM_COLLECTION:
            update_stm_embedding(
                db=self._db,
                stm_id=str(doc_id),
                org_id=str(org_id),
                embedding=embedding,
                embedding_model_id=self._embedder.model_id,
            )
        else:
            col = get_collection(self._db, collection)
            col.update_one(
                {"_id": doc_id, "org_id": org_id},
                {
                    "$set": {
                        "embedding": embedding,
                        "has_embedding": True,
                        "embedding_model_id": self._embedder.model_id,
                    }
                },
            )

        logger.info("Embedded %s/%s", collection, doc_id)


__all__ = ["EmbeddingHandler"]
