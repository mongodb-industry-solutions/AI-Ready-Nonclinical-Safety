"""
Persistence layer for extraction results.

Provides idempotent ADD, race-safe UPDATE with versioning, and atomic REINFORCE.
Ports ExoMemory's db_operations.py patterns for full parity.
"""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

if TYPE_CHECKING:
    from pymongo.database import Database

from bson import ObjectId
from mongomem_core.common.utils import handle_db_error, safe_object_id, utcnow
from mongomem_core.extraction.config import SemanticExtractionConfig
from mongomem_core.extraction.types import ConsolidationDecision, PersistenceResult
from mongomem_core.extraction.utils import build_reinforce_pipeline
from mongomem_core.models.memory.base import ChunkVisibility
from mongomem_core.storage import get_collection
from mongomem_core.storage.collections import SemanticMemoryCollection

logger = logging.getLogger(__name__)

# Use canonical collection reference from storage module
_SEMANTIC_COL = SemanticMemoryCollection()


# ═══════════════════════════════════════════════════════════════════════════════
# Extraction ID Generation
# ═══════════════════════════════════════════════════════════════════════════════


def generate_extraction_id(
    source_id: str,
    content: str,
    idempotency_key: Optional[str] = None,
) -> str:
    """
    Generate SHA-256 hash for idempotent writes.

    The extraction_id uniquely identifies an extraction from a specific source
    and content combination, preventing duplicate inserts.

    Args:
        source_id: Source reference (e.g., snapshot ID)
        content: Extracted content text
        idempotency_key: Optional additional key for uniqueness

    Returns:
        SHA-256 hash string
    """
    data = f"{source_id}_{content}"
    if idempotency_key:
        data = f"{data}_{idempotency_key}"
    return hashlib.sha256(data.encode()).hexdigest()


def generate_semantic_label(
    source_id: str,
    content: str,
    org_id: str,
    prefix: str = "sem",
) -> str:
    """
    Generate deterministic label from content hash.

    Args:
        source_id: Source reference (snapshot ID)
        content: Memory content text
        org_id: Organization ID
        prefix: Label prefix (default: "sem")

    Returns:
        Deterministic label string
    """
    content_hash = hashlib.sha256(f"{source_id}_{content}_{org_id}".encode()).hexdigest()[:8]
    return f"{prefix}_{content_hash}"


def _validate_extraction_for_persistence(extraction: Any) -> bool:
    """
    Validate extraction has required fields for persistence.

    Args:
        extraction: ScoredExtraction to validate

    Returns:
        True if valid, False otherwise
    """
    if not extraction.content or not extraction.content.strip():
        logger.warning("Extraction missing content")
        return False
    if not extraction.embedding:
        logger.warning("Extraction missing embedding")
        return False
    return True


# ═══════════════════════════════════════════════════════════════════════════════
# Idempotent ADD
# ═══════════════════════════════════════════════════════════════════════════════


def perform_add(
    db: "Database",
    decision: ConsolidationDecision,
    org_id: str,
    user_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    embedding_model_id: str,
    visibility: ChunkVisibility = ChunkVisibility.PRIVATE,
    project_id: Optional[str] = None,
) -> Optional[str]:
    """
    Idempotent ADD using extraction_id.

    Uses update_one with upsert and $setOnInsert for race-safety.
    If a document with the same extraction_id already exists, returns None
    (idempotent - no duplicate created).

    Args:
        db: MongoDB database instance
        decision: Consolidation decision with extraction
        org_id: Organization ID
        user_id: User ID
        source_id: Source reference (snapshot ID)
        extraction_timestamp: When extraction was performed
        embedding_model_id: Embedding model used

    Returns:
        Created document ID string, or None if duplicate detected
    """
    col = get_collection(_SEMANTIC_COL, db)
    extraction = decision.extraction

    # Validate extraction before persistence
    if not _validate_extraction_for_persistence(extraction):
        logger.warning("Invalid extraction for ADD, skipping")
        return None

    extraction_id = generate_extraction_id(source_id, extraction.content)
    label = generate_semantic_label(source_id, extraction.content, org_id)

    # Build contextual_metadata with scoring info (ExoMemory parity)
    contextual_metadata = {
        "citation_score": extraction.citation_score,
        "llm_confidence_score": extraction.confidence,
        "combined_score": extraction.combined_score,
        "cited_text": extraction.cited_text,
        "reinforcement_sources": [],  # ExoMemory stores this here
        **extraction.metadata,
    }

    # Build document
    now = utcnow()
    new_id = ObjectId()
    doc = {
        "_id": new_id,
        "org_id": org_id,
        "user_id": user_id,
        "label": label,
        "content": extraction.content,
        "extraction_id": extraction_id,
        "source": source_id,  # ExoMemory uses "source" not "source_id"
        "citations": extraction.citations,
        "embedding": extraction.embedding,
        "embedding_model_id": embedding_model_id,
        "has_embedding": True,
        # Versioning fields
        "version": 1,
        "is_latest": True,
        "memory_lineage_id": str(new_id),
        "previous_version_id": None,
        # Reinforcement fields
        "reinforcement_count": 0,
        "last_reinforced_at": None,
        "reinforcement_history": [],
        # Timestamps
        "timestamp": extraction_timestamp,  # ExoMemory uses "timestamp"
        "created_at": now,
        "updated_at": now,
        # Contextual metadata (includes scoring and cited_text)
        "contextual_metadata": contextual_metadata,
        "extraction_source": "agent_mediated",
        # Visibility/scope
        "visibility": visibility.value,
        "project_id": project_id,
    }

    # Validate extraction_id before upsert (defense against partial index edge case)
    if not extraction_id or not isinstance(extraction_id, str):
        logger.error("Invalid extraction_id: %s", extraction_id)
        return None

    # Idempotent upsert - only inserts if no document with extraction_id exists
    with handle_db_error(
        operation="update_one",
        collection=_SEMANTIC_COL.name,
        log_message="Failed to perform idempotent ADD: extraction_id=%s org=%s",
        log_args_tuple=(extraction_id, org_id),
    ):
        result = col.update_one(
            {"extraction_id": extraction_id, "org_id": org_id},
            {"$setOnInsert": doc},
            upsert=True,
        )

        if result.upserted_id:
            logger.debug("Created new semantic memory: %s", result.upserted_id)
            return str(result.upserted_id)
        elif result.matched_count > 0:
            logger.info("Duplicate extraction detected, skipping (idempotent)")
            return None

    return None


# ═══════════════════════════════════════════════════════════════════════════════
# Race-Safe UPDATE with Versioning
# ═══════════════════════════════════════════════════════════════════════════════


def perform_update(
    db: "Database",
    decision: ConsolidationDecision,
    org_id: str,
    user_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    embedding_model_id: str,
    visibility: ChunkVisibility = ChunkVisibility.PRIVATE,
    project_id: Optional[str] = None,
) -> Optional[Tuple[str, str]]:
    """
    Version-aware UPDATE with comprehensive race condition handling.

    Flow:
    1. Fetch existing doc (is_latest=True)
    2. Check idempotency - was this exact update already applied?
    3. Insert new version with is_latest=True
    4. Atomically mark old as is_latest=False
    5. Handle race: if another worker already updated, resolve by timestamp
    6. Cleanup: if step 4 fails, mark new version as not latest

    Port of ExoMemory's perform_update_memory_operation().

    Args:
        db: MongoDB database instance
        decision: Consolidation decision with extraction and existing_id
        org_id: Organization ID
        user_id: User ID
        source_id: Source reference (snapshot ID)
        extraction_timestamp: When extraction was performed
        embedding_model_id: Embedding model used

    Returns:
        Tuple of (new_doc_id, old_doc_id) if updated, or None if failed/idempotent
    """
    col = get_collection(_SEMANTIC_COL, db)
    extraction = decision.extraction
    existing_id = decision.existing_id

    if not existing_id:
        logger.warning("UPDATE decision missing existing_id")
        return None

    # Validate extraction before persistence
    if not _validate_extraction_for_persistence(extraction):
        logger.warning("Invalid extraction for UPDATE, skipping")
        return None

    # Convert existing_id to ObjectId
    try:
        query_id = ObjectId(existing_id)
    except Exception as e:
        logger.warning("Invalid ObjectId format: %s - %s", existing_id, e)
        return None

    # Step 1: Fetch existing document
    try:
        existing = col.find_one(
            {
                "_id": query_id,
                "org_id": org_id,
                "user_id": user_id,  # ExoMemory includes user_id check
                "is_latest": True,
            }
        )
    except Exception as e:
        logger.error("Failed to fetch existing document %s: %s", existing_id, e)
        return None

    if not existing:
        logger.warning(
            "Existing document %s not found or not latest version (org_id=%s, user_id=%s)",
            existing_id,
            org_id,
            user_id,
        )
        return None

    # Extract lineage info
    memory_lineage_id = existing.get("memory_lineage_id") or str(existing["_id"])
    new_version = existing.get("version", 1) + 1

    # Step 2: Check idempotency - was this exact update already applied?
    extraction_id = generate_extraction_id(source_id, extraction.content)
    label = generate_semantic_label(source_id, extraction.content, org_id)

    existing_with_extraction_id = col.find_one(
        {
            "extraction_id": extraction_id,
            "memory_lineage_id": memory_lineage_id,
            "org_id": org_id,
        },
        projection={"_id": 1, "version": 1, "is_latest": 1},
    )

    if existing_with_extraction_id:
        logger.info(
            "UPDATE idempotency: Version %s with extraction_id %s already exists",
            existing_with_extraction_id["_id"],
            extraction_id,
        )
        return (str(existing_with_extraction_id["_id"]), existing_id)

    # Step 3: Build and insert new version document
    now = utcnow()

    # Build contextual_metadata with scoring info
    contextual_metadata = {
        "citation_score": extraction.citation_score,
        "llm_confidence_score": extraction.confidence,
        "combined_score": extraction.combined_score,
        "cited_text": extraction.cited_text,
        # Preserve existing contextual_metadata fields
        **existing.get("contextual_metadata", {}),
        **extraction.metadata,
    }

    new_doc = {
        "org_id": org_id,
        "user_id": user_id,
        "label": label,
        "content": extraction.content,
        "extraction_id": extraction_id,
        "source": source_id,
        "citations": extraction.citations,
        "embedding": extraction.embedding,
        "embedding_model_id": embedding_model_id,
        "has_embedding": True,
        # Versioning fields
        "version": new_version,
        "is_latest": True,
        "memory_lineage_id": memory_lineage_id,
        "previous_version_id": existing_id,
        # Copy reinforcement fields from existing
        "reinforcement_count": existing.get("reinforcement_count", 0),
        "last_reinforced_at": existing.get("last_reinforced_at"),
        "reinforcement_history": existing.get("reinforcement_history", []),
        # Timestamps
        "timestamp": extraction_timestamp,
        "created_at": existing.get("created_at", now),  # Preserve original
        "updated_at": now,
        # Contextual metadata
        "contextual_metadata": contextual_metadata,
        "extraction_source": "agent_mediated",
        # Visibility/scope
        "visibility": visibility.value,
        "project_id": project_id,
    }

    try:
        insert_result = col.insert_one(new_doc)
        new_doc_id = str(insert_result.inserted_id)
        logger.debug(
            "Inserted new version %s for lineage %s (version=%d)",
            new_doc_id,
            memory_lineage_id,
            new_version,
        )
    except Exception as e:
        logger.error("Failed to insert new version: %s", e)
        return None

    # Step 4: Atomically mark old document as superseded
    try:
        update_result = col.update_one(
            {
                "_id": query_id,
                "org_id": org_id,
                "user_id": user_id,
                "is_latest": True,  # Race condition guard
            },
            {
                "$set": {
                    "is_latest": False,
                    "updated_at": now,
                    "contextual_metadata.superseded_by_snapshot": source_id,
                    "contextual_metadata.superseded_by_version_id": new_doc_id,
                }
            },
        )
    except Exception as e:
        # CRITICAL: Update failed - cleanup new version to prevent data corruption
        logger.error(
            "Failed to mark old version %s as superseded: %s. Cleaning up new version %s.",
            existing_id,
            e,
            new_doc_id,
        )
        try:
            col.update_one(
                {"_id": insert_result.inserted_id},
                {
                    "$set": {
                        "is_latest": False,
                        "contextual_metadata.superseded_by_update_failure": True,
                        "contextual_metadata.update_failure_reason": str(e)[:500],
                    }
                },
            )
            logger.info("Cleaned up new version %s after update failure", new_doc_id)
        except Exception as cleanup_error:
            logger.error(
                "CRITICAL: Cleanup failed for %s: %s. "
                "Multiple is_latest=True may exist for lineage %s.",
                new_doc_id,
                cleanup_error,
                memory_lineage_id,
            )
        return None

    # Step 5: Handle race condition
    if update_result.matched_count == 0:
        # Another worker already updated - race detected
        logger.warning(
            "Race condition detected: memory %s was already updated. Resolving by timestamp.",
            existing_id,
        )

        try:
            # Find the competing version (the one that won the race)
            competing_version = col.find_one(
                {
                    "memory_lineage_id": memory_lineage_id,
                    "is_latest": True,
                    "_id": {"$ne": insert_result.inserted_id},
                },
                projection={"_id": 1, "timestamp": 1, "updated_at": 1},
            )

            if not competing_version:
                logger.warning(
                    "Race condition but no competing latest version found. "
                    "Keeping current version as latest."
                )
            else:
                # Compare timestamps - newer wins
                competing_timestamp = competing_version.get("timestamp") or competing_version.get(
                    "updated_at"
                )
                our_timestamp = extraction_timestamp

                if our_timestamp and competing_timestamp and our_timestamp > competing_timestamp:
                    # Our version is newer - mark competing as not latest
                    logger.info(
                        "Version %s is newer (%s > %s). Marking competing %s as not latest.",
                        new_doc_id,
                        our_timestamp,
                        competing_timestamp,
                        competing_version["_id"],
                    )
                    col.update_one(
                        {"_id": competing_version["_id"]},
                        {
                            "$set": {
                                "is_latest": False,
                                "contextual_metadata.superseded_by_newer_version": new_doc_id,
                                "contextual_metadata.superseded_at": now,
                            }
                        },
                    )
                else:
                    # Competing version is newer - mark ours as not latest
                    logger.info(
                        "Competing version %s is newer. Marking %s as not latest.",
                        competing_version["_id"],
                        new_doc_id,
                    )
                    col.update_one(
                        {"_id": insert_result.inserted_id},
                        {
                            "$set": {
                                "is_latest": False,
                                "contextual_metadata.superseded_by_race_condition": True,
                                "contextual_metadata.superseded_by_newer_version": str(
                                    competing_version["_id"]
                                ),
                            }
                        },
                    )
                    return (new_doc_id, existing_id)  # Still return - doc created

        except Exception as race_error:
            logger.error(
                "CRITICAL: Failed to resolve race condition for %s: %s. "
                "Multiple is_latest=True may exist for lineage %s.",
                new_doc_id,
                race_error,
                memory_lineage_id,
            )

    elif update_result.modified_count > 0:
        logger.info(
            "Successfully updated memory %s to version %s: new=%s, source=%s",
            existing_id,
            new_version,
            new_doc_id,
            source_id,
        )
    else:
        logger.debug(
            "Memory %s matched but not modified (possibly already in correct state)",
            existing_id,
        )

    return (new_doc_id, existing_id)


# ═══════════════════════════════════════════════════════════════════════════════
# Atomic REINFORCE
# ═══════════════════════════════════════════════════════════════════════════════


def perform_reinforce(
    db: "Database",
    decision: ConsolidationDecision,
    org_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    reinforcement_history_limit: int = 20,
    user_id: Optional[str] = None,
) -> Optional[str]:
    """
    Atomic reinforcement using MongoDB aggregation pipeline.

    This function is fully atomic and race-condition safe:
    - Uses MongoDB aggregation pipeline for atomic read-modify-write
    - Prevents duplicate snapshot IDs using $cond and $in
    - Uses $slice for atomic array trimming
    - All operations are performed in a single atomic update
    - Safe for concurrent execution by multiple workers
    - Idempotent: same snapshot ID won't increment count twice

    Port of ExoMemory's perform_noop_memory_operation().

    Args:
        db: MongoDB database instance
        decision: Consolidation decision with existing_id
        org_id: Organization ID
        source_id: Source reference (snapshot ID)
        extraction_timestamp: When extraction was performed
        reinforcement_history_limit: Max reinforcement history entries to keep
        user_id: Optional user ID for additional filtering

    Returns:
        Document ID if reinforced, or None if failed
    """
    col = get_collection(_SEMANTIC_COL, db)
    existing_id = decision.existing_id

    # Use safe_object_id for cleaner validation
    query_id = safe_object_id(existing_id, "REINFORCE")
    if not query_id:
        return None

    # Build atomic reinforcement pipeline using shared utility
    # ExoMemory stores reinforcement_sources in contextual_metadata
    update_pipeline = build_reinforce_pipeline(
        source_id=source_id,
        timestamp=extraction_timestamp,
        sources_field="contextual_metadata.reinforcement_sources",
        history_field="reinforcement_history",
        count_field="reinforcement_count",
        last_reinforced_field="last_reinforced_at",
        history_limit=reinforcement_history_limit,
        extra_set_stages={
            # Semantic also updates updated_at unconditionally
            "updated_at": extraction_timestamp,
        },
    )

    # Build query filter
    query_filter: Dict[str, Any] = {"_id": query_id, "org_id": org_id}
    if user_id:
        query_filter["user_id"] = user_id

    try:
        result = col.update_one(query_filter, update_pipeline)
    except Exception as e:
        logger.error("Failed to reinforce document %s: %s", existing_id, e)
        return None

    if result.matched_count > 0:
        if result.modified_count > 0:
            logger.info(
                "Tracked reinforcement for semantic memory %s: source_snapshot=%s",
                existing_id,
                source_id,
            )
        else:
            logger.debug(
                "Memory %s already reinforced by snapshot %s - skipping (idempotent)",
                existing_id,
                source_id,
            )
        return existing_id

    logger.warning(
        "Memory %s not found for reinforcement (org_id=%s)",
        existing_id,
        org_id,
    )
    return None


# ═══════════════════════════════════════════════════════════════════════════════
# Main apply_decisions Function
# ═══════════════════════════════════════════════════════════════════════════════


def apply_decisions(
    db: "Database",
    decisions: List[ConsolidationDecision],
    org_id: str,
    user_id: str,
    source_id: str,
    extraction_timestamp: datetime,
    embedding_model_id: str,
    config: SemanticExtractionConfig,
    visibility: ChunkVisibility = ChunkVisibility.PRIVATE,
    project_id: Optional[str] = None,
) -> PersistenceResult:
    """
    Apply all consolidation decisions with full tracking.

    Args:
        db: MongoDB database instance
        decisions: List of consolidation decisions
        org_id: Organization ID
        user_id: User ID
        source_id: Source reference (snapshot ID)
        extraction_timestamp: When extraction was performed
        embedding_model_id: Embedding model used
        config: Extraction configuration

    Returns:
        PersistenceResult with counts and IDs of affected documents
    """
    result = PersistenceResult()

    for decision in decisions:
        try:
            if decision.action == "ADD":
                doc_id = perform_add(
                    db=db,
                    decision=decision,
                    org_id=org_id,
                    user_id=user_id,
                    source_id=source_id,
                    extraction_timestamp=extraction_timestamp,
                    embedding_model_id=embedding_model_id,
                    visibility=visibility,
                    project_id=project_id,
                )
                if doc_id:
                    result.added += 1
                    result.created_ids.append(doc_id)
                else:
                    result.skipped += 1  # Idempotent duplicate

            elif decision.action == "UPDATE":
                ids = perform_update(
                    db=db,
                    decision=decision,
                    org_id=org_id,
                    user_id=user_id,
                    source_id=source_id,
                    extraction_timestamp=extraction_timestamp,
                    embedding_model_id=embedding_model_id,
                    visibility=visibility,
                    project_id=project_id,
                )
                if ids:
                    result.updated += 1
                    result.updated_new_version_ids.append(ids[0])
                    result.updated_old_version_ids.append(ids[1])
                else:
                    result.skipped += 1

            elif decision.action == "REINFORCE":
                doc_id = perform_reinforce(
                    db=db,
                    decision=decision,
                    org_id=org_id,
                    source_id=source_id,
                    extraction_timestamp=extraction_timestamp,
                    reinforcement_history_limit=config.reinforcement_history_limit,
                    user_id=user_id,  # Pass for filtering
                )
                if doc_id:
                    result.reinforced += 1
                    result.reinforced_ids.append(doc_id)
                else:
                    result.skipped += 1

            elif decision.action == "DUPLICATE":
                result.skipped += 1

        except Exception as e:
            logger.warning(
                "%s failed for decision %s: %s",
                decision.action,
                decision.extraction.content[:50],
                e,
            )
            result.errors.append(f"{decision.action}: {e}")

    return result


__all__ = [
    "generate_extraction_id",
    "generate_semantic_label",
    "perform_add",
    "perform_update",
    "perform_reinforce",
    "apply_decisions",
]
