"""
Shared utilities for extraction persistence operations.

This module provides reusable building blocks for the extraction pipeline,
reducing code duplication across semantic, episodic, and taxonomic persistence.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional


def build_reinforce_pipeline(
    source_id: str,
    timestamp: datetime,
    *,
    sources_field: str = "reinforcement_sources",
    history_field: str = "reinforcement_history",
    count_field: str = "reinforcement_count",
    last_reinforced_field: str = "last_reinforced_at",
    history_limit: int = 20,
    extra_set_stages: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """
    Build an atomic idempotent reinforcement aggregation pipeline.

    This utility generates the common MongoDB aggregation pipeline stages
    used for reinforcement across all memory types. The pipeline ensures:

    1. Idempotency: Same source won't increment count twice
    2. Atomicity: All updates happen in a single operation
    3. History tracking: Capped list of reinforcement timestamps
    4. Source tracking: Capped list of sources that reinforced

    The generated pipeline checks if the source already reinforced,
    then conditionally updates fields only if it's a new source.

    Args:
        source_id: Source reference (snapshot ID) that triggered reinforcement
        timestamp: When the reinforcement occurred
        sources_field: Field path for tracking reinforcement sources
            (e.g., "reinforcement_sources" or "metadata.reinforcement_sources")
        history_field: Field path for reinforcement history timestamps
        count_field: Field path for reinforcement count
        last_reinforced_field: Field path for last reinforced timestamp
        history_limit: Maximum entries to keep in history/sources lists
        extra_set_stages: Additional $set operations to include in step 2
            (e.g., merging related_terms for taxonomic)

    Returns:
        List of aggregation pipeline stages ready for find_one_and_update()

    Example:
        >>> pipeline = build_reinforce_pipeline(
        ...     source_id="snap-123",
        ...     timestamp=datetime.now(timezone.utc),
        ...     sources_field="metadata.reinforcement_sources",
        ...     history_limit=10,
        ... )
        >>> col.find_one_and_update(
        ...     {"_id": doc_id},
        ...     pipeline,
        ...     return_document=ReturnDocument.AFTER,
        ... )

    Note:
        For type-specific merges (e.g., taxonomic evidence_spans),
        pass additional stages via extra_set_stages parameter.
    """
    # Build the $ifNull path for nested fields
    sources_ifnull = f"${sources_field}"
    history_ifnull = f"${history_field}"
    count_ifnull = f"${count_field}"

    # Step 1: Check if this source already reinforced this memory
    step1_check_source = {
        "$set": {
            "__source_exists": {
                "$in": [
                    source_id,
                    {"$ifNull": [sources_ifnull, []]},
                ]
            }
        }
    }

    # Step 2: Conditionally update fields based on whether already reinforced
    step2_updates: Dict[str, Any] = {
        # Increment count only if new source
        count_field: {
            "$cond": {
                "if": "$__source_exists",
                "then": f"${count_field}",
                "else": {"$add": [{"$ifNull": [count_ifnull, 0]}, 1]},
            }
        },
        # Update last reinforced timestamp only if new source
        last_reinforced_field: {
            "$cond": {
                "if": "$__source_exists",
                "then": f"${last_reinforced_field}",
                "else": timestamp,
            }
        },
        # Append to history (capped) only if new source
        history_field: {
            "$cond": {
                "if": "$__source_exists",
                "then": f"${history_field}",
                "else": {
                    "$slice": [
                        {
                            "$concatArrays": [
                                {"$ifNull": [history_ifnull, []]},
                                [timestamp],
                            ]
                        },
                        -history_limit,
                    ]
                },
            }
        },
        # Append source to tracking list (capped) only if new source
        sources_field: {
            "$cond": {
                "if": "$__source_exists",
                "then": f"${sources_field}",
                "else": {
                    "$slice": [
                        {
                            "$concatArrays": [
                                {"$ifNull": [sources_ifnull, []]},
                                [source_id],
                            ]
                        },
                        -history_limit,
                    ]
                },
            }
        },
    }

    # Merge any type-specific extra stages
    if extra_set_stages:
        step2_updates.update(extra_set_stages)

    step2_conditional_update = {"$set": step2_updates}

    # Step 3: Clean up temporary field
    step3_cleanup = {"$unset": "__source_exists"}

    return [step1_check_source, step2_conditional_update, step3_cleanup]


def build_array_merge_stage(
    field: str,
    new_values: List[Any],
    *,
    deduplicate: bool = True,
    only_if_new_source: bool = True,
) -> Dict[str, Any]:
    """
    Build a conditional array merge stage for use in reinforcement pipelines.

    This is useful for type-specific fields like taxonomic evidence_spans
    or related_terms that need to be merged during reinforcement.

    Args:
        field: Field path to merge into (e.g., "evidence_spans")
        new_values: New values to merge into the array
        deduplicate: Whether to deduplicate using $setUnion (default: True)
        only_if_new_source: Whether to only merge if __source_exists is False

    Returns:
        A $cond expression suitable for inclusion in a $set stage

    Example:
        >>> extra_stages = {
        ...     "evidence_spans": build_array_merge_stage(
        ...         "evidence_spans",
        ...         [{"start": 0, "end": 10}],
        ...     ),
        ...     "related_terms": build_array_merge_stage(
        ...         "related_terms",
        ...         ["python", "pandas"],
        ...     ),
        ... }
        >>> pipeline = build_reinforce_pipeline(..., extra_set_stages=extra_stages)
    """
    field_ref = f"${field}"
    existing = {"$ifNull": [field_ref, []]}

    if deduplicate:
        # Use $setUnion to merge and deduplicate
        merged = {"$setUnion": [existing, new_values]}
    else:
        # Just concatenate without deduplication
        merged = {"$concatArrays": [existing, new_values]}

    if only_if_new_source:
        return {
            "$cond": {
                "if": "$__source_exists",
                "then": field_ref,
                "else": merged,
            }
        }
    else:
        return merged


__all__ = [
    "build_reinforce_pipeline",
    "build_array_merge_stage",
]
