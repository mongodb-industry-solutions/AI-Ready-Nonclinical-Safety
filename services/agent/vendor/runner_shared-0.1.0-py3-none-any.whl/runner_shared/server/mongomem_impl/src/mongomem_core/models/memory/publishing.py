"""
Publishing metadata models for cross-project knowledge sharing.

These models support the knowledge publishing and sharing features
for episodic, semantic, and taxonomic memories.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field, model_validator


class PublishedScope(str, Enum):
    """Published knowledge visibility scopes."""

    PUBLISHED_SHARED = "PUBLISHED_SHARED"
    PUBLISHED_ORG = "PUBLISHED_ORG"


class ShareableMemoryType(str, Enum):
    """Memory types that can be shared through publishing."""

    TAXONOMIC = "taxonomic"
    SEMANTIC = "semantic"
    EPISODIC = "episodic"
    PROCEDURAL = "procedural"


class PublishingLineageEntry(BaseModel):
    """Lineage entry tracking the source of published knowledge."""

    collection: str
    id: str
    version: int


class PublishingMetadata(BaseModel):
    """
    Publishing metadata for cross-project knowledge sharing.

    Tracks whether a memory item has been published, its scope,
    and lineage information for provenance.
    """

    published: bool = False
    published_scope: Optional[PublishedScope] = None
    published_at: Optional[datetime] = None
    published_by_project: Optional[str] = None
    revoked_at: Optional[datetime] = None
    lineage: Optional[List[PublishingLineageEntry]] = Field(default=None)

    @model_validator(mode="after")
    def validate_publishing_business_rules(self) -> "PublishingMetadata":
        """Validate publishing metadata business rules."""
        # Business rule: published=true requires published_scope and published_by_project
        if self.published:
            if not self.published_scope:
                raise ValueError("published=true requires published_scope to be set")
            if not self.published_by_project:
                raise ValueError("published=true requires published_by_project to be set")

        # Business rule: if not published, scope and group should be None
        if not self.published:
            if self.published_scope is not None:
                raise ValueError("published=false cannot have published_scope set")
            if self.published_by_project is not None:
                raise ValueError("published=false cannot have published_by_project set")

        return self


class ExtractionMetadataMixin:
    """
    Mixin for extraction-related metadata fields.

    These fields are used for dual storage and cohort routing
    in episodic, semantic, and taxonomic memories.
    """

    extraction_id: Optional[str] = Field(
        default=None,
        pattern="^[a-f0-9]{64}$",
        description="SHA-256 hash for idempotent extraction writes",
    )
    extraction_scope: Optional[str] = Field(
        default=None,
        description="Scope of extraction: user_private, agent_shared (cohort), or org_wide",
    )
    contributed_by: Optional[str] = Field(
        default=None,
        description="User ID who contributed this extraction (for cohort analytics)",
    )
    owner_id: Optional[str] = Field(
        default=None,
        description="User ID with permanent access rights to this extraction",
    )
    deleted: bool = Field(
        default=False,
        description="Soft-delete flag for auditability",
    )
    deleted_at: Optional[datetime] = Field(
        default=None,
        description="Timestamp of soft deletion",
    )
    idempotency_key_in: Optional[str] = Field(
        default=None,
        description="Original idempotency key for debugging",
    )


class AgentAttributionMixin:
    """
    Mixin for agent attribution fields for collective intelligence.

    These fields track agent-mediated learning and collective
    intelligence metadata.
    """

    agent_id: Optional[str] = Field(
        default=None,
        description="Agent ID if this knowledge was extracted via agent-mediated learning",
    )
    extraction_source: Optional[str] = Field(
        default=None,
        description="Source of extraction: 'user_direct', 'agent_mediated', 'agent_collective'",
    )
    collective_metadata: Optional[dict] = Field(
        default=None,
        description="Metadata for collective intelligence: contributing_users, confidence, patterns",
    )
