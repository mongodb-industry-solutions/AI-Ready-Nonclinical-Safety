"""
Models for taxonomic memory documents.

Taxonomic memory stores domain-specific terms with definitions and embeddings
for both vector and text search. Each document represents a concept within
a domain that can be retrieved for query expansion or context enrichment.

Key differences from semantic:
- Uses domain+term as the unique key (not label)
- Includes query_expansion flag for retrieval control
- Evidence spans for LLM-extracted entries
- CreationMethod enum for tracking how entry was created
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Union

from bson import ObjectId
from mongomem_core.common.utils import utcnow
from mongomem_core.models.memory.base import (
    BaseMemoryIn,
    ChunkVisibility,
    HasEmbeddings,
)
from mongomem_core.models.memory.publishing import PublishingMetadata
from mongomem_core.models.types import PyObjectId
from pydantic import BaseModel, Field, field_serializer, model_validator


class CreationMethod(str, Enum):
    """Methods for creating taxonomic entries."""

    USER_CREATED = "user_created"
    LLM_EXTRACTION = "llm_extraction"
    SYSTEM_GENERATED = "system_generated"


class TaxonomicIn(BaseMemoryIn, HasEmbeddings):
    """Input model for creating a taxonomic memory entry."""

    # Override default visibility to ORG (taxonomy is typically org-wide)
    visibility: ChunkVisibility = ChunkVisibility.ORG

    # Publishing metadata for cross-group knowledge sharing
    publishing: Optional[PublishingMetadata] = Field(default_factory=PublishingMetadata)

    # Embedding model tracking
    embedding_model_id: Optional[str] = Field(
        default=None,
        description="Model identifier used to generate the embedding",
    )

    # Taxonomic-specific payload fields
    domain: str = Field(..., description="Domain/category for this term")
    term: str = Field(..., description="The term being defined")
    definition: str = Field(..., description="Definition of the term")
    related_terms: List[str] = Field(
        default_factory=list, description="Related terms for semantic linking"
    )
    query_expansion: bool = Field(
        default=True, description="Whether to use this term for query expansion"
    )

    # Performance optimization fields
    search_keywords: Optional[List[str]] = Field(
        default=None, description="Pre-computed keywords for optimized text search"
    )
    complexity_score: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Complexity score for search prioritization and caching",
    )
    usage_frequency: Optional[float] = Field(
        default=0.0, ge=0.0, description="Usage frequency for cache prioritization"
    )

    # Agent attribution fields for collective intelligence
    agent_id: Optional[str] = Field(
        default=None,
        description="Agent ID if this knowledge was extracted via agent-mediated learning",
    )
    extraction_source: Optional[str] = Field(
        default=None,
        description="Source of extraction: 'user_direct', 'agent_mediated', 'agent_collective'",
    )
    collective_metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Metadata for collective intelligence: contributing_users, confidence, patterns",
    )

    # Source tracking fields
    creation_method: CreationMethod = Field(
        default=CreationMethod.USER_CREATED,
        description="Method used to create this taxonomic entry",
    )
    source_agent: Optional[str] = Field(
        default=None,
        description="Agent/model that created this entry (for LLM extractions)",
    )
    user_source: Optional[str] = Field(
        default=None,
        description="User ID who initiated the creation/extraction (for audit trails)",
    )
    source_reference: Optional[str] = Field(
        default=None,
        description="Reference to source document (e.g., snapshot ID)",
    )

    # LLM extraction specific fields
    evidence_spans: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        description="Evidence spans pointing to source content (required for LLM extractions)",
    )
    contextual_metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Metadata about the extraction process (for LLM extractions)",
    )
    confidence_score: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Confidence score for LLM-generated content",
    )

    @model_validator(mode="after")
    def validate_llm_extraction_fields(self) -> "TaxonomicIn":
        """Validate that LLM extractions have required fields (following ExoMemory patterns)."""
        if self.creation_method == CreationMethod.LLM_EXTRACTION:
            if not self.evidence_spans:
                raise ValueError("LLM extractions must include evidence spans")
            if not self.source_agent:
                raise ValueError("LLM extractions must specify the source agent/model")
            if not self.source_reference:
                raise ValueError("LLM extractions must include source reference")
            if not self.user_source:
                raise ValueError("LLM extractions must specify the user source")
        return self


class TaxonomicUpdate(BaseModel):
    """Model for partial updates to taxonomic memory."""

    # Management fields
    visibility: Optional[ChunkVisibility] = None
    project_id: Optional[str] = None
    publishing: Optional[PublishingMetadata] = None

    # Embedding fields
    embedding: Optional[List[float]] = None
    embedding_model_id: Optional[str] = Field(
        default=None,
        description="Model identifier used to generate the embedding",
    )

    # Taxonomic payload fields
    domain: Optional[str] = None
    term: Optional[str] = None
    definition: Optional[str] = None
    related_terms: Optional[List[str]] = None
    query_expansion: Optional[bool] = None

    # Performance optimization fields
    search_keywords: Optional[List[str]] = None
    complexity_score: Optional[float] = None
    usage_frequency: Optional[float] = None

    # Agent attribution fields for updates
    agent_id: Optional[str] = Field(
        default=None,
        description="Agent ID if this knowledge was extracted via agent-mediated learning",
    )
    extraction_source: Optional[str] = Field(
        default=None,
        description="Source of extraction: 'user_direct', 'agent_mediated', 'agent_collective'",
    )
    collective_metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Metadata for collective intelligence: contributing_users, confidence, patterns",
    )

    # Source tracking fields (for updates)
    creation_method: Optional[CreationMethod] = None
    source_agent: Optional[str] = None
    user_source: Optional[str] = None
    source_reference: Optional[str] = None

    # LLM extraction fields (for updates)
    evidence_spans: Optional[List[Dict[str, Any]]] = None
    contextual_metadata: Optional[Dict[str, Any]] = None
    confidence_score: Optional[float] = Field(default=None, ge=0.0, le=1.0)


class TaxonomicBase(TaxonomicIn):
    """Base model with org/user context, versioning, and extraction metadata.

    Includes org_id, user_id, timestamps, version control, and extraction
    metadata which are typically set by the service layer.
    """

    org_id: str = Field(..., description="Organization/tenant ID")
    user_id: str = Field(..., description="Creator of entry")
    timestamp: datetime = Field(default_factory=utcnow, description="Creation time")
    updated_at: datetime = Field(default_factory=utcnow, description="Last-modified time")

    version: int = Field(default=1, description="Version number, increments on each update")
    is_latest: bool = Field(default=True, description="Only the latest version has this flag")

    # Memory Lineage Fields
    memory_lineage_id: Optional[str] = Field(
        default=None, description="Shared ID across all versions of this memory"
    )
    previous_version_id: Optional[str] = Field(
        default=None, description="Reference to previous version for audit trail"
    )

    # Memory Reinforcement & Boosting Fields (lighter for taxonomic)
    reinforcement_count: int = Field(
        default=0,
        ge=0,
        description="Number of times this memory was attempted to be re-created",
    )
    last_reinforced_at: Optional[datetime] = Field(
        default=None, description="Timestamp of the most recent reinforcement"
    )
    reinforcement_history: List[datetime] = Field(
        default_factory=list,
        description="Recent reinforcement timestamps (capped)",
    )
    reinforcement_sources: List[str] = Field(
        default_factory=list,
        description="Source IDs (snapshots) that reinforced this term (capped)",
    )

    # Extraction metadata for dual storage and cohort routing
    extraction_id: Optional[str] = Field(
        default=None,
        pattern="^[a-f0-9]{64}$",
        description="SHA-256 hash for idempotent extraction writes",
    )
    extraction_scope: Optional[Literal["user_private", "agent_shared", "org_wide"]] = Field(
        default=None,
        description="Scope of extraction: user_private, agent_shared (cohort), or org_wide",
    )
    contributed_by: Optional[str] = Field(
        default=None,
        description="User ID who contributed this extraction (for cohort analytics)",
    )
    owner_id: Optional[str] = Field(
        default=None,
        description="User ID with permanent access rights to this extraction",
    )
    deleted: bool = Field(
        default=False,
        description="Soft-delete flag for auditability",
    )
    deleted_at: Optional[datetime] = Field(
        default=None,
        description="Timestamp of soft deletion",
    )
    idempotency_key_in: Optional[str] = Field(
        default=None,
        description="Original idempotency key for debugging",
    )

    @model_validator(mode="before")
    @classmethod
    def set_timestamps(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        now = utcnow()
        values.setdefault("timestamp", now)
        values.setdefault("updated_at", now)
        return values

    model_config = {
        "arbitrary_types_allowed": True,
        "from_attributes": True,
        "populate_by_name": True,
        "use_enum_values": True,
    }


class TaxonomicDB(TaxonomicBase):
    """Database model with MongoDB _id."""

    id: PyObjectId = Field(default_factory=PyObjectId, alias="_id")

    @field_serializer("id", when_used="json")
    def _serialize_id(self, v: ObjectId) -> str:
        return str(v)


class TaxonomicOut(TaxonomicBase):
    """Output model for API responses."""

    id: str = Field(..., alias="_id")

    # Transient field from MongoDB $vectorSearch (not persisted to DB)
    score: Optional[float] = Field(
        default=None,
        description="Vector search similarity score from MongoDB Atlas (query-specific, not stored)",
    )

    @staticmethod
    def of(doc: Union[TaxonomicDB, Dict[str, Any], None]) -> Optional["TaxonomicOut"]:
        if doc is None:
            return None
        if isinstance(doc, TaxonomicDB):
            doc = doc.model_dump(by_alias=True, mode="json")
        doc["_id"] = str(doc["_id"])
        return TaxonomicOut.model_validate(doc)


class TaxonomicOutFiltered(BaseModel):
    """Filtered response model containing only essential fields for taxonomic memory."""

    project_id: Optional[str] = None
    visibility: ChunkVisibility
    published: bool = Field(description="Whether the taxonomic memory is published")
    published_scope: Optional[str] = Field(default=None, description="Published scope if published")
    domain: str
    term: str
    definition: str
    related_terms: List[str] = Field(default_factory=list)

    @classmethod
    def from_taxonomic_out(cls, taxonomic: TaxonomicOut) -> "TaxonomicOutFiltered":
        """Create filtered response from full TaxonomicOut."""
        publishing = taxonomic.publishing or PublishingMetadata()
        return cls(
            project_id=taxonomic.project_id,
            visibility=taxonomic.visibility,
            published=publishing.published,
            published_scope=publishing.published_scope.value
            if publishing.published_scope
            else None,
            domain=taxonomic.domain,
            term=taxonomic.term,
            definition=taxonomic.definition,
            related_terms=taxonomic.related_terms or [],
        )

    model_config = {
        "arbitrary_types_allowed": True,
        "from_attributes": True,
        "populate_by_name": True,
        "use_enum_values": True,
    }


class TaxonomicBulkIn(BaseModel):
    """Input model for bulk creating taxonomic terms."""

    # Shared fields for all terms in bulk
    domain: str
    visibility: ChunkVisibility = ChunkVisibility.ORG
    project_id: Optional[str] = None
    query_expansion: bool = True

    # Array of term definitions
    terms: List[dict] = Field(
        description="Array of {term: str, definition: str, related_terms?: List[str]} objects"
    )

    # Source tracking fields for bulk operations
    creation_method: CreationMethod = Field(
        default=CreationMethod.USER_CREATED,
        description="Method used to create these taxonomic entries",
    )
    source_agent: Optional[str] = Field(
        default=None,
        description="Agent/model that created these entries (for LLM extractions)",
    )
    user_source: Optional[str] = Field(
        default=None, description="User ID who initiated the creation/extraction"
    )
    source_reference: Optional[str] = Field(
        default=None, description="Reference to source document (e.g., snapshot ID)"
    )


__all__ = [
    "CreationMethod",
    "TaxonomicIn",
    "TaxonomicUpdate",
    "TaxonomicBase",
    "TaxonomicDB",
    "TaxonomicOut",
    "TaxonomicOutFiltered",
    "TaxonomicBulkIn",
]
