"""Framework-agnostic query plugin protocol for the AER.

The AER hosts two read endpoints that surface framework-specific persisted
state — per-session summary and conversation messages. The implementations
live in framework adapter packages (e.g. ``magenta-sdklanggraph``); the AER
itself only hosts the routes and delegates to whichever plugin the runtime
has been configured with.

Trust model
-----------

These endpoints take no workspace identifier and apply no workspace-level
authorization. The AER trusts its caller (the platform's Orchestration
Engine proxy) to pass only session_ids that belong to the caller's
workspace. The OE establishes that scope by consulting the ``executions``
collection — which is tagged with ``workspace_id`` — before issuing the
request. Within the AER, reads are then narrowed by
``thread_id = session_id``; this is safe **only** because the upstream
proxy has already validated ownership.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from magenta_sdk_core.models import (
    SessionMessagesResponse,
    SessionsSummaryResponse,
)


@runtime_checkable
class AERQueryPlugin(Protocol):
    """Read-side plugin that surfaces framework-specific session state.

    Implementations live alongside framework adapters and read from the
    adapter's persistence (LangGraph checkpoint collections, ADK state
    store, etc.).
    """

    async def get_summaries_for_sessions(self, session_ids: list[str]) -> SessionsSummaryResponse:
        """Given a list of session_ids, return a SessionsSummaryResponse."""
        ...

    async def get_messages_for_session(self, session_id: str) -> SessionMessagesResponse:
        """Given a session_id, return a SessionMessagesResponse."""
        ...
