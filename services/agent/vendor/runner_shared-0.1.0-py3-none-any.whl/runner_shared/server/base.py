"""
Base server class for Runner SDK components.

Provides common functionality for all server types:
- Health check endpoint
- Startup/shutdown hooks
- FastAPI app setup
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from contextlib import asynccontextmanager
from copy import deepcopy
from typing import TYPE_CHECKING, Any, AsyncGenerator, Dict, Optional

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from uvicorn.config import LOGGING_CONFIG as UVICORN_LOGGING_CONFIG

from runner_shared.models import HealthResponse, HealthStatus

if TYPE_CHECKING:
    from runner_shared.runtime import TenantRuntime

logger = logging.getLogger(__name__)

_APP_TITLES: dict[str, str] = {
    "aer": "Agent Execution Runtime (AER)",
    "tool": "Tool Executor Pod",
    "memory-server": "Memory Server",
}

_APP_DESCRIPTIONS: dict[str, str] = {
    "aer": (
        "Agent Execution Runtime HTTP API for the MongoDB Agentic Platform. "
        "Executes agents via the BaseAgent protocol with SecureToolWrapper "
        "for audited tool and LLM routing through the Orchestration Engine."
    ),
    "tool": (
        "Tool Executor Pod HTTP API for the MongoDB Agentic Platform. "
        "Runs registered tool functions and LLM invocations in isolated pods "
        "with dedicated network and secret access."
    ),
    "memory-server": (
        "Memory Server HTTP API for the MongoDB Agentic Platform. "
        "Provides REST endpoints for semantic, episodic, procedural, and "
        "short-term memory operations with document ingestion and context building."
    ),
}


class RunnerAccessLogFilter(logging.Filter):
    """Reduce noise from low-value access logs while keeping normal traffic visible."""

    SUPPRESSED_PATHS = {"/health", "/healthz", "/readyz"}
    POLLING_PATHS = {"/query/execution-logs", "/query/node-executions"}

    @classmethod
    def _extract_path(cls, record: logging.LogRecord) -> Optional[str]:
        args = record.args if isinstance(record.args, tuple) else ()
        if len(args) >= 3:
            # Uvicorn currently stores the raw request target in args[2].
            # Fall back to message parsing below in case that format changes.
            return str(args[2]).split("?", 1)[0]

        message = record.getMessage()
        for path in cls.SUPPRESSED_PATHS | cls.POLLING_PATHS:
            if f'"GET {path} HTTP/' in message or f'"HEAD {path} HTTP/' in message:
                return path

        return None

    def filter(self, record: logging.LogRecord) -> bool:
        if record.name != "uvicorn.access":
            return True

        path = self._extract_path(record)
        if path in self.SUPPRESSED_PATHS | self.POLLING_PATHS:
            return False

        return True


def build_uvicorn_log_config() -> Dict[str, Any]:
    """Clone Uvicorn's logging config and suppress low-value access logs."""
    log_config = deepcopy(UVICORN_LOGGING_CONFIG)
    filters = log_config.setdefault("filters", {})
    filters["suppress_runner_access_noise"] = {
        "()": "runner_shared.server.base.RunnerAccessLogFilter",
    }

    access_handler = log_config.get("handlers", {}).get("access")
    if access_handler is not None:
        access_handler["filters"] = [
            *access_handler.get("filters", []),
            "suppress_runner_access_noise",
        ]

    return log_config


class BaseServer(ABC):
    """
    Base server class for all runtime modes.

    Subclasses implement:
    - mode_name: Name of the mode (aer, tool, memory-server)
    - default_port: Default port for this mode
    - register_routes: Register mode-specific routes
    - on_startup: Optional startup hook
    - on_shutdown: Optional shutdown hook
    - get_health_details: Optional health check details
    """

    # Default ports for each mode
    DEFAULT_PORTS = {
        "aer": 8001,
        "tool": 8002,
        "memory-server": 8081,
    }

    def __init__(self, runtime: "TenantRuntime"):
        """
        Initialize the server.

        Args:
            runtime: The TenantRuntime instance
        """
        self.runtime = runtime
        self._app: Optional[FastAPI] = None

    @property
    @abstractmethod
    def mode_name(self) -> str:
        """Return the mode name (aer, tool, memory-server)."""
        pass

    @property
    def default_port(self) -> int:
        """Return the default port for this mode."""
        return self.DEFAULT_PORTS.get(self.mode_name, 8000)

    @abstractmethod
    def register_routes(self, app: FastAPI) -> None:
        """Register mode-specific routes on the FastAPI app."""
        pass

    async def on_startup(self) -> None:
        """Called when server starts. Override in subclass."""
        pass

    async def on_shutdown(self) -> None:
        """Called when server shuts down. Override in subclass."""
        pass

    def get_health_details(self) -> Dict[str, Any]:
        """Return additional health check details. Override in subclass."""
        return {}

    def _create_lifespan(self) -> Any:
        """Create a lifespan context manager for the FastAPI app."""
        server = self

        @asynccontextmanager
        async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
            # Startup
            logger.info(f"Starting {server.mode_name} server...")
            await server.on_startup()
            logger.info(f"{server.mode_name.title()} server started")
            yield
            # Shutdown
            logger.info(f"Shutting down {server.mode_name} server...")
            await server.on_shutdown()
            logger.info(f"{server.mode_name.title()} server stopped")

        return lifespan

    def create_app(self) -> FastAPI:
        """Create and configure the FastAPI application."""
        from runner_shared.utils import get_env

        app = FastAPI(
            title=_APP_TITLES.get(self.mode_name, f"Runner SDK - {self.mode_name.title()}"),
            description=_APP_DESCRIPTIONS.get(
                self.mode_name, f"{self.mode_name.title()} server for Runner SDK"
            ),
            version="1.0.0",
            lifespan=self._create_lifespan(),
        )

        # Add CORS middleware (configurable via environment variable)
        cors_origins = get_env("CORS_ALLOWED_ORIGINS", "*").split(",")
        app.add_middleware(
            CORSMiddleware,
            allow_origins=cors_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        # Register common routes
        self._register_common_routes(app)

        # Register mode-specific routes
        self.register_routes(app)

        self._app = app
        return app

    def _register_common_routes(self, app: FastAPI) -> None:
        """Register routes common to all modes."""
        from datetime import datetime, timezone

        from runner_shared.metrics import Metrics

        server = self

        @app.get("/health", response_model=HealthResponse)
        async def health_check() -> HealthResponse:
            """Check component health and readiness.

            Returns the component's health status, runtime mode, version, and
            mode-specific details (e.g. registered tools, graph builder state).
            Used by Kubernetes liveness and readiness probes.
            """
            return HealthResponse(
                status=HealthStatus.HEALTHY,
                component=server.runtime.app_name,
                mode=server.mode_name,
                version="1.0.0",
                details=server.get_health_details(),
            )

        @app.get("/")
        async def root() -> Dict[str, str]:
            """Return basic service identity and status."""
            return {
                "service": server.runtime.app_name,
                "mode": server.mode_name,
                "status": "running",
            }

        @app.get("/metrics")
        async def get_metrics() -> Dict[str, Any]:
            """Return collected execution metrics for this component.

            Includes per-operation timing, error counts, and invocation totals
            aggregated since the last pod restart.
            """
            return {
                "status": "ok",
                "component": server.mode_name,
                "metrics": Metrics.get_all(),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

    async def run(
        self,
        host: str = "0.0.0.0",
        port: Optional[int] = None,
        log_level: str = "info",
    ) -> None:
        """
        Run the server.

        Args:
            host: Host to bind to. The launch path in
                ``runner_shared.runtime`` auto-detects the host
                (``"::"`` on IPv6 dual-stack, ``"0.0.0.0"`` otherwise)
                and passes it here, so direct callers usually do not
                need to override. Pass the bare IP literal — uvicorn's
                ``getaddrinfo`` does not strip URI brackets on every
                platform.
            port: Port to bind to (defaults to mode default)
            log_level: Logging level
        """
        port = port or self.default_port
        app = self.create_app()

        logger.info(f"Starting {self.mode_name} server on {host}:{port}")

        config = uvicorn.Config(
            app=app,
            host=host,
            port=port,
            log_level=log_level,
            log_config=build_uvicorn_log_config(),
        )
        server = uvicorn.Server(config)
        await server.serve()
