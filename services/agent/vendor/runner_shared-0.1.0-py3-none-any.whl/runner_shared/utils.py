"""
Utility functions for Runner SDK.
"""

from __future__ import annotations

import json
import logging
import os
import re
import sys
from enum import Enum
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional


def normalize_content(content: Any) -> str:
    """
    Normalize LLM message content to a string.

    LLM content can be:
    - A string (normal text)
    - A list (multimodal content with text and other parts)
    - None or empty

    This handles cases where LangChain's AIMessageChunk.content is a list
    of content blocks (e.g., from Gemini multimodal responses) rather than
    a simple string.

    Args:
        content: The content to normalize (string, list, or None)

    Returns:
        A string representation of the content
    """
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        # Handle multimodal content - extract text parts
        text_parts = []
        for part in content:
            if isinstance(part, str):
                text_parts.append(part)
            elif isinstance(part, dict):
                # Common format: {"type": "text", "text": "..."} or {"type": "image", ...}
                if part.get("type") == "text":
                    text_parts.append(part.get("text", ""))
                # Skip non-text parts (images, etc.)
            elif hasattr(part, "type") and hasattr(part, "text") and part.type == "text":
                # sdk-core TextBlock or similar typed content blocks
                text_parts.append(part.text)
        return "".join(text_parts)
    # Fallback: convert to string
    return str(content)


def normalize_tool_call_args(args: Any) -> str | None:
    """Normalize streamed tool-call args into the wire-format string payload."""
    if args is None or isinstance(args, str):
        return args
    try:
        return json.dumps(args)
    except (TypeError, ValueError):
        return str(args)


_THINK_OPEN = "<think>"
_THINK_CLOSE = "</think>"


def strip_thinking(text: str) -> str:
    """Remove ``<think>...</think>`` blocks and unclosed ``<think>`` tails."""
    if not text:
        return ""
    cleaned = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL)
    cleaned = re.sub(r"<think>.*$", "", cleaned, flags=re.DOTALL)
    return cleaned.strip()


def filter_thinking_tokens(token: str, buffer: str, inside: bool) -> tuple[str, str, bool]:
    """Filter ``<think>`` blocks from a stream of token chunks.

    Accumulates text in *buffer* until we can determine whether content
    is inside a thinking block.  Returns ``(streamable, new_buffer,
    inside)`` where *streamable* is the text safe to send to the client.
    """
    buffer += token
    streamable_parts: list[str] = []

    while True:
        if inside:
            close_idx = buffer.find(_THINK_CLOSE)
            if close_idx == -1:
                return "".join(streamable_parts), buffer, True
            buffer = buffer[close_idx + len(_THINK_CLOSE) :]
            inside = False
        else:
            open_idx = buffer.find(_THINK_OPEN)
            if open_idx == -1:
                streamable_parts.append(buffer)
                return "".join(streamable_parts), "", False
            streamable_parts.append(buffer[:open_idx])
            buffer = buffer[open_idx + len(_THINK_OPEN) :]
            inside = True


class RuntimeMode(str, Enum):
    """Runtime mode for the Runner SDK."""

    AER = "aer"
    TOOL = "tool"
    MEMORY_SERVER = "memory-server"


_MODE_MAP: dict[str, RuntimeMode] = {m.value: m for m in RuntimeMode}


def get_runtime_mode() -> RuntimeMode:
    """
    Get the current runtime mode from environment variable.

    Returns:
        RuntimeMode based on RUNNER_MODE environment variable.

    Raises:
        ValueError: If RUNNER_MODE is not set or is not a valid mode.
    """
    raw = os.environ.get("RUNNER_MODE")
    if raw is None:
        raise ValueError(
            f"RUNNER_MODE environment variable is required. Valid values: {', '.join(_MODE_MAP)}"
        )
    mode = raw.lower()
    try:
        return _MODE_MAP[mode]
    except KeyError:
        raise ValueError(
            f"Unknown RUNNER_MODE '{mode}'. Valid values: {', '.join(_MODE_MAP)}"
        ) from None


def get_env(name: str, default: str = "") -> str:
    """Get environment variable with default."""
    return os.environ.get(name, default)


def get_env_int(name: str, default: int) -> int:
    """Get integer environment variable with default."""
    try:
        return int(os.environ.get(name, str(default)))
    except ValueError:
        return default


def get_env_float(name: str, default: float) -> float:
    """Get float environment variable with default."""
    try:
        return float(os.environ.get(name, str(default)))
    except ValueError:
        return default


def get_env_bool(name: str, default: bool = False) -> bool:
    """Get boolean environment variable with default."""
    value = os.environ.get(name, str(default)).lower()
    return value in ("true", "1", "yes", "on")


# Env vars set by the platform inside the runtime container.
# Filtered OUT of the tenant-visible env mapping passed to
# ``load_runtime_agent_config(env_vars=...)`` so tenant ``agent.yaml`` cannot
# use ``${VAR}`` interpolation to dereference platform secrets or internal
# service addresses (e.g. ``url: https://attacker/${OPENAI_API_KEY}``).
#
# Maintenance: whenever a new platform-owned env var is introduced in
# ``runner-shared`` (or a sibling package whose env reaches the runtime
# container), add its exact name to ``_PLATFORM_ENV_VARS`` or, if it shares a
# common prefix with related platform vars, extend ``_PLATFORM_ENV_VAR_PREFIXES``.
# The prefix list does most of the work -- prefer adding a prefix over
# enumerating individual names.
_PLATFORM_ENV_VAR_PREFIXES: tuple[str, ...] = (
    # ``AGENTIC_*`` is the platform's reserved namespace. Tenants are
    # documented to use unprefixed names for their own vars.
    "AGENTIC_",
    # Component-scoped families
    "MONGOMEM_",  # memory server config
    "MONGODB_",  # MongoDB URI + client tunables
    "VOYAGE_",  # platform-owned embedder config
    "LLM_",  # retry tunables in this module
    "OE_",  # orchestration engine
    "AER_",  # Agent Execution Runtime endpoints
    "TOOL_",  # Tool Pod endpoints
    "ECP_",  # Executor Control Plane
    "RUNNER_",  # runner-internal tunables (mode, stream timeouts, ...)
    "GUARDRAILS_",  # guardrails server config + LLM key
    "FILESYSTEM_",  # Tool Pod sandbox limits
    "SHELL_",  # Tool Pod sandbox limits
    "MAX_",  # Tool Pod sandbox limits (MAX_LS_ENTRIES, MAX_GREP_*, ...)
    # Auth / observability
    "OKTA_",
    "OIDC_",
    "OTEL_",
    # Test infra (must not leak into production tenant interpolation either)
    "E2E_",
    # Container / orchestration infra
    "KUBERNETES_",
    "HELIX_",
    # POSIX
    "LC_",
)

_PLATFORM_ENV_VARS: frozenset[str] = frozenset(
    {
        # Multi-tenant identity
        "ORG_ID",
        "PROJECT_ID",
        "TENANT_ID",
        "APP_ID",
        # Platform LLM provider credentials. Read by the memory server's
        # ``mongomem_impl`` for extraction-pipeline provider detection, but
        # potentially present in any runtime container.
        "OPENAI_API_KEY",
        "ANTHROPIC_API_KEY",
        "CEREBRAS_API_KEY",
        "GEMINI_API_KEY",
        # Platform LLM endpoints (not secret, but leaking them via tenant
        # YAML is still pointless and a potential SSRF vector).
        "OPENAI_BASE_URL",
        "ANTHROPIC_BASE_URL",
        # Auth / inter-service secrets
        "A2A_JWT_SECRET",
        # Server / network config
        "APP_HOST",
        "APP_PORT",
        "LOG_LEVEL",
        "LOG_DIR",  # operator-injected via render.WorkloadInjectedEnv
        "STRUCTURED_LOGGING",  # operator-injected via render.StructuredLoggingEnv
        "CORS_ALLOWED_ORIGINS",  # OE-injected (forward-defensive on AER)
        "USE_MEMORY_CLIENT",
        "AGENT_STREAM_TERMINAL_DRAIN_TIMEOUT",
        # Runner launcher entrypoint baked into the Dockerfile ENV by ECP
        "AGENT_ENTRYPOINT",
        # Platform persistence
        "PLATFORM_DATABASE",
        "MEMORY_DATABASE_NAME",
        "MDB_AGENTIC_STORE_DB",
        "DB_NAME",
        "CHECKPOINTER_SERVER_SELECTION_TIMEOUT",
        "CHECKPOINTER_CONNECT_TIMEOUT",
        "CHECKPOINTER_SOCKET_TIMEOUT",
        "TEST_MONGO_URI",
        # Tool Pod sandbox (covered partially by prefix, but the no-prefix
        # ``WORKSPACE_DIR`` / ``DOWNLOAD_MAX_BYTES`` names live here).
        "WORKSPACE_DIR",
        "DOWNLOAD_MAX_BYTES",
        # Feature toggles
        "ENABLE_MEMORY",
        "ENABLE_TRACING",
        "ENABLE_VECTOR_SEARCH_TESTS",
        # Dev / test infra
        "SEED_DATA",
        "CI",
        # Container / pod infra
        "POD_NAME",
        "HOSTNAME",
        # Generic POSIX. Substituting these into a URL is never what the
        # tenant means; blocking prevents accidental leakage of process
        # identity / filesystem layout.
        "PATH",
        "HOME",
        "USER",
        "PWD",
        "LANG",
        "TERM",
        "SHELL",
        "SHLVL",
        "_",
    }
)


def is_platform_env_var(name: str) -> bool:
    """Return ``True`` if ``name`` matches a platform-owned env var.

    Public-API view of the same membership check used by ``tenant_env_vars``.
    Used by ``agent_config`` to validate fields that name an env var (e.g.
    ``mcp.servers.*.auth.token_env``) so tenant YAML cannot redirect a
    secret-indirection path at a platform-owned variable.
    """
    return name in _PLATFORM_ENV_VARS or any(
        name.startswith(prefix) for prefix in _PLATFORM_ENV_VAR_PREFIXES
    )


def tenant_env_vars(source: Mapping[str, str] | None = None) -> dict[str, str]:
    """Return the tenant-owned subset of environment variables.

    ``source`` defaults to ``os.environ``. Names listed in ``_PLATFORM_ENV_VARS``
    or matching any prefix in ``_PLATFORM_ENV_VAR_PREFIXES`` are excluded, so
    the result is safe to pass as the substitution mapping to
    ``load_runtime_agent_config(env_vars=...)``.
    """
    if source is None:
        source = os.environ
    return {name: value for name, value in source.items() if not is_platform_env_var(name)}


# LLM retry configuration for rate limit errors
LLM_MAX_RETRIES = int(os.environ.get("LLM_MAX_RETRIES", "3"))
LLM_INITIAL_BACKOFF = float(os.environ.get("LLM_INITIAL_BACKOFF", "1.0"))  # seconds
LLM_BACKOFF_MULTIPLIER = float(os.environ.get("LLM_BACKOFF_MULTIPLIER", "2.0"))
LLM_MAX_BACKOFF = float(os.environ.get("LLM_MAX_BACKOFF", "30.0"))  # seconds

# LLM read timeout — LLM generation can take much longer than a typical HTTP request.
# Applies to both streaming (per-chunk wait) and non-streaming (full-response wait) paths.
LLM_READ_TIMEOUT = float(
    os.environ.get(
        "RUNNER_LLM_READ_TIMEOUT",
        os.environ.get("RUNNER_STREAM_READ_TIMEOUT", "300.0"),
    )
)  # seconds


def is_retryable_error(error: Exception) -> bool:
    """Check if an error is retryable (rate limit, server overload, etc.)."""
    error_str = str(error).lower()
    retryable_patterns = [
        "too_many_requests",
        "rate_limit",
        "429",
        "500",
        "503",
        "server error",
        "queue_exceeded",
        "high traffic",
        "overloaded",
    ]
    return any(pattern in error_str for pattern in retryable_patterns)


# Configurable HTTP request timeout
def get_request_timeout() -> float:
    """
    Get the HTTP request timeout from environment.

    Uses RUNNER_REQUEST_TIMEOUT env var, defaults to 60.0 seconds.
    """
    return get_env_float("RUNNER_REQUEST_TIMEOUT", 60.0)


# =============================================================================
# Logging Configuration
# =============================================================================


def setup_logging(
    *,
    app_name: str = "runner",
    mode: str = "aer",
    log_dir: Optional[str] = None,
    log_level: Optional[str] = None,
    backup_count: int = 5,
) -> logging.Logger:
    """
    Configure logging with both console and file output.

    All arguments are keyword-only. Prior versions took ``log_level`` as the
    first positional argument; keyword-only ensures ``setup_logging("DEBUG")``
    from older call sites fails loudly instead of silently binding ``"DEBUG"``
    to ``app_name`` and taking the default log level.

    When ``STRUCTURED_LOGGING=true`` is set, delegates to
    ``runner_shared.structured_logging.install_structured_logging`` so all
    output emerges as single-line JSON matching the AP-1167 agent-log
    contract. Disk logging is skipped in that mode — Fluent Bit ships
    container stdout to S3, so a duplicate on-disk copy adds no value and
    just wastes IO.

    Args:
        app_name: Application name for log file naming
        mode: Runtime mode (aer, tool, memory-server)
        log_dir: Directory for log files (default: ./logs)
        log_level: Log level (default: from LOG_LEVEL env or INFO)
        backup_count: Number of rotated backup files to keep

    Returns:
        Root logger configured with handlers
    """
    if get_env("STRUCTURED_LOGGING", "").lower() == "true":
        # Imported here to keep the structured-logging path opt-in: callers
        # that don't set the env var pay no import-time cost.
        from runner_shared.structured_logging import install_structured_logging

        # Pass mode through so the formatter's ``service`` field reflects
        # the caller's intent even if RUNNER_MODE env happens to be unset
        # — without this, a setup_logging(mode="aer") call with no env
        # would silently produce service="agent-execution-runtime" (the
        # default), lying about which component emitted the line.
        install_structured_logging(level=log_level, mode=mode)
        return logging.getLogger()

    # Determine log level
    level_str = log_level or get_env("LOG_LEVEL", "INFO").upper()
    level = getattr(logging, level_str, logging.INFO)

    # Formatters
    detailed_formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s:%(lineno)d | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    console_formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(message)s",
        datefmt="%H:%M:%S",
    )

    # Get root logger. Drop any existing handlers so repeat calls don't
    # accumulate duplicate writers. For file handlers we also close() to
    # release the fd; for stdio-backed StreamHandlers we skip close() —
    # closing sys.stdout/sys.stderr breaks subsequent logging and print()
    # calls in the same process ("I/O operation on closed file").
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    while root_logger.handlers:
        handler = root_logger.handlers.pop()
        stream = getattr(handler, "stream", None)
        if stream in (sys.stdout, sys.stderr):
            continue
        try:
            handler.close()
        except Exception:
            pass

    # Console handler — always attached; disk logging is a convenience,
    # not a correctness requirement, so we install console first.
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(console_formatter)
    root_logger.addHandler(console_handler)

    # File handler with rotation — best effort. A read-only container
    # filesystem or a restricted-mount working directory used to crash
    # TenantRuntime.__init__ here; we now warn via the console handler
    # and continue stdout-only.
    log_dir = log_dir or get_env("LOG_DIR", "./logs")
    log_file: Optional[Path] = None
    try:
        log_path = Path(log_dir)
        log_path.mkdir(parents=True, exist_ok=True)
        # TimedRotatingFileHandler with ``utc=True`` rolls at UTC midnight
        # and stamps the rotated file with the *actual* rotation date, so a
        # multi-day pod doesn't end up with log content that doesn't match
        # the filename date. Base filename stays undated; rotated backups get
        # ``.YYYY-MM-DD`` appended by the handler itself.
        log_file = log_path / f"{app_name}-{mode}.log"
        file_handler = TimedRotatingFileHandler(
            log_file,
            when="midnight",
            backupCount=backup_count,
            encoding="utf-8",
            utc=True,
        )
        file_handler.setLevel(level)
        file_handler.setFormatter(detailed_formatter)
        root_logger.addHandler(file_handler)
    except OSError as e:
        root_logger.warning(
            "File logging disabled (log_dir=%s not writable: %s). "
            "Continuing with console output only.",
            log_dir,
            e,
        )
        log_file = None

    # Reduce noise from third-party libraries
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)

    if log_file is not None:
        root_logger.info(f"Logging initialized: level={level_str}, file={log_file}")
    else:
        root_logger.info(f"Logging initialized: level={level_str}, file=<disabled>")

    return root_logger


# =============================================================================
# Structured Logging Utilities
# =============================================================================

# Logger for this module's utility functions
_log_utils_logger = logging.getLogger(__name__)

# Truncation limits for log readability
MAX_CONTENT_LENGTH = 200
MAX_RESULT_LENGTH = 200


def log_separator() -> None:
    """Log a minor section separator (for individual operations)."""
    _log_utils_logger.info("-" * 40)


def log_section() -> None:
    """Log a major section separator (for execution boundaries)."""
    _log_utils_logger.info("=" * 60)


def log_llm_messages(
    messages: List[Any],
    prefix: str = "LLM",
    count_only: bool = False,
) -> None:
    """
    Log LLM conversation messages in a consistent format.

    Args:
        messages: List of message dicts or LangChain message objects
        prefix: Log line prefix (e.g., "OE", "LLM", "AER")
        count_only: If True, only log message count (for info level)
    """
    if count_only:
        _log_utils_logger.info(f"{prefix}: {len(messages)} messages")
        return

    _log_utils_logger.debug(f"{prefix}: {len(messages)} messages:")
    for i, msg in enumerate(messages):
        # Handle both dict and LangChain message objects
        if isinstance(msg, dict):
            msg_type = msg.get("type", "unknown")
            content = msg.get("content", "")
            tool_calls = msg.get("tool_calls")
        else:
            msg_type = getattr(msg, "type", "unknown")
            content = getattr(msg, "content", "")
            tool_calls = getattr(msg, "tool_calls", None)

        content_preview = str(content)[:MAX_CONTENT_LENGTH] if content else "(empty)"

        if tool_calls:
            _log_utils_logger.debug(
                f"{prefix}:   [{i}] {msg_type}: {content_preview}... + {len(tool_calls)} tool_calls"
            )
        else:
            _log_utils_logger.debug(f"{prefix}:   [{i}] {msg_type}: {content_preview}...")


def log_llm_response(
    result: Any,
    step: int,
    prefix: str = "LLM",
) -> None:
    """
    Log an LLM response in a consistent format.

    Args:
        result: LLM response (dict or AIMessage)
        step: Step number
        prefix: Log line prefix
    """
    if result is None:
        return

    if isinstance(result, dict):
        content = result.get("content", "")
        tool_calls = result.get("tool_calls", [])
    else:
        content = getattr(result, "content", "")
        tool_calls = getattr(result, "tool_calls", [])

    content_preview = str(content)[:MAX_CONTENT_LENGTH] if content else "(empty)"
    _log_utils_logger.debug(f"{prefix}: Step {step} - Response: {content_preview}...")

    if tool_calls:
        tool_names = []
        for tc in tool_calls:
            name = tc.get("name", tc) if isinstance(tc, dict) else getattr(tc, "name", str(tc))
            tool_names.append(name)
        _log_utils_logger.info(f"{prefix}: Step {step} - Tool calls: {tool_names}")


def log_tool_request(
    tool_name: str,
    arguments: Dict[str, Any],
    step: int,
    prefix: str = "TOOL",
) -> None:
    """
    Log a tool execution request.

    Args:
        tool_name: Name of the tool
        arguments: Tool arguments
        step: Step number
        prefix: Log line prefix
    """
    log_separator()
    _log_utils_logger.info(f"{prefix}: Step {step} - {tool_name}")
    _log_utils_logger.debug(f"{prefix}: Step {step} - Arguments: {arguments}")


def log_tool_result(
    tool_name: str,
    step: int,
    status: str,
    result: Any = None,
    error: Optional[str] = None,
    duration_ms: float = 0,
    prefix: str = "TOOL",
) -> None:
    """
    Log a tool execution result.

    Args:
        tool_name: Name of the tool
        step: Step number
        status: Execution status (success, error)
        result: Tool result
        error: Error message if failed
        duration_ms: Execution duration in milliseconds
        prefix: Log line prefix
    """
    _log_utils_logger.info(f"{prefix}: Step {step} - {tool_name} {status} ({duration_ms:.0f}ms)")

    if error:
        _log_utils_logger.error(f"{prefix}: Step {step} - Error: {error}")
    elif result is not None:
        result_str = str(result)[:MAX_RESULT_LENGTH]
        _log_utils_logger.debug(f"{prefix}: Step {step} - Result: {result_str}...")


def log_cached_result(
    tool_name: str,
    step: int,
    prefix: str = "TOOL",
) -> None:
    """Log that a cached result is being used (replay scenario)."""
    _log_utils_logger.info(f"{prefix}: Step {step} - {tool_name} using CACHED result (replay)")


def log_policy_blocked(
    tool_name: str,
    step: int,
    reason: str,
    prefix: str = "TOOL",
) -> None:
    """Log that a tool call was blocked by policy."""
    _log_utils_logger.warning(f"{prefix}: Step {step} - {tool_name} BLOCKED by policy: {reason}")


def log_execution_start(
    execution_id: str,
    input_keys: List[str],
    prefix: str = "OE",
) -> None:
    """Log the start of an execution."""
    log_section()
    _log_utils_logger.info(f"{prefix}: Starting execution {execution_id[:8]}...")
    _log_utils_logger.debug(f"{prefix}: Input keys: {input_keys}")


def log_execution_callback(
    execution_id: str,
    status: str,
    result: Any = None,
    error: Optional[str] = None,
    suspend_reason: Optional[str] = None,
    prefix: str = "OE",
) -> None:
    """Log an execution callback (completion/suspension/error)."""
    log_section()
    _log_utils_logger.info(f"{prefix}: Execution {execution_id[:8]}... → {status}")

    if suspend_reason:
        _log_utils_logger.info(f"{prefix}: Suspend reason: {suspend_reason}")
    if error:
        _log_utils_logger.error(f"{prefix}: Error: {error}")
    if result:
        result_preview = str(result)[:300]
        _log_utils_logger.debug(f"{prefix}: Result: {result_preview}...")
