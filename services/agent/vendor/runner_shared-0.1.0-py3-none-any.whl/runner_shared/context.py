"""
Per-execution context management using contextvars.

This module provides thread-safe, coroutine-safe context for execution state.
Each concurrent execution gets its own isolated context, preventing cross-execution
contamination of execution_id, wrapper, and OE URL.

Best Practice: All context variables are available for log correlation.

Usage:
    from runner_shared.context import (
        current_execution_id,
        current_wrapper,
        current_oe_url,
        set_execution_context,
        clear_execution_context,
    )

    # Set context at start of execution
    tokens = set_execution_context(execution_id, wrapper, oe_url)

    try:
        # During execution, access via .get()
        exec_id = current_execution_id.get()
        wrapper = current_wrapper.get()
    finally:
        # Always clear context when done
        clear_execution_context(tokens)
"""

from __future__ import annotations

import uuid
from contextvars import ContextVar, Token
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, Optional, Tuple

if TYPE_CHECKING:
    from runner_shared.models import ToolAuthorization

# Per-execution context variables
current_execution_id: ContextVar[Optional[str]] = ContextVar("current_execution_id", default=None)
current_wrapper: ContextVar[Optional[Any]] = ContextVar("current_wrapper", default=None)
current_oe_url: ContextVar[Optional[str]] = ContextVar("current_oe_url", default=None)
# Request ID for log correlation across components
current_request_id: ContextVar[Optional[str]] = ContextVar("current_request_id", default=None)
# User ID for the current execution
current_user_id: ContextVar[Optional[str]] = ContextVar("current_user_id", default=None)
# Session/thread ID for conversation continuity
current_session_id: ContextVar[Optional[str]] = ContextVar("current_session_id", default=None)
# Workspace ID for workspace-scoped attribution (AP-384)
current_workspace_id: ContextVar[Optional[str]] = ContextVar("current_workspace_id", default=None)
# Delegated credential injected by OE for tool execution.
current_authorization: ContextVar[Optional["ToolAuthorization"]] = ContextVar(
    "current_authorization", default=None
)
# Custom headers forwarded from the caller (X-Mdb-Agentic-Platform-Custom-* headers, prefix-stripped and lowercased)
current_custom_headers: ContextVar[Optional[Dict[str, str]]] = ContextVar(
    "current_custom_headers", default=None
)
current_execution_metadata: ContextVar[Optional[Dict[str, Any]]] = ContextVar(
    "current_execution_metadata", default=None
)
# Opaque caller-provided payload for the current execution (the invocation
# request body beyond `message`). Agent code reads it via get_current_payload().
current_payload: ContextVar[Optional[Dict[str, Any]]] = ContextVar("current_payload", default=None)


ContextTokens = Tuple[
    Token[Optional[str]],
    Token[Optional[Any]],
    Token[Optional[str]],
    Token[Optional[str]],
    Token[Optional[str]],
    Token[Optional[str]],
    Token[Optional[str]],
    Token[Optional["ToolAuthorization"]],
    Token[Optional[Dict[str, str]]],
    Token[Optional[Dict[str, Any]]],
    Token[Optional[Dict[str, Any]]],
]


def set_execution_context(
    execution_id: str,
    wrapper: Any,
    oe_url: str,
    request_id: Optional[str] = None,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    workspace_id: Optional[str] = None,
    custom_headers: Optional[Dict[str, str]] = None,
    authorization: Optional["ToolAuthorization"] = None,
    payload: Optional[Dict[str, Any]] = None,
) -> ContextTokens:
    """
    Set execution context for the current async task.

    Args:
        execution_id: The execution ID for this request
        wrapper: The SecureToolWrapper instance
        oe_url: The OE callback URL
        request_id: Optional request ID for log correlation (auto-generated if not provided)
        user_id: Optional user ID for the current execution
        session_id: Optional session/thread ID for conversation continuity
        workspace_id: Optional workspace ID for guardrails/cost attribution
        custom_headers: Optional caller-provided custom headers (X-Mdb-Agentic-Platform-Custom-* prefix-stripped)
        authorization: Optional delegated credential context for tool execution
        payload: Optional opaque caller-provided invocation payload

    Returns:
        Tuple of tokens for resetting context later
    """
    exec_token = current_execution_id.set(execution_id)
    wrap_token = current_wrapper.set(wrapper)
    url_token = current_oe_url.set(oe_url)
    # Auto-generate request_id if not provided
    req_id = request_id or f"req-{uuid.uuid4().hex[:12]}"
    req_token = current_request_id.set(req_id)
    user_token = current_user_id.set(user_id)
    session_token = current_session_id.set(session_id)
    workspace_token = current_workspace_id.set(workspace_id)
    authorization_token = current_authorization.set(authorization)
    custom_headers_token = current_custom_headers.set(custom_headers)
    metadata_token = current_execution_metadata.set({})
    payload_token = current_payload.set(payload)
    return (
        exec_token,
        wrap_token,
        url_token,
        req_token,
        user_token,
        session_token,
        workspace_token,
        authorization_token,
        custom_headers_token,
        metadata_token,
        payload_token,
    )


def clear_execution_context(tokens: ContextTokens) -> None:
    """
    Clear execution context using the tokens from set_execution_context.

    Args:
        tokens: The tuple of tokens returned by set_execution_context
    """
    (
        exec_token,
        wrap_token,
        url_token,
        req_token,
        user_token,
        session_token,
        workspace_token,
        authorization_token,
        custom_headers_token,
        metadata_token,
        payload_token,
    ) = tokens
    current_execution_id.reset(exec_token)
    current_wrapper.reset(wrap_token)
    current_oe_url.reset(url_token)
    current_request_id.reset(req_token)
    current_user_id.reset(user_token)
    current_session_id.reset(session_token)
    current_workspace_id.reset(workspace_token)
    current_authorization.reset(authorization_token)
    current_custom_headers.reset(custom_headers_token)
    current_execution_metadata.reset(metadata_token)
    current_payload.reset(payload_token)


def get_current_wrapper() -> Optional[Any]:
    """Get the current execution's SecureToolWrapper, or None if not in execution context."""
    return current_wrapper.get()


def get_current_execution_id() -> Optional[str]:
    """Get the current execution ID, or None if not in execution context."""
    return current_execution_id.get()


def get_current_request_id() -> Optional[str]:
    """
    Get the current request ID for log correlation.

    Returns None if not in execution context.
    """
    return current_request_id.get()


def get_current_oe_url() -> Optional[str]:
    """Get the current OE URL, or None if not in execution context."""
    return current_oe_url.get()


def get_current_user_id() -> Optional[str]:
    """Get the current user ID, or None if not in execution context."""
    return current_user_id.get()


def get_current_session_id() -> Optional[str]:
    """Get the current session/thread ID, or None if not in execution context."""
    return current_session_id.get()


def get_current_workspace_id() -> Optional[str]:
    """Get the current workspace ID, or None if not in execution context."""
    return current_workspace_id.get()


def get_current_authorization() -> Optional["ToolAuthorization"]:
    """Get delegated authorization for the current execution, if available."""
    return current_authorization.get()


def get_current_custom_headers() -> Dict[str, str]:
    """Get caller-provided custom headers, or empty dict if not set.

    Platform-internal headers (``a2a-`` prefix) are stripped - agent code
    should never see A2A tokens or routing metadata.  Internal platform
    code that needs the full set (e.g. the A2A client) should call
    :func:`get_all_custom_headers` instead.
    """
    headers = current_custom_headers.get() or {}
    return {k: v for k, v in headers.items() if not k.startswith("a2a-")}


def get_all_custom_headers() -> Dict[str, str]:
    """Get all custom headers including platform-internal ``a2a-`` entries."""
    return current_custom_headers.get() or {}


def get_current_execution_metadata() -> Dict[str, Any]:
    """Get metadata accumulated for the current execution step."""
    return current_execution_metadata.get() or {}


def get_current_payload() -> Dict[str, Any]:
    """Get the caller-provided invocation payload, or empty dict if not set.

    This is the opaque request body the caller sent alongside ``message``
    (e.g. screen state, structured context). Agent code can read it from
    anywhere in the execution, including tool functions.
    """
    return current_payload.get() or {}


def record_current_memory_metadata(
    *,
    action: str,
    memory_type: str,
    content: Optional[str] = None,
    relevance_score: Optional[float] = None,
) -> None:
    """Attach explicit memory metadata to the current execution step, if one exists."""
    metadata = current_execution_metadata.get()
    if metadata is None:
        return

    memory: Dict[str, Any] = {
        "action": action,
        "type": memory_type,
    }
    if content:
        memory["content"] = content
    if relevance_score is not None:
        memory["relevance_score"] = relevance_score

    memory_events = metadata.setdefault("memory_events", [])
    if isinstance(memory_events, list):
        memory_events.append(memory)
    metadata["memory"] = memory


# =========================================================================
# Validation Context (for passing execution identity to guardrails)
# =========================================================================


@dataclass(frozen=True)
class ValidationContext:
    """Execution identity passed to guardrails for audit logging."""

    session_id: str = ""
    execution_id: str = ""
    user_id: str = ""
    workspace_id: str = ""

    def to_dict(self) -> Dict[str, str]:
        """Serialize to a dict for inclusion in HTTP payloads."""
        return {
            "session_id": self.session_id,
            "execution_id": self.execution_id,
            "user_id": self.user_id,
            "workspace_id": self.workspace_id,
        }


def get_validation_context() -> ValidationContext:
    """Build a ValidationContext from the current execution contextvars."""
    return ValidationContext(
        session_id=current_session_id.get() or "",
        execution_id=current_execution_id.get() or "",
        user_id=current_user_id.get() or "",
        workspace_id=current_workspace_id.get() or "",
    )
