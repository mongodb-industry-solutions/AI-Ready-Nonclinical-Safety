"""
Tracing setup for Runner SDK.

Provides a simple interface to initialize OpenTelemetry with popular
AI/LLM instrumentors like OpenInference, exporting traces to JSONL or MongoDB.

When enabled, traces are written to:
1. JSONL file (always - for now) - observability/traces.jsonl
2. MongoDB collection (if configured)
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

from opentelemetry import trace
from opentelemetry.context import Context
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import ReadableSpan, Span, SpanProcessor, TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from .exporters import JSONLSpanExporter, MongoDBSpanExporter, get_trace_path

if TYPE_CHECKING:
    from pymongo.collection import Collection

logger = logging.getLogger(__name__)

# Track if tracing has been set up.
_tracer_provider: Optional[TracerProvider] = None


class ExecutionContextSpanProcessor(SpanProcessor):
    """Attach platform execution context to spans created during AER requests."""

    def on_start(self, span: Span, parent_context: Context | None = None) -> None:
        from runner_shared.context import (
            get_current_execution_id,
            get_current_session_id,
            get_current_workspace_id,
        )

        attrs = {
            "execution.id": get_current_execution_id(),
            "session.id": get_current_session_id(),
            "workspace.id": get_current_workspace_id(),
        }
        for key, value in attrs.items():
            if value:
                span.set_attribute(key, value)

    def on_end(self, span: ReadableSpan) -> None:
        return

    def shutdown(self) -> None:
        return

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True


def setup_tracing(
    service_name: str = "runner-sdk",
    mongodb_collection: Optional["Collection"] = None,
) -> None:
    """Set up OpenTelemetry tracing with OpenInference.

    OpenInference instrumentors will automatically
    send spans to exporters once this is called.

    Args:
        service_name: Name of your service (appears in traces).
        mongodb_collection: MongoDB collection for traces (optional).

    Example:
        setup_tracing(service_name="my-agent")

        # With MongoDB:
        setup_tracing(
            service_name="my-agent",
            mongodb_collection=client["mydb"]["traces"],
        )
    """
    global _tracer_provider

    if _tracer_provider is not None:
        logger.debug("Tracing already initialized")
        return

    # Create tracer provider.
    resource = Resource.create({"service.name": service_name})
    provider = TracerProvider(resource=resource)
    _tracer_provider = provider

    # Add JSONL exporter.
    provider.add_span_processor(ExecutionContextSpanProcessor())
    provider.add_span_processor(BatchSpanProcessor(JSONLSpanExporter()))
    logger.info(f"Tracing: JSONL output at {get_trace_path()}")

    # Add MongoDB exporter (if configured).
    if mongodb_collection is not None:
        provider.add_span_processor(BatchSpanProcessor(MongoDBSpanExporter(mongodb_collection)))
        logger.info(
            f"Tracing: MongoDB output to {mongodb_collection.database.name}.{mongodb_collection.name}"
        )

    # Set as global tracer provider.
    trace.set_tracer_provider(provider)

    # Enable framework-specific instrumentation if registered.
    _run_instrumentor()

    logger.info(f"Tracing enabled for '{service_name}'")


def _run_instrumentor() -> None:
    """Run the registered framework instrumentor, if any."""
    from runner_shared.hooks import get_instrumentor

    instrumentor = get_instrumentor()
    if instrumentor is not None:
        try:
            instrumentor()
            logger.info("Framework instrumentation enabled")
        except Exception:
            logger.warning("Framework instrumentor failed — tracing disabled", exc_info=True)
    else:
        logger.warning(
            "No instrumentor hook registered. "
            "Framework SDK should call register_instrumentor() to enable tracing."
        )


def shutdown_tracing() -> None:
    """Shutdown tracing and flush pending spans."""
    global _tracer_provider

    if _tracer_provider is not None:
        _tracer_provider.shutdown()
        _tracer_provider = None
        logger.info("Tracing shutdown complete")


def get_current_trace_context() -> tuple[Optional[str], Optional[str]]:
    """
    Get current trace_id and span_id from the active span.

    Returns:
        Tuple of (trace_id, span_id) or (None, None) if no active span
    """
    span = trace.get_current_span()
    if span and span.get_span_context().is_valid:
        ctx = span.get_span_context()
        return format(ctx.trace_id, "032x"), format(ctx.span_id, "016x")
    return None, None


def get_tracer(name: str = "runner-sdk") -> trace.Tracer:
    """
    Get a tracer for creating custom spans.

    Args:
        name: Name of the tracer (usually module name)

    Returns:
        OpenTelemetry Tracer instance
    """
    return trace.get_tracer(name)
