"""
Span Exporters for Runner SDK.

Simple exporters that work with OpenInference instrumentation:
- JSONLSpanExporter: Writes to local JSONL file (always enabled for now).
- MongoDBSpanExporter: Writes to MongoDB collection (when configured).
"""

from __future__ import annotations

import json
import logging
import os
import threading
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Sequence

from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult

if TYPE_CHECKING:
    from pymongo.collection import Collection

logger = logging.getLogger(__name__)


def get_trace_path() -> Path:
    """Get the trace file path from env vars or default."""
    if file_env := os.getenv("AGENTIC_TRACES_FILE"):
        path = Path(file_env)
    elif base_dir := os.getenv("AGENTIC_OBSERVABILITY_DIR"):
        path = Path(base_dir) / "traces.jsonl"
    else:
        path = Path("observability") / "traces.jsonl"

    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _span_to_dict(span: ReadableSpan) -> Dict[str, Any]:
    """Convert OpenTelemetry span to a dict for storage."""
    ctx = span.get_span_context()
    parent = span.parent

    # Extract attributes
    attributes = dict(span.attributes) if span.attributes else {}

    # These attributes are emitted by runner-shared's span processor for
    # correlation only. Trusted tenant/root scope is applied by OE from
    # Execution records when events are read.
    session_id = attributes.get("session.id") or attributes.get("session_id")
    execution_id = attributes.get("execution.id") or attributes.get("execution_id")

    doc = {
        "trace_id": format(ctx.trace_id, "032x"),  # type: ignore[union-attr]  # ctx is set by get_span_context()
        "span_id": format(ctx.span_id, "016x"),  # type: ignore[union-attr]
        "name": span.name,
        "kind": span.kind.name,
        "start_time_ns": span.start_time,
        "end_time_ns": span.end_time,
        "duration_ns": (span.end_time or 0) - (span.start_time or 0),
        "status": {
            "code": span.status.status_code.name,
            "description": span.status.description,
        },
        "attributes": attributes,
        "resource": dict(span.resource.attributes)
        if span.resource and span.resource.attributes
        else {},
    }

    # Add session_id as top-level field for easier querying
    if session_id:
        doc["session_id"] = session_id

    # Add execution_id as top-level field for easier querying
    if execution_id:
        doc["execution_id"] = execution_id

    if parent:
        doc["parent_span_id"] = format(parent.span_id, "016x")

    if span.events:
        doc["events"] = [
            {
                "name": e.name,
                "timestamp_ns": e.timestamp,
                "attributes": dict(e.attributes) if e.attributes else {},
            }
            for e in span.events
        ]

    return doc


class JSONLSpanExporter(SpanExporter):
    """Exports spans to a JSONL file."""

    def __init__(self, path: Path | None = None):
        self._path = path
        self._lock = threading.Lock()

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        """Write spans to the JSONL file."""
        if not spans:
            return SpanExportResult.SUCCESS

        path = self._path or get_trace_path()

        try:
            with self._lock:
                with path.open("a", encoding="utf-8") as f:
                    for span in spans:
                        f.write(json.dumps(_span_to_dict(span), default=str) + "\n")
            return SpanExportResult.SUCCESS
        except Exception as e:
            logger.error(f"Failed to write traces to {path}: {e}", exc_info=True)
            return SpanExportResult.FAILURE


class MongoDBSpanExporter(SpanExporter):
    """Exports spans to a MongoDB collection."""

    def __init__(self, collection: "Collection"):
        self.collection = collection

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        """Insert spans as documents into MongoDB."""
        if not spans:
            return SpanExportResult.SUCCESS

        try:
            docs = [_span_to_dict(span) for span in spans]
            self.collection.insert_many(docs)
            return SpanExportResult.SUCCESS
        except Exception as e:
            logger.error(f"Failed to write traces to MongoDB: {e}", exc_info=True)
            return SpanExportResult.FAILURE
