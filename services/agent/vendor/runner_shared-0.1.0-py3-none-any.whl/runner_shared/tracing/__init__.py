"""
Tracing module for Runner SDK.

Uses OpenInference for automatic LLM instrumentation.
Traces are exported to JSONL file and optionally MongoDB.

Usage:
    from runner_shared.tracing import setup_tracing

    # Simple - traces go to observability/traces.jsonl
    setup_tracing(service_name="my-agent")

    # With MongoDB
    setup_tracing(service_name="my-agent", mongodb_collection=collection)
"""

from .exporters import JSONLSpanExporter, MongoDBSpanExporter, get_trace_path
from .setup import get_current_trace_context, get_tracer, setup_tracing, shutdown_tracing

__all__ = [
    "setup_tracing",
    "shutdown_tracing",
    "get_current_trace_context",
    "get_tracer",
    "get_trace_path",
    "JSONLSpanExporter",
    "MongoDBSpanExporter",
]
