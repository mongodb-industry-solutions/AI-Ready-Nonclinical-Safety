"""Shared local error reporting helpers for CLI-generated runtime flows."""

from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    import sentry_sdk
    from sentry_sdk._types import LogLevelStr
    from sentry_sdk.types import Event, Hint
else:
    try:
        import sentry_sdk
        from sentry_sdk.types import Event, Hint
    except ImportError:
        sentry_sdk = None  # type: ignore[assignment]
        Event = dict[str, Any]  # type: ignore[misc,assignment]
        Hint = dict[str, Any]  # type: ignore[misc,assignment]
    LogLevelStr = str

_ENABLED = False
_MAX_SUMMARY_LINE_LENGTH = 240
_MAX_OUTPUT_TAIL_CHARS = 8 * 1024
_SECRET_INLINE_PATTERN = re.compile(
    r"(?i)\b(api[_-]?key|access[_-]?token|refresh[_-]?token|token|secret|password)(=|:)\s*([^\s,;]+)"
)
_BEARER_PATTERN = re.compile(r"(?i)\b(bearer)\s+[A-Za-z0-9._\-]+")
_URL_USERINFO_PATTERN = re.compile(r"(?i)\b([a-z][a-z0-9+.\-]*://)[^:/\s@]+:[^@\s/]+@")


def _resolve_home_dir() -> str:
    try:
        home_dir = str(Path.home())
    except (RuntimeError, KeyError):
        home_dir = os.getenv("HOME", "").strip()
    return home_dir.strip()


_HOME_DIR = _resolve_home_dir()


def init_error_reporting(
    *, surface: str, component: str | None = None, mode: str | None = None
) -> bool:
    global _ENABLED

    dsn = os.getenv("AGENTIC_SENTRY_DSN", "").strip()
    _ENABLED = sentry_sdk is not None and os.getenv("AGENTIC_SENTRY_ENABLED") == "1" and bool(dsn)
    if not _ENABLED:
        return False

    sentry_sdk.init(
        dsn=dsn,
        environment=os.getenv("AGENTIC_SENTRY_ENVIRONMENT", "local-dev"),
        release=os.getenv("AGENTIC_SENTRY_RELEASE") or None,
        traces_sample_rate=0.0,
        debug=os.getenv("AGENTIC_SENTRY_DEBUG") == "1",
        before_send=_before_send,
    )
    sentry_sdk.set_tag("surface", surface)
    if component:
        sentry_sdk.set_tag("component", component)
    if mode:
        sentry_sdk.set_tag("mode", mode)

    return True


def capture_exception(exc: BaseException, *, summary: str | None = None, **extra: Any) -> None:
    if not _ENABLED:
        return
    captured_exc = _exception_for_capture(exc, summary)
    with sentry_sdk.push_scope() as scope:
        if summary:
            scope.set_extra("original_exception_type", type(exc).__name__)
            scope.set_extra("original_exception_message", _redact_text(str(exc)))
        for key, value in extra.items():
            scope.set_extra(key, _redact_value(value))
        sentry_sdk.capture_exception(captured_exc)


def capture_message(message: str, level: LogLevelStr = "error", **extra: Any) -> None:
    if not _ENABLED:
        return
    with sentry_sdk.push_scope() as scope:
        for key, value in extra.items():
            scope.set_extra(key, _redact_value(value))
        sentry_sdk.capture_message(_redact_text(message), level=level)


def flush(timeout: float = 2.0) -> None:
    if _ENABLED:
        sentry_sdk.flush(timeout=timeout)


def summarize_subprocess_failure(exc: subprocess.CalledProcessError) -> str:
    command = _command_label(exc.cmd)
    headline = _failure_headline(subprocess_output_tail(exc))
    if headline:
        return f"{command} failed: {headline}"
    return f"{command} failed with exit {exc.returncode}"


def subprocess_output_tail(exc: subprocess.CalledProcessError) -> str:
    chunks: list[str] = []
    for value in (getattr(exc, "output", None), getattr(exc, "stderr", None)):
        if value is None:
            continue
        if isinstance(value, bytes):
            chunks.append(value.decode("utf-8", errors="replace"))
        else:
            chunks.append(str(value))
    if not chunks:
        return ""
    return _tail_text("\n".join(chunks))


def _before_send(event: Event, _hint: Hint) -> Event | None:
    event_data = cast(dict[str, Any], event)
    event_data["server_name"] = None
    if "message" in event_data:
        event_data["message"] = _redact_text(str(event_data["message"]))
    for section in (
        "request",
        "user",
        "tags",
        "extra",
        "contexts",
        "exception",
        "breadcrumbs",
        "threads",
        "logentry",
        "modules",
    ):
        payload = event_data.get(section)
        if isinstance(payload, dict):
            event_data[section] = {key: _redact_value(value) for key, value in payload.items()}
        elif isinstance(payload, list):
            event_data[section] = [_redact_value(item) for item in payload]
    return event


def _redact_value(value: Any) -> Any:
    if isinstance(value, str):
        return _redact_text(value)
    if isinstance(value, Path):
        return _redact_text(str(value))
    if isinstance(value, list):
        return [_redact_value(item) for item in value]
    if isinstance(value, dict):
        return {key: _redact_value(item) for key, item in value.items()}
    return value


def _redact_text(text: str) -> str:
    if not text:
        return text

    redacted = text
    if _HOME_DIR:
        redacted = redacted.replace(_HOME_DIR, "<home>")
    redacted = _URL_USERINFO_PATTERN.sub(r"\1<redacted>:<redacted>@", redacted)
    redacted = _SECRET_INLINE_PATTERN.sub(r"\1\2<redacted>", redacted)
    redacted = _BEARER_PATTERN.sub(r"\1 <redacted>", redacted)
    return redacted


def _exception_for_capture(exc: BaseException, summary: str | None) -> BaseException:
    if not summary:
        return exc
    wrapped = RuntimeError(_redact_text(summary))
    if exc.__traceback__ is not None:
        return wrapped.with_traceback(exc.__traceback__)
    return wrapped


def _command_label(cmd: object) -> str:
    if isinstance(cmd, (list, tuple)):
        parts = [str(part) for part in cmd if str(part).strip()]
        if not parts:
            return "subprocess"
        if len(parts) >= 3 and parts[0] == "uv" and parts[1] == "pip":
            return " ".join(parts[:3])
        if len(parts) >= 2:
            return " ".join(parts[:2])
        return parts[0]
    text = str(cmd).strip()
    return text or "subprocess"


def _failure_headline(output: str) -> str:
    lines = [_normalize_failure_line(line) for line in output.splitlines()]
    normalized = [line for line in lines if line]
    for line in reversed(normalized):
        lower = line.lower()
        if (
            "failed" in lower
            or "error" in lower
            or "not found" in lower
            or "no matching" in lower
            or "exception" in lower
        ):
            return _truncate_summary_line(line)
    if not normalized:
        return ""
    return _truncate_summary_line(normalized[-1])


def _normalize_failure_line(line: str) -> str:
    cleaned = line.strip().lstrip("│>").strip()
    if cleaned.startswith("×"):
        cleaned = cleaned[1:].strip()
    if cleaned.startswith("╰─▶"):
        cleaned = cleaned[3:].strip()
    if cleaned.lower().startswith("error:"):
        cleaned = cleaned[6:].strip()
    return cleaned


def _tail_text(text: str) -> str:
    trimmed = text.strip()
    if len(trimmed) <= _MAX_OUTPUT_TAIL_CHARS:
        return trimmed
    return trimmed[-_MAX_OUTPUT_TAIL_CHARS:]


def _truncate_summary_line(line: str) -> str:
    if len(line) <= _MAX_SUMMARY_LINE_LENGTH:
        return line
    return line[: _MAX_SUMMARY_LINE_LENGTH - 3] + "..."
