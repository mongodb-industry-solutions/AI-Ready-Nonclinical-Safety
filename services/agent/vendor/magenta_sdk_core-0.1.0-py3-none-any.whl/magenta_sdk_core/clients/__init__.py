"""HTTP clients for platform APIs (internal — not part of the public SDK surface)."""
