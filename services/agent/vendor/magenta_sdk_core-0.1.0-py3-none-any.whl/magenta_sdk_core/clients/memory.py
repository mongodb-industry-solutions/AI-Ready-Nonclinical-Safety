"""HTTP client for the Memory Server API.

Implements MemoryEngineProtocol by making HTTP calls to the memory server,
allowing transparent replacement of direct mongomem_core usage.
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

from magenta_sdk_core.api.v1.memory import (
    ContextResponse,
    CreateEpisodicResult,
    CreateProceduralResult,
    CreateSemanticResult,
    CreateTaxonomicResult,
    DeleteResult,
    MemoryChunk,
    WriteTurnResult,
)

logger = logging.getLogger(__name__)

# Headers injected into every request so the memory server can identify
# the calling agent and the active execution.
_HEADER_AGENT_ID = "X-Agentic-Agent-Id"
_HEADER_EXECUTION_ID = "X-Agentic-Execution-Id"


def _require_session_id(session_id: str | None) -> str:
    """Return a non-empty session ID or raise before issuing an HTTP request."""
    if not session_id or not session_id.strip():
        raise ValueError("session_id is required for memory server requests")
    return session_id.strip()


_CREATE_EPISODIC_EXTRA_FIELDS = (
    "snapshot_ref_id",
    "summary_type",
    "source_agent",
    "participants",
    "tags",
    "extraction_source",
    "embedding",
    "skip_embedding",
)


class MemoryClient:
    """
    HTTP client for Memory Server that implements MemoryEngineProtocol.

    Usage:
        client = MemoryClient("http://127.0.0.1:8081")

        # Write conversation turn
        client.write_turn(
            session_id="thread_123",
            role="user",
            content="Hello",
            org_id="org_1",
            user_id="user_1",
        )

        # Build context
        context = client.build_context(
            query="What did we discuss?",
            session_id="thread_123",
            org_id="org_1",
            user_id="user_1",
        )
    """

    def __init__(
        self,
        base_url: str,
        timeout: float = 30.0,
        static_headers: dict[str, str] | None = None,
        api_prefix: str = "/api/v1/memory",
    ):
        """
        Initialize memory client.

        Args:
            base_url: Memory server base URL (e.g., "http://127.0.0.1:8081")
            timeout: Request timeout in seconds (default: 30.0)
            static_headers: Pod-level identity headers set at construction time
                (e.g. X-Agentic-Agent-Id from APP_ID env var). Defensively
                copied so caller mutations after construction have no effect.
            api_prefix: URL path prefix for memory endpoints. Defaults to
                "/api/v1/memory" (OE proxy route). Use "/api/v1" when
                connecting directly to the memory server.
        """
        self._base_url = base_url.rstrip("/")
        self._api_prefix = "/" + api_prefix.strip("/")
        self._client = httpx.Client(timeout=timeout)
        self._static_headers: dict[str, str] = dict(static_headers or {})
        logger.info(f"MemoryClient initialized: {self._base_url}")

    def _request_headers(self) -> dict[str, str]:
        """Return identity headers for a single request.

        Static pod-level headers (set at construction) are merged with the
        execution_id from the active execution context. The contextvar layer
        is imported lazily to avoid a hard dependency on runner_shared from
        within sdk-core.
        """
        headers = dict(self._static_headers)
        try:
            from runner_shared.context import get_current_execution_id

            if execution_id := get_current_execution_id():
                headers[_HEADER_EXECUTION_ID] = execution_id
        except ImportError:
            pass
        return headers

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> MemoryClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    # =========================================================================
    # Short-Term Memory (STM)
    # =========================================================================

    def write_turn(
        self,
        session_id: str,
        role: str,
        org_id: str,
        user_id: str,
        project_id: str,
        content: str | None = None,
        tokens: int | None = None,
        stop_reason: str | None = None,
        model_name: str | None = None,
        tool_calls: list[dict[str, Any]] | None = None,
        tool_call_id: str | None = None,
        tool_name: str | None = None,
        is_error: bool = False,
        **kwargs: Any,
    ) -> WriteTurnResult:
        """Write a conversation turn to short-term memory."""
        body = {
            "session_id": _require_session_id(session_id),
            "role": role,
            "org_id": org_id,
            "user_id": user_id,
            "project_id": project_id,
            "content": content,
            "tokens": tokens,
            "stop_reason": stop_reason,
            "model_name": model_name,
            "tool_calls": tool_calls,
            "tool_call_id": tool_call_id,
            "tool_name": tool_name,
            "is_error": is_error,
        }

        resp = self._client.post(
            f"{self._base_url}{self._api_prefix}/stm/turns",
            json=body,
            headers=self._request_headers(),
        )
        resp.raise_for_status()
        return WriteTurnResult.model_validate(resp.json())

    # =========================================================================
    # Context Building
    # =========================================================================

    def build_context(
        self,
        query: str,
        session_id: str,
        org_id: str,
        user_id: str,
        project_id: str,
        visibility: str | None = None,
        metadata_filter: dict[str, Any] | None = None,
        enabled_sources: set[str] | None = None,
        format_style: str | None = None,
        top_k: int = 50,
        **kwargs: Any,
    ) -> ContextResponse:
        """Build formatted context from memories."""
        body: dict[str, Any] = {
            "query": query,
            "session_id": _require_session_id(session_id),
            "org_id": org_id,
            "user_id": user_id,
            "visibility": visibility,
            "project_id": project_id,
            "enabled_sources": list(enabled_sources) if enabled_sources else None,
            "format_style": format_style,
            "top_k": top_k,
        }
        if metadata_filter:
            body["metadata_filter"] = metadata_filter

        resp = self._client.post(
            f"{self._base_url}{self._api_prefix}/retrieval/context",
            json=body,
            headers=self._request_headers(),
        )
        resp.raise_for_status()
        return ContextResponse.model_validate(resp.json())

    # =========================================================================
    # Semantic Memory
    # =========================================================================

    def create_semantic(
        self,
        label: str,
        text: str,
        org_id: str,
        user_id: str,
        project_id: str,
        source: str = "agent",
        visibility: str = "private",
        agent_id: str | None = None,
        embedding: list[float] | None = None,
        contextual_metadata: dict[str, Any] | None = None,
        upsert: bool = False,
        **kwargs: Any,
    ) -> CreateSemanticResult:
        """Create a semantic memory."""
        body = {
            "label": label,
            "text": text,
            "org_id": org_id,
            "user_id": user_id,
            "source": source,
            "visibility": visibility,
            "project_id": project_id,
            "agent_id": agent_id,
            "embedding": embedding,
            "contextual_metadata": contextual_metadata,
            "upsert": upsert,
        }

        resp = self._client.post(
            f"{self._base_url}{self._api_prefix}/semantic",
            json=body,
            headers=self._request_headers(),
        )
        resp.raise_for_status()
        return CreateSemanticResult.model_validate(resp.json())

    def fetch_semantic_memories(
        self,
        query: str,
        org_id: str,
        project_id: str,
        user_id: str | None = None,
        visibility: str | None = None,
        top_k: int = 50,
        **kwargs: Any,
    ) -> list[MemoryChunk]:
        """Search semantic memories."""
        body = {
            "query": query,
            "org_id": org_id,
            "project_id": project_id,
            "user_id": user_id,
            "visibility": visibility,
            "top_k": top_k,
        }

        resp = self._client.post(
            f"{self._base_url}{self._api_prefix}/retrieval/semantic",
            json=body,
            headers=self._request_headers(),
        )
        resp.raise_for_status()
        memories_data = resp.json().get("memories", [])
        return [MemoryChunk.model_validate(m) for m in memories_data]

    def get_semantic(
        self,
        org_id: str,
        project_id: str,
        label: str | None = None,
        id: str | None = None,
        user_id: str | None = None,
        visibility: str | None = None,
        **kwargs: Any,
    ) -> Any | None:
        """Get semantic memory by label or ID."""
        params = {"org_id": org_id, "project_id": project_id}
        if user_id:
            params["user_id"] = user_id
        if visibility:
            params["visibility"] = visibility
        if label:
            params["label"] = label

        # If ID provided, use direct endpoint
        if id:
            id_params: dict[str, Any] = {"org_id": org_id, "project_id": project_id}
            if user_id:
                id_params["user_id"] = user_id
            if visibility:
                id_params["visibility"] = visibility
            resp = self._client.get(
                f"{self._base_url}{self._api_prefix}/semantic/{id}",
                params=id_params,
                headers=self._request_headers(),
            )
        else:
            # Otherwise list with label filter
            resp = self._client.get(
                f"{self._base_url}{self._api_prefix}/semantic",
                params=params,
                headers=self._request_headers(),
            )

        if resp.status_code == 404:
            return None
        resp.raise_for_status()

        data = resp.json()
        # If list endpoint, return first match
        if "entries" in data:
            entries = data["entries"]
            return entries[0] if entries else None
        return data

    def update_semantic(
        self,
        org_id: str,
        project_id: str,
        label: str,
        text: str | None = None,
        source: str | None = None,
        visibility: str | None = None,
        contextual_metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Any:
        """Update semantic memory."""
        # First get the memory ID by label
        memory = self.get_semantic(org_id=org_id, project_id=project_id, label=label)
        if not memory:
            raise ValueError(f"Semantic memory not found: {label}")

        memory_id = memory.get("id") or memory.get("_id")

        body = {
            "org_id": org_id,
            "project_id": project_id,
            "text": text,
            "source": source,
            "visibility": visibility,
            "contextual_metadata": contextual_metadata,
        }

        resp = self._client.patch(
            f"{self._base_url}{self._api_prefix}/semantic/{memory_id}",
            json=body,
            headers=self._request_headers(),
        )
        resp.raise_for_status()
        return resp.json()

    # =========================================================================
    # Episodic Memory
    # =========================================================================

    def create_episodic(
        self,
        title: str,
        content: str,
        summary_text: str,
        org_id: str,
        user_id: str,
        session_id: str,
        project_id: str,
        visibility: str = "private",
        agent_id: str | None = None,
        **kwargs: Any,
    ) -> CreateEpisodicResult:
        """Create an episodic memory."""
        body = {
            "title": title,
            "content": content,
            "summary_text": summary_text,
            "org_id": org_id,
            "user_id": user_id,
            "session_id": _require_session_id(session_id),
            "visibility": visibility,
            "project_id": project_id,
            "agent_id": agent_id,
        }
        for field in _CREATE_EPISODIC_EXTRA_FIELDS:
            if field in kwargs:
                body[field] = kwargs[field]

        resp = self._client.post(
            f"{self._base_url}{self._api_prefix}/episodic",
            json=body,
            headers=self._request_headers(),
        )
        resp.raise_for_status()
        return CreateEpisodicResult.model_validate(resp.json())

    def fetch_episodic_memories(
        self,
        query: str,
        org_id: str,
        project_id: str,
        user_id: str | None = None,
        visibility: str | None = None,
        session_id: str | None = None,
        top_k: int = 50,
        **kwargs: Any,
    ) -> list[MemoryChunk]:
        """Search episodic memories."""
        body = {
            "query": query,
            "org_id": org_id,
            "project_id": project_id,
            "user_id": user_id,
            "visibility": visibility,
            "session_id": session_id,
            "top_k": top_k,
        }

        resp = self._client.post(
            f"{self._base_url}{self._api_prefix}/retrieval/episodic",
            json=body,
            headers=self._request_headers(),
        )
        resp.raise_for_status()
        memories_data = resp.json().get("memories", [])
        return [MemoryChunk.model_validate(m) for m in memories_data]

    def list_episodic(
        self,
        org_id: str,
        project_id: str,
        user_id: str | None = None,
        session_id: str | None = None,
        visibility: str | None = None,
        limit: int = 20,
        **kwargs: Any,
    ) -> list[Any]:
        """List episodic memories."""
        params = {
            "org_id": org_id,
            "project_id": project_id,
            "user_id": user_id,
            "session_id": session_id,
            "visibility": visibility,
            "limit": limit,
        }

        resp = self._client.get(
            f"{self._base_url}{self._api_prefix}/episodic",
            params=params,
            headers=self._request_headers(),
        )
        resp.raise_for_status()
        return resp.json().get("entries", [])

    # =========================================================================
    # Taxonomic Memory
    # =========================================================================

    def create_taxonomic(
        self,
        domain: str,
        term: str,
        definition: str,
        org_id: str,
        user_id: str,
        project_id: str,
        related_terms: list[str] | None = None,
        query_expansion: bool = True,
        visibility: str = "org",
        **kwargs: Any,
    ) -> CreateTaxonomicResult:
        """Create a taxonomic memory."""
        body = {
            "domain": domain,
            "term": term,
            "definition": definition,
            "org_id": org_id,
            "user_id": user_id,
            "project_id": project_id,
            "related_terms": related_terms,
            "query_expansion": query_expansion,
            "visibility": visibility,
        }

        resp = self._client.post(
            f"{self._base_url}{self._api_prefix}/taxonomic",
            json=body,
            headers=self._request_headers(),
        )
        resp.raise_for_status()
        return CreateTaxonomicResult.model_validate(resp.json())

    def fetch_taxonomic_memories(
        self,
        query: str,
        org_id: str,
        project_id: str,
        domain: str | None = None,
        visibility: str | None = None,
        top_k: int = 50,
        **kwargs: Any,
    ) -> list[MemoryChunk]:
        """Search taxonomic memories."""
        body = {
            "query": query,
            "org_id": org_id,
            "project_id": project_id,
            "domain": domain,
            "visibility": visibility,
            "top_k": top_k,
        }

        resp = self._client.post(
            f"{self._base_url}{self._api_prefix}/retrieval/taxonomic",
            json=body,
            headers=self._request_headers(),
        )
        resp.raise_for_status()
        memories_data = resp.json().get("memories", [])
        return [MemoryChunk.model_validate(m) for m in memories_data]

    def get_taxonomic(
        self,
        org_id: str,
        project_id: str,
        domain: str | None = None,
        term: str | None = None,
        user_id: str | None = None,
        visibility: str | None = None,
        **kwargs: Any,
    ) -> Any | None:
        """Get taxonomic memory by domain and term."""
        params: dict[str, Any] = {
            "org_id": org_id,
            "project_id": project_id,
            "domain": domain,
        }
        if user_id:
            params["user_id"] = user_id
        if visibility:
            params["visibility"] = visibility

        resp = self._client.get(
            f"{self._base_url}{self._api_prefix}/taxonomic",
            params=params,
            headers=self._request_headers(),
        )
        if resp.status_code == 404:
            return None
        resp.raise_for_status()

        entries = resp.json().get("entries", [])
        # Filter by term if provided
        if term:
            for entry in entries:
                if entry.get("term") == term:
                    return entry
            return None
        return entries[0] if entries else None

    def get_distinct_domains(
        self,
        org_id: str,
        project_id: str,
        visibility: str | None = None,
        **kwargs: Any,
    ) -> list[str]:
        """Get distinct taxonomic domains."""
        params: dict[str, Any] = {"org_id": org_id, "project_id": project_id}
        if visibility:
            params["visibility"] = visibility
        resp = self._client.get(
            f"{self._base_url}{self._api_prefix}/taxonomic/domains",
            params=params,
            headers=self._request_headers(),
        )
        resp.raise_for_status()
        return resp.json().get("domains", [])

    # =========================================================================
    # Procedural Memory
    # =========================================================================

    def create_procedural(
        self,
        *,
        procedure: str,
        description: str,
        content: str,
        org_id: str,
        user_id: str,
        steps: list[dict[str, Any]] | None = None,
        resources: list[dict[str, Any]] | None = None,
        allowed_tools: list[str] | None = None,
        compatibility: str | None = None,
        license: str | None = None,
        trigger_conditions: list[str] | None = None,
        tags: list[str] | None = None,
        visibility: str = "private",
        project_id: str,
        agent_id: str | None = None,
        extraction_source: str | None = None,
        source_format: str | None = None,
        source_path: str | None = None,
        **kwargs: Any,
    ) -> CreateProceduralResult:
        """Create a procedural memory."""
        body = {
            "procedure": procedure,
            "description": description,
            "content": content,
            "org_id": org_id,
            "user_id": user_id,
            "steps": steps,
            "resources": resources,
            "allowed_tools": allowed_tools,
            "compatibility": compatibility,
            "license": license,
            "trigger_conditions": trigger_conditions,
            "tags": tags,
            "visibility": visibility,
            "project_id": project_id,
            "agent_id": agent_id,
            "extraction_source": extraction_source,
            "source_format": source_format,
            "source_path": source_path,
        }

        resp = self._client.post(
            f"{self._base_url}{self._api_prefix}/procedural",
            json=body,
            headers=self._request_headers(),
        )
        resp.raise_for_status()
        return CreateProceduralResult.model_validate(resp.json())

    def get_procedural(
        self,
        org_id: str,
        project_id: str,
        *,
        id: str | None = None,
        procedure: str | None = None,
        user_id: str | None = None,
        visibility: str | None = None,
        include_deleted: bool = False,
        **kwargs: Any,
    ) -> Any | None:
        """Get a procedural memory by ID or procedure name."""
        if id:
            id_params: dict[str, Any] = {
                "org_id": org_id,
                "project_id": project_id,
                "include_deleted": include_deleted,
            }
            if user_id:
                id_params["user_id"] = user_id
            if visibility:
                id_params["visibility"] = visibility
            resp = self._client.get(
                f"{self._base_url}{self._api_prefix}/procedural/{id}",
                params=id_params,
                headers=self._request_headers(),
            )
        else:
            params: dict[str, Any] = {
                "org_id": org_id,
                "project_id": project_id,
                "include_deleted": include_deleted,
            }
            if user_id:
                params["user_id"] = user_id
            if visibility:
                params["visibility"] = visibility
            if procedure:
                params["procedure"] = procedure
            resp = self._client.get(
                f"{self._base_url}{self._api_prefix}/procedural",
                params=params,
                headers=self._request_headers(),
            )

        if resp.status_code == 404:
            return None
        resp.raise_for_status()

        data = resp.json()
        if "entries" in data:
            entries = data["entries"]
            if procedure:
                for entry in entries:
                    if entry.get("procedure") == procedure:
                        return entry
                return None
            return entries[0] if entries else None
        return data

    def update_procedural(
        self,
        org_id: str,
        project_id: str,
        *,
        id: str | None = None,
        procedure: str | None = None,
        description: str | None = None,
        content: str | None = None,
        steps: list[dict[str, Any]] | None = None,
        resources: list[dict[str, Any]] | None = None,
        allowed_tools: list[str] | None = None,
        trigger_conditions: list[str] | None = None,
        tags: list[str] | None = None,
        visibility: str | None = None,
        **kwargs: Any,
    ) -> Any:
        """Update a procedural memory."""
        memory_id = id
        if not memory_id and procedure:
            existing = self.get_procedural(
                org_id=org_id, project_id=project_id, procedure=procedure
            )
            if not existing:
                raise ValueError(f"Procedural memory not found: {procedure}")
            memory_id = existing.get("id") or existing.get("_id")

        body = {
            "org_id": org_id,
            "description": description,
            "content": content,
            "steps": steps,
            "resources": resources,
            "allowed_tools": allowed_tools,
            "trigger_conditions": trigger_conditions,
            "tags": tags,
            "visibility": visibility,
            "project_id": project_id,
        }

        resp = self._client.patch(
            f"{self._base_url}{self._api_prefix}/procedural/{memory_id}",
            json=body,
            headers=self._request_headers(),
        )
        resp.raise_for_status()
        return resp.json()

    def delete_procedural(
        self,
        org_id: str,
        project_id: str,
        *,
        id: str | None = None,
        procedure: str | None = None,
        soft: bool = True,
        **kwargs: Any,
    ) -> DeleteResult:
        """Delete a procedural memory."""
        memory_id = id
        if not memory_id and procedure:
            existing = self.get_procedural(
                org_id=org_id, project_id=project_id, procedure=procedure
            )
            if not existing:
                raise ValueError(f"Procedural memory not found: {procedure}")
            memory_id = existing.get("id") or existing.get("_id")

        resp = self._client.delete(
            f"{self._base_url}{self._api_prefix}/procedural/{memory_id}",
            params={"org_id": org_id, "project_id": project_id, "soft": soft},
            headers=self._request_headers(),
        )
        resp.raise_for_status()
        return DeleteResult.model_validate(resp.json())

    def discover_procedures(
        self,
        query: str,
        org_id: str,
        project_id: str,
        *,
        user_id: str | None = None,
        visibility: str | None = None,
        tags: list[str] | None = None,
        top_k: int = 10,
        similarity_threshold: float = 0.0,
        metadata_filter: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> list[dict[str, Any]]:
        """Discover procedures matching a query (lightweight results)."""
        body: dict[str, Any] = {
            "query": query,
            "org_id": org_id,
            "user_id": user_id,
            "visibility": visibility,
            "project_id": project_id,
            "tags": tags,
            "top_k": top_k,
            "similarity_threshold": similarity_threshold,
        }
        if metadata_filter:
            body["metadata_filter"] = metadata_filter

        resp = self._client.post(
            f"{self._base_url}{self._api_prefix}/retrieval/procedural",
            json=body,
            headers=self._request_headers(),
        )
        resp.raise_for_status()
        memories_data = resp.json().get("memories", [])
        return [
            {
                "procedure": m.get("metadata", {}).get("procedure", ""),
                "content": m.get("content", ""),
                "score": m.get("similarity_score", 0.0),
                **m.get("metadata", {}),
            }
            for m in memories_data
        ]

    def fetch_procedural_memories(
        self,
        query: str,
        org_id: str,
        project_id: str,
        *,
        user_id: str | None = None,
        visibility: str | None = None,
        tags: list[str] | None = None,
        top_k: int = 50,
        **kwargs: Any,
    ) -> list[MemoryChunk]:
        """Fetch procedural memories by query (full content)."""
        body = {
            "query": query,
            "org_id": org_id,
            "user_id": user_id,
            "visibility": visibility,
            "project_id": project_id,
            "tags": tags,
            "top_k": top_k,
        }

        resp = self._client.post(
            f"{self._base_url}{self._api_prefix}/retrieval/procedural",
            json=body,
            headers=self._request_headers(),
        )
        resp.raise_for_status()
        memories_data = resp.json().get("memories", [])
        return [MemoryChunk.model_validate(m) for m in memories_data]

    # =========================================================================
    # Bootstrap (no-op for HTTP client)
    # =========================================================================

    def bootstrap(self) -> None:
        """No-op for HTTP client - server handles bootstrap."""
        pass
