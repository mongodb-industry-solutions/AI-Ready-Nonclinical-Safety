"""Version 1 of the Memory API models."""

from magenta_sdk_core.api.v1.memory import (
    BulkCreateSemanticResult,
    ContextConfig,
    ContextMetadata,
    ContextResponse,
    CreateEpisodicResult,
    CreateProceduralResult,
    CreateSemanticResult,
    CreateSnapshotResult,
    CreateTaxonomicResult,
    CreateUserContextResult,
    DeleteResult,
    FormatStyle,
    InternalStateResult,
    ISGenerationResult,
    MemoryChunk,
    MemorySource,
    ModelType,
    PromoteSnapshotResult,
    WriteTurnResult,
)

__all__ = [
    # Result models
    "WriteTurnResult",
    "CreateSemanticResult",
    "BulkCreateSemanticResult",
    "CreateEpisodicResult",
    "CreateTaxonomicResult",
    "CreateProceduralResult",
    "CreateUserContextResult",
    "CreateSnapshotResult",
    "PromoteSnapshotResult",
    "DeleteResult",
    "InternalStateResult",
    "ISGenerationResult",
    # Retrieval enums
    "MemorySource",
    "FormatStyle",
    "ModelType",
    # Retrieval models
    "MemoryChunk",
    "ContextConfig",
    "ContextMetadata",
    "ContextResponse",
]
