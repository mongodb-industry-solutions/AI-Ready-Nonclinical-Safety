"""
Canonical Pydantic models for Memory API.

These models define the request/response types for the Memory Server HTTP API
and are used by both MemoryClient and the server routes.

Single source of truth for Memory API types.
"""

from __future__ import annotations

from collections.abc import Iterable
from datetime import datetime
from enum import Enum
from typing import Any, cast

from pydantic import BaseModel, Field, field_validator, model_validator

# =============================================================================
# Result Models (Operation Results)
# =============================================================================


class WriteTurnResult(BaseModel):
    """Result of writing a conversation turn."""

    id: str = Field(..., description="Created document ID")
    session_id: str = Field(..., description="Session ID")
    turn_seq: int = Field(..., description="Turn sequence number")
    acknowledged: bool = Field(
        default=True, description="Whether operation was acknowledged"
    )


class CreateSemanticResult(BaseModel):
    """Result of creating a semantic memory."""

    id: str = Field(..., description="Created document ID")
    label: str = Field(..., description="Label of the memory")
    has_embedding: bool = Field(..., description="Whether embedding was generated")
    acknowledged: bool = Field(
        default=True, description="Whether operation was acknowledged"
    )


class BulkCreateSemanticResult(BaseModel):
    """Result of bulk creating semantic memories."""

    created_count: int = Field(..., description="Number of memories created")
    skipped_count: int = Field(..., description="Number of duplicates skipped")
    created_ids: list[str] = Field(..., description="List of created document IDs")
    skipped_labels: list[str] = Field(..., description="List of skipped labels")
    has_embeddings: bool = Field(..., description="Whether embeddings were generated")
    acknowledged: bool = Field(
        default=True, description="Whether operation was acknowledged"
    )


class CreateEpisodicResult(BaseModel):
    """Result of creating an episodic memory."""

    id: str = Field(..., description="Created document ID")
    title: str = Field(..., description="Title of the memory")
    has_embedding: bool = Field(..., description="Whether embedding was generated")
    acknowledged: bool = Field(
        default=True, description="Whether operation was acknowledged"
    )


class CreateTaxonomicResult(BaseModel):
    """Result of creating a taxonomic memory."""

    id: str = Field(..., description="Created document ID")
    domain: str = Field(..., description="Domain of the taxonomic entry")
    term: str = Field(..., description="Term defined")
    has_embedding: bool = Field(..., description="Whether embedding was generated")
    acknowledged: bool = Field(
        default=True, description="Whether operation was acknowledged"
    )


class CreateProceduralResult(BaseModel):
    """Result of creating a procedural memory."""

    id: str = Field(..., description="Created document ID")
    procedure: str = Field(..., description="Procedure name")
    has_embedding: bool = Field(..., description="Whether embedding was generated")
    acknowledged: bool = Field(
        default=True, description="Whether operation was acknowledged"
    )


class CreateUserContextResult(BaseModel):
    """Result of creating a user context memory."""

    id: str = Field(..., description="Created document ID")
    context_key: str = Field(..., description="Context key")
    acknowledged: bool = Field(
        default=True, description="Whether operation was acknowledged"
    )


class CreateSnapshotResult(BaseModel):
    """Result of creating a snapshot memory."""

    id: str = Field(..., description="Created document ID")
    session_id: str = Field(..., description="Session ID")
    message_count: int = Field(..., description="Number of messages in snapshot")
    has_embedding: bool = Field(..., description="Whether embedding was generated")
    embedding_strategy: str | None = Field(None, description="Embedding strategy used")
    snapshot_reason: str = Field(default="manual", description="Reason for snapshot")
    acknowledged: bool = Field(
        default=True, description="Whether operation was acknowledged"
    )


class PromoteSnapshotResult(BaseModel):
    """Result of promoting STM to snapshot."""

    snapshot_id: str | None = Field(
        None, description="Snapshot ID (None if no promotion)"
    )
    session_id: str = Field(..., description="Session ID")
    promoted_count: int = Field(..., description="Number of turns promoted")
    reason: str = Field(..., description="Promotion reason")
    has_embedding: bool = Field(
        default=False, description="Whether embedding was generated"
    )
    acknowledged: bool = Field(
        default=True, description="Whether operation was acknowledged"
    )


class DeleteResult(BaseModel):
    """Result of a delete operation."""

    deleted_count: int = Field(..., description="Number of documents deleted")
    acknowledged: bool = Field(
        default=True, description="Whether operation was acknowledged"
    )


class InternalStateResult(BaseModel):
    """
    Result of updating internal state.

    Returns key information for verification:
    - session_id: Which session was updated
    - version: New version number (increments on each update)
    - token_count: Token count of the new content
    - content_hash: SHA256[:16] for integrity verification
    """

    session_id: str = Field(..., description="Session ID")
    version: int = Field(..., description="New version number")
    token_count: int = Field(..., description="Token count of the content")
    content_hash: str = Field(..., description="SHA256[:16] hash for integrity")
    previous_version: int | None = Field(None, description="Previous version number")
    was_noop: bool = Field(default=False, description="True if content_hash unchanged")
    acknowledged: bool = Field(
        default=True, description="Whether operation was acknowledged"
    )


class ISGenerationResult(BaseModel):
    """
    Result of automatic IS generation via generate_is_from_turn().

    Tracks whether the update happened, was skipped, or coalesced.
    """

    updated: bool = Field(..., description="True if IS was generated and stored")
    version: int | None = Field(None, description="New IS version number")
    token_count: int | None = Field(None, description="Token count of generated IS")
    content_hash: str | None = Field(
        None, description="SHA256[:16] of generated content"
    )
    previous_version: int | None = Field(None, description="Version before this update")
    was_noop: bool = Field(default=False, description="True if content_hash unchanged")
    coalesced: bool = Field(default=False, description="True if update was queued")
    skipped_reason: str | None = Field(None, description="Why update was skipped")
    next_update_at: str | None = Field(
        None, description="ISO timestamp for next update"
    )
    model_id: str | None = Field(None, description="Model used for generation")
    events_hash: str | None = Field(None, description="Hash of input events")


# =============================================================================
# Retrieval Models (Memory Chunks and Context)
# =============================================================================


class MemorySource(str, Enum):
    """Source type for memory chunks."""

    STM = "stm"
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    TAXONOMIC = "taxonomic"
    PROCEDURAL = "procedural"


class FormatStyle(str, Enum):
    """Format style for context output."""

    OPENAI = "openai"
    CLAUDE = "claude"
    JINJA2 = "jinja2"


class ModelType(str, Enum):
    """Model type for context formatting."""

    OPENAI = "openai"
    CLAUDE = "claude"
    ANTHROPIC = "anthropic"
    GEMINI = "gemini"
    GENERIC = "generic"


class MemoryChunk(BaseModel):
    """
    Unified representation of memory from any source (STM, episodic, semantic).

    This model provides a common interface for memory chunks retrieved from
    different memory types, enabling uniform processing in the retrieval pipeline.
    """

    id: str = Field(..., description="Memory document ID")
    content: str = Field(..., description="Text content of the memory chunk")
    source: MemorySource = Field(
        ..., description="Source type: stm, episodic, or semantic"
    )
    timestamp: datetime = Field(
        ..., description="Timestamp when the memory was created"
    )
    embedding: list[float] | None = Field(
        default=None, description="Vector embedding for the memory chunk"
    )
    similarity_score: float | None = Field(
        default=None, description="Similarity score from vector search (0.0-1.0)"
    )
    metadata: dict[str, Any] | None = Field(
        default=None,
        description="Additional metadata about the memory chunk",
    )

    model_config = {
        "arbitrary_types_allowed": True,
        "use_enum_values": True,
    }

    @property
    def org_id(self) -> str | None:
        """Get org_id from metadata if available."""
        if self.metadata:
            return self.metadata.get("org_id")
        return None


class ContextConfig(BaseModel):
    """
    Configuration for context building.

    Controls how memories are retrieved, ranked, and formatted into context
    for LLM consumption.
    """

    max_tokens: int = Field(
        default=16000,
        ge=1,
        description="Maximum token budget for the context",
    )
    token_buffer: int = Field(
        default=500,
        ge=0,
        description="Reserve tokens for formatting overhead",
    )
    format_style: FormatStyle = Field(
        default=FormatStyle.OPENAI,
        description="Format style for context output: openai, claude, or jinja2",
    )
    model_type: ModelType = Field(
        default=ModelType.OPENAI,
        description="Model type for context formatting",
    )
    similarity_threshold: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
        description="Minimum similarity score threshold (0.0-1.0)",
    )
    ranking_weights: dict[str, float] = Field(
        default_factory=dict,
        description="Weights for ranking factors",
    )
    enabled_sources: set[MemorySource] = Field(
        default_factory=lambda: {MemorySource.EPISODIC, MemorySource.SEMANTIC},
        description="Set of memory sources to include",
    )
    include_memories: bool = Field(
        default=False,
        description="If True, attach selected MemoryChunks to response",
    )

    @field_validator("model_type", mode="before")
    @classmethod
    def validate_model_type(cls, v: Any) -> Any:
        """Convert string to ModelType enum if needed."""
        if isinstance(v, str):
            return ModelType(v.lower())
        return v

    @field_validator("format_style", mode="before")
    @classmethod
    def validate_format_style(cls, v: Any) -> Any:
        """Convert string to FormatStyle enum if needed."""
        if isinstance(v, str):
            return FormatStyle(v.lower())
        return v

    @field_validator("enabled_sources", mode="before")
    @classmethod
    def validate_enabled_sources(cls, v: Any) -> Any:
        """Convert string literals to MemorySource enum values."""
        if isinstance(v, (list, set)):
            values = cast(Iterable[Any], v)
            return {
                MemorySource(source) if isinstance(source, str) else source
                for source in values
            }
        return v

    @model_validator(mode="after")
    def validate_config(self) -> ContextConfig:
        """Validate configuration constraints."""
        if not self.enabled_sources:
            raise ValueError("enabled_sources cannot be empty")
        return self

    model_config = {
        "use_enum_values": True,
    }


class ContextMetadata(BaseModel):
    """
    Metadata about the context building process.

    Provides information about token usage, memory counts, and timing.
    """

    token_count: int = Field(
        default=0,
        ge=0,
        description="Total token count in the formatted context",
    )
    memory_counts: dict[str, int] = Field(
        default_factory=dict,
        description="Count of memories by source type",
    )
    timing: dict[str, float] = Field(
        default_factory=dict,
        description="Timing information in seconds",
    )


class ContextResponse(BaseModel):
    """
    Final response model for context building.

    Contains the formatted context and metadata about the retrieval process.
    """

    formatted_context: str | list[dict[str, Any]] = Field(
        ...,
        description="Formatted context as string or list of dicts",
    )
    metadata: ContextMetadata = Field(
        ...,
        description="Metadata about the context building process",
    )
    selected_memories: list[MemoryChunk] | None = Field(
        default=None,
        description="Selected memory chunks (only if include_memories=True)",
    )

    model_config = {
        "arbitrary_types_allowed": True,
    }


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Result models
    "WriteTurnResult",
    "CreateSemanticResult",
    "BulkCreateSemanticResult",
    "CreateEpisodicResult",
    "CreateTaxonomicResult",
    "CreateProceduralResult",
    "CreateUserContextResult",
    "CreateSnapshotResult",
    "PromoteSnapshotResult",
    "DeleteResult",
    "InternalStateResult",
    "ISGenerationResult",
    # Retrieval enums
    "MemorySource",
    "FormatStyle",
    "ModelType",
    # Retrieval models
    "MemoryChunk",
    "ContextConfig",
    "ContextMetadata",
    "ContextResponse",
]
