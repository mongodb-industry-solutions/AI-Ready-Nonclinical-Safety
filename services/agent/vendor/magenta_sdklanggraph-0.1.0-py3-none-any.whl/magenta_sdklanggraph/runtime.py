"""LangChain SDK Runtime"""

from __future__ import annotations

import logging
import os
from collections.abc import Callable, Sequence
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from magenta_sdklanggraph.agent import PrepareAgentInput

from langchain_core.language_models import BaseChatModel
from langchain_core.tools import StructuredTool
from langchain_core.tools import tool as lc_tool
from magenta_sdk_core import BaseApp, ToolDefinition

from magenta_sdklanggraph.secure_llm import SecureWrappedLLM
from runner_shared import (
    RuntimeAgentConfig,
    RuntimeLLMConfig,
    RuntimeMode,
    SuspendPayload,
    TenantRuntime,
)
from runner_shared.context import (
    get_current_session_id,
    get_current_user_id,
    get_current_wrapper,
)
from runner_shared.db_config import get_store_db_name
from runner_shared.mcp_tools import (
    MCPConfigError,
    MCPToolBinding,
    discover_mcp_tools,
    make_mcp_tool_pod_callable,
    make_sync_mcp_tool_callable,
    mcp_server_network_hosts,
)
from runner_shared.utils import get_env_bool, get_env_float

logger = logging.getLogger(__name__)

_UNSET = object()  # Sentinel for "use default" -- distinct from None

DEFAULT_TOP_K = 10


def _default_user_id_for_read(
    user_id: str | None, visibility: str | None
) -> str | None:
    """Return the principal user_id when neither user_id nor visibility is provided."""
    if user_id is None and visibility is None:
        return get_current_user_id() or None
    return user_id


CHECKPOINTER_SERVER_SELECTION_TIMEOUT_ENV = "CHECKPOINTER_SERVER_SELECTION_TIMEOUT"
CHECKPOINTER_CONNECT_TIMEOUT_ENV = "CHECKPOINTER_CONNECT_TIMEOUT"
CHECKPOINTER_SOCKET_TIMEOUT_ENV = "CHECKPOINTER_SOCKET_TIMEOUT"


def _checkpointer_timeout_ms(name: str, default_s: float) -> int:
    return int(get_env_float(name, default_s) * 1000)


class Memory:
    """Memory interface for semantic, episodic, and taxonomic memories.

    Provides access to all memory operations via app.memory property.
    All methods delegate to the underlying TenantRuntime.
    """

    def __init__(self, runtime: TenantRuntime):
        """Initialize Memory with a TenantRuntime instance.

        Args:
            runtime: TenantRuntime instance to delegate to
        """
        self._runtime = runtime

    # =========================================================================
    # Semantic Memory - Facts, customer profiles
    # =========================================================================

    def save_semantic(
        self,
        text: str,
        label: str,
        user_id: str | None = None,
        source: str = "agent",
        visibility: str = "private",
        metadata: dict[str, Any] | None = None,
        upsert: bool = True,
        agent_id: str | None = None,
    ) -> bool:
        """Save semantic memory (facts, customer profiles).

        Args:
            text: Memory content to store
            label: Unique label/identifier
            user_id: User ID (defaults to current execution context user)
            source: Source of memory (default: "agent")
            visibility: Memory visibility (private, shared, org)
            metadata: Optional contextual metadata
            upsert: If True, update existing memory with same label

        Returns:
            True if saved successfully
        """
        return self._runtime.save_semantic(
            text=text,
            label=label,
            user_id=user_id,
            source=source,
            visibility=visibility,
            metadata=metadata,
            upsert=upsert,
            agent_id=agent_id,
        )

    def search_semantic(
        self,
        query: str,
        user_id: str | None = None,
        visibility: str | None = None,
        top_k: int = DEFAULT_TOP_K,
    ) -> list[dict[str, Any]]:
        """Search semantic memories.

        Args:
            query: Search query text
            user_id: User ID filter (defaults to principal if visibility also None)
            visibility: Optional visibility filter (private, shared, org)
            top_k: Maximum number of results

        Returns:
            List of matching memories with label, text, and metadata
        """
        user_id = _default_user_id_for_read(user_id, visibility)
        return self._runtime.search_semantic(
            query=query,
            user_id=user_id,
            visibility=visibility,
            top_k=top_k,
        )

    def get_semantic(
        self,
        label: str,
        user_id: str | None = None,
        visibility: str | None = None,
    ) -> dict[str, Any] | None:
        """Get a specific semantic memory by label.

        Args:
            label: Memory label
            user_id: User ID filter (defaults to principal if visibility also None)
            visibility: Optional visibility filter (private, shared, org)

        Returns:
            Dict with memory details, or None if not found
        """
        user_id = _default_user_id_for_read(user_id, visibility)
        return self._runtime.get_semantic(
            label=label, user_id=user_id, visibility=visibility
        )

    # =========================================================================
    # Episodic Memory - Conversation summaries
    # =========================================================================

    def save_episode(
        self,
        title: str,
        content: str,
        user_id: str | None = None,
        summary: str | None = None,
        session_id: str | None = None,
        participants: list[str] | None = None,
        tags: list[str] | None = None,
        visibility: str = "private",
        agent_id: str | None = None,
    ) -> str | None:
        """Save episodic memory (conversation summary).

        Args:
            title: Title/label for this episode
            content: Full content of the episode
            user_id: User ID (defaults to current execution context user)
            summary: Brief summary for search/display
            session_id: Session ID
            participants: List of participants
            tags: Tags for categorization
            visibility: Visibility scope (default: "private")

        Returns:
            Created document ID, or None if creation fails
        """
        return self._runtime.save_episode(
            title=title,
            content=content,
            user_id=user_id,
            summary=summary,
            session_id=session_id or get_current_session_id(),
            participants=participants,
            tags=tags,
            visibility=visibility,
            agent_id=agent_id,
        )

    def search_episodes(
        self,
        query: str,
        user_id: str | None = None,
        visibility: str | None = None,
        session_id: str | None = None,
        top_k: int = DEFAULT_TOP_K,
    ) -> list[dict[str, Any]]:
        """Search past episodes.

        Args:
            query: Search query text
            user_id: User ID filter (defaults to principal if visibility also None)
            visibility: Optional visibility filter (private, shared, org)
            session_id: Optional session ID filter
            top_k: Maximum number of results

        Returns:
            List of matching episodes with title, content, summary
        """
        user_id = _default_user_id_for_read(user_id, visibility)
        return self._runtime.search_episodes(
            query=query,
            user_id=user_id,
            visibility=visibility,
            session_id=session_id,
            top_k=top_k,
        )

    def list_episodes(
        self,
        user_id: str | None = None,
        visibility: str | None = None,
        session_id: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """List episodic memories with optional filters.

        Args:
            user_id: User ID filter (defaults to principal if visibility also None)
            visibility: Optional visibility filter (private, shared, org)
            session_id: Optional session ID filter
            limit: Maximum number of results

        Returns:
            List of episodic memory entries
        """
        user_id = _default_user_id_for_read(user_id, visibility)
        return self._runtime.list_episodes(
            user_id=user_id,
            visibility=visibility,
            session_id=session_id,
            limit=limit,
        )

    # =========================================================================
    # Taxonomic Memory - Knowledge base
    # =========================================================================

    def save_taxonomic(
        self,
        domain: str,
        term: str,
        definition: str,
        related_terms: list[str] | None = None,
        visibility: str = "org",
        user_id: str | None = None,
    ) -> str | None:
        """Save taxonomic term (knowledge base entry).

        Args:
            domain: Domain/category for this term
            term: The term being defined
            definition: Definition of the term
            related_terms: Related terms for semantic linking
            visibility: Visibility scope (default: "org")
            user_id: User ID (uses "system" if not provided)

        Returns:
            Created document ID, or None if creation fails
        """
        return self._runtime.create_taxonomic(
            domain=domain,
            term=term,
            definition=definition,
            related_terms=related_terms,
            visibility=visibility,
            user_id=user_id,
        )

    def search_taxonomic(
        self,
        query: str,
        user_id: str | None = None,
        domain: str | None = None,
        visibility: str | None = None,
        top_k: int = DEFAULT_TOP_K,
    ) -> list[dict[str, Any]]:
        """Search knowledge base.

        Args:
            query: Search query text
            user_id: User ID filter (defaults to principal if visibility also None)
            domain: Optional domain filter
            visibility: Optional visibility filter (private, shared, org)
            top_k: Maximum number of results

        Returns:
            List of matching terms with term, definition, and related_terms
        """
        user_id = _default_user_id_for_read(user_id, visibility)
        return self._runtime.search_taxonomic(
            query=query,
            user_id=user_id,
            domain=domain,
            visibility=visibility,
            top_k=top_k,
        )

    def get_taxonomic_term(
        self,
        domain: str,
        term: str,
        user_id: str | None = None,
        visibility: str | None = None,
    ) -> dict[str, Any] | None:
        """Get specific knowledge base term.

        Args:
            domain: Domain name
            term: Term name
            user_id: User ID filter (defaults to principal if visibility also None)
            visibility: Optional visibility filter (private, shared, org)

        Returns:
            Dict with term details, or None if not found
        """
        user_id = _default_user_id_for_read(user_id, visibility)
        return self._runtime.get_taxonomic_term(
            domain=domain,
            term=term,
            user_id=user_id,
            visibility=visibility,
        )

    def list_domains(
        self,
        visibility: str | None = None,
    ) -> list[str]:
        """List all knowledge base domains.

        Args:
            visibility: Optional visibility filter (private, shared, org)

        Returns:
            List of domain names
        """
        return self._runtime.list_taxonomic_domains(visibility=visibility)

    # =========================================================================
    # Procedural Memory - Reusable workflows
    # =========================================================================

    def discover_procedures(
        self,
        query: str,
        user_id: str | None = None,
        *,
        visibility: str | None = None,
        tags: list[str] | None = None,
        top_k: int = 10,
        similarity_threshold: float = 0.0,
        metadata_filter: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Discover procedures matching a query without loading full content."""
        user_id = _default_user_id_for_read(user_id, visibility)
        return self._runtime.discover_procedures(
            query=query,
            user_id=user_id,
            visibility=visibility,
            tags=tags,
            top_k=top_k,
            similarity_threshold=similarity_threshold,
            metadata_filter=metadata_filter,
        )

    def get_procedure(
        self,
        procedure_name: str,
        *,
        user_id: str | None = None,
        visibility: str | None = None,
        include_deleted: bool = False,
    ) -> dict[str, Any] | None:
        """Get a full procedural memory by procedure name."""
        user_id = _default_user_id_for_read(user_id, visibility)
        return self._runtime.get_procedure(
            procedure_name=procedure_name,
            user_id=user_id,
            visibility=visibility,
            include_deleted=include_deleted,
        )

    def save_procedure(
        self,
        *,
        procedure: str,
        description: str,
        content: str,
        user_id: str | None = None,
        steps: list[dict[str, Any]] | None = None,
        resources: list[dict[str, Any]] | None = None,
        allowed_tools: list[str] | None = None,
        compatibility: str | None = None,
        license: str | None = None,
        trigger_conditions: list[str] | None = None,
        tags: list[str] | None = None,
        visibility: str = "private",
        agent_id: str | None = None,
        extraction_source: str | None = None,
        source_format: str | None = None,
        source_path: str | None = None,
        update_existing: bool = False,
    ) -> dict[str, Any] | None:
        """Create or update a procedural memory."""
        return self._runtime.save_procedure(
            procedure=procedure,
            description=description,
            content=content,
            user_id=user_id,
            steps=steps,
            resources=resources,
            allowed_tools=allowed_tools,
            compatibility=compatibility,
            license=license,
            trigger_conditions=trigger_conditions,
            tags=tags,
            visibility=visibility,
            agent_id=agent_id,
            extraction_source=extraction_source,
            source_format=source_format,
            source_path=source_path,
            update_existing=update_existing,
        )

    # =========================================================================
    # Context Building
    # =========================================================================

    def build_context(
        self,
        query: str,
        user_id: str | None = None,
        session_id: str | None = None,
        visibility: str | None = None,
        metadata_filter: dict[str, Any] | None = None,
        enabled_sources: set[str] | None = None,
        *,
        thread_id: str | None = None,
    ) -> str:
        """Build unified memory context from all memory types.

        Args:
            query: The user's query/message
            user_id: User ID (defaults to principal if visibility also omitted)
            session_id: Session ID
            visibility: Visibility scope filter (private, shared, org)
            metadata_filter: Field-level metadata filter
            enabled_sources: Memory sources to include
            thread_id: Deprecated alias for session_id

        Returns:
            Formatted context string, or empty string if memory disabled
        """
        user_id = _default_user_id_for_read(user_id, visibility)
        resolved_session_id = session_id or thread_id or get_current_session_id()
        return self._runtime.build_context(
            query=query,
            user_id=user_id,
            session_id=resolved_session_id,
            visibility=visibility,
            metadata_filter=metadata_filter,
            enabled_sources=enabled_sources,
        )


class App(BaseApp):
    """LangChain SDK for MongoDB Agentic Platform.

    Example:
    ```python
        from magenta_sdklanggraph import App
        from langchain_openai import ChatOpenAI

        app = App(app_name="My Agent")

        @app.tool()
        def my_tool(query: str) -> str:
            return "result"

        @app.entrypoint
        def build_agent():
            llm = app.llm(ChatOpenAI(model="gpt-4"))
            checkpointer = app.checkpointer()
            tools = app.get_tools()
            # Build LangGraph...
            return graph
    ```
    """

    def __init__(
        self,
        app_name: str,
        app_version: str = "1.0.0",
        mongodb_uri: str | None = None,
        database_name: str | None = None,
        enable_tracing: bool | None = None,
        traces_collection_name: str = "traces",
        enable_memory: bool | None = None,
        org_id: str | None = None,
    ):
        """Initialize the App.

        Args:
            app_name: Application name
            app_version: Application version
            mongodb_uri: MongoDB URI
            database_name: Database name
            enable_tracing: Deprecated. Tracing is always enabled.
            traces_collection_name: Collection name for trace storage
            enable_memory: Deprecated. Use agent.yaml features.memory instead.
            org_id: Organization ID for multi-tenant isolation
        """
        super().__init__(name=app_name)
        self._runtime = TenantRuntime(
            app_name=app_name,
            app_version=app_version,
            mongodb_uri=mongodb_uri,
            database_name=database_name,
            enable_tracing=enable_tracing,
            traces_collection_name=traces_collection_name,
            enable_memory=enable_memory,
            org_id=org_id,
        )
        self._memory: Memory | None = None
        self._builder_fn: Callable[..., Any] | None = None
        self._prepare_input_fn: PrepareAgentInput | None = None
        self._tool_defs: list[ToolDefinition] = []
        self._lc_tools: dict[str, Any] = {}
        self._mongo_client: Any | None = None
        self._checkpointer: Any | None = None
        if self._runtime.mode == RuntimeMode.AER:
            self._register_mcp_tools_from_config()

    @property
    def agent_config(self) -> RuntimeAgentConfig:
        """Return the runtime SDK's parsed view of agent.yaml."""
        return self._runtime.agent_config

    @property
    def llm_config(self) -> RuntimeLLMConfig:
        """Return the raw LLM config hints from agent.yaml."""
        return self._runtime.llm_config

    @property
    def memory(self) -> Memory:
        """Access memory interface.

        Returns:
            Memory instance for semantic, episodic, and taxonomic operations
        """
        if self._memory is None:
            self._memory = Memory(self._runtime)
        return self._memory

    # =========================================================================
    # BaseApp contract
    # =========================================================================

    def get_tool_definitions(self) -> list[ToolDefinition]:
        """Return sdk-core ToolDefinitions for all registered tools."""
        return list(self._tool_defs)

    def tools(self) -> list[Any]:
        """Return wrapped, LangGraph-specific tools for ToolNode."""
        return self.get_tools()

    # =========================================================================
    # Decorator API
    # =========================================================================

    def _register_mcp_tools_from_config(self) -> None:
        mcp_config = self.agent_config.mcp
        if not mcp_config.servers:
            return

        for binding in discover_mcp_tools(mcp_config):
            self._register_mcp_tool(binding)

    def _register_mcp_tool(self, binding: MCPToolBinding) -> None:
        tool_pod_callable = make_mcp_tool_pod_callable(binding)
        description = (
            binding.description or f"Remote MCP tool {binding.tool_name}"
        ).strip()
        langchain_tool = StructuredTool.from_function(
            func=make_sync_mcp_tool_callable(binding),
            coroutine=tool_pod_callable,
            name=binding.sdk_tool_name,
            description=description,
            args_schema=binding.input_schema,
        )

        self._register_tool_definition(
            name=binding.sdk_tool_name,
            func=tool_pod_callable,
            description=description,
            args_schema=binding.input_schema,
            is_local=False,
            catalog=None,
            network=mcp_server_network_hosts(binding.server_config),
            timeout_seconds=binding.server_config.timeout_seconds,
            redact_fields=[],
            langchain_tool=langchain_tool,
            additional_metadata={
                "mcp_server": binding.server_name,
                "mcp_tool": binding.tool_name,
            },
            source="mcp",
        )

    def _register_tool_definition(
        self,
        *,
        name: str,
        func: Callable[..., Any],
        description: str,
        args_schema: dict[str, Any],
        is_local: bool,
        catalog: str | None,
        network: list[str],
        timeout_seconds: int,
        redact_fields: list[str],
        langchain_tool: Any | None = None,
        additional_metadata: dict[str, Any] | None = None,
        source: Literal["decorator", "mcp"] = "decorator",
    ) -> None:
        if name in self._runtime._tools or name in self._lc_tools:
            message = f"tool {name!r} is already registered"
            if source == "mcp":
                raise MCPConfigError(f"mcp {message}")
            raise ValueError(message)

        description = description.strip()
        metadata = {
            "name": name,
            "description": description,
            "is_local": is_local,
            "catalog": catalog,
            "network": network,
            "timeout_seconds": timeout_seconds,
            "redact_fields": redact_fields,
        }
        if additional_metadata:
            metadata.update(additional_metadata)

        self._runtime.register_tool(
            name=name,
            func=func,
            metadata=metadata,
        )

        self._lc_tools[name] = (
            langchain_tool if langchain_tool is not None else lc_tool(func)
        )
        self._tool_defs.append(
            ToolDefinition(
                name=name,
                description=description,
                args_schema=args_schema,
                callable=func,
                remote=not is_local,
                catalog=catalog,
                network=network,
                timeout_seconds=timeout_seconds,
                redact_fields=redact_fields,
            )
        )

    def tool(
        self,
        is_local: bool = True,
        *,
        catalog: str | None = None,
        network: list[str] | None = None,
        timeout: int = 30,
        redact_fields: list[str] | None = None,
    ):
        """Register a tool function.

        Creates a LangChain tool and registers the raw function on the runtime
        for Tool Pod execution.

        Args:
            is_local: If True, runs in AER; if False, runs in Tool Pod (default: True)
            catalog: Catalog policy ID
            network: Allowed network hosts (for tool pod)
            timeout: Execution timeout in seconds
            redact_fields: Fields to redact in logs

        Returns:
            Decorator function
        """
        app = self

        def wrapper(fn: Callable[..., Any]) -> Any:
            # Resolve effective values from catalog policy
            effective_network = network or []
            effective_timeout = timeout
            effective_redact = redact_fields or []
            effective_is_local = is_local

            if catalog:
                try:
                    from runner_shared.catalog import load_policy

                    policy = load_policy(catalog)
                    effective_network = policy.network or effective_network
                    effective_timeout = policy.timeout_seconds or effective_timeout
                    effective_redact = policy.redact_fields or effective_redact
                    effective_is_local = (
                        policy.is_local if policy.is_local is not None else is_local
                    )
                    logger.debug(
                        "Loaded catalog policy '%s' for tool %s", catalog, fn.__name__
                    )
                except ValueError as e:
                    logger.warning("Catalog policy '%s' not found: %s", catalog, e)
                except Exception as e:
                    logger.warning("Failed to load catalog policy '%s': %s", catalog, e)

            app._register_tool_definition(
                name=fn.__name__,
                func=fn,
                description=fn.__doc__ or "",
                args_schema={},
                is_local=effective_is_local,
                catalog=catalog,
                network=effective_network,
                timeout_seconds=effective_timeout,
                redact_fields=effective_redact,
                langchain_tool=lc_tool(fn),
            )

            return fn

        return wrapper

    def entrypoint(self, fn: Callable[..., Any]) -> Callable[..., Any]:
        """Mark the graph builder function.

        Args:
            fn: Function that builds and returns a CompiledStateGraph

        Returns:
            The original function (unchanged)
        """
        self._builder_fn = fn
        return fn

    def prepare_agent_input(self, fn: PrepareAgentInput) -> PrepareAgentInput:
        """Register a hook that builds graph input from the invocation.

        The hook receives the framework-neutral ``AgentInput`` (the opaque
        caller payload) and ``RequestContext``, and returns a value LangGraph
        can ingest directly — a graph state dict or a ``Command``. It lets an
        agent author control how the request becomes the graph's starting
        input (e.g. fold extra payload context into the prompt, seed a system
        message, or populate custom state keys).

        Only fresh invocations flow through the hook; HITL resume stays
        platform-managed. When no hook is registered, the default
        message-wrapping behavior is used, so existing agents are unaffected.

        Example:

        ```python
        @app.prepare_agent_input
        def prepare(input: AgentInput, ctx: RequestContext) -> GraphInput:
            payload = input.payload
            return {
                "messages": [HumanMessage(content=payload["message"])],
                "extra": payload.get("extra"),
            }
        ```

        Args:
            fn: Callable ``(AgentInput, RequestContext) -> GraphInput``.

        Returns:
            The original function (unchanged), so it can be used as a decorator.
        """
        self._prepare_input_fn = fn
        return fn

    def get_agent(self, callbacks: list[Any] | None = None) -> Any:
        """Build and return a BaseAgent instance.

        Calls the registered entrypoint function to build the graph,
        then wraps it in a LangGraphBaseAgent adapter.

        Args:
            callbacks: Optional list of BaseExecutionCallback instances
                for observability (e.g., NodeExecutionLogger from the AER).
                Wrapped in LangGraphCallbackAdapter before passing to the graph.

        Returns:
            LangGraphBaseAgent instance implementing BaseAgent protocol

        Raises:
            RuntimeError: If no entrypoint function has been registered
        """
        if self._builder_fn is None:
            raise RuntimeError(
                "No entrypoint registered. Use @app.entrypoint to mark "
                "the graph builder function."
            )

        from .agent import LangGraphBaseAgent
        from .node_logger_adapter import LangGraphCallbackAdapter

        # Wrap BaseExecutionCallback instances as LangChain callbacks.
        # The only caller is the AER, which passes NodeExecutionLogger.
        adapted_callbacks = None
        if callbacks:
            adapted_callbacks = []
            for cb in callbacks:
                adapted_callbacks.append(LangGraphCallbackAdapter(cb))

        from runner_shared.hooks import reset_llm_registry

        reset_llm_registry()
        graph = self._builder_fn()
        return LangGraphBaseAgent(
            graph,
            callbacks=adapted_callbacks,
            prepare_input=self._prepare_input_fn,
        )

    def run(self, **kwargs) -> None:
        """Start the agent service.

        Registers the builder function and starts the runtime server. This is
        called by the platform entrypoint dispatcher.

        Args:
            **kwargs: Runtime startup options passed to the runtime.
                ``grpc_port`` and ``log_level`` are supported.
                Deprecated ``host`` and ``http_port`` values are still accepted
                for backwards compatibility but are ignored by runner-shared.

        Raises:
            RuntimeError: If no @app.entrypoint has been registered
        """
        if self._builder_fn is None:
            raise RuntimeError(
                "No @app.entrypoint registered. Decorate your graph-builder "
                "function with @app.entrypoint before calling run()."
            )
        # Register framework hooks so runner-shared can call framework
        # code without importing it directly.
        self._register_hooks()

        # Re-run the instrumentor now that the hook is registered.
        # TenantRuntime.__init__ already called setup_tracing() (which sets
        # up the TracerProvider), but _run_instrumentor() ran before hooks
        # were registered and was a no-op. This second call enables the
        # LangChain/OpenInference instrumentation.
        from runner_shared.tracing.setup import _run_instrumentor

        _run_instrumentor()

        # Register the LangGraph query plugin so the AER's /query/sessions*
        # routes can surface framework-specific state. Skipped when no
        # checkpointer is available (MONGODB_URI not configured) or when
        # construction fails (bad URI, auth, etc.) — the routes then
        # return 501 rather than taking down the rest of the AER. Note
        # that this only sees sessions written through app.checkpointer();
        # tenants who compile their graph with a custom checkpointer will
        # get empty /query/sessions* responses.
        if self._runtime.mode == RuntimeMode.AER:
            try:
                checkpointer = self.checkpointer()
            except Exception as exc:  # noqa: BLE001 — query is non-essential
                # Log only the exception class — pymongo's URI-parsing
                # errors can echo the full ``MONGODB_URI`` (credentials
                # and all). Operators who need the underlying detail can
                # reproduce locally with DEBUG logging.
                logger.warning(
                    "Failed to construct checkpointer for query plugin (%s); "
                    "/query/sessions* will return 501",
                    type(exc).__name__,
                )
                checkpointer = None
            if checkpointer is not None:
                from magenta_sdklanggraph.query import LangGraphQueryPlugin

                self._runtime.register_query_plugin(LangGraphQueryPlugin(checkpointer))

        # Pass App instance so AER can call app.get_agent(callbacks).
        # Type ignore: TenantRuntime signature will be updated to accept App.
        self._runtime.register_and_run(self, **kwargs)  # type: ignore[arg-type]

    @staticmethod
    def _register_hooks() -> None:
        """Register framework-specific hooks."""
        from langgraph.types import interrupt

        from magenta_sdklanggraph.llm_adapter import LangChainLLMAdapter
        from runner_shared.hooks import (
            register_instrumentor,
            register_llm_adapter_factory,
            register_suspend_handler,
        )

        register_suspend_handler(interrupt)
        register_llm_adapter_factory(LangChainLLMAdapter)

        from openinference.instrumentation.langchain import LangChainInstrumentor

        register_instrumentor(lambda: LangChainInstrumentor().instrument())

    # =========================================================================
    # LLM API
    # =========================================================================

    def llm(
        self,
        llm: BaseChatModel,
        llm_id: str | None = None,
    ) -> BaseChatModel:
        """Wrap a LangChain LLM for audited I/O through the Orchestration Engine.

        For agents with a single LLM, call without ``llm_id``::

            llm = app.llm(ChatOpenAI(model="gpt-4o"))

        For agents with multiple LLMs, every call must supply a unique ``llm_id``::

            llm_a = app.llm(ChatOpenAI(model="gpt-4o"), llm_id="primary")
            llm_b = app.llm(ChatOpenAI(model="gpt-4o-mini"), llm_id="fast")

        Unnamed calls register under the sentinel id ``"__default__"``; calling
        ``app.llm()`` twice without an id therefore raises the same duplicate-id
        error as registering the same named id twice.

        Args:
            llm: LangChain LLM instance.
            llm_id: Unique identifier for this LLM. Optional when the agent uses
                a single LLM.

        Returns:
            ``SecureWrappedLLM`` in AER mode; the raw *llm* in TOOL mode.

        Raises:
            ValueError: If ``llm_id`` has already been registered (including a
                second unnamed call which collides on ``"__default__"``).
        """
        from runner_shared.hooks import register_llm

        resolved_id = llm_id if llm_id is not None else "__default__"
        register_llm(resolved_id, llm)

        if self._runtime.mode == RuntimeMode.TOOL:
            return llm
        return SecureWrappedLLM(
            llm=llm, get_wrapper=get_current_wrapper, llm_id=resolved_id
        )

    # =========================================================================
    # Deep Agent API
    # =========================================================================

    def deep_agent(
        self,
        llm: BaseChatModel,
        *,
        tools: Sequence[Any] | None = None,
        subagents: Sequence[Any] | None = None,
        system_prompt: str | None = None,
        middleware: Sequence[Any] = (),
        checkpointer: Any = _UNSET,
        store: Any = None,
        skills: list[str] | None = None,
        backend: Any = None,
    ) -> Any:
        """Create a deep agent graph pre-configured with Magenta secure routing.

        Wraps ``create_magenta_deep_agent()`` with:
        - ``SecureWrappedLLM`` as the model (all LLM calls route through OE)
        - Configurable backend (defaults to ``MagentaToolPodBackend``)
        - Checkpointer sentinel resolution (``_UNSET`` -> ``app.checkpointer()``,
          ``None`` -> disable, instance -> use directly)
        - SubAgent model validation (string model specs rejected to prevent OE bypass)

        The returned ``CompiledStateGraph`` should be used inside an
        ``@app.entrypoint`` function. ``app.get_agent()`` will then wrap it
        in ``LangGraphBaseAgent`` for AER compatibility.

        Args:
            llm: Base LLM instance to wrap with SecureWrappedLLM.
            tools: Additional tools for the deep agent (merged with built-in tools).
            subagents: SubAgent specs. Each spec with a ``model`` field must pass
                a ``BaseChatModel`` instance, not a string.
            system_prompt: Custom system instructions.
            middleware: Additional middleware (appended after built-in stack).
            checkpointer: LangGraph checkpointer for state persistence. Defaults
                to ``_UNSET`` which resolves to ``app.checkpointer()`` (MongoDB).
                Pass ``None`` to disable checkpointing. Pass a
                ``BaseCheckpointSaver`` instance to use a custom checkpointer.
            store: LangGraph store for skills and shared data.
            skills: List of filesystem paths (as ``str``) to directories containing
                SKILL.md files, or to individual SKILL.md files. Each path must be a
                ``str`` — ``pathlib.Path`` objects are NOT accepted because
                deepagents' SkillsMiddleware calls ``.rstrip("/")`` on the value
                (use ``str(path)`` at the call site if you start from a ``Path``).
                Paths are relative to the directory containing ``agent.yaml``.
                ``AGENTIC_SKILLS_DIR`` may set a different skills root, but it
                must also be relative to that same source root. When ``None``
                (default) no skills are loaded. See the "Skills" section below
                for the directory/frontmatter contract and runtime behavior.
            backend: Backend for filesystem/shell ops. Defaults to
                ``MagentaToolPodBackend`` when ``None``. Pass a custom backend
                (e.g. ``StoreBackend``) to override. **Security note:** custom
                backends bypass the default OE-audited I/O path — use only in
                tests or with backends that provide equivalent auditing.

        Skills (progressive disclosure):
            The ``skills`` parameter enables deepagents' progressive-disclosure
            pattern — the LLM sees only skill *metadata* (name + description +
            path) on turn 1 and reads the full SKILL.md body on demand via
            ``read_file(path)``. This keeps the system prompt small while still
            giving the agent access to deep domain knowledge.

        Directory layout:
            Each entry in ``skills=`` points to either a directory or a single
            SKILL.md file. When a directory is passed, ``SkillsMiddleware``
            recursively discovers every ``SKILL.md`` below it::

                /app/skills/
                  code-review-style/
                    SKILL.md
                    examples/
                      good.py
                      bad.py
                  security-checklist/
                    SKILL.md

            The skill's ``name`` must match its containing directory name.

        Frontmatter:
            Each SKILL.md must begin — at byte 0, no leading blank lines — with
            YAML frontmatter containing at minimum ``name`` and ``description``::

                ---
                name: code-review-style
                description: Load when the user asks for a code review, style
                  audit, or linting-style feedback on a pull request.
                ---

                # Code Review Style Guide
                ... skill body ...

            Malformed frontmatter (missing required keys, name vs. dirname
            mismatch, or frontmatter not at byte 0) causes ``SkillsMiddleware``
            to log a WARNING and skip the file rather than crash the agent.

        Subagent non-inheritance:
            Skills attached to the top-level agent DO NOT propagate to
            subagents. If a subagent needs the same skills, pass ``skills=`` on
            its own ``SubAgent`` spec. This is a deepagents-level behavior and
            may change in a future release.

        Runtime state:
            On the first turn, ``SkillsMiddleware.before_agent`` loads the
            metadata into ``state["skills_metadata"]`` and injects a
            ``## Skills System`` block into the system prompt. After turn 1 the
            metadata is cached on the thread; edits to SKILL.md files on disk
            are NOT picked up inside the same thread (start a new thread to
            pick up edits).

        Returns:
            CompiledStateGraph ready for LangGraphBaseAgent wrapping.

        Raises:
            RuntimeError: If any SubAgent spec uses a string model.
        """
        from magenta_sdklanggraph.deep_agent import create_magenta_deep_agent

        # Fail fast if the tenant hasn't opted into the Tool-Pod's built-in
        # filesystem / shell handlers — otherwise the deep agent would build
        # successfully here but every ``filesystem_*`` or ``shell_execute``
        # call at runtime would come back as "unknown tool" from the Tool
        # Pod, which is a confusing error surface several layers removed
        # from the real cause. Requiring the flag at construction time
        # gives the developer an immediate, actionable message.
        if not self._runtime.agent_config.feature_enabled("deep_agent", default=False):
            raise RuntimeError(
                "App.deep_agent() requires 'features.deep_agent: true' in "
                "agent.yaml. Without it the Tool-Pod does not register the "
                "built-in filesystem + shell handlers that deep agents rely "
                "on, and every MagentaToolPodBackend call would fail at "
                "runtime with 'unknown tool'. Add:\n\n"
                "    features:\n"
                "      deep_agent: true\n\n"
                "to your agent.yaml and redeploy the Tool Pod."
            )

        from runner_shared.hooks import reset_llm_registry

        reset_llm_registry()
        secure_llm = self.llm(llm)

        # Checkpointer sentinel resolution:
        # _UNSET -> delegate to app.checkpointer() (returns None outside AER)
        # None   -> disable checkpointing
        # instance -> use directly
        if checkpointer is _UNSET:
            resolved_checkpointer = self.checkpointer()
        else:
            resolved_checkpointer = checkpointer

        # Backend resolution: None -> MagentaToolPodBackend default
        if backend is None:
            from magenta_sdklanggraph.backends.toolpod import MagentaToolPodBackend

            resolved_backend = MagentaToolPodBackend()
        else:
            resolved_backend = backend

        agent_config_path = self._runtime.agent_config.path
        agent_dir = (
            agent_config_path.parent.resolve()
            if agent_config_path is not None
            else None
        )
        configured_skills_dir = os.environ.get("AGENTIC_SKILLS_DIR")
        if configured_skills_dir:
            skills_base_path = Path(configured_skills_dir)
            if skills_base_path.is_absolute():
                raise ValueError(
                    "AGENTIC_SKILLS_DIR must be relative to the agent source root; "
                    f"got {configured_skills_dir!r}"
                )
            if agent_dir is None:
                raise ValueError(
                    "AGENTIC_SKILLS_DIR requires agent.yaml to determine the "
                    "agent source root"
                )
            skills_base_path = (agent_dir / skills_base_path).resolve()
            agent_dir_str = str(agent_dir)
            skills_base_path_str = str(skills_base_path)
            if (
                os.path.commonpath([agent_dir_str, skills_base_path_str])
                != agent_dir_str
            ):
                raise ValueError(
                    "AGENTIC_SKILLS_DIR must stay within the agent source root; "
                    f"got {configured_skills_dir!r}"
                )
            skills_base_dir = skills_base_path
        else:
            skills_base_dir = agent_dir
        relative_skills = [path for path in skills or [] if not os.path.isabs(path)]
        if skills_base_dir is None and relative_skills:
            logger.warning(
                "Relative skill paths %s cannot be resolved because agent.yaml "
                "was not found and AGENTIC_SKILLS_DIR is unset",
                relative_skills,
            )

        return create_magenta_deep_agent(
            secure_llm=secure_llm,
            backend=resolved_backend,
            tools=tools,
            subagents=subagents,
            system_prompt=system_prompt,
            middleware=middleware,
            checkpointer=resolved_checkpointer,
            store=store,
            skills=skills,
            skills_base_dir=skills_base_dir,
        )

    # =========================================================================
    # Checkpointing
    # =========================================================================

    def checkpointer(self) -> Any | None:
        """Get MongoDB checkpointer for LangGraph.

        The checkpointer is created lazily on first call and cached. The
        underlying ``MongoClient`` is closed when ``App.close()`` is called.

        The database name is read from the ``MDB_AGENTIC_STORE_DB`` environment
        variable (default: ``"mdb_agentic_store"``).

        Returns:
            MongoDBSaver instance in AER mode, None otherwise
        """
        if self._runtime.mode == RuntimeMode.AER:
            if self._checkpointer is not None:
                return self._checkpointer

            checkpoint_db = get_store_db_name()

            if self._runtime.mongodb_uri:
                from langgraph.checkpoint.mongodb import MongoDBSaver
                from pymongo import MongoClient

                server_selection_timeout_ms = _checkpointer_timeout_ms(
                    CHECKPOINTER_SERVER_SELECTION_TIMEOUT_ENV, 5.0
                )
                connect_timeout_ms = _checkpointer_timeout_ms(
                    CHECKPOINTER_CONNECT_TIMEOUT_ENV, 5.0
                )
                socket_timeout_ms = _checkpointer_timeout_ms(
                    CHECKPOINTER_SOCKET_TIMEOUT_ENV, 15.0
                )
                logger.info(
                    "Using MongoDB checkpointer: db=%s "
                    "serverSelectionTimeoutMS=%d connectTimeoutMS=%d "
                    "socketTimeoutMS=%d",
                    checkpoint_db,
                    server_selection_timeout_ms,
                    connect_timeout_ms,
                    socket_timeout_ms,
                )
                client = MongoClient(
                    self._runtime.mongodb_uri,
                    serverSelectionTimeoutMS=server_selection_timeout_ms,
                    connectTimeoutMS=connect_timeout_ms,
                    socketTimeoutMS=socket_timeout_ms,
                )
                try:
                    self._checkpointer = MongoDBSaver(client, db_name=checkpoint_db)
                except Exception:
                    # MongoDBSaver construction may fail (e.g., bad URI, auth).
                    # Close the freshly-opened client before the exception
                    # propagates so every failed init does not leak a pool
                    # connection.
                    client.close()
                    raise
                self._mongo_client = client
                return self._checkpointer

            logger.warning("MongoDB URI not defined, required for checkpointer")
            return None

        logger.warning(
            "app.checkpointer() called in %s mode; checkpointing is managed "
            "by the platform in non-AER modes — returning None",
            self._runtime.mode.value,
        )
        return None

    def close(self) -> None:
        """Release resources held by this App instance.

        Closes the MongoDB client opened by :meth:`checkpointer`, if any.
        """
        if self._mongo_client is not None:
            self._mongo_client.close()
            self._mongo_client = None
            self._checkpointer = None

    # =========================================================================
    # Tools
    # =========================================================================

    def get_tools(self) -> list[Any]:
        """Get wrapped tools for ToolNode.

        In AER mode, returns tools wrapped with SecureToolWrapper that route
        all executions through OE for logging and policy enforcement.
        In other modes, returns the original LangChain tools.

        Returns:
            List of tools ready for ToolNode
        """
        tools_list = list(self._lc_tools.values())

        if self._runtime.mode != RuntimeMode.AER:
            return tools_list

        from runner_shared.secure_wrapper import create_secure_tool_function

        wrapped_tools = []
        allow_direct = get_env_bool("RUNNER_ALLOW_DIRECT_TOOL_EXECUTION", False)

        for tool_obj in tools_list:
            tool_name = tool_obj.name
            tool_metadata = self._runtime.get_tool_metadata(tool_name)
            tool_call_metadata: dict[str, str] | None = None
            mcp_server_name = tool_metadata.get("mcp_server")
            mcp_tool_name = tool_metadata.get("mcp_tool")
            if isinstance(mcp_server_name, str) and isinstance(mcp_tool_name, str):
                tool_call_metadata = {
                    "mcp_server": mcp_server_name,
                    "mcp_tool": mcp_tool_name,
                }
            wrapper_func = create_secure_tool_function(
                original_tool=tool_obj,
                tool_name=tool_name,
                allow_direct=allow_direct,
                metadata=tool_call_metadata,
            )

            wrapped_tool = StructuredTool.from_function(
                func=wrapper_func,
                name=tool_obj.name,
                description=tool_obj.description,
                args_schema=tool_obj.args_schema,
                handle_tool_error=True,
            )
            wrapped_tools.append(wrapped_tool)
            logger.debug("Wrapped tool: %s", tool_name)

        return wrapped_tools

    def get_tool_schemas(self) -> list[Any]:
        """Get tool schemas for llm.bind_tools().

        Returns:
            List of original LangChain tools (not wrapped)
        """
        return list(self._lc_tools.values())

    def suspend(self, reason: str, context: dict[str, Any]) -> str:
        """Generates a suspend command. If a tool should suspend, return the result
        of this function.
        """
        return SuspendPayload(
            suspend_reason=reason,
            suspend_context=context,
        ).to_json()

    # =========================================================================
    # Guardrails
    # =========================================================================

    def validate_llm_response(self, response: Any) -> Any:
        """Apply guardrails validation to LLM response.

        Checks if the response has content (and no tool calls), runs guardrails
        validation, and returns a new AIMessage with validated content if
        modifications were made.

        Args:
            response: LangChain AIMessage or similar response object

        Returns:
            Original or modified response after validation
        """
        has_content = (
            hasattr(response, "content")
            and isinstance(response.content, str)
            and response.content
        )
        has_tool_calls = hasattr(response, "tool_calls") and response.tool_calls

        if not has_content or has_tool_calls:
            return response

        validated_content = self._runtime.validate_output(response.content)

        if validated_content != response.content:
            from langchain_core.messages import AIMessage

            return AIMessage(
                content=validated_content,
                tool_calls=getattr(response, "tool_calls", None),
                response_metadata=getattr(response, "response_metadata", {}),
            )

        return response

    def validate_output(self, text: str) -> str:
        """Validate text output using configured guardrails.

        Args:
            text: Text to validate

        Returns:
            Validated (possibly modified) text
        """
        return self._runtime.validate_output(text)

    # =========================================================================
    # Agent-to-Agent (A2A)
    # =========================================================================

    def a2a_tools(self) -> list[Any]:
        """Get LangChain tools for A2A agent discovery and invocation.

        Returns StructuredTool instances that execute in the AER process
        (not via the tool pod) because A2A requires the execution context's
        OE URL and A2A JWT.

        Bind them to the LLM and pass to ToolNode alongside any @app.tool
        tools::

            a2a = app.a2a_tools()
            llm_with_tools = llm.bind_tools(app.get_tool_schemas() + a2a)
            ToolNode(app.get_tools() + a2a)

        Returns:
            List of LangChain tools for discover_agents and invoke_agent.
            Empty list when A2A is not enabled in agent.yaml.
        """
        if not self.agent_config.a2a.enabled:
            return []

        from magenta_sdklanggraph.a2a_tools import build_a2a_tools

        return build_a2a_tools(self._runtime)

    # =========================================================================
    # Context
    # =========================================================================

    def get_current_user_id(self) -> str | None:
        """Get current execution context user ID.

        Returns:
            User ID from the current execution context, or None
        """
        return self._runtime.get_current_user_id()
