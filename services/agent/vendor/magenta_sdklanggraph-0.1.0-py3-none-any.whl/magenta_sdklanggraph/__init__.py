"""LangChain SDK for MongoDB Agentic Platform.

``MagentaToolPodBackend`` and ``create_magenta_deep_agent`` are intentionally
NOT re-exported at the package root. They depend on the optional ``deepagents``
extra and importing them eagerly from ``__init__.py`` would break any
downstream package that depends on ``magenta-sdklanggraph`` without also
declaring ``deepagents``. Import them directly when needed::

    from magenta_sdklanggraph.deep_agent import create_magenta_deep_agent
    from magenta_sdklanggraph.backends.toolpod import MagentaToolPodBackend

Or, for the common case, use ``App.deep_agent()`` which lazy-imports both.
"""

from .agent import LangGraphBaseAgent
from .runtime import App, Memory

__all__ = ["App", "LangGraphBaseAgent", "Memory"]
