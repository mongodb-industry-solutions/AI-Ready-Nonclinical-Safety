"""
SecureWrappedLLM - LangChain BaseChatModel adapter for secure LLM calls.

This is a thin adapter that provides the LangChain BaseChatModel interface
while delegating invoke_llm orchestration to SecureLLMProxy in runner-shared.
"""

from __future__ import annotations

import logging
from collections.abc import Callable, Iterator, Sequence
from typing import Any, cast

from langchain_core.callbacks.manager import CallbackManagerForLLMRun
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, AIMessageChunk, BaseMessage, ToolMessage
from langchain_core.outputs import ChatGenerationChunk, ChatResult
from magenta_sdk_core.models import LLMInvocationOptions

from magenta_sdklanggraph.messages import (
    lc_messages_to_platform,
    llm_response_to_chat_result,
    llm_stream_chunk_to_generation_chunk,
)
from runner_shared.metrics import Metrics
from runner_shared.secure_llm_proxy import SecureLLMProxy
from runner_shared.secure_wrapper import (
    LLMInvocationError,
    PolicyDeniedException,
)
from runner_shared.utils import (
    log_cached_result,
    log_llm_messages,
    log_llm_response,
    log_policy_blocked,
    log_separator,
)

# Re-export for backward compatibility (tests import from here)
__all__ = ["SecureWrappedLLM", "PolicyDeniedException", "LLMInvocationError"]

_logger = logging.getLogger(__name__)
_MISSING_TOOL_RESULT_TEMPLATE = (
    "Tool execution failed before the platform recorded a result for {tool_name}. "
    "Treat this as a failed tool call and continue with the user request."
)


def _repair_missing_tool_messages(messages: list[BaseMessage]) -> list[BaseMessage]:
    """Insert missing ToolMessages after assistant tool calls before LLM invocation.

    A tool node failure can leave a checkpoint with an assistant ``tool_calls``
    message but no matching ``ToolMessage``. Providers reject that history on
    the next LLM call, so repair the prompt sent to OE while preserving the
    original checkpoint state.
    """

    repaired: list[BaseMessage] = []
    inserted = 0
    index = 0

    while index < len(messages):
        message = messages[index]
        repaired.append(message)
        index += 1

        if not isinstance(message, AIMessage) or not message.tool_calls:
            continue

        expected: list[tuple[str, str | None]] = []
        for tool_call in message.tool_calls:
            if not isinstance(tool_call, dict):
                continue
            tool_call_id = tool_call.get("id")
            if not isinstance(tool_call_id, str) or not tool_call_id:
                continue
            tool_name = tool_call.get("name")
            expected.append(
                (tool_call_id, tool_name if isinstance(tool_name, str) else None)
            )

        if not expected:
            continue

        seen: set[str] = set()
        while index < len(messages) and isinstance(messages[index], ToolMessage):
            tool_message = cast(ToolMessage, messages[index])
            if tool_message.tool_call_id:
                seen.add(tool_message.tool_call_id)
            repaired.append(tool_message)
            index += 1

        for tool_call_id, tool_name in expected:
            if tool_call_id in seen:
                continue
            display_name = tool_name or "the requested tool"
            repaired.append(
                ToolMessage(
                    content=_MISSING_TOOL_RESULT_TEMPLATE.format(
                        tool_name=display_name
                    ),
                    tool_call_id=tool_call_id,
                    name=tool_name,
                    status="error",
                )
            )
            inserted += 1

    if inserted:
        _logger.warning(
            "Inserted %d missing tool message(s) before LLM invocation", inserted
        )
        return repaired
    return messages


class SecureWrappedLLM(BaseChatModel):
    """LangChain LLM wrapper that routes all calls through OE.

    This wraps a real LLM (Gemini, OpenAI, etc.) and delegates OE
    orchestration to SecureLLMProxy. The adapter handles:
    - LangChain ↔ sdk-core message conversion
    - Translating OE-owned invoke_llm results back into LangChain types
    - Logging and metrics (LangChain-specific concerns)

    The SecureToolWrapper is obtained via a callable at invocation time,
    allowing the graph to be built before execution context exists.
    """

    model_name: str = "secure-wrapped-llm"
    _llm: Any = None
    _get_wrapper: Any = None
    _bound_tools: Sequence[Any] = []

    def __init__(
        self,
        llm: Any,
        get_wrapper: Callable,
        llm_id: str,
        model_name: str | None = None,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)
        self._llm = llm
        self._get_wrapper = get_wrapper
        self._bound_tools = []
        self._llm_id: str = llm_id
        self.model_name = (
            model_name
            or getattr(llm, "model", None)
            or getattr(llm, "model_name", "unknown")
        )

    @property
    def _llm_type(self) -> str:
        return "secure-wrapped-llm"

    @property
    def _identifying_params(self) -> dict[str, Any]:
        return {"model_name": self.model_name, "llm_id": self._llm_id}

    def bind_tools(self, tools: Sequence[Any], **kwargs: Any) -> SecureWrappedLLM:
        """Bind tools to the LLM."""
        new_llm = SecureWrappedLLM(
            llm=self._llm.bind_tools(tools, **kwargs)
            if hasattr(self._llm, "bind_tools")
            else self._llm,
            get_wrapper=self._get_wrapper,
            llm_id=self._llm_id,
            model_name=self.model_name,
        )
        new_llm._bound_tools = tools
        return new_llm

    def _get_wrapper_or_raise(self) -> Any:
        """Get the wrapper, raising an error if not available."""
        wrapper = self._get_wrapper()
        if wrapper is None:
            raise RuntimeError(
                "SecureToolWrapper is not initialized. "
                "This means the LLM is being invoked outside of an execution context. "
                "Ensure the graph is invoked via AER's /execute endpoint."
            )
        return wrapper

    @staticmethod
    def _build_invocation_options(
        kwargs: dict[str, Any],
    ) -> LLMInvocationOptions | None:
        """Convert LangChain's loose kwargs into a typed invocation-options model."""
        if not kwargs:
            return None
        return LLMInvocationOptions.model_validate(kwargs)

    def _generate(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: CallbackManagerForLLMRun | None = None,
        **kwargs: Any,
    ) -> ChatResult:
        """Generate a response using the wrapped LLM."""
        wrapper = self._get_wrapper_or_raise()

        wrapper.step_counter += 1
        step = wrapper.step_counter

        messages = _repair_missing_tool_messages(messages)

        log_separator()
        log_llm_messages(messages, prefix="LLM")

        # Convert LangChain messages to sdk-core format
        platform_messages = lc_messages_to_platform(messages)
        options = self._build_invocation_options(kwargs)

        # Create per-call proxy and delegate
        proxy = SecureLLMProxy(
            oe_url=wrapper.oe_url,
            execution_id=wrapper.execution_id,
            llm_id=self._llm_id,
            model_name=self.model_name,
            bound_tools=list(self._bound_tools) if self._bound_tools else None,
        )

        try:
            stream_chunks = list(
                proxy.stream(
                    messages=platform_messages,
                    step=step,
                    stop=stop,
                    options=options,
                )
            )
            response = proxy.response_from_stream_chunks(stream_chunks)
        except PolicyDeniedException as e:
            log_policy_blocked("invoke_llm", step, str(e), prefix="LLM")
            raise
        except LLMInvocationError:
            Metrics.record_latency(
                "llm_call",
                proxy.last_duration_ms,
                model_name=self.model_name or "unknown",
            )
            Metrics.record_error("llm_call", model_name=self.model_name or "unknown")
            raise

        if proxy.last_latest_step_number is not None:
            wrapper.step_counter = max(
                wrapper.step_counter, proxy.last_latest_step_number
            )

        if proxy.last_from_cache:
            log_cached_result("invoke_llm", step, prefix="LLM")

        # Convert response to LangChain format
        result = llm_response_to_chat_result(response)

        # Log and record metrics
        ai_message = result.generations[0].message
        log_llm_response(ai_message, step, prefix="LLM")
        duration_ms = proxy.last_duration_ms
        Metrics.record_latency(
            "llm_call", duration_ms, model_name=self.model_name or "unknown"
        )

        return result

    def _stream(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: CallbackManagerForLLMRun | None = None,
        **kwargs: Any,
    ) -> Iterator[ChatGenerationChunk]:
        """Stream a response using the wrapped LLM."""
        wrapper = self._get_wrapper_or_raise()

        # Check if underlying LLM supports streaming BEFORE touching step counter
        # If not, delegate entirely to _generate which handles its own step/OE flow
        if not (hasattr(self._llm, "stream") and callable(self._llm.stream)):
            result = self._generate(messages, stop, run_manager, **kwargs)
            msg = result.generations[0].message
            msg_data = msg.model_dump()
            msg_data["type"] = "AIMessageChunk"
            yield ChatGenerationChunk(message=AIMessageChunk.model_validate(msg_data))
            return

        wrapper.step_counter += 1
        step = wrapper.step_counter

        messages = _repair_missing_tool_messages(messages)

        log_separator()
        log_llm_messages(messages, prefix="LLM")

        # Convert LangChain messages to sdk-core format
        platform_messages = lc_messages_to_platform(messages)
        options = self._build_invocation_options(kwargs)

        # Create per-call proxy and delegate
        proxy = SecureLLMProxy(
            oe_url=wrapper.oe_url,
            execution_id=wrapper.execution_id,
            llm_id=self._llm_id,
            model_name=self.model_name,
            bound_tools=list(self._bound_tools) if self._bound_tools else None,
        )

        try:
            for sdk_chunk in proxy.stream(
                messages=platform_messages,
                step=step,
                stop=stop,
                options=options,
            ):
                yield llm_stream_chunk_to_generation_chunk(sdk_chunk)
        except PolicyDeniedException as e:
            log_policy_blocked("invoke_llm", step, str(e), prefix="LLM")
            raise
        except LLMInvocationError:
            Metrics.record_latency(
                "llm_call",
                proxy.last_duration_ms,
                model_name=self.model_name or "unknown",
            )
            Metrics.record_error("llm_call", model_name=self.model_name or "unknown")
            raise

        if proxy.last_latest_step_number is not None:
            wrapper.step_counter = max(
                wrapper.step_counter, proxy.last_latest_step_number
            )

        if proxy.last_from_cache:
            log_cached_result("invoke_llm", step, prefix="LLM")

        # Record metrics
        Metrics.record_latency(
            "llm_call", proxy.last_duration_ms, model_name=self.model_name or "unknown"
        )
