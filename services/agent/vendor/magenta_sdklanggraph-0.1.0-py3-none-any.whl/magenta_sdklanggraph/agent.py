"""LangGraph BaseAgent adapter.

Wraps a LangGraph CompiledGraph to implement the framework-neutral BaseAgent
protocol from magenta-sdk-core. This adapter handles all LangGraph-specific
concerns including HumanMessage wrapping, Command(resume=...) construction,
and streaming mode handling.
"""

from __future__ import annotations

import asyncio
import inspect
import logging
from collections.abc import AsyncIterator, Callable, Iterable, Iterator
from dataclasses import dataclass
from typing import Any

from langchain_core.messages import AIMessage, AIMessageChunk, HumanMessage, ToolMessage
from langchain_core.runnables import RunnableConfig
from langgraph.graph.state import CompiledStateGraph
from langgraph.types import Command, Interrupt, Overwrite
from magenta_sdk_core import (
    AgentInput,
    AgentOutput,
    BaseAgent,
    ExecutionResult,
    Message,
    RequestContext,
    StreamEvent,
)

from .messages import lc_messages_to_platform

# A value LangGraph can ingest directly as the first arg to ``ainvoke``/
# ``astream``: a graph state dict or a ``Command``.
GraphInput = dict[str, Any] | Command
# Hook that maps a fresh invocation to graph input. Registered via
# ``@app.prepare_agent_input``; replaces the default message-wrapping when set.
PrepareAgentInput = Callable[[AgentInput, RequestContext], GraphInput]

__all__ = ["GraphInput", "LangGraphBaseAgent", "PrepareAgentInput"]

_logger = logging.getLogger(__name__)

# LangGraph namespace segment shape: ``"<node_name>:<task_id>"``.
_NS_TASK_SEP = ":"
# LangChain/LangGraph pregel node names; never identify a real subagent.
_NS_SENTINEL_NAMES = frozenset({"agent", "model", "tools"})

# deepagents' SubAgentMiddleware registers the dispatch tool under this name;
# any AIMessage tool_call with this name kicks off a subagent run.
_DISPATCH_TOOL_NAME = "task"
_TERMINAL_AGENT_UPDATE_DRAIN_TIMEOUT_S = 1.0


async def _aclose_stream_iter(stream_iter: Any) -> None:
    """Close an async iterator when it supports generator-style ``aclose``."""
    aclose = getattr(stream_iter, "aclose", None)
    if aclose is None:
        return
    try:
        result = aclose()
        if inspect.isawaitable(result):
            await result
    except Exception:
        _logger.warning("Failed to close LangGraph stream iterator", exc_info=True)


def _source_from_namespace(namespace: tuple[str, ...]) -> str:
    """Extract subagent attribution from a LangGraph subgraph namespace tuple.

    ``astream(..., subgraphs=True)`` yields a tuple of ``"<node>:<task_id>"``
    segments identifying the subgraph path; the root graph yields ``()``.
    Walk right-to-left, strip ``:task_id``, return the first non-sentinel
    name. Matches the deepagents streaming guide:
    https://docs.langchain.com/oss/python/deepagents/streaming.

    ``lc_agent_name`` is deliberately not used: ``create_agent`` sets it on
    the root too (commonly to ``"model"``), so any non-empty value would fire
    spurious ``subagent_start`` events on every root LLM turn.
    """
    for segment in reversed(namespace):
        name = segment.split(_NS_TASK_SEP, 1)[0]
        if name and name not in _NS_SENTINEL_NAMES:
            return name
    return ""


def _tc_get(tc: Any, key: str) -> Any:
    """Read ``key`` from a tool_call that may be a dict or a pydantic-ish object."""
    return tc.get(key) if isinstance(tc, dict) else getattr(tc, key, None)


def _unwrap_overwrite(x: Any) -> list[Any]:
    """Unwrap ``Overwrite``-wrapped messages from ``PatchToolCallsMiddleware``.

    Materializes to a list so callers can iterate it twice (extend +
    extract) without worrying about generator exhaustion.
    """
    return list(x.value) if isinstance(x, Overwrite) else list(x)


@dataclass(frozen=True)
class _TaskCall:
    """A validated parent-agent ``task`` tool_call."""

    tool_call_id: str
    subagent_name: str
    description: str


def _iter_task_calls(msgs_or_chunks: Iterable[Any]) -> Iterator[_TaskCall]:
    """Yield validated ``task`` tool_calls from any iterable of messages/chunks.

    Filters non-``task`` calls and entries whose ``id`` isn't a non-empty
    string. Caller may further filter by ``subagent_name``.
    """
    for m in msgs_or_chunks:
        for tc in getattr(m, "tool_calls", None) or []:
            if _tc_get(tc, "name") != _DISPATCH_TOOL_NAME:
                continue
            tc_id = _tc_get(tc, "id")
            if not isinstance(tc_id, str) or not tc_id:
                continue
            args = _tc_get(tc, "args")
            args_dict = args if isinstance(args, dict) else {}
            yield _TaskCall(
                tool_call_id=tc_id,
                subagent_name=str(args_dict.get("subagent_type", "") or ""),
                description=str(args_dict.get("description", "") or ""),
            )


@dataclass
class _SubagentTask:
    """Per-subagent state for stream() boundary tracking.

    ``tc_id == ""`` means tokens arrived before the parent's ``task``
    tool_call assembled; the entry lives in ``pending`` until the real
    tool_call arrives and promotes it to ``tasks_by_id``.
    """

    name: str
    tc_id: str
    description: str


def _start_event(task: _SubagentTask) -> StreamEvent:
    return StreamEvent(
        data={
            "source": task.name,
            "subagent_name": task.name,
            "tool_call_id": task.tc_id,
            "description": task.description,
        },
        event="subagent_start",
    )


def _end_event(task: _SubagentTask, summary: str | None = None) -> StreamEvent:
    return StreamEvent(
        data={
            "source": task.name,
            "subagent_name": task.name,
            "tool_call_id": task.tc_id,
            "summary": summary or "",
        },
        event="subagent_end",
    )


def _tc_id_for_source(source: str, tasks_by_id: dict[str, _SubagentTask]) -> str:
    """Return the tc_id of the first matching task for token attribution."""
    if not source:
        return ""
    for task in tasks_by_id.values():
        if task.name == source:
            return task.tc_id
    return ""


async def _on_task_call(
    call: _TaskCall,
    tasks_by_id: dict[str, _SubagentTask],
    pending: dict[str, _SubagentTask],
) -> AsyncIterator[StreamEvent]:
    """Handle a real ``task`` tool_call. Promote any pending placeholder,
    insert otherwise. Emit ``subagent_start`` once per task entry."""
    placeholder = pending.pop(call.subagent_name, None)
    if placeholder is not None:
        # Strategy A: ``_on_sourced_token`` deferred the start event so we
        # could emit it here with the real ``tool_call_id`` and ``description``.
        # Promote the placeholder into ``tasks_by_id`` and yield the
        # canonical start exactly once.
        placeholder.tc_id = call.tool_call_id
        if call.description and not placeholder.description:
            placeholder.description = call.description
        tasks_by_id[call.tool_call_id] = placeholder
        yield _start_event(placeholder)
        return

    existing = tasks_by_id.get(call.tool_call_id)
    if existing is not None:
        if call.description and not existing.description:
            existing.description = call.description
        return

    task = _SubagentTask(
        name=call.subagent_name,
        tc_id=call.tool_call_id,
        description=call.description,
    )
    tasks_by_id[call.tool_call_id] = task
    yield _start_event(task)


async def _on_sourced_token(
    source: str,
    tasks_by_id: dict[str, _SubagentTask],
    pending: dict[str, _SubagentTask],
) -> AsyncIterator[StreamEvent]:
    """First sourced token signal. Insert a synthetic placeholder into
    ``pending`` if no entry exists yet for this name. Strategy A: do NOT
    emit ``subagent_start`` here — defer until ``_on_task_call`` promotes
    the placeholder (so the start carries the real ``tool_call_id`` and
    ``description``) or until the drain path emits start+end for a
    never-promoted orphan."""
    for task in tasks_by_id.values():
        if task.name == source:
            return
    if source in pending:
        return
    placeholder = _SubagentTask(name=source, tc_id="", description="")
    pending[source] = placeholder
    # Intentionally no yield: see docstring (Strategy A).
    if False:
        yield  # pragma: no cover - keep this an async generator


async def _drain_open_tasks(
    tasks_by_id: dict[str, _SubagentTask],
    pending: dict[str, _SubagentTask],
) -> AsyncIterator[StreamEvent]:
    """Emit a defensive ``subagent_end`` for every open task, then clear.

    Tasks already in ``tasks_by_id`` had their ``subagent_start`` emitted by
    ``_on_task_call`` (placeholder-promotion or new-task branch); only the
    end is needed.

    Tasks still in ``pending`` are never-promoted synthetic-only orphans
    under Strategy A — their start was deferred. To preserve a balanced
    lifecycle on the wire, emit ``subagent_start`` immediately followed by
    ``subagent_end`` (both carrying ``tool_call_id == ""``).
    """
    for task in list(tasks_by_id.values()):
        yield _end_event(task)
    for task in list(pending.values()):
        yield _start_event(task)
        yield _end_event(task)
    tasks_by_id.clear()
    pending.clear()


def _is_terminal_agent_update(
    namespace: tuple[str, ...],
    payload: dict[str, Any],
    all_messages: list[Any],
    captured_interrupts: list[Interrupt],
    *,
    has_open_subagents: bool,
) -> bool:
    """Return true when an updates payload may be the final ReAct response.

    LangGraph 1.2.x can leave the async stream iterator open after the terminal
    ReAct ``agent`` update. The update already contains the final AI message,
    so the adapter treats this as a completion candidate and waits briefly for a
    subsequent event before finishing. Non-root subgraph updates and graphs with
    open subagent tasks are not terminal for the root run.
    """
    if (
        namespace != ()
        or captured_interrupts
        or has_open_subagents
        or "agent" not in payload
        or not all_messages
    ):
        return False
    last_message = all_messages[-1]
    return isinstance(last_message, AIMessage) and not (
        getattr(last_message, "tool_calls", []) or []
    )


class _ExecutionResult:
    """Concrete ExecutionResult that satisfies the ExecutionResult protocol."""

    def __init__(self, invoke, stream):
        self._invoke = invoke
        self._stream = stream

    def __await__(self):
        return self._invoke().__await__()

    async def __aiter__(self):
        async for event in self._stream():
            yield event


def _normalize_content(content: Any) -> str:
    """Normalize LangChain message content to a string.

    Args:
        content: Message content (str, list, or other)

    Returns:
        Normalized string content
    """
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        # Multimodal content - extract text parts
        parts = []
        for block in content:
            if isinstance(block, dict):
                if block.get("type") == "text":
                    parts.append(block.get("text", ""))
            elif isinstance(block, str):
                parts.append(block)
        return "".join(parts)
    return str(content) if content else ""


def _find_last_ai_content(messages: list[Any]) -> str:
    """Return normalized text from the last AIMessage with content.

    Skips ToolMessages, HumanMessages, and AIMessages whose text
    content is empty (common with Anthropic after tool execution).

    Args:
        messages: List of LangChain messages

    Returns:
        Content of the last AIMessage, or empty string
    """
    for msg in reversed(messages):
        if isinstance(msg, AIMessage):
            content = _normalize_content(msg.content)
            if content:
                return content
    return ""


def _normalize_checkpoint_id(value: Any) -> str | None:
    """Normalize checkpoint ids from payload values.

    Fresh executions often carry ``checkpoint_id=None`` through the payload.
    Treat that as absent instead of the literal string ``"None"``, otherwise
    we suppress latest-checkpoint lookup and start a new checkpoint root.
    """
    if value is None:
        return None

    checkpoint_id = str(value).strip()
    if not checkpoint_id or checkpoint_id.lower() == "none":
        return None

    return checkpoint_id


class LangGraphBaseAgent(BaseAgent):
    """LangGraph adapter implementing the BaseAgent protocol.

    Wraps a LangGraph CompiledGraph and provides the framework-neutral
    invoke/stream interface that the AER expects.

    This adapter handles:
    - Converting AgentInput to LangGraph state format (with HumanMessage)
    - Converting Command(resume=...) for HITL resume flows
    - Streaming with token-level events via StreamEvent
    - Converting final results to AgentOutput

    Resume state travels on the RequestContext, not the caller payload:
    - ctx.resume: Boolean indicating resume vs fresh execution
    - ctx.resume_data: Data for Command(resume=...)
    - ctx.metadata["checkpoint_id"]: Checkpoint to resume from

    Example:
    ```python
        from langgraph.graph import StateGraph
        from magenta_sdklanggraph import LangGraphBaseAgent

        # Build your graph
        graph = StateGraph(...)
        compiled = graph.compile(checkpointer=...)

        # Wrap it with optional callbacks
        agent = LangGraphBaseAgent(compiled, callbacks=[my_callback])

        # Use via BaseAgent protocol
        output = await agent.execute(ctx, agent_input)          # non-streaming
        async for event in agent.execute(ctx, agent_input):     # streaming
            ...
    ```
    """

    def __init__(
        self,
        graph: CompiledStateGraph,
        callbacks: list[Any] | None = None,
        prepare_input: PrepareAgentInput | None = None,
    ) -> None:
        """Initialize the adapter with a compiled LangGraph.

        Args:
            graph: A compiled LangGraph StateGraph with checkpointer
            callbacks: Optional list of LangChain callbacks for observability
            prepare_input: Optional tenant hook (``@app.prepare_agent_input``)
                that builds the graph input for a fresh invocation. When None,
                the default message-wrapping is used.
        """
        self._graph = graph
        self._callbacks = callbacks or []
        self._prepare_input = prepare_input

    def execute(self, ctx: RequestContext, input: AgentInput) -> ExecutionResult:
        """Run the agent. Await for a result, or iterate for streaming."""
        return _ExecutionResult(
            invoke=lambda: self.invoke(ctx, input),
            stream=lambda: self.stream(ctx, input),
        )

    def _build_graph_input(self, ctx: RequestContext, input: AgentInput) -> Any:
        """Build LangGraph input from the request context and caller payload.

        For fresh executions, builds a state dict with a HumanMessage from the
        caller payload's ``message``. For resume flows (``ctx.resume``), builds
        a ``Command(resume=ctx.resume_data)``. Identity (user/session) is read
        from ``ctx``, not the payload.

        Args:
            ctx: Request-scoped context (identity, resume state)
            input: Framework-neutral agent input (opaque caller payload)

        Returns:
            LangGraph-compatible input (state dict or Command)
        """
        if ctx.resume:
            if ctx.resume_data is None:
                raise ValueError(
                    "ctx.resume is True but resume_data is missing. "
                    "Provide resume_data to resume a suspended graph."
                )
            _logger.debug("Building Command(resume=...) for HITL resume")
            return Command(resume=ctx.resume_data)

        # Tenant-provided hook owns fresh-execution input construction.
        # Resume (above) stays platform-managed so authors never reimplement it.
        if self._prepare_input is not None:
            return self._prepare_input(input, ctx)

        # Fresh execution - build state with HumanMessage from the caller payload
        if not isinstance(input.payload, dict):
            raise TypeError(f"Expected dict payload, got {type(input.payload)}")
        input_payload: dict[str, Any] = input.payload
        message = str(input_payload.get("message", ""))
        graph_input: dict[str, Any] = {"messages": [HumanMessage(content=message)]}

        if ctx.user_id:
            graph_input["user_id"] = ctx.user_id
        if ctx.session_id:
            graph_input["session_id"] = ctx.session_id

        return graph_input

    def _build_config(self, ctx: RequestContext) -> RunnableConfig:
        """Build LangGraph config from the request context.

        Args:
            ctx: Request-scoped context

        Returns:
            LangGraph config dict with thread_id, checkpoint_id, callbacks,
            and request_context injected into configurable
        """
        # session_id is the conversation-continuity id used for checkpointing.
        thread_id = str(ctx.session_id or "default")

        config: RunnableConfig = {
            "configurable": {
                "thread_id": thread_id,
                "request_context": ctx,
            }
        }

        # checkpoint_id is opaque framework state the platform forwarded on
        # resume; read it from ctx.metadata. Synthetic "thread:" IDs are
        # resolved later to the latest real checkpoint for the thread.
        metadata = ctx.metadata or {}
        checkpoint_id = _normalize_checkpoint_id(metadata.get("checkpoint_id"))
        if checkpoint_id and not checkpoint_id.startswith("thread:"):
            config["configurable"]["checkpoint_id"] = checkpoint_id  # type: ignore[index]

        # Add callbacks if provided
        if self._callbacks:
            config["callbacks"] = list(self._callbacks)

        return config

    async def _get_checkpoint_id(self, thread_id: str) -> str | None:
        """Get the latest checkpoint ID for a thread.

        Args:
            thread_id: The thread ID to get checkpoint for

        Returns:
            Checkpoint ID string, or None if not available
        """
        checkpointer = getattr(self._graph, "checkpointer", None)
        if checkpointer is None or not hasattr(checkpointer, "aget_tuple"):
            return None

        try:
            config: RunnableConfig = {"configurable": {"thread_id": thread_id}}
            checkpoint_tuple = await checkpointer.aget_tuple(config)
            if checkpoint_tuple and hasattr(checkpoint_tuple, "checkpoint"):
                checkpoint = checkpoint_tuple.checkpoint
                if isinstance(checkpoint, dict):
                    return checkpoint.get("id")
        except Exception:
            _logger.exception(
                "Failed to get checkpoint ID for thread %s — degrading to None "
                "so the suspend StreamEvent still reaches the consumer",
                thread_id,
            )
        return None

    async def invoke(self, ctx: RequestContext, input: AgentInput) -> AgentOutput:
        """Execute the agent and return the final result.

        Args:
            ctx: Request-scoped context
            input: Framework-neutral agent input

        Returns:
            Framework-neutral agent output
        """
        graph_input = self._build_graph_input(ctx, input)
        config = self._build_config(ctx)

        result = await self._graph.ainvoke(graph_input, config)

        # Extract messages from result
        messages = result.get("messages", [])
        response = _find_last_ai_content(messages)

        is_resume = ctx.resume
        thread_id = str(ctx.session_id or "default")

        # Check for interrupt (HITL suspend)
        state = await self._graph.aget_state(config)
        if state.next:
            # Graph is paused at an interrupt
            checkpoint_id = await self._get_checkpoint_id(thread_id)
            interrupt_values = [
                intr.value
                for task in getattr(state, "tasks", [])
                if hasattr(task, "interrupts")
                for intr in task.interrupts
            ]
            suspend_context: dict[str, Any] = {
                "checkpoint_id": checkpoint_id,
                "interrupt_values": interrupt_values,
            }
            return AgentOutput(
                response={
                    "response": response,
                    "execution_id": thread_id,
                    "status": "suspended",
                    "suspend_context": suspend_context,
                    "message_count": len(messages),
                    "resumed": is_resume,
                },
            )

        return AgentOutput(
            response={
                "response": response,
                "execution_id": thread_id,
                "status": "completed",
                "message_count": len(messages),
                "resumed": is_resume,
            },
        )

    async def resume(
        self, ctx: RequestContext, input: AgentInput, decision: str
    ) -> AgentOutput:
        """Resume a suspended agent with a human decision.

        Convenience method that sets up resume value fields and delegates to invoke().

        Args:
            ctx: Request-scoped context
            input: Framework-neutral agent input (opaque caller payload)
            decision: The human decision string to resume with

        Returns:
            Framework-neutral agent output
        """
        # Resume state lives on the context, not the caller payload.
        resume_ctx = ctx.model_copy(update={"resume": True, "resume_data": decision})
        return await self.invoke(resume_ctx, input)

    async def _process_messages_chunk(
        self,
        chunk: Any,
        source: str,
        tasks_by_id: dict[str, _SubagentTask],
        pending: dict[str, _SubagentTask],
    ) -> AsyncIterator[StreamEvent]:
        """Handle one messages-mode chunk from LangGraph astream."""
        if not isinstance(chunk, AIMessageChunk):
            return

        if not source:
            # Root-namespace chunk: scan for parent ``task`` tool_calls.
            for call in _iter_task_calls([chunk]):
                if not call.subagent_name:
                    continue
                async for ev in _on_task_call(call, tasks_by_id, pending):
                    yield ev
        else:
            async for ev in _on_sourced_token(source, tasks_by_id, pending):
                yield ev

        token = _normalize_content(chunk.content)
        if token:
            yield StreamEvent(
                data={
                    "content": token,
                    "source": source,
                    "tool_call_id": _tc_id_for_source(source, tasks_by_id),
                },
                event="token",
            )

    async def _process_add_messages_update(
        self,
        msgs: Any,
        tasks_by_id: dict[str, _SubagentTask],
        pending: dict[str, _SubagentTask],
        all_messages: list[Any],
    ) -> AsyncIterator[StreamEvent]:
        """Update path — handles both subagent open (parent ``task`` tool_calls
        on AIMessages) and close (ToolMessages whose ``tool_call_id`` matches
        an open task).

        deepagents' ``task`` tool returns ``Command(update={"messages":
        [ToolMessage(..., tool_call_id=<parent_tc>)]})``, but the LangGraph
        pregel runtime unwraps the Command before streaming. So on the updates
        stream we see a plain ``{"<node>": {"messages": [ToolMessage(...)]}}``
        dict — never a raw Command. The close arrives here, not via
        ``_process_command_update`` (which is kept as a defensive fallback).
        """
        extracted = _unwrap_overwrite(msgs)
        all_messages.extend(extracted)

        # Open: AIMessages bearing ``task`` tool_calls.
        for call in _iter_task_calls(extracted):
            if not call.subagent_name:
                continue
            async for ev in _on_task_call(call, tasks_by_id, pending):
                yield ev

        # Close: ToolMessages whose tool_call_id matches an open task.
        for msg in extracted:
            if not isinstance(msg, ToolMessage):
                continue
            tc_id = getattr(msg, "tool_call_id", None)
            if not isinstance(tc_id, str) or not tc_id:
                continue
            task = tasks_by_id.pop(tc_id, None)
            if task is None:
                continue
            summary = _normalize_content(getattr(msg, "content", None) or "")
            yield _end_event(task, summary=summary)

    async def _process_command_update(
        self,
        cmd: Command,
        tasks_by_id: dict[str, _SubagentTask],
        all_messages: list[Any],
    ) -> AsyncIterator[StreamEvent]:
        """Defensive fallback — handle a raw ``Command(update=...)`` if a future
        LangGraph version ever leaks one onto the updates stream. In practice
        the pregel runtime unwraps Commands inside the tools node, so closes
        arrive via ``_process_add_messages_update`` instead.
        """
        cmd_update = cmd.update
        if not isinstance(cmd_update, dict) or "messages" not in cmd_update:
            return
        extracted = _unwrap_overwrite(cmd_update["messages"])
        all_messages.extend(extracted)
        for msg in extracted:
            tc_id = getattr(msg, "tool_call_id", None)
            if not isinstance(tc_id, str) or not tc_id:
                continue
            task = tasks_by_id.pop(tc_id, None)
            if task is None:
                continue
            summary = _normalize_content(getattr(msg, "content", None) or "")
            yield _end_event(task, summary=summary)

    async def stream(
        self, ctx: RequestContext, input: AgentInput
    ) -> AsyncIterator[StreamEvent]:
        """Stream agent execution with token-level events.

        Handles both fresh executions and resume flows based on the context:
        - ctx.resume: Boolean indicating resume vs fresh execution
        - ctx.resume_data: Data for Command(resume=...)
        - ctx.metadata["checkpoint_id"]: Checkpoint to resume from

        Yields StreamEvent objects with event:
        - "token": Streaming LLM token (data["content"], data["source"],
              data["tool_call_id"])
        - "subagent_start": Subagent dispatch begins (data["source"],
              data["subagent_name"], data["tool_call_id"], data["description"])
        - "subagent_end": Subagent dispatch completes (data["source"],
              data["subagent_name"], data["tool_call_id"], data["summary"]
              with the subagent's final response text; empty string for
              defensive drain ends)
        - "result": Final completion (data with response + messages)
        - "suspend": HITL interrupt (data with suspend_payload + opaque metadata)

        Args:
            ctx: Request-scoped context
            input: Framework-neutral agent input

        Yields:
            StreamEvent instances
        """
        graph_input = self._build_graph_input(ctx, input)
        config = self._build_config(ctx)
        is_resume = ctx.resume

        # Get thread_id for checkpoint lookup (session_id is the continuity id)
        thread_id = ctx.session_id or "default"

        all_messages: list[Any] = []
        # Accumulated across all updates payloads — a subagent (subgraph)
        # interrupt that arrives mid-stream must not be overwritten by a later
        # root-namespace updates payload.
        captured_interrupts: list[Interrupt] = []

        # Subagent boundary tracking. Real entries (after a ``task`` tool_call
        # is seen) live in ``tasks_by_id``; synthetic placeholders inserted on
        # a sourced token before any tool_call arrives live in ``pending`` and
        # promote to ``tasks_by_id`` once the real tool_call is observed.
        tasks_by_id: dict[str, _SubagentTask] = {}
        pending: dict[str, _SubagentTask] = {}

        # ``subgraphs=True`` is required for LangGraph to emit messages-mode
        # chunks from subagent (nested) graphs; otherwise the messages handler
        # filters them out and sourced tokens are silently dropped.
        graph_stream = self._graph.astream(
            graph_input,
            config,
            stream_mode=["messages", "updates"],
            subgraphs=True,
        )
        stream_iter = graph_stream.__aiter__()
        terminal_candidate_pending = False
        terminal_candidate_consumed = False
        try:
            try:
                while True:
                    try:
                        next_item = stream_iter.__anext__()
                        if terminal_candidate_pending:
                            try:
                                (
                                    namespace,
                                    stream_mode,
                                    payload,
                                ) = await asyncio.wait_for(
                                    next_item,
                                    timeout=_TERMINAL_AGENT_UPDATE_DRAIN_TIMEOUT_S,
                                )
                            except asyncio.TimeoutError:
                                _logger.debug(
                                    "Timed out waiting for LangGraph event after "
                                    "terminal agent update; finishing stream"
                                )
                                break
                        else:
                            namespace, stream_mode, payload = await next_item
                    except StopAsyncIteration:
                        break

                    terminal_candidate_pending = False
                    normalized_namespace = (
                        namespace if isinstance(namespace, tuple) else ()
                    )

                    if stream_mode == "messages":
                        chunk, _ = payload
                        source = _source_from_namespace(normalized_namespace)
                        async for event in self._process_messages_chunk(
                            chunk, source, tasks_by_id, pending
                        ):
                            yield event
                    elif stream_mode == "updates":
                        if not isinstance(payload, dict):
                            _logger.warning(
                                "Unexpected non-dict updates payload: %s",
                                type(payload).__name__,
                            )
                            continue
                        interrupts = payload.get("__interrupt__")
                        # LangGraph emits this as a tuple in production; older
                        # docs/examples imply a list. Accept both.
                        if isinstance(interrupts, (list, tuple)):
                            captured_interrupts.extend(interrupts)
                        for node_output in payload.values():
                            if (
                                isinstance(node_output, dict)
                                and "messages" in node_output
                            ):
                                async for event in self._process_add_messages_update(
                                    node_output["messages"],
                                    tasks_by_id,
                                    pending,
                                    all_messages,
                                ):
                                    yield event
                            elif isinstance(node_output, Command):
                                async for event in self._process_command_update(
                                    node_output, tasks_by_id, all_messages
                                ):
                                    yield event
                        if (
                            not terminal_candidate_consumed
                            and _is_terminal_agent_update(
                                normalized_namespace,
                                payload,
                                all_messages,
                                captured_interrupts,
                                has_open_subagents=bool(tasks_by_id or pending),
                            )
                        ):
                            terminal_candidate_pending = True
                            terminal_candidate_consumed = True
            finally:
                await _aclose_stream_iter(stream_iter)

        except (GeneratorExit, asyncio.CancelledError):
            # Yielding during GeneratorExit propagation raises RuntimeError
            # and masks the cancellation; the surrounding task is being torn
            # down on CancelledError so awaiting the consumer there either
            # re-raises or is masked by an injected GeneratorExit. Re-raise
            # without yielding. CancelledError extends BaseException so it
            # must be caught before ``except Exception``.
            raise
        except Exception:
            # Ordinary stream error. Consumer is still attached, so emit
            # defensive ``subagent_end`` for open tasks (otherwise UI pills
            # hang). Catches ``Exception`` not ``BaseException`` so SystemExit
            # / KeyboardInterrupt propagate without yielding.
            async for event in _drain_open_tasks(tasks_by_id, pending):
                yield event
            raise
        else:
            # Skip drain on HITL suspend — the suspend event is the session
            # boundary. Emitting subagent_end here would be premature because
            # the graph is merely paused, not finished. On resume, the
            # continuation stream handles close events normally.
            if not captured_interrupts:
                async for event in _drain_open_tasks(tasks_by_id, pending):
                    yield event

        # Check for interrupt (HITL suspend) — captured across all updates so
        # subagent-emitted interrupts survive subsequent root-namespace updates.
        if captured_interrupts:
            # AER expects a flat dict that validates as SuspendPayload
            # (suspend_reason, suspend_context); use the first interrupt's value.
            interrupt_payload: dict[str, Any] = captured_interrupts[0].value
            checkpoint_id = await self._get_checkpoint_id(thread_id)

            # All LangGraph-specific resume state goes in the opaque
            # ``metadata`` dict. The AER forwards it to the OE unchanged and
            # hands it back via ``ctx.metadata`` on resume, where _build_config
            # reads checkpoint_id to restore the graph at the right checkpoint.
            yield StreamEvent(
                data={
                    "suspend_payload": interrupt_payload,
                    "resumed": is_resume,
                    "metadata": {
                        "checkpoint_id": checkpoint_id,
                        "interrupt_count": len(captured_interrupts),
                    },
                },
                event="suspend",
            )
            return

        # Check for empty messages
        if not all_messages:
            raise RuntimeError("Graph completed without producing messages")

        # Normal completion
        response = _find_last_ai_content(all_messages)
        platform_messages: list[Message] = lc_messages_to_platform(all_messages)

        yield StreamEvent(
            data={
                "response": response,
                "messages": [m.model_dump() for m in platform_messages],
                "message_count": len(all_messages),
                "resumed": is_resume,
            },
            event="result",
        )
