"""Deep agent factory for Magenta AER integration.

:func:`create_magenta_deep_agent` wraps deepagents' ``create_deep_agent``
with two pre-validation passes:

* :class:`~magenta_sdklanggraph.skills.SkillManifest` filters malformed
  ``SKILL.md`` files (WARN-and-skip semantics).
* :func:`~magenta_sdklanggraph.subagents.validate_subagent_tree` rejects
  subagent specs with string models (which would bypass OE routing
  because the upstream factory instantiates a raw LLM without
  ``SecureWrappedLLM``).

Each validator lives in its own module so tests can drive it directly
against real fixtures instead of monkeypatching ``create_deep_agent``.
"""

from __future__ import annotations

import logging
import os
from collections.abc import Callable, Sequence
from typing import Any, cast

from deepagents import (
    AsyncSubAgent,
    CompiledSubAgent,
    SubAgent,
    create_deep_agent,
)
from deepagents.backends.protocol import BackendProtocol
from langchain.agents.middleware.types import AgentMiddleware
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.tools.base import BaseTool
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.graph.state import CompiledStateGraph
from langgraph.store.base import BaseStore

from magenta_sdklanggraph.skills import SkillManifest
from magenta_sdklanggraph.subagents import validate_subagent_tree

logger = logging.getLogger(__name__)

SkillsBaseDir = str | os.PathLike[str]
SubAgentSpec = SubAgent | CompiledSubAgent | AsyncSubAgent


def _load_skill_paths(
    paths: Sequence[str],
    *,
    base_dir: SkillsBaseDir | None,
) -> list[str]:
    manifest = SkillManifest.load(paths, base_dir=base_dir)
    manifest.log_warnings(logger)
    return list(manifest.paths)


def _load_subagent_skill_paths(
    subagents: Sequence[SubAgentSpec],
    *,
    base_dir: SkillsBaseDir | None,
) -> list[SubAgentSpec]:
    resolved: list[SubAgentSpec] = []
    for spec in subagents:
        if "runnable" in spec or "graph_id" in spec or "skills" not in spec:
            resolved.append(spec)
            continue

        updated = dict(spec)
        updated["skills"] = _load_skill_paths(
            cast(Sequence[str], spec["skills"]),
            base_dir=base_dir,
        )
        resolved.append(cast(SubAgentSpec, updated))

    return resolved


def create_magenta_deep_agent(
    secure_llm: BaseChatModel,
    backend: BackendProtocol,
    *,
    tools: Sequence[BaseTool | Callable | dict[str, Any]] | None = None,
    subagents: Sequence[SubAgent | CompiledSubAgent | AsyncSubAgent] | None = None,
    system_prompt: str | None = None,
    middleware: Sequence[AgentMiddleware] = (),
    checkpointer: None | bool | BaseCheckpointSaver = None,
    store: BaseStore | None = None,
    skills: list[str] | None = None,
    skills_base_dir: SkillsBaseDir | None = None,
) -> CompiledStateGraph:
    """Create a deep agent graph pre-configured for Magenta AER.

    Validates the subagent tree, loads + filters the skill manifest,
    then delegates to ``deepagents.create_deep_agent``.

    Args:
        secure_llm: ``SecureWrappedLLM`` instance — every LLM call is
            audited by the OE.
        backend: Backend for filesystem/shell ops; resolved by
            ``App.deep_agent()`` before calling this function.
        tools: Additional tools for the deep agent.
        subagents: SubAgent specs. Plain ``SubAgent`` entries with a
            ``model`` field must use a ``BaseChatModel`` instance, not a
            string — string models bypass OE routing.
        system_prompt: Custom system instructions.
        middleware: Additional middleware.
        checkpointer: LangGraph checkpointer for state persistence,
            HITL suspend/resume, and multi-turn conversations.
        store: LangGraph store for skills and shared data.
        skills: Filesystem paths (as ``str``) to directories or files
            containing ``SKILL.md`` files. Each is run through
            :class:`SkillManifest`; malformed entries are filtered out
            with a WARNING log. When ``skills_base_dir`` is set, entries
            must be relative to that base. ``Path`` objects are NOT
            accepted — deepagents calls ``.rstrip("/")`` on the string,
            which crashes on ``pathlib.Path``. Convert with ``str(path)``
            at the call site.
        skills_base_dir: Base directory for relative skill paths. ``App``
            sets this from the directory containing ``agent.yaml``, optionally
            plus the relative ``AGENTIC_SKILLS_DIR`` override.

    Returns:
        A ``CompiledStateGraph`` ready for ``LangGraphBaseAgent`` wrapping.

    Raises:
        RuntimeError: A subagent spec uses a string model, or nesting
            exceeds the maximum recursion depth.
    """
    validate_subagent_tree(subagents)

    forwarded_skills = (
        _load_skill_paths(skills, base_dir=skills_base_dir)
        if skills is not None
        else None
    )
    forwarded_subagents = (
        _load_subagent_skill_paths(subagents, base_dir=skills_base_dir)
        if subagents is not None
        else None
    )

    return create_deep_agent(
        model=secure_llm,
        backend=backend,
        tools=tools,
        subagents=forwarded_subagents,
        system_prompt=system_prompt,
        middleware=middleware,
        checkpointer=checkpointer,
        store=store,
        skills=forwarded_skills,
    )
