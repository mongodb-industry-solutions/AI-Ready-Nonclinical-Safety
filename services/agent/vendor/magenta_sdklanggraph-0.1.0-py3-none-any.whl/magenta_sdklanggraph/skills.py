"""SKILL.md validation for ``create_magenta_deep_agent``.

Pulls path resolution, frontmatter parsing, and contract checks out of
``deep_agent.py`` so the validation logic can be exercised directly
against real fixture directories — no monkeypatching of the upstream
``deepagents.create_deep_agent`` factory required.

The shape is **load → inspect**:

* :meth:`SkillManifest.load` walks every supplied path, returning a
  :class:`SkillManifest` with both the validated paths (to forward to
  deepagents' ``SkillsMiddleware``) and the structured warnings for
  every skill that got filtered out.
* :meth:`SkillManifest.log_warnings` emits each warning at WARNING
  level on a caller-supplied logger. Logging is a separate concern
  from validation so tests can assert on ``manifest.warnings``
  without ``caplog`` plumbing.
"""

from __future__ import annotations

import logging
import os
from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any

import yaml


@dataclass(frozen=True)
class SkillWarning:
    """One reason a SKILL.md was filtered out of a manifest."""

    path: str
    reason: str


@dataclass(frozen=True)
class SkillManifest:
    """A validated skill list plus the structured warnings collected during load.

    ``paths`` is the tuple ``create_magenta_deep_agent`` forwards to
    deepagents' ``SkillsMiddleware``. ``warnings`` records every skill
    that got filtered out and why.
    """

    paths: tuple[str, ...]
    warnings: tuple[SkillWarning, ...]

    @classmethod
    def empty(cls) -> SkillManifest:
        return cls(paths=(), warnings=())

    @classmethod
    def load(
        cls,
        paths: Iterable[str],
        *,
        base_dir: str | os.PathLike[str] | None = None,
    ) -> SkillManifest:
        """Validate every path; collect the survivors and the rejection reasons."""
        valid: list[str] = []
        warnings: list[SkillWarning] = []
        for path in paths:
            normalized, normalization_error = _normalize_path(path, base_dir)
            if normalization_error is not None:
                warnings.append(
                    SkillWarning(path=normalized, reason=normalization_error)
                )
                continue
            reason = _validate(normalized)
            if reason is None:
                valid.append(normalized)
            else:
                warnings.append(SkillWarning(path=normalized, reason=reason))
        return cls(paths=tuple(valid), warnings=tuple(warnings))

    def log_warnings(self, target: logging.Logger) -> None:
        """Emit each warning on *target* at WARNING level."""
        for w in self.warnings:
            target.warning("Skill %s: %s — skipping", w.path, w.reason)


# ---------------------------------------------------------------------------
# Internal helpers — return the failure reason, or None if valid
# ---------------------------------------------------------------------------


def _normalize_path(
    skill_path: str,
    base_dir: str | os.PathLike[str] | None,
) -> tuple[str, str | None]:
    if base_dir is None:
        return skill_path, None

    real_base = os.path.realpath(os.path.abspath(os.fspath(base_dir)))
    if os.path.isabs(skill_path):
        normalized = os.path.realpath(os.path.abspath(skill_path))
        return (
            normalized,
            "absolute skill paths are not supported; "
            f"use a path relative to {real_base}",
        )

    normalized = os.path.realpath(os.path.abspath(os.path.join(real_base, skill_path)))
    if os.path.commonpath([real_base, normalized]) != real_base:
        return normalized, f"path escapes base directory {real_base}"
    return normalized, None


def _validate(skill_path: str) -> str | None:
    """Return the failure reason for a malformed skill, or ``None`` if valid.

    A malformed skill produces a WARNING and is filtered out rather than
    crashing agent startup.
    """
    skill_dir, skill_md = _resolve_paths(skill_path)

    if not os.path.isfile(skill_md):
        return f"SKILL.md not found at {skill_md}"

    parsed = _read_frontmatter(skill_md)
    if isinstance(parsed, str):
        # Reason text — the read or parse failed.
        return parsed
    frontmatter = parsed

    name_value = frontmatter.get("name")
    if name_value is None:
        return "missing name field"

    dirname = os.path.basename(skill_dir)
    if str(name_value) != dirname:
        return f"name does not match directory (name='{name_value}', dir='{dirname}')"

    description = frontmatter.get("description")
    if description is None or not str(description).strip():
        return "missing or empty description field"

    return None


def _resolve_paths(skill_path: str) -> tuple[str, str]:
    """Return ``(skill_dir, skill_md)`` for *skill_path*.

    Accepts either a directory (containing ``SKILL.md``) or a direct
    path to ``SKILL.md`` itself.
    """
    if os.path.isdir(skill_path):
        skill_dir = skill_path.rstrip("/")
        return skill_dir, os.path.join(skill_dir, "SKILL.md")
    return os.path.dirname(skill_path).rstrip("/"), skill_path


def _read_frontmatter(skill_md: str) -> dict[str, Any] | str:
    """Parse the YAML frontmatter at the head of *skill_md*.

    Returns the parsed mapping on success, or a failure reason string
    when the file cannot be read, decoded, fenced, or YAML-parsed.
    """
    try:
        with open(skill_md, encoding="utf-8") as f:
            text = f.read()
    except OSError as exc:
        return f"failed to read SKILL.md ({exc})"
    except UnicodeDecodeError as exc:
        # A non-UTF-8 SKILL.md (e.g. Latin-1 accented characters, BOM in
        # the wrong place) used to crash agent startup here. WARN-and-skip
        # semantics demand we surface a reason instead.
        return f"SKILL.md is not valid UTF-8 ({exc})"

    if not (text.startswith("---\n") or text.startswith("---\r")):
        return "frontmatter not at byte 0"

    remainder = text.split("\n", 1)[1] if "\n" in text else ""
    end_idx = remainder.find("\n---")
    if end_idx == -1:
        return "unterminated frontmatter"

    try:
        frontmatter = yaml.safe_load(remainder[:end_idx]) or {}
    except yaml.YAMLError as exc:
        return f"invalid YAML frontmatter ({exc})"

    if not isinstance(frontmatter, dict):
        return "frontmatter is not a mapping"
    return frontmatter
