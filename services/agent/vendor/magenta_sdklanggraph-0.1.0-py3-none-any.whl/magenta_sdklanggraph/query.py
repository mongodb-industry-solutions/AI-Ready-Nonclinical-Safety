"""LangGraph-backed implementation of :class:`AERQueryPlugin`.

Reads from the same MongoDB collections that LangGraph's ``MongoDBSaver``
writes to (``checkpoints``, ``checkpoint_writes``). Deserialization is
delegated to the saver's ``serde`` so this code does not need to know how
LangGraph encodes state on disk.

The plugin is workspace-agnostic: per-session reads filter by
``thread_id = session_id`` only. Workspace isolation is enforced by the
OE proxy, which scopes session_ids via the ``executions`` collection
before calling here. See ``runner_shared.server.query`` for the full
trust-model discussion.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, cast

from langchain_core.runnables import RunnableConfig
from langgraph.checkpoint.mongodb import MongoDBSaver
from magenta_sdk_core.models import (
    SessionMessage,
    SessionMessagesResponse,
    SessionsSummaryResponse,
    SessionSummary,
)
from pydantic import JsonValue, TypeAdapter, ValidationError

logger = logging.getLogger(__name__)
_JSON_VALUE_ADAPTER = TypeAdapter(JsonValue)

_PREVIEW_MAX_CHARS = 80
_PREVIEW_WRITES_PER_SESSION = 5

# Cap on the bytes logged from a deserialization exception. langgraph's
# serde errors can carry chunks of the raw on-disk payload (and therefore
# user content) — truncate so a Splunk-visible warning never doubles as a
# data-leak vector.
_DESERIALIZATION_ERROR_MAX_CHARS = 200

# Cap the per-session checkpoint scan in ``get_messages_for_session``. LangGraph
# writes one checkpoint per graph step, so an unbounded scan is O(turns) in
# both DB I/O and deserialization cost. Mirrors the OE's historical cap on
# the equivalent Go read path. Sessions with more than this many checkpoints
# return the messages present in the most recent ``_MAX_CHECKPOINTS_PER_SESSION``
# checkpoints; older turns are not surfaced. Raise this if real sessions
# routinely exceed it.
_MAX_CHECKPOINTS_PER_SESSION = 500

# Server-side and client-side time budgets on the read paths. Without
# these, a slow / hung MongoDB pins the executor thread serving the
# request indefinitely; with them, the request fails fast and the thread
# is returned to the pool. The two numbers exist in a sandwich: maxTimeMS
# is enforced inside the database, the asyncio timeout is enforced in the
# AER's event loop. The asyncio bound is set higher to allow maxTimeMS
# to surface its own error first when both fire.
_AGGREGATION_TIMEOUT_MS = 15_000
_MESSAGE_READ_TIMEOUT_SECONDS = 20.0

# LangChain BaseMessage.type → framework-neutral role used on the wire.
# Mirrors the role surface the OE has exposed historically; "function" is an
# older LangChain message type that we collapse onto "tool" so callers do not
# need to distinguish.
_ROLE_MAP = {
    "human": "human",
    "ai": "assistant",
    "system": "system",
    "tool": "tool",
    "function": "tool",
}


class LangGraphQueryPlugin:
    """AERQueryPlugin backed by LangGraph's MongoDBSaver."""

    def __init__(self, checkpointer: MongoDBSaver) -> None:
        self._checkpointer = checkpointer
        self._checkpoints_collection = checkpointer.checkpoint_collection
        self._writes_collection = checkpointer.writes_collection
        self._serde = checkpointer.serde

    async def get_summaries_for_sessions(
        self, session_ids: list[str]
    ) -> SessionsSummaryResponse:
        if not session_ids:
            return SessionsSummaryResponse(sessions=[])
        loop = asyncio.get_running_loop()
        sessions = await loop.run_in_executor(
            None, self._aggregate_session_summaries, list(session_ids)
        )
        return SessionsSummaryResponse(sessions=sessions)

    async def get_messages_for_session(
        self, session_id: str
    ) -> SessionMessagesResponse:
        # Walk checkpoints via MongoDBSaver.alist() — deserialization, cursor
        # lifecycle, and timestamp surfacing (``checkpoint["ts"]``) are all
        # owned by LangGraph. A corrupt checkpoint here propagates as a 500
        # rather than being silently skipped: that's the right call for
        # state-store corruption.
        thread_config: RunnableConfig = {"configurable": {"thread_id": session_id}}
        checkpoints_newest_first = await asyncio.wait_for(
            self._collect_checkpoints(thread_config),
            timeout=_MESSAGE_READ_TIMEOUT_SECONDS,
        )

        # Keep only checkpoints whose ``messages`` channel is a usable list;
        # everything else is skipped. The most recent such checkpoint is the
        # authoritative message list.
        checkpoints_with_messages_newest_first = [
            (checkpoint_tuple, messages)
            for checkpoint_tuple in checkpoints_newest_first
            if (messages := _extract_messages(checkpoint_tuple)) is not None
        ]

        if not checkpoints_with_messages_newest_first:
            return SessionMessagesResponse(messages=[])

        _, authoritative_messages = checkpoints_with_messages_newest_first[0]
        first_appearance_by_index = _attribute_first_appearance_timestamps(
            checkpoints_with_messages_newest_first
        )

        return SessionMessagesResponse(
            messages=[
                _to_session_message(
                    message=message,
                    session_id=session_id,
                    message_index=message_index,
                    timestamp=first_appearance_by_index.get(message_index, ""),
                )
                for message_index, message in enumerate(authoritative_messages)
            ]
        )

    async def _collect_checkpoints(self, thread_config: RunnableConfig) -> list[Any]:
        """Materialize a bounded checkpoint window for one thread.

        Pulled into its own coroutine so the caller can wrap it in
        ``asyncio.wait_for``; without that bound, a hung MongoDB would
        keep an executor thread parked indefinitely.
        """
        return [
            checkpoint_tuple
            async for checkpoint_tuple in self._checkpointer.alist(
                thread_config, limit=_MAX_CHECKPOINTS_PER_SESSION
            )
        ]

    # ------------------------------------------------------------------
    # Session summaries
    # ------------------------------------------------------------------

    def _aggregate_session_summaries(
        self, session_ids: list[str]
    ) -> list[SessionSummary]:
        aggregate_doc_by_session_id = {
            session_id: aggregate_doc
            for aggregate_doc in self._checkpoints_collection.aggregate(
                _session_summaries_pipeline(session_ids),
                maxTimeMS=_AGGREGATION_TIMEOUT_MS,
            )
            if (session_id := str(aggregate_doc.get("_id", "")))
        }

        preview_by_session_id = self._collect_previews(
            list(aggregate_doc_by_session_id.keys())
        )

        return [
            SessionSummary(
                session_id=session_id,
                last_activity=_iso_or_empty(aggregate_doc.get("latest_ts")),
                created_at=_iso_or_empty(aggregate_doc.get("first_ts")),
                message_count=int(aggregate_doc.get("checkpoint_count") or 0),
                first_message_preview=preview_by_session_id.get(session_id, ""),
            )
            for session_id, aggregate_doc in aggregate_doc_by_session_id.items()
        ]

    def _collect_previews(self, session_ids: list[str]) -> dict[str, str]:
        if not session_ids:
            return {}

        preview_candidates_by_session_id = (
            (
                str(aggregate_doc.get("_id", "")),
                aggregate_doc.get("writes") or [],
            )
            for aggregate_doc in self._writes_collection.aggregate(
                _message_previews_pipeline(session_ids),
                maxTimeMS=_AGGREGATION_TIMEOUT_MS,
            )
        )

        return {
            session_id: preview
            for session_id, candidate_writes in preview_candidates_by_session_id
            if session_id
            and (
                preview := self._first_non_empty_human_preview(
                    candidate_writes, session_id
                )
            )
        }

    def _first_non_empty_human_preview(
        self, candidate_writes: list[dict[str, Any]], session_id: str
    ) -> str:
        """Return the first non-empty human-message preview across ``writes``.

        ``writes`` is the per-session $push result from the preview pipeline,
        ordered oldest-first. Returns ``""`` if no write decodes to a human
        message with text content.
        """
        candidate_previews = (
            self._decode_human_preview(write_record, session_id)
            for write_record in candidate_writes
        )
        return next(
            (preview for preview in candidate_previews if preview),
            "",
        )

    def _decode_human_preview(
        self, write_record: dict[str, Any], session_id: str
    ) -> str:
        """Decode a single ``checkpoint_writes`` document and return the
        first human-authored text content it contains, truncated.

        Returns ``""`` for non-human writes, malformed writes, and any
        deserialization failures (logged at WARNING for observability).
        """
        serde_type_tag = write_record.get("type")
        serialized_value = write_record.get("value")
        if not serde_type_tag or serialized_value is None:
            return ""

        try:
            deserialized = self._serde.loads_typed((serde_type_tag, serialized_value))
        except Exception as exc:  # noqa: BLE001 — corrupt single write shouldn't fail the list
            # Surface at warning level so schema drift / data corruption is
            # observable in Splunk — a debug-level swallow would silently
            # serve empty previews to every caller. Bound the message
            # length so deserialization errors that echo raw payload bytes
            # (or user content) don't bloat logs or leak data.
            logger.warning(
                "preview deserialization failed for session %s: %s: %s",
                session_id,
                type(exc).__name__,
                str(exc)[:_DESERIALIZATION_ERROR_MAX_CHARS],
            )
            return ""

        decoded_messages = (
            deserialized if isinstance(deserialized, list) else [deserialized]
        )
        human_contents = (
            _human_content(decoded_message) for decoded_message in decoded_messages
        )
        return next(
            (content[:_PREVIEW_MAX_CHARS] for content in human_contents if content),
            "",
        )


# ----------------------------------------------------------------------
# Module-level helpers — kept stateless and pure so they're easy to read
# and easy to test in isolation.
# ----------------------------------------------------------------------


def _session_summaries_pipeline(session_ids: list[str]) -> list[dict[str, Any]]:
    """Aggregation pipeline that reduces per-session checkpoint rows to
    one summary row per session (first/last activity, checkpoint count)."""
    return [
        {"$match": {"thread_id": {"$in": session_ids}}},
        {"$addFields": {"_ts": {"$toDate": "$_id"}}},
        {
            "$group": {
                "_id": "$thread_id",
                "latest_ts": {"$max": "$_ts"},
                "first_ts": {"$min": "$_ts"},
                "checkpoint_count": {"$sum": 1},
            }
        },
        {"$sort": {"latest_ts": -1}},
    ]


def _message_previews_pipeline(session_ids: list[str]) -> list[dict[str, Any]]:
    """Aggregation pipeline that pulls the oldest few ``messages``-channel
    writes per session so we can extract a human-message preview.

    ``$firstN`` caps the per-session write count at the accumulator — the
    full sorted stream is never materialized in memory. The preceding
    ``$sort: {_id: 1}`` makes "first N" mean "oldest N".
    """
    return [
        {
            "$match": {
                "thread_id": {"$in": session_ids},
                "channel": "messages",
            }
        },
        {"$sort": {"_id": 1}},
        {
            "$group": {
                "_id": "$thread_id",
                "writes": {
                    "$firstN": {
                        "input": {"type": "$type", "value": "$value"},
                        "n": _PREVIEW_WRITES_PER_SESSION,
                    }
                },
            }
        },
    ]


def _extract_messages(checkpoint_tuple: Any) -> list[Any] | None:
    """Return the ``messages`` channel from a ``CheckpointTuple`` if it's
    a list, otherwise ``None``.

    A ``None`` return signals "skip this checkpoint" — the channel is
    either absent, malformed, or the checkpoint itself isn't a dict.
    """
    checkpoint = getattr(checkpoint_tuple, "checkpoint", None)
    if not isinstance(checkpoint, dict):
        return None
    channel_values = checkpoint.get("channel_values", {})
    if not isinstance(channel_values, dict):
        return None
    messages = channel_values.get("messages")
    return messages if isinstance(messages, list) else None


def _checkpoint_timestamp(checkpoint_tuple: Any) -> str:
    """Read ``checkpoint["ts"]`` — LangGraph's own ISO-8601 timestamp
    field — falling back to the empty string if it's missing."""
    checkpoint = getattr(checkpoint_tuple, "checkpoint", None)
    if not isinstance(checkpoint, dict):
        return ""
    return str(checkpoint.get("ts") or "")


def _attribute_first_appearance_timestamps(
    checkpoints_with_messages_newest_first: list[tuple[Any, list[Any]]],
) -> dict[int, str]:
    """For each message index in the conversation history, return the
    timestamp of the *earliest* checkpoint where that index existed.

    The caller passes pairs in newest-first order (the natural ``alist()``
    direction); this function walks them oldest-first so that
    ``setdefault`` records each index's first appearance.
    """
    first_appearance_by_index: dict[int, str] = {}
    for checkpoint_tuple, messages_at_this_step in reversed(
        checkpoints_with_messages_newest_first
    ):
        timestamp = _checkpoint_timestamp(checkpoint_tuple)
        for message_index in range(len(messages_at_this_step)):
            first_appearance_by_index.setdefault(message_index, timestamp)
    return first_appearance_by_index


def _to_session_message(
    *,
    message: Any,
    session_id: str,
    message_index: int,
    timestamp: str,
) -> SessionMessage:
    raw_message_type = getattr(message, "type", "") or ""
    role = _ROLE_MAP.get(raw_message_type, raw_message_type)
    name = getattr(message, "name", "") or ""
    message_id = getattr(message, "id", "") or f"msg-{session_id}-{message_index}"
    additional_kwargs = getattr(message, "additional_kwargs", None)
    return SessionMessage(
        id=message_id,
        role=role,
        content=_message_text(message),
        timestamp=timestamp,
        session_id=session_id,
        name=name,
        additional_kwargs=_json_safe_metadata(additional_kwargs),
    )


def _json_safe_metadata(value: Any) -> dict[str, JsonValue] | None:
    if not isinstance(value, dict):
        return None

    metadata: dict[str, JsonValue] = {}
    for key, raw_field in value.items():
        if not isinstance(key, str):
            continue
        try:
            metadata[key] = cast(
                JsonValue,
                _JSON_VALUE_ADAPTER.validate_python(raw_field),
            )
        except ValidationError:
            logger.warning("Skipping non-JSON message metadata field: %s", key)

    return metadata or None


def _message_text(message: Any) -> str:
    """Return a flat-string view of a LangChain message's content.

    Uses ``BaseMessage.text`` when available — it collapses str/list
    content to a string and extracts only ``type: "text"`` blocks.
    Falls back to ``str(content)`` for stand-ins that don't implement
    the LangChain message protocol (e.g. test doubles).
    """
    text_accessor = getattr(message, "text", None)
    if text_accessor is None:
        return str(getattr(message, "content", "") or "")
    return str(text_accessor)


def _human_content(decoded_message: Any) -> str:
    if getattr(decoded_message, "type", None) != "human":
        return ""
    return _message_text(decoded_message)


def _iso_or_empty(value: Any) -> str:
    if value is None:
        return ""
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return ""
