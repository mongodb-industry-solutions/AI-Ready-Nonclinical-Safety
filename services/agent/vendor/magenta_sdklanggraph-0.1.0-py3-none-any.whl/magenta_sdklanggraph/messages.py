"""LangChain message conversion layer.

Converts between LangChain message types (AIMessage, HumanMessage, etc.)
and the framework-neutral Message model from magenta-sdk-core.
"""

from __future__ import annotations

import json
import logging
from typing import Any, cast

from langchain_core.messages import (
    AIMessage,
    AIMessageChunk,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.messages.tool import ToolCall
from langchain_core.messages.tool import ToolCallChunk as LCToolCallChunk
from langchain_core.outputs import ChatGeneration, ChatGenerationChunk, ChatResult
from magenta_sdk_core import (
    AnyContentBlock,
    DocumentBlock,
    ImageBlock,
    LLMToolCall,
    Message,
    Role,
    TextBlock,
)
from magenta_sdk_core.models import LLMResponse, LLMStreamChunk, LLMTokenUsage
from pydantic import JsonValue

__all__ = [
    "lc_to_platform_message",
    "platform_to_lc_message",
    "lc_messages_to_platform",
    "platform_messages_to_lc",
    "llm_response_to_chat_result",
    "llm_stream_chunk_to_generation_chunk",
    "message_to_dict",
    "dict_to_ai_message",
    "dict_to_ai_message_chunk",
]

_logger = logging.getLogger(__name__)


def _convert_lc_content_to_platform(
    content: Any,
) -> str | list[AnyContentBlock]:
    """Convert LangChain message content to platform format.

    LangChain messages can have multimodal content as a list of content blocks.
    This function preserves the structure for multimodal content while keeping
    simple string content as-is.

    Args:
        content: LangChain message content (str or list of content blocks)

    Returns:
        String for simple text, or list of ContentBlocks for multimodal content
    """
    if isinstance(content, str):
        return content
    if not isinstance(content, list):
        return str(content)

    # Multimodal content - preserve structure
    blocks: list[AnyContentBlock] = []
    for block in content:
        if isinstance(block, dict):
            block_type = block.get("type", "text")
            if block_type == "text":
                blocks.append(TextBlock(text=block.get("text", "")))
            elif block_type in ("image", "image_url"):
                # Handle LangChain's image_url format (supports both string and dict)
                if "image_url" in block:
                    image_data = block["image_url"]
                    if isinstance(image_data, dict):
                        url = image_data.get("url")
                    else:
                        url = image_data
                else:
                    url = block.get("url")
                if url:
                    blocks.append(ImageBlock(url=url, mime_type=block.get("mime_type")))
                else:
                    _logger.warning("Image block missing url; skipping")
                    continue
            elif block_type in ("file", "document"):
                url = block.get("url")
                if url:
                    blocks.append(
                        DocumentBlock(
                            url=url,
                            mime_type=block.get("mime_type"),
                            filename=block.get("filename"),
                        )
                    )
                else:
                    _logger.warning("Document block missing url; skipping")
                    continue
            else:
                # Unknown type - log warning and serialize to text
                _logger.warning(
                    "Unknown content block type=%s; serializing to TextBlock",
                    block_type,
                )
                blocks.append(TextBlock(text=json.dumps(block)))
        else:
            blocks.append(TextBlock(text=str(block)))

    # Optimization: single text block → string
    if len(blocks) == 1 and isinstance(blocks[0], TextBlock):
        return blocks[0].text

    return blocks if blocks else ""


def _serialize_tool_calls(tool_calls: list[ToolCall]) -> list[LLMToolCall]:
    """Serialize LangChain tool calls to dicts.

    LangChain's ToolCall is a TypedDict — at runtime, tool_calls on an
    AIMessage are always plain dicts with ``name``, ``args``, ``id``, and
    ``type`` keys (enforced by LangChain's model validator).

    Args:
        tool_calls: LangChain ToolCall dicts

    Returns:
        List of typed tool calls
    """
    required_keys = {"name", "args", "id"}
    result: list[LLMToolCall] = []
    for tc in tool_calls:
        if not isinstance(tc, dict):
            raise TypeError(f"Expected dict tool call, got {type(tc).__name__}")
        missing = required_keys - tc.keys()
        if missing:
            _logger.warning("Tool call missing keys %s: %s", missing, tc)
        result.append(LLMToolCall.model_validate(tc))
    return result


def lc_to_platform_message(lc_message: BaseMessage) -> Message:
    """Convert a LangChain message to platform Message.

    Args:
        lc_message: LangChain BaseMessage instance

    Returns:
        Platform Message instance
    """
    # Get the message type from LangChain's type field
    msg_type = getattr(lc_message, "type", "human")
    _ROLE_MAP: dict[str, Role] = {
        "human": "user",
        "ai": "assistant",
        "system": "system",
        "tool": "tool",
    }
    role: Role = _ROLE_MAP.get(msg_type, "user")

    # Extract content (preserves multimodal structure)
    content = _convert_lc_content_to_platform(lc_message.content)

    # Handle tool calls (for AIMessage)
    tool_calls: list[LLMToolCall] | None = None
    if isinstance(lc_message, AIMessage) and lc_message.tool_calls:
        tool_calls = _serialize_tool_calls(lc_message.tool_calls)

    # Handle tool_call_id (for ToolMessage)
    tool_call_id: str | None = None
    if isinstance(lc_message, ToolMessage):
        tool_call_id = lc_message.tool_call_id

    # Preserve name (available on all BaseMessage types)
    name: str | None = lc_message.name
    additional_kwargs = (
        cast(dict[str, JsonValue], lc_message.additional_kwargs)
        if lc_message.additional_kwargs
        else None
    )
    response_metadata = (
        cast(dict[str, JsonValue], lc_message.response_metadata)
        if lc_message.response_metadata
        else None
    )

    return Message(
        role=role,
        content=content,
        tool_calls=tool_calls,
        tool_call_id=tool_call_id,
        name=name,
        id=lc_message.id,
        additional_kwargs=additional_kwargs,
        response_metadata=response_metadata,
    )


def _convert_platform_content_to_lc(
    content: str | list[AnyContentBlock],
) -> str | list[dict[str, Any]]:
    """Convert platform content to LangChain format.

    Args:
        content: Platform message content (str or list of ContentBlocks)

    Returns:
        String for simple text, or list of dicts for multimodal content
    """
    if isinstance(content, str):
        return content

    # Convert ContentBlocks to LangChain dict format
    lc_blocks: list[dict[str, Any]] = []
    for block in content:
        if isinstance(block, TextBlock):
            lc_blocks.append({"type": "text", "text": block.text})
        elif isinstance(block, ImageBlock):
            lc_block: dict[str, Any] = {"type": "image", "url": block.url}
            if block.mime_type:
                lc_block["mime_type"] = block.mime_type
            lc_blocks.append(lc_block)
        elif isinstance(block, DocumentBlock):
            lc_block: dict[str, Any] = {"type": "document", "url": block.url}
            if block.mime_type:
                lc_block["mime_type"] = block.mime_type
            if block.filename:
                lc_block["filename"] = block.filename
            lc_blocks.append(lc_block)

    return lc_blocks if lc_blocks else ""


def platform_to_lc_message(message: Message) -> BaseMessage | None:
    """Convert a platform Message to LangChain message.

    Args:
        message: Platform Message instance

    Returns:
        LangChain BaseMessage instance, or None if the message cannot be converted
        (e.g., tool message with missing tool_call_id)
    """
    role = message.role
    lc_class = {
        "user": HumanMessage,
        "assistant": AIMessage,
        "system": SystemMessage,
        "tool": ToolMessage,
    }.get(role, HumanMessage)

    # Convert content to LangChain format
    lc_content = _convert_platform_content_to_lc(message.content)

    if lc_class == ToolMessage:
        # ToolMessage requires tool_call_id and string content
        if not message.tool_call_id:
            preview = (
                message.content[:50] if isinstance(message.content, str) else "..."
            )
            _logger.warning(
                "Skipping tool message: missing tool_call_id (content=%r)", preview
            )
            return None
        # ToolMessage typically expects string content
        str_content = (
            lc_content if isinstance(lc_content, str) else json.dumps(lc_content)
        )
        return ToolMessage(
            content=str_content,
            tool_call_id=message.tool_call_id,
            name=message.name,
            id=message.id,
            additional_kwargs=message.additional_kwargs or {},
            response_metadata=message.response_metadata or {},
        )
    elif lc_class == AIMessage:
        # AIMessage may have tool_calls
        return AIMessage(
            content=lc_content,  # type: ignore[arg-type]
            tool_calls=[
                tool_call.to_langchain_dict()
                for tool_call in (message.tool_calls or [])
            ],
            name=message.name,
            id=message.id,
            additional_kwargs=message.additional_kwargs or {},
            response_metadata=message.response_metadata or {},
        )
    else:
        # HumanMessage, SystemMessage (content can be str or list of content blocks)
        return lc_class(  # type: ignore[call-arg]
            content=lc_content,
            name=message.name,
            id=message.id,
            additional_kwargs=message.additional_kwargs or {},
            response_metadata=message.response_metadata or {},
        )


def lc_messages_to_platform(messages: list[BaseMessage]) -> list[Message]:
    """Convert a list of LangChain messages to platform Messages.

    Args:
        messages: List of LangChain BaseMessage instances

    Returns:
        List of platform Message instances
    """
    return [lc_to_platform_message(msg) for msg in messages]


def platform_messages_to_lc(messages: list[Message]) -> list[BaseMessage]:
    """Convert a list of platform Messages to LangChain messages.

    Invalid messages (e.g., tool messages with missing tool_call_id) are
    skipped with a warning logged.

    Args:
        messages: List of platform Message instances

    Returns:
        List of LangChain BaseMessage instances (invalid messages filtered out)
    """
    result = []
    for msg in messages:
        lc_msg = platform_to_lc_message(msg)
        if lc_msg is not None:
            result.append(lc_msg)
    return result


# =============================================================================
# OE message serialization (LangChain ↔ dict)
# =============================================================================

FRAMEWORK_LANGCHAIN = "langchain"


def message_to_dict(message: BaseMessage) -> dict[str, Any]:
    """Serialize a LangChain message to the platform wire format.

    Stamps every dict with ``"framework": "langchain"`` so downstream
    consumers can identify which framework produced the message.
    """
    data = message.model_dump(exclude_none=True)
    data["framework"] = FRAMEWORK_LANGCHAIN
    return data


def _check_framework(data: dict[str, Any]) -> None:
    """Raise if the wire-format dict came from an unsupported framework."""
    fw = data.get("framework")
    if fw is not None and fw != FRAMEWORK_LANGCHAIN:
        raise ValueError(
            f"Cannot deserialize message from framework {fw!r} "
            "with the LangChain deserializer"
        )


def dict_to_ai_message(data: Any) -> AIMessage:
    """Deserialize a platform wire-format dict to a LangChain AIMessage."""
    if isinstance(data, AIMessage):
        return data
    if isinstance(data, dict):
        _check_framework(data)
        return AIMessage.model_validate(data)
    return AIMessage(content=str(data))


def dict_to_ai_message_chunk(data: Any) -> AIMessageChunk:
    """Deserialize a platform wire-format dict to a LangChain AIMessageChunk.

    Used for streaming replay where ChatGenerationChunk expects a chunk type.
    """
    if isinstance(data, AIMessageChunk):
        return data
    if isinstance(data, dict):
        _check_framework(data)
        return AIMessageChunk.model_validate({**data, "type": "AIMessageChunk"})
    return AIMessageChunk(content=str(data))


# =============================================================================
# LLM Response conversion (sdk-core ↔ LangChain)
# =============================================================================


def _usage_from_response(response: LLMResponse) -> LLMTokenUsage | None:
    if response.usage is not None:
        return response.usage

    metadata = dict(response.metadata)
    nested_usage = metadata.get("usage")
    if isinstance(nested_usage, dict):
        return LLMTokenUsage.model_validate(nested_usage)

    token_keys = {
        "input_tokens",
        "output_tokens",
        "prompt_tokens",
        "completion_tokens",
        "total_tokens",
        "model",
    }
    if any(key in metadata for key in token_keys):
        return LLMTokenUsage.model_validate(metadata)
    return None


def llm_response_to_chat_result(response: LLMResponse) -> ChatResult:
    """Convert sdk-core LLMResponse to LangChain ChatResult.

    Args:
        response: sdk-core LLMResponse instance

    Returns:
        LangChain ChatResult with AIMessage generation
    """
    response_metadata = dict(response.metadata)
    raw_metadata = response_metadata.pop("_raw_response_metadata", {})
    raw_response_metadata: dict[str, Any] = (
        raw_metadata if isinstance(raw_metadata, dict) else {}
    )
    response_metadata.pop("usage", None)
    explicit_response_metadata = dict(response.response_metadata or {})
    usage = _usage_from_response(response)
    usage_metadata = usage.model_dump(exclude_none=True) if usage is not None else {}
    merged_metadata = {
        **response_metadata,
        **usage_metadata,
        **raw_response_metadata,
        **explicit_response_metadata,
    }
    ai_message = AIMessage(
        content=response.content,
        tool_calls=[
            tool_call.to_langchain_dict() for tool_call in (response.tool_calls or [])
        ],
        id=response.id,
        name=response.name,
        additional_kwargs=response.additional_kwargs or {},
        response_metadata=merged_metadata,
    )
    return ChatResult(generations=[ChatGeneration(message=ai_message)])


def llm_stream_chunk_to_generation_chunk(
    chunk: LLMStreamChunk,
) -> ChatGenerationChunk:
    """Convert sdk-core LLMStreamChunk to LangChain ChatGenerationChunk.

    Args:
        chunk: sdk-core LLMStreamChunk instance

    Returns:
        LangChain ChatGenerationChunk with AIMessageChunk
    """
    tool_call_chunks: list[LCToolCallChunk] = [
        LCToolCallChunk(id=tc.id, name=tc.name, args=tc.args, index=tc.index)
        for tc in (chunk.tool_calls or [])
    ]
    # Normalize usage keys: sdk-core uses prompt_tokens/completion_tokens,
    # but LangChain UsageMetadata requires input_tokens/output_tokens.
    usage_metadata = (
        chunk.usage.to_langchain_usage_metadata() if chunk.usage is not None else None
    )
    ai_chunk = AIMessageChunk(
        content=chunk.content or "",
        tool_call_chunks=tool_call_chunks,
        id=chunk.id,
        name=chunk.name,
        additional_kwargs=chunk.additional_kwargs or {},
        response_metadata=chunk.response_metadata or {},
        usage_metadata=cast(Any, usage_metadata),
    )
    return ChatGenerationChunk(message=ai_chunk)
