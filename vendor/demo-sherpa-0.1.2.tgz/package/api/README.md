# Sherpa API

Lightweight Node API for the editable Sherpa catalog and ingestion workflow.

This lives inside the `demo-sherpa` repo so the catalog stays shared and independent from any host demo such as Leafy Hospital.

## Why This Approach

This repo already ships JavaScript, and the catalog API is intentionally light. A Node API inside `api/` is simpler than keeping a separate Python service and easier to evolve into Next route handlers later if needed.

## Run

```sh
cp api/.env.example api/.env
npm install
npm run api
```

Default API base URL: `http://localhost:9091`

Useful helpers:

```sh
npm run api:bootstrap
npm run api:embed
npm run api:ingest
npm run api:smoke
```

`api:bootstrap` assumes the API server is already running.
`api:embed` talks directly to MongoDB and embeds chunk text with Voyage.
`api:ingest` talks directly to MongoDB and performs the broader portal plus Solutions Library ingestion pass.

## Environment Variables

`api/.env.example` is the source of truth for supported variables. The main ones are:

- `MONGODB_CONNECTION_STRING`: required for the API and direct-ingest scripts
- `SHERPA_ALLOWED_ORIGINS`: comma-separated CORS allowlist for host demos; include the active local dev origin such as `http://localhost:3000` or `http://localhost:3001`
- `AWS_REGION`: Bedrock and AWS AI region, matching the same AWS setup used in Leafy Hospital
- `AWS_PROFILE` or `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY`: credentials for Bedrock, Polly, and Transcribe
- `AWS_BEDROCK_ASSUME_ROLE_ARN` or `AWS_ASSUMED_ROLE`: optional assumed role for shared AWS environments
- `AWS_BUCKET_NAME` or `SHERPA_MEDIA_BUCKET_NAME`: required for Sherpa-hosted transcription because Amazon Transcribe uses S3-backed media jobs
- `BEDROCK_DEFAULT_MODEL`: primary Bedrock model for the streamed Sherpa copilot chat
- `SHERPA_COPILOT_MODEL`: optional Bedrock override for the streamed copilot loop
- `SHERPA_TRANSLATE_MODEL`: optional Bedrock override for narration preparation
- `SHERPA_TTS_ENGINE`: optional Amazon Polly engine override
- `VOYAGE_API_KEY`: required for `api:embed`, semantic search, and vector-powered retrieval
- `SHERPA_API_BASE_URL`: used by helper scripts such as `api:bootstrap` and `api:smoke`

Optional collection and bucket names are also included so another developer can stand the API up without reading the source.

## Endpoints

- `GET /sherpa/catalog/health`
- `GET /sherpa/service/capabilities`
- `POST /sherpa/services/tts`
- `POST /sherpa/services/transcribe`
- `POST /sherpa/services/translate`
- `POST /sherpa/catalog/bootstrap/portal`
- `POST /sherpa/catalog/embed`
- `POST /sherpa/catalog/search/semantic`
- `GET /sherpa/catalog/taxonomies`
- `GET /sherpa/catalog/demos`
- `GET /sherpa/catalog/demos/:slug`
- `PUT /sherpa/catalog/demos/:slug`
- `GET /sherpa/catalog/ingestion/jobs`
- `POST /sherpa/catalog/ingestion/jobs`
- `POST /sherpa/catalog/ingestion/solution-library/preview`
- `POST /sherpa/copilot/brief`
- `POST /sherpa/copilot/chat`

## What It Seeds

The bootstrap endpoint seeds:

- the 51 demos from the IST demo portal inventory
- editable taxonomies
- portal source records
- initial text chunks for future vectorization

Not every seeded demo is assumed to have a recorded journey.

## UI Integration

Sherpa also exports a lightweight client helper from `src/modules/catalogApi.js`:

```js
import { createSherpaCatalogClient } from "demo-sherpa/catalog-api";

const client = createSherpaCatalogClient({
  baseUrl: "http://localhost:9091",
});

const demos = await client.listDemos({ limit: 10 });
```

For semantic retrieval and copilot briefing:

```js
const brief = await client.createCopilotBrief({
  industry: "Healthcare",
  audience: "Solutions Architect",
  opportunitySummary: "We need a healthcare AI demo with real structured output and clear business value.",
});
```

When a host app wants per-user journey governance, pass actor headers through the exported client by creating it with a `currentUser` identity in the host wrapper. Global admins are configured server-side with `SHERPA_ADMIN_EMAILS` in `api/.env`, and each host integration can pass `projectOwnerEmails` for the current project/demo so the API can recognize project owners for that scope.

When the AWS / Bedrock variables are configured, the same API can now act as a Sherpa-native AI service surface. Hosts can point `catalogApiBaseUrl` at the Sherpa API and let Studio/player discover service-backed `tts`, `transcribe`, and `translate` endpoints automatically through `GET /sherpa/service/capabilities`, instead of implementing host-local `/api/journey/*` routes.
