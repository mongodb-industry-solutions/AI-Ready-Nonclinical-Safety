import dotenv from "dotenv";
import { MongoClient } from "mongodb";

import {
  bootstrapPortalCatalog,
  ensureCatalogIndexes,
  extractSolutionLibraryDirectoryEntries,
  extractSitemapEntries,
  extractSolutionLibraryPreview,
  findBestDemoMatch,
  persistSolutionLibraryPreview,
} from "../lib/catalogServices.mjs";

dotenv.config({
  path: new URL("../.env", import.meta.url),
});

const env = (name, fallback = "") => process.env[name] || fallback;

if (!env("MONGODB_CONNECTION_STRING")) {
  throw new Error("Missing required environment variable: MONGODB_CONNECTION_STRING");
}

const mongoClient = new MongoClient(env("MONGODB_CONNECTION_STRING"));
await mongoClient.connect();

const db = mongoClient.db(env("SHERPA_DB", "demo-sherpa"));
const collections = {
  demos: db.collection(env("SHERPA_DEMOS_COLLECTION", "demos")),
  sources: db.collection(env("SHERPA_SOURCES_COLLECTION", "demo_sources")),
  assets: db.collection(env("SHERPA_ASSETS_COLLECTION", "demo_assets")),
  chunks: db.collection(env("SHERPA_CHUNKS_COLLECTION", "demo_chunks")),
  taxonomies: db.collection(env("SHERPA_TAXONOMIES_COLLECTION", "taxonomies")),
  journeys: db.collection(env("SHERPA_JOURNEYS_COLLECTION", "journeys")),
  journeySteps: db.collection(env("SHERPA_JOURNEY_STEPS_COLLECTION", "journey_steps")),
  ingestionJobs: db.collection(env("SHERPA_INGESTION_JOBS_COLLECTION", "ingestion_jobs")),
};

await ensureCatalogIndexes(collections);
const bootstrapResult = await bootstrapPortalCatalog(collections, { overwrite: false });

const directoryUrl = env(
  "SHERPA_SOLUTION_LIBRARY_DIRECTORY",
  "https://www.mongodb.com/docs/atlas/architecture/current/solutions-library/",
);
const sitemapUrl = env(
  "SHERPA_SOLUTION_LIBRARY_SITEMAP",
  "https://www.mongodb.com/docs/atlas/architecture/current/sitemap-0.xml",
);

let detailUrls = await extractSitemapEntries(
  sitemapUrl,
  (url) => url.includes("/solutions-library/") && url !== directoryUrl,
);
if (!detailUrls.length) {
  detailUrls = await extractSolutionLibraryDirectoryEntries(directoryUrl);
}
const demos = await collections.demos.find({}, { projection: { _id: 1, slug: 1, name: 1 } }).toArray();
const existingSolutionLibrarySources = await collections.sources
  .find({ sourceType: "solution-library" }, { projection: { url: 1 } })
  .toArray();
const existingSolutionLibraryUrlSet = new Set(
  existingSolutionLibrarySources
    .map((item) => item?.url)
    .filter(Boolean),
);
const maxItems = Number.parseInt(env("SHERPA_INGEST_MAX", "0"), 10);
const urlsToProcess = detailUrls.filter((url) => !existingSolutionLibraryUrlSet.has(url));
const limitedUrls = maxItems > 0 ? urlsToProcess.slice(0, maxItems) : urlsToProcess;

const summary = {
  bootstrap: bootstrapResult,
  directoryUrl,
  sitemapUrl,
  directoryEntries: detailUrls.length,
  alreadyPresent: existingSolutionLibraryUrlSet.size,
  queued: limitedUrls.length,
  ingested: 0,
  matched: 0,
  unmatched: 0,
  skipped: 0,
  failed: 0,
  items: [],
};

for (const [index, url] of limitedUrls.entries()) {
  try {
    console.log(`Ingesting ${index + 1}/${limitedUrls.length}: ${url}`);
    const preview = await extractSolutionLibraryPreview(url);
    const match = findBestDemoMatch(preview.title, demos);
    const persistence = await persistSolutionLibraryPreview(collections, {
      preview,
      url,
      demoSlug: match?.demo?.slug || null,
    });

    if (match?.demo?.slug) {
      await collections.demos.updateOne(
        { _id: match.demo._id },
        {
          $set: {
            "resourceCoverage.solutionLibrary": true,
            updatedAt: new Date(),
          },
          $addToSet: {
            "resourceLinks.solutionLibrary": {
              url,
              title: preview.title,
            },
          },
        },
      );
      summary.matched += 1;
    } else {
      summary.unmatched += 1;
    }

    summary.ingested += 1;
    summary.items.push({
      title: preview.title,
      url,
      matchedDemo: match?.demo?.name || null,
      matchScore: match?.score || null,
      sourceId: persistence.sourceId,
      jobId: persistence.jobId,
    });
  } catch (error) {
    summary.failed += 1;
    summary.items.push({
      url,
      error: String(error?.message || error),
    });
  }
}

console.log(JSON.stringify(summary, null, 2));

await mongoClient.close();
