import dotenv from "dotenv";
import { MongoClient } from "mongodb";

import { PORTAL_DEMOS, DEFAULT_TAXONOMIES } from "../lib/catalogSeed.mjs";
import { DEMO_LOGO_FILENAMES, buildDemoLogoUrl } from "../lib/demoLogoMappings.mjs";

dotenv.config({
  path: new URL("../.env", import.meta.url),
});

const slugify = (value) =>
  String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .replace(/-+/g, "-");

const now = () => new Date();

const resolveIndustry = (industryLabel) => {
  const raw = String(industryLabel || "").trim();
  const normalized = raw.toLowerCase();
  const entry = (DEFAULT_TAXONOMIES.industries || []).find((item) =>
    String(item.label || "").trim().toLowerCase() === normalized
  );
  if (!entry) {
    return [{ id: slugify(raw), label: raw }];
  }
  return [{ id: entry.key, label: entry.label }];
};

const client = new MongoClient(process.env.MONGODB_CONNECTION_STRING);

try {
  await client.connect();
  const db = client.db(process.env.SHERPA_DB || "demo-sherpa");
  const demos = db.collection(process.env.SHERPA_DEMOS_COLLECTION || "demos");
  const assets = db.collection(process.env.SHERPA_ASSETS_COLLECTION || "demo_assets");

  let updated = 0;
  let missing = 0;

  for (const seedDemo of PORTAL_DEMOS) {
    const slug = slugify(seedDemo.name);
    const demo = await demos.findOne({ slug }, { projection: { _id: 1, name: 1 } });
    if (!demo?._id) {
      missing += 1;
      continue;
    }

    const filename = DEMO_LOGO_FILENAMES[slug] || "";
    let logoAssetId = null;
    if (filename) {
      const url = buildDemoLogoUrl(filename);
      const existingAsset = await assets.findOne(
        { demoId: demo._id, assetKind: "logo", url },
        { projection: { _id: 1 } },
      );
      logoAssetId = existingAsset?._id || (
        await assets.insertOne({
          demoId: demo._id,
          sourceId: null,
          assetKind: "logo",
          title: `${demo.name} logo`,
          mimeType: "image/png",
          url,
          storageKey: null,
          thumbnailUrl: url,
          language: null,
          pageNumber: null,
          caption: "Demo portal logo",
          ocrText: null,
          metadata: {
            source: "portal-review-reconciliation",
            filename,
          },
          createdAt: now(),
        })
      ).insertedId;
    }

    await demos.updateOne(
      { _id: demo._id },
      {
        $set: {
          availability: seedDemo.availability || "available",
          status: seedDemo.availability === "currently-unavailable" ? "currently-unavailable" : "active",
          builtByPartner: Boolean(seedDemo.builtByPartner),
          portal: {
            seedVersion: "2026-03-15-portal-review",
            industryLabel: seedDemo.industry,
            labels: [...(seedDemo.portalLabels || [])],
            primaryLabel: String(seedDemo.portalLabels?.[0] || seedDemo.industry || "").trim(),
            tryDemoEnabled: seedDemo.availability !== "currently-unavailable",
          },
          industries: resolveIndustry(seedDemo.industry),
          ...(logoAssetId ? { logoAssetId } : {}),
          updatedAt: now(),
        },
      },
    );
    updated += 1;
  }

  console.log(JSON.stringify({ updated, missing }, null, 2));
} finally {
  await client.close();
}
