import dotenv from "dotenv";
import { MongoClient } from "mongodb";

import { DEMO_LOGO_FILENAMES, buildDemoLogoUrl } from "../lib/demoLogoMappings.mjs";

dotenv.config({
  path: new URL("../.env", import.meta.url),
});

const client = new MongoClient(process.env.MONGODB_CONNECTION_STRING);

const now = () => new Date();

try {
  await client.connect();
  const db = client.db(process.env.SHERPA_DB || "demo-sherpa");
  const demos = db.collection(process.env.SHERPA_DEMOS_COLLECTION || "demos");
  const assets = db.collection(process.env.SHERPA_ASSETS_COLLECTION || "demo_assets");

  let updated = 0;
  let missing = 0;

  for (const [slug, filename] of Object.entries(DEMO_LOGO_FILENAMES)) {
    const demo = await demos.findOne({ slug }, { projection: { _id: 1, name: 1, resourceCoverage: 1, logoAssetId: 1 } });
    if (!demo) {
      missing += 1;
      continue;
    }

    const url = buildDemoLogoUrl(filename);
    const existingAsset = await assets.findOne({ demoId: demo._id, assetKind: "logo", url }, { projection: { _id: 1 } });
    const assetId = existingAsset?._id || (
      await assets.insertOne({
        demoId: demo._id,
        sourceId: null,
        assetKind: "logo",
        title: `${demo.name} logo`,
        mimeType: "image/png",
        url,
        storageKey: null,
        thumbnailUrl: url,
        language: null,
        pageNumber: null,
        caption: "Demo portal logo",
        ocrText: null,
        metadata: {
          source: "local-demo-logo-library",
          filename,
        },
        createdAt: now(),
      })
    ).insertedId;

    await demos.updateOne(
      { _id: demo._id },
      {
        $set: {
          logoAssetId: assetId,
          "resourceCoverage.logo": true,
          updatedAt: now(),
        },
      },
    );
    updated += 1;
  }

  console.log(JSON.stringify({
    updated,
    missingMappings: missing,
    mappedDemos: Object.keys(DEMO_LOGO_FILENAMES).length,
  }, null, 2));
} finally {
  await client.close();
}
