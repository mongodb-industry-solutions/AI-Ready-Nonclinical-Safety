import dotenv from "dotenv";

dotenv.config({
  path: new URL("../.env", import.meta.url),
});

const baseUrl = process.env.SHERPA_API_BASE_URL || `http://localhost:${process.env.PORT || "9091"}`;
const overwrite = String(process.env.SHERPA_BOOTSTRAP_OVERWRITE || "false").trim().toLowerCase() === "true";

const response = await fetch(`${baseUrl}/sherpa/catalog/bootstrap/portal`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({ overwrite }),
});

const payload = await response.json().catch(() => ({}));
if (!response.ok) {
  console.error(JSON.stringify(payload, null, 2));
  process.exit(1);
}

console.log(JSON.stringify(payload, null, 2));
