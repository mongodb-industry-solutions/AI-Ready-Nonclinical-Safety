import http from "node:http";
import fs from "node:fs";
import crypto from "node:crypto";
import { once } from "node:events";
import { URL, fileURLToPath } from "node:url";
import path from "node:path";

import dotenv from "dotenv";
import { GridFSBucket, MongoClient, ObjectId } from "mongodb";

import {
  canEditDemo,
  canEditJourney,
  canManageCatalog,
  canManageJourneyGovernance,
  canReadJourney,
  isAdminActorWithConfig,
  normalizeAdminEmails,
  parseActor,
} from "./lib/accessControl.mjs";
import { DEMO_LOGO_FILENAMES, buildDemoLogoUrl } from "./lib/demoLogoMappings.mjs";
import {
  bootstrapPortalCatalog,
  buildCopilotBrief,
  buildManualDemoDocument,
  embedCatalogChunks,
  createIntakeJob,
  ensureCatalogIndexes,
  extractSolutionLibraryPreview,
  persistSolutionLibraryPreview,
  sanitizeDemoUpdate,
  slugify,
  semanticSearchCatalog,
} from "./lib/catalogServices.mjs";
import { buildSherpaCopilotChatReply } from "./lib/copilotChat.mjs";
import { getVoyageConfig, isVoyageConfigured } from "./lib/voyage.mjs";
import { isBedrockConfigured } from "./lib/awsRuntime.mjs";
import { runAgentChat } from "./lib/agentOrchestrator.mjs";
import {
  getSherpaServiceCapabilities,
  prepareSherpaNarrationText,
  synthesizeSherpaSpeech,
  transcribeSherpaAudio,
} from "./lib/sherpaServices.mjs";
import { normalizeLaunchTargets } from "./lib/launchTargets.mjs";

dotenv.config({
  path: new URL("./.env", import.meta.url),
});

const env = (name, fallback = "") => process.env[name] || fallback;

if (!env("MONGODB_CONNECTION_STRING")) {
  throw new Error("Missing required environment variable: MONGODB_CONNECTION_STRING");
}

const parseIntValue = (value, fallback, minimum = null) => {
  const parsed = Number.parseInt(value, 10);
  const safe = Number.isNaN(parsed) ? fallback : parsed;
  return minimum === null ? safe : Math.max(minimum, safe);
};

const parseBoolValue = (value, fallback = false) => {
  if (value === undefined || value === null || value === "") return fallback;
  if (typeof value === "boolean") return value;
  const normalized = String(value).trim().toLowerCase();
  if (["1", "true", "yes", "y", "on"].includes(normalized)) return true;
  if (["0", "false", "no", "n", "off"].includes(normalized)) return false;
  return fallback;
};

const serializeDoc = (value) => {
  if (Array.isArray(value)) return value.map(serializeDoc);
  if (value instanceof Date) return value.toISOString();
  if (value && typeof value === "object") {
    if (value._bsontype === "ObjectId") return String(value);
    return Object.fromEntries(Object.entries(value).map(([key, nested]) => [key, serializeDoc(nested)]));
  }
  return value;
};

const allowedOrigins = env(
  "SHERPA_ALLOWED_ORIGINS",
  "http://localhost:3000,http://127.0.0.1:3000,http://localhost:3001,http://127.0.0.1:3001,http://localhost:8080,http://127.0.0.1:8080",
)
  .split(",")
  .map((value) => value.trim())
  .filter(Boolean);
const adminEmails = normalizeAdminEmails(env("SHERPA_ADMIN_EMAILS", ""));
const authOptions = { adminEmails };

const mongoClient = new MongoClient(env("MONGODB_CONNECTION_STRING"));
await mongoClient.connect();

const db = mongoClient.db(env("SHERPA_DB", "demo-sherpa"));
const collections = {
  demos: db.collection(env("SHERPA_DEMOS_COLLECTION", "demos")),
  sources: db.collection(env("SHERPA_SOURCES_COLLECTION", "demo_sources")),
  assets: db.collection(env("SHERPA_ASSETS_COLLECTION", "demo_assets")),
  journeyAssets: db.collection(env("SHERPA_JOURNEY_ASSETS_COLLECTION", "journey_assets")),
  chunks: db.collection(env("SHERPA_CHUNKS_COLLECTION", "demo_chunks")),
  taxonomies: db.collection(env("SHERPA_TAXONOMIES_COLLECTION", "taxonomies")),
  journeys: db.collection(env("SHERPA_JOURNEYS_COLLECTION", "journeys")),
  journeySteps: db.collection(env("SHERPA_JOURNEY_STEPS_COLLECTION", "journey_steps")),
  ingestionJobs: db.collection(env("SHERPA_INGESTION_JOBS_COLLECTION", "ingestion_jobs")),
};
const journeyAssetBucket = new GridFSBucket(db, {
  bucketName: env("SHERPA_JOURNEY_FILES_BUCKET", "journey_asset_files"),
});

await ensureCatalogIndexes(collections);

const json = (res, statusCode, payload, origin) => {
  res.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": resolveCorsOrigin(origin),
    "Access-Control-Allow-Credentials": "true",
    "Access-Control-Allow-Headers": "Content-Type, x-sherpa-user-id, x-sherpa-user-name, x-sherpa-user-email, x-sherpa-user-roles, x-sherpa-project-owner-scopes, x-sherpa-project-owner-emails, x-sherpa-project-id, x-sherpa-project-slug, x-sherpa-project-name",
    "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
  });
  res.end(JSON.stringify(payload));
};

const readBody = async (req) => {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  if (!chunks.length) return {};
  const raw = Buffer.concat(chunks).toString("utf8").trim();
  return raw ? JSON.parse(raw) : {};
};

const readFormData = async (req) => {
  const request = new Request(`http://localhost${req.url || "/"}`, {
    method: req.method || "POST",
    headers: req.headers,
    body: req,
    duplex: "half",
  });
  return request.formData();
};

const sanitizeJourneyForActor = (journey, actor, existingJourney = null) => {
  const { _id, ...rawJourney } = journey || {};
  const safeJourney = sanitizeJourneyMediaFields(rawJourney);
  const context = safeJourney?.context || {};
  const governanceInput = journey?.governance || {};
  const existingGovernance = existingJourney?.governance || {};
  const canManageGovernance = canManageJourneyGovernance(
    {
      ...existingJourney,
      context: {
        ...(existingJourney?.context || {}),
        ...(context || {}),
      },
    },
    actor,
    authOptions,
  );
  const ownerId = String(existingGovernance.ownerId || actor?.id || "");
  const ownerName = String(existingGovernance.ownerName || actor?.name || "");
  const ownerEmail = String(existingGovernance.ownerEmail || actor?.email || "");
  const requestedStatus = String(governanceInput.publicationStatus || existingGovernance.publicationStatus || "draft");
  const publicationStatus = !canManageGovernance && requestedStatus === "recommended"
    ? String(existingGovernance.publicationStatus || "draft")
    : requestedStatus;

  return {
    ...safeJourney,
    demoId: context?.demoId || existingJourney?.demoId || "",
    demoSlug: context?.demoSlug || existingJourney?.demoSlug || "",
    governance: {
      ownerId,
      ownerName,
      ownerEmail,
      editorIds: canManageGovernance && Array.isArray(governanceInput.editorIds)
        ? governanceInput.editorIds.map((value) => String(value || "").trim()).filter(Boolean)
        : Array.isArray(existingGovernance.editorIds)
          ? existingGovernance.editorIds
          : [],
      visibility: canManageGovernance && ["private", "team", "public"].includes(governanceInput.visibility)
        ? governanceInput.visibility
        : existingGovernance.visibility || "private",
      publicationStatus: ["draft", "review", "published", "recommended", "archived"].includes(publicationStatus)
        ? publicationStatus
        : "draft",
      isRecommended: canManageGovernance
        ? Boolean(governanceInput.isRecommended || publicationStatus === "recommended")
        : Boolean(existingGovernance.isRecommended),
    },
    createdBy: String(existingJourney?.createdBy || actor?.id || ""),
    updatedBy: String(actor?.id || existingJourney?.updatedBy || ""),
    createdAt: existingJourney?.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
};

const staticRoot = fileURLToPath(new URL("../public/", import.meta.url));
const distRoot = fileURLToPath(new URL("../dist/", import.meta.url));
const vendorRoot = fileURLToPath(new URL("../node_modules/", import.meta.url));
const buildJourneyAssetPath = (assetId) => `/sherpa/journey-assets/${String(assetId)}/content`;
const browserShimModules = {
  "/dist-shims/react.js": `const sherpaDeps = window.__DEMO_SHERPA_DEPS__ || window.__LEAFY_SHERPA_DEPS__;
const React = sherpaDeps?.React;
if (!React) throw new Error("Demo Sherpa React shim is not initialized");
export default React;
export const useCallback = React.useCallback;
export const useEffect = React.useEffect;
export const useMemo = React.useMemo;
export const useRef = React.useRef;
export const useState = React.useState;
export const createElement = React.createElement;
export const Fragment = React.Fragment;
export const Component = React.Component;
`,
  "/dist-shims/react-dom.js": `const sherpaDeps = window.__DEMO_SHERPA_DEPS__ || window.__LEAFY_SHERPA_DEPS__;
const ReactDOM = sherpaDeps?.ReactDOM;
if (!ReactDOM) throw new Error("Demo Sherpa ReactDOM shim is not initialized");
export default ReactDOM;
export const createPortal = ReactDOM.createPortal.bind(ReactDOM);
`,
  "/dist-shims/react-router-dom.js": `const sherpaDeps = window.__DEMO_SHERPA_DEPS__ || window.__LEAFY_SHERPA_DEPS__;
const ReactRouterDOM = sherpaDeps?.ReactRouterDOM;
if (!ReactRouterDOM) throw new Error("Demo Sherpa React Router shim is not initialized");
export default ReactRouterDOM;
export const useLocation = ReactRouterDOM.useLocation;
export const useNavigate = ReactRouterDOM.useNavigate;
`,
};

const guessMimeType = (pathname) => {
  const ext = path.extname(pathname).toLowerCase();
  if (ext === ".js" || ext === ".mjs") return "text/javascript; charset=utf-8";
  if (ext === ".css") return "text/css; charset=utf-8";
  if (ext === ".json") return "application/json; charset=utf-8";
  if (ext === ".png") return "image/png";
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  if (ext === ".svg") return "image/svg+xml";
  if (ext === ".webp") return "image/webp";
  return "application/octet-stream";
};

const resolveCorsOrigin = (origin) =>
  origin && allowedOrigins.includes(origin) ? origin : allowedOrigins[0] || "*";

const rewriteBrowserModuleImports = (contents) =>
  String(contents || "")
    .replaceAll('from "react";', 'from "/dist-shims/react.js";')
    .replaceAll('from "react-dom";', 'from "/dist-shims/react-dom.js";')
    .replaceAll('from "react-router-dom";', 'from "/dist-shims/react-router-dom.js";')
    .replaceAll('from "html2canvas";', 'from "/dist/vendor/html2canvas.js";')
    .replaceAll('import("html2canvas")', 'import("/dist/vendor/html2canvas.js")');

const toCssShimPath = (modulePathname, relativeImport) => {
  const resolvedUrl = new URL(relativeImport, `http://localhost${modulePathname}`);
  return `/dist-css${resolvedUrl.pathname.replace(/^\/dist/, "")}.js`;
};

const rewriteCssImports = (contents, modulePathname) =>
  String(contents || "").replace(
    /import\s+["']([^"']+\.css)["'];/g,
    (_, cssImportPath) => `import "${toCssShimPath(modulePathname, cssImportPath)}";`
  );

const buildCssInjectionModule = (cssContents) => {
  const css = String(cssContents || "");
  const styleId = `demo-sherpa-style-${crypto.createHash("sha1").update(css).digest("hex").slice(0, 16)}`;
  return `const css = ${JSON.stringify(css)};
const styleId = ${JSON.stringify(styleId)};
if (!document.getElementById(styleId)) {
  const style = document.createElement("style");
  style.id = styleId;
  style.textContent = css;
  document.head.appendChild(style);
}
export default css;
`;
};

const toAbsoluteAssetUrl = (assetUrl, req) => {
  if (!assetUrl) return "";
  if (/^https?:\/\//i.test(assetUrl)) return assetUrl;
  const host = req.headers.host || "localhost:9091";
  return `http://${host}${assetUrl.startsWith("/") ? assetUrl : `/${assetUrl}`}`;
};

const parseDataUrlPayload = (dataUrl) => {
  const raw = String(dataUrl || "");
  const commaIndex = raw.indexOf(",");
  if (commaIndex <= 5 || !raw.startsWith("data:")) {
    throw new Error("Invalid data URL payload");
  }
  const header = raw.slice(5, commaIndex);
  const body = raw.slice(commaIndex + 1);
  const headerParts = header.split(";").map((value) => value.trim()).filter(Boolean);
  const mimeType = headerParts[0] && !headerParts[0].includes("=")
    ? headerParts[0]
    : "application/octet-stream";
  if (!headerParts.includes("base64")) {
    throw new Error("Journey asset payload must be base64 encoded");
  }
  return {
    mimeType,
    buffer: Buffer.from(body, "base64"),
  };
};

const getJourneyAssetQuery = ({
  journeyId,
  stepId,
  clipId = "",
  imageId = "",
  segmentId = "",
  locale = "",
  assetType,
}) => {
  if (assetType === "clip") {
    return { journeyId, stepId, clipId, assetType };
  }
  if (assetType === "step-frame") {
    return { journeyId, stepId, imageId, assetType };
  }
  if (assetType === "segment-voice") {
    return {
      journeyId,
      stepId,
      segmentId,
      locale: String(locale || "").trim().toLowerCase(),
      assetType,
    };
  }
  return { journeyId, stepId, assetType };
};

const sanitizeSegmentTranslations = (translations = {}) =>
  Object.fromEntries(
    Object.entries(translations || {}).map(([key, value]) => [
      key,
      {
        ...value,
        audioDataUrl: null,
        audioAssetId: String(value?.audioAssetId || ""),
        audioAssetUrl: value?.audioAssetId ? buildJourneyAssetPath(value.audioAssetId) : "",
      },
    ]),
  );

const sanitizeJourneyMediaFields = (journey) => ({
  ...journey,
  steps: Array.isArray(journey?.steps)
    ? journey.steps.map((step) => ({
        ...step,
        voiceDataUrl: null,
        voiceAssetId: String(step?.voiceAssetId || ""),
        voiceAssetUrl: step?.voiceAssetId ? buildJourneyAssetPath(step.voiceAssetId) : "",
        posterImageDataUrl: null,
        posterMimeType: String(step?.posterMimeType || "image/webp"),
        posterAssetId: String(step?.posterAssetId || ""),
        posterAssetUrl: step?.posterAssetId ? buildJourneyAssetPath(step.posterAssetId) : "",
        capturedImages: Array.isArray(step?.capturedImages)
          ? step.capturedImages.map((image) => ({
              ...image,
              dataUrl: null,
              assetId: String(image?.assetId || ""),
              assetUrl: image?.assetId ? buildJourneyAssetPath(image.assetId) : String(image?.assetUrl || ""),
            }))
          : [],
        audioClips: Array.isArray(step?.audioClips)
          ? step.audioClips.map((clip) => ({
              ...clip,
              blobDataUrl: null,
              assetId: String(clip?.assetId || ""),
              assetUrl: clip?.assetId ? buildJourneyAssetPath(clip.assetId) : "",
            }))
          : [],
        narrationSegments: Array.isArray(step?.narrationSegments)
          ? step.narrationSegments.map((segment) => ({
              ...segment,
              translations: sanitizeSegmentTranslations(segment?.translations),
            }))
          : [],
      }))
    : [],
});

const hydrateJourneyMediaUrls = (journey, req) => ({
  ...journey,
  steps: Array.isArray(journey?.steps)
    ? journey.steps.map((step) => ({
        ...step,
        voiceAssetUrl: step?.voiceAssetId
          ? toAbsoluteAssetUrl(buildJourneyAssetPath(step.voiceAssetId), req)
          : "",
        posterAssetUrl: step?.posterAssetId
          ? toAbsoluteAssetUrl(buildJourneyAssetPath(step.posterAssetId), req)
          : "",
        capturedImages: Array.isArray(step?.capturedImages)
          ? step.capturedImages.map((image) => ({
              ...image,
              assetUrl: image?.assetId
                ? toAbsoluteAssetUrl(buildJourneyAssetPath(image.assetId), req)
                : String(image?.assetUrl || ""),
            }))
          : [],
        audioClips: Array.isArray(step?.audioClips)
          ? step.audioClips.map((clip) => ({
              ...clip,
              assetUrl: clip?.assetId
                ? toAbsoluteAssetUrl(buildJourneyAssetPath(clip.assetId), req)
                : "",
            }))
          : [],
        narrationSegments: Array.isArray(step?.narrationSegments)
          ? step.narrationSegments.map((segment) => ({
              ...segment,
              translations: Object.fromEntries(
                Object.entries(segment?.translations || {}).map(([key, value]) => [
                  key,
                  {
                    ...value,
                    audioAssetUrl: value?.audioAssetId
                      ? toAbsoluteAssetUrl(buildJourneyAssetPath(value.audioAssetId), req)
                      : "",
                  },
                ]),
              ),
            }))
          : [],
      }))
    : [],
});

const collectReferencedJourneyAssetIds = (journey) => {
  const ids = new Set();
  (journey?.steps || []).forEach((step) => {
    const voiceAssetId = String(step?.voiceAssetId || "").trim();
    if (ObjectId.isValid(voiceAssetId)) ids.add(voiceAssetId);

    const posterAssetId = String(step?.posterAssetId || "").trim();
    if (ObjectId.isValid(posterAssetId)) ids.add(posterAssetId);

    (step?.capturedImages || []).forEach((image) => {
      const imageAssetId = String(image?.assetId || "").trim();
      if (ObjectId.isValid(imageAssetId)) ids.add(imageAssetId);
    });

    (step?.audioClips || []).forEach((clip) => {
      const clipAssetId = String(clip?.assetId || "").trim();
      if (ObjectId.isValid(clipAssetId)) ids.add(clipAssetId);
    });

    (step?.narrationSegments || []).forEach((segment) => {
      Object.values(segment?.translations || {}).forEach((translation) => {
        const audioAssetId = String(translation?.audioAssetId || "").trim();
        if (ObjectId.isValid(audioAssetId)) ids.add(audioAssetId);
      });
    });
  });
  return ids;
};

const removeUnreferencedJourneyAssets = async (journeyId, journey) => {
  if (!journeyId) return;
  const referencedIds = collectReferencedJourneyAssetIds(journey);
  const relatedAssets = await collections.journeyAssets.find({ journeyId }).toArray();
  const orphanedAssets = relatedAssets.filter((asset) => !referencedIds.has(String(asset?._id || "")));
  await Promise.all(orphanedAssets.map((asset) => removeJourneyAssetDocument(asset)));
};

const removeJourneyAssetDocument = async (assetDoc) => {
  if (!assetDoc) return;
  if (assetDoc.gridFsFileId) {
    try {
      await journeyAssetBucket.delete(assetDoc.gridFsFileId);
    } catch {
      // ignore missing file blobs
    }
  }
  await collections.journeyAssets.deleteOne({ _id: assetDoc._id });
};

const storeJourneyAsset = async ({
  actor,
  journeyId,
  stepId,
  clipId = "",
  imageId = "",
  segmentId = "",
  locale = "",
  assetType,
  fileName = "",
  mimeType = "",
  dataUrl = "",
}) => {
  const parsed = parseDataUrlPayload(dataUrl);
  const effectiveMimeType = mimeType || parsed.mimeType || "application/octet-stream";
  const fingerprint = crypto.createHash("sha1").update(parsed.buffer).digest("hex");
  const query = getJourneyAssetQuery({ journeyId, stepId, clipId, imageId, segmentId, locale, assetType });
  const existing = await collections.journeyAssets.findOne(query);
  if (existing?.fingerprint === fingerprint) {
    return existing;
  }
  if (existing) {
    await removeJourneyAssetDocument(existing);
  }

  const uploadStream = journeyAssetBucket.openUploadStream(
    fileName || `${journeyId}-${stepId}-${clipId || imageId || assetType}.${effectiveMimeType.split("/")[1] || "bin"}`,
    {
      contentType: effectiveMimeType,
      metadata: {
        journeyId,
        stepId,
        clipId: clipId || null,
        imageId: imageId || null,
        segmentId: segmentId || null,
        locale: locale ? String(locale).trim().toLowerCase() : null,
        assetType,
        ownerId: actor?.id || "",
        ownerEmail: actor?.email || "",
        fingerprint,
      },
    },
  );
  uploadStream.end(parsed.buffer);
  await once(uploadStream, "finish");

  const now = new Date();
  const assetDoc = {
    ...query,
    ownerId: String(actor?.id || ""),
    ownerName: String(actor?.name || ""),
    ownerEmail: String(actor?.email || ""),
    fileName: fileName || uploadStream.filename,
    mimeType: effectiveMimeType,
    sizeBytes: parsed.buffer.length,
    fingerprint,
    gridFsFileId: uploadStream.id,
    createdAt: now,
    updatedAt: now,
  };
  const insertResult = await collections.journeyAssets.insertOne(assetDoc);
  return {
    ...assetDoc,
    _id: insertResult.insertedId,
  };
};

const withDemoLogos = async (demoDocs, req) => {
  const demos = Array.isArray(demoDocs) ? demoDocs : [demoDocs].filter(Boolean);
  if (!demos.length) return Array.isArray(demoDocs) ? [] : null;

  const logoAssetIds = demos.map((demo) => demo?.logoAssetId).filter(Boolean);
  const logoAssets = logoAssetIds.length
    ? await collections.assets.find({ _id: { $in: logoAssetIds } }).toArray()
    : [];
  const logoById = new Map(logoAssets.map((asset) => [String(asset._id), asset]));

  const hydrated = demos.map((demo) => {
    const logoAsset = logoById.get(String(demo.logoAssetId || "")) || null;
    const assetLogoUrl = logoAsset ? toAbsoluteAssetUrl(logoAsset.url || logoAsset.thumbnailUrl, req) : "";
    const mappedLogoUrl = buildDemoLogoUrl(DEMO_LOGO_FILENAMES[demo.slug] || "");
    return {
      ...demo,
      logoUrl: assetLogoUrl || toAbsoluteAssetUrl(demo.logoUrl || mappedLogoUrl, req) || "",
      logoAsset: logoAsset ? serializeDoc(logoAsset) : null,
    };
  });

  return Array.isArray(demoDocs) ? hydrated : hydrated[0];
};

const sendServiceError = (res, origin, fallbackMessage, error) => {
  json(res, Number(error?.status || 500) || 500, {
    error: fallbackMessage,
    details: String(error?.details || error?.message || error || fallbackMessage),
    ...(error?.code ? { code: String(error.code) } : {}),
    ...(error?.type ? { type: String(error.type) } : {}),
    ...(error?.provider ? { provider: String(error.provider) } : {}),
  }, origin);
};

const appendUnique = (items, value) => {
  if (!value) return items || [];
  const values = Array.isArray(items) ? [...items] : [];
  if (!values.includes(value)) values.push(value);
  return values;
};

const escapeRegex = (value) => String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const buildDemoJourneyQuery = (demo) => {
  if (!demo?._id && !demo?.slug && !demo?.name) return {};
  const demoId = demo?._id || null;
  const slug = String(demo?.slug || "").trim();
  const name = String(demo?.name || "").trim();
  const or = [];
  if (demoId) {
    or.push({ demoId });
    or.push({ "context.demoId": demoId });
    or.push({ "context.demoId": String(demoId) });
  }
  if (slug) {
    or.push({ "context.demoSlug": slug });
  }
  if (name) {
    or.push({ "context.demoName": { $regex: `^${escapeRegex(name)}$`, $options: "i" } });
  }
  return or.length ? { $or: or } : {};
};

const maybeCreateExternalAsset = async (demoId, sourceId, assetKind, url, title) => {
  if (!demoId || !url) return null;
  const existing = await collections.assets.findOne({ demoId, assetKind, url }, { projection: { _id: 1 } });
  if (existing) return existing._id;
  const result = await collections.assets.insertOne({
    demoId,
    sourceId,
    assetKind,
    title,
    mimeType: null,
    url,
    storageKey: null,
    thumbnailUrl: url,
    language: null,
    pageNumber: null,
    caption: "",
    ocrText: null,
    metadata: {
      status: "linked-not-downloaded",
      source: "manual-intake",
    },
    createdAt: new Date(),
  });
  return result.insertedId;
};

const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin;
  if (req.method === "OPTIONS") {
    json(res, 200, { ok: true }, origin);
    return;
  }

  const requestUrl = new URL(req.url, `http://${req.headers.host}`);
  const { pathname, searchParams } = requestUrl;

  try {
    if (req.method === "GET" && browserShimModules[pathname]) {
      res.writeHead(200, {
        "Content-Type": "text/javascript; charset=utf-8",
        "Access-Control-Allow-Origin": resolveCorsOrigin(origin),
        "Access-Control-Allow-Credentials": "true",
      });
      res.end(browserShimModules[pathname]);
      return;
    }

    if (req.method === "GET" && pathname === "/dist-vendor/html2canvas.js") {
      const filePath = path.resolve(vendorRoot, "html2canvas/dist/html2canvas.esm.js");
      if (!filePath.startsWith(vendorRoot) || !fs.existsSync(filePath)) {
        json(res, 404, { error: "Vendor module not found" }, origin);
        return;
      }
      res.writeHead(200, {
        "Content-Type": "text/javascript; charset=utf-8",
        "Access-Control-Allow-Origin": resolveCorsOrigin(origin),
        "Access-Control-Allow-Credentials": "true",
      });
      res.end(fs.readFileSync(filePath, "utf8"));
      return;
    }

    if (req.method === "GET" && pathname.startsWith("/dist-css/")) {
      const relativePath = decodeURIComponent(pathname.replace(/^\/dist-css\//, "").replace(/\.js$/, ""));
      const safePath = path.normalize(relativePath).replace(/^(\.\.(\/|\\|$))+/, "");
      const filePath = path.resolve(distRoot, safePath);
      if (!filePath.startsWith(distRoot) || !fs.existsSync(filePath)) {
        json(res, 404, { error: "Stylesheet not found" }, origin);
        return;
      }
      res.writeHead(200, {
        "Content-Type": "text/javascript; charset=utf-8",
        "Access-Control-Allow-Origin": resolveCorsOrigin(origin),
        "Access-Control-Allow-Credentials": "true",
      });
      res.end(buildCssInjectionModule(fs.readFileSync(filePath, "utf8")));
      return;
    }

    if (req.method === "GET" && pathname.startsWith("/dist/")) {
      const relativePath = decodeURIComponent(pathname.replace(/^\/+/, ""));
      const safePath = path.normalize(relativePath.replace(/^dist\//, "")).replace(/^(\.\.(\/|\\|$))+/, "");
      const filePath = path.resolve(distRoot, safePath);
      if (!filePath.startsWith(distRoot) || !fs.existsSync(filePath)) {
        json(res, 404, { error: "Module not found" }, origin);
        return;
      }
      const mimeType = guessMimeType(filePath);
      if (mimeType.startsWith("text/javascript")) {
        res.writeHead(200, {
          "Content-Type": mimeType,
          "Access-Control-Allow-Origin": resolveCorsOrigin(origin),
          "Access-Control-Allow-Credentials": "true",
        });
        const source = fs.readFileSync(filePath, "utf8");
        res.end(rewriteCssImports(rewriteBrowserModuleImports(source), pathname));
        return;
      }
      res.writeHead(200, {
        "Content-Type": mimeType,
        "Access-Control-Allow-Origin": resolveCorsOrigin(origin),
        "Access-Control-Allow-Credentials": "true",
      });
      fs.createReadStream(filePath).pipe(res);
      return;
    }

    if (req.method === "GET" && (pathname.startsWith("/demo-logos/") || pathname.startsWith("/icons/"))) {
      const relativePath = decodeURIComponent(pathname.replace(/^\/+/, ""));
      const safePath = path.normalize(relativePath).replace(/^(\.\.(\/|\\|$))+/, "");
      const filePath = path.resolve(staticRoot, safePath);
      if (!filePath.startsWith(staticRoot) || !fs.existsSync(filePath)) {
        json(res, 404, { error: "Asset not found" }, origin);
        return;
      }
      res.writeHead(200, {
        "Content-Type": guessMimeType(filePath),
        "Access-Control-Allow-Origin": origin && allowedOrigins.includes(origin) ? origin : allowedOrigins[0] || "*",
      });
      fs.createReadStream(filePath).pipe(res);
      return;
    }

    if (req.method === "GET" && pathname === "/") {
      json(res, 200, {
        ok: true,
        service: "demo-sherpa-api",
        endpoints: [
          "/sherpa/catalog/health",
          "/sherpa/access/capabilities",
          "/sherpa/catalog/bootstrap/portal",
          "/sherpa/catalog/embed",
          "/sherpa/catalog/search/semantic",
          "/sherpa/catalog/taxonomies",
          "/sherpa/catalog/demos",
          "/sherpa/catalog/ingestion/jobs",
          "/sherpa/catalog/ingestion/solution-library/preview",
          "/sherpa/copilot/brief",
          "/sherpa/copilot/chat",
          "/sherpa/journeys",
        ],
      }, origin);
      return;
    }

    if (req.method === "GET" && pathname === "/sherpa/catalog/health") {
      await ensureCatalogIndexes(collections);
      json(res, 200, {
        ok: true,
        voyage: {
          configured: isVoyageConfigured(),
          model: getVoyageConfig().embeddingModel,
        },
        counts: {
          demos: await collections.demos.estimatedDocumentCount(),
          sources: await collections.sources.estimatedDocumentCount(),
          assets: await collections.assets.estimatedDocumentCount(),
          journeyAssets: await collections.journeyAssets.estimatedDocumentCount(),
          chunks: await collections.chunks.estimatedDocumentCount(),
          taxonomies: await collections.taxonomies.estimatedDocumentCount(),
          journeys: await collections.journeys.estimatedDocumentCount(),
          journeySteps: await collections.journeySteps.estimatedDocumentCount(),
          ingestionJobs: await collections.ingestionJobs.estimatedDocumentCount(),
        },
      }, origin);
      return;
    }

    if (req.method === "GET" && pathname === "/sherpa/access/capabilities") {
      const actor = parseActor(req);
      const projectScope = {
        projectId: String(searchParams.get("projectId") || actor?.projectScope?.projectId || "").trim(),
        projectSlug: String(searchParams.get("projectSlug") || actor?.projectScope?.projectSlug || "").trim(),
        projectName: String(searchParams.get("projectName") || actor?.projectScope?.projectName || "").trim(),
      };
      const isAdmin = isAdminActorWithConfig(actor, authOptions);
      const canManageProject = canManageCatalog(actor, projectScope, authOptions);
      json(res, 200, {
        actor: {
          email: String(actor?.email || "").trim(),
        },
        projectScope,
        capabilities: {
          isAdmin,
          isProjectOwner: canManageProject && !isAdmin,
          canManageCatalog: canManageProject,
        },
      }, origin);
      return;
    }

    if (req.method === "GET" && pathname === "/sherpa/service/capabilities") {
      json(res, 200, {
        services: getSherpaServiceCapabilities(),
      }, origin);
      return;
    }

    if (req.method === "POST" && pathname === "/sherpa/services/tts") {
      try {
        const body = await readBody(req);
        const result = await synthesizeSherpaSpeech(body || {});
        json(res, 200, result, origin);
      } catch (error) {
        sendServiceError(res, origin, "Sherpa voice synthesis failed", error);
      }
      return;
    }

    if (req.method === "POST" && pathname === "/sherpa/services/transcribe") {
      try {
        const formData = await readFormData(req);
        const file = formData.get("file");
        if (!file) {
          json(res, 400, { error: "Missing required form field: file" }, origin);
          return;
        }
        const result = await transcribeSherpaAudio({
          file,
          sourceLanguage: String(formData.get("sourceLanguage") || "").trim(),
          sourceLocale: String(formData.get("sourceLocale") || "").trim(),
        });
        json(res, 200, result, origin);
      } catch (error) {
        sendServiceError(res, origin, "Sherpa transcription failed", error);
      }
      return;
    }

    if (req.method === "POST" && pathname === "/sherpa/services/translate") {
      try {
        const body = await readBody(req);
        const result = await prepareSherpaNarrationText(body || {});
        json(res, 200, result, origin);
      } catch (error) {
        sendServiceError(res, origin, "Sherpa narration preparation failed", error);
      }
      return;
    }

    if (req.method === "POST" && pathname === "/sherpa/catalog/embed") {
      const actor = parseActor(req);
      if (!isAdminActorWithConfig(actor, authOptions)) {
        json(res, 403, { error: "Only admins can embed the catalog" }, origin);
        return;
      }
      const body = await readBody(req);
      const result = await embedCatalogChunks(collections, {
        limit: parseIntValue(body.limit, 200, 1),
        force: parseBoolValue(body.force, false),
      });
      json(res, 200, { success: true, result }, origin);
      return;
    }

    if (req.method === "POST" && pathname === "/sherpa/catalog/search/semantic") {
      const body = await readBody(req);
      const results = await semanticSearchCatalog(collections, {
        queryText: body.queryText,
        limit: parseIntValue(body.limit, 8, 1),
        filters: body.filters || {},
      });
      json(res, 200, {
        success: true,
        items: serializeDoc(results.map((result) => ({
          score: Number(result.score.toFixed(4)),
          chunk: result.chunk,
          demo: result.demo,
          source: result.source,
        }))),
      }, origin);
      return;
    }

    if (req.method === "POST" && pathname === "/sherpa/catalog/bootstrap/portal") {
      const actor = parseActor(req);
      if (!isAdminActorWithConfig(actor, authOptions)) {
        json(res, 403, { error: "Only admins can bootstrap the catalog" }, origin);
        return;
      }
      const body = await readBody(req);
      const result = await bootstrapPortalCatalog(collections, { overwrite: parseBoolValue(body.overwrite, false) });
      json(res, 200, { success: true, result }, origin);
      return;
    }

    if (req.method === "GET" && pathname === "/sherpa/catalog/taxonomies") {
      const taxonomy = String(searchParams.get("taxonomy") || "").trim();
      const query = taxonomy ? { taxonomy } : {};
      const items = await collections.taxonomies.find(query).sort({ taxonomy: 1, sortOrder: 1, label: 1 }).toArray();
      json(res, 200, { items: serializeDoc(items) }, origin);
      return;
    }

    if (req.method === "GET" && pathname === "/sherpa/catalog/demos") {
      const searchText = String(searchParams.get("q") || "").trim();
      const industry = String(searchParams.get("industry") || "").trim();
      const availability = String(searchParams.get("availability") || "").trim();
      const hasGuidedJourney = searchParams.get("hasGuidedJourney");
      const limit = Math.min(parseIntValue(searchParams.get("limit"), 100, 1), 250);
      const query = {};
      if (searchText) {
        query.$or = [
          { name: { $regex: searchText, $options: "i" } },
          { shortDescription: { $regex: searchText, $options: "i" } },
          { "portal.labels": { $regex: searchText, $options: "i" } },
          { "businessKnowhow.summary": { $regex: searchText, $options: "i" } },
        ];
      }
      if (industry) {
        query.$and = query.$and || [];
        query.$and.push({
          $or: [
            { "industries.id": industry },
            { "industries.label": { $regex: `^${industry}$`, $options: "i" } },
            { "portal.industryLabel": { $regex: `^${industry}$`, $options: "i" } },
          ],
        });
      }
      if (availability) query.availability = availability;
      if (hasGuidedJourney !== null) query.hasGuidedJourney = parseBoolValue(hasGuidedJourney, false);
      const fieldsParam = String(searchParams.get("fields") || "").trim();
      const projection = fieldsParam === "summary"
        ? { slug: 1, name: 1, logoUrl: 1, industries: 1, portal: 1, hasGuidedJourney: 1, availability: 1, builtByPartner: 1, launchUrl: 1, launchTargets: 1 }
        : undefined;
      const findOpts = projection ? { projection } : {};
      const items = await collections.demos.find(query, findOpts).sort({ name: 1 }).limit(limit).toArray();
      json(res, 200, { count: items.length, items: serializeDoc(await withDemoLogos(items, req)) }, origin);
      return;
    }

    if (req.method === "POST" && pathname === "/sherpa/catalog/demos") {
      const actor = parseActor(req);
      const body = await readBody(req);
      const name = String(body.name || body.demoName || "").trim();
      if (!name) {
        json(res, 400, { error: "Missing required field name" }, origin);
        return;
      }
      if (!canManageCatalog(actor, body, authOptions)) {
        json(res, 403, { error: "You do not have permission to create demos for this project" }, origin);
        return;
      }
      const slug = slugify(name);
      const existing = await collections.demos.findOne({ slug }, { projection: { _id: 1 } });
      if (existing) {
        json(res, 409, { error: "A demo with this name already exists", slug }, origin);
        return;
      }
      const demoDoc = buildManualDemoDocument(body);
      demoDoc.createdAt = new Date();
      demoDoc.updatedAt = new Date();
      const insertResult = await collections.demos.insertOne(demoDoc);
      const createdDemo = await collections.demos.findOne({ _id: insertResult.insertedId });
      json(res, 201, { success: true, demo: serializeDoc(createdDemo) }, origin);
      return;
    }

    const demoMatch = pathname.match(/^\/sherpa\/catalog\/demos\/([^/]+)$/);
    if (demoMatch && req.method === "GET") {
      const actor = parseActor(req);
      const slug = decodeURIComponent(demoMatch[1]);
      const demo = await collections.demos.findOne({ slug });
      if (!demo) {
        json(res, 404, { error: "Demo not found" }, origin);
        return;
      }
      const [sources, assets, journeys, chunks] = await Promise.all([
        collections.sources.find({ demoId: demo._id }).sort({ updatedAt: -1 }).toArray(),
        collections.assets.find({ demoId: demo._id }).sort({ createdAt: -1 }).toArray(),
        collections.journeys.find(buildDemoJourneyQuery(demo)).sort({ "governance.isRecommended": -1, updatedAt: -1, name: 1 }).toArray(),
        collections.chunks.find({ demoId: demo._id }).limit(20).toArray(),
      ]);
      json(res, 200, {
        demo: serializeDoc(await withDemoLogos(demo, req)),
        sources: serializeDoc(sources),
        assets: serializeDoc(assets),
        journeys: serializeDoc(
          journeys
            .filter((journey) => canReadJourney(journey, actor))
            .map((journey) => hydrateJourneyMediaUrls(journey, req))
        ),
        chunksPreview: serializeDoc(chunks),
      }, origin);
      return;
    }

    if (demoMatch && req.method === "PUT") {
      const actor = parseActor(req);
      const slug = decodeURIComponent(demoMatch[1]);
      const demo = await collections.demos.findOne({ slug });
      if (!demo) {
        json(res, 404, { error: "Demo not found" }, origin);
        return;
      }
      if (!canEditDemo(demo, actor, authOptions)) {
        json(res, 403, { error: "You do not have permission to update this demo" }, origin);
        return;
      }
      const body = await readBody(req);
      const updates = sanitizeDemoUpdate(body);
      if (Object.keys(updates).length <= 1) {
        json(res, 400, { error: "No editable fields supplied" }, origin);
        return;
      }
      if (!isAdminActorWithConfig(actor, authOptions) && ["projectId", "projectSlug", "projectName"].some((key) => Object.prototype.hasOwnProperty.call(updates, key))) {
        json(res, 403, { error: "Only admins can reassign a demo to a different project" }, origin);
        return;
      }
      await collections.demos.updateOne({ _id: demo._id }, { $set: updates });
      const updatedDemo = await collections.demos.findOne({ _id: demo._id });
      json(res, 200, { success: true, demo: serializeDoc(await withDemoLogos(updatedDemo, req)) }, origin);
      return;
    }

    if (pathname === "/sherpa/catalog/ingestion/jobs" && req.method === "GET") {
      const actor = parseActor(req);
      if (!isAdminActorWithConfig(actor, authOptions) && !canManageCatalog(actor, actor?.projectScope || {}, authOptions)) {
        json(res, 403, { error: "You do not have permission to view ingestion jobs" }, origin);
        return;
      }
      const limit = Math.min(parseIntValue(searchParams.get("limit"), 50, 1), 200);
      const query = isAdminActorWithConfig(actor, authOptions)
        ? {}
        : Object.fromEntries(Object.entries({
            ...(actor?.projectScope?.projectId ? { projectId: actor.projectScope.projectId } : {}),
            ...(actor?.projectScope?.projectSlug ? { projectSlug: actor.projectScope.projectSlug } : {}),
            ...(actor?.projectScope?.projectName ? { projectName: actor.projectScope.projectName } : {}),
          }).filter(([, value]) => value));
      const items = await collections.ingestionJobs.find(query).sort({ updatedAt: -1 }).limit(limit).toArray();
      json(res, 200, { count: items.length, items: serializeDoc(items) }, origin);
      return;
    }

    if (pathname === "/sherpa/catalog/ingestion/jobs" && req.method === "POST") {
      const actor = parseActor(req);
      const body = await readBody(req);
      if (!["demoName", "demoSlug", "portalUrl", "githubUrl", "videoUrl", "powerpointUrl", "solutionLibraryUrl", "enablementUrl", "logoUrl", "architectureDiagramUrl"].some((key) => body[key])) {
        json(res, 400, { error: "Provide at least one demo identifier or resource link" }, origin);
        return;
      }
      const demoSlug = String(body.demoSlug || "").trim() || (body.demoName ? slugify(body.demoName) : "");
      const demo = demoSlug ? await collections.demos.findOne({ slug: demoSlug }) : null;
      const scopeTarget = demo || body;
      if (!canManageCatalog(actor, scopeTarget, authOptions)) {
        json(res, 403, { error: "You do not have permission to ingest demos for this project" }, origin);
        return;
      }
      const job = createIntakeJob({
        ...body,
        submittedBy: actor?.email || actor?.id || body.submittedBy || "manual-intake",
        projectId: body.projectId || demo?.projectId || "",
        projectSlug: body.projectSlug || demo?.projectSlug || "",
        projectName: body.projectName || demo?.projectName || "",
      });
      const insertResult = await collections.ingestionJobs.insertOne(job);

      if (demo) {
        const resourceLinks = demo.resourceLinks || {};
        const resourceCoverage = demo.resourceCoverage || {};
        const launchTargetUpdates = (body.launchTargets || body.launchUrl)
          ? normalizeLaunchTargets({
              launchTargets: body.launchTargets,
              launchUrl: body.launchUrl ? String(body.launchUrl).trim() : "",
            })
          : {};
        await collections.demos.updateOne(
          { _id: demo._id },
          {
            $set: {
              resourceLinks: {
                ...resourceLinks,
                portalUrl: body.portalUrl || resourceLinks.portalUrl || null,
                solutionLibrary: appendUnique(resourceLinks.solutionLibrary, body.solutionLibraryUrl),
                github: appendUnique(resourceLinks.github, body.githubUrl),
                videos: appendUnique(resourceLinks.videos, body.videoUrl),
                powerpoints: appendUnique(resourceLinks.powerpoints, body.powerpointUrl),
                enablement: appendUnique(resourceLinks.enablement, body.enablementUrl),
              },
              resourceCoverage: {
                ...resourceCoverage,
                github: resourceCoverage.github || Boolean(body.githubUrl),
                video: resourceCoverage.video || Boolean(body.videoUrl),
                powerpoint: resourceCoverage.powerpoint || Boolean(body.powerpointUrl),
                logo: resourceCoverage.logo || Boolean(body.logoUrl),
                architectureDiagram: resourceCoverage.architectureDiagram || Boolean(body.architectureDiagramUrl),
                solutionLibrary: resourceCoverage.solutionLibrary || Boolean(body.solutionLibraryUrl),
              },
              ...launchTargetUpdates,
              updatedAt: new Date(),
            },
          },
        );
        await maybeCreateExternalAsset(demo._id, null, "logo", body.logoUrl, `${demo.name} logo`);
        await maybeCreateExternalAsset(demo._id, null, "architecture-diagram", body.architectureDiagramUrl, `${demo.name} architecture diagram`);
      }

      let previewPayload = null;
      if (parseBoolValue(body.autoPreviewSolutionLibrary, false) && body.solutionLibraryUrl) {
        const preview = await extractSolutionLibraryPreview(String(body.solutionLibraryUrl).trim());
        const persisted = await persistSolutionLibraryPreview(collections, {
          preview,
          url: String(body.solutionLibraryUrl).trim(),
          demoSlug: demo?.slug || demoSlug || null,
        });
        previewPayload = { preview, persisted };
        await collections.ingestionJobs.updateOne(
          { _id: insertResult.insertedId },
          {
            $set: {
              pipelineStatus: "previewed",
              updatedAt: new Date(),
              "steps.1.status": "completed",
              "steps.1.completedAt": new Date(),
              "steps.2.status": "completed",
              "steps.2.completedAt": new Date(),
            },
          },
        );
      }

      const createdJob = await collections.ingestionJobs.findOne({ _id: insertResult.insertedId });
      json(res, 201, { success: true, job: serializeDoc(createdJob), preview: serializeDoc(previewPayload) }, origin);
      return;
    }

    if (pathname === "/sherpa/catalog/ingestion/solution-library/preview" && req.method === "POST") {
      const actor = parseActor(req);
      const body = await readBody(req);
      const url = String(body.url || "").trim();
      const demoSlug = String(body.demoSlug || "").trim() || null;
      const persist = parseBoolValue(body.persist, false);
      if (!url) {
        json(res, 400, { error: "Missing required field url" }, origin);
        return;
      }
      const demo = demoSlug ? await collections.demos.findOne({ slug: demoSlug }) : null;
      if (!canManageCatalog(actor, demo || body, authOptions)) {
        json(res, 403, { error: "You do not have permission to preview or persist solution-library data for this project" }, origin);
        return;
      }
      const preview = await extractSolutionLibraryPreview(url);
      const payload = { success: true, preview };
      if (persist) {
        payload.persisted = await persistSolutionLibraryPreview(collections, { preview, url, demoSlug });
      }
      json(res, 200, payload, origin);
      return;
    }

    if (pathname === "/sherpa/copilot/brief" && req.method === "POST") {
      const body = await readBody(req);
      const brief = await buildCopilotBrief(collections, body || {});
      json(res, 200, {
        success: true,
        brief: serializeDoc(brief),
      }, origin);
      return;
    }

    if (pathname === "/sherpa/copilot/chat" && req.method === "POST") {
      const actor = parseActor(req);
      const body = await readBody(req);
      const demos = await collections.demos.find({}).toArray();
      const allJourneys = await collections.journeys.find({}).sort({ "governance.isRecommended": -1, updatedAt: -1, name: 1 }).toArray();
      const visibleJourneys = allJourneys.filter((journey) => canReadJourney(journey, actor));

      const acceptsSSE = String(req.headers.accept || "").includes("text/event-stream");
      const wantsStream = acceptsSSE && isBedrockConfigured();

      if (wantsStream) {
        // SSE streaming mode via agentic orchestrator
        const allowOrigin = origin && allowedOrigins.includes(origin) ? origin : allowedOrigins[0] || "*";
        res.writeHead(200, {
          "Content-Type": "text/event-stream; charset=utf-8",
          "Cache-Control": "no-cache",
          "Connection": "keep-alive",
          "Access-Control-Allow-Origin": allowOrigin,
          "Access-Control-Allow-Credentials": "true",
          "Access-Control-Allow-Headers": "Content-Type, x-sherpa-user-id, x-sherpa-user-name, x-sherpa-user-email, x-sherpa-user-roles, x-sherpa-project-owner-scopes, x-sherpa-project-owner-emails, x-sherpa-project-id, x-sherpa-project-slug, x-sherpa-project-name",
          "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
        });

        try {
          await runAgentChat({
            res,
            collections,
            demos,
            journeys: visibleJourneys,
            profile: body.profile || {},
            messages: Array.isArray(body.messages) ? body.messages : [],
          });
        } catch (agentError) {
          console.error("[sherpa-api] agent chat error, falling back", agentError);
          // Fallback: run heuristic engine and emit as structured_data
          try {
            const fallbackReply = await buildSherpaCopilotChatReply({
              collections,
              demos,
              journeys: visibleJourneys,
              profile: body.profile || {},
              messages: Array.isArray(body.messages) ? body.messages : [],
            });
            res.write(`event: text\ndata: ${JSON.stringify({ content: fallbackReply.assistantMessage || "Let me help you find the right demo." })}\n\n`);
            res.write(`event: structured_data\ndata: ${JSON.stringify(serializeDoc(fallbackReply))}\n\n`);
            res.write(`event: done\ndata: {}\n\n`);
          } catch (fallbackError) {
            console.error("[sherpa-api] fallback also failed", fallbackError);
            res.write(`event: error\ndata: ${JSON.stringify({ message: "An error occurred. Please try again." })}\n\n`);
            res.write(`event: done\ndata: {}\n\n`);
          }
        }
        res.end();
        return;
      }

      // JSON fallback mode (no Bedrock config or client doesn't accept SSE)
      const reply = await buildSherpaCopilotChatReply({
        collections,
        demos,
        journeys: visibleJourneys,
        profile: body.profile || {},
        messages: Array.isArray(body.messages) ? body.messages : [],
      });

      const hydratedRecommendations = reply.recommendations?.length
        ? await withDemoLogos(reply.recommendations.map((item) => item.demo), req)
        : [];
      const hydratedBySlug = new Map((hydratedRecommendations || []).map((demo) => [String(demo?.slug || ""), demo]));

      json(res, 200, {
        success: true,
        reply: serializeDoc({
          ...reply,
          recommendations: (reply.recommendations || []).map((item) => ({
            ...item,
            demo: hydratedBySlug.get(String(item?.demo?.slug || "")) || item.demo,
          })),
        }),
      }, origin);
      return;
    }

    if (pathname === "/sherpa/journey-assets" && req.method === "POST") {
      const actor = parseActor(req);
      const body = await readBody(req);
      const journeyId = String(body.journeyId || "").trim();
      const stepId = String(body.stepId || "").trim();
      const clipId = String(body.clipId || "").trim();
      const imageId = String(body.imageId || "").trim();
      const segmentId = String(body.segmentId || "").trim();
      const locale = String(body.locale || "").trim();
      const assetType = String(body.assetType || "").trim();
      if (!journeyId || !stepId || !["clip", "voice", "segment-voice", "step-poster", "step-frame"].includes(assetType)) {
        json(res, 400, { error: "Missing required asset fields" }, origin);
        return;
      }
      if (assetType === "clip" && !clipId) {
        json(res, 400, { error: "clipId is required for clip assets" }, origin);
        return;
      }
      if (assetType === "step-frame" && !imageId) {
        json(res, 400, { error: "imageId is required for step frame assets" }, origin);
        return;
      }
      if (assetType === "segment-voice" && (!segmentId || !locale)) {
        json(res, 400, { error: "segmentId and locale are required for segment voice assets" }, origin);
        return;
      }
      const existingJourney = await collections.journeys.findOne({ id: journeyId }, { projection: { id: 1, context: 1, governance: 1, createdBy: 1 } });
      if (existingJourney && !canEditJourney(existingJourney, actor, authOptions)) {
        json(res, 403, { error: "You do not have permission to upload assets for this journey" }, origin);
        return;
      }
      const asset = await storeJourneyAsset({
        actor,
        journeyId,
        stepId,
        clipId,
        imageId,
        segmentId,
        locale,
        assetType,
        fileName: String(body.fileName || "").trim(),
        mimeType: String(body.mimeType || "").trim(),
        dataUrl: String(body.dataUrl || ""),
      });
      json(res, 201, {
        success: true,
        asset: serializeDoc({
          ...asset,
          url: toAbsoluteAssetUrl(buildJourneyAssetPath(asset._id), req),
        }),
      }, origin);
      return;
    }

    const journeyAssetMatch = pathname.match(/^\/sherpa\/journey-assets\/([^/]+)\/content$/);
    if (journeyAssetMatch && req.method === "GET") {
      const assetId = decodeURIComponent(journeyAssetMatch[1]);
      if (!ObjectId.isValid(assetId)) {
        json(res, 404, { error: "Journey asset not found" }, origin);
        return;
      }
      const asset = await collections.journeyAssets.findOne({ _id: new ObjectId(assetId) });
      if (!asset?.gridFsFileId) {
        json(res, 404, { error: "Journey asset not found" }, origin);
        return;
      }
      res.writeHead(200, {
        "Content-Type": asset.mimeType || "application/octet-stream",
        ...(asset.sizeBytes ? { "Content-Length": String(asset.sizeBytes) } : {}),
        "Cache-Control": "public, max-age=31536000, immutable",
        "Access-Control-Allow-Origin": origin && allowedOrigins.includes(origin) ? origin : allowedOrigins[0] || "*",
      });
      journeyAssetBucket.openDownloadStream(asset.gridFsFileId).pipe(res);
      return;
    }

    if (pathname === "/sherpa/journeys" && req.method === "GET") {
      const actor = parseActor(req);
      const demoId = String(searchParams.get("demoId") || "").trim();
      const demoSlug = String(searchParams.get("demoSlug") || "").trim();
      const demoName = String(searchParams.get("demoName") || "").trim();
      const journeyQueryParts = [];
      if (demoId) {
        journeyQueryParts.push({ demoId });
        journeyQueryParts.push({ "context.demoId": demoId });
      }
      if (demoSlug) journeyQueryParts.push({ "context.demoSlug": demoSlug });
      if (demoName) journeyQueryParts.push({ "context.demoName": { $regex: `^${escapeRegex(demoName)}$`, $options: "i" } });
      const query = journeyQueryParts.length ? { $or: journeyQueryParts } : {};
      const items = await collections.journeys.find(query).sort({ "governance.isRecommended": -1, updatedAt: -1, name: 1 }).toArray();
      const visible = items.filter((journey) => canReadJourney(journey, actor));
      json(res, 200, {
        count: visible.length,
        items: serializeDoc(visible.map((journey) => hydrateJourneyMediaUrls(journey, req))),
      }, origin);
      return;
    }

    const journeyMatch = pathname.match(/^\/sherpa\/journeys\/([^/]+)$/);
    if (journeyMatch && req.method === "PUT") {
      const actor = parseActor(req);
      const journeyId = decodeURIComponent(journeyMatch[1]);
      const body = await readBody(req);
      const existing = await collections.journeys.findOne({ id: journeyId });
      if (existing && !canEditJourney(existing, actor, authOptions)) {
        json(res, 403, { error: "You do not have permission to edit this journey" }, origin);
        return;
      }
      const payload = sanitizeJourneyForActor({
        ...body,
        id: journeyId,
      }, actor, existing);
      const { createdAt, ...updatableJourney } = payload;
      await collections.journeys.updateOne(
        { id: journeyId },
        { $set: updatableJourney, $setOnInsert: { createdAt } },
        { upsert: true },
      );
      await removeUnreferencedJourneyAssets(journeyId, updatableJourney);
      const updated = await collections.journeys.findOne({ id: journeyId });
      json(res, 200, { success: true, journey: serializeDoc(hydrateJourneyMediaUrls(updated, req)) }, origin);
      return;
    }

    if (journeyMatch && req.method === "DELETE") {
      const actor = parseActor(req);
      const journeyId = decodeURIComponent(journeyMatch[1]);
      const existing = await collections.journeys.findOne({ id: journeyId });
      if (!existing) {
        json(res, 404, { error: "Journey not found" }, origin);
        return;
      }
      if (!canEditJourney(existing, actor, authOptions)) {
        json(res, 403, { error: "You do not have permission to delete this journey" }, origin);
        return;
      }
      const relatedAssets = await collections.journeyAssets.find({ journeyId }).toArray();
      await Promise.all(relatedAssets.map((asset) => removeJourneyAssetDocument(asset)));
      await collections.journeys.deleteOne({ id: journeyId });
      json(res, 200, { success: true }, origin);
      return;
    }

    json(res, 404, { error: "Not found" }, origin);
  } catch (error) {
    console.error("[sherpa-api] request failed", req.method, req.url, error);
    json(res, 500, { error: "Internal server error", details: String(error?.message || error) }, origin);
  }
});

const port = parseIntValue(env("PORT", "9091"), 9091, 1);
server.listen(port);
console.log(`Demo Sherpa API listening on http://localhost:${port}`);
