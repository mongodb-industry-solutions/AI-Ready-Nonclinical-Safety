# Demo Sherpa

Embeddable guided-demo package for multi-page React demos.

Sherpa gives a host app four main capabilities:

- a guided journey side panel
- a Studio to record and compose journeys
- a capture bridge to record user interactions across pages
- an opportunity planner to recommend the best demo or journey for a customer scenario
- an optional lightweight Node API for the editable demo catalog and ingestion pipeline

## Packaging Status

Sherpa can now be packaged for third-party reuse in two layers:

- the reusable React package in `dist/`
- the optional Node catalog API in `api/` plus its static assets in `public/`

That means a published tarball contains the same optional API scripts and docs referenced below, instead of shipping only the React bundle.

## What Sherpa Expects From The Host App

Sherpa is intentionally generic, but the host app must provide a few things:

- `react`, `react-dom`, and `react-router-dom`
- a router context around Sherpa components
- a route metadata resolver for host-specific talk tracks
- optional backend endpoints for TTS, transcription, and narration preparation

Sherpa does not own your demo routes or your business data model. It sits on top of your app and records, replays, and recommends journeys.

## Third-Party Integration Checklist

If another developer wants to embed Sherpa into a different demo, these are the required steps:

1. Install `demo-sherpa` plus the peer dependencies expected by the host app.
2. Render `DemoSherpaCaptureBridge` once inside the app router.
3. Wrap `DemoSherpaGuide` in a thin host-owned component that passes branding, route context, and optional catalog/API settings.
4. Provide a `routeContextResolver(pathname)` function that returns presenter-facing talk tracks for each route.
5. If you want host-owned AI services, expose `POST /api/journey/tts`, `POST /api/journey/transcribe`, and optionally `POST /api/journey/translate`.
6. If you want Sherpa-hosted AI services instead, run the optional Sherpa catalog API and pass `catalogApiBaseUrl`.
7. If you want shared journeys, editable catalog data, planner search, and copilot briefing, also pass a `currentUser` with that shared Sherpa API.

If a host app skips steps 5 through 7, Sherpa still works in local/browser-only mode, but with fewer AI and shared-catalog features.

## Host Contract

Sherpa now treats the host integration as a small contract, not just a loose set of props. A healthy host setup should provide:

- scoped `demoContext` with both project and demo identity
- route-aware notes for the current page through `routeContextResolver(pathname)` or page overrides
- a valid `ttsEndpoint` or Sherpa-hosted voice service if AI voice is enabled
- a valid `transcribeEndpoint` or Sherpa-hosted transcription service if automatic clip transcription is enabled
- a valid `catalogApiBaseUrl` if shared sync/catalog features are enabled
- `currentUser` when shared sync or governance features are enabled

Studio surfaces these checks directly in its diagnostics and readiness checklist as `Host contract`.

## Install

For local sibling-repo verification that matches third-party consumption:

```sh
cd ../demo-sherpa
npm install
npm pack --silent
```

Then in the host app:

```json
{
  "dependencies": {
    "demo-sherpa": "file:../../demo-sherpa/demo-sherpa-0.1.0.tgz"
  }
}
```

For a published/shared package later, replace the tarball path with a versioned package reference or GitHub release artifact.

Peer dependencies expected from the host app:

- `react`
- `react-dom`
- `react-router-dom`

When consuming Sherpa from a live local symlink instead of a packed tarball, make sure those three peer imports resolve from the same React runtime the host app already uses. In Next.js, the safest path is to avoid custom React aliases entirely and consume Sherpa as a packed tarball or published package so Next can keep control of React resolution. A clean dev-server restart is often required after switching install modes.

## Tiny Example

If you want a minimal runnable host instead of only README snippets, start with:

- `examples/next-app-router-hello-world`

That example shows:

- a thin Sherpa wrapper owned by the host app
- a small `BrowserRouter` bridge for Next.js App Router
- an intentionally empty page that tells the user to click the Sherpa button
- browser-local mode with no backend dependency

Read `examples/next-app-router-hello-world/README.md` for the step-by-step setup.

## Exports

- `DemoSherpaGuide`
- `DemoSherpaCaptureBridge`
- `JourneyStudioWorkbench`
- `OpportunityPlanner`
- `createSherpaCatalogClient`
- taxonomy helpers through `demo-sherpa/taxonomy`

## Minimal Embed

Sherpa components must render inside `react-router-dom` context.

```jsx
import { BrowserRouter } from "react-router-dom";
import { DemoSherpaGuide, DemoSherpaCaptureBridge } from "demo-sherpa";

const resolveRouteContext = (pathname) => ({
  title: "Demo Context",
  talkTrack: ["Explain what this page proves."],
  journeySteps: ["Show the main workflow."],
  whyMongo: ["Connect the page to the MongoDB value story."],
});

export default function AppShell() {
  return (
    <BrowserRouter>
      <DemoSherpaCaptureBridge />
      <DemoSherpaGuide
        enabled
        title="Demo Sherpa"
        studioTitle="Demo Sherpa Studio"
        routeContextResolver={resolveRouteContext}
        ttsEndpoint="/api/journey/tts"
        transcribeEndpoint="/api/journey/transcribe"
        translateEndpoint="/api/journey/translate"
        defaultPosition={{ right: 16, top: 16 }}
      />
      {/* your normal app routes/components */}
    </BrowserRouter>
  );
}
```

This is enough for:

- guided playback
- local capture
- local journey storage in browser storage

## Recommended Host Wrapper

In practice, most apps should keep Sherpa behind a thin integration wrapper so branding, route talk tracks, and endpoint wiring stay local to the host app.

```jsx
import React from "react";
import { DemoSherpaGuide, DemoSherpaCaptureBridge } from "demo-sherpa";
import { getRouteTalkTrackBundle } from "./talkTracks";

export const DemoSherpaBridge = () => <DemoSherpaCaptureBridge />;

export const DemoSherpa = () => (
  <DemoSherpaGuide
    enabled={process.env.REACT_APP_SHERPA_ENABLED !== "false"}
    title={process.env.REACT_APP_SHERPA_TITLE || "Demo Sherpa"}
    studioTitle={process.env.REACT_APP_SHERPA_STUDIO_TITLE || "Demo Sherpa Studio"}
    routeContextResolver={getRouteTalkTrackBundle}
    ttsEndpoint="/api/journey/tts"
    transcribeEndpoint="/api/journey/transcribe"
    translateEndpoint="/api/journey/translate"
    playerLogoSrc={process.env.REACT_APP_SHERPA_PLAYER_LOGO_URL || ""}
    assistantLogoSrc={process.env.REACT_APP_SHERPA_ASSISTANT_LOGO_URL || ""}
    catalogApiBaseUrl={process.env.REACT_APP_SHERPA_CATALOG_API_URL}
    currentUser={{
      id: process.env.REACT_APP_USER_ID,
      name: process.env.REACT_APP_USER_NAME,
      email: process.env.REACT_APP_USER_EMAIL,
      roles: (process.env.REACT_APP_SHERPA_ROLES || "")
        .split(",")
        .map((value) => value.trim())
        .filter(Boolean),
    }}
    projectOwnerEmails={(process.env.REACT_APP_SHERPA_PROJECT_OWNER_EMAILS || "")
      .split(",")
      .map((value) => value.trim())
      .filter(Boolean)}
    overviewSections={[
      { id: "narration", label: "Narration" },
      { id: "step-outline", label: "Walkthrough" },
      { id: "customer-outcomes", label: "Customer outcomes", placeholder: "<ul><li>What should land with the buyer?</li></ul>", renderMode: "list" },
    ]}
    defaultPosition={{
      right: Number(process.env.REACT_APP_SHERPA_DEFAULT_RIGHT || 16),
      top: Number(process.env.REACT_APP_SHERPA_DEFAULT_TOP || 16),
    }}
    demoContext={{
      projectSlug: process.env.REACT_APP_SHERPA_PROJECT_SLUG || "ist-demos",
      projectName: process.env.REACT_APP_SHERPA_PROJECT_NAME || "IST Demos",
      demoSlug: process.env.REACT_APP_SHERPA_DEMO_SLUG || "leafy-hospital",
      demoName: process.env.REACT_APP_SHERPA_DEMO_NAME || "Leafy Hospital",
      demoDescription: "One-line summary of what this demo proves.",
    }}
  />
);
```

Recommended host-side `.env.example` entries when using the shared catalog API:

```dotenv
REACT_APP_SHERPA_CATALOG_API_URL=http://localhost:9091
REACT_APP_SHERPA_ENABLED=true
REACT_APP_SHERPA_TITLE=Demo Sherpa
REACT_APP_SHERPA_STUDIO_TITLE=Demo Sherpa Studio
REACT_APP_SHERPA_PLAYER_LOGO_URL=
REACT_APP_SHERPA_ASSISTANT_LOGO_URL=
REACT_APP_SHERPA_DEFAULT_RIGHT=16
REACT_APP_SHERPA_DEFAULT_TOP=16
REACT_APP_SHERPA_PROJECT_SLUG=ist-demos
REACT_APP_SHERPA_PROJECT_NAME=IST Demos
REACT_APP_SHERPA_DEMO_SLUG=leafy-hospital
REACT_APP_SHERPA_DEMO_NAME=Leafy Hospital
REACT_APP_USER_ID=
REACT_APP_USER_NAME=
REACT_APP_USER_EMAIL=
REACT_APP_SHERPA_ROLES=
REACT_APP_SHERPA_PROJECT_OWNER_EMAILS=
```

`currentUser.email` is the most important identity field to pass from the host. If `id` is omitted, Sherpa now keeps the email/name/roles and fills in a stable browser-scoped fallback id underneath.

`currentUser` does not need to come only from `.env`. In most host apps it is better to resolve it from the live session, app state, or `localStorage`, then pass the current identity into Sherpa from the integration wrapper.

Recommended permission model:

- global admins are configured in the Sherpa API via `SHERPA_ADMIN_EMAILS`
- `projectOwnerEmails` comes from the host integration for the current project/demo
- `user` or no special role can play any journey and create their own journeys, but cannot manage catalog data or journey governance

Typical setup:

- API `.env`: `SHERPA_ADMIN_EMAILS=alice@mongodb.com,bob@mongodb.com`
- host wrapper: `projectOwnerEmails={["owner1@mongodb.com", "owner2@mongodb.com"]}`

`playerLogoSrc` controls the logo in the guide/player header. `assistantLogoSrc` controls the icon in Sherpa Assistant. If those props are omitted, Sherpa falls back to its bundled Leafy-style default branding. `brandIconSrc` still works as a backward-compatible alias for the player logo.

Typography follows Sherpa's default Leafy-style system stack unless the host overrides `--sherpa-font-family`.

`enabled` lets the host app turn the guide on or off entirely. `defaultPosition` only sets the first position; after the presenter drags the panel, the saved browser position wins.

## Draft Persistence Modes

Sherpa now distinguishes draft state more explicitly in Studio:

- `Local draft only`: browser-only authoring, no shared catalog configured
- `Local draft pending sync`: shared catalog exists, but local edits are newer than the last remote sync
- `Syncing draft`: Sherpa is uploading the latest local changes
- `Remote synced`: local and remote versions match
- `Sync attention`: the last remote sync failed and needs review

Recovery snapshots remain local rollback points for safer editing, even when shared sync is enabled.

When shared catalog is configured, Sherpa now treats the shared catalog as the authoritative copy and the browser state as a working draft cache plus recovery layer. That is not full remote-first persistence yet, but it gives authors and operators a clearer mental model for sync behavior.

## Deployment Modes

Studio now reports Sherpa's current deployment mode directly:

- `Browser local`
- `Voice-enabled local`
- `Shared catalog`
- `Service-backed`

That mode is inferred from the configured host contract, especially `ttsEndpoint` and `catalogApiBaseUrl`.

### Build-Safe Integration Patterns

There are two valid ways to integrate Sherpa into a host app:

1. install `demo-sherpa` as a normal dependency that is available during the host build
2. treat Sherpa as optional and load it only at runtime from a hosted module URL

The first approach is best when the host app and Sherpa are versioned and built together.

The second approach is safer for isolated CI/CD systems such as Kanopy when the host app might be built without the sibling Sherpa package present. In that setup:

- keep the host wrapper fail-open
- if the Sherpa module URL is missing or the module throws, render nothing and continue loading the host app
- do not let a missing Sherpa package break the host build

Example host wrapper for optional runtime loading:

```jsx
import React, { useEffect, useState } from "react";

const sherpaModuleUrl = process.env.REACT_APP_SHERPA_MODULE_URL || "";

const loadSherpaModule = () => {
  if (!sherpaModuleUrl) return Promise.resolve(null);
  return import(/* webpackIgnore: true */ sherpaModuleUrl).catch((error) => {
    console.error("Demo Sherpa failed to load. Continuing without it.", error);
    return null;
  });
};

export function DemoSherpaBridge() {
  const [module, setModule] = useState(null);

  useEffect(() => {
    let cancelled = false;
    loadSherpaModule().then((loaded) => {
      if (!cancelled) setModule(loaded);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  if (!module?.DemoSherpaCaptureBridge) return null;
  const CaptureBridge = module.DemoSherpaCaptureBridge;
  return <CaptureBridge />;
}
```

Recommended host env for the optional-runtime pattern:

```dotenv
REACT_APP_SHERPA_ENABLED=true
REACT_APP_SHERPA_MODULE_URL=
```

If `REACT_APP_SHERPA_MODULE_URL` is empty, the host app should simply run without Sherpa.

## Complete Host Integration

For a full integration, the host app usually needs exactly two runtime mount points:

1. a single `DemoSherpaCaptureBridge` mounted inside the router so page actions can be recorded
2. a single `DemoSherpaGuide` mounted near the app shell so the guide stays available across routes

Typical structure:

```jsx
import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import DemoSherpa, { DemoSherpaBridge } from "./integrations/demoSherpa/DemoSherpa";
import HomePage from "./pages/HomePage";
import SearchPage from "./pages/SearchPage";

export default function App() {
  return (
    <BrowserRouter>
      <DemoSherpaBridge />
      <DemoSherpa />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/search" element={<SearchPage />} />
      </Routes>
    </BrowserRouter>
  );
}
```

This keeps Sherpa integration thin and predictable:

- the host app owns routes, layout, business logic, and API endpoints
- the host wrapper owns Sherpa props and branding
- the `demo-sherpa` package owns recording, playback, Studio, planner, and catalog client behavior

Sherpa now ships browser-side CSS injection modules in `dist/`, so the host does not need a special raw-CSS loader just to consume the package.

### Next.js And Internal-View Apps

If the host app is not already driven by `react-router-dom` routes, do not rewrite the whole app just for Sherpa. A thin compatibility layer is enough.

The pattern used in `HealthcareDataLab` is:

1. keep the host app's own internal view state
2. expose Sherpa-safe browser paths such as `/workspace/strategies` and `/workspace/learn/<module>`
3. mount a small `BrowserRouter` bridge that syncs host view state with those paths
4. add a catch-all page so refreshes and direct links keep working

High-level example:

```jsx
"use client";

import React from "react";
import { BrowserRouter, useLocation, useNavigate } from "react-router-dom";

const viewToPath = (view) => {
  if (view === "home") return "/";
  if (view.startsWith("learn:")) return `/workspace/learn/${encodeURIComponent(view.slice(6))}`;
  return `/workspace/${encodeURIComponent(view)}`;
};

const pathToView = (pathname) => {
  if (pathname === "/") return "home";
  const parts = pathname.split("/").filter(Boolean);
  if (parts[0] !== "workspace") return "home";
  if (parts[1] === "learn") return parts[2] ? `learn:${decodeURIComponent(parts[2])}` : "learn";
  return decodeURIComponent(parts[1] || "home");
};

function SherpaRouteSync({ currentView, onNavigate, children }) {
  const location = useLocation();
  const navigate = useNavigate();

  React.useEffect(() => {
    const nextView = pathToView(location.pathname);
    if (nextView !== currentView) onNavigate(nextView);
  }, [location.pathname, currentView, onNavigate]);

  React.useEffect(() => {
    const targetPath = viewToPath(currentView);
    if (location.pathname !== targetPath) navigate(targetPath);
  }, [currentView, location.pathname, navigate]);

  return children;
}

export function SherpaHostRouter({ currentView, onNavigate, children }) {
  return (
    <BrowserRouter>
      <SherpaRouteSync currentView={currentView} onNavigate={onNavigate}>
        {children}
      </SherpaRouteSync>
    </BrowserRouter>
  );
}
```

On the Next.js side, map those browser paths back to the shared app shell with a catch-all page, for example `app/workspace/[[...slug]]/page.js`.

### Recommended File Split

For a clean integration boundary in the host app:

- `src/integrations/demoSherpa/DemoSherpa.js`: wrapper around package exports
- `src/content/talkTracks.js`: host-specific route narration and presenter guidance
- `src/App.js`: mount the wrapper once

That is the pattern used in Leafy Hospital, adapted in Healthcare Data Lab, and recommended for other demos.

### Detached Guide Window

If your host app wants the guide in a separate browser window while preserving routing context, mount the same wrapper in a dedicated app-shell branch and pass `externalWindowMode`.

Example:

```jsx
const isSherpaWindow =
  typeof window !== "undefined"
  && new URLSearchParams(window.location.search).get("journeyGuideWindow") === "1";

if (isSherpaWindow) {
  return (
    <BrowserRouter>
      <DemoSherpaBridge />
      <DemoSherpa externalWindowMode />
    </BrowserRouter>
  );
}
```

This mode is optional. If you do not support detached-window presentation, a normal in-app mount is enough.

## Route Context Contract

`routeContextResolver(pathname)` should return an object like:

```js
{
  title: "Screening List",
  talkTrack: ["Explain the page in presenter language."],
  journeySteps: ["Which user actions matter on this page."],
  whyMongo: ["Why this page demonstrates value."],
}
```

Sherpa normalizes missing fields, so you do not need to populate every field for every route.

The player treats this route context as the default source for the `Narration`, `Walkthrough`, and `Why Mongo` panels. Step-level notes entered in Studio only override the matching panel for that specific step, so you can keep reusable page context in the host app and add step-specific exceptions only where needed.

Recommended host implementation:

- keep route talk tracks in one file instead of scattering them across pages
- return stable route metadata for every meaningful presenter route
- include concise `talkTrack`, `journeySteps`, and `whyMongo` arrays rather than page-specific UI state

## Host Responsibilities

To avoid leaking Sherpa internals into the host app, the host should only own:

- where Sherpa mounts
- what route talk tracks say
- what branding to show
- which endpoints and environment variables to pass
- which demo identity and current user to supply

The host app should not read or mutate Sherpa local-storage keys, journey persistence formats, replay internals, or Studio state directly.

## Optional Backend Endpoints

Sherpa works without backend AI services, but some features improve if these endpoints exist:

- `POST /api/journey/tts`
  Purpose: synthesize talk track audio
- `POST /api/journey/transcribe`
  Purpose: transcribe recorded audio clips
  Contract:
  - accepts multipart `file`
  - should honor optional `sourceLanguage` and `sourceLocale` fields when the host knows the source recording language
  - should return transcript text plus timing metadata when available
- `POST /api/journey/translate`
  Purpose: refine or translate narration text for AI voice generation

If these endpoints are missing:

- playback can still use browser speech synthesis
- Studio recording still works, but automatic transcription will not

Sherpa can also run with its own boxed API in [api/README.md](./api/README.md). That optional API owns:

- the editable MongoDB catalog in `demo-sherpa`
- Sherpa-hosted `tts`, `transcribe`, and `translate` services when the AWS / Bedrock variables are configured
- streamed Sherpa copilot chat backed by Amazon Bedrock
- portal bootstrap for the current 51 demos
- ingestion jobs for GitHub, video, PowerPoint, and Solution Library links
- Solution Library preview extraction

When `catalogApiBaseUrl` is present, Sherpa now checks `GET /sherpa/service/capabilities` and can automatically prefer:

- `/sherpa/services/tts`
- `/sherpa/services/transcribe`
- `/sherpa/services/translate`

Host-owned `ttsEndpoint`, `transcribeEndpoint`, and `translateEndpoint` remain explicit overrides.

This keeps the shared Sherpa catalog API out of any one host app such as Leafy Hospital, while staying in the same JavaScript project instead of introducing a separate Python stack.

Sherpa also exports `createSherpaCatalogClient(...)` so host apps can talk to the Sherpa catalog API without rewriting fetch helpers.

For the next productization phase, the market-readiness roadmap and execution backlog are documented in:

- [docs/market-readiness-roadmap.md](./docs/market-readiness-roadmap.md)
- [docs/market-readiness-backlog.md](./docs/market-readiness-backlog.md)
- [docs/host-integration-guide.md](./docs/host-integration-guide.md)
- [docs/launch-readiness-checklist.md](./docs/launch-readiness-checklist.md)

Recommended non-React imports:

```js
import { createSherpaCatalogClient } from "demo-sherpa/catalog-api";
import { CATALOG_TAXONOMY } from "demo-sherpa/taxonomy";
```

## Data Model

Sherpa stores journey data locally in browser storage today.

Each journey can include:

- demo metadata: `demoName`, `demoDescription`, `industries`, `products`, `businessCases`, `targetAudiences`, `useCases`, `valueHighlights`
- guidance metadata: presenter notes and generated journey guidance
- step metadata: `primaryLanguage`, `recordedLanguages`, estimated timing, manual switch instructions
- recorded assets: events, mic clips, talk tracks, synthesized voice

This supports both:

- fully guided recorded journeys
- recommendation-only demo matching when no journey has been recorded yet

For the next phase, Sherpa should move to a MongoDB-backed editable catalog. The proposed catalog structure, ingestion flow, taxonomy model, and vector-search strategy are documented in [docs/catalog-model.md](./docs/catalog-model.md). A first controlled-vocabulary seed is also exposed from `src/catalogTaxonomy.js` for industries, use cases, products, MongoDB capabilities, audiences, source types, and asset types.

## Planner

`OpportunityPlanner` recommends the best journey or demo candidate from the stored Sherpa data using:

- industry
- product
- business case
- audience
- use case
- free-text opportunity summary
- time budget

Most recommendations will usually point to a single demo. If no journey is recorded, Sherpa can still recommend the demo without pretending it can guide it.

## Manual Cross-Demo Handoffs

Sherpa does not automatically jump across demos when a presenter needs to open another app, tab, or environment.

Instead, mark a step as requiring manual advance and add presenter instructions. During playback Sherpa pauses and waits for the user to continue.

## Build

```sh
npm run build
```

This writes transpiled output to `dist/`.

## Optional Catalog API

Run the bundled API when you want shared demo metadata, shared journeys, semantic catalog search, planner recommendations, or the copilot briefing flow.

```sh
cp api/.env.example api/.env
npm install
npm run api
```

The default base URL is `http://localhost:9091`.

The most important API variables are:

- `MONGODB_CONNECTION_STRING`: required for every API mode
- `VOYAGE_API_KEY`: required for embeddings and semantic search
- `AWS_REGION`: required for Bedrock, Polly, and Transcribe requests
- `AWS_PROFILE` or `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY`: Bedrock and AWS AI credentials
- `AWS_BUCKET_NAME` or `SHERPA_MEDIA_BUCKET_NAME`: required for Sherpa-hosted transcription jobs
- `BEDROCK_DEFAULT_MODEL`: primary model for streamed Sherpa copilot chat
- `SHERPA_ALLOWED_ORIGINS`: CORS allowlist for host demos; include the active local dev origin such as `http://localhost:3000` or `http://localhost:3001`

Every supported variable now appears in [`api/.env.example`](./api/.env.example).

## API Scripts

```sh
npm run api
npm run api:bootstrap
npm run api:smoke
```

## Typical Shared-Repo Workflow

Recommended team workflow:

1. Develop Sherpa in this repo.
2. Build it locally with `npm run build`.
3. Consume it from demos through a local `file:` dependency during development.
4. Publish versioned releases later for broader reuse.

That keeps Sherpa shared and reusable while allowing each demo to keep only a thin host-specific wrapper.
