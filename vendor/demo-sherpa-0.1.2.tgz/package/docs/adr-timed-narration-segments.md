# ADR: Timed Narration Segments

## Status
Accepted

## Context
Sherpa originally captured narration mainly as one or more recorded step clips plus a single step-level talk track. That worked for original audio playback, but it caused drift when replay depended on synthesized narration or future translation flows:

- text-only transcription removed meaningful pauses
- a whole step could be synthesized as one long audio unit
- exact total-duration matching pushed TTS into unnatural pacing

Sherpa already had partial support for `narrationSegments`, manual timing markers, and checkpoint-aware playback. The missing piece was reliable timing-rich ASR data and a stronger segmentation pipeline.

## Decision
Sherpa treats narration as an ordered timeline of:

- `speech` segments
- `silence` segments

Each speech segment keeps:

- source text
- source start/end timing
- target duration
- pause after
- optional checkpoint key and checkpoint condition

Each silence segment keeps:

- start/end timing
- explicit duration

Automatic segment generation now prefers:

1. manual timing markers
2. checkpoint anchors
3. detected pauses from ASR timings
4. sentence heuristics as fallback

Playback remains state-driven:

- original recorded clips still work
- synthesized playback iterates segment-by-segment
- explicit silence is preserved
- checkpoint failures pause playback instead of continuing blindly
- before TTS, each speech segment can be LLM-refined for spoken delivery and translated/adapted toward the segment timing target

## Consequences

### Positive
- natural pacing no longer depends on one monolithic synthesized clip
- explicit pauses survive transcription and can be edited
- future translation can operate per speech segment instead of per full step
- legacy journeys still play through original clip mode
- translated or same-language synthesized narration can be shortened or expanded by the LLM before speech generation instead of relying only on playback-rate stretching

### Tradeoffs
- rich ASR timing metadata increases payload size
- local persistence needs fallbacks when timing arrays become too large
- timing is approximate by design; exact dubbing remains an anti-goal

## Migration stance
No explicit migration workflow is required for older journeys right now. New or re-recorded journeys automatically benefit from the improved ASR and segmentation path, while legacy clip playback remains available.
