# Catalog Manager Phase 1 Spec

## Goal

Turn Catalog Manager from a browseable demo catalog into the authoritative catalog operations console behind Sherpa.

The product goal is:

- issues first
- canonical records second
- portal preview third

The operator should feel:

"I can trust this data, fix problems quickly, and know exactly what will appear downstream."

## Current Repo Reality

This spec is based on the current implementation in:

- `src/components/CatalogWorkspace.js`
- `src/components/OpportunityPlanner.js`
- `src/modules/catalogApi.js`
- `api/lib/catalogServices.mjs`
- `api/server.mjs`
- `docs/catalog-model.md`

What exists already:

- a catalog API with health, list, detail, update, create, ingestion preview, semantic search
- a front-end `CatalogWorkspace` with:
  - sidebar list
  - demo detail page
  - simple add-demo ingest flow
- a copilot/assistant surface in `OpportunityPlanner`
- a canonical `demos` collection plus linked `demo_sources`, `demo_assets`, `demo_chunks`, `journeys`

What is still missing:

- issue-driven ops view
- source-of-truth enforcement by field
- typed operational statuses
- reconciliation workflow
- canonical logo governance
- environment-aware launch targets
- publish safety checks
- audit and override reasoning

## Phase 1 Outcome

Phase 1 should ship a trustworthy operations console, not a prettier gallery.

Phase 1 delivers:

- issue-driven table as default Catalog Manager home
- separate `catalogStatus`, `availabilityStatus`, and `healthStatus`
- field authority rules
- logo and launch target warnings
- canonical/master diff panel
- archive/deprecate instead of destructive delete language
- portal preview as a secondary view

## Information Architecture

### New primary views

Catalog Manager should move from:

- `Catalog`
- `Add Demo`

to:

- `Operations`
- `Preview`
- `Ingest`

### Operations

Default landing view.

Primary unit is the canonical demo record in a table, with issue counts and reconciliation state.

Columns:

- Name
- Canonical match
- Catalog status
- Availability
- Health
- Logo
- Launch target
- Owner
- Sources
- Journeys
- Last sync
- Issues

Filters:

- Needs review
- Unmatched source
- Availability conflict
- Logo mismatch
- Missing launch target
- Localhost URL
- Duplicate candidate
- Partner-built
- No journeys
- Draft
- Deprecated
- Archived

Bulk actions:

- Accept master logo
- Sync availability from master
- Assign owner
- Publish
- Archive
- Resolve match

### Preview

Portal-style card rendering.

Purpose:

- show exactly how the demo will appear downstream
- validate logo, labels, availability badge, and summary copy

This keeps the current card language, but only as preview.

### Ingest

Replace direct create flow with reconciliation-first flow:

1. Capture source
2. Attempt match
3. Review diffs
4. Attach to existing demo, create new canonical demo, or mark as supporting source

## Data Model Changes

### 1. Split operational statuses

Current code mixes `status` and `availability`.

Phase 1 should introduce:

- `catalogStatus`
  - `draft`
  - `published`
  - `deprecated`
  - `archived`
- `availabilityStatus`
  - `available`
  - `currently-unavailable`
- `healthStatus`
  - `healthy`
  - `warning`
  - `broken`

Transitional rule:

- keep reading existing `status` and `availability`
- derive new fields where absent
- write new fields on all updates

### 2. Field authority rules

Add an explicit authority model for canonical fields.

Authoritative sources by field:

- master catalog / portal
  - canonical name
  - slug
  - availability
  - partner-built flag
  - canonical logo asset
  - primary launch target
  - display badges
- external sources
  - summary candidates
  - GitHub URL
  - supporting links
  - notes candidates
- Sherpa local/manual
  - journeys
  - owner/team
  - aliases
  - readiness notes
  - review status
  - override reasons

New metadata fields on `demos`:

- `fieldAuthority`
- `overrideReasons`
- `lastMasterSyncAt`
- `lastManualOverrideAt`
- `lastManualOverrideBy`

### 3. Canonical logo handling

Current model already anticipates `logoAssetId`, but current UI still edits `logoUrl`.

Phase 1 rules:

- `logoAssetId` becomes canonical
- `logoUrl` becomes imported candidate only
- if a master match exists, master logo wins by default
- manual override requires reason
- localhost logo URLs always raise a warning

New computed issue types:

- `missing-logo-asset`
- `logo-mismatch`
- `localhost-logo-url`

### 4. Launch targets by environment

Replace single `launchUrl` as the operational truth with:

- `launchTargets.local`
- `launchTargets.staging`
- `launchTargets.production`
- `launchTargets.defaultEnvironment`

Transitional compatibility:

- preserve `launchUrl`
- derive it from `launchTargets[defaultEnvironment]` when available

New computed issue types:

- `missing-launch-target`
- `localhost-launch-url`
- `broken-launch-target`

### 5. Taxonomy normalization

Current `portal.labels` is overloaded.

Phase 1 should separate:

- `industries`
- `solutionTags`
- `capabilities`
- `partnerBadges`
- `portalDisplayBadges`

`portal.primaryLabel` should become a display choice, not semantic truth.

## Reconciliation Model

### Source ingestion should not equal demo creation

Current `CatalogWorkspace` ingest flow creates a demo too early.

Phase 1 must change the mental model to:

- ingest source
- try to match canonical demo
- show confidence and diffs
- let curator decide

Decision paths:

- attach to existing demo
- create new canonical demo
- mark as supporting source
- merge/alias with another record

### Match confidence bands

Add three bands:

- auto-match
- review-required
- create-candidate

Matching signals:

- normalized slug
- name similarity
- launch URL host/path
- aliases
- source overlap
- logo similarity as weak hint only

## Front-End Changes

## `src/components/CatalogWorkspace.js`

Phase 1 refactor target:

- replace current sidebar list + hero detail default with `Operations` table
- keep current card-like detail data, but move it behind an `open record` pattern
- keep current preview rendering logic for `Preview`

### New state shape

Add:

- `activeTab = "operations" | "preview" | "ingest"`
- `issueFilters`
- `selectedRows`
- `opsSort`
- `selectedIssueType`
- `recordDrawerOpen`

### New computed issue model

Add a front-end issue builder while backend catches up.

Derive issues from current data:

- unavailable
- localhost launch URL
- localhost logo URL
- missing logo asset
- no journeys
- no launch URL
- portal/canonical label mismatch
- source count zero

### Detail page restructure

Top section should become `Canonical Record`:

- name
- slug
- master catalog id
- catalog status
- availability status
- health status
- partner-built
- canonical logo asset
- launch targets
- owner/team
- last sync
- last override

Tabs inside detail:

- `Sources`
- `Assets`
- `Metadata`
- `Journeys`
- `Audit`
- `Portal Preview`

### Rename buttons

Change labels:

- `Catalog` -> `Operations`
- `Add Demo` -> `Ingest Source`
- `Save Changes` -> `Publish Metadata`
- `Launch Demo` -> `Open Live Demo`
- `Edit` -> `Edit Canonical Record`

Avoid `Delete` in Phase 1 UI. Use:

- `Archive`
- `Deprecate`

## API Changes

Current API surface is a strong base and should be extended instead of replaced.

### Existing routes to keep

- `GET /sherpa/catalog/health`
- `GET /sherpa/catalog/demos`
- `GET /sherpa/catalog/demos/:slug`
- `PUT /sherpa/catalog/demos/:slug`
- `POST /sherpa/catalog/demos`
- `POST /sherpa/catalog/ingestion/solution-library/preview`

### New routes for Phase 1

- `GET /sherpa/catalog/issues`
- `POST /sherpa/catalog/reconcile/match`
- `POST /sherpa/catalog/reconcile/resolve`
- `POST /sherpa/catalog/demos/:slug/publish`
- `POST /sherpa/catalog/demos/:slug/archive`
- `POST /sherpa/catalog/demos/:slug/deprecate`
- `POST /sherpa/catalog/demos/:slug/sync-master`

### Response shape additions

For demo summary rows:

- `catalogStatus`
- `availabilityStatus`
- `healthStatus`
- `issueCount`
- `issues`
- `sourceCount`
- `journeyCount`
- `owner`
- `lastSyncAt`
- `canonicalMatch`
- `logo`
- `launchTargets`

For detail response:

- `audit`
- `authority`
- `diffs`
- `masterRecord`
- `overrideHistory`

## Backend Service Changes

## `api/lib/catalogServices.mjs`

Phase 1 tasks:

- extend `buildDemoDocument` and `buildManualDemoDocument`
- stop defaulting everything into a browseable-shape-only payload
- add derived issue computation
- add source authority helpers
- add launch target normalization
- add logo asset preference rules

New helper areas:

- `computeDemoIssues(demo, linkedSources, assets, journeys)`
- `normalizeLaunchTargets(payload)`
- `resolveCanonicalLogo(demo, masterSource, assets)`
- `deriveHealthStatus(demo)`
- `buildAuthoritySummary(demo, sources)`

### Transitional migration logic

On read:

- map old fields into new operational fields if missing

On write:

- preserve backwards-compatible fields
- populate new operational fields

## `api/server.mjs`

Phase 1 tasks:

- expose issue-list endpoint
- support archive/deprecate/publish actions
- add reconciliation endpoints
- include issue summaries in demo list responses
- expose warning metadata for localhost URLs and missing assets

## Assistant Review

Assistant should stay downstream of trusted catalog data.

Current Assistant surface:

- `src/components/OpportunityPlanner.js`
- `api/lib/copilotChat.mjs`

### Current strength

Assistant already produces recommendation cards with:

- demo
- confidence
- rationale
- journey summary
- launch/open actions

### Current weakness

It still trusts catalog records that are not operationally governed enough.

That means the Assistant can recommend records that are:

- available-looking but not actually safe to launch
- logo-inconsistent
- taxonomy-noisy
- localhost-bound
- missing authoritative match

### Phase 1 Assistant dependency

Once Catalog Manager emits trusted issue and status fields, Assistant should filter and rank by them.

Add ranking penalties for:

- `healthStatus !== healthy`
- `availabilityStatus !== available`
- `catalogStatus !== published`
- localhost launch targets
- missing canonical logo asset
- unresolved reconciliation state

Add visible warnings to recommendation cards:

- `Needs review`
- `Unavailable`
- `Localhost target`
- `No guided journey`

Assistant should default to recommending only:

- `published`
- `available`
- `healthy`

unless the user explicitly asks to include drafts or edge cases.

## Immediate Repo Tasks

### Phase 1A

- Add the new operational fields to demo documents and update sanitization.
- Compute issue summaries in list/detail API responses.
- Replace `CatalogWorkspace` default home with an operations table.
- Move current card/detail rendering into `Preview`.

### Phase 1B

- Add archive/deprecate/publish actions.
- Add localhost URL and logo warnings.
- Promote `logoAssetId` ahead of `logoUrl`.
- Add environment-aware launch targets.

### Phase 1C

- Add reconciliation queue and match review flow.
- Add diff panel against master/source records.
- Add audit trail and override reason capture.

## Product Rules To Enforce First

- only truly unavailable demos should render unavailable
- master logo wins when canonical match exists
- `logoAssetId` is the canonical logo field
- `hasGuidedJourney` should be computed from linked journeys, not trusted as imported static truth
- any localhost URL is warning-grade data
- source import should not silently create a canonical demo without match review unless confidence is extremely high

## Non-Goals For Phase 1

- advanced visual polish for the sake of polish
- replacing the current Assistant interaction model
- full automation of reconciliation without human review
- removing backwards compatibility with current fields

## Definition Of Done

Catalog Manager Phase 1 is done when:

- the default view is issue-driven
- canonical records expose separate statuses
- operators can see and fix logo and launch target problems quickly
- preview is clearly separated from operations
- ingestion no longer behaves like direct uncontrolled demo creation
- Assistant can safely prefer trusted, published, healthy demo records
