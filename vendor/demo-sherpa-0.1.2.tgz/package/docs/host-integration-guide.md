# Host Integration Guide

Use this guide when embedding Demo Sherpa into a new host demo.

## Recommended deployment modes

Sherpa now recognizes four practical deployment modes:

- `Browser local`
  - no shared catalog
  - no AI voice endpoint
  - journeys stay in browser storage

- `Voice-enabled local`
  - `ttsEndpoint` configured
  - no shared catalog
  - AI voice works, but journeys still persist locally

- `Shared catalog`
  - `catalogApiBaseUrl` configured
  - shared sync and catalog features enabled
  - AI voice optional

- `Service-backed`
  - `catalogApiBaseUrl` configured
  - `ttsEndpoint` configured
  - best packaged host experience for collaboration plus AI voice

## Minimum host contract

Sherpa expects these inputs from the host:

- `demoContext`
  - include both project and demo identity
- `routeContextResolver(pathname)`
  - provide page-aware presenter notes
- `currentUser`
  - recommended always
  - required in practice for shared sync/governance
- `ttsEndpoint`
  - required only for AI voice features
- `transcribeEndpoint`
  - optional host override for clip transcription
- `translateEndpoint`
  - optional host override for narration refinement or translation
- `catalogApiBaseUrl`
  - required only for shared catalog/sync behavior

## Safe integration checklist

1. Render `DemoSherpaCaptureBridge` once inside the router.
2. Wrap `DemoSherpaGuide` in a host-owned integration component.
3. Pass scoped `demoContext` with project and demo identity.
4. Pass `currentUser` from live session state when available.
5. Add route notes through `routeContextResolver(pathname)`.
6. Add `ttsEndpoint`, `transcribeEndpoint`, and `translateEndpoint` if the host wants to own the AI service routes itself.
7. Add `catalogApiBaseUrl` if the host wants shared journeys and catalog workflows, or if the host wants Sherpa-hosted AI services discovered automatically from the shared API.

## Validation in Studio

Studio now surfaces:

- `Host contract`
- `Deployment mode`
- `Launch actions`
- `Service profile`
- route context, transcription, TTS, catalog, and recorder diagnostics
- `Publish gate`
- `Support snapshot`

Treat those as the first-line validation surface before recording a market-facing journey.

## Service-backed mode

When `catalogApiBaseUrl` points at the Sherpa API, Sherpa now checks `GET /sherpa/service/capabilities` and can automatically use:

- `/sherpa/services/transcribe`
- `/sherpa/services/tts`
- `/sherpa/services/translate`

That means a host can integrate the shared Sherpa API without implementing its own `/api/journey/*` AI routes. If the host already has those routes, `ttsEndpoint`, `transcribeEndpoint`, and `translateEndpoint` remain explicit overrides.

In shared mode, Studio also keeps the last authoritative shared snapshot locally. That gives authors a safer fallback during temporary shared-API outages, while still treating the shared catalog as the authoritative copy.

## Operator handoff

Before staging or production rollout, export both:

- the `Readiness summary`
- the `Support snapshot`

Use `Launch actions` inside Studio as the prioritized rollout queue, then export the artifacts once the checklist is stable. The readiness summary is better for authoring and launch review. The support snapshot is better for operations/support because it condenses deployment mode, authoritative copy, key diagnostics, launch actions, and publish blockers into one short handoff artifact.
