# Demo Sherpa Market Readiness Roadmap

## Goal

Turn Demo Sherpa from a powerful internal authoring/runtime tool into a market-ready product for complex demo authoring, guided playback, multilingual narration, and reusable demo operations.

This roadmap intentionally excludes permissions and identity hardening. Those remain important, but they are out of scope for this plan.

## Product Position

Sherpa should not be framed as a generic floating helper.

The product should be:

- the authoring layer for guided demo journeys
- the playback layer for consistent live delivery
- the localization layer for multilingual narration and presenter guidance
- the operational layer for reusable journeys, demo context, and shared enablement

The strongest market wedge is:

"Make complex solution demos repeatable, presentable, and localizable without turning them into brittle screen recordings."

## Current Reality

Sherpa already has strong foundations:

- journey capture with step-based authoring
- replay and guided playback
- original recording plus AI voice generation
- route-aware and page-aware context
- journey reuse and shared catalog integration
- project-aware governance hooks

Sherpa is not yet market-ready because:

- core host integration is still too variable
- the Studio experience is too dense for non-expert users
- browser-local state still carries too much product responsibility
- the main runtime modules are too large and tightly coupled
- reliability coverage is still too unit-focused instead of workflow-focused

## Phase 1: Product Workflow and Reliability

### Objective

Make Sherpa feel dependable and understandable for real demo authors before tackling deeper platform packaging.

### Outcomes

- recording and playback flows feel deterministic
- source recording, transcript, AI voices, and derived languages are explicit
- Studio becomes easier to understand without losing power
- the most important workflows are covered by browser-level tests

### Workstreams

#### 1. Source recording and voice identity

- keep `sourceRecording` as the canonical human take
- keep `playbackVariants` as explicit voice outputs
- distinguish clearly between:
  - source language
  - original voice
  - AI voice
  - derived language
- require source language confirmation before first recording, while allowing a default suggestion
- allow deleting derived languages cleanly

Acceptance criteria:

- a step always has one canonical source recording identity
- original voice and AI voice are always distinguishable in UI
- derived languages can be removed without corrupting the step

#### 2. Recording workflow hardening

- formalize step-level recording sessions
- fix handoff behavior for:
  - pause -> resume
  - pause -> add step -> continue
  - restart step
  - stop -> background upload
- make recorder actions clearer:
  - `Resume recording`
  - `Add step and continue`
  - `Restart step`

Acceptance criteria:

- no inherited leading silence across steps
- no missing clip boundaries after pause/resume
- recorder state is always visible and understandable

#### 3. Studio information architecture

- evolve the current tab model into an author-first sequence:
  - `Record`
  - `Script`
  - `Voices`
  - `Review`
- keep advanced timing and reliability controls, but behind secondary affordances
- reduce competing concepts on the same screen

Acceptance criteria:

- a new author can complete a 2-step journey without prior coaching
- advanced controls remain available but are not visually dominant

#### 4. Playback clarity

- keep player preferences simple:
  - language
  - voice type
  - playback mode
- improve presenter-facing labels:
  - `Original voice`
  - `AI voice`
  - `Notes source`
- make recovery and paused states clearer

Acceptance criteria:

- a presenter always knows what voice and language are active
- playback problems are surfaced clearly, not inferred

#### 5. Reliability tests

- add browser E2E flows for:
  - record first step
  - pause and resume
  - add step and continue
  - regenerate transcript
  - switch original vs AI playback
  - route context plus step override rendering

Acceptance criteria:

- the top workflow regressions are reproducible and test-protected

## Phase 2: Platform Packaging and Architecture

### Objective

Reduce integration fragility and make Sherpa feel like a product platform, not a per-host customization exercise.

### Outcomes

- a clearer integration contract
- reduced dependency on ad hoc host behavior
- smaller, more maintainable runtime modules
- improved sync and storage architecture

### Workstreams

#### 1. Boxed Sherpa service mode

- support a first-class Sherpa-hosted mode for:
  - transcription
  - TTS
  - catalog/journey sync
- keep host-owned endpoints as overrides, not the default operational assumption
- add startup diagnostics for missing services

Acceptance criteria:

- a new host can get Sherpa working from one setup contract
- AI capabilities behave consistently across hosts

#### 2. Integration SDK and runtime validation

- create a stronger host wrapper contract
- validate:
  - `routeContextResolver`
  - `pageContextResolver`
  - `catalogApiBaseUrl`
  - `ttsEndpoint`
  - `transcribeEndpoint`
  - required user/demo metadata
- surface integration warnings inside Sherpa instead of only in console output

Acceptance criteria:

- host setup errors are diagnosable without deep code inspection

#### 3. Architecture decomposition

- split large modules by domain:
  - recording session controller
  - step audio model
  - playback state machine
  - narration/translation workspace
  - page context management
  - remote sync client
- reduce coupling between Studio UI and runtime logic

Acceptance criteria:

- major runtime modules are smaller and easier to reason about
- changes in one area no longer create broad unintended regressions

#### 4. Remote-first drafts and sync

- move journeys toward remote-first persistence with local draft cache
- treat browser-local storage as resilience support, not the system of record
- expose draft recovery and sync status explicitly

Acceptance criteria:

- refreshing the browser or moving to another machine is not risky
- sync state is inspectable by authors

## Phase 3: Product Polish and Launch Readiness

### Objective

Polish the experience, documentation, diagnostics, and operational guardrails so Sherpa can be presented as a product offering.

### Outcomes

- player and Studio feel intentionally designed
- launch and troubleshooting are well documented
- adoption and demo-author onboarding are simpler

### Workstreams

#### 1. Studio and player polish

- improve spacing, hierarchy, and state design
- remove residual internal/debug language
- add clearer success, warning, and review states
- make media, voice, and overview areas feel authored instead of technical

Acceptance criteria:

- Studio feels like an authoring product, not an engineering console
- player feels safe to use live in front of customers

#### 2. Diagnostics and support tooling

- add integration diagnostics view
- add journey health/status summary
- add asset and narration readiness checks
- add exportable support snapshots

Acceptance criteria:

- most field issues can be diagnosed without reading source code

#### 3. Documentation and onboarding

- publish docs for:
  - product overview
  - host integration
  - author workflow
  - source vs AI narration model
  - page context vs step override model
  - launch checklist

Acceptance criteria:

- another team can adopt Sherpa without pairing with the core developers

#### 4. Launch readiness checklist

- define launch checklist across:
  - integration
  - services
  - asset lifecycle
  - sync
  - testing
  - diagnostics
  - docs

Acceptance criteria:

- the product can be evaluated with a consistent release gate instead of intuition

## Release Order

Recommended order:

1. Phase 1 first
2. Phase 2 second
3. Phase 3 last

Do not start with surface polish alone. Reliability, workflow clarity, and packaging must land first.

## Success Metrics

Suggested metrics for this roadmap:

- time to create a new 3-step journey
- rate of failed or retried recordings
- rate of source-language mismatch or transcript correction
- time to diagnose integration issues
- number of host-specific fixes required per integration
- number of replay regressions caught by automated tests before manual QA

## Exit Criteria

Sherpa should be considered market-ready only when:

- recording/playback flows are deterministic under the main author workflows
- the source recording and AI voice model is explicit and reliable
- host integration is boxed and diagnosable
- critical flows have E2E coverage
- Studio and player are understandable without expert guidance
- launch and operations documentation exist and are usable
