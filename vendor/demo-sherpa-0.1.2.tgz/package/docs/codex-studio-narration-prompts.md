# Codex prompt pack for Studio narration refactor

Use these prompts in order.

## Prompt 1: plan only
I need a design and phased implementation plan only. Do not write code yet.

Context:
We have a demo-journey product. Today, an author records one full step in one go, so each step often has one long audio file. We can transcribe the audio to text, but we lose the meaningful pause structure. When we synthesize that text with a digital voice or translate it into another language, the pacing becomes unnatural and the audio drifts from the UI flow.

Core problem:
We currently model narration as one monolithic step audio. That is the wrong abstraction for multilingual playback and reliable pacing.

New target model:
A step must be represented as an ordered sequence of timed narration units:
- speech units
- silence or pause units

Each speech unit should keep timing marks from the original recording.
Each pause should be explicit data, not inferred only from punctuation.

Playback must be state-driven:
- narration should wait for UI checkpoints when needed
- if the UI flow is lost, playback should pause instead of continuing blindly

Please inspect the codebase and produce:
1. Current architecture map for step recording, transcript extraction, storage, editor UI, TTS and translation, and step playback
2. Where the current model causes timing drift
3. Proposed schema and data model changes
4. Proposed APIs and services
5. A phased implementation plan with low-risk slices
6. Migration strategy for old steps
7. Test strategy
8. Risks and rollback plan

Important constraints:
- Keep legacy recorded audio working during migration
- Do not propose exact dubbing of a whole translated step to one exact total duration
- Prefer chunked narration with approximate timing bands
- Preserve compatibility with the existing step player where possible
- Minimize vendor lock-in for ASR and TTS

At the end, give me:
- the recommended architecture
- the first implementation slice
- the files and components you expect to touch
- the acceptance criteria for each slice

## Prompt 2: implement slice 1 only
Implement slice 1 only.

Goal:
Refactor the system so a step can store timed narration segments derived from the original recorded audio.

Requirements:
1. From the original recorded step audio, extract:
   - full transcript
   - word-level timestamps if the current ASR supports them; otherwise sentence or phrase timing with a clear fallback path
   - silence intervals and pause durations

2. Build a segmenter that creates an ordered list of narration segments:
   - type equals speech or silence
   - segment boundaries should prefer:
     a) manual markers if present
     b) UI checkpoint anchors if present
     c) long pauses such as greater than 300 to 400 ms
     d) sentence boundaries

3. Persist for each speech segment:
   - step_id
   - ordinal
   - source_language
   - source_text
   - source_start_ms
   - source_end_ms
   - target_duration_ms
   - pause_after_ms
   - checkpoint_key nullable
   - review_status

4. Persist for each silence segment:
   - step_id
   - ordinal
   - start_ms
   - end_ms
   - duration_ms

5. Update the editor UI so authors can:
   - see generated segments
   - split or merge speech segments
   - edit pause durations
   - assign or edit checkpoint keys
   - keep old full-step audio visible as legacy source

6. Do not implement TTS yet.
7. Keep current recorded-step playback working.
8. Add tests for:
   - segment creation
   - pause extraction
   - split and merge editing
   - migration safety

Important:
- Do not rely on punctuation alone to recover pauses
- Do not remove legacy playback yet
- Add a short ADR or design note explaining the new model

At the end:
- summarize what changed
- show schema changes
- list tests added
- report blockers for the next slice

## Prompt 3: implement slice 2 on top
Implement slice 2 on top of the timed segment model.

Goal:
Support translated and synthesized narration without forcing a whole step into one long audio file.

Requirements:
1. Translate per speech segment, not per whole step
2. Generate TTS per speech segment
3. Render pauses explicitly from stored silence or pause data
4. Use approximate timing, not exact timing:
   - each generated speech segment should aim for a duration band relative to original
   - first implementation target is 85 percent to 115 percent of original speech segment duration
5. If a generated segment is outside the duration band:
   - first try a small speech-rate adjustment within safe bounds
   - if still outside band, split segment and retry, or flag for manual review
6. Store translated text and generated audio per segment
7. Update player to play segment by segment
8. If a segment has checkpoint_key:
   - do not continue past that point until checkpoint is reached
   - if not reached within timeout, pause playback and show recovery UI

Recovery UI should offer:
- Retry checkpoint
- Continue manually
- Skip to next segment or step

Acceptance criteria:
- translated narration no longer depends on one monolithic step audio file
- pauses sound intentional because they come from explicit pause data
- synthetic pace is natural enough without exact waveform mimicry
- playback pauses when UI flow is lost
- legacy recorded audio still works
- tests cover timing-band enforcement and checkpoint pause behavior

Important:
- Do not implement full-step exact dubbing
- Do not hide timing failures; surface them for review
- Keep provider-specific TTS logic behind an adapter interface

## Extra instruction for all slices
Also add optional manual timing markers. Automatic segmentation is helpful, but authors must be able to override boundaries, pauses, and checkpoint anchors in the editor.
